-- Generated file, do not edit.
local addon, _ns = ...

if (GetLocale() ~= 'frFR') then return end

local L = _G[addon].L
L[" (current stack of %d)"] = "(pile actuelle de %d)"
L[" (full stack of %d)"] = "(pile complète de %d)"
L[" (item doesn't stack)"] = "(l'objet ne s'empile pas)"
L[" (per item)"] = "(par objet)"
L["Better Vendor Price bug report open: "] = "Better Vendor Price rapport de bug ouvert:"
L["Bug report from slash command"] = "Rapport de bug depuis la commande slash"
L["Debug level"] = "Niveau de debug"
L["Development, troubleshooting and advanced options:"] = "Développement, problèmes et options avancées:"
L["Get Information to submit a bug."] = "Obtenir les informations pour rapporter un bug."
L["Please submit on discord or on https://|cFF99E5FFbit.ly/vendorbug|r  or email"] = "Merci de rapporter les bugs sur discord ou sur https://|cFF99E5FFbit.ly/vendorbug|r ou par email"
L["Sets the debug level"] = "Configurer le niveau de debug"
L["These options let you control the behavior of BetterVendorPrice"] = "Voici les options de BetterVendorPrice"
L["Vendors for:"] = "Vendeurs :"

