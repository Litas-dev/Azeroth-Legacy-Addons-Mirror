-- Generated file, do not edit.
local addon, _ns = ...

if (GetLocale() ~= 'koKR') then return end

local L = _G[addon].L
L[" (current stack of %d)"] = "(현재 %d중첩)"
L[" (full stack of %d)"] = "(최대 %d중첩)"
L[" (item doesn't stack)"] = "(중첩 안 됨)"
L[" (per item)"] = "(아이템 당)"
L["Bug Report"] = "버그 신고"
L["Bug report from slash command"] = "슬래시 명령의 버그 리포트"
L["Debug level"] = "디버그 레벨"
L["Development, troubleshooting and advanced options:"] = "개발, 문제 해결 및 고급 옵션:"
L["Get Information to submit a bug."] = "버그를 제출하기위한 정보를 얻으십시오."
L["Please submit on discord or on https://|cFF99E5FFbit.ly/vendorbug|r  or email"] = "디스코드 또는 https://|cFF99E5FFbit.ly/vendorbug|r 이메일로 제출하십시오"
L["Sets the debug level"] = "디버그 레벨을 설정합니다."
L["Show AHDB info"] = "AHDB 정보 표시"
L["Show AHDB min bid"] = "AHDB 최소 입찰가 표시"
L["Show all only when Shift is held"] = "Shift 키를 누른 상태에서만 모두 표시"
L["These options let you control the behavior of BetterVendorPrice"] = "이 옵션을 사용하면 BetterVendorPrice의 동작을 제어 할 수 있습니다."
L["Vendors for:"] = "상점가:"
L["Whether to show the AHDB info or not"] = "AHDB 정보 표시 여부"
L["Whether to show the AHDB min bid or not"] = "AHDB 최소 입찰가 표시 여부"

