-- Generated file, do not edit.
local addon, _ns = ...

if (GetLocale() ~= 'enUS') then return end

local L = _G[addon].L
L[" (% |4seller:sellers;), "] = true
L[" (%+ sellers), "] = true
L[" (curr. full stack of %d)"] = true
L[" (curr. stack of %d/%d)"] = true
L[" (current stack of %d)"] = true
L[" (full stack of %d)"] = true
L[" (item doesn't stack)"] = true
L[" (per item)"] = true
L[" (per; stacks to %d)"] = true
L["% |4item:total items;"] = true
L["AHDB buyout"] = true
L["AHDB last scan: % |4auction:auctions;"] = true
L["AHDB minbid"] = true
L["Better Vendor Price"] = true
L["Better Vendor Price bug report open: "] = true
L["Better Vendor Price options"] = true
L["Bug Report"] = true
L["Bug report from slash command"] = true
L["Debug level"] = true
L["Development, troubleshooting and advanced options:"] = true
L["Get Auction House DataBase (|cFF99E5FFAHDB|r) v0.12 or newer to see auction information on the toolip!"] = true
L["Get Information to submit a bug."] = true
L["Please submit on discord or on https://|cFF99E5FFbit.ly/vendorbug|r  or email"] = true
L["Sets the debug level"] = true
L["Show AHDB info"] = true
L["Show AHDB min bid"] = true
L["Show all only when Shift is held"] = true
L["Show full stack vendor price info"] = true
L["These options let you control the behavior of BetterVendorPrice"] = true
L["Vendors for:"] = true
L["Whether to require the shift key to show full info"] = true
L["Whether to show the AHDB info or not"] = true
L["Whether to show the AHDB min bid or not"] = true
L["Whether to show the up to 3 lines vendor pricing info or skip the full stack one"] = true

