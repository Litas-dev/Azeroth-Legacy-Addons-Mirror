-- Generated file, do not edit.
local addon, _ns = ...

if (GetLocale() ~= 'ruRU') then return end

local L = _G[addon].L
L[" (% |4seller:sellers;), "] = "(% |4продавец:продавцы;),"
L[" (%+ sellers), "] = "(%+ продавцы),"
L[" (curr. full stack of %d)"] = " ( полная стопка %d шт. )"
L[" (curr. stack of %d/%d)"] = "(только стаки %d/%d)"
L[" (current stack of %d)"] = " ( %d шт. )"
L[" (full stack of %d)"] = " ( полная стопка %d шт. )"
L[" (item doesn't stack)"] = " ( не складывается )"
L[" (per item)"] = " ( 1 шт. )"
L[" (per; stacks to %d)"] = " ( 1 шт.; стопка %d шт. )"
L["% |4item:total items;"] = "% |4предмет:всего предметов;"
L["AHDB buyout"] = "Выкуп AHDB"
L["AHDB last scan: % |4auction:auctions;"] = "Последнее сканирование AHDB: % |4аукцион:аукционы;"
L["AHDB minbid"] = "AHDB  минимальная ставка"
L["Better Vendor Price"] = true
L["Better Vendor Price bug report open: "] = "Better Vendor Price открыто сообщение об ошибке:"
L["Better Vendor Price options"] = "Better Vendor Price Параметры"
L["Bug Report"] = "Сообщение об ошибке"
L["Bug report from slash command"] = "Отчет об ошибке из команды слеш"
L["Debug level"] = "Уровень отладки"
L["Development, troubleshooting and advanced options:"] = "Разработка, устранение неполадок и расширенные возможности:"
L["Get Auction House DataBase (|cFF99E5FFAHDB|r) v0.12 or newer to see auction information on the toolip!"] = "Установите Auction House DataBase (|cFF99E5FFAHDB|r) v0.12 или новее, \\n чтобы увидеть информацию об аукционе на всплывающей подсказке!"
L["Get Information to submit a bug."] = "Получите информацию, чтобы отправить сообщение об ошибке."
L["Please submit on discord or on https://|cFF99E5FFbit.ly/vendorbug|r  or email"] = "Пожалуйста, отправьте в дискорд https://|cFF99E5FFbit.ly/vendorbug|r или по электронной почте"
L["Sets the debug level"] = "Устанавливает уровень отладки"
L["Show AHDB info"] = "Показать информацию AHDB"
L["Show AHDB min bid"] = "Показать минимальную ставку AHDB"
L["Show all only when Shift is held"] = "Показать все только когда удерживается Shift"
L["Show full stack vendor price info"] = "Показать информацию о цене продавца полного стака"
L["These options let you control the behavior of BetterVendorPrice"] = "Эти параметры позволяют контролировать поведение BetterVendorPrice"
L["Vendors for:"] = "Цена продажи:"
L["Whether to require the shift key to show full info"] = "Требовать ли клавишу Shift для отображения полной информации"
L["Whether to show the AHDB info or not"] = "Показывать ли информацию AHDB или нет"
L["Whether to show the AHDB min bid or not"] = "Показывать ли минимальную ставку AHDB или нет"
L["Whether to show the up to 3 lines vendor pricing info or skip the full stack one"] = "Показывать ли информацию о цене продавца до 3-х строк или пропустить полные стаки"

