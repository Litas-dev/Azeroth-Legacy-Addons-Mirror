# Better Vendor Price

## [v1.17.04](https://github.com/mooreatv/BetterVendorPrice/tree/v1.17.04) (2022-10-25)
[Full Changelog](https://github.com/mooreatv/BetterVendorPrice/compare/v1.17.03...v1.17.04) [Previous Releases](https://github.com/mooreatv/BetterVendorPrice/releases)

- Dragonflight toc  
