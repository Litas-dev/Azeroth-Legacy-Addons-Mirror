\# Auctioneer + BigPicture (Warparia / Ascension Bronzebeard Build)



A working, cleaned version of Auctioneer with BigPicture enabled and tested on Ascension Bronzebeard (Warparia client compatibility).  

This build restores full Auctioneer functionality including market scans, price data UI, and BigPicture expanded auction interface.



---



\## ✦ Features



\- Auctioneer Core + Modules working

\- BigPicture fully operational

\- Scan-based pricing + AH tools

\- Buyout/stack comparisons

\- Tooltip market pricing data



Perfect for players running Auction House operations, flipping, market posting, and economic playstyles.



---



\## 🔧 Installation



1\. Download the latest release `.zip`

2\. Extract the folder \*\*MOVE FILES INSIDE THIS FOLDER\*\* into:




3. Launch game → AddOns menu → **Enable "Load out of date addons"**
4. Log in and open Auction House to confirm BigPicture loads

---

## Folder Structure



If you see `AddOns/Auctioneer/Auctioneer+bean counter and the others/` then move the inner folder up one level.

---

## 🛠 Notes

- No personal SavedVariables included
- Use `/auc` or `/auctioneer` for commands
- Initial scan recommended for pricing accuracy

Run:


---

## Known Limitations

- UI may show "out of date" – safe to ignore
- Use with or without TSM (standalone recommended)

---

## Updates & Support

Future versions will include:
- Config-friendly SavedVariables export
- Optional AH UI skin
- Auto-version checker

Feedback, issues, suggestions welcome.


