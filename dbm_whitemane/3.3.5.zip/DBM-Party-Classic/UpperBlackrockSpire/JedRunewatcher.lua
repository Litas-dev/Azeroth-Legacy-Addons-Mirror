local mod	= DBM:NewMod("JedRunewatcher", "DBM-Party-Classic", 4)
local L		= mod:GetLocalizedStrings()

mod:SetRevision("20220518110528")
mod:SetCreatureID(10509)

mod:RegisterCombat("combat")
