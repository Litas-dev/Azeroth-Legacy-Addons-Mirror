local mod	= DBM:NewMod("TheRavenian", "DBM-Party-Classic", 13)
local L		= mod:GetLocalizedStrings()

mod:SetRevision("20220518110528")
mod:SetCreatureID(10507)

mod:RegisterCombat("combat")
