local mod	= DBM:NewMod(419, "DBM-Party-Classic", 7, 231)
local L		= mod:GetLocalizedStrings()

mod:SetRevision("20220518110528")
mod:SetCreatureID(7361)

mod:RegisterCombat("combat")
