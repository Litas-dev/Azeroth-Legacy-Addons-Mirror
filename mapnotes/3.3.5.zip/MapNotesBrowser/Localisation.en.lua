
MNB_NAME = "MapNotes Browser";

MNB_ALLMAPS = "All Maps";
MNB_SEARCH = "Search";
