
MNB_NAME = "MapNotes Suche";

MNB_ALLMAPS = "Alle Karten";
MNB_SEARCH = "Suche";
