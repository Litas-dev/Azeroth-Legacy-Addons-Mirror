Welcome to Rested.

Rested shows the rested status of your alts in one simple command.

How to use:
Install the addon for any alt you wish to track. Log into that alt.
Type '/rested' to see a list of alts and their rested status.

Rested shows:
Character level    - What level the character is was at when last seen.
Resting status     - + means resting, - means not resting
Rested percent     - Total expected rested amount.  This is green if the 
                   - rested will take the alt into the next level.
(Rested Gained)    - Amount of rested xp gained since last logged into.
Realm : Char Name  - The realm and name of the character.


This list is filtered to not show alts at max level, and not to show alts that
were last seen with full rested status.

Alts can be removed from the list, at least until the next time they are seen, by using
'/rested -name'. 'name' will be removed from the list of alts being tracked.

Commands:
/rested             -> Rested Report
/rested -name       -> Removes name from tracking
/rested max         -> Shows list of max level characters - (shows older than nagtime, but less than stale time)
/rested status      -> Shows status message
/rested stale       -> Shows characters older than stale
/rested nagtime #   -> Sets nagtime for max level characters


Change Log:
1.2     - added a function to show the time since level 80's have been seen.
        - inits cutoff value at 7 days.
		- /rested nagtime # sets cutoff value
		- status massage shows character and realm count
		- stale value set to 10 days
		- stale report
1.1		- changed output to show time till fully rested.


To do:
- Show time until rested to next level
- Limit to the last n alts
- Only show those that are rested past the next level
