BossTactics improves and simplifies explaining boss tactics in World of Warcraft.

-------------------
---Main Features---
-------------------

    * Tactics for all Raidinstances ingame
    * Maps for every bosslocation, to show where people have to stand
    * Buttons for playerpositions
    * Raidleaders can add/remove/move/rename Buttons
    * Raidleader chat
    * Control if people are actually watch the right scene
    * Short Bosstactics for the Raid-chat
    * Sessions for explainig a Bosstactic
    * Save your own tactic for Bosses or Trash and switch between yours and the standard
    * Trash tactics, if available
    * Ping on the image
    * Painting on the image
    * Class and role chat channels
    * Range-Check frame
    * Synchronizable tactic texts
    * Queries for Addon- and Item-Checks
    * Assigning tasks to tanks, healers, and special roles depending on the bosses
    * ID tracking for all your characters. Realm independent.
    * 5-man instances quickinfos and tactics
    * Raidleaders can perform acclamations

--------------------------
-----Instance Modules-----
--------------------------

This version contains only the framework, if you like to download only a few instance modules, you can find them by searching for "BossTactics_*" on curse.com
You can find download links of the modules and module collections on the curse project. You can find it here:
http://www.curse.com/downloads/wow-addons/details/boss-tactics.aspx

To install a module it must not be copied into the BossTactics folder, you must copy them into the addons folder. So in a sense
every module is an Addon on its own.

-----------------------
----Slash Commands-----
-----------------------

/bt or /bosstactics for overview

/bt show opens bossframe

(check the others in the overview)

------------------------
---------Website--------
------------------------

For news and other features, see www.bosstactics.net