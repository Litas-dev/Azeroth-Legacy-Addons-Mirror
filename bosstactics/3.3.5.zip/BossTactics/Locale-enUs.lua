local L = LibStub("AceLocale-3.0"):NewLocale("BossTactics", "enUS", true)
if not L then return end

-- Chat commands
L["BossTactics"] = "bosstactics"
L["bt"] = "bt"
L["menu options tab"] = "Show options tab"
L["menu main frame"] = "Show the Boss Frame"
L["menu info"] = "Show Info"
L["menu debug"] = "Enter debug mode"
L["menu minimap"] = "Show or hide minimap button"
L["menu SessionAbort"] = "Raidleaders can abort a running session"
L["menu main frame hide"] = "Hide the main frame"
L["menu join"] = "Join a class channel"
L["menu quit"] = "Quit a class channel"
L["hide"] = true
L["menu chaninfo"] = "Show joined channels"
L["menu chatinfo"] = "Show member of channel x"
L["menu chatconfig"] = "Config some features of the chat"
L["menu cameramax"] = "Sets the possible camera distance to the maximum value"
L["menu rangecheck"] = "Opens the Range Frame"
L["menu fontsize"] = "Change Tactic text size to <value>"
L["menu itemId"] = "Shows the id of a given Item"
L["menu vote"] = "Start an acclamation (only for raid leaders)"

--Button labels
L["healer"] = "healer"
L["melee"] = "melee"
L["ranged DPS"] = "ranged DPS"
L["tank"] = "tank"
L["boss"] = "boss"

--Gui
--common Gui
L["Ok"] = "Ok"
L["Cancel"] = "Cancel"
L["Close Menu"] = "Close Menu"
L["Yes"] = "Yes"
L["No"] = "No"
L["All"] = true
L["Close"] = true

L["SwitchStd"] = "Show Standard"
L["SwitchMy"] = "Show my notices"
L["Tactic"] = "Tactic"
L["Trash"] = "Trash"
L["PingBtn"] = "Ping"
L["PaintBtn"] = "Paint"
L["PaintDelBtn"] = "Clear drawing"

--left panel
L["5-man instances"] = true
L["Instances"] = "Instances"
L["Bosses"] = "Bosses"
L["mode"] = true
L["Session"] = "Start Session"
L["EndSession"] = "End Session"
L["Info"] = "Info"
L["Options"] = "Options"
L["Sync"] = "Synchronize"
L["LeaderSync"] = "Synchronize Raid"
L["Recover Standard"] = "Recover Standard"
L["Recover Session"] = "Reset Session"
L["Save"] = "Save"
L["SaveAs"] = "New Text"
L["RaSend"] = "Send RA-Msg"
L["VerBtn"] = "Get Versions"
L["Title Inputframe"] = "Button Name"
L["No picture"] = "no picture available"
L["Tactic Mode"] = true
L["Raidleader Actions"] = "Actions"
L["TextSyncBtn"] = "Sy"
L["Raidleader"] = "Set Raidleaders"
L["Query Manager"] = true
L["Delete"] = true
L["Execute"] = true
L["Check"] = true
L["New"] = true
L["Task Manager"] = true
L["Raid View"] = true

--Leader Gui
L["Title Raidmessage"] = "Short Bossoverview"
L["Title Addonlist"] = "Version Overview"
L["out of sync"] = "out of sync"
L["module incompatible"] = true
L["No addon found"] = "no BossTactics"
L["version incompatible"] = "incompatible"
L["offline"] = true

L["Title Groupmessage"] = "Group Messages"
L["Post Message"] = true

--minimap
L["version"] = "Version %s"
L["tooltip1"] = "Easy explain Bosses"
L["tooltip2"] = "rightclick to drag"

--Main
L["Module disabled"] = "Module |cffdf6003%s|r is disabled"
L["Module missing"] = "Module |cffdf6003%s|r is missing"
L["Module currupt"] = "Module |cffdf6003%s|r is currupt"
L["Module interface version"] = "Module |cffdf6003%s|r is not compatible with this interface Version"
L["Module loaded"] ="Module |cffdf6003%s|r loaded"

L["title info"] = "BossTactics version %s"
L["info text"] = "Addon for easy explaining bosstactics for raid instances.\n\n |cff91069EProgrammed by|r Sorontur @Mal'GanisEU\n|cff91069EGraphics by|r Vonswan @MalygosEU\n\n|cffC0C0C0[http://bosstactics.net]|r\n\nModuleinfo:\n\n"
L["update info text"] = "The current module has new tactical data.\nWould you like to load the new Version? Your own changes will be lost but it is highliy recommendet to load the new Version. Please reload your interface to get the changes work."
L["Close info text"] = "You have started a Session. If you want to close the window, the session will be closed"
L["Version info text"] = "Your Version is incompatible. Please visit our website www.bosstactics.net to get updates."
L["no save while session"] = "You cannot save while a session is going on.\nPlease wait until it is closed."
L["not while session"] = "You cannot do that while a session is going on.\nPlease wait until it is closed."
L["tactic question text"] = "You are in a group which is normally not in the instance. Would you like to follow the tactics anyway?"
L["mode not supported"] = "This mode is not supported by this instance."
L["Title New Text Inputframe"] = "New Text"
L["Title New Query Inputframe"] = "New Query"
L["New Text info"] = "Give the name of the new text:"
L["New Query info"] = "Give the name of the new query:"
L["del tactic message"] = "You really want to delete that text?"
L["syncmessage"] = "Synchronisation %.0f%% finished." 
L["incompatible module"] = "This module has a new version.\nPlease update it because BossTactics cannot work with you version."
L["title ChatConfig"] = "Chat Config"
L["Camera set to max distance"] = true
L["move start"] = "The main frame is now movable. Click again on the button to fix it."
L["move end"] = "The main frame is now fixed."
L["tactic name already used"] = "This tactic name is already used. Please choose another one."
L["text size changed"] = "Font size changed to %d"
L["del query message"] = "Do you really like to delete that query?"
L["Ora MT checkbox"] = "Use the MT-Targets defined in oRA for tanks"

--errors
L["Out of synch with raidleader"] = "Out of synch with raidleader"
L["error fontsize"] = "Please put in a number"
L["no print without group"] = "You are not in a party"
L["no raid"] = "You are not in a raid"

--infos
L["defaults recovered"] = "defaults recovered"
L["minimap off"] = "Minimapbutton turned off"
L["minimap on"] = "Minimapbutton turned on"
L["session started"] = "Raidleader %s has started a session"
L["session ended"] = "Raidleader %s has ended the session"
L["SessAbortPermitted"] = "You are not allowed to kill sessions"
L["5man in session not allowed"] = "You cannot open a 5-man instance in a session."

--vote
L["rl vote title"] = "Start an acclamation"
L["vote title"] = "Acclamation from %s"
L["Start vote"] = "Start Acclamation"
L["Title vote alts"] = "Alternatives (new line, new alternative)"
L["std alts"] = "yes\nno"
L["Title vote Input"] = "Question"
L["vote err1"] = "You will need at least two alternatives."
L["vote err2"] = "The question is missing"
L["vote err3"] = "You cannot use more than five alternatives"
L["Cancel Vote"] = "Abstain"
L["Vote Time text"] = "You have %d seconds left for voting"
L["Send"] = "Send"
L["selfvote"] = "\nPlease select your vote"
L["Abstention"] = true
L["Vote Time rl text"] = "The Acclamation lasts max %d seconds."
L["vote done"] = "Acclamation is done"
L["PrintVote"] = "Print result"
L["voteRa"] = "Results for Acclamation %s"
L["vote chat err"] = "You have to be a promoted raid leader in BossTactics to be able to perform acclamations"
L["Vote"] = "Acclamation"

--raidleaders frame
L["raidleaders title"] = "Raidleader"
L["Title Choosable"] = "Choosable:"
L["Title selected"] = "Selected:"
L["text sync on"] = "Turn text sync off"
L["text sync off"] = "Turn text sync on"
L["text lock on"] = "unlock text"
L["text lock off"] = "lock text"

--Task manager frame
L["Player:"] = true
L["Task:"] = true
L["Post"] = true
L["tanks "] = true
L["heals "] = true
L["PostAll"] = "Post all"
L["tank intro"] = "Tank allocation (Tank - Target):"
L["healer intro"] = "Healer allocation (Healer - Targets):"
L["melee intro"] = "Melee allocation:"
L["range intro"] = "Range allocation:"
L["info no task"] = "You must first select an instance before you can choose tasks."
L["task extro"] = "Whisper %s to get your assignment"
L["no task"] = "You do not have a special assignment"


--query manager frame
L["Type:"] = true
L["Query:"] = true
L["Valid input"] = "This is a valid input"
L["Invalid input"]  = "This input is invalid. Please check if it is spelled correctly."
L["No text"] = "There is no text in the input."
L["Query Save Ok"] = "The query was saved successfully."
L["Query name exists"] = "A query with this name already exists"
L["Query deleted"] = "The query is deleted."
L["Query not saved"] = "Save is not possible here"
L["Query not work"] = "This Query is not be true for yourself."
L["Warning: "] = true
L["Error: "] = true
L["Query Result"] = true
L["No char allowed"] = "The char %s is not allowed in the input"
L["usage ItemId"] = "Please add the item link. You can do this by shift + klick on the item."
L["Help"] = true

--range check frame
L["set range to"] = "%d yd"
L["range check header"] = "Range Check (%d yd)"
L["range check hide"] = "Hide"
L["range check set range"] = "Set range"

L["Outdoor"] = "Worldbosses"

--update infomessages
L["updateinfo for version 1.1"] = "The database must be updated. All modules will be loaded, you loose no information." 
L["updateinfo for version 2.9"] = "All Modules will be updated. You will loose no information."

--Leader frame
L["Text Save Checkbox"] = "Save for future Raids. (Means that players will be promoted assistant automaticaly)"

--Id Info Frame
L["title IdInfo"] = "ID information"
L["Id Info"] = true
L["Char"] = "Char:"

--channels
L["shortcut for deathknight channel"] = true
L["deathknight channel"] = true
L["shortcut for druid channel"] = true
L["druid channel"] = true
L["shortcut for hunter channel"] = true
L["hunter channel"] = true
L["shortcut for mage channel"] = true
L["mage channel"] = true
L["shortcut for paladin channel"] = true
L["paladin channel"] = true
L["shortcut for priest channel"] = true
L["priest channel"] = true
L["shortcut for rogue channel"] = true
L["rogue channel"] = true
L["shortcut for shaman channel"] = true
L["shaman channel"] = true
L["shortcut for warlock channel"] = true
L["warlock channel"] = true
L["shortcut for warrior channel"] = true
L["warrior channel"] = true
L["shortcut for range DD channel"] = true
L["range dd channel"] = true
L["shortcut for melee channel"] = true
L["melee channel"] = true
L["shortcut for healer channel"] = true
L["healer channel"] = true
L["shortcut for tank channel"] = true
L["tank channel"] = true

L["dk"] = true
L["d"] = true
L["h"] = true
L["m"] = true
L["p"] = true
L["pr"] = true
L["r"] = true
L["s"] = true
L["w"] = true
L["wa"] = true
L["he"] = true
L["dd"] = true
L["me"] = true
L["t"] = true


L["channel not found"]  = "channel %s not found"
L["you are not in this channel"] = true
L["already in channel"] = "You are already in the %s channel"
L["channel joined"] = "|cff%sYou have joined the %s channel|r"
L["channel quit"] = "|cff%sYou have left the %s channel|r"
L["you are in channels: "] = "you are in channels: %s"
L["members of channel"] = "members of channel %s:"
L["you are not in a raid"] = true

--channel config frame
L["select channel"] = true
L["Color"] = true

--help texts
L["help query addons"] = [[
Usage of addon queries:

Syntax:
Addon names are in quotation marks
Logical connectors are 'or' and 'and'
You can use brackets
and binds stronger than or

Result:
Red - Addon is not installed
Yellow - Addon is installed but deaktivated
Green - Addon is active

Example:
("Addon1" or "Addon2") and "Addon3"
]]
L["help query items"] = [[
Usage of item queries:

ItemIds:
BossTactics has a chat command, which gives you the itemId
/BossTactics itemid <itemlink>
<itemlink> is an item link (you can create it with shift + click on an item in your bag)

Syntax:
ItemId comparison operator value
Possible comparison operators are < > <= >= =
Values are natural numbers bigger or equal than 0
You can use brackets
and binds stronger than or

Result:
You will get the count of the items. Is a term valid, it is green. If it is not valid it is red.

Example:
(4711 = 5 or 4242 <= 20) and 13 = 7
]]