local L = LibStub("AceLocale-3.0"):NewLocale("BossTactics", "deDE")
if not L then return end


-- Chat commands
L["BossTactics"] = "bosstactics"
L["bt"] = "bt"
L["menu options tab"] = "Zeige Optionen Fenster"
L["menu main frame"] = "\195\150ffnet das Boss Fenster"
L["menu info"] = "Zeige Info"
L["menu debug"] = "Schaltet den debug Modus ein"
L["menu minimap"] = "Anzeigen oder Verstecken des Minimap-Buttons"
L["menu SessionAbort"] = "Raidleiter k\195\182nnen eine Session abbrechen"
L["menu main frame hide"] = "Schlie\195\159e das Hauptfenster"
L["menu join"] = "Einem Klassenchannel beitreten"
L["menu quit"] = "Einen Klassenchannel verlassen"
L["hide"] = "schließen"
L["menu chaninfo"] = "Beigetretene Channel anzeigen"
L["menu chatinfo"] = "Zeigt die Member in Channel x an"
L["menu chatconfig"] = "Konfiguration der Chatfeatures"
L["menu cameramax"] = "Setzt die maximale Kameraentfernung auf den größten Wert"
L["menu rangecheck"] = "Öffnet den Abstandsmesser"
L["menu fontsize"] = "Taktiktext Schriftgröße auf <Wert> ändern"
L["menu itemId"] = "Zeigt die Id eines Items an"
L["menu vote"] = "Starte eine Abstimmung (nur als Raidleiter)"

--Button labels
L["healer"] = "Heiler"
L["melee"] = "Nahk\195\164mpfer"
L["ranged DPS"] = "Fernk\195\164mpfer"
L["tank"] = "Tank"
L["boss"] = "Boss"
L["SwitchStd"] = "Zeige Standard"
L["SwitchMy"] = "Zeige meine Notizen"
L["Tactic"] = "Taktik"
L["Trash"] = "Trash"
L["PingBtn"] = "Ping"
L["PaintBtn"] = "Zeichnen"
L["PaintDelBtn"] = "Zechnung entfernen"
L["Tactic Mode"] = "Taktik Modus"
L["Raidleader Actions"] = "Aktionen"
L["TextSyncBtn"] = "Sy"
L["Raidleader"] = "Setze Raidleiter"
L["Query Manager"] = true
L["Delete"] = "L\195\182schen"
L["Execute"] = "Ausführen"
L["Check"] = "Prüfen"
L["New"] = "Neu"
L["Task Manager"] = "Aufgaben-Manager"
L["Raid View"] = "Raidansicht"

--Gui
--common elements
L["Ok"] = "Ok"
L["Cancel"] = "Abbrechen"
L["Close Menu"] = "Schlie\195\159e Men\195\188"
L["Yes"] = "Ja"
L["No"] = "Nein"
L["All"] = "Alle"
L["Close"] = "Schließen"

--left panel
L["5-man instances"] = "5-Mann Instanzen"
L["Instances"] = "Instanzen"
L["Bosses"] = "Bosse"
L["mode"] = "Mode"
L["Session"] = "Starte Session"
L["EndSession"] = "Beende Session"
L["Info"] = "Info"
L["Options"] = "Optionen"
L["Sync"] = "Synchronisiere"
L["Save"] = "Speichern"
L["SaveAs"] = "Neuer Text"
L["RaSend"] = "Sende RA-Msg"
L["LeaderSync"] = "Synchronisiere Raid"
L["VerBtn"] = "Hole Versionen"
L["Recover Standard"] = "Standard Wiederherstellen"
L["Recover Session"] = "Session zur\195\188setzen"
L["No picture"] = "Kein Bild vorhanden"

L["title info"] = "|cffdf6003BossTactics|r version %s"
L["info text"] = "Addon zur einfachen Erl\195\164uterung von Raidbossen.\n\n|cff91069EProgrammed by|r Sorontur @Mal'GanisEU\n|cff91069EGraphics by|r Vonswan @MalygosEU\n\n|cffC0C0C0[http://bosstactics.net]|r\n\nModulinfo:\n\n"
L["Title Inputframe"] = "Button Bezeichnung"
L["update info text"] = "Das aktuelle Modul hat neue Taktikdaten.\nWillst du die neuen Daten laden? Deine eigenenen \195\132nderungen gehen verloren, trotzdem ist es empfohlen die neuen Daten zu laden. Damit die \195\132nderung wirksam wird muss das Interface neu geladen werden."
L["Close info text"] = "Du hast noch eine Session aktiv. Willst du das Fenster schlie\195\159en? Die Session wird beendet."
L["Version info text"] = "Deine Version ist inkompatibel. Schau bitte auf der Website www.bosstactics.net nach Updates."
L["no save while session"] = "W\195\164hrend einer Session kannst du nicht speichern.\nWarte bis die Session beendet wurde."
L["not while session"] = "W\195\164hrend einer Session kannst du das nicht tun.\nWarte bis die Session beendet wurde."
L["tactic question text"] = "Du bist in einer Gruppe, die normal nicht in der Instanz anwesend ist. M\195\182chtest du die Taktik trotzdem verfolgen?"
L["mode not supported"] = "Dieser Modus wird f\195\188r diese Instanz nicht unterst\195\188tzt."
L["Title New Text Inputframe"] = "Neuer Text"
L["Title New Query Inputframe"] = "Neue Abfrage"
L["New Text info"] = "Gib eine Bezeichnung f\195\188r den neuen Text an:"
L["New Query info"] = "Gib eine Bezeichnung f\195\188r den neuen Query an:"
L["del tactic message"] = "Willst du die Taktik wirklich entfernen?"
L["syncmessage"] = "Synchronisation %.0f%% abgeschlossen."
L["incompatible module"] = "Dieses Modul ist in einer neuen Version verfügbar\nBitte aktualisiere das Modul, da BossTactics so nicht funktionieren kann."
L["title ChatConfig"] = "Chatkonfiguration"
L["Camera set to max distance"] = "Kamera auf maximale Distanz eingestellt"
L["move start"] = "Das Hauptfenster kann nun bewegt werden. Klicke erneut auf den Button, um das Fenster festzusetzen"
L["move end"] = "Das Hauptfenster ist nun wieder fest."
L["tactic name already used"] = "Dieser Taktikname ist bereits vorhanden. Wähle bitte einen anderen."
L["text size changed"] = "Schriftgröße auf %d eingestellt"
L["del query message"] = "Willst du den Query wirklich löschen?"
L["Ora MT checkbox"] = "Nutze die MT-Ziele, die in oRA definiert sind, als Tanks"

--minimap
L["version"] = "Version %s"
L["tooltip1"] = "Bosse erkl\195\164ren leicht gemacht"
L["tooltip2"] = "Rechtssklick zum Bewegen"

--Leader Gui
L["Title Raidmessage"] = "Boss\195\188bersicht"
L["Title Addonlist"] = "Versions\195\188bersicht"
L["out of sync"] = "out of sync"
L["module incompatible"] = "Modul incompatibel"
L["No addon found"] = "kein BossTactics"
L["version incompatible"] = "inkompatibel"
L["offline"] = true
L["text sync on"] = "Schalte Text Sync aus"
L["text sync off"] = "Schalte Text Sync an"
L["text lock on"] = "Text freigeben"
L["text lock off"] = "Text festsetzen"

L["Title Groupmessage"] = "Gruppen Ausgabe"
L["Post Message"] = "Poste Nachricht"

--Main
L["Module disabled"] = "Modul |cffdf6003%s|r ist ausgeschaltet"
L["Module missing"] = "Modul |cffdf6003%s|r ist nicht vorhanden"
L["Module currupt"] = "Modul |cffdf6003%s|r ist besch\195\164digt"
L["Module interface version"] = "Modul |cffdf6003%s|r ist inkompatibel zu dieser Interface Version"
L["Module loaded"] ="Modul |cffdf6003%s|r geladen"

--errors
L["Out of synch with raidleader"] = "Keine Synchronisation mit dem Raidleiter"
L["error fontsize"] = "Bitte eine Zahl angeben"
L["no print without group"] = "Du bist in keiner Gruppe"
L["no raid"] = "Du bist in keinem Schlachtzug"

--infos
L["defaults recovered"] = "Standardwerte wiederhergestellt"
L["minimap off"] = "Minimapbutton ausgeschaltet"
L["minimap on"] = "Minimapbutton angeschaltet"
L["session started"] = "Raidleiter %s hat eine Session gestartet"
L["session ended"] = "Raidleiter %s hat die Session beendet"
L["SessAbortPermitted"] = "Du hast nicht die Befugniss Sessions abzubrechen"
L["5man in session not allowed"] = "Du kannst in einer Session keine 5-Man Instanzen öffnen."

--votes
L["rl vote title"] = "Abstimmung starten"
L["vote title"] = "Abstimmung von %s"
L["Start vote"] = "Beginne Abstimmung"
L["Title vote alts"] = "Alternativen (neue Zeile, neue Alternative)"
L["std alts"] = "ja\nnein"
L["Title vote Input"] = "Abstimmungsfrage"
L["vote err1"] = "Es müssen mindestens zwei Alternativen angegeben werden"
L["vote err2"] = "Die Abstimmungsfrage ist pflicht"
L["vote err3"] = "Mehr als 5 Auswahlmöglichkeiten sind nicht zulässig"
L["Cancel Vote"] = "Enthalten"
L["Vote Time text"] = "Du hast noch %d Sekunden für deine Stimme"
L["Send"] = "Absenden"
L["selfvote"] = "\nBitte gib deine Stimme ab"
L["Abstention"] = "Enthaltung"
L["Vote Time rl text"] = "Die Abstimmung geht noch max %d Sekunden"
L["vote done"] = "Abstimmung ist abgeschlossen"
L["PrintVote"] = "Ergebnis Ausgeben"
L["voteRa"] = "Ergebnis der Abstimmung %s"
L["vote chat err"] = "Du musst als Raidleiter ernannt werden, um Abstimmungen durchführen zu können"
L["Vote"] = "Abstimmung"

--raidleaders frame
L["raidleaders title"] = "Raidleiter"
L["Title Choosable"] = "Auswahl:"
L["Title selected"] = "Ausgewählt:"

--Id Info Frame
L["title IdInfo"] = "ID Information"
L["Id Info"] = true
L["Char"] = "Char:"

--Task manager frame
L["Player:"] = "Spieler:"
L["Task:"] = "Aufgabe:"
L["Post"] = "Posten"
L["tanks "] = "tankt "
L["heals "] = "heilt "
L["PostAll"] = "Poste alles"
L["tank intro"] = "Tank Einteilung (Tank - Ziel):"
L["healer intro"] = "Heiler Einteilung (Heiler - Ziele):"
L["melee intro"] = "Nahkampf Einteilung:"
L["range intro"] = "Fernkampf Einteilung:"
L["info no task"] = "Du musst zuerst eine Instanz auswählen, um Tasks einteilen zu können."
L["task extro"] = "Flüstere %s, um deine Einteilung abzufragen."
L["no task"] = "Du hast keine spezielle Aufgabe"

--query manager frame
L["Type:"] = "Typ:"
L["Query:"] = true
L["Valid input"] = "Dies ist eine gültige Eingabe"
L["Invalid input"] = "Die Eingabe ist fehlerhaft, bitte überprüfe, ob du alles richtig eingegeben hast."
L["No text"] = "Es wurde kein Text eingegeben."
L["Query Save Ok"] = "Query erfolgreich gespeichert"
L["Query name exists"] = "Ein Query mit diesem Namen existiert bereits"
L["Query deleted"] = "Der Query wurde gelöscht."
L["Query not saved"] = "Speichern ist nicht möglich"
L["Query not work"] = "Dieser Query ist nicht wahr für deine Einstellung"
L["Warning: "] = "Warnung: "
L["Error: "] = true
L["Query Result"] = "Query Ergebnis"
L["No char allowed"] = "Das Zeichen %s ist in der Eingabe nicht erlaubt"
L["usage ItemId"] = "Bitte gib den Item Link an, das geht mit Shift+Klick auf das item"
L["Help"] = "Hilfe"

--instances
L["Outdoor"] = "Weltbosse"

--update infomessages
L["updateinfo for version 1.1"] = "Die Datenbank aller Module muss aktualisiert werden. Es werden alle Module geladen, es gehen keine Daten verloren."
L["updateinfo for version 2.9"] = "Alle installierten Module werden geladen und aktualisiert. Es gehen keine Daten verloren."

--Leader frame
L["Text Save Checkbox"] = "Speichere für zukünftige Schlachtzüge. (Bedeutet, dass die Spieler automatisch zu Assistenten befördert werden)"

--range check frame
L["set range to"] = "%d m"
L["range check header"] = "Abstandscheck (%d m)"
L["range check hide"] = "Verstecken"
L["range check set range"] = "Abstand Einstellen"

--channels
L["shortcut for deathknight channel"] = "Abkürzung für Todesritter channel"
L["deathknight channel"] = "Todesritter channel"
L["shortcut for druid channel"] = "Abkürzung für Druiden channel"
L["druid channel"] = "Druiden channel"
L["shortcut for hunter channel"] = "Abkürzung für Jäger channel"
L["hunter channel"] = "Jäger channel"
L["shortcut for mage channel"] = "Abkürzung für Magier channel"
L["mage channel"] = "Magier channel"
L["shortcut for paladin channel"] = "Abkürzung für Paladin channel"
L["paladin channel"] = "Paladin channel"
L["shortcut for priest channel"] = "Abkürzung für Priester channel"
L["priest channel"] = "Priester channel"
L["shortcut for rogue channel"] = "Abkürzung für Schurken channel"
L["rogue channel"] = "Schurken channel"
L["shortcut for shaman channel"] = "Abkürzung für Schamanen channel"
L["shaman channel"] = "Schamanen channel"
L["shortcut for warlock channel"] = "Abkürzung für Hexenmeister channel"
L["warlock channel"] = "Hexenmeister channel"
L["shortcut for warrior channel"] = "Abkürzung für Krieger channel"
L["warrior channel"] = "Krieger channel"
L["shortcut for range DD channel"] = "Abkürzung für Fernkämpfer channel"
L["range dd channel"] = "Fernkämpfer channel"
L["shortcut for melee channel"] = "Abkürzung für Nahkämpfer channel"
L["melee channel"] = "Nahkämpfer channel"
L["shortcut for healer channel"] = "Abkürzung für Heiler channel"
L["healer channel"] = "Heiler channel"
L["shortcut for tank channel"] = "Abkürzung für Tank channel"
L["tank channel"] = "Tank channel"

L["dk"] = "tr"
L["d"] = "d"
L["h"] = "j"
L["m"] = "m"
L["p"] = "p"
L["pr"] = "pr"
L["r"] = "s"
L["s"] = "sh"
L["w"] = "h"
L["wa"] = "k"
L["he"] = true
L["dd"] = true
L["me"] = "n"
L["t"] = true

L["channel not found"]  = "Channel %s nicht gefunden"
L["you are not in this channel"] = "Du bist nicht in diesem Channel"
L["already in channel"] = "Du bist bereits im %s Channel"
L["channel joined"] = "|cff%sDu bist dem %s Channel beigetreten|r"
L["channel quit"] = "|cff%sDu hast den %s Channel verlassen|r"
L["you are in channels: "] = "Du bist in den Channeln: %s"
L["members of channel"] = "Im Channel %s sind:"
L["you are not in a raid"] = "Du bist in keinem Schlachtzug."

--channel config frame
L["select channel"] = "Channel auswählen"
L["Color"] = "Farbe"

--help texts
L["help query addons"] = [[
Hilfe zur Verwendung von Addon Abfragen:

Syntax:
Addon-Namen stehen in doppelten Anführungszeichen
Logische Verbindungen sind or oder and
Klammerung ist möglich
and bindet stärker als or

Ergebnis:
Rot - Addon ist nicht installiert
Gelb - Addon ist installiert aber deaktiviert
Grün - Addon ist aktiv

Beispiel:
("Addon1" or "Addon2") and "Addon3"

]]
L["help query items"] = [[
Hilfe zur Verwendung von Item Abfragen:

ItemIds:
BossTactics hat einen Chatbefehl, der es ermöglicht die ItemId eines Items anzuzeigen.
/BossTactics itemid <itemlink>
<itemlink> bezeichnet einen Itemlink (zu erzeugen über shift + Klick auf ein Item)

Syntax:
ItemId VergleichsOperator Wert
Vergleichsoperatoren sind < > <= >= =
Mögliche Werte sind ganze Zahlen größer oder gleich 0
Klammerung ist möglich
and bindet stärker als or

Ergebnis:
Es wird die Anzahl der Gegenstände angegeben, ist der Teilausdruck gültig, ist er grün angezeigt. Wenn der Ausdruck rot ist, dann ist der Teilausdruck falsch.

Beispiel:
(4711 = 5 or 4242 <= 20) and 13 = 7

]]