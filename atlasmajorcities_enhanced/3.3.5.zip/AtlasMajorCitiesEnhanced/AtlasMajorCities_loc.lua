﻿AtlasMajorCities_Strings = {

Atlas_Category = "Major Cities";

-- key bindings
BIND_ASSIGN  = "/amca - Assign shop position";
BIND_COMMENT = "/amcc - Change NPC comment";
BIND_CREATE  = "/amcp - Create a shop";
BIND_LABEL   = "/amcl - Change the shop label";
BIND_SIGN    = "/amcs - Set shop sign position";
BIND_TITLE   = "/amct - Change shop comment";
BIND_ZONE    = "/amcz - Setup the zone";

-- help messages
Help01 = "/amc - Set one of the following modes:";
Help02 = "help - display this help text";
Help03 = "on - default mode to change or set all kind of text";
Help04 = "all - mode to setup everything";
Help05 = "pos - mode to set shop and sign positions only (no first person view)";
Help06 = "sign - mode to scan shop signs only";
Help07 = "npc - mode to scan NPCs only (no first person view)";
Help08 = "off - switch off any modifications";
Help09 = "reload - (re)load the UserDB in place of the AddonDB";
Help10 = "revert - (re)load the AddonDB";
Help11 = "copydbtouser - overwrite the UserDB with the AddonDB (make a copy)";
Help12 = "movelabel - allow the positioning of the labels at the map";
Help13 = "defaultlabel - shop labels at its default positions";
Help14 = "shoplabel - show labels at the shop positions";
Help15 = "signlabel - show labels at the shop sign positions";
Help16 = "/amcz [zone title] - Setup the Zone at this position (default mode)";
Help17 = "/amcp - Create shop at this position (all mode)";
Help18 = "/amca - Assign to the shop at this position (default mode)";
Help19 = "/amcl [label] - Set shop label (displayed at map) (all mode)";
Help20 = "/amcs - Mark the position of the shop sign (all mode)";
Help21 = "/amct [comment/title] - Change comment of assigned shop (default mode)";
Help22 = "/amcc [comment] - Change comment of target NPC";
Help23 = "Change the shop title by mouse over the shop sign and pressing CTRL+SHIFT";
Help24 = "Add NPCs to shop by targeting it, and moving the mouse over the target window";
Help25 = "Use 'delete' to remove a zone name, shop label, shop title, shop sign, or shop position";
Help26 = "Use 'none' as position to setup or assign a shop at the undefined position";
Help27 = "Use 'nonedelete' as position to delete the shop at the undefined position";

-- error messages
errNoAssignment = "ERROR: No shop assignment. Assign a shop first.";
errNoCityDef    = "ERROR: There is no city map in the database for: ";
errNoNPCDef     = "ERROR: This NPC is not in the database.";
errNoShopList   = "ERROR: There is no shop setup near this position.";
errNoShopSign   = "ERROR: No shop sign at this mouse position. (Maybe a slight different mouse position helps.)";
errNoZoneDef    = "ERROR: No zone definition for this map or at this position: ";
errNoZoneList   = "ERROR: There is no zone setup at this position.";
errOldShopSign  = "ERROR: There is already a shop sign at this position: ";
errNoNPC        = "ERROR: No target or target not in NPC database.";

-- popup dialog titles
dialogNPCComment = "Setup a comment added to the next NPC";
dialogShopLabel  = "Give the label for this location";
dialogShopTitle  = "Give the shop title or location description";
dialogZoneTitle  = "Give the subzone title";

-- status messages
msgCreatedShop = "** Shop created with ID: ";
msgCreatedSign = "* Shop sign created with ID: ";

msgDelComment = "* Comment from target NPC removed";
msgDelLabel   = "* Label for this shop removed";
msgDelShop    = "** This shop is deleted";
msgDelTitle   = "* Comment from this shop removed";
msgDelZone    = "*** Title for this zone removed";

msgIsLabel       = "* Shop label: ";
msgIsNPCComment  = "* Comment added to target NPC: ";
msgIsShop        = "** Shop is now: ";
msgIsShopComment = "* Shop comment: ";

msgOff      = "AtlasMajorCities scan mode disabled";
msgOn       = "AtlasMajorCities default scan mode enabled (all text)";
msgOnAll    = "AtlasMajorCities all scan mode enabled (positions and text)";
msgOnNPC    = "AtlasMajorCities NPC scan mode enabled";
msgOnPos    = "AtlasMajorCities positions only scan mode enabled";
msgOnSign   = "AtlasMajorCities sign scan mode enabled (include NPC)";
msgDBcopied = "AtlasMajorCities DB copied to user data";
msgnoDB     = "AtlasMajorCities DB in old incompartible format. Nothing copied";
msgUserOnly = "Label positioning only avalaible with UserDB. First use: /amc reload";
msgOnMove   = "AtlasMajorCities labels positioning mode enabled at the map";

-- sub-commands
subDeleteString   = "delete";
subNoPosString    = "none";
subDelNoPosString = "nonedelete";
}

if ( GetLocale() == "deDE" ) then

AtlasMajorCities_Locale = {

Atlas_Category = "Gro\195\159st\195\164dte";

}

end

AtlasMajorCities_loc = AtlasMajorCities_Strings;
for key, val in pairs(AtlasMajorCities_loc) do
	if ( AtlasMajorCities_Locale[key] ) then
		AtlasMajorCities_loc[key] = AtlasMajorCities_Locale[key];
	end
end
