Tongues.PetTable = {
	["Bat"] = {
		["Language"] = "Bat",
		["Speaktype"] = "squeeks",
	};
	["Bear"] = {
		["Language"] = "Bear",
		["Speaktype"] = "growls",
	};
	["Bird of Prey"] = {
		["Language"] = "Bird",
		["Speaktype"] = "cries",
	};
	["Boar"] = {
		["Language"] = "Boar",
		["Speaktype"] = "snorts",
	};
	["Carrion Bird"] = {
		["Language"] = "Bird",
		["Speaktype"] = "screeches",
	};
	["Cat"] = {
		["Language"] = "Cat",
		["Speaktype"] = "murmurs",
	};
	["Chimaera"] = {
		["Language"] = "Chimaera",
		["Speaktype"] = "screeches",
	};
	["Core Hound"] = {
		["Language"] = "Core Hound",
		["Speaktype"] = "barks",
	};	
	["Crab"] = {
		["Language"] = "Crab",
		["Speaktype"] = "clacks",
	};	
	["Crocolisk"] = {
		["Language"] = "Crocolisk",
		["Speaktype"] = "snaps",
	};	
	["Devilsaur"] = {
		["Language"] = "Devilsaur",
		["Speaktype"] = "roars",
	};
	["Dragonhawk"] = {
		["Language"] = "Dragonhawk",
		["Speaktype"] = "calls",
	};
	["Felguard"] = {
		["Language"] = "Demonic",
		["Speaktype"] = "roars",
	};
	["Felhunter"] = {
		["Language"] = "Demonic",
		["Speaktype"] = "growls",
	};
	["Gorilla"] = {
		["Language"] = "Gorilla",
		["Speaktype"] = "grunts",
	};
	["Ghoul"] = {
		["Language"] = "Undead",
		["Speaktype"] = "croaks",
	};
	["Hyena"] = {
		["Language"] = "Hyena",
		["Speaktype"] = "laughs",
	};
	["Imp"] = {
		["Language"] = "Demonic",
		["Speaktype"] = "cackles",
	};
	["Infernal"] = {
		["Language"] = "Demonic",
		["Speaktype"] = "roars",
	};
	["Moth"] = {
		["Language"] = "Moth",
		["Speaktype"] = "whispers",
	};
	["Nether Ray"] = {
		["Language"] = "Nether Ray",
		["Speaktype"] = "hisses",
	};
	["Ravager"] = {
		["Language"] = "Ravager",
		["Speaktype"] = "clacks",
	};
		["Raptor"] = {
		["Language"] = "Raptor",
		["Speaktype"] = "screeches",
	};

	["Rhino"] = {
		["Language"] = "Rhino",
		["Speaktype"] = "grunts",
	};
	["Scorpid"] = {
		["Language"] = "Scorpid",
		["Speaktype"] = "clacks",
	};
	["Serpent"] = {
		["Language"] = "Serpent",
		["Speaktype"] = "hisses",
	};
	["Silithid"] = {
		["Language"] = "Silithid",
		["Speaktype"] = "clacks",
	};
	["Spider"] = {
		["Language"] = "Spider",
		["Speaktype"] = "whispers",
	};
	["Spirit Beast"] = {
		["Language"] = "Spirit Beast",
		["Speaktype"] = "howls",
	};
	["Sporebat"] = {
		["Language"] = "Sporebat",
		["Speaktype"] = "squeeks",
	};
	["Succubus"] = {
		["Language"] = "Demonic",
		["Speaktype"] = "flirts",
	};
	["Tallstrider"] = {
		["Language"] = "Tallstrider",
		["Speaktype"] = "chrips",
	};
	["Turtle"] = {
		["Language"] = "Turtle",
		["Speaktype"] = "mumbles",
	};
	["Warp Stalker"] = {
		["Language"] = "Nether",
		["Speaktype"] = "growls",
	};
	["Wasp"] = {
		["Language"] = "Wasp",
		["Speaktype"] = "hisses",
	};
	["Wind Serpent"] = {
		["Language"] = "Serpent",
		["Speaktype"] = "hisses",
	};
	["Wolf"] = {
		["Language"] = "Wolf",
		["Speaktype"] = "howls",
	};
	["Worm"] = {
		["Language"] = "Worm",
		["Speaktype"] = "whispers",
	};
	["Voidwalker"] = {
		["Language"] = "Demonic",
		["Speaktype"] = "echoes",
	};
};