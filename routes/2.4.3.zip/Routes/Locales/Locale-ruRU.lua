﻿-- Routes
-- ruRU Localization file

local L = LibStub("AceLocale-3.0"):NewLocale("Routes", "ruRU")
if not L then return end


-- vim: ts=4 noexpandtab
