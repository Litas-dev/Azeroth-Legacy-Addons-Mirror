DBM for Hyjal, ChromieCraft
Cafe2024.05.31 last updated

- Must use base DBM from balleny (lys) as edits are based on his https://github.com/balleny/DBM
- Must use new localization.en.lua to catch archimonde emote for doomfire cd
- Must edit localization per language base and also the map name on DBM-Hyjal.toc to work