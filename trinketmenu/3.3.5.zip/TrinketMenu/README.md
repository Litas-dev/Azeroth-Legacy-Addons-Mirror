# TrinketMenu (3.3.5a)

Lightweight trinket manager by Gello, updated for Wrath 3.3.5a (Interface 30300).

## Install
Copy the `TrinketMenu` folder to `Interface/AddOns/` and `/reload`.

## Use
- `/trinket` — toggle window
- `/trinket opt` — options
- `/trinket fix` — repair/show if hidden
- `/trinket alwayson on|off` — keep visible even if other addons hide it

## Credits
Original by Gello. This fork provides 3.3.5a compatibility and small QoL.
