﻿--[[
****************************************************************************************
MountDatabase.lua
$Date: 2008-08-14 02:23:07 +0000 (Thu, 14 Aug 2008) $
$Rev: 17 $

Author: Ackis on Illidan US Horde

****************************************************************************************
]]--

local addon = Collectinator

local BFAC		= LibStub("LibBabble-Faction-3.0"):GetLookupTable()
local BZONE		= LibStub("LibBabble-Zone-3.0"):GetLookupTable()
local BBOSS		= LibStub("LibBabble-Boss-3.0"):GetLookupTable()

-- Adds all mini-pets, by spell ID to the local database.

function addon:MakeMountTable()

	self:Print("Populating mount list.")

end
