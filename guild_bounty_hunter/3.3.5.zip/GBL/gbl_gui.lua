function GBL_DelayScript(script,delay,id)   
   if id == nil then
      id = "GBL_TimerFrame"
   else
      id = "GBL_TimerFrame"..id
   end
   local f = CreateFrame("Frame",id,UIParent)
   local stop = time() + delay
   f:SetScript("OnUpdate",function() GBL_TimerUpdate(stop,f,script) end)   
end

function GBL_TimerUpdate(stop,self,script)   
   local t = time()    
   if t >= stop then       
      self:SetScript("OnUpdate",nil)
      RunScript(script)
   end   
end

function GBL_RosterLargessUpdate()     
   local i = GetGuildRosterSelection()      
   if i > 0 then  
      GBL_AuditInit()
      GBL_AuditLoad()
      local largess = GBL_AuditData[GBL_GuildMates[i].name].largess 
      if largess < 0 then 
         largess = abs(largess)
         GBL_NegRosterLargess:Show()
      else 
         GBL_NegRosterLargess:Hide()
      end
      --GBL_LargessMessage(largess)
      MoneyFrame_Update(GBL_RosterMoneyFrame, largess);      
   end
end

function GBL_RosterLargessAdd()         
   local i = GetGuildRosterSelection()     
   local name = GBL_GuildMates[i].name
   local add = MoneyInputFrame_GetCopper(GBL_LargessModFrame)  
   local base = GBL_AuditData[name].largess   
   GBL_SetLargess(name,base+add)
   local moneystr = GBL_CopperToGold(add)
   GBL_LargessMessage(moneystr.." added to "..name.."'s Largess.") 
end
   
 function GBL_RosterLargessSub()         
   local i = GetGuildRosterSelection()     
   local name = GBL_GuildMates[i].name
   local sub = MoneyInputFrame_GetCopper(GBL_LargessModFrame)  
   local base = GBL_AuditData[name].largess   
   GBL_SetLargess(name,base-sub)
   local moneystr = GBL_CopperToGold(sub)
   GBL_LargessMessage(moneystr.." subtracted from "..name.."'s Largess.","red") 
end 

function GBL_RosterLargessEq()         
   local i = GetGuildRosterSelection()     
   local name = GBL_GuildMates[i].name
   local set = MoneyInputFrame_GetCopper(GBL_LargessModFrame)    
   GBL_SetLargess(name,set)
   local moneystr = GBL_CopperToGold(set)
   GBL_LargessMessage(name.."'s Largess set to "..moneystr) 
end
