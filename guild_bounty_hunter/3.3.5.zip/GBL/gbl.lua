function GBL_OnLoad()
	this:RegisterEvent("VARIABLES_LOADED"); 	
    this:RegisterEvent("PLAYER_ENTERING_WORLD");	
end

function GBL_OnEvent()
   if event == "VARIABLES_LOADED" then
      GBL_Init()       
   elseif (event == "PLAYER_ENTERING_WORLD") then
      GuildRoster()      
      if not CanViewOfficerNote() then
         GBL_RosterLargessFrame:Hide()
      else
         
      end      
   end   
end

function GBL_Init()
	SLASH_GBL1 = "/gbl"
	SlashCmdList["GBL"] = GBL_Commands;   
   GBL_RosterLargessFrame:SetScript("OnUpdate",function() GBL_RosterLargessUpdate() end)
   GBL_VERSION = GetAddOnMetadata("GBL", "version")
end   

function GBL_msg(msg)
  
end