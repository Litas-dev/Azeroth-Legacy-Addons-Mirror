function GBL_Commands(args)  
   local s,e,cmd,arg1,arg2,arg3 = string.find(args,"(%a*)%s?([.?%a%d]*)%s?([.?%a%d]*)%s?([.?%a%d-?]*)")    
   
   --debug
   if cmd == "debug" then
      if arg1 == "on" then
         GBL_Config["debug"] = true
      elseif arg1 == "off" then
         GBL_Config["debug"] = false
      end
           
   --set guild bank largess cut
   elseif cmd == "cut" then
      GBL_SetGBCut(arg1)
    
   --largess commands
   elseif cmd == "largess" then
      if arg1 == "" then
         GBL_LargessMessage("Your current guild Largess is "..GBL_CopperToGold(GBL_Largess))
      elseif arg1 == "report" then
         GBL_GuildLargessReport()
      elseif arg1 == "set" then
         GBL_SetLargess(arg2,arg3)
      elseif arg1 == "mod" then
         GBL_ModLargess(arg2,arg3)
      end   
      
   --audit commands
   elseif cmd == "audit" then
      if arg1 == "reset" then
         --GBL_AuditData = nil
      elseif arg1 == "print" then
         --GBL_AuditPrint()
      elseif arg1 == "" then 
         GBL_AuditPrep()         
      --GBL_DoAudit()
      elseif arg1 == "init" then
         GBL_AuditInit()
      elseif arg1 == "load" then
         GBL_AuditLoad()
      elseif arg1 == "save" then
         GBL_AuditSave()      
      end     
   
   --version
   elseif cmd == "version" then
      GBL_LargessMessage("Guild Bank Largess v"..GBL_VERSION);
         
   --help
   elseif cmd == "help" then
      GBL_Help(arg1)    
   else 
      GBL_Help()
   end
end

function GBL_GetAdminLevel()
   if CanEditOfficerNote() and CanEditGuildInfo() then
      return GBL_SUPER_ADMIN
   elseif CanEditOfficerNote() then
      return GBL_ADMIN
   else
      return GBL_USER
   end   
end

