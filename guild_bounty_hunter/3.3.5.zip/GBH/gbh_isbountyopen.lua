function IsBountyOpen (name)
   local n = #GBH_HitList;
   local i;
   for i = 1, n do 
      if name == GBH_HitList[i].name and GBH_HitList[i].state == "GBH_OPEN" then
         return true, i
      end
   end
   return false, 0
end