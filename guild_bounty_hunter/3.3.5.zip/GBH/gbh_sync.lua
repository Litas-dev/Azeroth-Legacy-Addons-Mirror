--sync
if sync1 == nil then    
    sync1 = CreateFrame("Frame","syncFrame",UIParent);
    sync1:SetScript("OnEvent", function() sync1_OnEvent() end);
    sync1:RegisterEvent("CHAT_MSG_ADDON");
end
function sync1_OnEvent()
    if (event == "CHAT_MSG_ADDON") then         
        if (arg1 == "GBH_HL_SYNC_REQ") then     
            --GBH_Message("GBH_HL_SYNC_REQ")
            GBH_HL_DoSync(arg4);          
        end
        if (arg1 == "GBH_HL_UPDATE") then
            --GBH_Message("GBH_HL_UPDATE")
            GBH_HL_DoUpdate(arg2);
        end
        if(arg1 == "GBH_HL_CLEAR") then
           --GBH_Message("GBH_HL_CLEAR")
           GBH_HitList = {}
           GBH_HitListUpdate()
       end
    end
end  
function GBH_HL_DoSync(sender)   
    local i,n
    if GBH_HitList == nil then
        GBH_HitList={};
    end        
    n = #GBH_HitList        
    for  i = 1, n do        
      msg = GBH_BountyToString(i)
      --Debug 
      if GBH_Config["debug"] then GBH_Message("DoSync: "..msg) end       
      ChatThrottleLib:SendAddonMessage("NORMAL","GBH_HL_UPDATE",msg,"WHISPER",sender);
    end
end    
function GBH_HL_DoUpdate(msg)  
   local id,name,issuer,amount,state,claimer,timestamp,f,i,audit,faction,realm,zone,xcoord,ycoord,intelage,class,race,level
   --Debug 
   if GBH_Config["debug"] then GBH_Message("GBH_HL_DoUpdate: "..msg) end
   id,timestamp,name,issuer,amount,claimer,state,audit,faction,realm,zone,xcoord,ycoord,intelage,class,race,level = string.split(",",msg) 
   if name == nil or amount == nil then 
      return
   end   
   if intelage == nil then 
      intelage = 0
   end   
   local f,i = InHitList(id)
   if f == false then
      table.insert(GBH_HitList,{id=id,name=name,amount=amount,issuer=issuer,timestamp=timestamp,state=state,claimer=claimer,audit=audit,faction=faction,realm=realm,zone=zone,xcoord=xcoord,ycoord=ycoord,intelage=tonumber(intelage),class=class,race=race,level=level});  
   elseif (tonumber(timestamp) > tonumber(GBH_HitList[i].timestamp)) then
      GBH_HitList[i].id = id
      GBH_HitList[i].name = name
      GBH_HitList[i].amount = amount
      GBH_HitList[i].issuer = issuer
      GBH_HitList[i].timestamp = timestamp
      GBH_HitList[i].state = state
      GBH_HitList[i].claimer = claimer   
      GBH_HitList[i].audit = audit
      GBH_HitList[i].faction = faction
      GBH_HitList[i].realm = realm
   end
   if f == true then
      if GBH_HitList[i].intelage == nil then
         GBH_HitList[i].intelage = 0
      end      
      if (tonumber(intelage) > tonumber(GBH_HitList[i].intelage)) then
         GBH_HitList[i].zone = zone
         GBH_HitList[i].xcoord = xcoord
         GBH_HitList[i].ycoord = ycoord
         GBH_HitList[i].intelage = tonumber(intelage)
         GBH_HitList[i].class = class
         GBH_HitList[i].race = race
         GBH_HitList[i].level = level
         GBH_HitListUpdate()
      end   
   end
end

function GBH_BountyToString(i)
   local name = GBH_HitList[i].name
   local amount = GBH_HitList[i].amount   
   local id = GBH_HitList[i].id      
   local issuer = GBH_HitList[i].issuer
   local timestamp = GBH_HitList[i].timestamp
   local state = GBH_HitList[i].state
   local claimer = GBH_HitList[i].claimer  
   local audit = GBH_HitList[i].audit
   local faction = GBH_HitList[i].faction
   local realm = GBH_HitList[i].realm
   local zone = GBH_HitList[i].zone
   local xcoord = GBH_HitList[i].xcoord
   local ycoord = GBH_HitList[i].ycoord
   local intelage = GBH_HitList[i].intelage
   local class = GBH_HitList[i].class
   local race = GBH_HitList[i].race
   local level = GBH_HitList[i].level
   
   if audit == nil then 
      audit  = 0
   end   
   if faction == nil then
      faction = "UNKNOWN"
   end   
   if GBH_HitList[i].realm == nil then
      realm = ""
   end   
   if GBH_HitList[i].zone == nil then
      zone = ""
   end   
   if GBH_HitList[i].xcoord == nil then
      xcoord = ""
   end   
   if GBH_HitList[i].ycoord == nil then
      ycoord = ""
   end   
   if GBH_HitList[i].class == nil then
      class = ""
   end  
   if GBH_HitList[i].race == nil then
      race = ""
   end
   if GBH_HitList[i].level == nil then
      level = ""
   end   
   if GBH_HitList[i].intelage == nil then
      intelage = 0
   end   
   local msg = id..","..timestamp..","..name..","..issuer..","..amount..","..claimer..","..state..","..audit..","..faction..","..realm..","..zone..","..xcoord..","..ycoord..","..intelage..","..class..","..race..","..level;
  
   return msg
end