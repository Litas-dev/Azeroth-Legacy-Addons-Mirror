function GBH_ActionQueueInit()
   GBH_ActionQueue = {}
   if GBH_Timer == nil then
      GBH_Timer = CreateFrame("Frame")       
      GBH_Timer:SetScript("OnUpdate", GBH_ActionQueueUpdate)
   end
   
end

function GBH_ActionQueueUpdate()
   if #GBH_ActionQueue == 0 then 
      GBH_Timer:Hide()
      return 
   end 
   if time() >= GBH_ActionQueue[1].ts then 
      RunScript(GBH_ActionQueue[1].script)
      table.remove(GBH_ActionQueue, 1)
   end
end

function GBH_ActionQueueAdd(script, delay)
   table.insert(GBH_ActionQueue, {ts=time()+delay, script=script})
   table.sort(GBH_ActionQueue, GBH_ActionSort)
   GBH_Timer:Show()
end

function GBH_ActionSort(a,b)
   return a.ts < b.ts
end



