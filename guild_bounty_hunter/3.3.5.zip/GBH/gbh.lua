function GBH_OnLoad()
	this:RegisterEvent("VARIABLES_LOADED"); 	
   this:RegisterEvent("PLAYER_LOGIN");
   this:RegisterEvent("PLAYER_ENTERING_WORLD");	
end

function GBH_OnEvent()

   if event == "VARIABLES_LOADED" then
      --GBH_Init()   
   elseif (event == "PLAYER_LOGIN") then
      GBH_Init()   
      GBH_Purge()
   elseif (event == "PLAYER_ENTERING_WORLD") then
      --GBH_Init()
      SendAddonMessage("GBH_HL_SYNC_REQ",nil,"GUILD");
      --GBH_Purge()
      GuildRoster()
   end
end      
  