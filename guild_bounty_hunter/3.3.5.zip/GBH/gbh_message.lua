function GBH_DisplayList()
   local i, n,name,amount,msg
   
   GBH_FilterHitList()
   
   GBH_Msg("     ")   
   GBH_Msg("------------------------------------------")   
   GBH_Msg("Guild Bounty Hunter v"..GBH_VERSION,"GUILD")
   GBH_Msg("------------------------------------------")
   GBH_Msg("Target {skull} Bounty {circle} Claimer {cross}")
   GBH_Msg("------------------------------------------")
   
   n = #GBH_HitListFiltered
   for i = 1, n do
      name = GBH_HitListFiltered[i].name
      amount =  GBH_HitListFiltered[i].amount
      msg = string.format("%s {skull} %s {circle}",name,GBL_CopperToGold(amount))
      if (GBH_HitList[i].state == "GBH_CLAIMED") then
         msg = string.format("%s {skull} %s {circle}  %s {cross}",name,GBL_CopperToGold(amount),GBH_HitListFiltered[i].claimer);
      end 
      GBH_Msg(msg)
   end
end

function GBH_Message(msg)
   --SendChatMessage(msg, GBH_Config["channel"], nil)
   if GBH_Config["channel"] == "PRIVATE" then
      ChatFrame1:AddMessage(msg,0,1,0);
   else
      ChatThrottleLib:SendChatMessage("NORMAL", "GBH", msg, GBH_Config["channel"], nil, nil);
   end
end

function gbh_msg(msg)
   if GBH_Config["debug"] then
      ChatFrame1:AddMessage(msg,0,1,0);
   end
end

function GBH_Msg(msg)
   if GBH_FilterFormCheckGuild:GetChecked() then
      ChatThrottleLib:SendChatMessage("NORMAL", "GBH", msg, "GUILD", nil, nil);
   end
   
   if GBH_FilterFormCheckSay:GetChecked() then
      ChatThrottleLib:SendChatMessage("NORMAL", "GBH", msg, "SAY", nil, nil);
   end
end
   