function GBH_HitListSort(self)
   table.sort(GBH_HitList,GBH_SortBy(self.sortType,a,b))
    GBH_HitListUpdate()
end

function GBH_SortBy(sortType,a,b)
   
end