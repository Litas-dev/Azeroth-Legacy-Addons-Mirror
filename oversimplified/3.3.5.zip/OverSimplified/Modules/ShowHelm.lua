function osSH()
	if ShowingHelm() then 
		ShowHelm(false) 
	else 
		ShowHelm() 
	end
end

SLASH_SH1 = "/sh";
SLASH_SH2 = "/showhelm";
SlashCmdList["SH"] = osSH