﻿if (GetLocale() == "enUS") or (GetLocale() == "enGB") then
	errorRaid 		= "You are not a raid leader or have raid assist, and cannot perform a 'ready check'."
	errorParty 		= "You are not the party leader and cannot perform a 'ready check'."
	errorNoGroup 	= "You are not in a group."
-- Chat Configuration
elseif (GetLocale() == "frFR") then
	errorRaid 		= "Vous n'êtes pas un chef de raid ou n’avez pas avoir 'Raid Assist', et ne pouvez pas effectuer un 'ready check'."
	errorParty 		= "Vous n'êtes pas le chef du parti et ne pouvez pas effectuer un 'ready check'."
	errorNoGroup 	= "Vous n'êtes pas dans un groupe."
elseif (GetLocale() == "ruRU") then
	-- Thanks Vladimir Akinshin 
	errorRaid 		= "Вы не являетесь Лидером Рейда или у вас нет Прав Ассистента, и вы неможете проводить Проверку на готовность."
	errorParty 		= "Вы не лидер группы и не можете проводить Проверку на готовность."
	errorNoGroup 	= "Вы не в группе."
elseif (GetLocale() == "deDE") then
	errorRaid 		= ""
	errorParty 		= ""
	errorNoGroup 	= ""
elseif (GetLocale() == "koKR") then
	errorRaid 		= ""
	errorParty 		= ""
	errorNoGroup 	= ""
elseif (GetLocale() == "zhCN") then
	errorRaid 		= "你不是一个“'Raid Leader'”或“'Raid Assist'”，而不能执行“'Ready Check'”。"
	errorParty 		= "您还没有党的领导，不能执行“'Ready Check'”。"
	errorNoGroup 	= "您还没有在一个组。"
elseif (GetLocale() == "zhTW") then
	errorRaid 		= "你不是一個“'Raid Leader'”或“'Raid Assist'”，而不能執行“'Ready Check'”。"
	errorParty 		= "您還沒有黨的領導，不能執行“'Ready Check'”。"
	errorNoGroup 	= "您還沒有在一個組。"
elseif (GetLocale() == "esES") then
	errorRaid 		= "Usted no es un 'Raid Leader' o 'Raid Assist', y no puede realizar una 'ready check'."
	errorParty 		= "Usted no es el líder del partido y no puede realizar una 'ready check'."
	errorNoGroup 	= "Usted no está en un grupo."
elseif (GetLocale() == "esMX") then
	errorRaid 		= "Usted no es un 'Raid Leader' o 'Raid Assist', y no puede realizar una 'ready check'."
	errorParty 		= "Usted no es el líder del partido y no puede realizar una 'ready check'."
	errorNoGroup 	= "Usted no está en un grupo."
else
	errorRaid 		= ""
	errorParty 		= ""
	errorNoGroup 	= ""
end



function osRC()
	if (UnitInRaid("player") ~= nil) and (GetNumRaidMembers() > 0) then
		if IsRaidLeader() or IsRaidOfficer() then
			DoReadyCheck()
		else
			print(OStext..errorRaid)
		end
	elseif (UnitInParty("player") ~= nil) and (GetNumPartyMembers() > 0) then
		if UnitIsPartyLeader("player") then
			DoReadyCheck()		
		else
			print(OStext..errorParty)
		end
	else
		print(OStext..errorNoGroup)
	end
end

SLASH_RC1 = "/rc";
SLASH_RC2 = "/readycheck";
SlashCmdList["RC"] = osRC