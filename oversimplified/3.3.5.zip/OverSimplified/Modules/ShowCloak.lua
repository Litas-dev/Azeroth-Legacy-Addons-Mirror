function osSC()
	if ShowingCloak() then
		ShowCloak(false)
	else
		ShowCloak()
	end
end

SLASH_SC1 = "/sc";
SLASH_SC2 = "/showcloak";
SlashCmdList["SC"] = osSC