function osRL()
	ReloadUI();
end

SLASH_RL1 = "/rl";
SlashCmdList["RL"] = osRL