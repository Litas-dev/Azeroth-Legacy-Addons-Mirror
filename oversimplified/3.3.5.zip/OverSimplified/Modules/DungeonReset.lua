function osDGR()
	ResetInstances();
end

SLASH_DGR1 = "/dgr";
SLASH_DGR2 = "/dungeonreset";
SlashCmdList["DGR"] = osDGR