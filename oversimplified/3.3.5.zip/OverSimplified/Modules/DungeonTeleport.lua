function osDGT()
	local inInstance, _ = IsInInstance()
	if inInstance then
		LFGTeleport(true);
	else
		LFGTeleport();
	end
end

SLASH_DGT1 = "/dgt";
SLASH_DGT2 = "/dungeontele";
SlashCmdList["DGT"] = osDGT