local toggle = {};
toggle.on = function() 
	if (LoggingCombat()) then
		print(OStext.."Combat logging is currently enabled.")
	else
		print(OStext.."Combat logging is now enabled.")
		LoggingCombat(1)
	end
end
toggle.off = function() 
	if not (LoggingCombat()) then
		print(OStext.."Combat logging is currently disabled.")
	else
		print(OStext.."Combat logging is now disabled.")
		LoggingCombat(0)
	end
end

function osCL(arg)
	if type(toggle[arg]) == 'function' then 
		toggle[arg]()
	else 
		print(OStext.."Available commands are /cl 'on' or 'off'.")
	end
end

SLASH_CL1 = "/cl";
SlashCmdList["CL"] = osCL