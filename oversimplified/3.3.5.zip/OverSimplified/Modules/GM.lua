function osGM()
	ToggleHelpFrame();
end

SLASH_GM1 = "/gm";
SlashCmdList["GM"] = osGM