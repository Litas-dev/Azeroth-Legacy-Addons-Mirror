function osGK()
	UninviteUnit(UnitName("target"))
end

SLASH_GK1 = "/vk";
SLASH_GK2 = "/votekick";
SLASH_GK3 = "/gk";
SLASH_GK4 = "/groupkick";
SlashCmdList["GK"] = osGK