function osBG()
	local _,bgtype = IsInInstance()
	if bgtype == "arena" or bgtype == "pvp" then
		if bgtype == "pvp" then 
			bgtype = "battleground"
		elseif bgtype == "arena" then 
			if (select(2, IsActiveBattlefieldArena())) then 
				bgtype = "rated arena match" 
			else 
				bgtype = "arena skirmish" 
			end
		end
		StaticPopupDialogs["LeaveBattleField"] = {
			text = GetAddOnMetadata("OverSimplified", "title").."\n\nWould you like to leave this |cff5CB3FF"..bgtype.."|r?\n", 
			button1 = "Yes", 
			button2 = "No",
			timeout = 0,
			whileDead = 1, 
			hideOnEscape = 1, 
			OnAccept = function() LeaveBattlefield() end,
			OnCancel = function() end,
		}
		StaticPopup_Show("LeaveBattleField")
	end
end

SLASH_BG1 = "/lbg";
SlashCmdList["BG"] = osBG