function osGL()
	PromoteToLeader("target")
end

SLASH_GL1 = "/gl";
SLASH_GL2 = "/grouplead";
SlashCmdList["GL"] = osGL