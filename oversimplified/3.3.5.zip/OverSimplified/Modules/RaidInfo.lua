﻿function osRI()
	if ( RaidInfoFrame:IsShown() ) and ( FriendsFrame:IsShown() ) then
		ToggleFriendsFrame(5)
		RaidInfoFrame:Hide();
	else
		ToggleFriendsFrame(5)
		RaidInfoFrame:Show();
	end
end

SLASH_RI1 = "/ri";
SlashCmdList["RI"] = osRI