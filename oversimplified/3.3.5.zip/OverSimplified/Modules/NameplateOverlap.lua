function osOL()
	SetCVar("nameplateAllowOverlap",abs(GetCVar("nameplateAllowOverlap")-1))
end

SLASH_OL1 = "/ol";
SLASH_OL2 = "/overlap";
SlashCmdList["OL"] = osOL