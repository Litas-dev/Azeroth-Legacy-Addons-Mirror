function osLG()
	LeaveParty();
end

SLASH_LG1 = "/lg";
SlashCmdList["LG"] = osLG