local L = LibStub("AceLocale-3.0"):NewLocale("GDKPd", "zhCN")
if not L then return end

L["Allow multiple simultanous auctions"] = "允许同时拍卖多项物品"
L["Amount"] = "金额" -- Needs review
-- L["Anchor balance window to status window"] = "Anchor balance window to status window"
L["Announce auction start to raid warning"] = "拍卖开始时在团队警告频道通告"
L["Announce & auto-auction"] = "通告与自动拍卖"
L["Announce loot"] = "发布掉落物品"
L["Announce the current pot amount after each auction"] = "在每次拍卖完成之后通告当前拍卖收入"
L["Appearance options"] = "外观选项" -- Needs review
L["Auction bid timeout refresh"] = [=[拍卖出价超时刷新
每次有新出价时重置拍卖时间
]=]
L["Auction history"] = "拍卖记录"
L["Auction note: %s"] = "拍卖注释: %s"
L["Auction timeout"] = "拍卖超时"
L["Auto-award loot to winner"] = "自动分配物品给拍卖获胜者"
L["Auto bid"] = "自动出价"
L["Award loot to Master Looter when auto-auctioning"] = "在自动拍卖时将掉落物品分配给分配者"
-- L["Balance"] = "Balance"
L["Behaviour options"] = "规则选项" -- Needs review
L["Bid"] = "出价"
L["Bid button re-enable delay"] = "出价按钮重新可用的延迟"
-- L["Broadcast rules"] = "Broadcast rules"
L["Cannot start auction without Master Looter privileges."] = "没有分配物品权限时无法开始拍卖"
-- L[" |cffaa0000(Distribute: %dg)|r"] = " |cffaa0000(Distribute: %dg)|r"
-- L["Configure per-item settings"] = "Configure per-item settings"
L["Control panel scale"] = "控制面板缩放"
L["Current bid: "] = "当前报价"
L["Distribute"] = "分配"
L["Do not announce"] = "禁止通告"
L["Do you want to save your pot or reset without saving? You can also add a note to the pot."] = "你想保存拍卖收入还是重置不保存?你也可以在拍卖收入中添加注释."
L["Enable"] = "启用"
-- L["Enter the amount you want to add to player %s:"] = "Enter the amount you want to add to player %s:"
L["Enter the amount you want to add to the pot:"] = "输入你想添加进拍卖收入中的金额:"
-- L["Enter the amount you want to subtract from player %s:"] = "Enter the amount you want to subtract from player %s:"
L["Enter the amount you want to subtract from the pot:"] = "输入你想从拍卖收入中扣除的金额:"
L["Enter the maximum amount of money you want to bid on %s:"] = "输入你想对 %s 出价的最大金额:"
L["Export"] = "导出"
L["Frame alpha"] = "框架透明度"
L["Frame scale"] = "框架缩放"
L["GDKPd auction history"] = "GDKPd拍卖记录"
L["GDKPd auction history for %s"] = "GDKPd对 %s 的拍卖记录"
L["GDKPd: Drag to move"] = "GDKPd:点击拖动"
L["[GDKPd] Loot dropped: "] = "[GDKPd]物品掉落:"
L["GDKPd: No detailed data available"] = "GDKPd: 无可用的详细数据"
L["[GDKPd] This raid uses GDKPd to faciliate its GDKP bidding process. While you can bid on items without having GDKPd installed, installing it provides you with a GUI bidding panel, auto bidding functions, auction timers, chat filtering and more!"] = "[GDKPd]本团队使用GDKPd来辅助拍卖.你也可以在未安装GDKPd的情况进行出价,安装本插件将可以使用出价面板,自动出价,拍卖计时器,聊天过滤等多种功能!"
L["GDKPd version %s. Packaged %s."] = "GKPd版本 %s. 封装 %s." -- Needs review
L["[GDKPd] Your version of GDKPd is outdated and no longer compatible with the raid leader's in one or more functionalities. In order to ensure smooth performance, please update GDKPd."] = "[GDKPd]你的GDKPd版本过期且多项功能无法与团长使用的版本兼容.为了确保正常使用,请升级GDKPd."
L["[GDKPd] Your version of GDKPd is slightly outdated compared to the raid leader's. Full compability should be possible, however, you might want to take some time and update GDKPd."] = "[GDKPd]你的GDKPd版本比团长的版本稍低.也许可以与团长的版本兼容,然而你有必要花些时间升级你的GDKPd."
L["Hide"] = "隐藏"
L["Hide 'Auction finished' announcements"] = "隐藏\"拍卖结束\"通告"
L["Hide 'Bidding starts' announcements"] = "隐藏\"拍卖开始\"通告"
L["Hide 'Bidding starts' announcements from raid warning"] = "在团队警告频道隐藏\"拍卖开始\"通告"
L["Hide chat messages"] = "隐藏聊天信息"
L["Hide 'Current pot:' announcements"] = "隐藏\"当前拍卖收入\"通告"
-- L["Hide frames in combat"] = "Hide frames in combat"
-- L["Hide history window"] = "Hide history window"
L["Hide 'New highest bidder' announcements"] = "隐藏\"新的最高出价者\"通告"
L["Hide players' bid messages"] = "隐藏玩家的出价信息"
-- L["Hide status and balance windows"] = "Hide status and balance windows"
L["Hide 'Time remaining' announcements"] = "隐藏\"剩余时间\"通告"
-- L["Hide version check window"] = "Hide version check window"
L["Highest bidder: %s"] = "最高出价者: %s"
L["History"] = "记录"
-- L["Item settings"] = "Item settings"
-- L["Itm"] = "Itm"
L["Lock"] = "锁定"
L["Manual adjustment"] = [=[手动调整
在浏览记录时手动调整拍卖收入.(例子:手动调整: +300g)]=]
L["Minimum bid: "] = "最低出价:"
L["Minimum increment"] = "最低加价"
L["Minimum quality"] = "最低品质"
L["Notification options"] = "提示选项"
L["Notify outdated versions"] = "提示过期版本"
L["Notify outdated versions that are compatible with your version"] = "提示过期但是与你的版本兼容的版本"
L["Notify outdated versions that aren't compatible with your version"] = "提示过期且与你的版本不兼容的版本"
L["Notify raid members that do not have GDKPd installed"] = "提示团队中未安装GDKPd的人"
-- L["Player balance"] = "Player balance"
-- L["Please enter the itemID of an item you want to drop here:"] = "Please enter the itemID of an item you want to drop here:"
L["Pot export"] = "导出拍卖收入" -- Needs review
L["Pot size: %d|cffffd100g|r"] = "拍卖收入: %d|cffffd100g|r"
L["Prevent dragging and hide anchor"] = "防止拖动并隐藏锚点"
L["Request version data"] = "查看版本信息"
-- L["Rules"] = "Rules"
L["Second bidder share"] = "第二出价者分享" -- Needs review
-- L["Show"] = "Show"
-- L["Show addon frames"] = "Show addon frames"
L["Show auction duration spiral"] = "显示拍卖时间螺旋" -- Needs review
L["Show countdown text on auction duration spiral"] = "在拍卖时间螺旋上显示倒计时文字" -- Needs review
L["Starting bid"] = "开始出价"
L["Stop bid"] = "停止出价"
L["The amount of seconds that have to pass after a bid before the auction is closed"] = "收到最后出价后直到拍卖成功所需要等待的秒数"
L["The amount of seconds that have to pass before the auction is closed without bids recieved"] = "因未收到出价而结束拍卖所必须等待的秒数"
L["Third bidder share"] = "第三出价者分享"
L["This player does not have GDKPd running or his version of GDKPd does not yet support version checks."] = "该玩家没有安装GDKPd或他使用的版本不支持版本检查"
L["This player has the same version of GDKPd as you do. Full compability is ensured."] = "该玩家使用了与你相同版本的GDKPd.保证了完全兼容"
L["This player's version of GDKPd is more advanced than yours. Please consult your Curse Client for updates or manually check the curse.com page."] = "该玩家使用比你更高版本的GDKPd.请查看你的Curse Client进行升级或手动在curse.com升级本插件"
L["This player's version of GDKPd is outdated and one or more functionalities are not compatible:"] = "该玩家使用了过期的GDKPd并且其多种功能与你的版本不兼容"
L["This player's version of GDKPd is outdated. However, their version should be fully compatible with yours."] = "该玩家的GDKPd版本过期.但是他的版本应该可以与你的版本完全兼容"
L["This version of GDKPd was never functional due to internal errors."] = "由于内部错误导致该版本GDKPd无法正常运行"
-- L["This version's player balance window will be unable to recognize distributions by you."] = "This version's player balance window will be unable to recognize distributions by you."
L["This version will be unable to recognize auctions started by you."] = "该版本将无法识别你发布的拍卖"
L[ [=[This will completely wipe your auction history and is IRREVERSIBLE.
Are you completely SURE you want to do this?]=] ] = [=[这么做会完全清除拍卖记录并且无法恢复.
你很确定要这么做吗?]=]
-- L["Toggle zero balance"] = "Toggle zero balance"
L["Use looting system loot threshold setting"] = "使用系统的拾取分配阀值设置" -- Needs review
L["Version notifications"] = "版本提示"
L["Versions"] = "版本"
L["Version status for player %s"] = "玩家 %s 的版本信息"
-- L["Visibility settings"] = "Visibility settings"
L["Wipe history"] = "灭团记录"
L[ [=[You have looted a monster!
Do you want GDKPd to announce loot?]=] ] = [=[你拾取了一个怪物的尸体!
你想要GDKPd通告物品掉落吗?]=]
L[ [=[You have selected the current pot, size %d gold.
What do you want to do with this pot?]=] ] = [=[你选择了当前的拍卖收入,数量 %d 金.
你想如何处理这些拍卖收入?
]=]
L[ [=[You have selected the following pot:
%s, dated %s, size %d gold.
What do you want to do with this pot?]=] ] = [=[你选择了以下的拍卖收入:
%s,日期 %s,数量 %d 金.
你想如何处理这些拍卖收入?]=]
