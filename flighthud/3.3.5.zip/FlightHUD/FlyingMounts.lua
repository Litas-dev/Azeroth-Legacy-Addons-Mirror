--[[

Scraped from http://www.wowhead.com/?spells&filter=na=Outland;ex=on;me=21

Have to manually add the 2 Headless Horseman's Mounts, as its tooltip does not
contain the word "Outland". Sigh...


]]--

FlightHUDFlyingMounts = {
  [60025] = 1, -- Albino Drake
  [63844] = 1, -- Argent Hippogryph
  [61230] = 1, -- Armored Blue Wind Rider
  [61229] = 1, -- Armored Snowy Gryphon
  [40192] = 1, -- Ashes of Al'ar
  [59567] = 1, -- Azure Drake
  [41514] = 1, -- Azure Netherwing Drake
  [62048] = 1, -- Black Dragonhawk Mount
  [59650] = 1, -- Black Drake
  [59976] = 1, -- Black Proto-Drake
  [72808] = 1, -- Bloodbathed Frostbrood Vanquisher
  [61996] = 1, -- Blue Dragonhawk
  [59568] = 1, -- Blue Drake
  [59996] = 1, -- Blue Proto-Drake
  [39803] = 1, -- Blue Riding Nether Ray
  [32244] = 1, -- Blue Wind Rider
  [59569] = 1, -- Bronze Drake
  [58615] = 1, -- Brutal Nether Drake
  [43927] = 1, -- Cenarion War Hippogryph
  [41515] = 1, -- Cobalt Netherwing Drake
  [64927] = 1, -- Deadly Gladiator's Frost Wyrm
  [40212] = 1, -- Dragonmaw Nether Drake
  [32239] = 1, -- Ebon Gryphon
  [42667] = 1, -- Flying Broom
  [42673] = 1, -- Flying Broom
  [61451] = 1, -- Flying Carpet
  [44153] = 1, -- Flying Machine
  [51960] = 1, -- Frost Wyrm Mount
  [75596] = 1, -- Frosty Flying Carpet
  [65439] = 1, -- Furious Gladiator's Frost Wyrm
  [32235] = 1, -- Golden Gryphon
  [61294] = 1, -- Green Proto-Drake
  [39798] = 1, -- Green Riding Nether Ray
  [32245] = 1, -- Green Wind Rider
  [72807] = 1, -- Icebound Frostbrood Vanquisher
  [63956] = 1, -- Ironbound Proto-Drake
  [61309] = 1, -- Magnificent Flying Carpet
  [44744] = 1, -- Merciless Nether Drake
  [63796] = 1, -- Mimiron's Head
  [39949] = 1, -- Mount (Test Anim)
  [3363] = 1, -- Nether Drake
  [41513] = 1, -- Onyx Netherwing Drake
  [69395] = 1, -- Onyxian Drake
  [32345] = 1, -- Peep the Phoenix Mount
  [60021] = 1, -- Plagued Proto-Drake
  [41516] = 1, -- Purple Netherwing Drake
  [39801] = 1, -- Purple Riding Nether Ray
  [61997] = 1, -- Red Dragonhawk
  [59570] = 1, -- Red Drake
  [59961] = 1, -- Red Proto-Drake
  [39800] = 1, -- Red Riding Nether Ray
  [67336] = 1, -- Relentless Gladiator's Frost Wyrm
  [63963] = 1, -- Rusted Proto-Drake
  [66087] = 1, -- Silver Covenant Hippogryph
  [39802] = 1, -- Silver Riding Nether Ray
  [32240] = 1, -- Snowy Gryphon
  [66088] = 1, -- Sunreaver Dragonhawk
  [32242] = 1, -- Swift Blue Gryphon
  [42668] = 1, -- Swift Flying Broom
  [42679] = 1, -- Swift Flying Broom
  [32290] = 1, -- Swift Green Gryphon
  [32295] = 1, -- Swift Green Wind Rider
  [37015] = 1, -- Swift Nether Drake
  [32292] = 1, -- Swift Purple Gryphon
  [32297] = 1, -- Swift Purple Wind Rider
  [32289] = 1, -- Swift Red Gryphon
  [32246] = 1, -- Swift Red Wind Rider
  [32296] = 1, -- Swift Yellow Wind Rider
  [32243] = 1, -- Tawny Wind Rider
  [60002] = 1, -- Time-Lost Proto-Drake
  [44151] = 1, -- Turbo-Charged Flying Machine
  [59571] = 1, -- Twilight Drake
  [49193] = 1, -- Vengeful Nether Drake
  [41517] = 1, -- Veridian Netherwing Drake
  [41518] = 1, -- Violet Netherwing Drake
  [60024] = 1, -- Violet Proto-Drake
  [54729] = 1, -- Winged Steed of the Ebon Blade
  [54726] = 1, -- Winged Steed of the Ebon Blade
  [54727] = 1, -- Winged Steed of the Ebon Blade
  [71810] = 1, -- Wrathful Gladiator's Frost Wyrm
  [46197] = 1, -- X-51 Nether-Rocket
  [46199] = 1, -- X-51 Nether-Rocket X-TREME
  [48023] = 1, -- Headless Horseman's Mount 280
  [51617] = 1, -- Headless Horseman's Mount 100
}
--[[

Compiled 82 mounts on Thu May 20 21:08:22 2010. Two mounts added manually not present
in the count.

]]--
