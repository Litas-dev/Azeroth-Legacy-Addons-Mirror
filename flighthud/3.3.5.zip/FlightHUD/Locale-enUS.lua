local L = LibStub("AceLocale-3.0"):NewLocale("FlightHUD", "enUS", true)
if not L then return end

L["+"] = true

L["A Heads Up Display (HUD) that shows information while flying or riding"] = true
L["Add FlightHUD Waypoint"] = true
L["Add Normal Waypoint"] = true
L["Add Sticky Waypoint"] = true
L["Allow clicking on the Blizzard quest helper to set waypoints in the HUD"] = true
L["Alt"] = true
L["Alt-Ctrl"] = true
L["Alt-Ctrl-Shift"] = true
L["Alt-Shift"] = true
L["Always"] = true
L["Always show compass"] = true
L["Always show pitch"] = true
L["Always show the HUD"] = true
L["Announce the arrival for a waypoint with a sound file"] = true

L["Both"] = true
L["Blizzard Quest Waypoint"] = true

L["Cancel"] = true
L["Choose to display waypoints in an ellipse or a rectangle."] = true
L["Coordinates Text Color"] = true
L["Completely disable the addon."] = true
L["Control how speed is displayed."] = true
L["Ctrl"] = true
L["Ctrl-Shift"] = true

L["degree"] = true
L["degrees"] = true
L["Description/Notes:"] = true
L["Disable"] = true
L["Dwarf Female Roar"] = true
L["Dwarf Male Roar"] = true

L["Edit FlightHUD Waypoint"] = true
L["Ellipse"] = true
L["ETA: "] = true
L["Event that shows the HUD"] = true
L["Events which dictate when the HUD and its elements are shown."] = true

L["FlightHUD"] = true
L["FlightHUD Waypoints"] = true
L["Flying"] = true
L["Flying or Riding"] = true
L["Font Scale"] = true
L["Frame Scale"] = true

L["General"] = true
L["General Options"] = true
L["Gnome Female Roar"] = true
L["Gnome Male Roar"] = true

L["H: "] = true
L["Heading text"] = true
L["Heading Text Color"] = true
L["Horizontal speed"] = true
L["HUD Alpha"] = true
L["HUD BG Alpha"] = true
L["Human Female Roar"] = true
L["Human Male Roar"] = true

L["Lock"] = true
L["Lock the position of the HUD"] = true

L["Make all waypoints sticky by default. You have to explicitly delete them from the map."] = true
L["Make the QuestHelper default quest always appear as a waypoint in the HUD"] = true
L["Map coordinates text"] = true
L["minute"] = true
L["minutes"] = true
L["Mounted"] = true

L["Never"] = true
L["Night Elf Female Roar"] = true
L["Night Elf Male Roar"] = true
L["Notification Sound"] = true

L["Only Flying"] = true
L["Options for scaling the HUD and its elements."] = true
L["Options for resetting all other options."] = true
L["Orc Female Roar"] = true
L["Orc Male Roar"] = true

L["Percentage"] = true
L["Pitch Graphics Scale"] = true
L["Pitch text"] = true
L["Pitch Text Color"] = true
L["Player speed text"] = true
L["Prepend a prefix to denote the speed type ([H]orizontal or [T]rue)"] = true
L["PVP Flag Taken"] = true

L["QuestHelper Integration"] = true
L["QuestHelper Waypoint"] = true

L["Raid Warning"] = true
L["Ready Check"] = true
L["Really delete waypoint '%s'?"] = true
L["Really remove all non-sticky waypoints?"] = true
L["Really remove all sticky waypoints?"] = true
L["Really reset all FlightHUD settings?"] = true
L["Really reset all text colors?"] = true
L["Really reset the position of the HUD?"] = true
L["Rectangle"] = true
L["Refresh Interval"] = true
L["Refresh the HUD every X seconds. (Lower values might be CPU intensive)"] = true
L["Remove all non-sticky waypoints"] = true
L["Remove all sticky waypoints"] = true
L["Remove Non Sticky Waypoints"] = true
L["Remove Sticky Waypoints"] = true
L["Reset"] = true
L["Reset all settings"] = true
L["Reset all text colors"] = true
L["Resets all text colors back to green"] = true
L["Reset Position"] = true
L["Reset the position of the HUD back to the center of the screen"] = true
L["Resets all FlightHUD settings back to the default"] = true
L["Right Click To Add a FlightHUD Waypoint"] = true
L["Run away little girl"] = true

L["Save Waypoints"] = true
L["Scale the HUD frame"] = true
L["Scale the HUD pitch graphic"] = true
L["Scale the HUD text fonts"] = true
L["Scaling"] = true
L["second"] = true
L["seconds"] = true
L["Set as FlightHUD waypoint"] = true
L["Set FlightHUD Waypoint"] = true
L["Set the modifier used when right-clicking on the world map to create a waypoint"] = true
L["Set the modifier used when right-clicking on World Map POI's to create a waypoint"] = true
L["Shift"] = true
L["Show compass when mounted on a flying mount"] = true
L["Show compass when mounted on a ground mount"] = true
L["Show compass when swimming"] = true
L["Show Events"] = true
L["Show on minimap"] = true
L["Show on worldmap"] = true
L["Show pitch when mounted on a flying mount"] = true
L["Show pitch when mounted on a ground mount"] = true
L["Show pitch when swimming"] = true
L["Show speed as yards per second or percentage."] = true
L["Show speed as true speed or horizontal speed."] = true
L["Show the exact heading text in the HUD"] = true
L["Show the exact pitch text in the HUD"] = true
L["Show the HUD when mounted on a flying mount"] = true
L["Show the HUD when mounted on a ground mount"] = true
L["Show the HUD when swimming"] = true
L["Show the map coordinates text in the HUD"] = true
L["Show the player's speed text in the HUD"] = true
L["Speed Controls"] = true
L["Speed display"] = true
L["Speed Precision"] = true
L["Speed Prefix Text"] = true
L["Speed Text Color"] = true
L["Sticky"] = true
L["Swimming"] = true

L["T: "] = true
L["Tauren Female Roar"] = true
L["Tauren Male Roar"] = true
L["Text Options"] = true
L["The arc in degrees in front of the character required for a waypoint to show ETA text."] = true
L["The color of the coordinates text"] = true
L["The color of the heading text"] = true
L["The color of the pitch text"] = true
L["The color of the speed text"] = true
L["The color of the waypoint text"] = true
L["The color of the waypoint text drop shadow"] = true
L["The distance from the waypoint before it is removed if it's not sticky"] = true
L["The number of decimal points to display for speed."] = true
L["The sound that will play upon arrival at a waypoint."] = true
L["The transparency value of the HUD"] = true
L["The transparency value of the HUD background"] = true
L["Thrall"] = true
L["Title"] = true
L["Toggle FlightHUD"] = true
L["Toggle the display of certain texts on and off."] = true
L["Troll Female Roar"] = true
L["Troll Male Roar"] = true
L["True speed"] = true

L["Undead Female Roar"] = true
L["Undead Male Roar"] = true

L["Waypoints"] = true
L["Waypoint Arrival Notification"] = true
L["Waypoint Display"] = true
L["Waypoint distance"] = true
L["Waypoint ETA Arc"] = true
L["Waypoint Text Color"] = true
L["Waypoint Text Drop Shadow Color"] = true
L["When to show the HUD"] = true
L["When to show compass"] = true
L["When to display compass HUD."] = true
L["Waypoint Options"] = true
L["When to display pitch HUD."] = true
L["When to show pitch"] = true
L["Which speed"] = true
L["Worldmap modifier"] = true
L["Worldmap POI Integration"] = true
L["Worldmap POI modifier"] = true

L["y/s"] = true
L["yards"] = true
L["Yards per second"] = true
L["Yes"] = true

L["Zone Only"] = true

--[===[@debug@
L["Debug"] = true
L["Options for debugging various aspects of the addon."] = true
L["Set the debug flag"] = true
--@end-debug@]===]
          