if not SunnArtPack then SunnArtPack = {theme = {}, overlap = {}, panels = {}, length = {}} end
SunnArtPack.theme["SunnArtPack10\\wc3_horde-"] = "Warcraft III - Horde"
SunnArtPack.overlap["SunnArtPack10\\wc3_horde-"] = 28.516
SunnArtPack.panels["SunnArtPack10\\wc3_horde-"] = 2

SunnArtPack.theme["SunnArtPack10\\wc3_human_ui2-"] = "Warcraft III - Human UI"
SunnArtPack.overlap["SunnArtPack10\\wc3_human_ui2-"] = 29.687
SunnArtPack.panels["SunnArtPack10\\wc3_human_ui2-"] = 4

SunnArtPack.theme["SunnArtPack10\\wc3_nelf_ui-"] = "Warcraft III - Night Elf UI"
SunnArtPack.overlap["SunnArtPack10\\wc3_nelf_ui-"] = 29.687
SunnArtPack.panels["SunnArtPack10\\wc3_nelf_ui-"] = 4

SunnArtPack.theme["SunnArtPack10\\wc3_orc_ui-"] = "Warcraft III - Orc UI"
SunnArtPack.overlap["SunnArtPack10\\wc3_orc_ui-"] = 29.687
SunnArtPack.panels["SunnArtPack10\\wc3_orc_ui-"] = 4

SunnArtPack.theme["SunnArtPack10\\wc3_undead_ui-"] = "Warcraft III - Undead UI"
SunnArtPack.overlap["SunnArtPack10\\wc3_undead_ui-"] = 29.687
SunnArtPack.panels["SunnArtPack10\\wc3_undead_ui-"] = 4

SunnArtPack.theme["SunnArtPack10\\wc3_decorative-"] = "Warcraft III - Decorative"
SunnArtPack.overlap["SunnArtPack10\\wc3_decorative-"] = 0
SunnArtPack.panels["SunnArtPack10\\wc3_decorative-"] = 4

DEFAULT_CHAT_FRAME:AddMessage("|cFF0000FFSunnArtPack10|r: Loaded")
