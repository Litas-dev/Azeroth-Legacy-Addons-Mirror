


function Pixel_OnUpdate()

	if t_pixel_onload and UnitClass("player")=="Warlock" and xtimer("PIXEL TEXT",0.11) then
		--Warlock

		if ( ( Unit_Buff_Timeleft("player","Drink") >0 and PlayerMana()<100 ) or ( Unit_Buff_Timeleft("player","Food") > 0 and PlayerHealth()<100 )  ) then
			SetPixelColor(0,0,0)
			
		elseif Able("Drain Life")==1 and UnitHostile() and UnitHealthMax("player")-UnitHealth("player")>175 and GetUnitSpeed("player")==0 then
			SetPixelColor(0,1,1)
			
		elseif Able("Drain Soul")==1 and UnitHostile() and ( UnitHealth("target")/UnitHealthMax("target")<0.25 or UnitHealth("target")<55 ) and GetItemCount("Soul Shard")<6 and GetUnitSpeed("player")==0 and FREEBAGSLOTS()>6 then
			SetPixelColor(1,0.5,1)	
			
		elseif Able("Health Funnel","pet")==1 and ( PlayerHealth()-PetHealth()>40 or UnitHealth("player")-61>UnitHealth("pet")+12*10 ) and UnitHealthMax("pet")-UnitHealth("pet")>12*10 then
			SetPixelColor(0,0,0.5)
			
		--start combat?
		elseif ( not UnitExists("pet") or UnitExists("pettarget") ) and PlayerHealth()+PlayerMana()>160 and PlayerHealth()>70 and Able("Immolate")==1 and not UnitIsDeadOrGhost("target") and UnitCanAttack("target","player") and not UnitDebuff("target","Immolate") and ( last_cast~="Immolate" or GetTime()-last_time>0.5 ) and UnitLevel("player")+2 >= UnitLevel("target") and UnitHealth("pet")+UnitMana("pet")>130 and not UnitAffectingCombat("player") and not UnitAffectingCombat("pet") and GetNumVisibleTeam()<=1 then 
			SetPixelColor(1,0,0)
			
		elseif Able("Curse of Agony")==1 and UnitHostile() and not UnitDebuff("target","Curse of Agony") then
			SetPixelColor(1,1,1)			
			
		elseif Able("Corruption")==1 and UnitHostile() and not UnitDebuff("target","Corruption") then
			SetPixelColor(1,0,1)
			
		elseif Able("Health Funnel","pet")==1 and UnitHealthMax("pet")-UnitHealth("pet")>12*10 and PlayerHealth()>96 then
			SetPixelColor(0,0,0.5)
			
		elseif Able("Immolate")==1 and UnitHostile() and not UnitDebuff("target","Immolate") and ( last_cast~="Immolate" or GetTime()-last_time>0.5 ) then
			SetPixelColor(1,0,0)
		
		elseif Able("Fear")==1 and UnitHostile() and not UnitDebuff("target","Fear") and targetFearable then
			SetPixelColor(1,1,0.5)
			
		elseif Able("Drain Life")==1 and UnitHostile() and UnitHealthMax("player")-UnitHealth("player")>125 and GetUnitSpeed("player")==0 then
			SetPixelColor(0,1,1)
		
		elseif Able("Shadow Bolt")==1 and UnitHostile() and UnitHealth("target")/UnitHealthMax("target")>0.33 then
		   SetPixelColor(0,0,1)
			

		elseif Able("Demon Skin") and WarlockArmor() < 60*15 and UnitClass("player")=="Warlock" then
			SetPixelColor(0,1,0)
			
		elseif Able("Life Tap") and PlayerHealth()>97 and PlayerMana()<82 then
			SetPixelColor(1,1,0)
			
		elseif Able("Life Tap") and PlayerMana()+55<PlayerHealth() then
			SetPixelColor(1,1,0)
			
		elseif ( not UnitExists("target") or not UnitCanAttack("target","player") ) and ( UnitCanAttack("focustarget","player") or UnitCanAttack("pettarget","player") or UnitCanAttack("targettarget","player") or UnitCanAttack("focus","player") ) then
			SetPixelColor(1,0.5,0.5)
			
		elseif UnitExists("pet") and UnitIsUnit("targettarget","player") and not UnitIsUnit("pettarget","target") and not UnitIsDeadOrGhost("target") and UnitCanAttack("target","player") then
		   SetPixelColor(0,0.5,0.5)
			
		--start combat?
		elseif UnitExists("pet") and GetNumVisibleTeam()<=1 and not UnitExists("pettarget") and PetHealth()+PetMana()>195 and PlayerHealth()+PlayerMana()>120 and PlayerHealth()>50 and GetUnitSpeed("pet")==0 and GetUnitSpeed("player")==0 and CheckInteractDistance("target",1) and not UnitIsDeadOrGhost("target") and UnitCanAttack("target","player") and UnitLevel("player")+2 >= UnitLevel("target") then
		   SetPixelColor(0,0.5,0.5)	
			
			
		else
			SetPixelColor(0,0,0)
			
		end	

	
	elseif t_pixel_onload and UnitClass("player")=="Warrior" and xtimer("PIXEL TEXT",0.07) then
		--Warrior

		if not UnitAffectingCombat("player") and ( ( Unit_Buff_Timeleft("player","Drink") >0 and PlayerMana()<100 ) or ( Unit_Buff_Timeleft("player","Food") > 0 and PlayerHealth()<100 )  ) then
			SetPixelColor(0,0,0)
		
		elseif Able("Devastate")==1 and UnitHostile() and ( select(4,UnitDebuff("target","Sunder Armor") ) or 0 )>2 and (select(7,UnitDebuff("target","Sunder Armor")) or 0)-GetTime()<9 then
			SetPixelColor(0,1,0)
		
		elseif Able("Shield Slam")==1 and UnitHostile() then
			SetPixelColor(1,0,1)
			
		elseif Able("Shockwave") and UnitHostile() and IsSpellInRange("Sunder Armor")==1 then
			SetPixelColor(1,1,0)
			
		elseif Able("Thunder Clap") and UnitHostile() and IsSpellInRange("Sunder Armor")==1 and not UnitDebuff("target","Thunder Clap") then
			SetPixelColor(1,0,0)			
			
		elseif Able("Revenge")==1 and UnitHostile() then
			SetPixelColor(0,1,1)
			
		--elseif Able("Demoralizing Shout") and UnitHostile() and IsSpellInRange("Sunder Armor")==1 and not UnitDebuff("target","Demoralizing Shout") then
		--	SetPixelColor(1,0,0)
		
		elseif Able("Thunder Clap") and UnitHostile() and IsSpellInRange("Sunder Armor")==1 then
			SetPixelColor(1,0,0)
		
		elseif Able("Devastate")==1 and UnitHostile() then
			SetPixelColor(0,1,0)
			
		else
			SetPixelColor(0,0,0)
			
		end
		
		
		
		
	elseif t_pixel_onload and UnitClass("player")=="Shaman" and xtimer("PIXEL TEXT",0.04) then
		--Shaman
		
		
		if not UnitAffectingCombat("player") and ( ( Unit_Buff_Timeleft("player","Drink") >0 and PlayerMana()<100 ) or ( Unit_Buff_Timeleft("player","Food") > 0 and PlayerHealth()<100 )  ) then
			SetPixelColor(0,0,0)
			
		elseif Able("Healing Wave")==2 and UnitHealthMax("player")-UnitHealth("player")>129*2.5 then
			SetPixelColor(3/255,0,0)
			
		elseif DidCanHeal() then
			--did something already !
			
		elseif Able("Flame Shock")==1 and not UnitDebuff("target","Flame Shock") and UnitHealth("target")>21 and UnitHostile() then
			SetPixelColor(10/255,0,0)
			
		elseif Able("Purge")==1 and UnitBuff("target",1,"CANCELABLE") and UnitHostile() then
			SetPixelColor(12/255,0,0)
			
		elseif Able("Earth Shock")==1 and not UnitDebuff("target","Earth Shock") and ( UnitHealth("target")>17 or GetUnitSpeed("target")~=0 ) and UnitHostile() then
			SetPixelColor(6/255,0,0)
			
		elseif Able("Lightning Shield") and Unit_Buff_Timeleft("player","Lightning Shield")<9 then
			SetPixelColor(1/255,0,0)	
			
		elseif Able("Healing Wave")==2 and UnitHealthMax("player")-UnitHealth("player")>129*1.5 and ( last_cast~="Healing Wave" or GetTime()-last_time>0.5 ) then
			SetPixelColor(3/255,0,0)
			
		elseif Able("Earth Shock")==1 and ( UnitHealth("target")>17 or GetUnitSpeed("target")~=0 ) and UnitHostile() then
			SetPixelColor(6/255,0,0)
			
		elseif Able("Stoneskin Totem") and  not GetEarthTotem() and UnitAffectingCombat("player") and Unit_Buff_Timeleft("player","Stoneskin")==0 and GetUnitSpeed("player")==0 then
			SetPixelColor(7/255,0,0)
		
		elseif Able("Lightning Bolt")==1 and UnitHealth("target")>9 and  Able("Healing Wave","player") and UnitHostile() then
			SetPixelColor(2/255,0,0)
			
			
		elseif Able("Flametongue Weapon") and WeaponEnchant()==0 then
			SetPixelColor(5/255,0,0)
			
		elseif Able("Lightning Shield") and ( Unit_Buff_Timeleft("player","Lightning Shield")<60*8 or Unit_Buff("player","Lightning Shield")<3 ) and not UnitAffectingCombat("player") then
			SetPixelColor(1/255,0,0)
			
		elseif Able("Lightning Shield") and ( Unit_Buff_Timeleft("player","Lightning Shield")<60*1 or Unit_Buff("player","Lightning Shield")<2 ) then
			SetPixelColor(1/255,0,0)

			
		else
			SetPixelColor(0,0,0)
			
		end
		
		
		
		
		
		
		
	elseif t_pixel_onload and xtimer("PIXEL TEXT",30) then
		SetPixelColor(0,0,0)
		PixelOffsetFrame:Hide()
		
	end
	
	
	
	
	if UnitCastingInfo("player") then
		last_cast = UnitCastingInfo("player")
		last_time = GetTime()
	end
end



--pixel rgb colors

p_curR = 0
p_curG = 0
p_curB = 0

function SetPixelColor(r,g,b)
	if r~=p_curR or g~=p_curG or b~=p_curB then
	--	print(r*255 .." "..g*255 .." "..b*255)
	end
	if type(r)=="number" then
		p_curR = r
	end
	if type(g)=="number" then
		p_curG = g
	end
	if type(b)=="number" then
		p_curB = b
	end
	PixelColorFrame.texture:SetTexture(p_curR,p_curG,p_curB,1)
end










function Able(spellName,unitName)
	if not unitName then
		unitName = "target"
	end
	
	local name, rank, icon, cost, isFunnel, powerType, castTime, minRange, maxRange = GetSpellInfo(spellName)
	
	if Cooldown(spellName)~=0 then
		return false
	elseif UnitCastingInfo("player") then
		return false
	elseif UnitChannelInfo("player") then
		return false
	--[[elseif IsSpellInRange(spellName)~=1 and maxRange~=0 and powerType~=1 then
		return false
	elseif IsSpellInRange(spellName)~=1 and powerType==1 then
		return false]]--
	elseif not IsUsableSpell(spellName) then
		return false
	elseif castTime~=0 and GetUnitSpeed("player")~=0 then
		return false
	else
		return ( IsSpellInRange(spellName,unitname) or 2 )
	end
end



function UnitHostile(unitName)
	if not unitName then
		unitName = "target"
	end
	if UnitIsDeadOrGhost(unitName) then
		return false
	elseif not UnitCanAttack(unitName,"player") and not UnitCanAttack("player",unitName) then
		return false
	elseif not UnitAffectingCombat(unitName) and UnitHealthMax(unitName)~=1 and not UnitIsUnit("targettarget","player") then
		return false
	else
		return 1
	end

end







function DidCanHeal()
	for index=0,40 do
		raidIndex = "raid"..index
		if Able("Healing Wave",raidIndex) and UnitHealthMax(raidIndex)-UnitHealth(raidIndex)>129*1.5 then

			row, col = RaidRowCol(index)

			if xtimer("didcanheal",1) then
				dprint(raidIndex.."   r"..row.."  c"..col)
			end
			SetPixelColor(0,(row*16+col)/255,0)
			return index
		end
	end
end





function RaidRowCol(unitNum)
	row = mod(unitNum,5)
	col = ceil(unitNum/5)
	return row , col
end










function WarlockArmor()
	return Unit_Buff_Timeleft("player","Demon Skin") + Unit_Buff_Timeleft("player","Demon Armor") + Unit_Buff_Timeleft("player","Fel Armor")
end