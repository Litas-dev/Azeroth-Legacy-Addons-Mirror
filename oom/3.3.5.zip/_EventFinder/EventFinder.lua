
-- UIErrorsFrame:AddMessage("msg" ,0,1,.5,1,2)
-- string.find( UnitDebuff("target",i),sDebuffName )
-- DEFAULT_CHAT_FRAME:AddMessage("woot!")

local CT = ColorText

local dprint = function(...)
  DEFAULT_CHAT_FRAME:AddMessage(...)
end

EventFinderMaxArgsSeen = -1


---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

function EventFinder_OnEvent(...)

  --Generage EventArg
  EventArg=event
  for esai = 1, select('#', ...) do
    EventStringAdder( select(esai , ...) ,esai)
  end

--[[
  s,d,e = GetSpellCooldown("Healing Touch") 
	EventArg = EventArg .. ColorText(0,1,0) .. " " .. s-GetTime()+d
	if s~=0 and d~=0 and s-GetTime()+d>1.5 then
		DEFAULT_CHAT_FRAME:AddMessage(EventArg)
	end
]]--
  
  --how many args to the center of a tootie pop?
  if type(EventFinderMaxArgsSeen)=="number" and select('#', ...) > EventFinderMaxArgsSeen then
    EventFinderMaxArgsSeen = select('#',  ...)
--  dprint("New " ..ColorText(1,0,0).."EventFinderMaxArgsSeen"..ColorText() .. " = " .. EventFinderMaxArgsSeen)
--  DEFAULT_CHAT_FRAME:AddMessage(EventArg)
  end
  
	

	
	
	if EventArg and EventFinderSearch and EventFinderSearch2 and strfind( strlower(EventArg) , strlower(EventFinderSearch) ) and strfind( strlower(EventArg) , strlower(EventFinderSearch2) ) then
	  if xtimer(EventArg.."1",1) or xtimer(EventArg.."2",1) or xtimer(EventArg.."3",2) then
			last_EventArg = EventArg
			EventFinderSpam = GetTime()
			DEFAULT_CHAT_FRAME:AddMessage(EventArg)
			DEFAULT_CHAT_FRAME:AddMessage(" ")
			return (EventArg)
    end
  elseif EventArg and EventFinderSearch and strfind( strlower(EventArg) , strlower(EventFinderSearch) ) and not EventFinderSearch2 then
		if xtimer(EventArg.."1",1) or xtimer(EventArg.."2",1) or xtimer(EventArg.."3",2) then
			last_EventArg = EventArg
			EventFinderSpam = GetTime()
			DEFAULT_CHAT_FRAME:AddMessage(EventArg)
			DEFAULT_CHAT_FRAME:AddMessage(" ")
			return (EventArg)
		end
  end
  
  
  
  
  if EventArg and strfind( strlower(EventArg) , strlower("reflect") ) then
  
		if event=="COMBAT_LOG_EVENT" then
			--ignore
			
		elseif event and strfind( event , "CHAT_MSG_") then
			--ignore
			
		elseif select(1,...)=="player" and select(2,...)=="Spell Reflection" then
			--ignore
		 
		elseif select(2,...)=="SPELL_AURA_APPLIED" and select(10,...)=="Spell Reflection" then
			--ignore
			
		elseif select(2,...)=="SPELL_CAST_SUCCESS" and select(10,...)=="Spell Reflection" then
			--ignore
			
		elseif select(2,...)=="SPELL_AURA_REMOVED" and select(10,...)=="Spell Reflection" then
			--ignore
			
		elseif event=="COMBAT_TEXT_UPDATE" and select(1,...)=="SPELL_AURA_START" and select(2,...)=="Spell Reflection" then
			--ignore
			
		elseif event=="COMBAT_TEXT_UPDATE" and select(1,...)=="SPELL_AURA_END" and select(2,...)=="Spell Reflection" then
			--ignore
		 
		 
		elseif event=="COMBAT_LOG_EVENT_UNFILTERED" and select(2,...)=="SPELL_CAST_FAILED" and select(10,...)=="Spell Reflection" and select(12,...)=="Not enough rage" then
			--ignore
			
		elseif event=="COMBAT_LOG_EVENT_UNFILTERED" and select(2,...)=="SPELL_CAST_FAILED" and select(10,...)=="Spell Reflection" and select(12,...)=="Not yet recovered" then
			--ignore	
		 
		  
		  
		elseif event=="COMBAT_LOG_EVENT_UNFILTERED" and select(2,...)=="SPELL_MISSED" and select(12,...)=="REFLECT" and type(select(4,...))=="string" and type(select(7,...))=="string" and type(select(10,...))=="string" then
			-- 4=caster
			-- 7=reflector
			-- 10=spell
			
			last_EventArg = EventArg
			EventFinderSpam = GetTime()
			
			dprint( "  "..ColorText(1,.7,.7)..select(4,...)..ColorText().."'s "..ColorText(1,.2,.2)..select(10,...) ..ColorText().." reflected by "..ColorText(.6,.6,1)..select(7,...)..ColorText() )
			return (EventArg)
		  
		elseif event=="UNIT_COMBAT" and select(1,...)=="player" and select(2,...)=="REFLECT" and select(4,...)==0 and select(5,...)==1 then
			-- figure something out?
			
		elseif event=="COMBAT_TEXT_UPDATE" and select(1,...)=="SPELL_REFLECT" then
			-- figure something out?
			
		--elseif strcount(EventArg,UnitName("target")) + strcount( strlower(EventArg) , "target" ) >0  then
			--DEFAULT_CHAT_FRAME:AddMessage(EventArg)
			
			
		elseif select(10,...)=="Reflective Shield" then
			--ignore
			
		elseif not showAllReflect then
			--ignore
		  
		elseif xtimer(EventArg.."1",1) or xtimer(EventArg.."2",2) or xtimer(EventArg.."3",3) then
			last_EventArg = EventArg
			EventFinderSpam = GetTime()
			DEFAULT_CHAT_FRAME:AddMessage(EventArg)
			return (EventArg)
			
    end
	 
  end
  
  
  
  
  
	--12 = DEBUFF
  
   if not select(2,...) or type( select(2,...) ) ~="string" then
		--ignore
   elseif strfind( select(2,...) , "CAST_SUCCESS" ) or strfind( select(2,...) , "AURA_REM" ) or strfind( select(2,...) , "HEAL" ) then
		--ignore
	elseif type(select(2,...))=="string" and strfind(select(2,...),"ENERGIZE") then
		--ignore
	elseif select(12,...) and select(12,...)=="BUFF" then
	  --ignore for now?!?
	  
	elseif EventArg and event~="COMBAT_LOG_EVENT" and strcount(EventArg,UnitName("target")) >1 and UnitCanAttack("player","target") then
	
		--DEFAULT_CHAT_FRAME:AddMessage(EventArg)

		if select(4,...)==select(7,...) and select(10,...) and type(select(10,...))=="string" then
			
			
			if select(12,...) and type( select(12,...) )=="number" then
				dprint( select(4,...) .." affected by its own " .. select(10,...) .." <"..select(12,...)..">" )
			else
				dprint( select(4,...) .." affected by its own " .. select(10,...)  )
			end
			
			if select(12,...)=="DEBUFF" then
				--ignore
			elseif type(select(2,...))=="string" and strfind(select(2,...),"SPELL_") and strfind(select(2,...),"_DAMAGE") then
			  --ignore
			else
				DEFAULT_CHAT_FRAME:AddMessage(EventArg)
			end
			
		else
						
		end
		
	end
  
end -- end of EventFinder_OnEvent()


















function EventStringAdder(arg,numarg)
  spacer = " "
  if numarg and arg then
    EventArg=EventArg..ColorText(1,0,0)..' '..numarg.."="..ColorText()
    spacer = ""
  end
  if arg and type(arg)~="boolean" and strlen(arg)>0 then
    EventArg=EventArg..spacer..arg
  elseif arg and type(arg)=="boolean" then
    EventArg=EventArg.." ".."TRUE"
  end
end







--copied from _OOM/Tools.lua
function ColorText(red,green,blue)
  red = tonumber( red )
  green = tonumber( green )
  blue = tonumber( blue )

  if type(red)=="number" and type(green)=="number" and type(blue)=="number" then
    if red<=0 then red=0 end
    if green<=0 then green=0 end
    if blue<=0 then blue=0 end

    if red<=1 and green<=1 and blue<=1 then
      red = red*256
      green = green*256
      blue = blue*256
    end

    red = round( red )
    green = round( green )
    blue = round( blue )

    if red>=255 then red=255 end
    if green>=255 then green=255 end
    if blue>=255 then blue=255 end

    return "\124cFF"..string.format("%02x%02x%02x", red, green, blue)
  else
    return "\124r"
  end
end








function strcount(inputstring,searchterm)
  count = 0
  
	if not inputstring or not searchterm then
		return -2
	end
  
  while( strfind( inputstring , searchterm ) ) do
  
		count = count + 1
		inputstring = strsub(inputstring,  strfind( inputstring , searchterm )+1 )
		
		if count>256 then
			return -1
		end
  
  end

  return count
end