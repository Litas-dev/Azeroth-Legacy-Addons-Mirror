-- UIErrorsFrame:AddMessage("msg",0,1,.5,1,2)
-- string.find( a_string , b_string )
-- DEFAULT_CHAT_FRAME:AddMessage("woot!")



function xkeysBindings()

  xWarrior()
  xPriest()
  xHunter()
	xPaladin()
  xShaman()

  --DEFAULT_CHAT_FRAME:AddMessage(" xkeys Loaded")
end







function xWarrior()
  if UnitClass("player")~="Warrior" then return nil end
  
  CleanSandW()
  
  
  
  SetBindingClick("ALT-CTRL-SHIFT-M", "Shield_Slam") 
  SetBindingClick("ALT-CTRL-SHIFT-R", "Revenge")  
  SetBindingClick("ALT-CTRL-SHIFT-T", "ThunderClap")
  SetBindingClick("ALT-CTRL-SHIFT-V", "ShockWave")
  SetBindingClick("ALT-CTRL-SHIFT-X", "Devastate")
  
  SetBindingClick("ALT-CTRL-SHIFT-G", "Charge")
  SetBindingClick("ALT-CTRL-SHIFT-I", "Intervene")
  SetBindingClick("ALT-CTRL-SHIFT-O", "Intercept")


  
  

  SetBindingClick("ALT-CTRL-SHIFT--", "AUTO_TAUNT")
  SetBindingClick("ALT-CTRL-SHIFT-=", "TAUNT")





  DEFAULT_CHAT_FRAME:AddMessage(" xkeys Loaded (Warrior)")
end






function xPriest()
  if UnitClass("player")~="Priest" then return nil end

  SetBindingSpell("ALT-CTRL-SHIFT-J", "Psychic Scream")
	
	DEFAULT_CHAT_FRAME:AddMessage(" xkeys Loaded (Priest)")
end






function xHunter()
  if UnitClass("player")~="Hunter" then return nil end

  SetBindingClick("ALT-CTRL-SHIFT-K", "KillCommand")
  SetBindingClick("ALT-CTRL-SHIFT-A", "ArcaneShot")
  SetBindingClick("ALT-CTRL-SHIFT-M", "MultiShot")
  SetBindingClick("ALT-CTRL-SHIFT-S", "SteadyShot")
	SetBindingClick("ALT-CTRL-SHIFT-H", "HunterMark")
	SetBindingClick("ALT-CTRL-SHIFT-C", "ConcussiveShot")
	SetBindingClick("ALT-CTRL-SHIFT-D", "Disengage")
	
	DEFAULT_CHAT_FRAME:AddMessage(" xkeys Loaded (Hunter)")
end


		--   \n/startattack [harm,combat,nodead]   \n/target [harm,nodead] [target=focustarget,harm,nodead] [target=targettarget,harm,nodead] 





function xPaladin()
  if UnitClass("player")~="Paladin" then return nil end

	SetBindingClick("ALT-CTRL-SHIFT-C", "Consecration3")
	SetBindingClick("ALT-CTRL-SHIFT-S", "HolyShield1")
	SetBindingClick("ALT-CTRL-SHIFT-R", "RighteousDefense")
	
	DEFAULT_CHAT_FRAME:AddMessage(" xkeys Loaded (Paladin)")
end



--  SetBindingSpell("ALT-CTRL-SHIFT-J", "Bloodrage")
--  SetBindingSpell("ALT-CTRL-SHIFT-5","Sunder Armor")






function xShaman()
  if UnitClass("player")~="Shaman" then return nil end

	SetBindingClick("ALT-CTRL-SHIFT-S", "Stormstrike")
	SetBindingClick("ALT-CTRL-SHIFT-E", "Earth_Shock")
  SetBindingClick("ALT-CTRL-SHIFT-C", "Chain_Lightning")
  SetBindingClick("ALT-CTRL-SHIFT-W", "Wind_Shock")
	SetBindingClick("ALT-CTRL-SHIFT-F", "Frost_Shock")
  SetBindingClick("ALT-CTRL-SHIFT-L", "Lava_Lash")
  SetBindingClick("ALT-CTRL-SHIFT-B", "Lightning_Bolt")
  SetBindingClick("ALT-CTRL-SHIFT-Q", "Wind_Shock_Always")
  SetBindingClick("ALT-CTRL-SHIFT-D", "Chain_Water")
  
	
	DEFAULT_CHAT_FRAME:AddMessage(" xkeys Loaded (Shaman)")
end
























function CleanSandW()
  SetBinding("ALT-S")
  SetBinding("CTRL-S")
  SetBinding("SHIFT-S")
  SetBinding("ALT-CTRL-S")
  SetBinding("ALT-SHIFT-S")
  SetBinding("CTRL-SHIFT-S")
  SetBinding("ALT-CTRL-SHIFT-S")
  
  SetBinding("ALT-W")
  SetBinding("CTRL-W")
  SetBinding("SHIFT-W")
  SetBinding("ALT-CTRL-W")
  SetBinding("ALT-SHIFT-W")
  SetBinding("CTRL-SHIFT-W")
  SetBinding("ALT-CTRL-SHIFT-W")
  
  --SaveBindings() 
end






















function MakeSlave()
  ClearNumbers()
	SetNumPadSlave()
	dprint(" MakeSlave()")
end




function ClearNumbers()
  for i=0,9 do
	  SetBinding(i)
  end
	  SetBinding("-")
		SetBinding("=")
	
end


function ClearNumPad()
  for i=0,9 do
	  SetBinding("NUMPAD"..i)
  end
	SetBinding("NUMPADDIVIDE")
	SetBinding("NUMPADMULTIPLY")
	SetBinding("NUMPADMINUS")
	SetBinding("NUMPADPLUS")
	SetBinding("NUMPADDECIMAL")
end


function SetNumPadSlave()
--ACTIONBUTTON1
  for i=1,9 do
	  SetBinding("NUMPAD"..i,"ACTIONBUTTON"..i)
  end
		SetBinding("NUMPAD0","ACTIONBUTTON10")
end


function SetNumbers()
  for i=1,9 do
	  SetBinding(i,"ACTIONBUTTON"..i)
  end
		SetBinding("0","ACTIONBUTTON10")
	  SetBinding("-","ACTIONBUTTON11")
		SetBinding("=","ACTIONBUTTON12")
end
