-- UIErrorsFrame:AddMessage("msg",0,1,.5,1,2)
-- (string.find(UnitDebuff("target",i),sDebuffName)) 
-- DEFAULT_CHAT_FRAME:AddMessage("woot!")



function xkeys_OnLoad()
  t_xkeys=GetTime()
end





function xkeys_OnUpdate(arg1)
  if t_xkeys and GetTime()-t_xkeys>3 and not UnitAffectingCombat("player") then
    xkeysBindings()
    t_xkeys=nil
  end
end
