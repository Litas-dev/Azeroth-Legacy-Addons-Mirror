-- UIErrorsFrame:AddMessage("msg",0,1,.5,1,2)
-- string.find(UnitDebuff("target",i),sDebuffName)
-- DEFAULT_CHAT_FRAME:AddMessage("woot!")
-- DEFAULT_CHAT_FRAMEScrollToBottom() 







function MBOLIE(...)
  DEFAULT_CHAT_FRAME:AddMessage("woot!")
end






function MakeBeaconOfLightIcon()
  myF = CreateFrame("Frame",nil,UIParent)
	myF:SetFrameStrata("LOW")
	myF:SetWidth(36)
	myF:SetHeight(36)
  myF:SetPoint("CENTER",0,0)
	myF:Show()

	myT = myF:CreateTexture(nil,"BACKGROUND")
	myT:SetTexture("Interface\\Icons\\Ability_Paladin_BeaconofLight")
	myT:SetTexture("Interface\\Icons\\INV_Misc_QuestionMark")
	
	
	myT:SetAllPoints(myF)
	
	myF.texture = myT

	myF:SetMovable(true)
	myF:EnableMouse(true)
	
	myF:SetScript("OnMouseDown",function() myF:StartMoving() echo("Wicked!") end)
	myF:SetScript("OnMouseUp",function() myF:StopMovingOrSizing() end)

	myF:SetClampedToScreen(true)
	
	--lgame.buttoninitialize()
	--MakeBeaconOfLightText()
	
	
	
	
	
	
		myText = CreateFrame("Button", tostring("lgame."..id), UIParent)
		myText:SetMovable(false)
		myText:SetScript("OnClick", MBOLIE)
		myText:SetWidth(2)
		myText:SetHeight(2)
		myText:SetFrameLevel("3")
		myText:ClearAllPoints()
		--myText:SetBackdrop({bgFile = "Interface/Tooltips/UI-Tooltip-Background", edgeFile =  "Interface/Tooltips/UI-Tooltip-Border", edgeSize= 16, insets = { left = 0, right = 0, top = 0, bottom = 0 }}) 



		
		
		myText.font = myText:CreateFontString(nil, "OVERLAY")
		myText.font:SetFontObject("GameFontNormal")
		myText.font:SetHeight(25)
		myText.font:SetWidth(75)
		myText.font:SetText("myText.font")
		myText.font:SetPoint("CENTER", myF, "CENTER",0,-24)
		
		myText:SetPoint("CENTER", myF, "CENTER", 0,0)

		myText:SetScript("OnClick", MBOLIE)
		
		


    --myText.font:SetText(round(mod(GetTime(),10)) )
		myF:SetAlpha(.5)
		
		
		
		myF:Hide()
		myText:Hide()
end

MakeBeaconOfLightIcon()



--[[
function MakeBeaconOfLightText()
  myS = CreateFontString(nil, "OVERLAY")
	myS:SetFrameStrata("DIALOG")
	myS:SetWidth(36)
	myS:SetHeight(36)
  myS:SetPoint("CENTER",0,0)
	myS:Show()

	
	myT = myF:CreateTexture(nil,"BACKGROUND")
	myT:SetTexture("Interface\\Icons\\Ability_Paladin_BeaconofLight")
	
	myS:SetAllPoints(myF)
	
	--myF.texture = myT

	myS:SetMovable(false)
	myS:EnableMouse(false)
	

	myF:SetScript("OnMouseDown",function() myF:StartMoving() end)
	myF:SetScript("OnMouseUp",function() myF:StopMovingOrSizing() end)

	myF:SetClampedToScreen(true)

end
]]--




function MakeBeaconOfLightText()
  myS = CreateFrame("Button","makethiswork",myF)
	
	myS:SetMovable(false)
	myS:SetScript("OnClick", MBOLIE )
	
	myS:SetWidth(50)
	myS:SetHeight(50)
	
	myS:SetFrameLevel("3")
	myS:ClearAllPoints()
	
	myS:SetBackdrop({bgFile = "Interface/Tooltips/UI-Tooltip-Background", edgeFile =  "Interface/Tooltips/UI-Tooltip-Border", edgeSize= 16, insets = { left = 0, right = 0, top = 0, bottom = 0 }}) 

	myS:SetPoint("CENTER", myF, "CENTER", 25, -25)
	
	
	myS.font = myS:CreateFontString(nil, "OVERLAY")
	myS.font:SetFontObject("GameFontNormal")
	myS.font:SetHeight(50)
	myS.font:SetWidth(50)
	myS.font:SetText("XXXXXXXXXXXXXXXXXXXX")
	--myS.font:SetPoint("TOPLEFT", lgame[id], "TOPLEFT")
	
	
	lgame.buttoninitialize()
end



--[[

id = tostring("b"..i)
title = tostring("lgame."..id)
lgame[id] = CreateFrame("Button", title, lgame.basic)
lgame[id]:SetMovable(false)
lgame[id]:SetScript("OnClick", lgame.click[id])
lgame[id]:SetWidth(50)
lgame[id]:SetHeight(50)
lgame[id]:SetFrameLevel("3")
lgame[id]:ClearAllPoints()
lgame[id]:SetBackdrop({bgFile = "Interface/Tooltips/UI-Tooltip-Background", edgeFile =  "Interface/Tooltips/UI-Tooltip-Border", edgeSize= 16, insets = { left = 0, right = 0, top = 0, bottom = 0 }}) 

lgame.buttonstatus[id] = "false"

lgame.fonts[id] = lgame[id]:CreateFontString(nil, "OVERLAY")
lgame.fonts[id]:SetFontObject("GameFontNormal")
lgame.fonts[id]:SetHeight(50)
lgame.fonts[id]:SetWidth(50)
lgame.fonts[id]:SetText("/")
lgame.fonts[id]:SetPoint("TOPLEFT", lgame[id], "TOPLEFT")



lgame.b1:SetPoint("BOTTOMLEFT", lgame.basic, "BOTTOMLEFT", 10, 110)

]]--


 
--lgame.click = {}
--lgame.fonts = {}



function buttoninitialize()

	for i = 7, 7 do
		id = tostring("b"..i)
		--title = tostring("lgame."..id)
		lgame = CreateFrame("Button", tostring("lgame."..id), myF)
		lgame:SetMovable(false)
		lgame:SetScript("OnClick", MBOLIE)
		lgame:SetWidth(50)
		lgame:SetHeight(50)
		lgame:SetFrameLevel("3")
		lgame:ClearAllPoints()
		lgame:SetBackdrop({bgFile = "Interface/Tooltips/UI-Tooltip-Background", edgeFile =  "Interface/Tooltips/UI-Tooltip-Border", edgeSize= 16, insets = { left = 0, right = 0, top = 0, bottom = 0 }}) 



		lgame.fonts = lgame:CreateFontString(nil, "OVERLAY")
		lgame.fonts:SetFontObject("GameFontNormal")
		lgame.fonts:SetHeight(50)
		lgame.fonts:SetWidth(50)
		lgame.fonts:SetText("/"..id)
		lgame.fonts:SetPoint("TOPLEFT", lgame[id], "TOPLEFT")
	end


	lgame:SetPoint("BOTTOMLEFT", myF, "BOTTOMLEFT", 10, 10)


	lgame:SetScript("OnClick", MBOLIE)

	lgame.texture = myT
end

