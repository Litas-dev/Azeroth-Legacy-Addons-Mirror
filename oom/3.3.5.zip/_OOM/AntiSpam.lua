-- UIErrorsFrame:AddMessage("msg",0,1,.5,1,2)
-- string.find( UnitDebuff("target",i),sDebuffName )
-- DEFAULT_CHAT_FRAME:AddMessage("woot!"   ,1/16,12/16,7/16)
-- DEFAULT_CHAT_FRAMEScrollToBottom()


AntiSpamFile = GetTime();




--[[
function UI_ERROR_MESSAGE(error)
		UIErrorsFrame:AddMessage(error, 1, .1, .1)
end
RegisterEvent("UI_ERROR_MESSAGE")
UIErrorsFrame:UnregisterEvent("UI_ERROR_MESSAGE")
]]--

local UIErrorsFrame_OnEvent = UIErrorsFrame:GetScript("OnEvent")
UIErrorsFrame:SetScript("OnEvent", function(self, event, error, ...)

	SI_lastError=event
	SI_lastMessage=message
	t_UIErrorsFrame_OnEvent = GetTime();

	if event ~= "UI_ERROR_MESSAGE" then
		UIErrorsFrame_OnEvent(self, event, error, ...)
		return
	end
	
	if xtimer(error.."UISPAM",9) then
		UIErrorsFrame_OnEvent(self, event, error, ...)
	else
		--echo( error ) 
	end
	
end)


--[[

SI_Old_UIErrorsFrame_OnEvent = UIErrorsFrame_OnEvent;

function SI_New_UIErrorsFrame_OnEvent(placeholder, event, message, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9)

	SI_lastError=event
	SI_lastMessage=message
	t_UIErrorsFrame_OnEvent = GetTime();

  
	if not event or not message or event~="UI_ERROR_MESSAGE" then
		SI_Old_UIErrorsFrame_OnEvent(placeholder, event, message, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9);
		return (nil)
	end

	
	--never show
	if message=="Not enough energy" then
	  return (message)
	
	--seldom
	elseif message=="Ability is not ready yet." then
	  if not xtimer(message,9) then return (message) end
    
  elseif message=="There is nothing to attack." then
	  if not xtimer(message,8) then return (message) end
    
  elseif message=="Invalid target" then
	  if not xtimer(message,8) then return (message) end
    
  elseif message=="You cannot attack that target." then
	  if not xtimer(message,8) then return (message) end
    
  elseif message=="Not enough rage" then
	  if not xtimer(message,8) then return (message) end
    
	--occationally
	elseif message=="Spell is not ready yet." then
	  if not xtimer(message,8) then return (message) end
		
	elseif message=="You can't do that yet" then
	  if not xtimer(message,8) then return (message) end
		
	elseif message=="Another action is in progress" then
	  if not xtimer(message,8) then return (message) end
		
	elseif message=="You have no target." then
	  if not xtimer(message,8/3) then return (message) end
    
  elseif message=="Target too close" then
	  if not xtimer(message,8/3) then return (message) end
    
  elseif message=="Can't do that while moving" then
	  if not xtimer(message,8/3) then return (message) end
		
	--frequently
	elseif message=="That is already being used." then
	  if not xtimer(message,1) then return (message) end
		
	elseif message=="Target not in line of sight" then
	  if not xtimer(message,1) then return (message) end
		
	elseif message=="Out of range." then
	  if not xtimer(message,1) then return (message) end
    
  elseif message=="Not enough mana" then
	  if not xtimer(message,1) then return (message) end
    
  --always show msg  
	elseif message=="Inventory is full." then
	  --nil
	elseif message=="Can only use outside" then
	  --nil  
	
	elseif message and not xtimer(message,0.3) then
	  SIM = message
    t_SIM = GetTime()
	  return (message)
    
  elseif d_AntiSpam then  --place # infront of messages that do not have specific timer
    message = "#"..message
		
	end
	

	SI_Old_UIErrorsFrame_OnEvent(placeholder, event, message, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9);
end

UIErrorsFrame_OnEvent = SI_New_UIErrorsFrame_OnEvent;

]]--

































Old_AntiSpamSendChatMessage = SendChatMessage;

function New_AntiSpamSendChatMessage(newmsg,chatType,language,channel)
	--UIErrorsFrame:AddMessage(newmsg)
	
	count = UpperCount(newmsg)
	
	if count>5 and count>strlen(newmsg)/3 then
	--	Old_AntiSpamSendChatMessage(strlower(newmsg),chatType,language,channel)
		UIErrorsFrame:AddMessage("CAPS LOCK")
	--	return
	end

	
	Old_AntiSpamSendChatMessage(newmsg,chatType,language,channel)
end

SendChatMessage = New_AntiSpamSendChatMessage;






function UpperCount(input)
	if type(input)~="string" then
		return -1
	end

	sum = 0;
	
	for i=1,strlen(input) do
		if strsub(input,i,i) ~= strlower( strsub(input,i,i) ) then
		  sum = sum + 1;
		end
	end

	return sum;
end














Old_ChatMsgChannelSpam = ChatFrame_MessageEventHandler;

function New_ChatMsgChannelSpam(self,event,...)
	arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9 = ...
	
	if ( not strfind(event,"CHAT_MSG_BN") and not strfind(event,"CHAT_MSG_TARGETICONS") and  not strfind(event,"GUILD") and not strfind(event,"CHAT_MSG_BG_SYSTEM") and not strfind(event,"_HONOR_") and event~="CHAT_MSG_OPENING" and event~="CHAT_MSG_MONEY" and event~="CHAT_MSG_COMBAT_XP_GAIN" and event~="CHAT_MSG_ACHIEVEMENT" and event~="CHAT_MSG_EMOTE" and event~="CHAT_MSG_SKILL" and not strfind(event,"MONSTER") and event~="CHAT_MSG_WHISPER_INFORM" and event~="CHAT_MSG_COMBAT_FACTION_CHANGE" and event~="CHAT_MSG_PET_INFO" and event~="CHAT_MSG_TRADESKILLS" and event~="CHAT_MSG_MONSTER_SAY" and event~="CHAT_MSG_MONSTER_YELL" and event~="CHAT_MSG_COMBAT_MISC_INFO" and event~="CHAT_MSG_RAID_BOSS_EMOTE" and event~="CHAT_MSG_RAID_BOSS_WHISPER" and event~="CHAT_MSG_MONSTER_EMOTE" and event~="CHAT_MSG_CHANNEL_NOTICE" and event~="CHAT_MSG_TEXT_EMOTE" and event~="CHAT_MSG_SYSTEM" and event~="UPDATE_FLOATING_CHAT_WINDOWS" and event~="CHAT_MSG_GUILD_ACHIEVEMENT" and event~="CHAT_MSG_LOOT" ) then
		if (  not strfind(event,"_BATTLEGROUND") and event~="CHAT_MSG_PARTY_LEADER" and event~="CHAT_MSG_RAID_WARNING" and event~="CHAT_MSG_SAY" and event~="CHAT_MSG_YELL" and event~="CHAT_MSG_GUILD" and event~="CHAT_MSG_RAID" and event~="CHAT_MSG_RAID_LEADER" and event~="CHAT_MSG_CHANNEL" and event~="CHAT_MSG_WHISPER" and event~="CHAT_MSG_PARTY" ) then
			dprint( delimitcat( ColorText(1,0,0).."_"..ColorText() ,self,event,...) )
		end
	end
  
	Old_ChatMsgChannelSpam(self,event,...)
end

ChatFrame_MessageEventHandler = New_ChatMsgChannelSpam;
