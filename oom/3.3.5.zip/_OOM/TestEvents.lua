TestR = {
	VERSION = 1
}





-- Initialize the variables
Eldest = {};
Eldest[GetRealmName()] = {};
Eldest[GetRealmName()][UnitName("player")] = {};








TestR_OnLoad = function ()
	testSpamGetTime=GetTime()
	testSpamTimer=0

	this:RegisterEvent("BAG_UPDATE");
	this:RegisterEvent("LOOT_CLOSED");
	this:RegisterEvent("LOOT_OPENED");
	this:RegisterEvent("LOOT_SLOT_CLEARED");
	this:RegisterEvent("START_LOOT_ROLL");

	this:RegisterEvent("TRADE_ACCEPT_UPDATE");
	this:RegisterEvent("PARTY_INVITE_REQUEST");

	this:RegisterEvent("UNIT_PVP_UPDATE");
--	this:RegisterEvent("UNIT_FACTION");
	this:RegisterEvent("UNIT_FLAGS");

	this:RegisterEvent("CHAT_MSG_WHISPER");
	this:RegisterEvent("CHAT_MSG_SAY");
	this:RegisterEvent("CHAT_MSG_PARTY");
	this:RegisterEvent("CHAT_MSG");
	this:RegisterEvent("CHAT_MSG_CHANNEL");

--	this:RegisterEvent("UNIT_HEALTH");
--	this:RegisterEvent("UNIT_MANA");
--	this:RegisterEvent("UNIT_RAGE");
--	this:RegisterEvent("UNIT_ENERGY");
--	this:RegisterEvent("UNIT_FOCUS");
--	this:RegisterEvent("UNIT_AURA");

	this:RegisterEvent("UI_INFO_MESSAGE");
	this:RegisterEvent("UI_ERROR_MESSAGE");
	this:RegisterEvent("MINIMAP_PING");

	this:RegisterEvent("SPELLS_CHANGED");
	this:RegisterEvent("SPELLCAST_CHANNEL_START");
	this:RegisterEvent("SPELLCAST_CHANNEL_UPDATE");
	this:RegisterEvent("SPELLCAST_CHANNEL_STOP");
	this:RegisterEvent("SPELLCAST_START");
	this:RegisterEvent("SPELLCAST_STOP");
	this:RegisterEvent("SPELLCAST_FAILED");
	this:RegisterEvent("SPELLCAST_INTERRUPTED");
	this:RegisterEvent("SPELLCAST_DELAYED");
--	this:RegisterEvent("SPELL_UPDATE_USABLE");
--	this:RegisterEvent("SPELL_UPDATE_COOLDOWN");

	this:RegisterEvent("PLAYER_TARGET_CHANGED");

	this:RegisterEvent("CHAT_MSG_BG_SYSTEM_ALLIANCE");
	this:RegisterEvent("CHAT_MSG_BG_SYSTEM_NEUTRAL");
	this:RegisterEvent("CHAT_MSG_BG_SYSTEM_HORDE");

	this:RegisterEvent("UPDATE_BATTLEFIELD_SCORE");
	this:RegisterEvent("UPDATE_BATTLEFIELD_STATUS");
	this:RegisterEvent("UPDATE_WORLD_STATES");

	this:RegisterEvent("RAID_ROSTER_UPDATE");
	this:RegisterEvent("CHAT_MSG_COMBAT_HOSTILE_DEATH");
	this:RegisterEvent("PLAYER_PVP_KILLS_CHANGED");



	this:RegisterEvent("CHAT_MSG_SPELL_CREATURE_VS_CREATURE_DAMAGE");
	this:RegisterEvent("CHAT_MSG_SPELL_CREATURE_VS_PARTY_DAMAGE");
	this:RegisterEvent("CHAT_MSG_SPELL_CREATURE_VS_SELF_DAMAGE");
	this:RegisterEvent("CHAT_MSG_SPELL_HOSTILEPLAYER_DAMAGE");
	this:RegisterEvent("CHAT_MSG_SPELL_PARTY_DAMAGE");
	this:RegisterEvent("CHAT_MSG_SPELL_PERIODIC_CREATURE_DAMAGE");
	this:RegisterEvent("CHAT_MSG_SPELL_PERIODIC_FRIENDLYPLAYER_DAMAGE");
	this:RegisterEvent("CHAT_MSG_SPELL_PERIODIC_HOSTILEPLAYER_DAMAGE");
	this:RegisterEvent("CHAT_MSG_SPELL_PERIODIC_SELF_DAMAGE");
	this:RegisterEvent("CHAT_MSG_SPELL_SELF_DAMAGE");
	this:RegisterEvent("CHAT_MSG_SPELL_SELF_DAMAGE");

	this:RegisterEvent("CHAT_MSG_SPELL_SELF_BUFF")
	this:RegisterEvent("CHAT_MSG_COMBAT_PET_HITS")
	this:RegisterEvent("CHAT_MSG_SPELL_PET_DAMAGE")

	this:RegisterEvent("UPDATE_MOUSEOVER_UNIT");

	this:RegisterEvent("CHAT_MSG_COMBAT_CREATURE_VS_PARTY_HITS");
	this:RegisterEvent("CHAT_MSG_COMBAT_CREATURE_VS_SELF_HITS");


--	this:RegisterEvent("");

--	this:RegisterEvent("QUEST_LOG_UPDATE");
--	this:RegisterEvent("PLAYTIME_CHANGED");
--	this:RegisterEvent("TIME_PLAYED_MSG");

--	this:RegisterEvent("CHAT_MSG_AFK");
--	this:RegisterEvent("CHAT_MSG_SYSTEM");
--	this:RegisterEvent("PLAYER_FLAGS_CHANGED");

--	this:RegisterEvent("MIRROR_TIMER_START");
--	this:RegisterEvent("MIRROR_TIMER_PAUSE");
--	this:RegisterEvent("MIRROR_TIMER_STOP");

--	this:RegisterEvent("PLAYTIME_CHANGED");
--	this:RegisterEvent("UNIT_DYNAMIC_FLAGS");
--	this:RegisterEvent("UNIT_FLAGS");
--	this:RegisterEvent("UNIT_MODEL_CHANGED");
--	this:RegisterEvent("UNIT_STATS");

--	this:RegisterEvent("SYSMSG");
--	this:RegisterEvent("RESURRECT_REQUEST");

--	this:RegisterEvent("QUEST_LOG_UPDATE");
--	this:RegisterEvent("QUEST_ITEM_UPDATE");

--	this:RegisterEvent("BAG_UPDATE_COOLDOWN");
--	this:RegisterEvent("CHARACTER_POINTS_CHANGED");

--	this:RegisterEvent("CHAT_MSG_LOOT");
--	this:RegisterEvent("CHAT_MSG_EMOTE");
--	this:RegisterEvent("CHAT_MSG_SAY");
--	this:RegisterEvent("CHAT_MSG_PARTY");
--	this:RegisterEvent("CHAT_MSG_SPELL_AURA_GONE_SELF");

--	this:RegisterEvent("CORPSE_IN_RANGE");
--	this:RegisterEvent("CURRENT_SPELL_CAST_CHANGED");
--	this:RegisterEvent("FRIENDLIST_UPDATE");
--	this:RegisterEvent("LOOT_OPENED");
--	this:RegisterEvent("MINIMAP_PING");
--	this:RegisterEvent("MINIMAP_UPDATE_ZOOM");
--	this:RegisterEvent("MINIMAP_ZONE_CHANGED");
--	this:RegisterEvent("PARTY_INVITE_CANCEL");
--	this:RegisterEvent("PET_ATTACK_START");
--	this:RegisterEvent("PET_ATTACK_STOP");
--	this:RegisterEvent("PLAYER_COMBO_POINTS");
--	this:RegisterEvent("PLAYER_DEAD");

--	this:RegisterEvent("PLAYER_ENTER_COMBAT");
--	this:RegisterEvent("PLAYER_REGEN_DISABLED");
--	this:RegisterEvent("PLAYER_REGEN_ENABLED");
--	this:RegisterEvent("PLAYER_TARGET_CHANGED");
--	this:RegisterEvent("PLAYER_UPDATE_RESTING");

--	this:RegisterEvent("PLAYER_XP_UPDATE");
--	this:RegisterEvent("PLAYTIME_CHANGED");
--	this:RegisterEvent("QUEST_ITEM_UPDATE");
--	this:RegisterEvent("RESURRECT_REQUEST");
--	this:RegisterEvent("START_LOOT_ROLL");

--	this:RegisterEvent("UNIT_ENERGY");
--	this:RegisterEvent("UNIT_FOCUS");
--	this:RegisterEvent("UNIT_MODEL_CHANGED");

--	this:RegisterEvent("UPDATE_MOUSEOVER_UNIT");
--	this:RegisterEvent("UPDATE_SHAPESHIFT_FORMS");
--	this:RegisterEvent("ZONE_CHANGED");
--	this:RegisterEvent("ZONE_CHANGED_INDOORS");


	SLASH_JOKE1 = "/joke";
	SlashCmdList["JOKE"] = TellJoke;


	SLASH_AUTOATTACKSETTING1 = "/autoattack";
	SlashCmdList["AUTOATTACKSETTING"] = AutoAttackSetting;



	SLASH_SELLGRAYITEMS1 = "/sellgrays";
  SLASH_SELLGRAYITEMS2 = "/sellgreys";
	SLASH_SELLGRAYITEMS3 = "/sgi";
	SlashCmdList["SELLGRAYITEMS"] = SellGrays;

	
	OOM_Test_LoadTime = GetTime()
end



function TellJoke(cmd)
  DoEmote("joke")
end



function AutoAttackSetting(cmd)
  ContinuousAssist=tonumber(cmd)
end












-----------------------------------------------------------------------------------------------------------------------

TestR_OnUpdate = function (arg1)

  if type(GCD_test)=="string" and SpellID(GCD_test)~=-1 then
    if type(oldGCD)~="number" then
      oldGCD = Cooldown(GCD_test)
    elseif Cooldown(GCD_test)>oldGCD then
      printcat( GCD_test , ' ' , Cooldown(GCD_test) )
      oldGCD = Cooldown(GCD_test)
    elseif Cooldown(GCD_test)<oldGCD then
      oldGCD = Cooldown(GCD_test)
    end
  end


  Baroness_Dorothea_Millstipe = FindUnitByName("Baroness Dorothea Millstipe")
  if Baroness_Dorothea_Millstipe then
    spell, rank, displayName, icon, startTime, endTime = UnitCastingInfo(Baroness_Dorothea_Millstipe)
    if spell=="Mana Burn" and xtimer("Baroness_Dorothea_Millstipe_Mana_Burn",5) then
      SendChatMessage("Baroness_Dorothea_Millstipe Mana_Burn","RAID_WARNING")
    end
  end

--[[
  if UnitClass("player")=="Priest" and Cooldown("Greater Heal")>=2 and Cooldown("Flash Heal")>=2 and Cooldown("Power Word: Shield")>=2 and Cooldown("Renew")>=2 and xtimer("PrimaryShutDown",2) then
    if abs( max(Cooldown("Greater Heal"),Cooldown("Flash Heal"),Cooldown("Renew")) - min(Cooldown("Greater Heal"),Cooldown("Flash Heal"),Cooldown("Renew")) )<0.1 and  GetNumPartyMembers()>0 and CanHeal() and UnitPowerType("player")==0 and xtimer("_120",12) then
      SendChatMessage("Your Priest's Healing spells have been Disabled!! <" .. ceil(max( Cooldown("Greater Heal"),Cooldown("Flash Heal"),Cooldown("Renew")) ) .. " seconds>" ,"Party",nil,nil)
    elseif GetNumPartyMembers()>0 and CanHeal() and UnitPowerType("player")==0 and xtimer("_120",12) then
      SendChatMessage("Your Priest's Healing spells have been Disabled!!","Party",nil,nil)
	DEFAULT_CHAT_FRAME:AddMessage(  min(Cooldown("Greater Heal"),Cooldown("Flash Heal"),Cooldown("Renew")) .. "   " .. max(Cooldown("Greater Heal"),Cooldown("Flash Heal"),Cooldown("Renew")) .. "      " .. abs( max(Cooldown("Greater Heal"),Cooldown("Flash Heal"),Cooldown("Renew")) - min(Cooldown("Greater Heal"),Cooldown("Flash Heal"),Cooldown("Renew")) )  )
    else
      DEFAULT_CHAT_FRAME:AddMessage( "Your Healing spells have been Disabled!! <" .. ceil(max( Cooldown("Greater Heal"),Cooldown("Flash Heal"),Cooldown("Renew")) ) .. " seconds>" )
    end
  end
]]--

--[[
  if UnitClass("player")=="Druid" and Cooldown("Healing Touch")>=2 and Cooldown("Regrowth")>=2 and Cooldown("Rejuvenation")>=2 and Cooldown("Tranquility")>=2 and xtimer("PrimaryShutDown",2) then
    if abs( max(Cooldown("Healing Touch"),Cooldown("Regrowth"),Cooldown("Rejuvenation")) - min(Cooldown("Healing Touch"),Cooldown("Regrowth"),Cooldown("Rejuvenation")) )<0.1 and  GetNumPartyMembers()>0 and CanHeal() and UnitPowerType("player")==0 and xtimer("_120",12) then
      SendChatMessage("Your Druid's Healing spells have been Disabled!! <" .. ceil(max(Cooldown("Healing Touch"),Cooldown("Regrowth"),Cooldown("Rejuvenation")) ) .. " seconds>" ,"Party",nil,nil)
    elseif nil and GetNumPartyMembers()>0 and CanHeal() and UnitPowerType("player")==0 and xtimer("_120",12) then
      SendChatMessage("Your Druid's Healing spells have been Disabled!!","Party",nil,nil)
	DEFAULT_CHAT_FRAME:AddMessage(  min(Cooldown("Greater Heal"),Cooldown("Flash Heal"),Cooldown("Renew")) .. "   " .. max(Cooldown("Greater Heal"),Cooldown("Flash Heal"),Cooldown("Renew")) .. "      " .. abs( max(Cooldown("Greater Heal"),Cooldown("Flash Heal"),Cooldown("Renew")) - min(Cooldown("Greater Heal"),Cooldown("Flash Heal"),Cooldown("Renew")) )  )
    else
      DEFAULT_CHAT_FRAME:AddMessage( "Your Healing spells have been Disabled!! <" .. ceil(max(Cooldown("Healing Touch"),Cooldown("Regrowth"),Cooldown("Rejuvenation")) ) .. " seconds>" )
    end
  end
]]--


--[[
  if UnitClass("player")=="Paladin" and Cooldown("Holy Light")>=2 and Cooldown("Flash of Light")>=2 and abs( max(Cooldown("Holy Light"),Cooldown("Flash of Light")) - min(Cooldown("Holy Light"),Cooldown("Flash of Light")) )<0.1 and UnitPowerType("player")==0 and xtimer("PrimaryShutDown",2) then
    if GetNumPartyMembers()>0 and xtimer("_120",12) then
      SendChatMessage("Paladins's Healing spells have been Disabled!! <" .. ceil(max(Cooldown("Holy Light"),Cooldown("Flash of Light")) ) .. " seconds>" ,"Party",nil,nil)
    else
      DEFAULT_CHAT_FRAME:AddMessage( "Your Healing spells have been Disabled!! <" .. ceil(max(Cooldown("Holy Light"),Cooldown("Flash of Light")) ) .. " seconds>" )
    end
  end
]]--


--[[
  -- abs( max(Cooldown("Lesser Healing Wave"),Cooldown("Healing Wave"),Cooldown("Chain Heal")) - min(Cooldown("Lesser Healing Wave"),Cooldown("Healing Wave"),Cooldown("Chain Heal")) ) <1 
  if UnitClass("player")=="Shaman" and Cooldown("Healing Wave")>1.6 and ( Cooldown("Lesser Healing Wave")>1.6 or Cooldown("Lesser Healing Wave")==-1 ) and ( Cooldown("Chain Heal")>1.6 or Cooldown("Chain Heal")==-1 ) and (true) and UnitPowerType("player")==0 and xtimer("PrimaryShutDown",2) then
    if GetNumPartyMembers()>0 and CanHeal() and xtimer("_120", ceil( max( Cooldown("Lesser Healing Wave"),Cooldown("Healing Wave"),Cooldown("Chain Heal"),8 ) )+2 ) then
      SendChatMessage("Your Shaman's Healing spells have been Disabled!! <" .. ceil( max(Cooldown("Lesser Healing Wave"),Cooldown("Healing Wave"),Cooldown("Chain Heal")) ) .. " seconds>" ,"Party",nil,nil)
    else
      DEFAULT_CHAT_FRAME:AddMessage( "Your Healing spells have been Disabled!! <" .. ceil( max(Cooldown("Lesser Healing Wave"),Cooldown("Healing Wave"),Cooldown("Chain Heal")) ) .. " seconds>" )
    end
  end
]]--













  if not BattleGround() then
    t_bg_rez=nil
    u_bg_rez=nil
  elseif UnitIsDeadOrGhost("player") and not t_bg_rez then
    t_bg_rez=GetTime()
  elseif not UnitIsDeadOrGhost("player") and t_bg_rez then
    if not u_bg_rez then u_bg_rez=0 end
    u_bg_rez=GetTime()-u_bg_rez
    echo("@"..GetTime() .. "      " .. u_bg_rez )
    t_bg_rez=nil
    u_bg_rez=GetTime()
  end







  if UnitIsVisible("party1") and UnitName("party1")=="Zinrael" and UnitIsVisible("pet") and not UnitExists("party2") then
    if UnitHealthMax("pet")-UnitHealth("pet")>2410 or UnitHealth("pet")/UnitHealthMax("pet")<0.50 then
      if UnitHealth("pet")>0 and xtimer("ZinraelHealPet",20) then
        SendChatMessage(" ZOMG ZINRAEL, MY PET NEEDS HEAL !" ,"PARTY")
      end
    end
  end
	
	
	
	
	
  ElcornMailCheck()
	
	
	
	
	
	
	
	
--  if xtimer("Eldest",20) then
--  	UpdateEldest()
    --[[
	if not haveListedEldest and GetTime()-OOM_Test_LoadTime>5 then
	  ListEldest()
	  haveListedEldest = GetTime()

  elseif GetTime()-OOM_Test_LoadTime>10 and not UnitAffectingCombat("player") and not BattleGround() and xtimer("UpdateSkillList",60*42) then
	  UpdateSkillSet()
    dprint("  Updating Skill Set")

	 
	end
	]]--
	
  
  t_TestROnUpdate = GetTime()
end

-----------------------------------------------------------------------------------------------------------------------



































--SkillListSet global saved 
--[[
function UpdateSkillSet()
  if not SkillListSet then
    SkillListSet = {}
  end
  if not SkillListSet[GetRealmName()] then
    SkillListSet[GetRealmName()] = {}
  end
  if not SkillListSet[GetRealmName()][UnitName("player")] then
    SkillListSet[GetRealmName()][UnitName("player")] = {}
  end
  
  local skillTable = {};
  
  ExpandSkillHeaders()
  
  for skillIndex = 1, GetNumSkillLines() do
    skillName, isHeader, isExpanded, skillRank, numTempPoints, skillModifier, skillMaxRank, isAbandonable, stepCost, rankCost, minLevel, skillCostType, skillDescription = GetSkillLineInfo(skillIndex)
    if isHeader == nil then
      if skillRank==1 and skillMaxRank==1 then
        --skip
      elseif strfind(skillName,"Language") then
        --skip
      else
        --DEFAULT_CHAT_FRAME:AddMessage(skillName .. " " .. skillRank .."/" .. skillMaxRank)
        skillTable[skillName] = skillRank .. " / " .. skillMaxRank
      end
    end
  end
  

  
  
  t_skilllistset = GetTime()
  SkillListSet[GetRealmName()][UnitName("player")] = skillTable
end
]]--






function echoSkills()
  for skillIndex = 1, GetNumSkillLines() do
    skillName, isHeader, isExpanded, skillRank, numTempPoints, skillModifier, skillMaxRank, isAbandonable, stepCost, rankCost, minLevel, skillCostType, skillDescription = GetSkillLineInfo(skillIndex)
    if isHeader == nil then
      DEFAULT_CHAT_FRAME:AddMessage("Skill: " .. skillName .. " - " .. skillRank)
      
    end
  end
end




function ExpandSkillHeaders()
  tempNum = GetNumSkillLines()
  for skillIndex = GetNumSkillLines(),1,-1 do
    ExpandSkillHeader(skillIndex)
  end
  if GetNumSkillLines()~=tempNum then
    dprint("Recursive!")
    ExpandSkillHeaders()
  end
end












function ElcornMailCheck()
  	if HasNewMail() ~= ElcornMail then
	  if GetTime()-OOM_Test_LoadTime > 1 then
		  if UnitName("player")=="Elcorn" and HasNewMail() and xtimer("ElcornLikesMail",60*60*4) then
			  DoEmote("Dance")
			  SendChatMessage("I've got mail!" ,"SAY")
			elseif HasNewMail() then
		    DEFAULT_CHAT_FRAME:AddMessage("You've got mail!")
			end
	  end
		ElcornMail = HasNewMail()
		t_Elcorn = GetTime()
	end
end

























--[[
function UpdateEldest()
	  if not Eldest then
		  Eldest = {}
		end
		if not Eldest[GetRealmName()] then
		  Eldest[GetRealmName()] = {}
		end
	  Eldest[GetRealmName()][UnitName("player")] = time()
end ]]--









-- also in _Banker/Banker.lua
function ListEldest()
  if not Eldest or not Eldest[GetRealmName()] then return end
	
	EldestSort = {}
	esID = 1
	
	for k2,v2 in pairs(Eldest) do
	  for k,v in pairs(Eldest[k2]) do
	    EldestSort[esID] = {}
			EldestSort[esID]["name"] = k
			EldestSort[esID]["server"] = k2
			EldestSort[esID]["value"] = v
			esID = esID+1
		end
	end
	
	table.sort(EldestSort , function (a,b) return (a["value"]>b["value"]) end)
	dprint("Listing Eldest" ,1,.5,0)
	
	  for k3,v3 in pairs(EldestSort) do
		  v = v3["value"]
			k = v3["name"]
			-- .. " " .. ColorText(0.5,0.5,0.5) .. v3["server"] .. ColorText()
			if v3["server"] == GetRealmName() then
			  k = k .. " " .. ColorText(0.5,0.5,0.5) .. v3["server"] .. ColorText()
			else
			  k = k .. " " .. ColorText(0.1,0.1,0.1) .. v3["server"] .. ColorText()
			end
          
			elderPrintString = "@!"
		  if (time()- v) > 60*60*24 *100 then
        --ignore, over 100 days old
      elseif (time()- v)>60*60*24 *8 then
			  elderPrintString = k .."  ".. round( (time()- v)/(60*60*24) ,-1) .. ColorText(1,0,0) .. " days"
		  elseif (time()- v)>60*60*24 *3 then
			  elderPrintString = k .."  ".. round( (time()- v)/(60*60*24) ,-1) .. ColorText(1,1,0) .. " days"
		  elseif (time()- v)>60*90 then
		      elderPrintString = k .."  ".. round( (time()- v)/(60*60) ,-1) .. ColorText(0,1,1) .. " hrs"
		  elseif (time()- v)>30 then
			  elderPrintString = k .."  ".. round( (time()- v)/(60) ,-1) .. ColorText(0,1,0) .. " mins"
		  else
			  elderPrintString = "@!!"
			end
		  
			if Inventory and Inventory[ v3["server"] ] and Inventory[ v3["server"] ][ v3["name"] ] and Inventory[ v3["server"] ][ v3["name"] ]["Mail"] then
		    eMailCount = Inventory[ v3["server"] ][ v3["name"] ]["Mail"]
			end
		  if eMailCount then
		    elderPrintString = elderPrintString .. ColorText() .. "    " .. eMailCount
		  end
			if elderPrintString and not strfind(elderPrintString,"@!") then
		    dprint( elderPrintString ) 
		  end
		end 
  --dprint("end of elder " ..GetTime())
end


--Inventory["Whisperwind"]["Xkq"]["Mail"]








function echoTable(nTable)
  if type(nTable)~="table" then
	  dprint("not a table" ,1/16,12/16,7/16)
    return
	else
	
    for key1,val1 in pairs(nTable) do
      if type(val1)=="table" then
        dprint("Sub Table:",0,0,1)
        echoTable(nTable[val1])
      else
			  if type(val1)=="boolean" and val1==true then
				  val1 = ColorText(0,0,1).."TRUE"
				elseif type(val1)=="boolean" and val1==false then
				val1 = ColorText(0,0,1).."FALSE"
				end
        dprint( "key: "..ColorText(1,0,0)..key1..ColorText().."   val: "..ColorText(0,1,0)..val1..ColorText() )
      end
    end
	
  end
end

EchoTable = echoTable




--[[
QueryQuestsCompleted()

local qlist = {}

GetQuestsCompleted(qlist)
for v,uk in pairs (qlist) do
  DEFAULT_CHAT_FRAME:AddMessage (v)
end 
]]--


function ListCompletedQuests(questID,echocomplete)
    local qlist = {}
    GetQuestsCompleted(qlist)
    
    if type(questID)=="number" then
        if qlist[questID] and echocomplete then
            DEFAULT_CHAT_FRAME:AddMessage(questID .. " Completed" ,1,1,0)
        elseif not qlist[questID] then
            DEFAULT_CHAT_FRAME:AddMessage(questID .. " Not Complete" ,1,0,0)
        end
    
    else
        for v,uk in pairs (qlist) do
            DEFAULT_CHAT_FRAME:AddMessage (v)
        end 
        
    end
end




















function Talk2Self()
  if not TalkSelf then TalkSelf=0 end
  if ( ( GetTime()-TalkSelf ) >120 ) then
    SendChatMessage(GetTime(),"WHISPER","Common",UnitName("player"));
    TalkSelf=GetTime()
    return true
  end
end







































-----------------------------------------------------------------------------------------------------------------------

TestR_OnEvent = function (arg1,arg2,arg3,arg3,arg4,arg5,arg6,arg7,arg8,arg9)
	recordEvent(event)
  if ( not de_lag ) then
		return
	end
	
  if ( event=="UI_ERROR_MESSAGE" ) then
    --Event_UIerror2(arg1)
  elseif event=="CHAT_MSG_SPELL_SELF_DAMAGE" and arg1 and string.find(arg1,"Gnomish Death Ray") then
    DEFAULT_CHAT_FRAME:AddMessage(arg1, 1,0,0)
  elseif event=="PLAYER_PVP_KILLS_CHANGED" and BattleGround() and nil then
    DoEmote("train")
  elseif arg1 and event=="CHAT_MSG_COMBAT_HOSTILE_DEATH" and BattleGround() and doTrainEmote then
    DoEmote("train")
  elseif arg1 and string.find(arg1,"lag was picked up by ") and event=="CHAT_MSG_BG_SYSTEM_ALLIANCE" then
    AllainceFlagCarrier=string.sub( arg1 , string.find( arg1 ,"lag was picked up by") + 21 , -2)
    DEFAULT_CHAT_FRAME:AddMessage("Flag Carrier:  " .. AllainceFlagCarrier)
  elseif arg1 and string.find(arg1,"lag was picked up by ") then
    HordeFlagCarrier=string.sub( arg1 , string.find( arg1 ,"lag was picked up by") + 21 , -2)
    DEFAULT_CHAT_FRAME:AddMessage("Flag Carrier:  " .. HordeFlagCarrier)

  elseif event=="TRADE_ACCEPT_UPDATE" and arg1 and arg2 then
    if arg2==1 and arg1==0 and GetPlayerTradeMoney()==0 and not GetTradePlayerItemInfo(1) and not GetTradePlayerItemInfo(2) and not GetTradePlayerItemInfo(3) and not GetTradePlayerItemInfo(4) and not GetTradePlayerItemInfo(5) and not GetTradePlayerItemInfo(6) and not GetTradePlayerItemInfo(7) and not GetTradeTargetItemInfo(7) then
      DEFAULT_CHAT_FRAME:AddMessage("Automatically Accepting Trade..." ,1,0,0)
      AcceptTrade()
    end
	--[[
  elseif event=="CHAT_MSG_WHISPER" and arg1 and string.find(arg1,"trade#") then
    if GetPlayerTradeMoney()==0 and not GetTradePlayerItemInfo(1) and not GetTradePlayerItemInfo(2) and not GetTradePlayerItemInfo(3) and not GetTradePlayerItemInfo(4) and not GetTradePlayerItemInfo(5) and not GetTradePlayerItemInfo(6) and not GetTradeTargetItemInfo(7) then
      AcceptTrade()
      DEFAULT_CHAT_FRAME:AddMessage("Accepting Trade..." ,1,0,0)
    end    ]]--
  elseif false and event=="START_LOOT_ROLL" and arg1 and ( UnitName("player")=="Kizrak" or UnitName("player")=="Xkq" or UnitName("player")=="Manabane" or UnitName("player")=="Rowyl" ) then
    l_texture, l_name, l_count, l_quality, l_pickup = GetLootRollItemInfo(arg1);
    if l_pickup and GetNumPartyMembers()>0 and GetNumRaidMembers()==0 then
      SendChatMessage(" <Binds on Pickup> " .. l_name ,"PARTY")
    end
  elseif event=="PLAYER_TARGET_CHANGED" and UnitExists("target") then
    Magic_UpdateTargetClassIcon()
  end
  if PlayerBuff("Ability_BullRush") and PlayerBuff("Racial_BearForm") and UnitHealth("player")>=UnitHealthMax("player") then
    RemoveBuff("Ability_BullRush")
  end




  ThisTestText:SetText( ColorText(random()*255,random()*255,random()*255)..floor(GetTime()) )




-- ***************************************************************************************************************
-- Find Events *** Find Events *** Find Events *** Find Events *** Find Events *** Find Events *** Find Events *** 
-- ***************************************************************************************************************




--[[
  mastereventstring="#"
  if arg1 then mastereventstring=mastereventstring .. arg1 end
  if arg2 then mastereventstring=mastereventstring .. arg2 end
  if arg3 then mastereventstring=mastereventstring .. arg3 end
  if arg4 then mastereventstring=mastereventstring .. arg4 end
  if arg5 then mastereventstring=mastereventstring .. arg5 end
  if arg6 then mastereventstring=mastereventstring .. arg6 end
  if arg7 then mastereventstring=mastereventstring .. arg7 end
  if arg8 then mastereventstring=mastereventstring .. arg8 end
  if arg9 then mastereventstring=mastereventstring .. arg9 end

  if nil and string.find(mastereventstring,"Totem") and string.find(mastereventstring," Fire damage.") and testSpamTimer<10 then
    DEFAULT_CHAT_FRAME:AddMessage(event)
    if debug_events then DEFAULT_CHAT_FRAME:AddMessage(mastereventstring) end
    testSpamTimer=testSpamTimer+1
  end
]]--










-- ***************************************************************************************************************

end

-----------------------------------------------------------------------------------------------------------------------







-- The Horde flag was picked up by <name>!
-- The Alliance Flag was picked up by <name>!

--  myString="The Alliance Flag was picked up by <name>!"  ;  DEFAULT_CHAT_FRAME:AddMessage( string.sub( myString , string.find(myString,"lag was picked up by") + 21 , -2) )







function BattleGroundKillCounter()
  if KBT and GetTime()-KBT>2 and BGKC and BGKillCount()~=BGKC then
    if BGKillCount()>0 then DEFAULT_CHAT_FRAME:AddMessage("Kill Count:  " .. BGKillCount()) end
    if BGKillCount()>BGKC then DoEmote("Train") end
    BGKC=BGKillCount()
  elseif not KBT or not BGKC then
    KBT=0
    BGKC=0
  end
end



















































function Event_UIerror2(arg1)
  if arg1=="You are already mounted! Dismount first." then
	  RemoveBuff("Nature_Swiftness")
	  RemoveBuff("Ability_Mount_")
  elseif arg1=="You are mounted" then
  	RemoveBuff("Nature_Swiftness")
  	RemoveBuff("Ability_Mount_")
  elseif arg1=="Can't attack while mounted." then
	  RemoveBuff("Nature_Swiftness")
	  RemoveBuff("Ability_Mount_")
  elseif arg1=="Can't do that while moving" then
	  return
  end
end

-- string.sub( "Can't do that while fleeing.", 2 , -2)

