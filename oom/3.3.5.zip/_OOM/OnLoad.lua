


function OOM_CallOnce()

	--fix default chat frame fading
	DEFAULT_CHAT_FRAME:SetFadeDuration(600)
	DEFAULT_CHAT_FRAME:SetTimeVisible(600)

	--combat frame? fading
	ChatFrame2:SetFadeDuration(600)
	ChatFrame2:SetTimeVisible(600)

	--chat frame fading
	ChatFrame3:SetFadeDuration(600)
	ChatFrame3:SetTimeVisible(600)

	--sets range for the combat log to 2000 yrs
	CombatLogRange2000()
	
	
	if AmAlan then
	  alan()
	end
	
	
	
	
	UpdateOOMFriends()
	
  dprint("OOM_CallOnce")
	de_lag=1
end





	--recorded variable
	OOM_Friends = {}

function UpdateOOMFriends()
	UnitNamePlayer = UnitName("player")
	
	dprint(UnitNamePlayer ,1,1,0)
	
	if not OOM_Friends then
		OOM_Friends = {}
	end
	if not OOM_Friends[UnitNamePlayer] then
		OOM_Friends[UnitNamePlayer] = {}
	end

	for friendIndex=0, GetNumFriends()+1 do
		local fname, level, class, area, connected, status, note = GetFriendInfo(friendIndex)

		--dprint(fname)
		if type(fname)=="string" then
		
			if type( OOM_Friends[UnitNamePlayer][fname] )~="number" then
				OOM_Friends[UnitNamePlayer][fname] = 1
		   else
				OOM_Friends[UnitNamePlayer][fname] = OOM_Friends[UnitNamePlayer][fname] + 1
			end
		
		end
		
	end

	--echoTable( OOM_Friends )
end

--[[
  if not SkillListSet then
    SkillListSet = {}
  end
  if not SkillListSet[GetRealmName()] then
    SkillListSet[GetRealmName()] = {}
  end
  if not SkillListSet[GetRealmName()][UnitName("player")] then
    SkillListSet[GetRealmName()][UnitName("player")] = {}
  end
]]--
