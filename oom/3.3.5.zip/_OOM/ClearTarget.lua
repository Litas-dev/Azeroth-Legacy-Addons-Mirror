--[[
   ClearTarget
       Clear's your target
   
   By: Xkq
   
   This allows you to clear your target with keybindings.
]]--












function CloseAll()
  if SpellIsTargeting() then
    SpellStopTargeting()
  else
    ClearTarget();
  end

  CloseAuctionHouse()
  CloseBankFrame()
  CloseBattlefield()
  CloseCraft()
  CloseGossip()
  CloseGuildRegistrar()
  CloseGuildRoster()
  CloseTabardCreation()
  CloseItemText()
  CloseLoot()
  CloseMail()
  CloseMerchant()
  ClosePetStables()
  ClosePetition()
  CloseQuest()
  CloseTaxiMap()
  CloseTradeSkill()
  CloseTrade()
  CloseTrainer()
  return
end





function ToggleChatLock()
  if (CHAT_LOCKED == "1") then
    FCF_Set_ChatLocked()
  else
    FCF_Set_ChatLocked(1)
  end

  if (CHAT_LOCKED == "1") then
    DEFAULT_CHAT_FRAME:AddMessage(" Chat Locked")
  else
    DEFAULT_CHAT_FRAME:AddMessage(" Chat Unlocked")
  end 
  return CHAT_LOCKED 
end