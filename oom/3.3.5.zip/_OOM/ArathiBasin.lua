-- UIErrorsFrame:AddMessage("msg",0,1,.5,1,2)
-- string.find(UnitDebuff("target",i),sDebuffName)
-- DEFAULT_CHAT_FRAME:AddMessage("woot!")
-- DEFAULT_CHAT_FRAMEScrollToBottom() 




ArathiBasin_OnLoad = function ()
  this:RegisterEvent("PLAYER_ENTER_COMBAT")
end











ArathiBasin_OnEvent = function (arg1,arg2,arg3,arg3,arg4,arg5,arg6,arg7,arg8,arg9)
  if event~="PLAYER_ENTER_COMBAT" then return event end
  if not BattleGround() then return BattleGround() end
  if not GetMinimapZoneText() then return GetMinimapZoneText() end

  --Minimap Zone Text
  MMZT = GetMinimapZoneText()
  WO = WhoOwns(MMZT)

  if ( BattleGround()==20 or BattleGround()==61 ) and event=="PLAYER_ENTER_COMBAT" and WO=="Horde Controlled" and xtimer("AB_BG_Msg",40) and xtimer("AB_BG_Msg"..MMZT,50) then
    SendChatMessage(" Addon: "..MMZT.." has entered combat.","BattleGround")
    -- Warn BattleGround
    
  elseif event=="PLAYER_ENTER_COMBAT" and WO=="Horde Controlled" then
    DEFAULT_CHAT_FRAME:AddMessage("     Addon: "..MMZT.." has entered combat." ,0,1,1)

  elseif event=="PLAYER_ENTER_COMBAT" and WO then
    DEFAULT_CHAT_FRAME:AddMessage(MMZT .. " is " .. WO .. "##")

  elseif event=="PLAYER_ENTER_COMBAT" then
    DEFAULT_CHAT_FRAME:AddMessage(MMZT .." is not a landmark @@")

  else
    DEFAULT_CHAT_FRAME:AddMessage("you are not in combat ??? "  ..event ,1/2,0,1)
  end

  t_ArathiBasinOnEvent = GetTime()
end








function WhoOwns(landmark)
  if not landmark then return landmark end

  for landmarkIndex=0,GetNumMapLandmarks()+1 do
    name, description, textureIndex, x, y = GetMapLandmarkInfo(landmarkIndex);
    if name==landmark then return (description) end
  end
  return (nil)
end






function ListLandmarks()
  for landmarkIndex=0,GetNumMapLandmarks()+1 do
    name, description, textureIndex, x, y = GetMapLandmarkInfo(landmarkIndex);
    if name and description then
      echo(name.." - "..description)
    end
  end
end