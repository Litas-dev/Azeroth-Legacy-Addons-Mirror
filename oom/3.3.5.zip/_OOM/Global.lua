-- DEFAULT_CHAT_FRAME:AddMessage(text,r,g,b)



--[[
function Wand()
  if UnitExists("target") and ( string.find(UnitName("target"),"Ward") or string.find(UnitName("target"),"Totem") ) and UnitIsVisible("target") and not UnitIsDeadOrGhost("target") and UnitHealth("target") then
    --nil
  else
    AssistIfNeed() AssistDouble() AssistNear()
  end

  if UnitExists("target") and UnitAffectingCombat("target") and UnitIsVisible("targettarget") and UnitHealth("target")/UnitHealthMax("target")<1 and UnitCanAttack("player","target") and UnitCanAttack("target","player") and not AnyAction() then
    CastSpellByName("Shoot")
    if not UnitIsPlayer("target") then SetRaidTarget("target",4) end
  end
end
]]--






























function OurFlagIsLeaving(method)
  if not method then
    DEFAULT_CHAT_FRAME:AddMessage("Need to indicate method.",0,0,0)
    return
  elseif ( not y_Warn ) or ( y_Warn and GetTime()-y_Warn >18 ) or ( method~=y_Last and y_Warn and GetTime()-y_Warn >8 ) then
    SendChatMessage("Our flag is leaving by " .. strupper(method) .. " !!" ,"RAID_WARNING",nil,nil)
    y_Last=method
    y_Raid=GetTime()
    y_Warn=GetTime()
  elseif ( not y_Raid ) or ( y_Raid and GetTime()-y_Raid >3 ) or ( method~=y_Last and y_Raid and GetTime()-y_Raid >0.5 ) then
    SendChatMessage("Our flag is leaving by " .. strupper(method) .. " !!" ,"RAID",nil,nil)
    y_Last=method
    y_Raid=GetTime()
    if y_Warn and GetTime()-y_Warn <4 then y_Warn=GetTime()-4 end
  end
end


























































































--[[

function Mongoose()
for i=1,300 do
	if GetActionTexture(i) and (string.find(GetActionTexture(i),"Hunter_SwiftStrike")) and IsUsableAction(i) and Cooldown("Mongoose Bite")==0 then
		CastSpellByName("Mongoose Bite")
		return true
	end
end
return nil
end

]]--

































function echoZone()
local pvpType, factionName, isArena = GetZonePVPInfo()
if not isArena then isArena="false" end
if not factionName then factionName="false" end
if not pvpType then pvpType="false" end
echo("--------------------")
echo("RealZone: " .. GetRealZoneText())
echo("Zone: " .. GetZoneText())
echo("Minimap: " .. GetMinimapZoneText())
echo("SubZone: " .. GetSubZoneText())
echo("Pvp: " .. pvpType .. "  " .. factionName .. "  " .. isArena)
return GetRealZoneText() .. " " .. GetZoneText() .. " " .. GetMinimapZoneText() .. " " .. GetSubZoneText() .. " " .. pvpType .. " " .. factionName .. " " .. isArena
end
























--  /targetinfo

function EchoTargetInfo()
if not UnitExists("target") then return nil end

distanceString="Target is within Interaction Distances: "
if CheckInteractDistance("target",1) then distanceString=distanceString .. " 1" end
if CheckInteractDistance("target",2) then distanceString=distanceString .. " 2" end
if CheckInteractDistance("target",3) then distanceString=distanceString .. " 3" end
if CheckInteractDistance("target",4) then distanceString=distanceString .. " 4" end

DEFAULT_CHAT_FRAME:AddMessage(" ")
DEFAULT_CHAT_FRAME:AddMessage("-----" .. UnitName("target") .. "-----" , 250/255, 200/255, 10/255)
if UnitAffectingCombat("target") then 			DEFAULT_CHAT_FRAME:AddMessage("Target is in combat.") end
if UnitClassification("target") then 			DEFAULT_CHAT_FRAME:AddMessage("Unit Classification: " .. UnitClassification("target")) end
if UnitIsCharmed("target") then 				DEFAULT_CHAT_FRAME:AddMessage("Target is Charmed.") end
if UnitIsConnected("target") then 				DEFAULT_CHAT_FRAME:AddMessage("Target is Connected") end
--if UnitIsCivilian("target") then 				DEFAULT_CHAT_FRAME:AddMessage("Target is Civilian") end
if UnitIsTapped("target") then 				DEFAULT_CHAT_FRAME:AddMessage("Target is Tapped") end

if UnitIsDead("target") then					DEFAULT_CHAT_FRAME:AddMessage("Target is Dead") end
if UnitIsDeadOrGhost("target") then				DEFAULT_CHAT_FRAME:AddMessage("Target is Dead or Ghost") end
if UnitIsGhost("target") then					DEFAULT_CHAT_FRAME:AddMessage("Target is Ghost") end

if UnitFactionGroup("target") then				DEFAULT_CHAT_FRAME:AddMessage("Target belongs to the faction group " .. UnitFactionGroup("target") , 250/255, 50/255, 0/255) end
if UnitIsPVP("target") then 					DEFAULT_CHAT_FRAME:AddMessage("Target is PVP.") end
if UnitCharacterPoints("target") then 			DEFAULT_CHAT_FRAME:AddMessage("Target Talent Points: " .. UnitCharacterPoints("target") ) end

if UnitIsEnemy("target","player") then 			DEFAULT_CHAT_FRAME:AddMessage("Unit is Enemy." ,0.9,0.9,0.9) end
if UnitIsFriend("target","player") then 			DEFAULT_CHAT_FRAME:AddMessage("Unit is Friend." ,0.9,0.9,0.9) end
if UnitCanAttack("target","player") then 			DEFAULT_CHAT_FRAME:AddMessage("Target can attack You." ,0.9,0.9,0.9) end
if UnitCanAttack("player","target") then 			DEFAULT_CHAT_FRAME:AddMessage("You can attack Target." ,0.9,0.9,0.9) end
if UnitCanAssist("target","player") then 			DEFAULT_CHAT_FRAME:AddMessage("Unit can Assist You." ,0.9,0.9,0.9) end
if UnitCanAssist("player","target") then 			DEFAULT_CHAT_FRAME:AddMessage("You can Assist Target." ,0.9,0.9,0.9) end
if UnitCanCooperate("target","player") then 		DEFAULT_CHAT_FRAME:AddMessage("Unit can Cooperate with You." ,0.9,0.9,0.9) end
if UnitCanCooperate("player","target") then 		DEFAULT_CHAT_FRAME:AddMessage("You can Cooperate with Target." ,0.9,0.9,0.9) end

if UnitIsPlayer("target") then 				DEFAULT_CHAT_FRAME:AddMessage("Target is Player.") end
if UnitIsPlusMob("target") then 				DEFAULT_CHAT_FRAME:AddMessage("Target is Plus Mob.") end
if UnitIsVisible("target") then 				DEFAULT_CHAT_FRAME:AddMessage("Target is Visible.") end
if UnitLevel("target") then 					DEFAULT_CHAT_FRAME:AddMessage("Target is level " .. UnitLevel("target")) end
if UnitClass("target") then 					DEFAULT_CHAT_FRAME:AddMessage("Target class is " .. UnitClass("target")) end
if UnitPlayerControlled("target") then 			DEFAULT_CHAT_FRAME:AddMessage("Target is controlled by a player.") end

if UnitRace("target") then	 				DEFAULT_CHAT_FRAME:AddMessage("Unit Race: " .. UnitRace("target") , 50/255, 100/255, 200/255) end
if UnitCreatureType("target") then 				DEFAULT_CHAT_FRAME:AddMessage("Unit Creature Type: " .. UnitCreatureType("target") , 50/255, 100/255, 200/255) end
if UnitCreatureFamily("target") then 			DEFAULT_CHAT_FRAME:AddMessage("Unit Creature Family: " .. UnitCreatureFamily("target") , 50/255, 100/255, 200/255) end

if UnitPowerType("target") then 				DEFAULT_CHAT_FRAME:AddMessage("Target uses " .. UnitPowerType("target") .. " type power.") end
if UnitReaction("target","player") then 			DEFAULT_CHAT_FRAME:AddMessage("Target has a " .. UnitReaction("target","player") .. " reaction to you.") end
if UnitAttackSpeed("target") then 				DEFAULT_CHAT_FRAME:AddMessage("Unit Attack Speed: " .. UnitAttackSpeed("target")) end
if UnitAttackPower("target") then 				DEFAULT_CHAT_FRAME:AddMessage("Unit Attack Power: " .. UnitAttackPower("target")) end
if UnitDefense("target") then 				DEFAULT_CHAT_FRAME:AddMessage("Unit Defense: " .. UnitDefense("target")) end
if UnitArmor("target") then 					DEFAULT_CHAT_FRAME:AddMessage("Unit Armor: " .. UnitArmor("target")) end
									DEFAULT_CHAT_FRAME:AddMessage( distanceString , 0/255, 200/255, 10/255)
end































function TalentSpec()
  talentspec=""
  talentcount=0

  for i=1,3 do
    name, iconTexture, pointsSpent, background = GetTalentTabInfo(i)
    if pointsSpent > talentcount and pointsSpent >10 then
      talentcount=pointsSpent
      talentspec=name
    end
  end
  return talentspec
end







function LFG()
  for c=1,9 do
    _, channelName=GetChannelName(c)
    if ( GetChannelName(c) and channelName and string.find(channelName,"LookingForGroup") ) then
      lfgChannel=c
    end
  end

  if not lfgTimer then lfgTimer=0 end
  if lfgTimer and GetTime()-lfgTimer >15 and lfgChannel then
    pClass=UnitClass("player")
    if UnitClass("player")=="Warrior" and TalentSpec()=="Protection" then pClass="Tank" end
    SendChatMessage("Level " .. UnitLevel("player") .. " " .. pClass .. " Looking for Group!  PST" ,"CHANNEL","Common",lfgChannel)
    lfgTimer=GetTime()
    LFGautoTimer=GetTime()
    return GetTime()
  end
  return
end

























--[[



-- Timer number , time between true returns (in seconds)
	xtime = {}
	xvarname = {}

function xtimer(tnum,ctime)
  if not xtimeset then
    xtime = {}
    xvarname = {}
    xtimeset=true
  end

  if type(tnum)=="string" then
    tnum=addx(tnum)
  elseif type(tnum)=="number" then
    xvarname[tnum]=tnum
  end

  if tnum and not xtime[tnum] then
    xtime[tnum]=GetTime()
    return -1
  end

  if not ctime or type(ctime)~="number" then
    echo(tnum .. "does not have numerical time value")
    return -2
  end

  if ( tnum and GetTime()-xtime[tnum] > ctime ) then
    local xtimer_return_value=GetTime()-xtime[tnum]
    xtime[tnum]=GetTime()
    return xtimer_return_value
  end
  return
end







xtimermaxindex=6

function addx(tnum)
  if not( type(tnum)=="string" ) then return end
  for xindex=1,xtimermaxindex do
    if xvarname[xindex] and xvarname[xindex]==tnum then
--    DEFAULT_CHAT_FRAME:AddMessage(xindex .. " found " .. xvarname[xindex] )
      return xindex
    elseif xvarname[xindex] then
      --nil
    else
      xvarname[xindex]=tnum
--    DEFAULT_CHAT_FRAME:AddMessage(xindex .. " made " .. xvarname[xindex] )
      return xindex
    end
  end

   xtimermaxindex=xtimermaxindex+1
-- DEFAULT_CHAT_FRAME:AddMessage("xtimer maxindex increased. " .. xtimermaxindex)

   xvarname[xtimermaxindex]=tnum
-- DEFAULT_CHAT_FRAME:AddMessage(xtimermaxindex .. " made " .. xvarname[xtimermaxindex] )
   return xindex
end



]]--
























--[[

function InviteBG()
  RequestBattlefieldScoreData()
  RequestBattlefieldPositions()
  if UnitRace("Player")=="Undead" or UnitRace("Player")=="Orc" or UnitRace("Player")=="Tauren" or UnitRace("Player")=="Troll" then
    MyFaction=0
  else
    MyFaction=1
  end
  RequestBattlefieldScoreData()
  for bgi=1,20 do
    local name, killingBlows, honorKills, deaths, honorGained, faction, rank, race, class = GetBattlefieldScore(bgi)
    if name and faction and faction==MyFaction and not InRaid(name) and CanInvite() then
--    DEFAULT_CHAT_FRAME:AddMessage(name .. faction)
      InviteByName(name)
    end
  end
end

]]--



























function CountMissingRaidBuffs(sBuffName,tBuffName,uBuffName)
  missingbuffs=0
  if not sBuffName then sBuffName="%NILL" end
  if not tBuffName then tBuffName="%NILL" end
  if not uBuffName then uBuffName="%NILL" end

  for j=1,40 do
    local buffCount = 0;
    for i=0,30 do
      if UnitBuff("raid" .. j,i) and ( string.find(UnitBuff("raid" .. j,i),sBuffName) or string.find(UnitBuff("raid" .. j,i),tBuffName) or string.find(UnitBuff("raid" .. j,i),uBuffName) ) then
        buffCount=buffCount+1
      end
    end
    if buffCount==0 and UnitExists("raid" .. j) and UnitIsVisible("raid" .. j) and UnitHealth("raid" .. j)>0 then missingbuffs=missingbuffs+1 end
  end
  
--  DEFAULT_CHAT_FRAME:AddMessage(missingbuffs)
  return missingbuffs
end








function CountMissingGroupBuffs(sBuffName)
  missingbuffs=0

    local buffCount = 0;
    for i=0,30 do
      if UnitBuff("player",i) and (string.find(UnitBuff("player",i),sBuffName)) then
        buffCount=buffCount+1
      end
    end
    if buffCount==0 and UnitExists("player") then missingbuffs=missingbuffs+1 end

  for j=1,5 do
    local buffCount = 0;
    for i=0,30 do
      if UnitBuff("party" .. j,i) and (string.find(UnitBuff("party" .. j,i),sBuffName)) then
        buffCount=buffCount+1
      end
    end
    if buffCount==0 and UnitExists("party" .. j) and UnitIsVisible("party" .. j) then missingbuffs=missingbuffs+1 end
  end
  
--  DEFAULT_CHAT_FRAME:AddMessage(missingbuffs)
  return missingbuffs
end





































--- MI2_Target.curHealth
--- MI2_Target.maxHealth 

-----------------------------------------------------------------------------------------------------------
-- REQUIRES MOBINFO2 !!
-----------------------------------------------------------------------------------------------------------

function RawHealth(unittype)
  if MI2_Target.maxHealth then
    return MI2_Target.maxHealth 
  else
    return 9999999999999999999999999999999
  end
end


function RawCurrent(unittype)
  if MI2_Target.curHealth then
    return MI2_Target.curHealth
  else
    return 9999999999999999999999999999999
  end
end







--[[
function RawHealth(unittype)
  if (not UnitExists(unittype)) or (not IsAddOnLoaded("MobInfo2")) or (not UnitIsVisible(unittype)) then return end
  mobData = MI2_GetMobData( UnitName(unittype) , UnitLevel(unittype) )
  return mobData.healthMax
end


function RawCurrent(unittype)
  if (not UnitExists(unittype)) or (not IsAddOnLoaded("MobInfo2")) or (not UnitIsVisible(unittype)) then return end
  mobData = MI2_GetMobData( UnitName(unittype) , UnitLevel(unittype) )
  return mobData.healthMax *(UnitHealth(unittype)/UnitHealthMax(unittype))
end
]]--

























function CanHeal()
  if UnitPowerType("player")~=0 then
    return nil
  elseif PlayerBuff("Shadowform")>0 then
    return nil
  elseif UnitClass("player")=="Priest" then
    return 1
  elseif UnitClass("player")=="Druid"  then
    return 2
  elseif UnitClass("player")=="Shaman" then
    return 3
  end
    return nil
end



































function GroupAndPetCondition(sType)
  local count_conditions = 0

    if CountCondition("player",sType) then
      count_conditions = count_conditions + CountCondition("player",sType)
    end

  for index_cc=1,4 do
    if UnitIsVisible("party"..index_cc) and CountCondition("party"..index_cc,sType) then
      count_conditions = count_conditions + CountCondition("party"..index_cc,sType) 
    end
  end

  for index_cc=1,4 do
    if UnitIsVisible("partypet"..index_cc) and CountCondition("partypet"..index_cc,sType) then
      count_conditions = count_conditions + CountCondition("partypet"..index_cc,sType) 
    end
  end

    if UnitIsVisible("pet") and CountCondition("pet",sType) then
      count_conditions = count_conditions + CountCondition("pet",sType)
    end

  return count_conditions
end






















function DisbandRaid()
  if xtimer("destoryraid",6) then
    DEFAULT_CHAT_FRAME:AddMessage("Repeat this command again within 6 seconds to completely disband all members from the raid.")
    return GetTime()
  end
  for i=1,40 do
    if UnitName("raid"..i)~=UnitName("player") then
      UninviteUnit("raid"..i)
    end
  end
  return
end



































--[[

-----------------------------------------------------------------------------------------------------------
-- ShortCuts
-----------------------------------------------------------------------------------------------------------

-- Cast Spell
function Cast(spellname)
  CastSpellByName(spellname)
end

-- Cast Spell
function C(spellname)
  CastSpellByName(spellname)
end

-- Cast Spell
function c(spellname)
  CastSpellByName(spellname)
end

-- Player Hitpoints Missing
function PHM()
  return (UnitHealthMax("player")-UnitHealth("player"))
end

-- Player Mana Missing
function PMM()
  return (UnitManaMax("player")-UnitMana("player"))
end

-- Player Percent Hitpoints
function PPH()
  return ( UnitHealth("player")/UnitHealthMax("player")*100 )
end

-- Player Percent Mana
function PPM()
  return ( UnitMana("player")/UnitManaMax("player")*100 )
end

-- Use Item By Name
function UCIBN(itemstring)
  return UseContainerItemByName(itemstring)
end

-- Is in Combat
function UAC(unittype)
  return UnitAffectingCombat(unittype)
end

-- Player Mana
function PM()
  return UnitMana("player")
end

-- Player Hitpoints
function PH()
  return UnitHealth("player")
end

-- Target Percent Hitpoints
function TPH()
  return ( UnitHealth("target")/UnitHealthMax("target")*100 )
end

-- Target Percent Mana
function TPM()
  return ( UnitMana("target")/UnitManaMax("target")*100 )
end

-- Free Bag Slots
function FBS()
  return FREEBAGSLOTS()
end

-- Player Buff
function PB(buffname)
  return PlayerBuff(buffname)
end

-- Target Debuff
function TDB(debuffName)
  return TargetDebuff(debuffName)
end

-- Spell cool down
function CD(CspellName)
  return Cooldown(CspellName)
end

]]--