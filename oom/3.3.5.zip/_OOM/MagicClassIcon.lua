
function Magic_UpdateTargetClassIcon()
  if UnitClass("target")=="Warrior" and UnitPowerType("target")==1 and not UnitIsPlayer("target") then
    TargetFrameClassIcon:Hide();
    return
  elseif UnitClass("target")=="Paladin" and UnitPowerType("target")==0 and not UnitIsPlayer("target") then
    TargetFrameClassIcon:Hide();
    return
  elseif not UnitClass("target") then
    TargetFrameClassIcon:Hide();
    return
  end
  local localizedClass, englishClass = UnitClass("target");
  if (not TargetFrameClassIcon:IsVisible()) then
    TargetFrameClassIcon:Show();
  end
  TargetFrameClassIconTexture:SetTexture("Interface\\AddOns\\_OOM\\Skin\\ClassIcons\\" .. localizedClass );
end




function Magic_UpdatePlayerClassIcon()
 --[[
  local localizedClass, englishClass = UnitClass("player");
  if (not PlayerFrameClassIcon:IsVisible()) then
    PlayerFrameClassIcon:Show();
  end
  PlayerFrameClassIconTexture:SetTexture("Interface\\AddOns\\_OOM\\Skin\\ClassIcons\\" .. localizedClass );
  PlayerFrameClassIcon:SetFrameStrata("HIGH")
  ]]--
end