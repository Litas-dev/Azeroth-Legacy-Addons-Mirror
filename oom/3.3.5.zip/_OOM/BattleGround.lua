-- UIErrorsFrame:AddMessage("msg",0,1,.5,1,2)
-- (string.find(UnitDebuff("target",i),sDebuffName)) 
-- DEFAULT_CHAT_FRAME:AddMessage("woot!")




BattleGround_OnLoad = function ()

end




BattleGround_OnEvent = function (arg1,arg2,arg3,arg3,arg4,arg5,arg6,arg7,arg8,arg9)
  if event=="CHAT_MSG_BG_SYSTEM_ALLIANCE" and arg1 and string.find(arg1,"lag was picked up by ") then
    AllainceFlagCarrier=string.sub( arg1 , string.find( arg1 ,"lag was picked up by") + 21 , -2)
    DEFAULT_CHAT_FRAME:AddMessage("Flag Carrier:  " .. AllainceFlagCarrier)
  elseif arg1 and type(arg1)=="string" and string.find(arg1,"lag was picked up by ") then
    HordeFlagCarrier=string.sub( arg1 , string.find( arg1 ,"lag was picked up by") + 21 , -2)
    DEFAULT_CHAT_FRAME:AddMessage("Flag Carrier:  " .. HordeFlagCarrier)
  end
end









-- The Horde flag was picked up by <name>!
-- The Alliance Flag was picked up by <name>!

--  myString="The Alliance Flag was picked up by <name>!"  ;  DEFAULT_CHAT_FRAME:AddMessage( string.sub( myString , string.find(myString,"lag was picked up by") + 21 , -2) )












function BattleGround()
  local e_zone = GetRealZoneText() .. GetZoneText() .. GetMinimapZoneText() .. GetSubZoneText()
  if string.find(e_zone,"Warsong Gulch") then
    return 10
  elseif string.find(e_zone,"Arathi Basin") then
    return 20
  elseif string.find(e_zone,"Alterac Valley") then
    return 51
	elseif string.find(e_zone,"Eye of the Storm") then
    return 61
  elseif string.find(e_zone,"Strand of the Ancients") then
    return 71
  elseif string.find(e_zone,"Wintergrasp") then
    return 80
  else
    return
  end
end


