-- UIErrorsFrame:AddMessage("msg",0,1,.5,1,2)
-- string.find(UnitDebuff("target",i),sDebuffName)
-- DEFAULT_CHAT_FRAME:AddMessage("woot!")






function Secure_OnLoad()
   secureLoadTime = GetTime();
	 t_JkeySet = GetTime()
	 
	 J_Key_Macro_Text = "/echo GetTime()-"..GetTime()
end







function Secure_OnEvent(arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9)

end



















function mySecureButtonSetAttribute(arg1,arg2)
  J_Key_Macro_Text = arg2
	--mySecureButton:SetAttribute(arg1,arg2) 
end 










































































-----------------------------------------------------------------------------------------------------------------------

function Secure_OnUpdate()
  if UnitAffectingCombat("player") then
	  t_combat = GetTime()
		return nil
	end
	
  if t_SecureOnUpdate and GetTime()-t_SecureOnUpdate < 1 then return end	
  if not secureLoadTime or GetTime() - secureLoadTime < 2 then return end	
  if not t_JkeySet or GetTime()-t_JkeySet < 3 then return end

  if not firstSecureLoad and not UnitAffectingCombat("player") then
    mySecureButton:SetAttribute("type1", "macro")
    mySecureButton:SetAttribute("macrotext", "/echo "..GetTime() )
    SetBindingClick("J","mySecureButton")

    SetBindingClick("ALT-CTRL-SHIFT-=", "TAUNT")

    DEFAULT_CHAT_FRAME:AddMessage("Secure!")
    firstSecureLoad = GetTime()
    return
  end

  

  
  
	
--[[
  -- Brew Feast
  if PlayerBuff("Ability_Mount_MountainRam") >0 then

    if PlayerBuff("INV_Misc_Gem_Pearl_05") >0 then
      mySecureButtonSetAttribute("macrotext", " ")
    elseif PlayerBuff("INV_Misc_Gem_Pearl_04") >0 then
      mySecureButtonSetAttribute("macrotext", " ")
    elseif BrewRam()<85 and PlayerBuff("INV_Misc_Gem_Pearl_0")==0 then
      mySecureButtonSetAttribute("macrotext", "/use Ram Racing Reins")
    elseif BrewRam()>60 then
      mySecureButtonSetAttribute("macrotext", " ")
    else
      mySecureButtonSetAttribute("macrotext", "/use Ram Racing Reins")
    end
		
  end
]]--



	
	

	--Combat
  if UnitAffectingCombat("player") then
--		return nil



	elseif PlayerBuff("Drink")>1 and t_mageDrink and GetTime()-t_mageDrink<18 and PlayerMana()<100 then
    mySecureButtonSetAttribute("macrotext", "/echo Drinking  " .. GetTime()-t_mageDrink )		
		
	--Drink Water
	elseif PlayerBuff("Drink")<1 and ( not t_mageDrink or GetTime()-t_mageDrink>15 ) and not UnitAffectingCombat("player") and ( ( MageWaterCount()>60 and PlayerMana()<4 ) or ( MageWaterCount()>10 and PlayerMana()<40 and UnitClass("player")=="Mage" ) ) and not PlayerMoving() and UnitPowerType("player")==0 then
    mySecureButtonSetAttribute("macrotext", "/use "..CurrentMageWater() .. "\n/script t_mageDrink=GetTime()" )

	--Conjure Mage water/food
	elseif not UnitAffectingCombat("player") and UnitClass("player")=="Mage" and MageWaterCount()<20 and FREEBAGSLOTS()>3 and not PlayerMoving() and Cooldown("Conjure Refreshment")==0 then	
    mySecureButtonSetAttribute("macrotext", "/cast [nocombat] Conjure Refreshment")
  elseif not UnitAffectingCombat("player") and UnitClass("player")=="Mage" and MageWaterCount()<35 and FREEBAGSLOTS()>3 and not PlayerMoving() and Cooldown("Conjure Water")==0 and Cooldown("Conjure Refreshment")==-1 then
    mySecureButtonSetAttribute("macrotext", "/cast [nocombat] Conjure Water")
  elseif not UnitAffectingCombat("player") and UnitClass("player")=="Mage" and MageFoodCount()<12 and FREEBAGSLOTS()>5 and not PlayerMoving() and Cooldown("Conjure Food")==0 then
    mySecureButtonSetAttribute("macrotext", "/cast [nocombat] Conjure Food")

	--Mage
  elseif UnitClass("player")=="Mage" and Cooldown("Combustion")==0 and PlayerBuff("Combustion")==0 then
    mySecureButtonSetAttribute("macrotext", "/cast [target=player,nocombat] Combustion")
	 
  elseif UnitClass("player")=="Mage" and PlayerBuff("Arcane Intellect")<6*60 and PlayerBuff("Fel Intelligence")<=0 and PlayerBuff("Dalaran Intellect")<=0 and PlayerBuff("Dalaran Brilliance")<=0 then
    mySecureButtonSetAttribute("macrotext", "/cast [target=player,nocombat] Arcane Intellect")
	 
  elseif UnitClass("player")=="Mage" and PlayerBuff("Dampen Magic")<2*60 then
    mySecureButtonSetAttribute("macrotext", "/cast [target=player,nocombat] Dampen Magic")
		
  --Mage Armor
  elseif UnitClass("player")=="Mage" and MageSelfArmor()<60*14 and ( Cooldown("Frost Armor")==0 or Cooldown("Mage Armor")==0 ) then
    --refresh current buff
    if PlayerBuff("Molten Armor")>0 then
      mySecureButtonSetAttribute("macrotext", "/cast [nocombat] Molten Armor")
			
    elseif PlayerBuff("Mage Armor")>0 then
      mySecureButtonSetAttribute("macrotext", "/cast [nocombat] Mage Armor")
			
    elseif PlayerBuff("Ice Armor")>0 then
      mySecureButtonSetAttribute("macrotext", "/cast [nocombat] Ice Armor")
			
    --pick new buff
    elseif Cooldown("Molten Armor")==0 and Talent("Molten Shields")>0 then
      mySecureButtonSetAttribute("macrotext", "/cast [nocombat] Molten Armor")
				
	elseif Cooldown("Molten Armor")==0 then
      mySecureButtonSetAttribute("macrotext", "/cast [nocombat] Molten Armor")
	  
    elseif Cooldown("Mage Armor")==0 then
      mySecureButtonSetAttribute("macrotext", "/cast [nocombat] Mage Armor")
			
    elseif Cooldown("Ice Armor")==0 then
      mySecureButtonSetAttribute("macrotext", "/cast [nocombat] Ice Armor")
    
    else --such a noob
      mySecureButtonSetAttribute("macrotext", "/cast [nocombat] Frost Armor")
			
    end
      
    
  --[[  mySecureButtonSetAttribute("macrotext", "/cast [nocombat] Molten Armor")  
  elseif UnitClass("player")=="Mage" and PlayerBuff("Mage Armor")<60*14   and PlayerBuff("Ice Armor")==0  and PlayerBuff("Molten Armor")==0 then
    mySecureButtonSetAttribute("macrotext", "/cast [nocombat] Mage Armor")
  elseif UnitClass("player")=="Mage" and PlayerBuff("Ice Armor")<14*60    and PlayerBuff("Mage Armor")==0 and PlayerBuff("Molten Armor")==0 then
    mySecureButtonSetAttribute("macrotext", "/cast [nocombat] Ice Armor")
  elseif UnitClass("player")=="Mage" and PlayerBuff("Frost Armor")<14*60  and PlayerBuff("Ice Armor")==0  and PlayerBuff("Mage Armor")==0 and PlayerBuff("Molten Armor")==0 then
    mySecureButtonSetAttribute("macrotext", "/cast [nocombat] Frost Armor")   ]]--



	--Warrior
	elseif UnitClass("player")=="Warrior" and PlayerMana()>10 and PlayerBuff("Commanding Shout")<60 then
	  mySecureButtonSetAttribute("macrotext", "/cast Commanding Shout")

		
  --Paladin (heal)
  elseif UnitClass("player")=="Paladin" and PlayerHealth()<4 and not PlayerMoving() and not IsMounted() then
    mySecureButtonSetAttribute("macrotext", "/cast [target=player,nocombat] Flash of Light")
  elseif UnitClass("player")=="Paladin" and PlayerHealth()<9 and PlayerMana()>15 and not PlayerMoving() and Cooldown("Flash of Light")==0 and not IsMounted() then
    mySecureButtonSetAttribute("macrotext", "/cast [target=player,nocombat] Flash of Light")

	--Paladin (Seal)
	elseif UnitClass("player")=="Paladin" and SealDuration()<60*12 and ( ( UnitCanAttack("player","target") and UnitCanAttack("target","player") ) or SealDuration()<60*6 ) and ( Cooldown("Seal of Righteousness")==0 or Cooldown("Seal of Justice")==0 ) and not IsMounted() then
    
		if Cooldown("Seal of Wisdom")==0 and PlayerBuff("Righteous Fury")==0 then
			mySecureButtonSetAttribute("macrotext", "/cast [nocombat] Seal of Wisdom")
			
		elseif PlayerMana()>50 and Cooldown("Seal of Corruption")==0 then
			mySecureButtonSetAttribute("macrotext", "/cast [nocombat] Seal of Corruption")
			
		elseif Cooldown("Seal of Wisdom")==0 then
			mySecureButtonSetAttribute("macrotext", "/cast [nocombat] Seal of Wisdom")
			
    elseif Cooldown("Seal of Righteousness")==0 then
      mySecureButtonSetAttribute("macrotext", "/cast [nocombat] Seal of Righteousness")
			
		end
		
		
  --Paladin (BLESSING)
  elseif UnitClass("player")=="Paladin" and AutoBlessing() and Aura() and not IsMounted() then
    castTarget, blessingOf = AutoBlessing();
    if castTarget and blessingOf then
      mySecureButtonSetAttribute("macrotext", "/cast [target="..castTarget..",nocombat] "..blessingOf)
    end
    
	--Paladin (Aura)
  elseif UnitClass("player")=="Paladin" and SelectNewAura() and PlayerBuff("Spirit Heal")<=0 then
    mySecureButtonSetAttribute("macrotext", "/cast [nocombat] "..SelectNewAura())
  --[[
	elseif UnitClass("player")=="Paladin" and ( not Aura() or ( Aura()=="Crusader Aura" and not IsMounted() ) or ( IsMounted() and Aura()~="Crusader Aura" and IsOutdoors() ) ) and PlayerBuff("Spirit Heal")<=0 then
	  castTarget, blessingOf = AutoBlessing();
	
	
	  if Cooldown("Crusader Aura")==0 and IsMounted() and ( ( not castTarget and not blessingOf ) or IsFlying() ) then
		  mySecureButtonSetAttribute("macrotext", "/cast [nocombat] Crusader Aura")
			
		elseif Cooldown("Sanctity Aura")==0 and PlayerBuff("Sanctity Aura")==0 then
		  mySecureButtonSetAttribute("macrotext", "/cast [nocombat] Sanctity Aura")
			
    elseif GetNumVisibleTeam()>0 and Cooldown("Concentration Aura")==0 and PlayerBuff("Concentration Aura")==0 then
			mySecureButtonSetAttribute("macrotext", "/cast [nocombat] Concentration Aura")
			
		elseif Cooldown("Retribution Aura")==0 and PlayerBuff("Retribution Aura")==0 then
			mySecureButtonSetAttribute("macrotext", "/cast [nocombat] Retribution Aura")
			
		elseif ( PlayerBuff("Devotion Aura")==0 or Talent("Improved Devotion Aura") ) and Cooldown("Devotion Aura")==0 then
		  mySecureButtonSetAttribute("macrotext", "/cast [nocombat] Devotion Aura")
			
		elseif GetNumVisibleTeam()>0 and Cooldown("Concentration Aura")==0 and Talent("Improved Concentration Aura")>0 then
			mySecureButtonSetAttribute("macrotext", "/cast [nocombat] Concentration Aura")
			
		elseif Talent("Improved Retribution Aura")>0 and Cooldown("Improved Retribution Aura")==0 then
		  mySecureButtonSetAttribute("macrotext", "/cast [nocombat] Retribution Aura")
			
		elseif Cooldown("Sanctity Aura")==0 and Talent("Improved Sanctity Aura")>0 then
		  mySecureButtonSetAttribute("macrotext", "/cast [nocombat] Sanctity Aura")
			
		end
    ]]--
		
    
	--Paladin
  elseif UnitClass("player")=="Paladin" and not forceOffRighteousFury and PlayerBuff("Righteous Fury")==0 and PlayerMana()>=50 and Cooldown("Righteous Fury")==0 and Talent("Improved Righteous Fury")>0 then
    mySecureButtonSetAttribute("macrotext", "/cast [nocombat] Righteous Fury")
  elseif UnitClass("player")=="Paladin" and not forceOffRighteousFury and PlayerBuff("Righteous Fury")==0 and PlayerMana()>=5  and Cooldown("Righteous Fury")==0 and Talent("Improved Righteous Fury")>0 then
    mySecureButtonSetAttribute("macrotext", "/cast [nocombat] Righteous Fury")
    
  elseif UnitClass("player")=="Paladin" and PlayerHealth()<19 and PlayerMana()>35 and Cooldown("Flash of Light")==0 and not PlayerMoving() then
    mySecureButtonSetAttribute("macrotext", "/cast [target=player,nocombat] Flash of Light")

    

  --Paladin (BLESSING)
  elseif UnitClass("player")=="Paladin" and AutoBlessing() and ( Cooldown("Blessing of Might")==0 or Cooldown("Blessing of Wisdom")==0 ) then
    castTarget, blessingOf = AutoBlessing();
    if castTarget and blessingOf then
      mySecureButtonSetAttribute("macrotext", "/cast [target="..castTarget..",nocombat] "..blessingOf)
    end


    

  --Druid
  elseif UnitClass("player")=="Druid" and ( TotalBuffCheck("Mark of the Wild","Gift of the Wild")<60*2 or ( not Aura() and TotalBuffCheck("Mark of the Wild","Gift of the Wild")<60*15 ) ) and PlayerMana()>45 and PlayerRage()<=0 and not IsStealthed() then
	  tbc_dur, tbc_char = TotalBuffCheck("Mark of the Wild","Gift of the Wild")
    mySecureButtonSetAttribute("macrotext", "/cast [target=" ..tbc_char.. ",nocombat] Mark of the Wild")
  --thorns
  elseif UnitClass("player")=="Druid" and ( PlayerBuff("Thorns")<60*2 or ( PlayerBuff("Thorns")<60*6 and not Aura() ) ) and Aura()~="Tree of Life" and PlayerBuff("Fire Shield")<=0 and PlayerRage()<=0 and not IsStealthed() then
	  mySecureButtonSetAttribute("macrotext", "/cast [target=player,nocombat] Thorns")
  --thorns
  elseif UnitClass("player")=="Druid" and ( TotalBuffCheck("Thorns","Fire Shield")<60*1 or ( TotalBuffCheck("Thorns","Fire Shield")<60*5 and not Aura() ) ) and Aura()~="Tree of Life" and ( not t_BearForm or GetTime()-t_BearForm>10*60 or BattleGround() ) and PlayerRage()<=0 and not IsStealthed() then
	  tbc_dur, tbc_char = TotalBuffCheck("Thorns","Fire Shield")
    mySecureButtonSetAttribute("macrotext", "/cast [target=" ..tbc_char.. ",nocombat] Thorns")
    
  --if full mana
  elseif UnitClass("player")=="Druid" and TotalBuffCheck("Mark of the Wild","Gift of the Wild")<60*22 and not Aura() and PlayerMana()>95 and PlayerRage()<=0 and not IsStealthed() then
	  tbc_dur, tbc_char = TotalBuffCheck("Mark of the Wild","Gift of the Wild")
    mySecureButtonSetAttribute("macrotext", "/cast [target=" ..tbc_char.. ",nocombat] Mark of the Wild")
  --thorns
  elseif UnitClass("player")=="Druid" and TotalBuffCheck("Thorns","Fire Shield")<60*7 and ( not t_BearForm or GetTime()-t_BearForm>10*60 or BattleGround() ) and not Aura() and PlayerMana()>95 and PlayerRage()<=0 and not IsStealthed() then
	  tbc_dur, tbc_char = TotalBuffCheck("Thorns","Fire Shield")
    mySecureButtonSetAttribute("macrotext", "/cast [target=" ..tbc_char.. ",nocombat] Thorns")
  elseif UnitClass("player")=="Druid" and TotalBuffCheck("Thorns","Fire Shield")<60*1 and ( not t_BearForm or GetTime()-t_BearForm>10*60 or BattleGround() ) and not Aura() and PlayerMana()>40 and PlayerRage()<=0 and not IsStealthed() then
	  tbc_dur, tbc_char = TotalBuffCheck("Thorns","Fire Shield")
    mySecureButtonSetAttribute("macrotext", "/cast [target=" ..tbc_char.. ",nocombat] Thorns")
    
--[[  --  elseif UnitClass("player")=="Druid" and Cooldown("Omen of Clarity")==0 and PlayerBuff("Omen of Clarity")<90 and PlayerRage()<=0 and not IsStealthed() then
--    mySecureButtonSetAttribute("macrotext", "/cast [nocombat] Omen of Clarity")

  elseif UnitClass("player")=="Druid" and who_MarkOfTheWild(1) and PlayerRage()<=0 and not IsStealthed() then
    mySecureButtonSetAttribute("macrotext", "/cast [target="..who_MarkOfTheWild(1)..",nocombat] ".."Mark of the Wild")
	
  elseif UnitClass("player")=="Druid" and who_MarkOfTheWild(max( PlayerBuff("Mark of the Wild")-60*4,60*12 )) and PlayerRage()<=0 and not IsStealthed() then
	  whatthefuck = who_MarkOfTheWild(max( PlayerBuff("Mark of the Wild")-60*4,60*12 ))
		if whatthefuck and type(whatthefuck)=="string" and strlen(whatthefuck)>0 then
      mySecureButtonSetAttribute("macrotext", "/cast [target=" .. whatthefuck .. ",nocombat] ".."Mark of the Wild")
		else
		  t_whatthefuck = GetTime()
		end
    
--  elseif UnitClass("player")=="Druid" and Cooldown("Omen of Clarity")==0 and PlayerBuff("Omen of Clarity")<11*60 and PlayerRage()<=0 and not IsStealthed() then
--    mySecureButtonSetAttribute("macrotext", "/cast [nocombat] Omen of Clarity")  ]]--


	--Priest
	elseif UnitClass("player")=="Priest" and PlayerBuff("Inner Fire")<60*4 and Cooldown("Inner Fire")==0 then
    mySecureButtonSetAttribute("macrotext", "/cast [nocombat] Inner Fire")
	elseif UnitClass("player")=="Priest" and PlayerBuff("Touch of Weakness")<60*3 and Cooldown("Touch of Weakness")==0 then
    mySecureButtonSetAttribute("macrotext", "/cast [nocombat] Touch of Weakness")
    
	--Priest (Divine Spirit)
	elseif UnitClass("player")=="Priest" and TotalBuffCheck("Divine Spirit","Prayer of Spirit","Fel Intelligence")<60*7 and PlayerMana()>5 and Cooldown("Divine Spirit")==0 then
	  tbc_dur, tbc_char = TotalBuffCheck("Divine Spirit","Prayer of Spirit","Fel Intelligence")
      mySecureButtonSetAttribute("macrotext", "/cast [target=" ..tbc_char.. ",nocombat] Divine Spirit")
    
	--Priest (Fortitude)
	elseif UnitClass("player")=="Priest" and TotalBuffCheck("Power Word: Fortitude","Prayer of Fortitude","K'iru's Song of Victory")<60*8 and PlayerMana()>15 then
	  tbc_dur, tbc_char = TotalBuffCheck("Power Word: Fortitude","Prayer of Fortitude","K'iru's Song of Victory")
    mySecureButtonSetAttribute("macrotext", "/cast [target=" ..tbc_char.. ",nocombat] Power Word: Fortitude")
	--Priest (Shadow Protection)
	elseif UnitClass("player")=="Priest" and TotalBuffCheck("Shadow Protection","Prayer of Shadow Protection")<60*2 and PlayerMana()>45 then
	  tbc_dur, tbc_char = TotalBuffCheck("Shadow Protection","Prayer of Shadow Protection")
    mySecureButtonSetAttribute("macrotext", "/cast [target=" ..tbc_char.. ",nocombat] Shadow Protection")
  elseif UnitClass("player")=="Priest" and PlayerBuff("Shadowform")==0 and Cooldown("Shadowform")==0 and PlayerMana()>99 then
    mySecureButtonSetAttribute("macrotext", "/cast [nostance] Shadowform")
  --priest fearward
  elseif UnitClass("player")=="Priest" and PlayerBuff("Fear Ward")<=0 and Cooldown("Fear Ward")==0 and ( BattleGround() or GetNumVisibleTeam()==0 ) then
	  mySecureButtonSetAttribute("macrotext", "/cast [target=player,nocombat] Fear Ward")
		
		
	--Shaman (self shield)
	elseif UnitClass("player")=="Shaman" and ( PlayerBuff("Water Shield")<60*8 or Unit_Buff("player","Water Shield")<3 ) and ( PlayerBuff("Lightning Shield")<=60*8 or Unit_Buff("player","Lightning Shield")<3 ) and PlayerBuff("Earth Shield")<=0 and Cooldown("Water Shield")==0 and PlayerMana()<100 then
    mySecureButtonSetAttribute("macrotext", "/cast [nocombat] Water Shield")
	elseif UnitClass("player")=="Shaman" and PlayerBuff("Lightning Shield")<=0 and PlayerBuff("Water Shield")<=0 and PlayerBuff("Earth Shield")<=0 and Cooldown("Lightning Shield")==0 and PlayerMana()>95 then
    mySecureButtonSetAttribute("macrotext", "/cast [nocombat] Lightning Shield")
	--Shaman Weapon Enchant
	elseif UnitClass("player")=="Shaman" and WeaponEnchant()==0 then
		mySecureButtonSetAttribute("macrotext", "/castrandom [nocombat] Frostbrand Weapon, Windfury Weapon, Flametongue Weapon")
	--Earth Shield
	elseif UnitClass("player")=="Shaman" and ( GetMyEarthShield()==nil or GetMyEarthShield()<2 ) and ( Cooldown("Earth Shield")==0 ) and UnitIsVisible("focus") and SpellInRange("Earth Shield","focus") then
    mySecureButtonSetAttribute("macrotext", "/cast [target=focus,exists,nodead,raid,nocombat] Earth Shield")
		
		
  --Shaman Totems
	--Call of the Elements
	elseif UnitClass("player")=="Shaman" and GetWaterTotem()==nil and GetEarthTotem()==nil and GetAirTotem()==nil and GetFireTotem()==nil and Cooldown("Call of the Elements")==0 and ( Cooldown("Mana Spring Totem")==0 and Cooldown("Mana Tide Totem")<(5*60-12-1) ) then
	  mySecureButtonSetAttribute("macrotext", "/cast [nocombat] Call of the Elements")
		
  --Totem(Water)
	elseif UnitClass("player")=="Shaman" and GetWaterTotem()==nil and PlayerBuff("Mana Spring")<=0 and PlayerBuff("Mana Tide")<=0 and PlayerBuff("Mana Tide Totem")<=0 and PlayerBuff("Healing Spring")<=0 and PlayerBuff("Fire Resistance")<=0 and ( Cooldown("Mana Spring Totem")==0 and Cooldown("Mana Tide Totem")<(5*60-12-1) ) then
    mySecureButtonSetAttribute("macrotext", "/cast [nocombat] Mana Spring Totem")
		
  --Totem (earth)
	elseif UnitClass("player")=="Shaman" and GetEarthTotem()==nil and PlayerBuff("Stoneskin")<=0 and PlayerBuff("Strength of Earth")<=0 and ( Cooldown("Strength of Earth Totem")==0 and Cooldown("Earthbind Totem")<=0 and Cooldown("Stoneclaw Totem")<=0 ) then
    mySecureButtonSetAttribute("macrotext", "/cast [nocombat] Strength of Earth Totem")
	elseif UnitClass("player")=="Shaman" and GetEarthTotem()==nil and PlayerBuff("Stoneskin")<=0 and PlayerBuff("Strength of Earth")<=0 and ( Cooldown("Stoneskin Totem")==0 and Cooldown("Earthbind Totem")<=0 and Cooldown("Stoneclaw Totem")<=0 ) then
    mySecureButtonSetAttribute("macrotext", "/cast [nocombat] Stoneskin Totem")
		
  --Totem(air)
  elseif UnitClass("player")=="Shaman" and PlayerBuff("Grounding Totem Effect")<=0 and PlayerBuff("Wrath of Air Totem")<=0 and PlayerBuff("Windfury Totem")<=0 and PlayerBuff("Nature Resistance")<=0 and Cooldown("Wrath of Air Totem")==0 then
    mySecureButtonSetAttribute("macrotext", "/cast Wrath of Air Totem")
  elseif UnitClass("player")=="Shaman" and GetAirTotem()==nil and Cooldown("Windfury Totem")==0 then
    mySecureButtonSetAttribute("macrotext", "/cast Windfury Totem")
	elseif UnitClass("player")=="Shaman" and GetAirTotem()==nil and PlayerBuff("Grounding Totem Effect")<=0 and PlayerBuff("Wrath of Air Totem")<=0 and PlayerBuff("Windfury Totem")<=0 and PlayerBuff("Grace of Air")<=0 and PlayerBuff("Windwall")<=0 and PlayerBuff("Nature Resistance")<=0 and PlayerBuff("Tranquil Air")<=0 and ( Cooldown("Grounding Totem")==0 ) then
    mySecureButtonSetAttribute("macrotext", "/cast Grounding Totem")
		
  --Totem (Fire)
  elseif UnitClass("player")=="Shaman" and GetFireTotem()==nil and Cooldown("Totem of Wrath")==0 then
    mySecureButtonSetAttribute("macrotext", "/cast [nocombat] Totem of Wrath")
  elseif UnitClass("player")=="Shaman" and GetFireTotem()==nil and Cooldown("Flametongue Totem")==0 then
    mySecureButtonSetAttribute("macrotext", "/cast [nocombat] Flametongue Totem")
  elseif UnitClass("player")=="Shaman" and GetFireTotem()==nil and Cooldown("Searing Totem")==0 then
    mySecureButtonSetAttribute("macrotext", "/cast [combat] Searing Totem")  
    
	--Earth Shield
	elseif UnitClass("player")=="Shaman" and ( GetMyEarthShield()==nil or ( GetMyEarthShield()<4 and PlayerMana()>66 ) or ( GetMyEarthShield()<2 ) ) and ( Cooldown("Earth Shield")==0 ) and UnitIsVisible("focus") and SpellInRange("Earth Shield","focus") then
    mySecureButtonSetAttribute("macrotext", "/cast [target=focus,exists,nodead,raid,nocombat] [target=focus,exists,nodead,raid,nocombat] Earth Shield")
		
    
		
		
	--Mage
	elseif UnitClass("player")=="Mage" and TotalBuffCheck("Arcane Intellect","Arcane Brilliance","Fel Intelligence","Dalaran Intellect","Dalaran Brilliance")<60*3 and PlayerMana()>5 then
	  tbc_dur, tbc_char =  TotalBuffCheck("Arcane Intellect","Arcane Brilliance","Fel Intelligence","Dalaran Intellect","Dalaran Brilliance")
		mySecureButtonSetAttribute("macrotext", "/cast [target=" ..tbc_char.. ",nocombat] Arcane Intellect")
  --Mage
	elseif UnitClass("player")=="Mage" and PlayerBuff("Ice Barrier")<=18 and Cooldown("Ice Barrier")==0 and not IsResting() then
	  mySecureButtonSetAttribute("macrotext", "/cast [nocombat] Ice Barrier")
	elseif UnitClass("player")=="Mage" and PlayerBuff("Mana Shield")<1.5 and PlayerMana()>97 and not IsResting() then
    mySecureButtonSetAttribute("macrotext", "/castsequence reset=20 Mana Shield,nil")
	
    --Conjure Mage refreshment
	elseif not UnitAffectingCombat("player") and UnitClass("player")=="Mage" and MageWaterCount()<35 and FREEBAGSLOTS()>3 and not PlayerMoving() and Cooldown("Conjure Refreshment")==0 then	
    mySecureButtonSetAttribute("macrotext", "/cast [nocombat] Conjure Refreshment")
	  
		
  --Paladin (Heal)
  elseif UnitClass("player")=="Paladin" and PlayerHealth()<PlayerMana() and UnitHealthMax("player")-UnitHealth("player") > SelfFlashOfLight()*1.5 and Cooldown("Flash of Light")==0 and not PlayerMoving() then
    mySecureButtonSetAttribute("macrotext", "/cast [target=player,nocombat] Flash of Light")


	--Hunter (Pet)
	elseif UnitClass("player")=="Hunter" and UnitIsVisible("pet") and Unit_Buff("pet","Mend Pet")<1 and ( UnitHealthMax("pet")-UnitHealth("pet")>1200 or UnitHealth("pet")/UnitHealthMax("pet")<0.84 ) and not UnitIsDeadOrGhost("pet") then
		mySecureButtonSetAttribute("macrotext", "/cast [nocombat] Mend Pet")
 	elseif UnitClass("player")=="Hunter" and UnitIsVisible("pet") and UnitIsDeadOrGhost("pet") then
		mySecureButtonSetAttribute("macrotext", "/cast [nocombat] Revive Pet")
	
	--Hunter (Aspect)
	elseif UnitClass("player")=="Hunter" and ( Aspect()==nil or Aspect()=="Aspect of the Pack" or Aspect()=="Aspect of the Cheetah" ) then
	  if ( Aspect()=="Aspect of the Pack" or Aspect()=="Aspect of the Cheetah" ) then
		  mySecureButtonSetAttribute("macrotext", "/castsequence [combat] reset=60/combat Aspect of the Monkey, nil")
    elseif PlayerMana()<100 and Cooldown("Aspect of the Viper")==0 then
	    mySecureButtonSetAttribute("macrotext", "/cast [nocombat] Aspect of the Viper")
		else
		  mySecureButtonSetAttribute("macrotext", "/cast [nocombat] Aspect of the Hawk")
		end
	elseif UnitClass("player")=="Hunter" and Aspect()=="Aspect of the Viper" and PlayerMana()>=100 then
	    mySecureButtonSetAttribute("macrotext", "/cast [nocombat] Aspect of the Hawk")
	elseif UnitClass("player")=="Hunter" and Aspect()=="Aspect of the Hawk" and PlayerMana()<40 then
	    mySecureButtonSetAttribute("macrotext", "/cast [nocombat] Aspect of the Viper")
  --Hunter
  elseif UnitClass("player")=="Hunter" and PlayerBuff("Trueshot Aura")==0 and Cooldown("Trueshot Aura")==0 then
      mySecureButtonSetAttribute("macrotext", "/cast [nocombat] Trueshot Aura")
      
	--Warlock
	elseif UnitClass("player")=="Warlock" and PlayerHealth()>=100 and PlayerMana()<15 and Cooldown("Life Tap")==0 then
	  mySecureButtonSetAttribute("macrotext", "/cast [nocombat] Life Tap")
  elseif UnitClass("player")=="Warlock" and PetMana()>=100 and PlayerMana()<45 and Cooldown("Dark Pact")==0 then
	  mySecureButtonSetAttribute("macrotext", "/cast [nocombat] Dark Pact")
	elseif UnitClass("player")=="Warlock" and PlayerBuff("Soul Link")==0 and Unit_Buff("pet","Soul Link")==0 and UnitCreatureType("pet")=="Demon" and ( UnitCreatureFamily("pet")=="Felguard" or UnitCreatureFamily("pet")=="Voidwalker" ) and Cooldown("Soul Link")==0 then
	  mySecureButtonSetAttribute("macrotext", "/cast [nocombat] Soul Link")
  --Warlock Armor
  elseif UnitClass("player")=="Warlock" and PlayerBuff("Fel Armor")<60*20 and PlayerBuff("Demon Armor")==0 and Cooldown("Fel Armor")==0 then
	  mySecureButtonSetAttribute("macrotext", "/cast [nocombat] Fel Armor")  
	elseif UnitClass("player")=="Warlock" and PlayerBuff("Demon Armor")<60*20 and PlayerBuff("Fel Armor")==0 and Cooldown("Demon Armor")==0 then
	  mySecureButtonSetAttribute("macrotext", "/cast [nocombat] Demon Armor")
  --Warlock Continued
	elseif UnitClass("player")=="Warlock" and PlayerBuff("Detect Invisibility")<60*4 then
	  mySecureButtonSetAttribute("macrotext", "/cast [target=player,nocombat] Detect Invisibility")
	elseif UnitClass("player")=="Warlock" and PlayerHealth()>=100 and PlayerMana()<60 and Cooldown("Life Tap")==0 then
	  mySecureButtonSetAttribute("macrotext", "/cast [nocombat] Life Tap")
  elseif UnitClass("player")=="Warlock" and PetMana()>=100 and PlayerMana()<85 and Cooldown("Dark Pact")==0 then
	  mySecureButtonSetAttribute("macrotext", "/cast [nocombat] Dark Pact")
	elseif UnitClass("player")=="Warlock" and TotalBuffCheck("Detect Invisibility")<60*1 then
		tbc_dur, tbc_char = TotalBuffCheck("Detect Invisibility")
		mySecureButtonSetAttribute("macrotext", "/cast [target=" ..tbc_char.. ",nocombat] Detect Invisibility")
	elseif UnitClass("player")=="Warlock" and ( PlayerHealth()>=100 and PlayerMana()<75 ) or ( PlayerHealth()>90 and PlayerMana()<25 ) and Cooldown("Life Tap")==0 then
	  mySecureButtonSetAttribute("macrotext", "/cast [nocombat] Life Tap")
		
  --Death Knight
  elseif UnitClass("player")=="Death Knight" and PlayerBuff("Bone Shield")<60 and Cooldown("Bone Shield")==0 and UnholyRunes()>=2 and UnitManaMax("player")-UnitMana("player")>=10 then
    mySecureButtonSetAttribute("macrotext", "/cast [nocombat] Bone Shield")
  elseif UnitClass("player")=="Death Knight" and PlayerBuff("Horn of Winter")<60 and Cooldown("Horn of Winter")==0 and UnitManaMax("player")-UnitMana("player")>=10 then
    mySecureButtonSetAttribute("macrotext", "/cast [nocombat] Horn of Winter")
  elseif UnitClass("player")=="Death Knight" and shouldPathOfFrost and PlayerBuff("Path of Frost")==0 and Cooldown("Path of Frost")==0 and FrostRunes()>=2 and ( IsSwimming() or IsMounted() ) then
    mySecureButtonSetAttribute("macrotext", "/cast [nocombat] Path of Frost")
    
  elseif UnitClass("player")=="Death Knight" and PlayerBuff("Bone Shield")<90 and UnitBuffCount("player","Bone Shield")<3 and Cooldown("Bone Shield")==0 and UnholyRunes()>=2 and UnitManaMax("player")-UnitMana("player")>=10 then
    mySecureButtonSetAttribute("macrotext", "/cast [nocombat] Bone Shield")    
  elseif UnitClass("player")=="Death Knight" and PlayerBuff("Horn of Winter")<100 and Cooldown("Horn of Winter")==0 and UnitMana("player")>=30 and UnitManaMax("player")-UnitMana("player")>=10 then
    mySecureButtonSetAttribute("macrotext", "/cast [nocombat] Horn of Winter")
  elseif UnitClass("player")=="Death Knight" and PlayerBuff("Bone Shield")<60*4 and UnitBuffCount("player","Bone Shield")<4 and Cooldown("Bone Shield")==0 and UnholyRunes()>=2 and UnitMana("player")>=30 and UnitManaMax("player")-UnitMana("player")>=10 then
    mySecureButtonSetAttribute("macrotext", "/cast [nocombat] Bone Shield")
	elseif UnitClass("player")=="Death Knight" and shouldPathOfFrost and PlayerBuff("Path of Frost")==0 and Cooldown("Path of Frost")==0 and FrostRunes()>=3 and ( IsSwimming() or IsMounted() or IsOutdoors() ) then
    mySecureButtonSetAttribute("macrotext", "/cast [nocombat] Path of Frost")
    
    
	--Drink Water
	elseif PlayerBuff("Drink")<1 and ( not t_mageDrink or GetTime()-t_mageDrink>15 ) and not UnitAffectingCombat("player") and ( ( MageWaterCount()>40 and PlayerMana()<15 ) or ( MageWaterCount()>20 and PlayerMana()<55 and UnitClass("player")=="Mage" ) ) and not PlayerMoving() and UnitPowerType("player")==0 then
    mySecureButtonSetAttribute("macrotext", "/use "..CurrentMageWater() .. "\n/script t_mageDrink=GetTime()" )
			
			
  --Vanity Pet
  elseif CurrentVanityPet()==false and not UnitAffectingCombat("player") and not BattleGround() and not UnitIsPVP("player") and not IsStealthed() and not IsMounted() and not UnitIsDeadOrGhost("player") and not imabigcowstinks then
    mySecureButtonSetAttribute("macrotext", "/script Jpet() ")
      
  --Do nothing
  else
    mySecureButtonSetAttribute("macrotext", "/script echoDoNothing() ")
    --SetBindingClick("ESCAPE","CLEARTARGET")
  end

	
	
	
	
	
	
	
	
	
  
  
  
  
	
	
	
	
	-- SET THE MACRO TEXT
	if CurrJKeyMacroText ~= J_Key_Macro_Text and not UnitAffectingCombat("player") and xtimer("Jkey_delay",0.4) then
	  CurrJKeyMacroText = J_Key_Macro_Text
	  mySecureButton:SetAttribute("macrotext",CurrJKeyMacroText .. " \n/script t_JkeySet=1  ")
		t_JkeySet = GetTime()
		if jkeydebug then dprint( CurrJKeyMacroText ) end
	end 
  
  
	t_SecureOnUpdate = GetTime()
end

-----------------------------------------------------------------------------------------------------------------------










--  mySecureButtonSetAttribute("macrotext", "/script if xtimer(\"NothingToDo\",8) then UIErrorsFrame:AddMessage(\"Nothing to Do\" ,0,1,.5,1,2) end if UnitIsEnemy(\"target\",\"player\") then SetRaidTarget(\"target\",8) end ")

function echoDoNothing()
  if UnitAffectingCombat("player") and xtimer("NothingToDo",7) then
	  UIErrorsFrame:AddMessage("In Combat" ,1,0,.5)
  elseif xtimer("NothingToDo",7) and not UnitAffectingCombat("player") then
	  UIErrorsFrame:AddMessage("Nothing to Do" ,0,1,.5,1,2)
	end
	if UnitIsEnemy("target","player") then
		SetRaidTarget("target",8)
  end 
end


















function SelfFlashOfLight()
  if PlayerBuff("Blessing of Light")>2 or PlayerBuff("Greater Blessing of Light")>2 then
    return (( 513 + GetSpellBonusHealing() *.43 + 185 )*( 1+Talent("Healing Light")*0.04 ))
  else
    return (( 513 + GetSpellBonusHealing() *.43 + 0 )*( 1+Talent("Healing Light")*0.04 ))
  end
end










--Vanity Pet
function Jpet()
  if CurrentVanityPet()==false and not UnitAffectingCombat("player") and not BattleGround() and not UnitIsPVP("player") and not IsStealthed() and not IsMounted() and not UnitIsDeadOrGhost("player") and xtimer("JVanityPet",4) then
    UIErrorsFrame:AddMessage( CallRandomVanityPet() ,0,1,1  ,1,1)
  end
end






















function MageSelfArmor()
  return ( PlayerBuff("Frost Armor") + PlayerBuff("Ice Armor") + PlayerBuff("Mage Armor") + PlayerBuff("Molten Armor") )
end


















function SelectNewAura()
  if PlayerBuff("Spirit Heal")>0 and BattleGround() then
	  return nil
    
  elseif IsMounted() and Aura()~="Crusader Aura" and Cooldown("Crusader Aura")==0 then
    return "Crusader Aura"
    
  elseif ( not IsMounted() and Aura()=="Crusader Aura" ) or not Aura() then
    --Talented
    if Talent("Improved Concentration Aura")>0 and Cooldown("Concentration Aura")==0 then
      return "Concentration Aura"
    elseif Talent("Sanctified Retribution")>0 and Cooldown("Retribution Aura")==0 then
      return "Retribution Aura"
    elseif Talent("Improved Devotion Aura")>0 and Cooldown("Devotion Aura")==0 then
      return "Devotion Aura"
    
    --Talent'ish
    elseif PlayerBuff("Retribution Aura")==0 and ( PlayerBuff("Righteous Fury")>0 or Talent("Blessing of Sanctuary")>0 or Talent("Improved Righteous Fury")>0 ) and Cooldown("Retribution Aura")==0 then
      return "Retribution Aura"
    elseif PlayerBuff("Concentration Aura")==0 and ( Talent("Spiritual Focus")>0 or Talent("Illumination")>0 ) and Cooldown("Concentration Aura")==0 then
      return "Concentration Aura"
      
    --No Talents
    elseif PlayerBuff("Retribution Aura")==0 and Cooldown("Retribution Aura")==0 then
      return "Retribution Aura"
    elseif PlayerBuff("Concentration Aura")==0 and Cooldown("Concentration Aura")==0 then
      return "Concentration Aura"
    elseif PlayerBuff("Devotion Aura")==0 and Cooldown("Devotion Aura")==0 then
      return "Devotion Aura"
    
    --Else
    elseif Cooldown("Retribution Aura")==0 then
      return "Retribution Aura"
    elseif Cooldown("Concentration Aura")==0 then
      return "Concentration Aura"
    elseif Cooldown("Devotion Aura")==0 then
      return "Devotion Aura"
    end
    
  end
end --end of SelectNewAura









--name, rank, icon, count, debuffType, duration, expirationTime, _, isStealable = UnitBuff(


--Paladin
--given unit, returns duration of MY blessing on unit, -1 if no blessing
--return duration, nameOfBlessing
function MyBlessing(nUnit)

	name, rank, icon, count, debuffType, duration, expirationTime, isMine, isStealable = UnitBuff(nUnit,"Blessing of Kings")
	if isMine=="player" then
		return (expirationTime - GetTime()), name
	end
	
	name, rank, icon, count, debuffType, duration, expirationTime, isMine, isStealable = UnitBuff(nUnit,"Greater Blessing of Kings")
	if isMine=="player" then
		return (expirationTime - GetTime()), name
	end
	
	
	name, rank, icon, count, debuffType, duration, expirationTime, isMine, isStealable = UnitBuff(nUnit,"Blessing of Wisdom")
	if isMine=="player" then
		return (expirationTime - GetTime()), name
	end
	
	name, rank, icon, count, debuffType, duration, expirationTime, isMine, isStealable = UnitBuff(nUnit,"Greater Blessing of Wisdom")
	if isMine=="player" then
		return (expirationTime - GetTime()), name
	end
	
	
	name, rank, icon, count, debuffType, duration, expirationTime, isMine, isStealable = UnitBuff(nUnit,"Blessing of Might")
	if isMine=="player" then
		return (expirationTime - GetTime()), name
	end
	
	name, rank, icon, count, debuffType, duration, expirationTime, isMine, isStealable = UnitBuff(nUnit,"Greater Blessing of Might")
	if isMine=="player" then
		return (expirationTime - GetTime()), name
	end
	
	
	name, rank, icon, count, debuffType, duration, expirationTime, isMine, isStealable = UnitBuff(nUnit,"Blessing of Sanctuary")
	if isMine=="player" then
		return (expirationTime - GetTime()), name
	end
	
	name, rank, icon, count, debuffType, duration, expirationTime, isMine, isStealable = UnitBuff(nUnit,"Greater Blessing of Sanctuary")
	if isMine=="player" then
		return (expirationTime - GetTime()), name
	end
	
	return -1, nil
--[[
  emptyBuffs = 0
  for blessingIndex=0,80 do
    name, rank, icon, count, debuffType, duration, expirationTime, isMine, isStealable = UnitBuff(nUnit,blessingIndex)
		
    if type(expirationTime)=="number" and type(name)=="string" and strfind(name,"Blessing of ") and isMine=="player" then
      return (expirationTime - GetTime()), name
			
		elseif not name and not icon and not timeLeft and emptyBuffs>3 then
      return -1, nil
	
    elseif not name and not icon and not timeLeft then
      emptyBuffs = emptyBuffs+1
			
    end
  end
	
  return -1, nil ]]--
end












--[[
  pickBlessing = PickBlessing("target")
  if pickBlessing then
    return "target" , pickBlessing
  end
]]--



function AutoBlessing()
		pickBlessing = PickBlessing("mouseover")
    if pickBlessing then
      return "mouseover" , pickBlessing
    end
		
    pickBlessing = PickBlessing("target")
    if pickBlessing then
      return "target" , pickBlessing
    end	
		
	  pickBlessing = PickBlessing("focus")
    if pickBlessing then
      return "focus" , pickBlessing
    end
		
  --SHORTEST DURATION!!
	  sdBless, durBless = FindMinDurationBlessing()
		pickBlessing = PickBlessing(sdBless)
    if pickBlessing then
      return sdBless , pickBlessing
    end

		
	--Party
  for i=1,5 do
    pickBlessing = PickBlessing("party"..i)
    if pickBlessing then
      return "party"..i , pickBlessing
    end
  end
  for i=1,5 do
    pickBlessing = PickBlessing("partypet"..i)
    if pickBlessing then
      return "partypet"..i , pickBlessing
    end
  end

  --Raid
  for i=1,40 do
    pickBlessing = PickBlessing("raidpet"..i)
    if pickBlessing then
      return "raidpet"..i , pickBlessing
    end
  end
  for i=1,40 do
    pickBlessing = PickBlessing("raid"..i)
    if pickBlessing then
      return "raid"..i , pickBlessing
    end
  end
	
	--suffix Target
	pickBlessing = PickBlessing("targettarget")
	if pickBlessing then
		return "targettarget" , pickBlessing
	end

	pickBlessing = PickBlessing("focustarget")
	if pickBlessing then
		return "focustarget" , pickBlessing
	end

	pickBlessing = PickBlessing("mouseovertarget")
	if pickBlessing then
		return "mouseovertarget" , pickBlessing
	end
	
	pickBlessing = PickBlessing("targettargettarget")
	if pickBlessing then
		return "targettargettarget" , pickBlessing
	end
	
	--pet
  pickBlessing = PickBlessing("pet")
  if pickBlessing then
    return "pet" , pickBlessing
  end
	
	--Party Target
	for i=1,5 do
    pickBlessing = PickBlessing("party"..i.."target")
    if pickBlessing then
      return "party"..i.."target" , pickBlessing
    end
  end
	
	--Self
	pickBlessing = PickBlessing("player")
  if pickBlessing then
    return "player" , pickBlessing
  end

  return nil
end




--[[
function AutoBlessing()
  for i=1,5 do
    if UnitIsVisible("partypet"..i) and SpellInRange("Blessing of Kings","partypet"..i) and MyBlessing("partypet"..i) < 60 and Unit_Buff("partypet"..i,"Blessing of Kings")==0 and not UnitIsDeadOrGhost("partypet"..i) then
       return "partypet"..i , "Blessing of Kings"
    end
  end
  for i=1,5 do
    if UnitIsVisible("party"..i) and SpellInRange("Blessing of Sanctuary","party"..i) and UnitClass("party"..i)=="Warrior" and MyBlessing("party"..i) < 60 and Unit_Buff("party"..i,"Blessing of Sanctuary")==0 and not UnitIsDeadOrGhost("party"..i) then
       return "party"..i , "Blessing of Sanctuary"
    elseif UnitIsVisible("party"..i) and SpellInRange("Blessing of Kings","party"..i) and UnitClass("party"..i)=="Warrior" and MyBlessing("party"..i) < 60 and Unit_Buff("party"..i,"Blessing of Kings")==0 and not UnitIsDeadOrGhost("party"..i) then
       return "party"..i , "Blessing of Kings"
    end
  end
  for i=1,5 do
    if UnitIsVisible("party"..i) and SpellInRange("Blessing of Salvation","party"..i) and MyBlessing("party"..i) < 60 and Unit_Buff("party"..i,"Blessing of Salvation")==0 and not UnitIsDeadOrGhost("party"..i) then
       return "party"..i , "Blessing of Salvation"
    elseif UnitIsVisible("party"..i) and SpellInRange("Blessing of Wisdom","party"..i) and UnitPowerType("party"..i)==0 and MyBlessing("party"..i) < 60 and Unit_Buff("party"..i,"Blessing of Wisdom")==0 and not UnitIsDeadOrGhost("party"..i) then
       return "party"..i , "Blessing of Wisdom"
    elseif UnitIsVisible("party"..i) and SpellInRange("Blessing of Kings","party"..i) and MyBlessing("party"..i) < 60 and Unit_Buff("party"..i,"Blessing of Kings")==0 and not UnitIsDeadOrGhost("party"..i) then
       return "party"..i , "Blessing of Kings"
    end
  end
end
]]--







function PickBlessing(nUnit)
  if not UnitIsVisible(nUnit) or UnitIsDeadOrGhost(nUnit) then
    return nil
	elseif ( MyBlessing(nUnit)>60*5.6 and PlayerMana()<71 ) or ( MyBlessing(nUnit)>60*8.6 ) then
	  return nil
  elseif IsSpellInRange("Blessing of Might",nUnit)==0 or IsSpellInRange("Blessing of Wisdom",nUnit)==0 then
    return nil
	elseif Cooldown("Blessing of Might")>0 or Cooldown("Blessing of Wisdom")>0 or Cooldown("Blessing of Kings")>0 then
	  return nil
  elseif not UnitCanAssist("player",nUnit) then
    return nil
  elseif UnitAffectingCombat(nUnit) then
    return nil
  elseif UnitCreatureType(nUnit)=="Totem" then
    return nil
	elseif UnitIsPVP(nUnit) and not BattleGround() then
    return nil
	elseif Unit_Buff(nUnit,"Phase Shift")>0 then
    return nil
	elseif not ShouldUnitBeBlessed(nUnit) then
	  return nil
  end

	

  
  if type(blanketBuff)=="string" then
    return blanketBuff
  end
  


  durrCurrent,currentBlessing = MyBlessing(nUnit)
--Renew Current Blessing On ANY TARGET
  if currentBlessing and ( ( currentBlessing=="Blessing of Wisdom" and UnitPowerType(nUnit)==0 ) or currentBlessing=="Blessing of Sanctuary" or currentBlessing=="Blessing of Kings" or currentBlessing=="Blessing of Might" ) then
    return currentBlessing
  end

	


--recall last cast
  if blessingTable and blessingTable[UnitName(nUnit)] then
	  if not HasBlessingOf( nUnit,strsub( blessingTable[UnitName(nUnit)] ,13) ) then
		  return (blessingTable[UnitName(nUnit)])
		end
	end

	
	
	
	


	

	
	
--Player
  if GetNumVisibleTeam()==0 and UnitIsUnit("player",nUnit) and not HasBlessingOf(nUnit,"Wisdom") then
    return "Blessing of Wisdom"
  elseif UnitIsUnit("player",nUnit) and not HasBlessingOf(nUnit,"Sanctuary") and IsEquippedItemType("Shields") and Cooldown("Blessing of Sanctuary")==0 then
    return "Blessing of Sanctuary"
  elseif UnitIsUnit("player",nUnit) and not HasBlessingOf(nUnit,"Wisdom") and IsEquippedItemType("Shields") then
    return "Blessing of Wisdom"
	elseif UnitIsUnit("player",nUnit) and not HasBlessingOf(nUnit,"Kings") and Cooldown("Blessing of Kings")==0 then
    return "Blessing of Kings"
		
--BattleGrounds (PVP)
  elseif not HasBlessingOf(nUnit,"Kings") and BattleGround() and UnitIsPVP("player") and UnitIsPVP(nUnit) and Cooldown("Blessing of Kings")==0 then
	  return "Blessing of Kings"
	elseif not HasBlessingOf(nUnit,"Sanctuary") and BattleGround() and UnitIsPVP("player") and UnitIsPVP(nUnit) and Cooldown("Blessing of Sanctuary")==0 then
	  return "Blessing of Sanctuary"

-- Improved Wisdom
  elseif UnitPowerType(nUnit)==0 and not HasBlessingOf(nUnit,"Wisdom") and Talent("Improved Blessing of Wisdom")>0 then
    return "Blessing of Wisdom"
		
--NPCs
  elseif not UnitIsPlayer(nUnit) and not HasBlessingOf(nUnit,"Kings") and Cooldown("Blessing of Kings")==0 then
    return "Blessing of Kings"
	elseif not UnitIsPlayer(nUnit) and UnitPowerType(nUnit)~=0 and not HasBlessingOf(nUnit,"Sanctuary") and Cooldown("Blessing of Sanctuary")==0 then
    return "Blessing of Sanctuary"	
  elseif not UnitIsPlayer(nUnit) and UnitPowerType(nUnit)==0 and not HasBlessingOf(nUnit,"Wisdom") then
    return "Blessing of Wisdom"
		
--Pets
  elseif IsPet(nUnit) and not HasBlessingOf(nUnit,"Kings") and Cooldown("Blessing of Kings")==0 then
    return "Blessing of Kings"
  elseif IsPet(nUnit) and UnitPowerType(nUnit)==0 and not HasBlessingOf(nUnit,"Wisdom") then
    return "Blessing of Wisdom"
	elseif not UnitIsPlayer(nUnit) and UnitPowerType(nUnit)~=0 and not HasBlessingOf(nUnit,"Sanctuary") and Cooldown("Blessing of Sanctuary")==0 then
    return "Blessing of Sanctuary"
	elseif not UnitIsPlayer(nUnit) and not HasBlessingOf(nUnit,"Might") then
    return "Blessing of Might"

--Bears
  elseif UnitClass(nUnit)=="Druid" and UnitPowerType(nUnit)==1 and not IsPet(nUnit) and Cooldown("Blessing of Kings")==0 then
    return "Blessing of Kings"
		
--NonTanks
--  elseif ( UnitPlayerOrPetInRaid(nUnit) or UnitPlayerOrPetInParty(nUnit) ) and not HasBlessingOf(nUnit,"Salvation") and not BattleGround() and UnitClass(nUnit)~="Warrior" and UnitClass(nUnit)~="Paladin" and UnitPowerType(nUnit)~=1 and not IsPet(nUnit) and Cooldown("Blessing of Salvation")==0 then
--    return "Blessing of Salvation"

--Warriors
  elseif UnitClass(nUnit)=="Warrior" and not HasBlessingOf(nUnit,"Sanctuary") and Cooldown("Blessing of Sanctuary")==0 then
    return "Blessing of Sanctuary"
  elseif UnitClass(nUnit)=="Warrior" and not HasBlessingOf(nUnit,"Kings") and Cooldown("Blessing of Kings")==0 then
    return "Blessing of Kings"

--Elseif
  elseif UnitPowerType(nUnit)==0 and not HasBlessingOf(nUnit,"Wisdom") then
    return "Blessing of Wisdom"
  elseif not HasBlessingOf(nUnit,"Kings") and Cooldown("Blessing of Kings")==0 then
    return "Blessing of Kings"
	elseif not HasBlessingOf(nUnit,"Might") and not UnitIsPlayer(nUnit) then
    return "Blessing of Might"
	elseif not HasBlessingOf(nUnit,"Sanctuary") and Cooldown("Blessing of Sanctuary")==0 then
    return "Blessing of Sanctuary"
	--Warriors, Rogues, Bears, Cats, Hunter_Pets
  elseif UnitPowerType(nUnit)~=0 and not HasBlessingOf(nUnit,"Might") then
    return "Blessing of Might"
	elseif not HasBlessingOf(nUnit,"Wisdom") and ( UnitPowerType(nUnit)==0 or UnitClass(nUnit)=="Priest" or UnitClass(nUnit)=="Mage" or UnitClass(nUnit)=="Warlock" or UnitClass(nUnit)=="Shaman" or UnitClass(nUnit)=="Hunter" or UnitClass(nUnit)=="Paladin" or UnitClass(nUnit)=="Druid" ) then
    return "Blessing of Wisdom"
	elseif not HasBlessingOf(nUnit,"Might") and ( UnitClass(nUnit)~="Priest" and UnitClass(nUnit)~="Mage" and UnitClass(nUnit)~="Warlock" ) then
    return "Blessing of Might"
    
--	elseif ( UnitPlayerOrPetInRaid(nUnit) or UnitPlayerOrPetInParty(nUnit) ) and not HasBlessingOf(nUnit,"Salvation") and not BattleGround() then
--    return "Blessing of Salvation"
--	elseif ( UnitPlayerOrPetInRaid(nUnit) or UnitPlayerOrPetInParty(nUnit) ) and not HasBlessingOf(nUnit,"Salvation") then
--    return "Blessing of Salvation"
		
  end
end







function IsPet(nUnit)
  if UnitPlayerControlled(nUnit) and not UnitIsPlayer(nUnit) then
    return 1
  end
    return nil
end










function dur_MarkOfTheWild(sUnit,minDur)
  if not UnitExists(sUnit) then
    return nil
  elseif not UnitIsVisible(sUnit) then
    return nil
	elseif UnitIsDeadOrGhost(sUnit) then
    return nil
  elseif not UnitCanAssist("player",sUnit) then
    return nil
  elseif UnitAffectingCombat(sUnit) then
    return nil
  elseif IsSpellInRange("Mark of the Wild",sUnit)~=1 then
    return nil
  elseif not minDur then
    minDur=1
  end
 
  sUnitCount = max( Unit_Buff(sUnit,"Mark of the Wild") , Unit_Buff(sUnit,"Gift of the Wild") )
  sUnitDur = max( Unit_Buff_Timeleft(sUnit,"Mark of the Wild") , Unit_Buff_Timeleft(sUnit,"Gift of the Wild") )
	
  if sUnitDur<minDur and sUnitDur>0 then
    return sUnitDur
  elseif sUnitCount==0 then
	  return 0
	else
	  return false
  end
end








function who_MarkOfTheWild(minDur)
  if dur_MarkOfTheWild("target",minDur) then
    return "target"
  elseif dur_MarkOfTheWild("mouseover",minDur) then
    return "mouseover"
	elseif dur_MarkOfTheWild("focus",minDur) then
    return "focus"
  elseif dur_MarkOfTheWild("targettarget",minDur) then
    return "targettarget"
	elseif dur_MarkOfTheWild("focustarget",minDur) then
    return "focustarget"
	elseif dur_MarkOfTheWild("pet",minDur) then
    return "pet"
  end
  
  for i=1,5 do
    if dur_MarkOfTheWild("party"..i,minDur) then
	  return "party"..i
	elseif dur_MarkOfTheWild("partypet"..i,minDur) then
	  return "partypet"..i
	end
  end
  
  for i=1,40 do
    if dur_MarkOfTheWild("raid"..i,minDur) then
	  return "raid"..i
	elseif dur_MarkOfTheWild("raidpet"..i,minDur) then
	  return "raidpet"..i
	end
  end
  
  if dur_MarkOfTheWild("player",minDur) then
	  return "player"
  end
	
  return (false)
end




















































































function ShouldUnitBeBlessed(nUnit)
  if not UnitIsVisible(nUnit) or UnitIsDeadOrGhost(nUnit) then
    return nil
  elseif IsSpellInRange("Blessing of Might",nUnit)==0 or IsSpellInRange("Blessing of Wisdom",nUnit)==0 then
    return nil
	elseif Cooldown("Blessing of Might")>0 or Cooldown("Blessing of Wisdom")>0 or Cooldown("Blessing of Kings")>0 then
	  return nil
  elseif not UnitCanAssist("player",nUnit) then
    return nil
  elseif UnitAffectingCombat(nUnit) then
    return nil
  elseif UnitCreatureType(nUnit)=="Totem" then
    return nil
	elseif UnitIsPVP(nUnit) and not BattleGround() then
    return nil
	elseif Unit_Buff(nUnit,"Phase Shift")>0 then
    return nil

	elseif UnitClass("nUnit")=="Rogue" and false then
    return nil
		
  end
	
	return (nUnit)
end







function WhatBlessingForUnit(nUnit)
	if not ShouldUnitBeBlessed(nUnit) then
		return nil
	end
	
	
end








--[[
function UnitMight(nUnit)
  mightDur = select( 7 , UnitBuff("player","Greater Blessing of Might")  )

end
]]--









-- returns WHO has least time on their blessing AND what time is left
function FindMinDurationBlessing()
  whoLowestBless = nil
	durLowestBless = 60*60*24*7

	
	currentBlessingTestUnit = "mouseover"
	valMyBless = MyBlessing(currentBlessingTestUnit)
  if ShouldUnitBeBlessed(currentBlessingTestUnit) and valMyBless < durLowestBless then
    whoLowestBless = currentBlessingTestUnit
	  durLowestBless = valMyBless
  end

	
	currentBlessingTestUnit = "target"
	valMyBless = MyBlessing(currentBlessingTestUnit)
  if ShouldUnitBeBlessed(currentBlessingTestUnit) and valMyBless < durLowestBless then
    whoLowestBless = currentBlessingTestUnit
	  durLowestBless = valMyBless
  end

	
	currentBlessingTestUnit = "focus"
	valMyBless = MyBlessing(currentBlessingTestUnit)
  if ShouldUnitBeBlessed(currentBlessingTestUnit) and valMyBless < durLowestBless then
    whoLowestBless = currentBlessingTestUnit
	  durLowestBless = valMyBless
  end

	
	--Party
  for i=1,5 do
	
	currentBlessingTestUnit = "party"..i
	valMyBless = MyBlessing(currentBlessingTestUnit)
  if ShouldUnitBeBlessed(currentBlessingTestUnit) and valMyBless < durLowestBless then
    whoLowestBless = currentBlessingTestUnit
	  durLowestBless = valMyBless
  end
	
	currentBlessingTestUnit = "partypet"..i
	valMyBless = MyBlessing(currentBlessingTestUnit)
  if ShouldUnitBeBlessed(currentBlessingTestUnit) and valMyBless < durLowestBless then
    whoLowestBless = currentBlessingTestUnit
	  durLowestBless = valMyBless
  end
	
	end


  --Raid
  for i=1,40 do
 
 	currentBlessingTestUnit = "raid"..i
	valMyBless = MyBlessing(currentBlessingTestUnit)
  if ShouldUnitBeBlessed(currentBlessingTestUnit) and valMyBless < durLowestBless then
    whoLowestBless = currentBlessingTestUnit
	  durLowestBless = valMyBless
  end
	
	currentBlessingTestUnit = "raidpet"..i
	valMyBless = MyBlessing(currentBlessingTestUnit)
  if ShouldUnitBeBlessed(currentBlessingTestUnit) and valMyBless < durLowestBless then
    whoLowestBless = currentBlessingTestUnit
	  durLowestBless = valMyBless
  end
 
  end
	
	--suffix Target
	currentBlessingTestUnit = "targettarget"
	valMyBless = MyBlessing(currentBlessingTestUnit)
  if ShouldUnitBeBlessed(currentBlessingTestUnit) and valMyBless < durLowestBless then
    whoLowestBless = currentBlessingTestUnit
	  durLowestBless = valMyBless
  end

	currentBlessingTestUnit = "focustarget"
	valMyBless = MyBlessing(currentBlessingTestUnit)
  if ShouldUnitBeBlessed(currentBlessingTestUnit) and valMyBless < durLowestBless then
    whoLowestBless = currentBlessingTestUnit
	  durLowestBless = valMyBless
  end

	currentBlessingTestUnit = "mouseovertarget"
	valMyBless = MyBlessing(currentBlessingTestUnit)
  if ShouldUnitBeBlessed(currentBlessingTestUnit) and valMyBless < durLowestBless then
    whoLowestBless = currentBlessingTestUnit
	  durLowestBless = valMyBless
  end
	
	currentBlessingTestUnit = "targettargettarget"
	valMyBless = MyBlessing(currentBlessingTestUnit)
  if ShouldUnitBeBlessed(currentBlessingTestUnit) and valMyBless < durLowestBless then
    whoLowestBless = currentBlessingTestUnit
	  durLowestBless = valMyBless
  end
	
	--pet
	currentBlessingTestUnit = "pet"
	valMyBless = MyBlessing(currentBlessingTestUnit)
  if ShouldUnitBeBlessed(currentBlessingTestUnit) and valMyBless < durLowestBless then
    whoLowestBless = currentBlessingTestUnit
	  durLowestBless = valMyBless
  end
	
	--Party Target
	for i=1,5 do

	currentBlessingTestUnit = "party"..i.."target"
	valMyBless = MyBlessing(currentBlessingTestUnit)
  if ShouldUnitBeBlessed(currentBlessingTestUnit) and valMyBless < durLowestBless then
    whoLowestBless = currentBlessingTestUnit
	  durLowestBless = valMyBless
  end
	
  end
	
	--Self
	currentBlessingTestUnit = "player"
	valMyBless = MyBlessing(currentBlessingTestUnit)
  if ShouldUnitBeBlessed(currentBlessingTestUnit) and valMyBless < durLowestBless then
    whoLowestBless = currentBlessingTestUnit
	  durLowestBless = valMyBless
  end

  return whoLowestBless, durLowestBless
end
















--prints who has the least time on their blessing
function EchoBlessMin()
  alphaBless, bataBless = FindMinDurationBlessing()
	if alphaBless and bataBless then
	  dprint( UnitName(alphaBless) .. " has " .. round(bataBless/60,-2) .. " mins left")
	end 
end


















































--Totem Durations

function GetFireTotem()
  local _,FIRE_TOTEM,FIRE_GET,FIRE_DUR,_ = GetTotemInfo(1)
	if type(FIRE_GET)=="number" and type(FIRE_DUR)=="number" and ( FIRE_GET + FIRE_DUR - GetTime() )>=0 then
	  return ( FIRE_GET + FIRE_DUR - GetTime() )
	else
	  return (nil)
	end 
end 






function GetEarthTotem()
  local _,EARTH_TOTEM,EARTH_GET,EARTH_DUR,_ = GetTotemInfo(2)
	if type(EARTH_GET)=="number" and type(EARTH_DUR)=="number" and ( EARTH_GET + EARTH_DUR - GetTime() )>=0 then
	  return ( EARTH_GET + EARTH_DUR - GetTime() )
	else
	  return (nil)
	end 
end 






function GetWaterTotem()
  local _,WATER_TOTEM,WATER_GET,WATER_DUR,_ = GetTotemInfo(3)
	if type(WATER_GET)=="number" and type(WATER_DUR)=="number" and ( WATER_GET + WATER_DUR - GetTime() )>=0 then
	  return ( WATER_GET + WATER_DUR - GetTime() )
	else
	  return (nil)
	end 
end 






function GetAirTotem()
  local _,AIR_TOTEM,AIR_GET,AIR_DUR,_ = GetTotemInfo(4)
	if type(AIR_GET)=="number" and type(AIR_DUR)=="number" and ( AIR_GET + AIR_DUR - GetTime() )>=0 then
	  return ( AIR_GET + AIR_DUR - GetTime() )
	else
	  return (nil)
	end 
end 





















-- copyed from _Display/BDisplay.lua
function PlayerMoving()
  if t_Moving and abs( GetTime()-t_Moving ) <0.1 then
    return (GetTime()-t_Moving)
  end
	return (false)
end