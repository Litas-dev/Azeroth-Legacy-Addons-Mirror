-- UIErrorsFrame:AddMessage("msg",0,1,.5,1,2)
-- string.find( UnitDebuff("target",i),sDebuffName )
-- DEFAULT_CHAT_FRAME:AddMessage("woot!"   ,1/16,12/16,7/16)
-- DEFAULT_CHAT_FRAMEScrollToBottom()

-- Information.lua








function ListImportantVariables()
  dprint(" SingularityTrack " .. ColorText(1,0,0) .. " set to name of buff you wish to track for Singularity Warning" )
	dprint(" imabigcowstinks " .. ColorText(1,0,0) .. " set true to prevent J key from summoning a random pet" )
  dprint(" d_AntiSpam " .. ColorText(1,0,0) .. " set true to enable # in unrecognized UIErrorsFrame_OnEvents")
	dprint(" MinDispPercent " .. ColorText(1,0,0) .. " set to percent number for displaying large dmg on player (default 11) ")
	dprint(" hide_customsearchs " .. ColorText(1,0,0) .. " set true to disable Interrupt, Resist and Immune messages from EventFinder ")
end










-- very difference from crit immune
function CrushImmuneStatus()
  DEFAULT_CHAT_FRAME:AddMessage("Need 102.4 combined avoidance. Currently at:",0.8,0.8,1)
  DEFAULT_CHAT_FRAME:AddMessage(5+GetDodgeChance()+GetParryChance()+GetBlockChance()+ (GetCombatRating(CR_DEFENSE_SKILL)*150/355 + 0)*0.04 ,1,0.5,0)
end
































-- Maive Foxfire
-- Maurie Hottank








function ListGearValue(unitName)
	DEFAULT_CHAT_FRAMEScrollToBottom()
	itemList = {}
  
	if type(unitName)~="string" then
		unitName = "player"
	end

	for i=1,19 do
		itemList[i] = {}
		itemList[i]["slotID"] = i
		GLi , IQi = GearLevel(i,unitName)
		itemList[i]["level"] = GLi
		--GIIQi = GetInventoryItemQuality(unitName,i)
		GIIQi = IQi
		itemList[i]["quality"] = GIIQi
		
		--printcat(i, GLi , GIIQi , IQi )
		
		if GIIQi==0 or GIIQi==1 then
			itemList[i]["value"] = (GLi-6.5)/2.5
		elseif GIIQi==2 then
			itemList[i]["value"] = (GLi-4)/2
		elseif GIIQi==3 then
			itemList[i]["value"] = (GLi-1.84)/1.6
		elseif GIIQi==4 then
			itemList[i]["value"] = (GLi-1.3)/1.3
		elseif GIIQi==5 or GIIQi==6 then
			itemList[i]["value"] = (GLi-0.7)/1
		else 
			itemList[i]["value"] = -1
		end
		
		--echo( i .. "  " .. itemList[i]["level"] .. "  " .. itemList[i]["slotID"] )
	end

  table.sort(itemList , function(a,b) return a["value"]<b["value"] end)

	for j=19,1,-1 do
		GLi , GIIQj = GearLevel(itemList[j]["slotID"],unitName)
		
	--	if GetInventoryItemQuality(unitName, itemList[j]["slotID"] ) then
		if GIIQj then
			itemName, itemLink, itemRarity, itemLevel, itemMinLevel, itemType, itemSubType, itemStackCount,itemEquipLoc, itemTexture = GetItemInfo( GetInventoryItemLink(unitName, itemList[j]["slotID"]) )
			r, g, b, hex = GetItemQualityColor(itemRarity)
			DEFAULT_CHAT_FRAME:AddMessage(j .. " " .. itemLink .. " \124cFFFF0000 " .. itemLevel )
		end
	end

end




























function ListGearLevel()
  DEFAULT_CHAT_FRAMEScrollToBottom()
  itemList = {}

  for i=1,19 do
    itemList[i] = {}
    itemList[i]["slotID"] = i
    itemList[i]["level"] = GearLevel(i)
  --echo( i .. "  " .. itemList[i]["level"] .. "  " .. itemList[i]["slotID"] )
  end

  table.sort(itemList , function(a,b) return a["level"]<b["level"] end)

  for j=19,1,-1 do
    if GetInventoryItemQuality("player", itemList[j]["slotID"] ) then
      itemName, itemLink, itemRarity, itemLevel, itemMinLevel, itemType, itemSubType, itemStackCount,itemEquipLoc, itemTexture = GetItemInfo( GetInventoryItemLink("player", itemList[j]["slotID"]) )
      r, g, b, hex = GetItemQualityColor(itemRarity)
      DEFAULT_CHAT_FRAME:AddMessage(j .. " " .. itemLink .. " \124cFFFF0000 " .. itemLevel )
    end
  end

end





--[[
function SortGearLevel()
  DEFAULT_CHAT_FRAMEScrollToBottom()
  itemList = {}

  for i=1,19 do
    itemList[i] = {}
    itemList[i]["slotID"] = i
    itemList[i]["level"] = GearLevel(i)
  end

  table.sort(itemList , function(a,b) return a["level"]<b["level"] end)

  for i=1,19 do
    echo( i .. "  " .. itemList[i]["level"] .. "  " .. itemList[i]["slotID"] )
  end
end
]]--









function GearLevel(gearslot,unitName)
	if type(unitName)~="string" then
		unitName = "player"
	end
	if GetInventoryItemLink(unitName, gearslot)==nil then return (-1) end
	itemName, itemLink, itemRarity, itemLevel, itemMinLevel, itemType, itemSubType, itemStackCount,itemEquipLoc, itemTexture = GetItemInfo( GetInventoryItemLink(unitName, gearslot) )
	return itemLevel , itemRarity
end



















function ListWeaponSkills()
  DEFAULT_CHAT_FRAMEScrollToBottom()
  skillList = {}

  for skillIndex=1,GetNumSkillLines() do
    skillName, isHeader, isExpanded, skillRank, numTempPoints, skillModifier, skillMaxRank, isAbandonable, stepCost, rankCost, minLevel, skillCostType, skillDescription = GetSkillLineInfo(skillIndex)
      skillList[skillIndex] = {}
      skillList[skillIndex]["skillName"] = skillName
      skillList[skillIndex]["skillRank"] = skillRank
      skillList[skillIndex]["skillDescription"] = skillDescription
  end

  table.sort(skillList, function(a,b) return a["skillRank"]>b["skillRank"] end)

  for skillIndex=1,GetNumSkillLines() do
    if skillList[skillIndex]["skillDescription"] and string.find( skillList[skillIndex]["skillDescription"], "your chance to hit." ) and skillList[skillIndex]["skillRank"] and skillList[skillIndex]["skillRank"]<UnitLevel("player")*5 then
      DEFAULT_CHAT_FRAME:AddMessage( skillList[skillIndex]["skillRank"] .. "  " .. skillList[skillIndex]["skillName"]  )
    end
  end
end

















function ListQuests()
  ExpandAllQuestHeader()
  DEFAULT_CHAT_FRAMEScrollToBottom()
  questList = {}

  for questID=0,GetNumQuestLogEntries() do
    local questTitle, level, questTag, suggestedGroup, isHeader, isCollapsed, isComplete, isDaily = GetQuestLogTitle(questID);
    questList[questID] = {}
    questList[questID]["questTitle"] = questTitle
    questList[questID]["level"] = level
    questList[questID]["questID"] = questID
  end
  
  table.sort(questList, function(a,b) return a["level"]>b["level"] end)

	
	dprint("------------------------",1,0,0)

  for k,v in pairs(questList) do
    local questTitle, level, questTag, suggestedGroup, isHeader, isCollapsed, isComplete, isDaily = GetQuestLogTitle(v["questID"]);

    if questTag then
      questTag = strsub(questTag,1,1)
    else
      questTag = ""
    end

    if isComplete then
      suffix = ColorText(1,.5,1) .. " complete" .. ColorText()
    else
      suffix = " "
    end
		
		if isDaily then
      suffix = suffix .. ColorText(1,0,1) .. " Daily" .. ColorText()
    else
      suffix = suffix
    end

    if questTitle and not isHeader then
      dprint(questTitle.." "..ColorText(ReturnColorForLevel(level)).."[" ..level..questTag.."]\124r".." "..suffix)
    end
  end
end


-- "\124r"








function ExpandAllQuestHeader()
  local questID = 1
  while GetQuestLogTitle(questID) do
    local questTitle, _, questTag, _, isHeader, isCollapsed = GetQuestLogTitle(questID);
    if isCollapsed then
      ExpandQuestHeader(questID)
    end
    questID = questID + 1
  end
end

















function ReturnColorForLevel(tLevel,pLevel)
  if not pLevel then pLevel = UnitLevel("player") end

  if tLevel >= pLevel +5 then return 1,0,0 end
  if tLevel > pLevel +2 then return 1,.5,0 end
  if tLevel >= pLevel -2 then return 1,1,0 end
  if tLevel >= pLevel -GetQuestGreenRange() then return 0,.5,0 end
  if tLevel >= 0 then return .5,.5,.5 end
  return 0,0,0
end




function ColorTextByLevel(level,pLevel)
  return ColorText(ReturnColorForLevel(level,pLevel))
end


































































-- http://www.wowwiki.com/Formulas:Damage_reduction

function DefensiveStats()
  DEFAULT_CHAT_FRAMEScrollToBottom()
	
  DEFAULT_CHAT_FRAME:AddMessage("Armor Midigation:  " .. round( ArmorReducePhysical() ,-3) .."%" )
	
  DEFAULT_CHAT_FRAME:AddMessage("Dodge:  " .. round(GetDodgeChance() ,-3) .."%" )
	if GetParryChance()>0 then
    DEFAULT_CHAT_FRAME:AddMessage("Parry:  " .. round(GetParryChance() ,-3) .."%" )
	end
	if GetBlockChance()>0 then
    DEFAULT_CHAT_FRAME:AddMessage("Block:  " .. round(GetBlockChance() ,-3) .."%" )
	end
	DEFAULT_CHAT_FRAME:AddMessage("Total Avoidance:  " .. round(GetDodgeChance()+GetParryChance()+GetBlockChance() ,-3) .."%" )
	
	DEFAULT_CHAT_FRAME:AddMessage("Total Reduction:  " .. round( 100 - ( 1 - ArmorReducePhysical()/100 ) * ( 1 - (GetDodgeChance()+GetParryChance() +GetBlockChance())/100 )*100 ,-3 ) .. "%")
end





function MaxReductionLevel(v_Armor)
  DEFAULT_CHAT_FRAMEScrollToBottom()
	
	if type(v_Armor)=="number" then
	  effectiveArmor = v_Armor
	else
    baseArmor, effectiveArmor, armor, posBuff, negBuff = UnitArmor("player");
	end
	
	if ( effectiveArmor/(75/100) - effectiveArmor - 400 )/85 <= 60 then
    max_level = ( effectiveArmor/(75/100) - effectiveArmor - 400 ) /85
	else
	  max_level = ( effectiveArmor/(75/100) - effectiveArmor + 22167.5 ) /467.5
	end
	
	DEFAULT_CHAT_FRAME:AddMessage("With " ..effectiveArmor.. " armor you can tank mobs upto level " ..max_level.. " with maximum midigation (75%)")
end







function ArmorReducePhysical(u_armor,u_level)
  baseArmor, effectiveArmor, armor, posBuff, negBuff = UnitArmor("player");
  if not u_level then u_level = UnitLevel("player") end
  if not u_armor then u_armor = effectiveArmor end

  if u_level <60 then
    return ( u_armor / ( u_armor + 400 + 85 * u_level )) * 100
  else
    return ( u_armor / ( u_armor - 22167.5 + 467.5 * u_level )) * 100
  end
end









function TheoryCraftPlus(hitvalue,blockvalue)
  if not hitvalue then
    hitvalue = 1
  end
  if not blockvalue then
    blockvalue = 0
  end

  armor_pct = (100 - ArmorReducePhysical() ) /100
  avoid_pct = (100 - GetDodgeChance()+GetParryChance() ) /100
  block_pct = (100 - GetBlockChance()*blockvalue/hitvalue ) /100
  
  hitavg = hitvalue * armor_pct * avoid_pct * block_pct
  
  hittotal = UnitHealthMax("player")/hitavg

  DEFAULT_CHAT_FRAME:AddMessage(hittotal)
end









































function echoStats()
  baseDefense, armorDefense = UnitDefense("player")
  armorMidigation = ArmorReducePhysical()
  dodge = GetDodgeChance()
  parry = GetParryChance()
  block = GetBlockChance()
  baseArmor, effectiveArmor, armor, posBuff, negBuff = UnitArmor("player")
  max_health = UnitHealthMax("player")
	
	round_value = -4

  dprint("Armor: ".. round( ArmorReducePhysical() ,round_value) .."%    Dodge&Parry: ".. round( GetDodgeChance()+GetParryChance() ,round_value) .."%   Block: ".. round( GetBlockChance() ,round_value).."%" )
end


--  dprint( GetDodgeChance()+GetParryChance()+GetBlockChance() )






























































function targetTalents(display)
  if GetNumTalentTabs(true)~=3 then return nil end
	
	local name1, _, pointsSpent1, _ = GetTalentTabInfo( 1 , true )
	local name2, _, pointsSpent2, _ = GetTalentTabInfo( 2 , true )
	local name3, _, pointsSpent3, _ = GetTalentTabInfo( 3 , true )
	
	total_talents = pointsSpent1 + pointsSpent2 + pointsSpent3
	
	if total_talents>0 and display and name1 and pointsSpent1 and UnitName("target") and name3 and pointsSpent3 then
	--  DEFAULT_CHAT_FRAME:AddMessage(name1 .. ' ' .. pointsSpent1)
	--	DEFAULT_CHAT_FRAME:AddMessage(name2 .. ' ' .. pointsSpent2)
	--	DEFAULT_CHAT_FRAME:AddMessage(name3 .. ' ' .. pointsSpent3)
    DEFAULT_CHAT_FRAME:AddMessage( UnitName("target").. "  " .. name1 .. " " .. pointsSpent1 .. "  ".. name2 .. " " .. pointsSpent2 .. "  " .. name3 .. " " .. pointsSpent3 )
	end
	
	return (name1 .. pointsSpent1 .. ' ' .. name2 .. pointsSpent2 .. ' ' .. name3 .. pointsSpent3)

end











































































function GuildFind(s_name)
  GuildRoster()
  SetGuildRosterShowOffline(true)
  if not s_name then return s_name end

  SortGuildRoster("name") ; SortGuildRoster("level") ; SortGuildRoster("rank") 
  name, rank, rankIndex, level, class, zone, note, officernote, online, status = GetGuildRosterInfo(1)
  if rankIndex~=0 then SortGuildRoster("rank") end

  echo("\124cFFFFFFFF".. "--"..s_name.."--")
  for index=1,GetNumGuildMembers(true) do
    name, rank, rankIndex, level, class, zone, note, officernote, online, status = GetGuildRosterInfo(index)
    if name and ( string.find(s_name,name) or string.find(name,s_name) ) then
      echo("<"..index.."> "..name.." ["..level.." "..class.."]\124cFFFFFF00 "..note)
    elseif note and string.find(note,s_name) then
      echo("<"..index.."> "..name.." ["..level.." "..class.."]\124cFFFFFF00 "..note)
    end
  end
end







function officernote()
  for index=1,GetNumGuildMembers(true) do
    name, rank, rankIndex, level, class, zone, note, officernote, online, status = GetGuildRosterInfo(index)
    if officernote and strlen(officernote) and strlen(officernote)>0 then
      echo("<"..index.."> "..name.." ["..level.." "..class.."]\124cFFFFFF00 "..officernote )
    end 
  end 
end







--[[
function FriendGuild()
  SetGuildRosterShowOffline(true)
  GuildRoster()
  ShowFriends()

  for index=1,GetNumGuildMembers(true) do

    name, rank, rankIndex, level, class, zone, note, officernote, online, status = GetGuildRosterInfo(index)
    if level>=70 and not IsFriend(name) then
      echo("\124cFFFFFF00Inviting: " .. index .."  "..name .. "  "..level)
      AddFriend(name) 
    elseif IsFriend(name) then
      echo("\124cFF0000FFIsFriend: " .. index .."  "..name .. "  "..level)
    elseif level<70 then
      echo("\124cFF000000Under 70: " .. index .."  "..name .. "  "..level)
    end 

  end
end
]]--







function IsFriend(p_name)
  if not p_name then return p_name end
  for friendIndex=1,GetNumFriends() do
    name, level, class, area, connected, status = GetFriendInfo(friendIndex)
    if name and name==p_name then return friendIndex end
  end
  return nil
end
















function ZoneInfo()
  echo( "RealZoneText \124cFFFFFFFF " ..GetRealZoneText() )
  echo( "ZoneText \124cFFFFFFFF " ..GetZoneText() )
  echo( "MinimapZoneText \124cFFFFFFFF " ..GetMinimapZoneText() )
  echo( "SubZoneText \124cFFFFFFFF " ..GetSubZoneText() )
end





























function echoProspecting()
  DEFAULT_CHAT_FRAMEScrollToBottom()
  echoProspectingCopper()
  echoProspectingTin()
  echoProspectingIron()
  echoProspectingMithril()
  echoProspectingThorium()
end



function echoProspectingCopper()
  echo("\124cFFB87333Copper:  \124cFFFF7F00Tigerseye 50% \124cFF0BDA51Malachite 50% \124cFFFF00FFShadowgem 10%")
end

function echoProspectingTin()
  echo("\124cFF808080Tin:  \124cFF00FF00Moss Agate 37% \124cFFFF00FFShadowgem 37% \124cFF00FFFFLesser Moonstone 37% \124cFFD2691ECitrine 3% \124cFF00A86BJade 3% \124cFF7FFFD4Aquamarine 3%")
end

function echoProspectingIron()
  echo("\124cFF708090Iron:  \124cFF00A86BJade 30% \124cFF00FFFFLesser Moonstone 30% \124cFFD2691ECitrine 30% \124cFFFF0000Star Ruby 5% \124cFF7FFFD4Aquamarine 5%")
end

function echoProspectingMithril()
  echo("\124cFF99FFFFMithril:  \124cFFFF0000Star Ruby 33% \124cFFD2691ECitrine 33% \124cFF7FFFD4Aquamarine 33% \124cFFFFFFFFAzerothian Diamond 3% \124cFF50C878Huge Emerald 3% \124ccFFCC550Large Opal 3% \124cFF0000FFBlue Sapphire 3%")
end

function echoProspectingThorium()
  echo("\124cFFD0F0C0Thorium:  \124cFFFF0000Star Ruby 30% \124cFFFFFFFFAzerothian Diamond 16% \124cFF50C878Huge Emerald 16% \124ccFFCC550Large Opal 16% \124cFF0000FFBlue Sapphire 16%  \124cFF000000Outland Gems 2%")
end






































--name, rank, icon, count, debuffType, duration, expirationTime, _, isStealable = UnitBuff(

function HasBlessingOf(sunit,nBlessing)
  for buffIndex=1,80 do
    name, rank, iconTexture, count, debuffType, duration, expirationTime = UnitBuff(sunit,buffIndex);
    if type(name)=="string" and strfind(name,"Blessing of "..nBlessing) then
      return buffIndex
    end
  end
  return false
end








































































function Aspect()
  if PlayerBuff("Aspect of the Monkey")~=0 then
	  return "Aspect of the Monkey"
	elseif PlayerBuff("Aspect of the Hawk")~=0 then
	  return "Aspect of the Hawk"
	elseif PlayerBuff("Aspect of the Cheetah")~=0 then
	  return "Aspect of the Cheetah"
	elseif PlayerBuff("Aspect of the Beast")~=0 then
	  return "Aspect of the Beast"
	elseif PlayerBuff("Aspect of the Viper")~=0 then
	  return "Aspect of the Viper"
	elseif PlayerBuff("Aspect of the Pack")~=0 then
	  return "Aspect of the Pack"
	elseif PlayerBuff("Aspect of the Wild")~=0 then
	  return "Aspect of the Wild"
    elseif PlayerBuff("Aspect of the Dragonhawk")~=0 then
	  return "Aspect of the Dragonhawk"
	end
	return (nil)
end




































































function RowylHerbs()
  dprint("====================",0,0,0)
	
  EchoRowylHerb("Unidentified Plant Parts")
  EchoRowylHerb("Un'Goro Soil")
  EchoRowylHerb("Sanguine Hibiscus")
  EchoRowylHerb("Packet of Tharlendris Seeds")
  EchoRowylHerb("Glowcap")
  EchoRowylHerb("Enriched Lasher Root")
  EchoRowylHerb("Bloodthistle Petal")
  EchoRowylHerb("Bloodthistle")
  EchoRowylHerb("Green Tea Leaf")
  EchoRowylHerb("Heart of the Wild")
  EchoRowylHerb("Morrowgrain")
  EchoRowylHerb("Whipper Root Tuber")
  EchoRowylHerb("Night Dragon's Breath")
  EchoRowylHerb("Thornling Seed")
  EchoRowylHerb("Bloodvine")
  
  EchoRowylHerb("Mote of Life")
  EchoRowylHerb("Primal Life")
  
  EchoRowylHerb("Fel Blossom")
  EchoRowylHerb("Flame Cap")
  EchoRowylHerb("Netherdust Pollen")
  EchoRowylHerb("Nightmare Seed")
  
  EchoRowylHerb("Fire Seed")
  EchoRowylHerb("Fire Leaf")
  
  EchoRowylHerb("Crystallized Life")
  EchoRowylHerb("Eternal Life")
  
  dprint("====================",0,0,0)
  
  EchoRowylHerb("Peacebloom") --5 req 1
	EchoRowylHerb("Silverleaf") --5 req 1
  EchoRowylHerb("Earthroot")  --5 req 15
	
	EchoRowylHerb("Mageroyal") --10 req 50
	
	EchoRowylHerb("Swiftthistle") --15
	EchoRowylHerb("Briarthorn") --15 req 70
	
	EchoRowylHerb("Stranglekelp") --20 req 85
  EchoRowylHerb("Bruiseweed") --20 req 100
	
	EchoRowylHerb("Wild Steelbloom") --22 req 115
	
  EchoRowylHerb("Grave Moss") --24 req 120
	EchoRowylHerb("Kingsblood") --24 req 125
	
	EchoRowylHerb("Liferoot") --30
	EchoRowylHerb("Fadeleaf") --32
	EchoRowylHerb("Goldthorn") --34
	EchoRowylHerb("Khadgar's Whisker") -- 37
	EchoRowylHerb("Wintersbite") --39
	EchoRowylHerb("Wildvine") --40
	EchoRowylHerb("Firebloom") --41
	EchoRowylHerb("Purple Lotus") --42
	EchoRowylHerb("Arthas' Tears") --44
	EchoRowylHerb("Sungrass") --46
  
	EchoRowylHerb("Blindweed") --47 req 235
	EchoRowylHerb("Ghost Mushroom") --47 req 245
	
	EchoRowylHerb("Gromsblood") --50
	EchoRowylHerb("Golden Sansam") --52
	EchoRowylHerb("Dreamfoil") --54
  EchoRowylHerb("Mountain Silversage") --56
	EchoRowylHerb("Plaguebloom") --57
	EchoRowylHerb("Icecap") --58
  EchoRowylHerb("Black Lotus") --60 req 300
	
	EchoRowylHerb("Felweed") --60 req 300
	EchoRowylHerb("Dreaming Glory") --60 req 315
	EchoRowylHerb("Terocone") --60 req 325
	
	EchoRowylHerb("Ragveil") --65
	EchoRowylHerb("Ancient Lichen") --68
	EchoRowylHerb("Netherbloom") --70 
	EchoRowylHerb("Nightmare Vine") --73 (70)
	
	EchoRowylHerb("Mana Thistle") --75 req 375 (70)
	EchoRowylHerb("Fel Lotus") --75 (70)
  
  EchoRowylHerb("Goldclover") -- 72 req 350
  EchoRowylHerb("Talandra's Rose") --72 req 385
  EchoRowylHerb("Tiger Lily") --72 req 400
  EchoRowylHerb("Deadnettle") --72
  
  EchoRowylHerb("Constrictor Grass") --75
  EchoRowylHerb("Adder's Tongue") --77 req 400
  
  EchoRowylHerb("Lichbloom") --80 req 425
  EchoRowylHerb("Icethorn") --80 req 435
  EchoRowylHerb("Frost Lotus") --80
end


function EchoRowylHerb(nHerb)
  if GetItemCount(nHerb,true)>0 then
    dprint( RowylColorHerb(nHerb) .. GetItemCount(nHerb,true) .. "  " .. nHerb ) 
  end
end

function RowylColorHerb(nHerb)
  local _, _, _, _, _, _, _, itemStackCount, _, _ = GetItemInfo(nHerb)
  if GetItemCount(nHerb,true) <=itemStackCount then
    return ColorText(1,1,1) --white
  elseif GetItemCount(nHerb,true) <=itemStackCount*2 then
    return ColorText(1/2,1/2,1) --blue
  elseif GetItemCount(nHerb,true) <=itemStackCount*3 then
    return ColorText(0,1,0) --green
  elseif GetItemCount(nHerb,true) <=itemStackCount*4 then
    return ColorText(1,1,0) --yellow
  elseif GetItemCount(nHerb,true) <=itemStackCount*5 then
    return ColorText(1,1/2,0) -- orange
  end
    return ColorText(1,0,0) --red
end 


--[[
function RowylColorHerb(nHerb)
  bluegreen = max(  min( (GetItemCount(nHerb,true)-20)/40 ,1)  ,0)
	red = bluegreen
	bluegreen = 1-bluegreen
  return ColorText(1,bluegreen,bluegreen) 
end 
]]--













































function MageManaGem()
  gem_count = GetItemCount("Mana Agate") + GetItemCount("Mana Jade") + GetItemCount("Mana Citrine") + GetItemCount("Mana Ruby") + GetItemCount("Mana Emerald")
	return (gem_count) 
end



function MageManaGemName()
  if GetItemCount("Mana Emerald")>0 then
	  return "Mana Emerald"
	elseif GetItemCount("Mana Ruby")>0 then
	  return "Mana Ruby"
	elseif GetItemCount("Mana Citrine")>0 then
	  return "Mana Citrine"
	elseif GetItemCount("Mana Jade")>0 then
	  return "Mana Jade"
	elseif GetItemCount("Mana Agate")>0 then
	  return "Mana Agate"
	end
end











































-- http://www.wowwiki.com/Instances_by_Level

function InstancesByLevel(Lvl)
  if not Lvl then Lvl = UnitLevel("player") end
	
	if Lvl >=8  then dprint("Ragefire Chasm "..ColorTextByLevel( (13+16)/2 ,Lvl).." 13-16") end
	if Lvl >=10 then dprint("Wailing Caverns "..ColorTextByLevel( (17+20)/2 ,Lvl).." 17-20") end
	if Lvl >=10 then dprint("The Deadmines "..ColorTextByLevel( (17+20)/2 ,Lvl).." 17-20") end
	if Lvl >=10 then dprint("Shadowfang Keep "..ColorTextByLevel( (18+21)/2 ,Lvl).." 18-21") end
	if Lvl >=19 then dprint("Blackfathom Deeps "..ColorTextByLevel( (21+24)/2 ,Lvl).." 21-24") end
	if Lvl >=15 then dprint("Stormwind Stockade "..ColorTextByLevel( (23+25)/2 ,Lvl).." 23-25") end
	if Lvl >=17 then dprint("Razorfen Kraul "..ColorTextByLevel( (24+27)/2 ,Lvl).." 24-27") end
	if Lvl >=15 then dprint("Gnomeregan "..ColorTextByLevel( (25+28)/2 ,Lvl).." 25-28") end
	if Lvl >=20 then dprint("Scarlet Monastery: Graveyard "..ColorTextByLevel( (30+32)/2 ,Lvl).." 30-32") end
	if Lvl >=20 then dprint("Scarlet Monastery: Library "..ColorTextByLevel( (33+35)/2 ,Lvl).." 33-35") end
	if Lvl >=20 then dprint("Scarlet Monastery: Armory "..ColorTextByLevel( (35+37)/2 ,Lvl).." 35-37") end
	if Lvl >=20 then dprint("Scarlet Monastery: Cathedral "..ColorTextByLevel( (36+40)/2 ,Lvl).." 36-40") end
	if Lvl >=25 then dprint("Razorfen Downs "..ColorTextByLevel( (34+37)/2 ,Lvl).." 34-37") end
	if Lvl >=30 then dprint("Uldaman "..ColorTextByLevel( (36+40)/2 ,Lvl).." 36-40") end
	if Lvl >=35 then dprint("Zul'Farrak "..ColorTextByLevel( (43+46)/2 ,Lvl).." 43-46") end
	if Lvl >=35 then dprint("Maraudon "..ColorTextByLevel( (43+48)/2 ,Lvl).." 43-48") end
	if Lvl >=35 then dprint("Temp of Atal'Hakkar "..ColorTextByLevel( (47+50)/2 ,Lvl).." 47-50") end
	if Lvl >=40 then dprint("Blackrock Depths "..ColorTextByLevel( (48+56)/2 ,Lvl).." 48-56") end
	if Lvl >=45 then
	  dprint("Dire Maul: East "..ColorTextByLevel( (55+58)/2 ,Lvl).." 55-58")
		dprint("Lower Blackrock Spire "..ColorTextByLevel( (54+60)/2 ,Lvl).." 54-60")
		dprint("Dire Maul: West/North "..ColorTextByLevel( (57+60)/2 ,Lvl).." 57-60")
		dprint("Stratholme/Scholomance/Upper Blackrock Spire "..ColorTextByLevel( (58+60)/2 ,Lvl).." 58-60")
	end
end






































function CalcArenaPoints(rating,size)
  if rating>1500 then
    points = 1511.26/( 1+1639.28*Power( 2.71828, -0.00412*rating ) ) 
  else
		points = 0.22*rating+14
	end 
	if strfind(size,"3") then
	  points = points*0.88
		size = "3v3"
	elseif strfind(size,"2") then
	  points = points*0.76
		size = "2v2"
	else
	  size = "5v5"
	end
	
	--dprint("Rating of "..rating.." gets ".. points .. " in a " ..size .. " team")
	return points , size
end




function ArenaPoints()
  local teamName, teamSize, teamRating, weekPlayed, weekWins, seasonPlayed, seasonWins, playerPlayed, seasonPlayerPlayed, teamRank, playerRating = GetArenaTeam(1);
  team1 = CalcArenaPoints(playerRating,teamSize)
	
	local teamName, teamSize, teamRating, weekPlayed, weekWins, seasonPlayed, seasonWins, playerPlayed, seasonPlayerPlayed, teamRank, playerRating = GetArenaTeam(2);
	team2 = CalcArenaPoints(playerRating,teamSize)
	
	local teamName, teamSize, teamRating, weekPlayed, weekWins, seasonPlayed, seasonWins, playerPlayed, seasonPlayerPlayed, teamRank, playerRating = GetArenaTeam(3);
	team3 = CalcArenaPoints(playerRating,teamSize)
	
	if team1>=team2 and team1>=team3 then
	  return (team1)
	elseif team2>=team3 and team2>=team1 then
	  return (team2)
	elseif team3>=team2 and team3>=team1 then
	  return (team3)
	end
end

































function CurrentVanityPet()
  if GetItemCount("Haunted Memento")==1 then
    return "Haunted Memento"
	elseif GetItemCount("Oracle Orphan Whistle")==1 then
    return "Oracle Orphan"
	elseif GetItemCount("Wolvar Orphan Whistle")==1 then
    return "Orphan"
  end
	
  for i_critter=1, GetNumCompanions("critter") do
    local creatureID, creatureName, creatureSpellID, icon, issummoned = GetCompanionInfo("critter",i_critter)
    if issummoned then
      return creatureName
    end 
  end 
  return false
end 


function CallRandomVanityPet()
  for snowballcheck=1,12 do
    local randcrit = floor(random()*GetNumCompanions("critter")+1)
    local creatureID, creatureName, creatureSpellID, icon, issummoned = GetCompanionInfo("critter",randcrit)
    if not PetRequiresSnowBall(creatureName) then
      CallCompanion("critter", randcrit )
      local _, creatureName = GetCompanionInfo("critter",randcrit)
      return creatureName
    end
  end
end


function PetRequiresSnowBall(pName)
  if pName=="Father Winter's Helper" or pName=="Tiny Snowman" or pName=="Winter Reindeer" or pName=="Winter's Little Helper" then
    return 1
  else
    return false
  end
end
































































function PrintAchievementInfo()
  for CategoryID=0,2^14 do
    Title, ParentCategoryID, Something = GetCategoryInfo(CategoryID)
    if Title then
    
    
    
      echo(Title..CategoryID)
      
      
      
    end
  end
end




function PrintAchievementList()
  for achievementID=0,2^14 do
    PrintAchievementID(achievementID)
  end 
end





function PrintAchievementID(achievementID)
  if achievementID then
    IDNumber, Name, Points, Completed, Month, Day, Year, Description, Flags, Image, RewardText = GetAchievementInfo(achievementID)
    if IDNumber and Name then
      DEFAULT_CHAT_FRAME:AddMessage( IDNumber .. ColorText(1/16,12/16,7/16) .. Name)
    end
  end
end






function SearchAchievementList()
  for achievementID=0,2^14 do
    IDNumber, Name, Points, Completed, Month, Day, Year, Description, Flags, Image, RewardText = GetAchievementInfo(achievementID)
    if IDNumber and Name and strfind(Name,"kill") then
    
      DEFAULT_CHAT_FRAME:AddMessage( IDNumber .. ColorText(1/16,12/16,7/16) .. Name)
      
    end
  end 
end





































-- UIErrorsFrame:AddMessage("msg",0,1,.5,1,2)
-- string.find( UnitDebuff("target",i),sDebuffName )
-- DEFAULT_CHAT_FRAME:AddMessage("woot!")
-- DEFAULT_CHAT_FRAMEScrollToBottom()



function GemNames()
  DEFAULT_CHAT_FRAMEScrollToBottom()
  DEFAULT_CHAT_FRAME:AddMessage("Blood Garnet",1,0,0)
  DEFAULT_CHAT_FRAME:AddMessage("Flame Spessarite",1,.5,0)
  DEFAULT_CHAT_FRAME:AddMessage("Golden Draenite",1,1,0)
  DEFAULT_CHAT_FRAME:AddMessage("Deep Peridot",0,1,0)
  DEFAULT_CHAT_FRAME:AddMessage("Azure Moonstonet",.25,.25,1)
  DEFAULT_CHAT_FRAME:AddMessage("Shadow Draenite",1,0,1)
  DEFAULT_CHAT_FRAME:AddMessage("Jaggal Pearl",1,1,1) 
end






function Herbs()
  DEFAULT_CHAT_FRAMEScrollToBottom()
  DEFAULT_CHAT_FRAME:AddMessage("Peacebloom	1")
  DEFAULT_CHAT_FRAME:AddMessage("Silverleaf	1")
  DEFAULT_CHAT_FRAME:AddMessage("Earthroot	15")
  DEFAULT_CHAT_FRAME:AddMessage("Mageroyal	50")
  DEFAULT_CHAT_FRAME:AddMessage("Briarthorn	70")

end















-- ****** Arathi Basin ******

-- Blacksmith  46.269  45.338
-- Lumbermill  40.355  55.757
-- Farm        56.067  60.014
-- Stables     37.438  29.121
-- Gold Mine   57.551  30.815





-- arguments should be 0 to 100
function MapDistance(x1,y1,x2,y2)
  local px, py = GetPlayerMapPosition("player");
  if x2 and y2 then
    return sqrt( (x1-x2)^2 + (y1-y2)^2 )
  elseif x1 and y1 then
    return sqrt( (x1-px*100)^2 + (y1-py*100)^2 )
  else
    return -1
  end
end


-- Lumbermill
function AB_LM()
  return MapDistance(40.355,55.757)
end

-- Blacksmith
function AB_BS()
  return MapDistance(46.269,45.338)
end

-- Gold mine
function AB_GM()
  return MapDistance(57.551,30.815)
end

-- Stables
function AB_SB()
  return MapDistance(37.438,29.121)
end

-- Farm
function AB_FM()
  return MapDistance(56.067,60.014)
end



function AB_Nearest(arg)
  if BattleGround()~=20 then return end
  if     AB_LM()<AB_SB() and AB_LM()<AB_FM() and AB_LM()<AB_BS() then
    loc_name= "Lumber Mill"
  elseif AB_SB()<AB_BS() and AB_SB()<AB_LM() and AB_SB()<AB_GM() then
    loc_name= "Stables"
  elseif AB_GM()<AB_SB() and AB_GM()<AB_BS() and AB_GM()<AB_FM() then
    loc_name= "Gold Mine"
  elseif AB_FM()<AB_GM() and AB_FM()<AB_BS() and AB_FM()<AB_LM() then
    loc_name= "Farm"
  else
    loc_name= "Blacksmith"
  end
  if arg and xtimer("_737",3) then echo( loc_name ) end
  return loc_name
end






function AB_Help()
  if BattleGround()==20 and AB_Nearest() and GetMinimapZoneText() and AB_Nearest()==GetMinimapZoneText() then
    if xtimer("AB_help_test",1) then SendChatMessage( GetMinimapZoneText() .. " !!" ,"BattleGround") end
  elseif BattleGround()==20 and AB_Nearest() and GetMinimapZoneText() then
    DEFAULT_CHAT_FRAME:AddMessage( AB_Nearest() .. "   " .. GetMinimapZoneText() )
  end
end






function AB_Warning()
  my_random=random()*10
  if BattleGround()==20 and AB_Nearest() and GetMinimapZoneText() and AB_Nearest()==GetMinimapZoneText() and xtimer("AB_W",1.5) then
  
    if my_random<1 then
      SendChatMessage( GetMinimapZoneText() .. " !" ,"BattleGround")
    elseif my_random<2 then
      SendChatMessage( GetMinimapZoneText() .. " is under attack!" ,"BattleGround")
    elseif my_random<3 then
      SendChatMessage( GetMinimapZoneText() .. " needs reinforcements!" ,"BattleGround")
    elseif my_random<4 then
      SendChatMessage( "Need help at " .. GetMinimapZoneText() .. "!" ,"BattleGround")
    elseif my_random<5 then
      SendChatMessage( "Enemies spotted near " .. GetMinimapZoneText() .. "!" ,"BattleGround")
    elseif my_random<6 then
      SendChatMessage( "Danger imminent at " .. GetMinimapZoneText() .. "!" ,"BattleGround")
    elseif my_random<7 then
      SendChatMessage( "Send backup to " .. GetMinimapZoneText() .. "!" ,"BattleGround")
    elseif my_random<8 then
      SendChatMessage( GetMinimapZoneText() .. " is in danger!" ,"BattleGround")
    elseif my_random<9 then
      SendChatMessage( GetMinimapZoneText() .. " could use help!" ,"BattleGround")
    else
      SendChatMessage( GetMinimapZoneText() .. " !!" ,"BattleGround")
    end
    return my_random
  elseif BattleGround()==20 and AB_Nearest() and GetMinimapZoneText() then
    DEFAULT_CHAT_FRAMEScrollToBottom()
    DEFAULT_CHAT_FRAME:AddMessage( AB_Nearest() .. "   " .. GetMinimapZoneText() )
  end
end



















function WeeklyQuestStatus()
	ExpandAllQuestHeader()

	for questID=0,GetNumQuestLogEntries() do
		local questTitle, level, questTag, suggestedGroup, isHeader, isCollapsed, isComplete, isDaily = GetQuestLogTitle(questID);

		if type(questTitle)=="string" and strfind(questTitle," Must Die!") and level==80 and questTag=="Raid" then
			return isComplete , questTitle
		end
	end

	return nil
end















function ListLockouts()
	for index=0,GetNumSavedInstances()+1 do
		name, id, reset, difficulty, locked, extended, instanceIDMostSig, isRaid, maxPlayers, difficultyName = GetSavedInstanceInfo(index)
		if locked==true and (  isRaid or ( type(difficultyName)=="string" and not strfind(difficultyName,"5 Player") ) ) then
			printcat(name, difficultyName)
		end
	end
end












function GetUnitGearScore(nUnit)
  local Server = GetRealmName();
  local Player = UnitName(nUnit) or nUnit;

	if GS_Data and GS_Data[Server] and GS_Data[Server]["Players"] and GS_Data[Server]["Players"][Player] and GS_Data[Server]["Players"][Player]["GearScore"] then
		GSn = GS_Data[Server]["Players"][Player]["GearScore"]
		if type( GSn )=="number" then
			return GSn, GearScore_GetDate( GetUnitGearDate(Player) )
		else
			return -1 , 365
		end
	end

end






-- from GearScore
-- GearScore_GetDate(TimeStamp)

function GetUnitGearDate(nUnit)
  local Server = GetRealmName();
  local Player = UnitName(nUnit) or nUnit;

	if GS_Data and GS_Data[Server] and GS_Data[Server]["Players"] and GS_Data[Server]["Players"][Player] and GS_Data[Server]["Players"][Player]["Date"] then
		return GS_Data[Server]["Players"][Player]["Date"]
	end

end




function ListGearScores()
	mGSlist = {}
	

	if GetNumRaidMembers()>0 then
	
		for index=0, 40 do
			UnitNameRaidIndex = UnitName("raid"..index)
			if UnitNameRaidIndex then
				rawr1, rawr2 = GetUnitGearScore(UnitNameRaidIndex)
				table.insert(mGSlist, { UnitNameRaidIndex , rawr1 , rawr2 } )
				
				if not rawr1 or not rawr2 then
					printcat( UnitNameRaidIndex , rawr1, rawr2 )
				end
			end
		end
		
	else
	
			UnitNameRaidIndex = UnitName("player")
			rawr1, rawr2 = GetUnitGearScore(UnitNameRaidIndex)
			table.insert(mGSlist, { UnitNameRaidIndex , rawr1 , rawr2 } )
	
		for index=0, 5 do
			UnitNameRaidIndex = UnitName("party"..index)
			if UnitNameRaidIndex then
				rawr1, rawr2 = GetUnitGearScore(UnitNameRaidIndex)
				table.insert(mGSlist, { UnitNameRaidIndex , rawr1 , rawr2 } )
				
				if not rawr1 or not rawr2 then
					printcat( UnitNameRaidIndex , rawr1, rawr2 )
				end
			end
		end
	
	end
	
	--table.sort(mGSlist, function(a,b) if ( type(a[2])~="number" ) then return false elseif (type(b[2])~="number" ) then return true else	return (a[2]>b[2]) end end	)
	table.sort(mGSlist, function(a,b) return ( (a[2] or 0) > (b[2] or 0) ) end )

	
	for key,value in pairs(mGSlist) do
		if not value[1] then
			dprint( "value[1] missing" )
		elseif not value[2] then
			dprint( value[1] .. "  unknown" , 1,0.3,0)
		--	dprint( "value[2] missing" )
		elseif type(value[3])~="number" then
			dprint( value[1] .. "   " .. value[2] ,1,0,0)
			
		elseif ( value[3] < 3 ) then
			dprint( value[1] .. "   " .. value[2] ,0,1,0)
		elseif ( value[3] < 9 ) then
			dprint( value[1] .. "   " .. value[2] ,0,1,1)
		elseif ( value[3] < 30 ) then
			dprint( value[1] .. "   " .. value[2] ,1,1,0)
		else -- value[3] > 30
			dprint( value[1] .. "   " .. value[2] ,1,0,0)
		end
	end


end
