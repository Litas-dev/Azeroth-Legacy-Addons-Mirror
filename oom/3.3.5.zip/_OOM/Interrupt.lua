-- UIErrorsFrame:AddMessage("msg",0,1,.5,1,2)
-- string.find(UnitDebuff("target",i),sDebuffName)
-- DEFAULT_CHAT_FRAME:AddMessage("woot!")
-- DEFAULT_CHAT_FRAMEScrollToBottom() 






function Interrupt_OnEvent(arg1,arg2,arg3,arg3,arg4,arg5,arg6,arg7,arg8,arg9)
  if event=="COMBAT_LOG_EVENT_UNFILTERED" and arg2=="SPELL_CAST_FAILED" and arg4==UnitName("player") and arg10 and arg12 and strfind(arg12,"Can't do that while ") then
    --arg10 = spell name
    --arg12 = reason for spell failure (ie: Can't do that while moving)
    
    if arg10 and arg12 and IsHeal(arg10) and not strfind(arg12,"Can't do that while moving") then
      ailment = strsub( arg12, strfind(arg12,"Can't do that while ")+20 )
      --dprint("#"..ailment.."#")
      p_ailment_msg = " I am " .. ailment .. " and cannot heal"
	  
      if GetNumVisiblePartyMembers()>0 and xtimer(p_ailment_msg,20) then
        SendChatMessage(p_ailment_msg ,"PARTY")
		
      elseif xtimer(p_ailment_msg.."selfmsg",2) then
        dprint(ColorText(0.5,0.5,1)..p_ailment_msg..ColorText().. " "..arg10)
		
      end
	  
    end
    
    --dprint(arg12 ,1,0,0) --dprint(arg10 .. arg12)
  end
  
  
  if event=="COMBAT_LOG_EVENT_UNFILTERED" and arg12=="Not enough mana" and arg2=="SPELL_CAST_FAILED" then
	--dprint(arg10)
    if IsHeal(arg10) and xtimer("YourHealerOOM",12) then
      -- _OOM\Events.lua
		  OutOfManaAlertMessage()
    end
  end
end






















function IsHeal(sName)
  if UnitClass("player")=="Paladin" and HasVariable(sName,PaladinHeals) then
	  return "Paladin"
	elseif UnitClass("player")=="Druid" and HasVariable(sName,DruidHeals) then
	  return "Druid"
  elseif UnitClass("player")=="Shaman" and HasVariable(sName,ShamanHeals) then
	  return "Shaman"
	elseif UnitClass("player")=="Priest" and HasVariable(sName,PriestHeals) then
	  return "Priest"
	end
end



-- HEALING SPELLS TABLES
PaladinHeals = { "Holy Light" , "Flash of Light" , "Cleanse" , "Divine Favor" , "Holy Shock" }
PriestHeals = { "Heal" , "Renew" , "Flash Heal" , "Greater Heal" , "Binding Heal" , "Prayer of Mending" , "Power Word: Shield" , "Lightwell" , "Pain Suppression" , "Circle of Healing" , "Abolish Disease" }
ShamanHeals = { "Healing Wave" , "Lesser Healing Wave" , "Chain Heal", "Riptide" , "Mana Tide Totem" , "Earth Shield" , "Cure Poison" , "Cure Disease" }
DruidHeals = { "Healing Touch" , "Rejuvenation" , "Regrowth" , "Rebirth" , "Remove Curse" , "Abolish Poison" , "Tranquility" , "Swiftmend" , "Lifebloom" , "Tree of Life", "Wild Growth", "Nourish" }




function HasVariable(sName,nTable)
 	for key,val in pairs(nTable) do
	  if sName==val then
		  return (key)
		end 
	end 
  return (false)
end

