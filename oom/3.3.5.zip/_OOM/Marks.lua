
Marks_Elapsed = -1
Focus_Mark = nil




SYMBOL_SHACKLE = 2      --Orange Circle
SYMBOL_SAP = 3          --Purple Diamond
SYMBOL_HIBERNATE = 4    --Green Triangle
SYMBOL_POLYMORPH = 5    --Pale Moon
SYMBOL_SEDUCTION = 6    --Blue Square





function OOM_Marks(elapsed)
  if GetRaidTargetIndex("player")==7 then SetRaidTarget("player",0) end
  if not Marks_Elapsed or GetTime()-Marks_Elapsed<1.5 then return nil end

  lowest_value =999;
  lowest_unit =nil;  

  for mi=1,4 do
    if not UnitCanAttack("party"..mi.."target","player") or not UnitIsVisible("party"..mi.."target") or UnitIsPlayer("party"..mi.."target") then
      --nil
    elseif not GetRaidTargetIndex("party"..mi.."target") and Unit_Debuff("party"..mi.."target","Sap")>0 and not UnitAffectingCombat("party"..mi.."target") then 
      SetRaidTarget("party"..mi.."target",SYMBOL_SAP)   --Sap
      Marks_Elapsed=GetTime()
    elseif not GetRaidTargetIndex("party"..mi.."target") and not UnitAffectingCombat("party"..mi.."target") and UnitCreatureType("party"..mi.."target")=="Humanoid" and Unit_Debuff("party"..mi.."target","Sap")>0 and UnitClass("party"..mi)=="Rogue" and Unit_Buff("party"..mi,"Stealth")>0 then 
      SetRaidTarget("party"..mi.."target",SYMBOL_SAP)  --Sap
      Marks_Elapsed=GetTime()
    elseif not GetRaidTargetIndex("party"..mi.."target") and ( UnitCreatureType("party"..mi.."target")=="Beast" or UnitCreatureType("party"..mi.."target")=="Dragonkin" ) and UnitClass("party"..mi)=="Druid" and UnitPowerType("party"..mi)==0 and UnitCastingInfo("party"..mi)=="Hibernate" then 
      SetRaidTarget("party"..mi.."target",SYMBOL_HIBERNATE)   --Hibernate
      Marks_Elapsed=GetTime()
    elseif not GetRaidTargetIndex("party"..mi.."target") and ( UnitCreatureType("party"..mi.."target")=="Beast" or UnitCreatureType("party"..mi.."target")=="Humanoid" ) and UnitClass("party"..mi)=="Mage" and UnitCastingInfo("party"..mi) and string.find( UnitCastingInfo("party"..mi),"Polymorph" ) then 
      SetRaidTarget("party"..mi.."target",SYMBOL_POLYMORPH)   --Polymorph
      Marks_Elapsed=GetTime()
    elseif not GetRaidTargetIndex("party"..mi.."target") and nil then 
      SetRaidTarget("party"..mi.."target",SYMBOL_POLYMORPH)   --Polymorph
      Marks_Elapsed=GetTime()
    elseif not GetRaidTargetIndex("party"..mi.."target") and ( UnitCreatureType("party"..mi.."target")=="Undead" ) and UnitClass("party"..mi)=="Priest" and UnitCastingInfo("party"..mi) and string.find( UnitCastingInfo("party"..mi),"Shackle Undead" ) then 
      SetRaidTarget("party"..mi.."target",SYMBOL_SHACKLE)  --Shackle Undead
      Marks_Elapsed=GetTime()
    elseif not GetRaidTargetIndex("partypet"..mi.."target") and UnitClass("party"..mi)=="Warlock" and UnitCreatureFamily("partypet"..mi)=="Succubus" and ( UnitCreatureType("partypet"..mi.."target")=="Humanoid" ) and UnitCastingInfo("partypet"..mi) and string.find( UnitCastingInfo("partypet"..mi),"Seduction" ) then 
      SetRaidTarget("partypet"..mi.."target",SYMBOL_SEDUCTION)  --Seduction
      Marks_Elapsed=GetTime()

    elseif not GetRaidTargetIndex("party"..mi.."target") and UnitHealth("party"..mi.."target")/UnitHealthMax("party"..mi.."target")<lowest_value then 
      lowest_unit="party"..mi.."target"
    end
  end



  if not UnitCanAttack("target","player") or not UnitIsVisible("target") or UnitIsPlayer("target") then
    --nil
  elseif ( not GetRaidTargetIndex("target") or GetRaidTargetIndex("target")==7 ) and UnitHealth("target")/UnitHealthMax("target")==lowest_value then
    SetRaidTarget("target",8)
    Marks_Elapsed=GetTime()
  end

  if Focus_Mark and type(Focus_Mark)=="number" and UnitIsVisible("focustarget") and ( not GetRaidTargetIndex("focustarget") or GetRaidTargetIndex("focustarget")~=Focus_Mark ) and ( not UnitIsPlayer("focustarget") or UnitFactionGroup("focustarget")==UnitFactionGroup("player") ) then
    SetRaidTarget("focustarget",Focus_Mark)
    Marks_Elapsed=GetTime()
  end

end








-- 1) Yellow Star
-- 2) Orange Circle
-- 3) Purple Diamond
-- 4) Green Triangle
-- 5) Pale Moon
-- 6) Blue Square
-- 7) Red X "Cross"
-- 8) Skull