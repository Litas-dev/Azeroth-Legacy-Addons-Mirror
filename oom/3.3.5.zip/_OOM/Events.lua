-- UIErrorsFrame:AddMessage("msg",0,1,.5,1,2)
-- string.find(UnitDebuff("target",i),sDebuffName)
-- DEFAULT_CHAT_FRAME:AddMessage("woot!")
-- DEFAULT_CHAT_FRAMEScrollToBottom() 



--[[
Beverly: Ladybomb	 anthony2 
Beverly: ladybomb	anthony2 
]]--



OOM_OnLoad = function ()
--	 this:RegisterEvent("COMBAT_LOG_EVENT_UNFILTERED")
	 this:RegisterEvent("QUEST_QUERY_COMPLETE")
	 
	 this:RegisterEvent("LFG_PROPOSAL_SHOW")
	 
	 this:RegisterEvent("CHAT_MSG_WHISPER")
   this:RegisterEvent("CHAT_MSG_ADDON")

	 this:RegisterEvent("UI_INFO_MESSAGE")
	 this:RegisterEvent("UI_ERROR_MESSAGE")
	 this:RegisterEvent("PLAYER_TARGET_CHANGED")
	 this:RegisterEvent("PARTY_INVITE_REQUEST")
	 this:RegisterEvent("START_LOOT_ROLL")
	 this:RegisterEvent("START_LOOT_ROLL")
	 this:RegisterEvent("CHAT_MSG_LOOT");
	 this:RegisterEvent("WORLD_MAP_UPDATE")
	 
	 this:RegisterEvent("UNIT_SPELLCAST_SENT")
   this:RegisterEvent("UNIT_SPELLCAST_SUCCEEDED")
	 this:RegisterEvent("UNIT_SPELLCAST_STOP")
	 this:RegisterEvent("UNIT_SPELLCAST_FAILED")
	 this:RegisterEvent("UNIT_SPELLCAST_FAILED_QUIET")

	 this:RegisterEvent("CHAT_MSG_COMBAT_CREATURE_VS_SELF_HITS")
	 this:RegisterEvent("CHAT_MSG_COMBAT_SELF_HITS")
	 this:RegisterEvent("CHAT_MSG_SPELL_SELF_BUFF")
	 this:RegisterEvent("CHAT_MSG_SPELL_SELF_DAMAGE")
	 this:RegisterEvent("CHAT_MSG_SPELL_CREATURE_VS_SELF_DAMAGE")
	 this:RegisterEvent("CHAT_MSG_SPELL_HOSTILEPLAYER_DAMAGE")
	 this:RegisterEvent("CHAT_MSG_SPELL_HOSTILEPLAYER_BUFF")

	 this:RegisterEvent("CHAT_MSG_SPELL_FAILED_LOCALPLAYER")

   this:RegisterEvent("MERCHANT_SHOW")
	 this:RegisterEvent("CHAT_MSG_SYSTEM")
	 
	 this:RegisterEvent("CURRENT_SPELL_CAST_CHANGED")
   

-- this:RegisterEvent("REPLACE_ENCHANT")

	 SLASH_SELLGRAYITEMS1 = "/sellgrays";
	 SLASH_SELLGRAYITEMS2 = "/sellgreys";
	 SLASH_SELLGRAYITEMS3 = "/sgi";
	 SlashCmdList["SELLGRAYITEMS"] = SellGrays;

	 SLASH_MATH1 = "/math";
	 SlashCmdList["MATH"] = function(msg) msg = "mathmacro =" .. msg; mathmacro = "Invalid Syntax"; RunScript(msg); ChatFrame1:AddMessage(mathmacro,0,1,.5); end;

	 SLASH_WHOT1 = "/whot";
	 SlashCmdList["WHOT"] = WhoT;

	 SLASH_TELLTARGET1 = "/tt";
	 SlashCmdList["TELLTARGET"] = TellTarget;
   
	 SLASH_PWGT1 = "/wgt";
	 SLASH_PWGT2 = "/wg";
	 SlashCmdList["PWGT"] = PrintGetWintergraspWaitTime;
   
	 SLASH_OOMW1 = "/oomw";
   SLASH_OOMW2 = "/oomwarn";
   SLASH_OOMW3 = "/oomwarning";
	 SlashCmdList["OOMW"] = SetOOMwarning;

	 SLASH_SCROLLBOTTOM1 = "/scrolltobottom";
	 SlashCmdList["SCROLLBOTTOM"] = function(msg) DEFAULT_CHAT_FRAME:ScrollToBottom() end ;

	 SLASH_LIST1 = "/list";
	 SlashCmdList["LIST"] = SlashList;
   
   SLASH_RANDOMPET1 = "/randompet";
	 SlashCmdList["RANDOMPET"] = function(msg) CallRandomVanityPet() end;
   
   SLASH_SINVITE1 = "/tellinvite";
   SLASH_SINVITE2 = "/2invite";
   SLASH_SINVITE3 = "/tinv";
   SLASH_SINVITE4 = "/2inv";
   SLASH_SINVITE5 = "/sinvite";
	 SlashCmdList["SINVITE"] = SpecialInvite;
   
   SLASH_BGAUTOINVITE1 = "/bgautoinvite";
   SlashCmdList["BGAUTOINVITE"] = SetBGAutoInvite;
	 
	 SLASH_RUNZCRIPT1 = "/z";
   SlashCmdList["RUNZCRIPT"] = RunScript;
	 
     
     SLASH_DISABLEERRORS1 = "/de";
     SLASH_DISABLEERRORS2 = "/disableerrors";
     SlashCmdList["DISABLEERRORS"] = DisableErrors;
     
     SLASH_ENABLEERRORS1 = "/ee";
     SLASH_ENABLEERRORS2 = "/enableerrors";
     SlashCmdList["ENABLEERRORS"] = EnableErrors;
	  
	  
	  SLASH_FOLLOWMASTER1 = "/followmaster";
	  SlashCmdList["FOLLOWMASTER"] = SetFollowMaster;
	 
	 
	  SLASH_MOUSEOVERINFO1 = "/mouseoverinfo";
     SLASH_MOUSEOVERINFO2 = "/moi";
     SlashCmdList["MOUSEOVERINFO"] = MouseoverInfo;
	 
	 
	 
	 LeaveMeAlone()


	--fix pvp score window location
	 WorldStateAlwaysUpFrame:ClearAllPoints()
	 WorldStateAlwaysUpFrame:SetMovable(1)
	 WorldStateAlwaysUpFrame:SetPoint("TOPLEFT", 600,-10);
	 WorldStateAlwaysUpFrame:SetMovable() 

	 
	 t_OnLoad=GetTime();
	 DEFAULT_CHAT_FRAME:AddMessage( ColorText(.5,.5,1) .. " OOM " ..ColorText() .. "loaded " .. date() )
end


























function SlashList(cmdtext)
	if strfind(strlower(cmdtext),"options") then
	  OOM_LoadOptions()
	  
	elseif strfind(strlower(cmdtext),"elde") then
--	  dprint("Listing Eldest" ,1,.5,0)
	  ListEldest()
		
	elseif strfind(strlower(cmdtext),"quest") then
		dprint("Listing Quests" ,1,.5,0)
	  ListQuests()
		
	elseif strfind(strlower(cmdtext),"weapon") then
	  dprint("Listing Weapon Skills" ,1,.5,0)
	  ListWeaponSkills()
	  
	elseif strfind(strlower(cmdtext),"gear") and strfind(strlower(cmdtext),"score") then
	  dprint("Listing Gear Scores" ,1,.5,0)
	  ListGearScores()
		
	elseif strfind(strlower(cmdtext),"gear") and strfind(strlower(cmdtext),"targ")  then
	  dprint("Listing "..ColorText(0,1,1).."Target"..ColorText().." Gear Level" ,1,.5,0)
	  ListGearValue("target")
	  
	elseif strfind(strlower(cmdtext),"gear") then
	  dprint("Listing Gear Level" ,1,.5,0)
	  ListGearValue()
		
	elseif strfind(strlower(cmdtext),"instance") or strfind(strlower(cmdtext),"dungeon") then
	  dprint("Listing Dungeons" ,1,.5,0)
	  InstancesByLevel()
	  --old school Dungeons
		
	elseif strfind(strlower(cmdtext),"chant") then
	  dprint("Listing Enchanting Materials" ,1,.5,0)
	  ListBankerEnchanting()
		
	elseif strfind(strlower(cmdtext),"herb") then
	  dprint("Listing Herbs" ,1,.5,0)
	  RowylHerbs()
		
	elseif strfind(strlower(cmdtext),"gem") then
	  dprint("Listing Gems&Ore" ,1,.5,0)
	  ListBankerGems()
		
	elseif strfind(strlower(cmdtext),"defe") then
	  dprint("Listing Defensive Stats" ,1,.5,0)
	  DefensiveStats()
		
	elseif strfind(strlower(cmdtext),"zone") then
	  ZoneInfo()
		
	elseif strfind(strlower(cmdtext),"prospect") then	
		echoProspecting()
		
  elseif strfind(strlower(cmdtext),"wellfed") then	
		ListBankerWellFed()
		
  elseif strfind(strlower(cmdtext),"avoid") then
    --no longer crush (after patch 3.0), but gives crit/hit immune status
		CrushImmuneStatus()
		
	elseif strfind(strlower(cmdtext),"theory") then	
		TheoryCraftPlus()
		
	elseif strfind(strlower(cmdtext),"injector") then
	  ListBankerInjectors()
		
	elseif strfind(strlower(cmdtext),"gold") then
	  BankerGold()
		
	elseif strfind(strlower(cmdtext),"variable") or strfind(strlower(cmdtext),"global") then
	  ListImportantVariables()
	  
	elseif strfind(strlower(cmdtext),"raid") or strfind(strlower(cmdtext),"lockout") then
	  ListLockouts()
		
	elseif strfind(strlower(cmdtext),"bank") then
	  dprint("Bank commands include: " ,1,.5,0)
		dprint("  /bfind <item-name>")
		dprint("  /bankfind <item-name>")
		dprint("  /searchbanker <item-name>")
		dprint("  /sgb <item-name>  Search Guild Bank")
		
		dprint("  /list injectors  Returns Potions that can be converted to Injectors (by account)")
		dprint("  /list herbs  Returns Herbs (by character)")
		dprint("  /list prospect  Returns Prospecting Information based on Ore")
	  dprint("  /list enchanting  Returns Enchanting Materials (by account)")
		dprint("  /list gems  Returns Gems & Ores (by account)")
		dprint("  /list wellfed  Returns Well Fed Food (by account)")
		DEFAULT_CHAT_FRAMEScrollToBottom() 
		
	else
		
		dprint("SlashList commands include: " ,1,.5,0)
		dprint("  /list options "..ColorText(.8,.8,.8) .." to view OOM options")
		dprint("  /list elder|eldest " ..ColorText(.8,.8,.8).. " Sorts characters by loggin")
		dprint("  /list quest " ..ColorText(.8,.8,.8).. " Sorts Quests by Level")
		dprint("  /list weapon " ..ColorText(.8,.8,.8).. " Sorts Weapon Skills ")
		dprint("  /list gear " ..ColorText(.8,.8,.8).. " Sorts Gear by iLevel")
		dprint("  /list defensive " ..ColorText(.8,.8,.8).. " Provides information about Defense")
		dprint("  /list avoidance " ..ColorText(.8,.8,.8).. " Provides information about Avoidance Immunities")
		dprint("  /list gold " ..ColorText(.8,.8,.8).. " Lists Gold for each character on account")
		dprint("  /list bank " ..ColorText(.8,.8,.8).. " Lists other banker commands")
		dprint("  /list variables " ..ColorText(.8,.8,.8).. " Lists important global variables")
		dprint("  /list gearscores " ..ColorText(.8,.8,.8).. " Lists Gearscores of raid/party members if available")
		dprint("  /list raid|lockout " ..ColorText(.8,.8,.8).. " Lists Raids you are saved to")


		dprint("Slash commands include: " ,1,.5,0)
		dprint("  /de "..ColorText(.8,.8,.8).." && "..ColorText().." /ee "..ColorText(.8,.8,.8).." Disable or Enable Sound & UI Error Messages")
		dprint("  /bgautoinvite <on/off> "..ColorText(.8,.8,.8).." Toggles automatic battleground invites")
		dprint("  /bfind <item-name> ")
		dprint("  /sgi " ..ColorText(.8,.8,.8).. " Sell Grey Items ")
		dprint("  /math <equation> ")
		dprint("  /tt <msg> " ..ColorText(.8,.8,.8).. " Sends message to target as a whisper ")
		dprint("  /randompet " ..ColorText(.8,.8,.8).. " Calls a random vanity pet ")
		dprint("  /whot " ..ColorText(.8,.8,.8).. " Preforms /who on current target ")
		dprint("  /loc " ..ColorText(.8,.8,.8).. " Returns your x,y location ")
		dprint("  /make " ..ColorText(.8,.8,.8).. " Promotes your target to group leader ")
		dprint("  /targetinfo " ..ColorText(.8,.8,.8).. " Provides information about your target (mostly code oriented) ")
		dprint("  /sgb <item-name> " ..ColorText(.8,.8,.8).. " Search Guild Bank")
		dprint("  /findloc <x,y>|<playername> " ..ColorText(.8,.8,.8).. " For Finding a given location, for finding a person (in battleground) ")
		dprint("  /oomw <RW>|<R>|<P>|<None> " ..ColorText(.8,.8,.8).. " Sets Max Out of Mana Warning Level ")
		dprint("  /tinv <name> " ..ColorText(.8,.8,.8).. " Invite someone when you are not leader (if leader has _OOM) or get leader to invite you, if they has _OOM ")
		dprint("  /followmaster <name> " ..ColorText(.8,.8,.8).. " Sets Person to follow religiously ")
		DEFAULT_CHAT_FRAMEScrollToBottom()
		
	end
	
end






















function DisableErrors()
  UIErrorsFrame:UnregisterEvent("UI_ERROR_MESSAGE")
  SetCVar("Sound_EnableSFX","0")
end


function EnableErrors()
  SetCVar("Sound_EnableSFX","1")
  UIErrorsFrame:RegisterEvent("UI_ERROR_MESSAGE")
  
end









--OOMwarning must be RW R P or None
function SetOOMwarning(cmdtext)
  cmdtext = strlower(cmdtext)
  
  if cmdtext=="rw" or strfind(cmdtext,"warn") then
    OOMwarning = "RW"
    
  elseif cmdtext=="r" or strfind(cmdtext,"raid") then
    OOMwarning = "R"
    
  elseif cmdtext=="p" or strfind(cmdtext,"party") then
    OOMwarning = "P"

  elseif cmdtext=="none" then
    OOMwarning = "None"
    
  else
    dprint(ColorText(.8,.8,.8) .. " Use " .. ColorText(1,1,1) .. "  /oomw <RW>|<R>|<P>|<None> " ..ColorText(.8,.8,.8).. " To Change the Max Annoucement of OOM warning ")
 
  end
  
  --OOMwarning must be RW R P or None
  if OOMwarning=="RW" then
    dprint(" OOM warning set to Raid Warning")
  elseif OOMwarning=="R" then
    dprint(" OOM warning set to Raid")
  elseif OOMwarning=="P" then
    dprint(" OOM warning set to Party")
  elseif OOMwarning=="None" then
    dprint(" OOM warning is off")
  else
    OOMwarning = "RW"
    dprint(" OOM warning set to Raid Warning")
  end
end





function SetBGAutoInvite(cmdtext)
  --dprint(cmdtext)
  
  if type( cmdtext )=="string" and strfind(cmdtext, "on") then
    preventBGAutoInvite = nil
    
  elseif type( cmdtext )=="string" and strfind(cmdtext, "off") then
    preventBGAutoInvite = 1
    
  elseif type( cmdtext )=="string" then
    dprint("  /bgautoinvite <on/off> "..ColorText(.8,.8,.8).." Toggles automatic battleground invites")

  elseif preventBGAutoInvite then
    preventBGAutoInvite = nil
    
  else
    preventBGAutoInvite = 1
    
  end
  
  if preventBGAutoInvite then
    dprint(" Automatic BG Invites are "..ColorText(1,0,0).."OFF")
  else
    dprint(" Automatic BG Invites are "..ColorText(0,1,0).."ON")
  end
  
end



function SpecialInvite(cmdtext)
  if cmdtext then
    AutoInviteSpecial(cmdtext)
    UIErrorsFrame:AddMessage(cmd ,1,1,0 ,1,2)
  elseif UnitName("target") then
    AutoInviteSpecial( UnitName("target") )
    UIErrorsFrame:AddMessage( UnitName("target") ,1,1,0 ,1,2)
  end
  --UIErrorsFrame:AddMessage("SpecialInvite" ,0,1,.5 ,1,2)
end




function AutoInviteSpecial(pname)
	UIErrorsFrame:AddMessage(pname ,0,1,0 ,1,2)
	if GetNumPartyMembers()==0 and GetNumRaidMembers()==0 then
		SendAddonMessage("_Invite",UnitName("player"),"WHISPER",pname)
	elseif CanInvite() then
		InviteUnit(pname)
	else
		SendAddonMessage("_Invite",pname,"RAID")
	end
end





function MouseoverInfo()
	GameTooltip_SetDefaultAnchor(GameTooltip, UIParent)
	GameTooltip:SetFrameStack(true)
end









function WhoT(cmdtext)
	SendWho( "n-" .. UnitName("target") .. " c-" .. UnitClass("target") .. " r-" .. UnitRace("target") )
	DEFAULT_CHAT_FRAMEScrollToBottom() 
end




function TellTarget(msg)
	SendChatMessage(msg, "WHISPER", nil, UnitName("target"));
end






function LeaveMeAlone()
	for index=1,11 do
		name1 = GetChatWindowChannels( DEFAULT_CHAT_FRAME:GetID() )
		if not name1 then break end
		ChatFrame_RemoveChannel(DEFAULT_CHAT_FRAME, name1)
	end
	
	for index=1,11 do
		id, name = GetChannelName(index)
		if not name then return index end
		cname = string.sub( name,1,string.find(name," ") )
--	echo( cname )
		ChatFrame_RemoveChannel(DEFAULT_CHAT_FRAME, cname)
	end
	DEFAULT_CHAT_FRAME:AddMessage(" Spam Removed from Default_Chat_Frame")
end








function PrintGetWintergraspWaitTime()
	echo( GetWintergraspWaitTime() )

	if not GetWintergraspWaitTime() or type(GetWintergraspWaitTime()) ~= "number" then
		dprint( " Time for Wintergrasp is Unknown " ,1,0,0)
		
	elseif GetWintergraspWaitTime()/60 > 90 then
		dprint( " Time for Wintergrasp is " .. round( GetWintergraspWaitTime()/(60*60) ,-2) .. " hours" ,1,1,0)
		
	elseif GetWintergraspWaitTime() > 90 then
		dprint( " Time for Wintergrasp is " .. round( GetWintergraspWaitTime()/60 ,-2) .. " minutes" ,0,1,0)
		
	else
		dprint( " Time for Wintergrasp is " .. GetWintergraspWaitTime() .. " seconds" ,0,0,1)
		
	end
	
end

--[[
	if PlayerBuff("Ability_BullRush") and PlayerBuff("Racial_BearForm") and UnitHealth("player")>=UnitHealthMax("player") then
		RemoveBuff("Ability_BullRush")
	end
]]--











function SetFollowMaster(cmdtext)
	nameUnit = UnitName(cmdtext)
	if type(nameUnit)=="string" then
		followmaster=nameUnit
		UIErrorsFrame:AddMessage(followmaster ,0,1,1)
		return
	elseif type(cmdtext)=="string" then
		cmdtext = strlower(cmdtext)
		if strfind(cmdtext,"combat") then
			if strfind(cmdtext,"no") then
				followmastercombat = nil
				UIErrorsFrame:AddMessage("no combat" ,0,1,1)
				return
			else
				followmastercombat = GetTime()
				UIErrorsFrame:AddMessage("combat" ,0,1,1)
				return
			end
		end
	elseif UnitInParty("target") or UnitInRaid("target") then
		followmaster = UnitName("target")
		UIErrorsFrame:AddMessage(followmaster ,0,1,1)
		return
	end
	followmaster=nil
	UIErrorsFrame:AddMessage("followmaster cleared" ,1,0.5,0.5)
end


















OOM_OnEvent = function (arg1,arg2,arg3,arg4,arg5,arg6,arg7,arg8,arg9)
	if event=="CHAT_MSG_WHISPER" then
		if not noPlaySound and xtimer("whisper_sound",120) then
			PlaySoundFile("Interface\\AddOns\\_OOM\\Sound\\bg.wav")
		end
		
	elseif ( event=="UI_ERROR_MESSAGE" ) then
		Event_UIerror(arg1)
		
	elseif event=="PLAYER_TARGET_CHANGED" then
		--if UnitExists("target") then Magic_UpdateTargetClassIcon() end
		if GetNumRaidMembers()>5 or Do_Not_AutoMark or not AmTank() or OOM_Options["AutoXMark"]==0 then
			--raid or setting or not tank
		elseif UnitExists("target") and not GetRaidTargetIndex("target") and not UnitIsPlayer("target") and not UnitPlayerControlled("target") and ( UnitCanAttack("player","target") or UnitCanAttack("target","player") or not UnitCanCooperate("player","target") or not UnitCanCooperate("target","player") ) then
			SetRaidTarget("target",7)
		elseif UnitExists("target") and GetRaidTargetIndex("target") and GetRaidTargetIndex("target")~=7 then
			SetRaidTarget("player",7)
		end
    
  --auto loot disenchantings
  elseif event=="UNIT_SPELLCAST_SUCCEEDED" and arg1=="player" and arg2=="Disenchant" then
    t_Disenchant = GetTime()
    lootIcon, lootName, lootQuantity, rarity, locked = GetLootSlotInfo(1)
    dprint( lootName )
		
	--auto loot milling
  elseif event=="UNIT_SPELLCAST_SUCCEEDED" and arg1=="player" and arg2=="Milling" then
    t_Milling = GetTime()
    lootIcon, lootName, lootQuantity, rarity, locked = GetLootSlotInfo(1)
    dprint( lootName )	
		
	--auto loot prospecting
  elseif event=="UNIT_SPELLCAST_SUCCEEDED" and arg1=="player" and arg2=="Prospecting" then
    t_Prospecting = GetTime()
    lootIcon, lootName, lootQuantity, rarity, locked = GetLootSlotInfo(1)
    dprint( lootName )	
		
  --Record Auto Blessing		
	elseif event=="UNIT_SPELLCAST_SENT" and type(arg2)=="string" and strfind(arg2,"Blessing of ") and type(arg4)=="string" then
			RecordBlessingPreference(arg4,arg2)
      
      
		
		
		
	--all Rez
	--arg1="player"
	--arg2=Rez Name
	--arg3=RankNum
	--arg4=target
	elseif event=="UNIT_SPELLCAST_SENT" and arg1=="player" and type(arg2)=="string" and ( arg2=="Ancestral Spirit" or arg2=="Redemption" or arg2=="Resurrection" or arg2=="Revive" or arg2=="Rebirth" ) and type(arg3)=="string" and type(arg4)=="string" then
	  if not UnitIsPVP("player") and not BattleGround() then
		  SendChatMessage( GetSpellLink(arg2.."("..arg3..")").." on "..arg4 ,"SAY")
			
		else
		  dprint( GetSpellLink(arg2.."("..arg3..")").." on "..arg4 )
		  
		end		
		

	--Paladin Rez 		
	elseif event=="UNIT_SPELLCAST_SENT" and arg1=="player" and arg2=="Redemption" and type(arg4)=="string" then
	  if not UnitIsPVP("player") and not BattleGround() then
		  SendChatMessage("\124cff71d5ff\124Hspell:48950\124h[Redemption]\124h\124r on "..arg4,"SAY")
			
		else
			dprint(" \124cff71d5ff\124Hspell:48950\124h[Redemption]\124h\124r on "..arg4)
		  
		end		
			
			
			
	--Paladin Divine Sacrifice
  elseif event=="UNIT_SPELLCAST_SENT" and arg1=="player" and arg2=="Divine Sacrifice" then
	  if not UnitIsPVP("player") and not BattleGround() and ( GetNumVisibleTeam()>0 ) then
		    SendChatMessage(" \124cff71d5ff\124Hspell:64205\124h[Divine Sacrifice]\124h\124r " ,TeamTalkType(4))

		else
			dprint(" \124cff71d5ff\124Hspell:64205\124h[Divine Sacrifice]\124h\124r")
		  
		end
		
		
	--Warrior Shield Wall
  elseif event=="UNIT_SPELLCAST_SENT" and arg1=="player" and arg2=="Shield Wall" then
	  if not UnitIsPVP("player") and not BattleGround() and ( GetNumVisibleTeam()>0 ) and xtimer("Shield Wall",24) then
		    SendChatMessage(" \124cff71d5ff\124Hspell:871\124h[Shield Wall]\124h\124r ",TeamTalkType(4))

		else
			dprint(" \124cff71d5ff\124Hspell:871\124h[Shield Wall]\124h\124r ")
		  
		end
			
			
			

      
      --printcat( event , ' ' , arg1 , ' ' , arg2 )
		
		
	elseif event=="PARTY_INVITE_REQUEST" and xtimer("InviteAccept",60) then
		AcceptGroup()
		DEFAULT_CHAT_FRAME:AddMessage(" Automatically accepting group invitation.")
		
	elseif event=="LFG_PROPOSAL_SHOW" then
	  t_LFG_PROPOSAL_SHOW = GetTime()
		s_LFG_PROPOSAL_SHOW = ( s_LFG_PROPOSAL_SHOW or 0 ) + 1 --how many times its shown up sense we "code" accepted
		dprint(" You have a group proposal!")
    
	elseif event=="START_LOOT_ROLL" and arg1 then
		local l_texture, l_name, l_count, l_quality, l_pickup = GetLootRollItemInfo(arg1);
		if l_pickup then DEFAULT_CHAT_FRAME:AddMessage(" <Binds on Pickup> " .. l_name ,1,0,0) end
		
	elseif event=="CHAT_MSG_SPELL_SELF_DAMAGE" and arg1 and string.find(arg1,"Gnomish Death Ray") then
		DEFAULT_CHAT_FRAME:AddMessage(arg1, 1,0,0)
		
	elseif event=="TRADE_ACCEPT_UPDATE" and arg1 and arg2 then
		if arg2==1 and arg1==0 and GetPlayerTradeMoney()==0 and not GetTradePlayerItemInfo(1) and not GetTradePlayerItemInfo(2) and not GetTradePlayerItemInfo(3) and not GetTradePlayerItemInfo(4) and not GetTradePlayerItemInfo(5) and not GetTradePlayerItemInfo(6) and not GetTradePlayerItemInfo(7) and not GetTradeTargetItemInfo(7) then 
		--DEFAULT_CHAT_FRAME:AddMessage("Automatically Accepting Trade..." ,1,0,0)	AcceptTrade()
		end
		
	--Taunt Resist
	elseif arg2=="SPELL_CAST_FAILED" and arg10=="Taunt" and arg12=="RESIST" then
	  if GetNumVisiblePartyMembers()>0 and type(arg6)=="string" and xtimer("TauntMsgFailedParty",7) then
		  SendChatMessage( "Taunt Resisted by "..arg6 ,"PARTY")
		end
		
	--Taunt Resist (pre2.4)
	elseif event=="CHAT_MSG_SPELL_SELF_DAMAGE" and string.find(arg1,"Your Taunt was resisted by") then
		DEFAULT_CHAT_FRAME:AddMessage(" "..string.sub(arg1,5) ,250/255,15/255,30/255)
		if GetNumVisiblePartyMembers()>0 and xtimer("TauntMsgFailedParty",7) then SendChatMessage( string.sub(arg1,5) ,"PARTY") end
	--Growl Resist	
	elseif event=="CHAT_MSG_SPELL_SELF_DAMAGE" and string.find(arg1,"Your Growl was resisted by") then
		DEFAULT_CHAT_FRAME:AddMessage(" "..string.sub(arg1,5) ,250/255,15/255,30/255)
		if GetNumVisiblePartyMembers()>0 and xtimer("TauntMsgFailedParty",7) then SendChatMessage( string.sub(arg1,5) ,"PARTY") end
		
	--Freezing Trap Resist
	elseif event=="CHAT_MSG_SPELL_PET_DAMAGE" and arg1 and strfind(arg1,"Freezing Trap Effect was resisted by ") then
		if GetNumVisibleTeam()>0 and xtimer("FreezingResist",1) then
			SendChatMessage(arg1,"PARTY")
		else
			dprint(" "..arg1 ,1,0,0)
		end
		
	--Righteous Defense
	elseif event=="CHAT_MSG_SPELL_SELF_DAMAGE" and arg1 and strfind(arg1,"Righteous Defense") and strfind(strlower(arg1),"resist") then
		if GetNumVisibleTeam()>0 and ( xtimer("Righteous Defense1",13) or xtimer("Righteous Defense2",13) or xtimer("Righteous Defense3",13) ) then
			SendChatMessage(string.sub(arg1,5),"PARTY")
		else
			dprint(event .. ColorText(1,0,0) .. "~" .. ColorText() .. string.sub(arg1,5))
		end
	elseif event and type(arg1)=="string" and strfind(arg1,"Righteous Defense") and strfind(strlower(arg1),"resist") then
		dprint(event .. ColorText(1,0,0) .. "~" .. ColorText() .. string.sub(arg1,5))
		
	--extra attack
	elseif event=="CHAT_MSG_SPELL_SELF_BUFF" and string.find(arg1,"extra attack through") then
		--DEFAULT_CHAT_FRAME:AddMessage(arg1 ,119/255,205/255,215/255)
		if not bonusAttacks then bonusAttacks=1 else bonusAttacks=bonusAttacks+1 end
		
	elseif event=="CHAT_MSG_SPELL_SELF_BUFF" and string.find(arg1,"Unbridled Wrath") then
		if not Unbridled_Wrath then Unbridled_Wrath=0 end
		Unbridled_Wrath=Unbridled_Wrath+1
--	DEFAULT_CHAT_FRAME:AddMessage(arg1 ,120/255,200/255,215/255)

	elseif event=="CHAT_MSG_SPELL_SELF_BUFF" and string.find(arg1,"Demonfork") then
		DEFAULT_CHAT_FRAME:AddMessage(arg1 ,120/255,200/255,215/255)
	elseif event=="CHAT_MSG_SPELL_CREATURE_VS_SELF_DAMAGE" and string.find(arg1,"reflect") then
		DEFAULT_CHAT_FRAME:AddMessage(" "..arg1 ,255/255,15/255,100/255)
	elseif event=="CHAT_MSG_SPELL_CREATURE_VS_SELF_DAMAGE" and string.find(arg2,"reflect") then
		DEFAULT_CHAT_FRAME:AddMessage("2 "..arg2 ,255/255,15/255,100/255)
	elseif event=="CHAT_MSG_SPELL_HOSTILEPLAYER_DAMAGE" and string.find(arg1,"reflect") then
		DEFAULT_CHAT_FRAME:AddMessage(" "..arg1 ,255/255,15/255,100/255)
	elseif event=="REPLACE_ENCHANT" and arg1 and arg2 and arg1==arg2 then
		UIErrorsFrame:AddMessage("Auto Enchant Replace",0,1,.5,1,2)
		ReplaceEnchant()

	elseif event=="CHAT_MSG_SPELL_HOSTILEPLAYER_BUFF" and string.find(arg1,"heals you") then
		local find_healsyou = string.find(arg1,"heals you for")+14
		if not find_healsyou then return find_healsyou end
		heal_value = tonumber( string.sub(arg1, find_healsyou, -2) )

		Deviation("HEALED_FOR",heal_value)
		if heal_value and heal_value>0 and heal_value>UnitHealthMax("player")*0.20 then
			s_color = "\124cFF"..string.format("%02x%02x%02x", 48, 192, 255)
			heal_text = string.gsub(arg1,heal_value,s_color..heal_value.."\124r")
			DEFAULT_CHAT_FRAME:AddMessage(heal_text	,226/255,224/255,254/255)
		end
	elseif arg1 and type(arg1)=="string" and (	 string.find(arg1,"You hit ")	 or	 string.find(arg1,"You crit ")	 or	 ( string.find(arg1,"Your ") and ( string.find(arg1," hits ") or string.find(arg1," crits ") ) )	 ) and string.find(arg1," for ") and (	 string.find(arg1," damage.",0,true) or string.find(arg1,".",0,true)		) then
		local lowest_show = 10
		local max_color = 50
		local s_for = string.find(arg1," for ")
		local s_space = string.find(arg1," ",s_for+5)
		if not s_space then s_space = string.find(arg1,".",s_for+4,true) end
		s_value = tonumber( string.sub(arg1,s_for+5,s_space-1) )
		u_pct = s_value/UnitHealthMax("player")*100

		Deviation("YOU_HIT",s_value)
		if s_value and type(s_value)=="number" and Deviation("YOU_HIT","count")>5 and s_value > Deviation("YOU_HIT","average")+2.1*Deviation("YOU_HIT","standardDeviation") then
 
			y_color = (-255/(max_color-lowest_show))*(u_pct-lowest_show)+255
			if y_color<0 then y_color = 0 elseif y_color>255 then y_color = 255 end
			s_color = "\124cFF"..string.format("%02x%02x%02x", 255, y_color, 0)
			s_text = string.gsub(arg1,"%d*",function(v) return s_color..v.."\124r" end)

			DEFAULT_CHAT_FRAME:AddMessage(" "..s_text	,1,1,1/4)
		end
	elseif arg1 and type(arg1)=="string" and strfind(arg1,"its you for %d*") then
		local pos_s1,pos_s2 = string.find(arg1,"its you for %d*")
		local lowest_show = 10
		local max_color = 50
		s_value = tonumber( string.sub(arg1,pos_s1+12,pos_s2) )
		u_pct = s_value/UnitHealthMax("player")*100

		Deviation("HITS_YOU",s_value)
		if s_value and type(s_value)=="number" and u_pct>lowest_show then
			y_color = floor(	(-255/(max_color-lowest_show))*(u_pct-lowest_show)+255	)
			if y_color<0 then y_color = 0 elseif y_color>255 then y_color = 255 end
			s_color = "\124cFF"..string.format("%02x%02x%02x", 255, y_color, 0)
			s_text = string.gsub(arg1,s_value,function(v) return (s_color..v.."\124r") end)
			DEFAULT_CHAT_FRAME:AddMessage(s_text	,1,1,1/4)
		end
	
	

	-- ReadyCheck
	elseif event=="CHAT_MSG_SYSTEM" and arg1 and strfind(arg1,"The following players are AFK") then
		t_RaidAfk = GetTime()
		if GetNumRaidMembers()>0 then
			SendChatMessage(arg1,"RAID")
		elseif GetNumPartyMembers()>0 then
			SendChatMessage(arg1,"PARTY")
		end
	elseif event=="CHAT_MSG_SYSTEM" and arg1 and strfind(arg1," is not ready") then
		t_RaidNotReady = GetTime()
		
		notReadyName = strsub(arg1,0,strfind(arg1," is not ready") - 1)
		notReadyUnit = FindUnitByName(notReadyName)
		
		if UnitIsConnected(notReadyUnit) then
			if GetNumRaidMembers()>0 then
				SendChatMessage(arg1,"RAID")
			elseif GetNumPartyMembers()>0 then
				SendChatMessage(arg1,"PARTY")
			end
		else
	    dprint(notReadyName.." is offline")
		end
		
		
		
	-- instances reset
	elseif event=="CHAT_MSG_SYSTEM" and arg1 and strfind(arg1," has been reset.") then
		if ( GetNumPartyMembers()>0 ) and xtimer("Instance_Reset",12) then
			SendChatMessage("<Instances Reset>","PARTY")
		end
    
    
  -- Addon Messages!
  --SendAddonMessage("prefix","text","type","player/target")
  elseif event=="CHAT_MSG_ADDON" and arg1=="_OOM" and arg2 and arg4 then
    if arg2=="EEXP" then
      SendChatMessage( round(UnitLevel("player")+UnitXP("player")/UnitXPMax("player") ,-4) ,"PARTY")
      -- SendAddonMessage("_OOM","EEXP","RAID")
      
    elseif arg2=="MakeMe" and ( UnitInParty(arg4) or UnitInRaid(arg4) ) and not InRaid(UnitName("player")) then
      PromoteToLeader(arg4)
      -- SendAddonMessage("_OOM","MakeMe","PARTY")
    end
  
  --arg2 = msg, arg4=sender
  elseif event=="CHAT_MSG_ADDON" and arg1=="_Invite" and arg2 and type(arg2)=="string" and arg4 and CanInvite() then
    InviteUnit(arg2)
    -- SendAddonMessage("_Invite","<name2invite>","RAID")
  elseif event=="CHAT_MSG_ADDON" and arg1=="_Invite" and arg2 and type(arg2)=="string" and arg4 and not ( UnitInParty(arg4) or UnitInRaid(arg4) ) then
    SendAddonMessage("_Invite",arg4,"RAID")
	 
	 

  --auto sgi...
  elseif event=="MERCHANT_SHOW" and xtimer("autoSellGreyItems",8) then
    SellGrays()
  
	
	-- soaks up UNIT_SPELLCAST_
	elseif ( event=="UNIT_SPELLCAST_SENT" or event=="UNIT_SPELLCAST_SUCCEEDED" or event=="UNIT_SPELLCAST_STOP" or event=="UNIT_SPELLCAST_FAILED" or event=="UNIT_SPELLCAST_FAILED_QUIET" ) and arg1 and arg2 then
		t_UnitSpellCast = GetTime()
		t_Cast = GetTime()




  elseif event=="CHAT_MSG_LOOT" and ( strfind(arg1,"You receive item: ") or strfind(arg1,"You create: ") ) and ( strfind(arg1,"Brewfest Prize Token") or strfind(arg1,"Portable Brewfest Keg") ) and strfind(arg1,"Brewfest") and xtimer("BrewfestKegRuns",1) then
	  if t_BrewKeg and t_BrewToken then
		
		  echo( "Half lap time: " .. abs( t_BrewKeg - t_BrewToken ) )
			if d_BrewLap then
			  echo( "Full lap time: " .. abs( t_BrewKeg - t_BrewToken ) + d_BrewLap )
			end
			d_BrewLap = abs( t_BrewKeg - t_BrewToken )
		end
		
    if strfind(arg1,"Portable Brewfest Keg") then
		  
		  t_BrewKeg = GetTime()
			
    elseif strfind(arg1,"Brewfest Prize Token") then
		  
			if not c_Brewfest_Prize_Token then
			  c_Brewfest_Prize_Token = 2
		  else
			  c_Brewfest_Prize_Token = 2 + c_Brewfest_Prize_Token
			end
			t_BrewToken = GetTime()
			echo( "Total Prize Tokens Recieved: " .. c_Brewfest_Prize_Token)
		
		
		elseif strfind(arg1,"Brewfest") then
		  dprint( arg1 )
			
	  end
		
  UIErrorsFrame:AddMessage(arg1)

	
	
	
	
	
	
	
	
	
	elseif event=="CHAT_MSG_SYSTEM" and DrunkMsg(arg1) then
		lastDrunkMsg = arg1
		lastDrunkScore = DrunkMsg(arg1)

	
	
	
	
	
	
	--disenchanting
	elseif event=="CURRENT_SPELL_CAST_CHANGED" and IsDisenchanting() and SpellIsTargeting() then
	  if xtimer("listingGreens",60) then
		  ListGreens()
		else
			xtimerpass("listingGreens",15) 
		
		--[[
		  for key1,val1 in pairs(xvarname) do
				if val1=="listingGreens" then
					dprint( "key: "..ColorText(1,0,0)..key1..ColorText().."   val: "..ColorText(0,1,0)..val1..ColorText() )
					dprint( GetTime() - xtime[key1] )
				end
			end ]]--
			
			
		end
	
	
	end--end of primary if statement
	
	--test for quests Christmas!!
	--use /z QueryQuestsCompleted()
	if event=="QUEST_QUERY_COMPLETE" then
		qlist = {}
		GetQuestsCompleted(qlist)
        dprint(" Quest List Updated")
		
		if true then
		  --its not winter veil anymore, ignore
			
	  elseif type( qlist[8768] )~="boolean" and UnitLevel("player")>=20 then
			dprint( " You have NOT collected your Winter Veil Vanity Pet (Gaily Wrapped Present)!")
			
		elseif type( qlist[8803] )~="boolean" and UnitLevel("player")>=10 then
		  dprint( " You have NOT collected your Winter Veil Wand (Festive Gift)!")
			
		elseif type( qlist[8769] )~="boolean" and UnitLevel("player")>=40 then
		  dprint( " You have NOT collected your Winter Veil Greench (Ticking Present)!")
			
		elseif type( qlist[11528] )~="boolean" and UnitLevel("player")>=10 and GetItemCount( "Red Rider Air Rifle",1)==0 then
		  dprint( " You have NOT collected your Winter Veil Rifle (Winter Veil Gift)!")
			
		elseif UnitLevel("player")>=10 then
			dprint( " You have collected your Winter Veil toys")
			
		end
	
	
	
	
	
	
	
	
	
	
	
	
	
		
	end 



    
    
    
    
	
	
	
	if ValiesIsAGirl and PlayerBuff("Jack-o'-Lanterned!")>0 and xtimer("JackRemove",1) then
    RemoveBuff("Jack-o'-Lanterned!")
	end
	
  if ValiesIsAGirl and PlayerBuff("Turkey Feathers")>0 and xtimer("JackRemove",1) then
    RemoveBuff("Turkey Feathers")
		DoEmote("Cheer")
		SendChatMessage("Turkey Feathers" ,"WHISPER" ,nil , UnitName("player") )
		ClearTarget()
	end
	
	
	
	
  
  
  if CurrentVanityPet()==false and callVanityPets and not UnitAffectingCombat("player") and not BattleGround() and not UnitIsPVP("player") and not IsStealthed() and not IsMounted() and not UnitIsDeadOrGhost("player") and xtimer("VanityPet",60) then
    UIErrorsFrame:AddMessage( CallRandomVanityPet() ,0,1,1  ,1,1)
  end
	
	t_OOM_OnEvent = GetTime()
end --end of fucntion













function MakeMe()
  SendAddonMessage("_OOM","MakeMe","PARTY")
end





























function DrunkMsg(arg1)

		if strfind(arg1,"You seem to be sobering up") then
		  return 0
			
		elseif strfind(arg1,"You feel a little tipsy from the ") then
		  return 1
			
		elseif strfind(arg1,"You're feeling drunk off of ") then
		  return 2
			
	  elseif strfind(arg1,"You feel completely smashed after that ") then
		  return 3
			
		elseif strfind(arg1,"You feel drunk. Woah!") then
		  return 2
		
		elseif strfind(arg1,"You feel tipsy. Whee!") then
		  return 1
			
		end

end













-- =(-255/(100-20))*(G7-20)+255
-- DEFAULT_CHAT_FRAME:AddMessage("\124cFF"..string.format("%02x%02x%02x", 200, 0, 100).."Hello")
-- s1,s2 = string.find(arg1,"its you for %d* ")	 echo( string.sub(arg1,s1+12,s2-1) .."<")
-- local s_for = string.find(arg1," for ")		local s_space = string.find(arg1," ",s_for+5)		s_value = string.sub(arg1, s_for+5 , s_space-1 )		echo(s_for .. " "..s_space..">".. s_value)
-- arg1="Xkq's Greater Heal heals you for 5602." ;	find_healsyou = string.find(arg1,"heals you for") +14 ;	 if find_healsyou then			heal_value = string.sub( arg1 , find_healsyou , -2 )			DEFAULT_CHAT_FRAME:AddMessage(" $"..heal_value) end

-- \124cFFRRGGBB		\124r





function AmTank()
	if UnitClass("player")=="Warrior" and IsEquippedItemType("Shields") then
    return 1
	elseif PlayerBuff("Bear Form")>0 or PlayerBuff("Dire Bear Form")>0 then
		return 1
	elseif IsEquippedItemType("Shields") and PlayerBuff("Righteous Fury")>0 then
		return 1
  elseif UnitClass("player")=="Death Knight" and Aura()=="Frost Presence" then
    return 1
	end
	
		return (false)
end



















































function Event_UIerror(arg1)
	t_UIerror=GetTime()
	if arg1=="You are already mounted! Dismount first." then
		DismountSafe()
		RemoveBuff("Gray Kodo")
		RemoveBuff("Nature_Swiftness")

	elseif arg1=="You are mounted" then
		DismountSafe()
		RemoveBuff("Gray Kodo")
		RemoveBuff("Nature_Swiftness")
		RemoveBuff("Reindeer")
		
	elseif arg1=="Can't attack while mounted." then
		DismountSafe()
		RemoveBuff("Nature_Swiftness")
		RemoveBuff("Gray Kodo")
		RemoveBuff("Reindeer")

	elseif arg1=="You must be behind your target" then
		t_notBehind=GetTime()
		
	elseif arg1=="Can't speak while shapeshifted." then
		RemoveBuff("Ability_Racial_BearForm")
		RemoveBuff("Ability_Druid_CatForm")
		RemoveBuff("Ability_Druid_TravelForm")
		RemoveBuff("Spell_Nature_SpiritWolf")
		return 1
		
	elseif arg1=="You can't do that while shapeshifted." and IsResting() then
		RemoveBuff("Ability_Racial_BearForm")
		RemoveBuff("Ability_Druid_CatForm")
		RemoveBuff("Ability_Druid_TravelForm")
		RemoveBuff("Spell_Nature_SpiritWolf")
		return 2
		
	elseif arg1=="You must be standing to do that" or arg1=="You need to be standing up to loot something!" then
		dprint(" Standing")
		DoEmote("Stand")
		return 3
		
	elseif arg1=="You are in shapeshift form" then
		RemoveBuff("Shadowform")
		RemoveBuff("Spell_Nature_SpiritWolf")
		return 4
	end  --first if

	
	
	
	

	
	
	
	
	
	if arg1=="Can only use outside" or arg1=="You can't mount here" then
		t_indoors=GetTime()
		
	elseif arg1=="Can't do that while moving" then
		t_moving=GetTime()
		
	elseif arg1=="Out of range." then
		t_OutOfRange=GetTime()
		
	elseif arg1=="Nothing to dispel" then
		t_nodispel=GetTime()
		
	elseif arg1=="Target too close" and not UnitAffectingCombat("player") then
		DismountSafe()
		t_targetclose=GetTime()
		
  end





			
	if arg1 and arg1=="You can't take a taxi while shapeshifted!" and not UnitAffectingCombat("player") then
		RemoveBuff("Bear Form")
		RemoveBuff("Cat Form")
		RemoveBuff("Dire Bear Form")
		RemoveBuff("Travel Form")
    RemoveBuff("Flight Form")
    RemoveBuff("Swift Flight Form")
		return 5
	end
  
  
  
  
  
  if type(arg1)=="string" and arg1=="You must have a lance equipped." and not UnitAffectingCombat("player") then
	  if GetItemCount("Horde Lance")>0 then
		  EquipItemByName("Horde Lance")
			dprint(" Auto Equipping Horde Lance" ,1,1,0)
			
		elseif GetItemCount("Argent Lance")>0 then
		  EquipItemByName("Argent Lance")
			dprint(" Auto Equipping Argent Lance" ,1,1,0)
			
		end
		
  elseif type(arg1)=="string" and arg1=="You are mounted." and not IsFlying() and not UnitAffectingCombat("player") and ( GetRealZoneText()~="Durotar" and GetZoneText()~="Durotar" and GetMinimapZoneText()~="Durotar" ) then
	  --GetItemInfo(GetInventoryItemLink("player",16) )
	  Dismount()
		dprint(" Auto dismounting by UI request" ,1,1,0)
		
	end
  
  
  
  
  
  
end
 -- end of Event_UIerror(arg1)
 
 
-- string.sub( "Can't do that while fleeing.", 2 , -2)














function DismountSafe()
	if not IsFlying() then Dismount() end
end


























































--called simi often (0.2 sec), not in combat
function OOM_FrequentOnUpdate()


--  followmaster = "Kizrak"
  if followmaster and ( followmastercombat or not UnitAffectingCombat("player") ) and not UnitCastingInfo("player") and not UnitChannelInfo("player") and PlayerBuff("INV_Drink_07")==0 and ( PlayerBuff("INV_Drink_")==0 or PlayerBuff("INV_Drink_")==PlayerBuff("Dire Brew") ) and PlayerBuff("INV_Misc_Fork&Knife")==0 and not PlayerMoving() and not UnitIsDeadOrGhost("player") and not UnitChannelInfo("player") then
    for i=1,4 do
      if ( followmastercombat or not UnitAffectingCombat("party"..i) ) and CheckInteractDistance("party"..i,4) and ( not CheckInteractDistance("party"..i,2) or not CheckInteractDistance("party"..i,3) ) and (  UnitName("party"..i)==followmaster or strlower( UnitName("party"..i) )==strlower( followmaster )  ) and not UnitIsDeadOrGhost("party"..i) and xtimer("follow",4) then
        FollowUnit("party"..i)
      end
    end
  end


	
	
	
	if type(t_LFG_PROPOSAL_SHOW)=="number" and s_LFG_PROPOSAL_SHOW and GetTime()-t_LFG_PROPOSAL_SHOW>(40-1.5) then
		dprint("TIME TO ACCEPT GROUP! " .. GetTime()-t_LFG_PROPOSAL_SHOW )
		
		s_LFG_PROPOSAL_SHOW = nil
		
		AcceptProposal()
	
	end
	
	
	
	if not autoFlyTrack then
	  --ignore
	elseif IsFlying() and Cooldown("Find Herbs")==0 and Cooldown("Find Minerals")==0 and GetTrackingTexture()=="Interface\\Icons\\Spell_Nature_Earthquake" and xtimer("autoFlyTracking",1) then
	  SetTrackingByName("Find Herbs")
	elseif IsFlying() and Cooldown("Find Herbs")==0 and Cooldown("Find Minerals")==0 and GetTrackingTexture()=="Interface\\Icons\\INV_Misc_Flower_02" and xtimer("autoFlyTracking",1) then
	  SetTrackingByName("Find Minerals")
	end
	
	


  t_OOM_FrequentOnUpdate = GetTime()
end







































function OutOfManaAlertMessage()
  if not OOMwarning then
    --OOMwarning must be RW R P or None
    OOMwarning = "RW"
  end
  
  if ( not oomTimer or GetTime()-oomTimer>120 ) and not UnitIsPVP("player") then
  
		if ( OOMwarning=="RW" ) and UnitAffectingCombat("player") and CanInvite() and xtimer("RaidOOM",120) then
			SendChatMessage("I am Out of Mana!","RAID_WARNING")
		elseif ( OOMwarning=="RW" or OOMwarning=="R" ) and UnitAffectingCombat("player") and GetNumRaidMembers()>0 and xtimer("RaidOOM",120) then
			SendChatMessage("I am Out of Mana!","RAID")
		elseif ( OOMwarning=="RW" ) and UnitAffectingCombat("player") and GetNumPartyMembers()>0 and ( UnitIsVisible("party1") or UnitIsVisible("party2") or UnitIsVisible("party3") or UnitIsVisible("party4") ) and GetNumRaidMembers()==0 and xtimer("ReportOOM",45) then
			SendChatMessage("I am Out of Mana!","RAID_WARNING")
		elseif ( OOMwarning=="RW" or OOMwarning=="R" or OOMwarning=="P" ) and UnitAffectingCombat("player") and GetNumVisibleTeam()>0 and xtimer("ReportOOM",120) then
			SendChatMessage("I am Out of Mana!","PARTY")
		else
			dprint("You are out of mana")
		end
    
		if not UnitExists("pet") and not BattleGround() and not UnitIsPVP("player") and ( GetNumRaidMembers()<=5 or xtimer("EmoteOOM",30) ) then
		  DoEmote("OOM")
		end
    
		oomTimer = GetTime()
	end
end






























































ChatRefreshRate=120;

--called infrequently and only out of combat
function OOM_OnUpdate(elapsed)
	if nil and ( ( PlayerBuff("INV_Drink_")>0 or ( PlayerBuff("INV_Misc_Fork&Knife")>0 and PlayerBuff("INV_Misc_Fork&Knife")<7.5 ) ) and (( PlayerBuff("INV_Drink_")>0 and UnitMana("player")/UnitManaMax("player")==1 ) or PlayerBuff("INV_Drink_")==0 ) and (( PlayerBuff("INV_Misc_Fork&Knife")>0 and UnitHealth("player")/UnitHealthMax("player")==1 ) or PlayerBuff("INV_Misc_Fork&Knife")==0 ) )	then
		if nil and xtimer("Stand",30) and PlayerBuff("Nature_Swiftness")==0 then DoEmote("stand") return end
    --still needs fixing
    
	elseif not t_BindClearTarget and t_OnLoad and GetTime()-t_OnLoad>1 then
--		BindClearTarget()
--		BindTaunt()
		if true then
			--ignore
		elseif UnitClass("player")=="Mage" then
			Do_Not_AutoMark = "Mage"
		elseif UnitClass("player")=="Priest" and Talent("Shadowform")==0 then
			Do_Not_AutoMark = "Priest"
		end
		
		t_BindClearTarget=GetTime()
    
    --fix default chat frame fading
    DEFAULT_CHAT_FRAME:SetFadeDuration(600)
    DEFAULT_CHAT_FRAME:SetTimeVisible(600)
    
    --combat frame? fading
    ChatFrame2:SetFadeDuration(600)
    ChatFrame2:SetTimeVisible(600)
    
    --chat frame fading
    ChatFrame3:SetFadeDuration(600)
    ChatFrame3:SetTimeVisible(600)
		
		--SET COMBATLOGRANGE 2000
		--sets range for the combat log to 2000 yrs
		CombatLogRange2000()

    
	elseif ( ChatRefreshRate ) and ( not ChatRefresh or GetTime()-ChatRefresh>ChatRefreshRate ) and UnitAffectingCombat("player") then
		DEFAULT_CHAT_FRAMEScrollToBottom() 
		ChatRefresh=GetTime()
    
	elseif UnitName("player")=="Shelak" and t_OnLoad and GetTime()-t_OnLoad>4 then
		Deviation("MANA",UnitMana("player"))
    
		
--	elseif t_OnLoad and GetTime()-t_OnLoad > 35 and not WhoMadhawk then
--	  SendWho( "n-" .. "Madhawk" .. " c-" .. "Warlock" .. " r-" .. "Orc" )
--		WhoMadhawk = GetTime()

	end
	
	
	
	
	
  
	
	
	
	
	
		-- AutoTracking (kittys)	patch 2.3
	if UnitCastingInfo("player") or UnitChannelInfo("player") or UnitIsDeadOrGhost("player") then
		--nil
	elseif t_UnitSpellCast and GetTime()-t_UnitSpellCast<1.5 then
		--nil
    
  elseif UnitAffectingCombat("player") or UnitAffectingCombat("target") or UnitAffectingCombat("mouseover") or UnitAffectingCombat("pet") then
		--nil  
	elseif t_UnitSpellCast and GetTime()-t_UnitSpellCast<2.5 then
		--nil
  elseif Aura()=="Cat Form" and not UnitAffectingCombat("player") and not strfind( GetTrackingTexture() , "Interface\\Icons\\Ability_Tracking" ) and Cooldown("Track Humanoids")==0 and UnitCreatureType("target")=="Humanoid" and ( UnitCanAttack("player","target") and UnitCanAttack("target","player") and not UnitIsDeadOrGhost("target") ) and ( UnitIsPVP("target") or BattleGround() ) and xtimer("AutoTracking",6) then
		SetTrackingByName("Track Humanoids")  
    
	elseif UnitClass("player")=="Hunter" and strfind( GetTrackingTexture() , "Interface\\Minimap\\Tracking\\None" ) and Cooldown("Track Hidden")==0 and xtimer("AutoTracking",3) then
		SetTrackingByName("Track Hidden")
  elseif Aura()=="Cat Form" and not UnitAffectingCombat("player") and strfind( GetTrackingTexture() , "Interface\\Minimap\\Tracking\\None" ) and Cooldown("Track Humanoids")==0 and xtimer("AutoTracking",6) then
		SetTrackingByName("Track Humanoids")  
	elseif BattleGround() then
		--nil
    
	elseif Aura()~="Cat Form" and strfind( GetTrackingTexture() , "Interface\\Minimap\\Tracking\\None" ) and Cooldown("Find Treasure")==0 and xtimer("AutoTracking",3) then
		SetTrackingByName("Find Treasure")
	elseif Aura()~="Cat Form" and strfind( GetTrackingTexture() , "Interface\\Minimap\\Tracking\\None" ) and Cooldown("Find Minerals")==0 and xtimer("AutoTracking",3) then
		SetTrackingByName("Find Minerals")
	elseif Aura()~="Cat Form" and strfind( GetTrackingTexture() , "Interface\\Minimap\\Tracking\\None" ) and Cooldown("Find Herbs")==0 and xtimer("AutoTracking",3) then
		SetTrackingByName("Find Herbs")
	end
	
	if PlayerBuff("Dire Bear Form")>0 or PlayerBuff("Bear Form")>0 then
    t_BearForm = GetTime()
  end

  
  
  
  
  
  
  
  if swapTrackingInFlight and not UnitAffectingCombat("player") and Cooldown("Find Minerals")==0 and Cooldown("Find Herbs")==0 and IsFlying() and xtimer("flipfloptrack",3) then
    if Track()=="Find Minerals" then
      SetTrackingByName("Find Herbs")
    else
      SetTrackingByName("Find Minerals")
    end
  end
  
  
	
	
	
	
	
	
	
	--for Quests (was for chirtsmas)
	if not t_QueriedForQuests and t_OnLoad and GetTime()-t_OnLoad>9 then
--		dprint(" Querying Quests...")
	    QueryQuestsCompleted()
		t_QueriedForQuests = GetTime()
	end
	
	
	
	
	
	
	
	
--	SingularityWarningTime = 2;
  --[[
  -- SingularityTrack = "Prayer of Mending"
  if SingularityTrack then
    newDurationSing,newWhoSing = Singularity(SingularityTrack)
    
		if not SingularityTrackWho or not UnitName(SingularityTrackWho) then
		  --skip
    elseif ( SingularityTrackDur and SingularityTrackDur>=SingularityWarningTime ) and ( newDurationSing and newDurationSing<=SingularityWarningTime ) then
      dprint( ColorText(1,1,0)..SingularityTrack ..ColorText().. " is about to end from "..ColorText(1,0.5,1)..UnitName(SingularityTrackWho) )
    elseif ( SingularityTrackDur and SingularityTrackDur>=SingularityWarningTime ) and not newDurationSing then
      dprint( ColorText(1,1,0)..SingularityTrack ..ColorText().. " has ended early from "..ColorText(1,0.5,1)..UnitName(SingularityTrackWho) )
    end
    
    SingularityTrackDur = newDurationSing
    SingularityTrackWho = newWhoSing
  end
  ]]--
  
  

  -- auto loot disenchants
  if t_Disenchant and GetTime() - t_Disenchant < 4 and xtimer("autoLootDisencahnts",1) then
    for aldi=1,GetNumLootItems() do
      local lootIcon, lootName, lootQuantity, rarity, locked = GetLootSlotInfo(aldi)
      
      if lootName and ( strfind( lootName , "Crystal") or strfind( lootName , "Dust") or strfind( lootName , "Essence") or strfind( lootName , "Shard") ) then
        dprint("DE loot found! " ..ColorText(1,0,1).. lootName ..ColorText().. " Auto Looting...")
        LootSlot(aldi)
      else
        dprint( lootName )
      end
      
    end
    
    
  end
	
  -- auto loot disenchants
  if t_Milling and GetTime() - t_Milling < 6 and GetLootSlotInfo(1) and xtimer("autoLootMilling",1) then
    for aldi=1,GetNumLootItems() do
      local lootIcon, lootName, lootQuantity, rarity, locked = GetLootSlotInfo(aldi)
      
      if lootName and ( strfind( lootName , "Pigment") ) then
        dprint("Milling loot found! " ..ColorText(1,0,1).. lootName ..ColorText().. " Auto Looting...")
        LootSlot(aldi)
      else
        dprint( lootName )
      end
      
    end
    
  end
  
	
	
	-- auto loot prospecting
  if t_Prospecting and GetTime() - t_Prospecting < 6 and GetLootSlotInfo(1) and xtimer("autoLootProspecting",1) then
    for aldi=1,GetNumLootItems() do
      local lootIcon, lootName, lootQuantity, rarity, locked = GetLootSlotInfo(aldi)
      
      if lootName and true then
        dprint("Prospecting loot found! " ..ColorText(1,0,1).. lootName ..ColorText().. " Auto Looting...")
        LootSlot(aldi)
      else
        dprint( lootName )
      end
      
    end
    
  end
	
	
	
	
	
	-- auto loot fishing
	if UnitChannelInfo("player")=="Fishing" then
	  t_fishing = GetTime()
	  
	elseif t_fishing and GetTime() - t_fishing < 4 and GetLootSlotInfo(1) and xtimer("autoLootFishing",0.2) then
    for aldi=1,GetNumLootItems() do
      local lootIcon, lootName, lootQuantity, rarity, locked = GetLootSlotInfo(aldi)
      
      if lootName  then
        dprint("Fishing Loot found! " ..ColorText(1,0,1).. lootName ..ColorText().. " Auto Looting...")
        LootSlot(aldi)
      else
        dprint( lootName )
      end
      
    end
	
	end
	
	
	
	
	
	
	
	
	if not t_OnLoad or GetTime()-t_OnLoad < 8 then
		--wait
	elseif IsResting() and WeeklyQuestStatus()==1 and xtimer("TurnInWeeklyMsg",60*3) then
	  dprint(" TURN IN WEEKLY!" ,1,0,0)
	  UIErrorsFrame:AddMessage("TURN IN WEEKLY!",1,0,0)
	elseif IsResting() and GetHonorCurrency()>=75000 and xtimer("MAX_HONOR",60*60*3) then
		dprint(" MAX HONOR!" ,1,0,0)
		UIErrorsFrame:AddMessage("MAX HONOR!",1,0,0)
	end
	
	
	
	
	
	
	--[[
	if not enableOOMGUI then
	  --exit
		
	elseif not t_OnLoad or t_OnLoad + 2 > GetTime() then
	  --wait
		
	elseif UnitClass("player")=="Paladin" and myT:GetTexture()~="Interface\\Icons\\Ability_Paladin_BlessedMending" and Cooldown("Sacred Shield")~=-1 then
	  myT:SetTexture("Interface\\Icons\\Ability_Paladin_BlessedMending")
		myF:Show()
		myText:Show()
		hide_myF = nil
		
  elseif UnitClass("player")=="Paladin"  and Cooldown("Sacred Shield")~=-1 then
	
	  local dur,who = Singularity("Sacred Shield")
		if myText and myText.font and dur then
			myText.font:SetText(round( dur ) )
			if not updatingText then
				myF:SetAlpha(.10)
			end
			updatingText = GetTime()
		elseif updatingText then
			myText.font:SetText(' ')
			myF:SetAlpha(.90)
			updatingText = false
		end
		
	elseif UnitClass("player")=="Shaman" and myT:GetTexture()~="Interface\\Icons\\Spell_Nature_SkinofEarth" and Cooldown("Earth Shield")~=-1 then
	  myT:SetTexture("Interface\\Icons\\Spell_Nature_SkinofEarth")
		myF:Show()
		myText:Show()
		hide_myF = nil
		
  elseif UnitClass("player")=="Shaman" and Cooldown("Earth Shield")~=-1 then

		local dur,who,apps = Singularity("Earth Shield")
		if myText and myText.font then
		  if apps~=oldESapps then
			  myText.font:SetText( apps )
				
				if not apps or apps==0 then
				  myF:SetAlpha(1)
				elseif apps==8 or apps==6 then
				  myF:SetAlpha(.05)
			  elseif apps==3 then
				  myF:SetAlpha(.32)
			  elseif apps==2 then
				  myF:SetAlpha(.62)
				elseif apps==1 then
				  myF:SetAlpha(.90)
				end
				
				oldESapps = apps
			end
		
		end
		
		
		
		
	--not a shaman or paladin
	elseif not hide_myF then
		myT:SetTexture("Interface\\Icons\\INV_Misc_QuestionMark")
		myF:Hide()
		myText:Hide()
		
		dprint(" Hiding Icon ")
		hide_myF = GetTime()
	
	end
		]]--
		--[[	myText.font:SetText(round( dur ) )
			if not updatingText then
				myF:SetAlpha(.10)
			end
			updatingText = GetTime()
		elseif updatingText then
			myText.font:SetText(' ')
			myF:SetAlpha(.90)
			updatingText = false
		end ]]--
	

	
	--[[
	if AutoGossip() then
		dprint("AutoGossip()")
		t_AutoGossip=GetTime()
		t_OOM_OnUpdate=nil
		return --prevent slow down !!
	elseif t_AutoGossip and GetTime()-t_AutoGossip<2 then
		t_OOM_OnUpdate=nil
		return --prevent slow down !!
	end
	]]--
	if AutoGossip() then
		dprint("AutoGossip()")
		t_AutoGossip=GetTime()
		return --prevent slow down ?!?
	end
	
	
	
	
	
	

	--used to slow down calls
	t_OOM_OnUpdate = GetTime()
end -- end of OOM_OnUpdate(elapsed)






SingularityWarningTime = 3;
--SingularityTrack = "Prayer of Mending"
SingularityTrackDur = 0
SingularityTrackWho = nil



--quests
function UpdateQuests()
    dprint(" Querying Quests...")
    QueryQuestsCompleted()
    t_QueriedForQuests = GetTime()
end



-- Onupdate delay variables
-- xkq_delay
-- OOM_updateDelay
-- xkq_delay = 2 ; OOM_updateDelay = 2