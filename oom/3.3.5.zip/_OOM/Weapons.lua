-- UIErrorsFrame:AddMessage("msg",0,1,.5,1,2)
-- string.find(UnitDebuff("target",i),sDebuffName)
-- DEFAULT_CHAT_FRAME:AddMessage("woot!")





function Weapons_OnLoad()
  this:RegisterEvent("PLAYER_REGEN_DISABLED")
  this:RegisterEvent("PLAYER_REGEN_ENABLED")
--  this:RegisterEvent("SPELL_UPDATE_USABLE")

  this:RegisterEvent("CHAT_MSG_COMBAT_CREATURE_VS_CREATURE_HITS")
  this:RegisterEvent("CHAT_MSG_COMBAT_CREATURE_VS_PARTY_HITS")
  this:RegisterEvent("CHAT_MSG_COMBAT_CREATURE_VS_SELF_HITS")
  this:RegisterEvent("CHAT_MSG_COMBAT_FRIENDLYPLAYER_HITS")
  this:RegisterEvent("CHAT_MSG_COMBAT_HOSTILEPLAYER_HITS")
  this:RegisterEvent("CHAT_MSG_COMBAT_PARTY_HITS")
  this:RegisterEvent("CHAT_MSG_COMBAT_PET_HITS")
  this:RegisterEvent("CHAT_MSG_COMBAT_SELF_HITS")

  this:RegisterEvent("CHAT_MSG_SPELL_CREATURE_VS_CREATURE_DAMAGE")
  this:RegisterEvent("CHAT_MSG_SPELL_CREATURE_VS_PARTY_DAMAGE")
  this:RegisterEvent("CHAT_MSG_SPELL_CREATURE_VS_SELF_DAMAGE")
  this:RegisterEvent("CHAT_MSG_SPELL_FRIENDLYPLAYER_DAMAGE")
  this:RegisterEvent("CHAT_MSG_SPELL_HOSTILEPLAYER_DAMAGE")
  this:RegisterEvent("CHAT_MSG_SPELL_PARTY_DAMAGE")
  this:RegisterEvent("CHAT_MSG_SPELL_PERIODIC_CREATURE_DAMAGE")
  this:RegisterEvent("CHAT_MSG_SPELL_PERIODIC_FRIENDLYPLAYER_DAMAGE")
  this:RegisterEvent("CHAT_MSG_SPELL_PERIODIC_HOSTILEPLAYER_DAMAGE")
  this:RegisterEvent("CHAT_MSG_SPELL_PERIODIC_PARTY_DAMAGE")
  this:RegisterEvent("CHAT_MSG_SPELL_PERIODIC_SELF_DAMAGE")
  this:RegisterEvent("CHAT_MSG_SPELL_PET_DAMAGE")
  this:RegisterEvent("CHAT_MSG_SPELL_SELF_DAMAGE")

  this:RegisterEvent("UPDATE_INVENTORY_ALERTS")
  this:RegisterEvent("BAG_UPDATE")
  this:RegisterEvent("SPELLS_CHANGED")
  this:RegisterEvent("ZONE_UNDER_ATTACK")

  this:RegisterEvent("UNIT_INVENTORY_CHANGED")
  this:RegisterEvent("UNIT_ATTACK")
--  this:RegisterEvent("UNIT_COMBAT")
  this:RegisterEvent("UNIT_DAMAGE")
  this:RegisterEvent("UNIT_DEFENSE")
--  this:RegisterEvent("UNIT_HEALTH")
--  this:RegisterEvent("UNIT_RAGE")
  this:RegisterEvent("UNIT_RESISTANCES")
  this:RegisterEvent("UNIT_STATS")
  this:RegisterEvent("UNIT_TARGET")

  this:RegisterEvent("UNIT_SPELLCAST_CHANNEL_START")
  this:RegisterEvent("UNIT_SPELLCAST_CHANNEL_STOP")
  this:RegisterEvent("UNIT_SPELLCAST_CHANNEL_UPDATE")
  this:RegisterEvent("UNIT_SPELLCAST_DELAYED")
  this:RegisterEvent("UNIT_SPELLCAST_FAILED")
  this:RegisterEvent("UNIT_SPELLCAST_INTERRUPTED")
  this:RegisterEvent("UNIT_SPELLCAST_SENT")
  this:RegisterEvent("UNIT_SPELLCAST_START")
  this:RegisterEvent("UNIT_SPELLCAST_STOP")
  this:RegisterEvent("UNIT_SPELLCAST_SUCCEEDED")
  this:RegisterEvent("UNIT_SPELLMISS")





end









function Weapons_OnEvent(arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9)
  t_WeaponsOnEvent = GetTime()
  if event=="PLAYER_REGEN_DISABLED" then
    if not UnitAffectingCombat("player") and HaveItem("Lei of Lilies") and not HaveItem("Lily Root") then
      local startTime, duration, enable = GetItemCooldown("Lei of Lilies");
      if startTime+duration-GetTime()<30 then
	  EquipItemByName("Lei of Lilies")
        echo("Equipping: Lei of Lilies")
      end
--    elseif HaveItem("Earthwarden's Coif") and xtimer("Hxt_Head",2) then
--      EquipItemByName("Earthwarden's Coif")
--      echo("Equipping: Earthwarden's Coif")
    end
  elseif not t_MeleeDmg then
    t_MeleeDmg = GetTime()

  elseif event and arg1 and type(arg1)=="string" then  
    if strfind(event,"its you for ") and not strfind(event,"SPELL") then
      debug_WeaponsEvent = event .. arg1
      if not UnitChannelInfo("player") and PlayerHealth()<80 and not IsEquippedItemType("Shields") and ( t_MeleeDmg and GetTime()-t_MeleeDmg<10 ) and ( UnitClass("player")=="Warrior" or UnitClass("player")=="Paladin" or UnitClass("player")=="Shaman" ) then
        EquipShield()
      end 
    t_MeleeDmg = GetTime()   
    end
  t_MeleeDmg = GetTime()
  end
end



-- UnitChannelInfo("player")
-- PlayerBuff("Redoubt")~=0 













function EquipShield()
  if IsEquippedItemType("Two-Hand") then
    --two hander equipped
    return
  elseif not xtimer("equipShield",4) and ClearCursor() then
    return

  elseif LastRecordedShield and HaveItem(LastRecordedShield) then
	  EquipItemByName(LastRecordedShield)
    echo("Equipping: "..LastRecordedShield.." *")
  elseif HaveItem("Crest of the Sha'tar") then
    EquipItemByName("Crest of the Sha'tar")
    echo("Equipping: Crest of the Sha'tar")
	elseif HaveItem("Platinum Shield of the Valorous") then
    EquipItemByName("Platinum Shield of the Valorous")
    echo("Equipping: Platinum Shield of the Valorous")
  elseif HaveItem("Rhombeard Protector") then
    EquipItemByName("Rhombeard Protector")
    echo("Equipping: Rhombeard Protector")
  elseif HaveItem("Landslide Buckler") then
    EquipItemByName("Landslide Buckler")
    echo("Equipping: Landslide Buckler")
  elseif HaveItem("Aegis of the Scarlet Commander") then
    EquipItemByName("Aegis of the Scarlet Commander")
    echo("Equipping: Aegis of the Scarlet Commander")

	elseif IsEquippedItemType("Shields") then
	  --already have shield equipped
  elseif xtimer("Cannot_find_sheild",60*10) then
    echo("Cannot find shield")
  end
end



























function OffHandInfo()
  offhandLink = GetInventoryItemLink("player",17)
	if offhandLink then
	  local itemName, itemLink, itemRarity, itemLevel, itemMinLevel, itemType, itemSubType, itemStackCount, itemEquipLoc, itemTexture = GetItemInfo( offhandLink )
	  return itemName, itemSubType
	end
	return nil, nil
end













function Weapons_OnUpdate(arg1)
  offhandName, offhandType = OffHandInfo()
  if IsEquippedItemType("Shields") and LastRecordedShield ~= offhandName and offhandType=="Shields" then
		  LastRecordedShield = offhandName
	end
	
  if ( BattleGround() or ( UnitIsPVP("player") and UnitIsPVP("target") ) ) and ( not t_MeleeDmg or GetTime()-t_MeleeDmg>8 ) and PlayerHealth()>90 and ( UnitAffectingCombat("player") or UnitAffectingCombat("target") ) and GetShapeshiftForm()~=2 and UnitClass("player")=="Warrior" and ( IsEquippedItemType("Shields") or GetInventoryItemTexture("player", 17)==nil ) and xtimer("EquipOffWeapon",20) then
    if HaveItem("Whispering Blade of Slaying") then
      EquipItemByName("Whispering Blade of Slaying",17)
      echo("Equipping: Whispering Blade of Slaying")
    end
  elseif GetInventoryItemTexture("player", 16)==nil and UnitAffectingCombat("player") and xtimer("EquipMainWeapon",6) then
    if HaveItem("Emerald Ripper") then
      EquipItemByName("Emerald Ripper",16)
      echo("Equipping: Emerald Ripper")
    end
	elseif GetInventoryItemTexture("player", 17)=="Interface\\Icons\\INV_RoseBouquet01" and PlayerHealth()<100 and UnitAffectingCombat("player") and xtimer("RoseBouquet",60) then
	  EquipShield()
  elseif UnitClass("player")=="Warrior" and Aura()=="Defensive Stance" and not IsEquippedItemType("Shields") and PlayerHealth()<100 and UnitAffectingCombat("player") and xtimer("DefensiveShield",12) then
	  EquipShield()
  end
end


