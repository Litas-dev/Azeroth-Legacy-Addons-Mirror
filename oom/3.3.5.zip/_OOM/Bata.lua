

function AutoPriestBuff()
  if UnitBuffCount("player","Inner Fire")==0 then
    DEFAULT_CHAT_FRAME:AddMessage("Inner Fire")
    CastSpellByName("Inner Fire")
    return "Inner Fire"
  end
  for i=1,5 do
    if UnitBuffCount("party"..i,"Power Word: Fortitude")==0 and UnitName("party"..i) then
      DEFAULT_CHAT_FRAME:AddMessage("Power Word: Fortitude -> " .. UnitName("party"..i) )
      TargetUnit("party"..i)
      CastSpellByName("Power Word: Fortitude")
      return "party"..i
    end
  end
end





function UnitBuffCount(sUnit,nBuff)
  local value=0
  for i=1,30 do
    name,rank,icon,count = UnitBuff(sUnit,i)
    if not name and not rank and not icon and not count then return value end
    if name==nBuff then
      if count==0 then count=1 end
      value=value+count
    end
  end
  return value
end















function MageWaterCount()
  return ( GetItemCount("Conjured Mana Strudel") + GetItemCount("Conjured Mana Pie") + GetItemCount("Conjured Mana Biscuit") + GetItemCount("Conjured Glacier Water") + GetItemCount("Conjured Mountain Spring Water") + GetItemCount("Conjured Crystal Water") + GetItemCount("Conjured Sparkling Water") + GetItemCount("Conjured Mineral Water") + GetItemCount("Conjured Spring Water") + GetItemCount("Conjured Purified Water") + GetItemCount("Conjured Fresh Water") + GetItemCount("Conjured Water") )
end






function MageFoodCount()
  return ( GetItemCount("Conjured Mana Strudel") + GetItemCount("Conjured Mana Pie") + GetItemCount("Conjured Mana Biscuit") + GetItemCount("Conjured Croissant") + GetItemCount("Conjured Cinnamon Roll") + GetItemCount("Conjured Sweet Roll") + GetItemCount("Conjured Sourdough") + GetItemCount("Conjured Pumpernickel") + GetItemCount("Conjured Rye") + GetItemCount("Conjured Bread") + GetItemCount("Conjured Muffin") )
end





function CurrentMageWater()
  if nil then
	elseif GetItemCount("Conjured Mana Strudel")>0 then
	  return "Conjured Mana Strudel"
	elseif GetItemCount("Conjured Mana Pie")>0 then
	  return "Conjured Mana Pie"
	elseif GetItemCount("Conjured Mana Biscuit")>0 then
	  return "Conjured Mana Biscuit"
		
  elseif GetItemCount("Conjured Water")>0 then
    return "Conjured Water"
  elseif GetItemCount("Conjured Fresh Water")>0 then
    return "Conjured Fresh Water"
  elseif GetItemCount("Conjured Purified Water")>0 then
    return "Conjured Purified Water"
  elseif GetItemCount("Conjured Spring Water")>0 then
    return "Conjured Spring Water"
  elseif GetItemCount("Conjured Mineral Water")>0 then
    return "Conjured Mineral Water"
  elseif GetItemCount("Conjured Sparkling Water")>0 then
    return "Conjured Sparkling Water"
  elseif GetItemCount("Conjured Crystal Water")>0 then
    return "Conjured Crystal Water"
  elseif GetItemCount("Conjured Mountain Spring Water")>0 then
    return "Conjured Mountain Spring Water"
  elseif GetItemCount("Conjured Glacier Water")>0 then
    return "Conjured Glacier Water"
  end
end





function CurrentMageFood()
  if nil then
	elseif GetItemCount("Conjured Mana Strudel")>0 then
	  return "Conjured Mana Strudel"
	elseif GetItemCount("Conjured Mana Pie")>0 then
	  return "Conjured Mana Pie"
	elseif GetItemCount("Conjured Mana Biscuit")>0 then
	  return "Conjured Mana Biscuit"
		
  elseif GetItemCount("Conjured Bread")>0 then
    return "Conjured Bread"
  elseif GetItemCount("Conjured Rye")>0 then
    return "Conjured Rye"
  elseif GetItemCount("Conjured Pumpernickel")>0 then
    return "Conjured Pumpernickel"
  elseif GetItemCount("Conjured Sourdough")>0 then
    return "Conjured Sourdough"
  elseif GetItemCount("Conjured Sweet Roll")>0 then
    return "Conjured Sweet Roll"
  elseif GetItemCount("Conjured Cinnamon Roll")>0 then
    return "Conjured Cinnamon Roll"
  elseif GetItemCount("Conjured Croissant")>0 then
    return "Conjured Croissant"
  elseif GetItemCount("Conjured Muffin")>0 then
    return "Conjured Muffin"
  end
end