-- UIErrorsFrame:AddMessage("msg",0,1,.5,1,2)
-- string.find(UnitDebuff("target",i),sDebuffName)
-- DEFAULT_CHAT_FRAME:AddMessage("woot!")
-- DEFAULT_CHAT_FRAMEScrollToBottom()
















function Test_OnUpdate(arg1)
  if targetTalents() ~= r_talents and xtimer("backup",1) then
	  r_talents = targetTalents(1)
	end

	if xtimer("testing",6) then
	  dprint("^")
		
--	CastSpellByName("Disenchant")
	end
	
end


















function WhoLowestUnit()
  low_value=999999
  low_unit="nil"

  for i=1,40 do
    if CheckInteractDistance("raid"..i,4) and UnitHealth("raid"..i)/UnitHealthMax("raid"..i)<1.00 and UnitHealth("raid"..i)<low_value and not UnitIsDeadOrGhost("raid"..i) then
      low_value=UnitHealth("raid"..i)
      low_unit= "raid"..i
    end
  end

  echo( low_unit )
end



























function LowestWeaponSkill(behind)
  DEFAULT_CHAT_FRAMEScrollToBottom()
  if behind and type(behind)=="number" then
    for skillIndex=1,GetNumSkillLines() do
      skillName, isHeader, isExpanded, skillRank, numTempPoints, skillModifier, skillMaxRank, isAbandonable, stepCost, rankCost, minLevel, skillCostType, skillDescription = GetSkillLineInfo(skillIndex)
      if skillDescription and string.find( skillDescription , "your chance to hit." ) and skillMaxRank-skillRank > behind then
        DEFAULT_CHAT_FRAME:AddMessage( skillName .. "  " .. skillRank)
      end
    end

  else

    local l_v=9999
    local l_s=-1
    for skillIndex=1,GetNumSkillLines() do
      skillName, isHeader, isExpanded, skillRank, numTempPoints, skillModifier, skillMaxRank, isAbandonable, stepCost, rankCost, minLevel, skillCostType, skillDescription = GetSkillLineInfo(skillIndex)
      if skillDescription and string.find( skillDescription , "your chance to hit." ) and skillRank and skillRank<l_v then
        l_s = skillIndex
        l_v = skillRank 
      end
    end
    skillName, isHeader, isExpanded, skillRank, numTempPoints, skillModifier, skillMaxRank, isAbandonable, stepCost, rankCost, minLevel, skillCostType, skillDescription = GetSkillLineInfo(l_s)
    DEFAULT_CHAT_FRAME:AddMessage( skillName .. "  " .. skillRank)
  end
end






--[[  MOVED TO _OOM/Information.lua

function ListWeaponSkills()
  DEFAULT_CHAT_FRAMEScrollToBottom()
  skillList = {}

  for skillIndex=1,GetNumSkillLines() do
    skillName, isHeader, isExpanded, skillRank, numTempPoints, skillModifier, skillMaxRank, isAbandonable, stepCost, rankCost, minLevel, skillCostType, skillDescription = GetSkillLineInfo(skillIndex)
      skillList[skillIndex] = {}
      skillList[skillIndex]["skillName"] = skillName
      skillList[skillIndex]["skillRank"] = skillRank
      skillList[skillIndex]["skillDescription"] = skillDescription
  end

  table.sort(skillList, function(a,b) return a["skillRank"]>b["skillRank"] end)

  for skillIndex=1,GetNumSkillLines() do
    if skillList[skillIndex]["skillDescription"] and string.find( skillList[skillIndex]["skillDescription"], "your chance to hit." ) and skillList[skillIndex]["skillRank"] and skillList[skillIndex]["skillRank"]<UnitLevel("player")*5 then
      DEFAULT_CHAT_FRAME:AddMessage( skillList[skillIndex]["skillRank"] .. "  " .. skillList[skillIndex]["skillName"]  )
    end
  end
end
]]--

























































function CraftIndexByName(cname)
  for i=1,GetNumCrafts() do
    craftName, craftSubSpellName, craftType, numAvailable, isExpanded, trainingPointCost, requiredLevel = GetCraftInfo(i)
    if craftName==cname then return i end
  end
  return nil
end



function AutoEnchant(nenchantment,nitem)
  BracerMinorHealth = CraftIndexByName(nenchantment)
  if BracerMinorHealth then
    DoCraft(BracerMinorHealth)
    UCIBN(nitem)
  end
end
















function FindSpellsByName(nspell)
  local i = 1
  while true do
   local spellName, spellRank = GetSpellName(i, BOOKTYPE_SPELL)
   if not spellName then
      do break end
   end
   
   -- use spellName and spellRank here
   if nspell and spellName and strfind(spellName,nspell) then
     if spellName ~= GetSpellName(i+1, BOOKTYPE_SPELL) then
       DEFAULT_CHAT_FRAME:AddMessage( spellName .. '(' .. spellRank .. ')' )
     end
   end
   
   i = i + 1
  end
end












-- string.find(alpha,bata)
-- DEFAULT_CHAT_FRAME:AddMessage(text)



--[[

function Able(a_spellname)
  if Cooldown(a_spellname)==0 and SpellInRange(a_spellname) and SpellUsable(a_spellname) then
    return 1
  else
    return
  end
end
]]--



















function enchantmentyelltimer()
  if not TT then TT=0 end
  if ( GetTime()-TT >45 ) then
    TT=GetTime()
    SendChatMessage("Free +1 Str/Sta/Spirit to Bracer, Minor Resistance Cloak, or Lesser Health Chest!  [ " .. GetMinimapZoneText() .. " ]  PST!","YELL")
  end
end
















































function BGKillCount()
  RequestBattlefieldScoreData()
  for bgi=1,30 do
    local name, killingBlows, honorKills, deaths, honorGained, faction, rank, race, class = GetBattlefieldScore(bgi)
    if name==UnitName("player") then
      DEFAULT_CHAT_FRAME:AddMessage(killingBlows)
      return killingBlows
    end
  end
  return -1
end










function PauseFor(valuename,timepassed)
  if (not valuename) or (not timepassed) then
    return 0
  elseif GetTime()-valuename > timepassed then
    return (GetTime()-valuename)
  else
    return 
  end 
end




















function Ready(spellname)
  SPELL_ID=SpellID(spellname)

  if SPELL_ID==-1 then
    return
  end

  if debug then echo(SPELL_ID) end

  _,SPELL_RANK=GetSpellName(SPELL_ID,1)
  SPELL_RANK=string.sub(SPELL_RANK,6)
  SPELL_RANK=tonumber(SPELL_RANK)

  if debug then echo(SPELL_RANK) end

  if Cooldown(spellname)>0 then
    return
  elseif SPELL_RANK and CastOptions.GetManaRank(spellname,SPELL_RANK) and CastOptions.GetManaRank(spellname,SPELL_RANK)<SPELL_RANK then
    return
  end
  
  return CastOptions.GetManaRank(spellname,SPELL_RANK)
end


























--[[

function TargetBG()
  if not BattleGround() or not UnitIsVisible("pet") then return end
  RequestBattlefieldScoreData()
  RequestBattlefieldPositions()

  if UnitRace("Player")=="Undead" or UnitRace("Player")=="Orc" or UnitRace("Player")=="Tauren" or UnitRace("Player")=="Troll" then
    MyFaction=0
  else
    MyFaction=1
  end

      if UnitCanAttack("player","target") and UnitIsPlayer("target") and UnitCanAttack("target","player") and UnitHealth("target")>0 and not UnitIsDeadOrGhost("target") and UnitCreatureType("target")~="Critter" then
        SetCycleName=UnitName("target")
        PetAttack()
      end

  for bgi=31,0,-1 do
    local name, killingBlows, honorKills, deaths, honorGained, faction, rank, race, class = GetBattlefieldScore(bgi)
    if name and faction and faction~=MyFaction then
      TargetByName(name)
      if UnitCanAttack("player","target") and UnitIsPlayer("target") and UnitCanAttack("target","player") and UnitHealth("target")>0 and not UnitIsDeadOrGhost("target") and UnitCreatureType("target")~="Critter" then
        SetCycleName=UnitName("target")
        PetAttack()
      end
    end
  end

  ClearTarget()

  if UnitIsVisible("pettarget") then
    TargetUnit("pettarget")
  else
    ClearTarget()
  end

  AssistUnit("pet")
  Assist()
  AssistDouble()
  AssistNear()
end

]]--










--UnitBuff(
--name, rank, iconTexture, count, duration, timeLeft
--name, rank, icon             , count, debuffType, duration, expirationTime, _, isStealable
--name, rank, iconTexture, count, debuffType, duration, expirationTime, _, isStealable

function AppEarthShield(nUnit)
  if not nUnit or not UnitName(nUnit) then
    return -1
  end

	local buffName, buffRank, buffTexture, buffApplications, debuffType, duration, expirationTime, isMine, isStealable = UnitBuff(nUnit,"Earth Shield")
	
  if type(buffApplications)=="number" and isMine=="player" then
    return buffApplications
		
  elseif not buffName and not buffTexture then
    return 0
		
  end
		
  return 0
end















function EarthShield(uName)
  local tUnit=FindUnitByName(uName)
  if not tUnit then ListEarthShield() return end
  local AppCount=AppEarthShield(tUnit)
  return (tUnit.."@"..AppCount)
end






function ListEarthShield()
  local AppCount=AppEarthShield("player")
  if UnitName("player") and AppCount and AppCount>0 then
    echo( UnitName("player").."&"..AppCount )
  end
  AppCount=nil

  for j=1,5 do
    local AppCount=AppEarthShield("party"..j)
    if UnitName("party"..j) and AppCount and AppCount>0 then
      echo( UnitName("party"..j).."&"..AppCount )
    end
    AppCount=nil
  end

  for j=1,5 do
    local AppCount=AppEarthShield("partypet"..j)
    if UnitName("partypet"..j) and AppCount and AppCount>0 then
      echo( UnitName("partypet"..j).."&"..AppCount )
    end
    AppCount=nil
  end

end











function GetMyEarthShield()
  local AppCount = AppEarthShield("focus")
  if AppCount>0 then
    return AppCount , "focus"
  end

  local AppCount = AppEarthShield("target")
  if AppCount>0 then
    return AppCount , "target"
  end

  local AppCount = AppEarthShield("player")
  if AppCount>0 then
    return AppCount , "player"
  end
	
  local AppCount = AppEarthShield("focustarget")
  if AppCount>0 then
    return AppCount , "focustarget"
  end
	
	local AppCount = AppEarthShield("targettarget")
  if AppCount>0 then
    return AppCount , "targettarget"
  end
	
	
  for h=1,GetNumPartyMembers() do
    local AppCount = AppEarthShield("party"..h)
    if AppCount>0 then
      return AppCount , "party"..h
    end
    local AppCount = AppEarthShield("partypet"..h)
    if AppCount>0 then
      return AppCount , "partypet"..h
    end
  end

  for h=1,GetNumRaidMembers() do
    local AppCount = AppEarthShield("raid"..h)
    if AppCount>0 then
      return AppCount , "raid"..h
    end
    local AppCount = AppEarthShield("raidpet"..h)
    if AppCount>0 then
      return AppCount , "raidpet"..h
    end
  end

	
	return nil , nil
end




























--	DEFAULT_CHAT_FRAME:AddMessage( text )







-- GetTotemInfo

function AllTotemInfo()
  dprint(" ")
  for index=1,4 do
	  TestTotemInfo(index)
	end 
end

-- 1 fire
-- 2 earth
-- 3 water
-- 4 air

function TestTotemInfo(index)
  if not index then index = 1 end
  local a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z = GetTotemInfo(index)
	local est_dur = round(c+d-GetTime())
	if c==0 and d==0 then
	  est_dur = ""
	end
	
	dprint(index .. " " .. ColorText(1,1,0) .. " " .. est_dur .. ColorText() ,1,0,0)
	
  TTIE(a,"a")
  TTIE(b,"b")
	TTIE(c,"c")
	TTIE(d,"d")
	TTIE(e,"e")
	TTIE(f,"f")
	TTIE(g,"g")
	TTIE(h,"h")
	TTIE(i,"i")
	TTIE(j,"j")
	TTIE(k,"k")
	TTIE(l,"l")
	TTIE(m,"m")
	TTIE(n,"n")
	TTIE(o,"o")
	TTIE(p,"p")
	TTIE(q,"q")
	TTIE(r,"r")
	TTIE(s,"s")
	TTIE(t,"t")
	TTIE(u,"u")
	TTIE(v,"b")
	TTIE(w,"x")
	TTIE(x,"x")
	TTIE(y,"y")
	TTIE(z,"z")
	
end



function TTIE(varValue,varName)
  if varValue and type(varValue)~="boolean" then
	  if type(varName)=="string" then
	    echo(varName.." "..varValue)
		else
		  echo(varValue)
		end
	elseif type(varValue)=="boolean" then
	  if varValue==true then
		  varValue = "TRUE"
		else
		  varValue = "FALSE"
		end
		if type(varName)=="string" then
	    echo(varName.." "..varValue)
		else
		  echo(varValue)
		end
	end
end



function TT()
	for index=1,4 do
	  local arg1, totemName, startTime, duration = GetTotemInfo(index)
	  local est_dur = round(startTime+duration-GetTime() )
	  DEFAULT_CHAT_FRAME:AddMessage(totemName .. "  " .. est_dur)  
	end  
end













function BGKillCount()
  RequestBattlefieldScoreData()
  for bgi=1,30 do
    local name, killingBlows, honorKills, deaths, honorGained, faction, rank, race, class = GetBattlefieldScore(bgi)
    if name==UnitName("player") then
--    DEFAULT_CHAT_FRAME:AddMessage(killingBlows)
      return killingBlows
    end
  end
  return -1
end







-- if CastOptions.GetManaRank("Demon Armor",3) ) == 3 then 













--[[
#showtooltip Taunt
/stopmacro [target=targettarget,noraid,group] ; [target=targettarget,noexists]
/cast [exists,harm,nodead] Taunt
]]--








































-----------------------------------------------------------------------------------------------------------------------
--[[
TestR.Xbank = function (arg1)
  if UnitName("player")~="Xbank" then return end

  local name, texture, count, quality, canUse, price = GetAuctionSellItemInfo()
  if name~="Snowball" then return end
  if count~=20 then return end

  if name=="Snowball" and count==20 and UnitName("player")=="Xbank" then
    DEFAULT_CHAT_FRAME:AddMessage("Automatic Auction")
    StartAuction(1*100*100 , 1.5*100*100 , 24*60)
  end

end
]]--
