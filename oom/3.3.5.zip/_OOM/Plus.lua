-- UIErrorsFrame:AddMessage("msg",0,1,.5,1,2)
-- string.find( UnitDebuff("target",i),sDebuffName )
-- DEFAULT_CHAT_FRAME:AddMessage("woot!")
-- DEFAULT_CHAT_FRAMEScrollToBottom()





Plus_OnLoad = function ()
--  this:RegisterEvent("COMBAT_LOG_EVENT_UNFILTERED")


	this:RegisterEvent("BAG_UPDATE");
	this:RegisterEvent("LOOT_CLOSED");
	this:RegisterEvent("LOOT_OPENED");
	this:RegisterEvent("LOOT_SLOT_CLEARED");

	this:RegisterEvent("PARTY_INVITE_REQUEST");
	this:RegisterEvent("CHAT_MSG_WHISPER");
	this:RegisterEvent("CHAT_MSG_SAY");
	this:RegisterEvent("CHAT_MSG_PARTY");
	this:RegisterEvent("CHAT_MSG");
	this:RegisterEvent("CHAT_MSG_CHANNEL");

--	this:RegisterEvent("UNIT_HEALTH");
--	this:RegisterEvent("UNIT_MANA");
--	this:RegisterEvent("UNIT_RAGE");
--	this:RegisterEvent("UNIT_ENERGY");
--	this:RegisterEvent("UNIT_FOCUS");

	this:RegisterEvent("UI_INFO_MESSAGE");
	this:RegisterEvent("UI_ERROR_MESSAGE");
	this:RegisterEvent("MINIMAP_PING");

	this:RegisterEvent("SPELLS_CHANGED");
	this:RegisterEvent("SPELLCAST_CHANNEL_START");
	this:RegisterEvent("SPELLCAST_CHANNEL_UPDATE");
	this:RegisterEvent("SPELLCAST_CHANNEL_STOP");
	this:RegisterEvent("SPELLCAST_START");
	this:RegisterEvent("SPELLCAST_STOP");
	this:RegisterEvent("SPELLCAST_FAILED");
	this:RegisterEvent("SPELLCAST_INTERRUPTED");
	this:RegisterEvent("SPELLCAST_DELAYED");
--	this:RegisterEvent("SPELL_UPDATE_USABLE");
--	this:RegisterEvent("SPELL_UPDATE_COOLDOWN");

	this:RegisterEvent("PLAYER_TARGET_CHANGED");

	this:RegisterEvent("PLAYER_LEVEL_UP");

	this:RegisterEvent("CHAT_MSG_BG_SYSTEM_ALLIANCE");
	this:RegisterEvent("CHAT_MSG_BG_SYSTEM_HORDE");
	this:RegisterEvent("CHAT_MSG_BG_SYSTEM_NEUTRAL");
	this:RegisterEvent("CHAT_MSG_BG_SYSTEM_HORDE");

	this:RegisterEvent("PLAYER_FLAGS_CHANGED");

	this:RegisterEvent("UPDATE_BATTLEFIELD_SCORE");
	this:RegisterEvent("UPDATE_BATTLEFIELD_STATUS");
	this:RegisterEvent("UPDATE_WORLD_STATES");

	this:RegisterEvent("RAID_ROSTER_UPDATE");
	this:RegisterEvent("CHAT_MSG_COMBAT_HOSTILE_DEATH");

	this:RegisterEvent("CHAT_MSG_SPELL_CREATURE_VS_SELF_DAMAGE");
	this:RegisterEvent("CHAT_MSG_SPELL_DAMAGESHIELDS_ON_SELF");
	this:RegisterEvent("CHAT_MSG_SPELL_FAILED_LOCALPLAYER");
	this:RegisterEvent("CHAT_MSG_SPELL_PERIODIC_CREATURE_BUFFS");
	this:RegisterEvent("CHAT_MSG_SPELL_PERIODIC_CREATURE_DAMAGE");
	this:RegisterEvent("CHAT_MSG_SPELL_PERIODIC_SELF_DAMAGE");
	this:RegisterEvent("CHAT_MSG_SPELL_SELF_DAMAGE");



	SLASH_LFG1 = "/lfg";
	SlashCmdList["LFG"] = LFGtoggle;

	SLASH_ECHO1 = "/echo";
	SlashCmdList["ECHO"] = ECHO;

	SLASH_LOC1 = "/loc";
	SlashCmdList["LOC"] = LOC;

	SLASH_WSG1 = "/wsg";
	SlashCmdList["WSG"] = WhoWSG;

	SLASH_AB1 = "/ab";
	SlashCmdList["AB"] = WhoAB;

	SLASH_MAKELEADER1 = "/make";
	SlashCmdList["MAKELEADER"] = MakeLeader;

	SLASH_TARGETINFO1 = "/info";
	SLASH_TARGETINFO1 = "/tarinfo";
	SLASH_TARGETINFO1 = "/targetinfo";
	SlashCmdList["TARGETINFO"] = EchoTargetInfo;

	SLASH_TEST1 = "/test";
	SlashCmdList["TEST"] = test;

	SLASH_TEXTURE1 = "/texture";
	SlashCmdList["TEXTURE"] = Textures;

	SLASH_SETTRACK1 = "/track";
	SlashCmdList["SETTRACK"] = SetTrack;

	SLASH_MATH1 = "/math";
	SlashCmdList["MATH"] = function(msg) msg = "mathmacro =" .. msg; mathmacro = "Invalid Syntax"; RunScript(msg); ChatFrame1:AddMessage(mathmacro,0,1,.5); end;

	SLASH_WHOT1 = "/whot";
	SlashCmdList["WHOT"] = WhoT;


	--DEFAULT_CHAT_FRAME:AddMessage("Hello World!",0,1,1)
end



-----------------------------------------------------------------------------------------------------------------------





function WhoT(cmdtext)
  DEFAULT_CHAT_FRAMEScrollToBottom()
  if UnitExists("target") then
    SendWho( "n-" .. UnitName("target") .. " c-" .. UnitClass("target") .. " r-" .. UnitRace("target") )
  else
    DEFAULT_CHAT_FRAME:AddMessage("No target to preform /who" ,0,1,.5) 
  end
end



function LOC(cmdtext)
  DEFAULT_CHAT_FRAMEScrollToBottom()
  local px, py = GetPlayerMapPosition("player");
  DEFAULT_CHAT_FRAME:AddMessage( " X: " .. px*100 .. "   Y: " .. py*100  ,0,1,.5) 
end



function SetTrack(cmdtext)
  if strlen(cmdtext) <=1 then
    TrackUnitName=nil
    DEFAULT_CHAT_FRAME:AddMessage("Track Cleared") 
    return
  end
  TrackUnitName=cmdtext
  DEFAULT_CHAT_FRAME:AddMessage(TrackUnitName) 
end



function ECHO(cmdtext)
  DEFAULT_CHAT_FRAMEScrollToBottom()
  RunScript(DEFAULT_CHAT_FRAME:AddMessage( gsub(cmdtext,"\124", "\124\124") ))
end



function SlashBattleGround(cmdtext)
  if BattleGround() then
    PromoteAll()
  else
    WhoWSG()
  end
end



function WhoWSG(cmdtext)
  SendWho(" z-\"Warsong Gulch\"  " .. floor(UnitLevel("player")/10)*10 .. "-" .. floor(UnitLevel("player")/10)*10+9 );
--DEFAULT_CHAT_FRAME:AddMessage(floor(UnitLevel("player")/10)*10 .. " " .. floor(UnitLevel("player")/10)*10+9)
end

function WhoAB(cmdtext)
  SendWho(" z-\"Arathi Basin\"  ");
end



function MakeLeader(cmdtext)
  DEFAULT_CHAT_FRAMEScrollToBottom()
  PromoteToLeader("target")
end



function Textures(cmdtext)
  DEFAULT_CHAT_FRAMEScrollToBottom()
  if cmdtext and tonumber(cmdtext) and tonumber(cmdtext)>=0 then
    if GetActionTexture( tonumber(cmdtext) ) then
      DEFAULT_CHAT_FRAME:AddMessage( "Texture " .. tonumber(cmdtext) .. "   " .. GetActionTexture( tonumber(cmdtext) ) , 245/255, 245/255, 250/255)
      return
    end
    return
  end

  local start=1
  
  DEFAULT_CHAT_FRAME:AddMessage("---Textures---",250/255,0/255,0/255)

  if UnitClass("player")=="Warrior" then
    local start=73
  end

  for i=start,start+11 do
    DEFAULT_CHAT_FRAME:AddMessage( GetActionTexture(i) , 225/255, 225/255, 225/255)
  end
end

-----------------------------------------------------------------------------------------------------------------------






























-----------------------------------------------------------------------------------------------------------------------

Plus_OnUpdate = function (arg1)
  debug_code0 = GetTime()
	
	
	if UnitClass("player")=="Rogue" and PlayerHealth()>99 and Unit_Buff("Blessing of Protection")>0 then
	  RemoveBuff("Blessing of Protection")
		if xtimer("rogue_remove_protection1",22) or xtimer("rogue_remove_protection2",22) or xtimer("rogue_remove_protection3",22) then
		  dprint("   Auto-Removing Blessing of Protection")
		end
	end
	
	
	
	if UnitClass("player")=="Paladin" and Cooldown("Divine Intervention")>60*19 and xtimer("DivineIntervention",60*19) then
	  if GetNumRaidMembers()==0 and xtimer("DI_Warning",60*9) then
		  SendChatMessage("\124cff71d5ff\124Hspell:19752\124h[Divine Intervention]\124h\124r !","RAID_WARNING")
		elseif GetNumRaidMembers()>0 and xtimer("DI_Warning",60*9) then
		  SendChatMessage("\124cff71d5ff\124Hspell:19752\124h[Divine Intervention]\124h\124r !","RAID")
		else
		  DEFAULT_CHAT_FRAME:AddMessage(" \124cff71d5ff\124Hspell:19752\124h[Divine Intervention]\124h\124r ! ")
		end
	end
	

  if not c_charge and UnitClass("player")=="Warrior" then
    c_charge=Cooldown("Charge")
  elseif c_charge~=Cooldown("Charge") and UnitClass("player")=="Warrior" then
    if Cooldown("Charge")>c_charge and Cooldown("Charge")>12 and xtimer("charge",13) then DoEmote("Charge") end
    c_charge=Cooldown("Charge")
  end


  if UnitClass("player")=="Priest" and Cooldown("Lightwell")>3*60-10 and xtimer("Lightwell",3*60-10) then
    DEFAULT_CHAT_FRAMEScrollToBottom()
    SendChatMessage("creates a Lightwell.","EMOTE")
  end




  if UnitClass("player")=="Shaman" and Cooldown("Mana Tide Totem")>5*60-20 and xtimer("ManaTide",4*60) then
    DEFAULT_CHAT_FRAMEScrollToBottom()
    SendChatMessage("creates a Mana Tide Totem.","EMOTE")
  end




  if nil and BattleGround() and BattleGround()==20 and savedloc~=AB_Nearest() and xtimer("_736",3) then
    echo( AB_Nearest() )
    savedloc=AB_Nearest()
  end




  if UnitAffectingCombat("player") then
    t_combat=GetTime()
  elseif not UnitAffectingCombat("player") and UnitMana("player")/UnitManaMax("player")>2/3 then
    oomTimer=nil
  end



  if LFGtoggleBool then CheckAutoLFG() end

  

  
  
  -- Auto stand
  curD = EatingOrDrinking()
  if not lastD then
    lastD = curD
    
  elseif delayAutoStand and GetTime()<delayAutoStand then
    --skip/wait
    
  elseif lastD ~= curD then
  
    if UnitChannelInfo("player") or UnitCastingInfo("player") or UnitAffectingCombat("player") then
      --ignore
      
    elseif curD==0 and lastD>0 then
      UIErrorsFrame:AddMessage("Standing" ,0,1,.5 ,1,2) --green
      DoEmote("Stand")
      
    elseif curD<8 and PlayerHealth() >= 100 and ( PlayerMana() >= 100 or UnitPowerType("player")~=0 ) and xtimer("autostandRed",15) then
      UIErrorsFrame:AddMessage("Standing" ,1,0,.5 ,1,2)  --red
      DoEmote("Stand")
      
    end
    lastD = curD
    
  end





  if Unit_Buff("pet","Feed Pet Effect")>0 and xtimer("Feed_Pet_Effect",29) then
    if GetNumVisiblePartyMembers()>0 and max( UnitLevel("party0"),UnitLevel("party1"),UnitLevel("party2"),UnitLevel("party3"),UnitLevel("party4"),UnitLevel("party5") )<UnitLevel("player") then
      SendChatMessage(" <Feeding Pet> ","PARTY")
    elseif not BattleGround() and not UnitIsPVP("player") and not UnitIsPVP("pet") then
      SendChatMessage("feeds "..UnitName("pet")..".","EMOTE")
    end
  end
	
	
	

	
	
	
	if t_pick_pocket and GetTime()-t_pick_pocket > 3 then
	  SetAutoLootDefault(false)
		t_pick_pocket = nil
	end
	
	
	

	debug_code1 = GetTime()
end

-----------------------------------------------------------------------------------------------------------------------




--UnitBuff(
--name, rank, iconTexture, count, duration, timeLeft
--name, rank, icon             , count, debuffType, duration, expirationTime, _, isStealable
--name, rank, iconTexture, count, debuffType, duration, expirationTime, _, isStealable

--[[
function EatingOrDrinking()
  curD = 60;
  foodordrink = nil;
  for buffIndex=1,90 do
    local name, rank, iconTexture, count, debuffType, duration, expirationTime = UnitBuff("player", buffIndex);
    if type(expirationTime)=="number" then
      timeleft = expirationTime - GetTime()
    else
      timeLeft = nil
    end
    if iconTexture and ( strfind(iconTexture,"INV_Drink_") or strfind(iconTexture,"INV_Misc_Fork&Knife") ) then
      if timeleft and timeleft<curD then
        curD = timeleft;
        foodordrink = name;
      end
    elseif not name and not iconTexture and not timeleft then
      return curD , foodordrink
    end
  end
  return curD , foodordrink
end
]]--







--  local name, rank, iconTexture, count, debuffType, duration, expirationTime, _, isStealable = UnitBuff("player", "Food");
function EatingOrDrinking()
  sumEOD = 0
  local _, _, _, _, _, _, DrinkExpirationTime = UnitBuff("player", "Drink");
  local _, _, _, _, _, _, FoodExpirationTime = UnitBuff("player", "Food");
  if DrinkExpirationTime then
    sumEOD = sumEOD + ( DrinkExpirationTime-GetTime() )
  end
  if FoodExpirationTime then
    sumEOD = sumEOD + ( FoodExpirationTime-GetTime() )
  end
  return sumEOD
end




















function HumarDistance()
  local px, py = GetPlayerMapPosition("player");
  hDistance = sqrt( (px*100-62.133)^2 + (py*100-33.429)^2 )
  return hDistance
end






function CheckAutoLFG()
  if not LFGautoTimer then LFGautoTimer=-99999 end
  if not LFGdelay then LFGdelay=60*4 end
  if not TeamCount then TeamCount= ( GetNumPartyMembers()+GetNumRaidMembers() ) end

  if ( GetNumPartyMembers()+GetNumRaidMembers() ) < TeamCount then
    TeamCount=( GetNumPartyMembers()+GetNumRaidMembers() )
    return
  elseif ( GetNumPartyMembers()+GetNumRaidMembers() ) > TeamCount  then
    TeamCount=(GetNumPartyMembers()+GetNumRaidMembers())
    if not BattleGround() then
      LFGtoggleBool=nil
      DEFAULT_CHAT_FRAME:AddMessage(" Automatic LFG has been turned OFF")
    end
    return
  end

  if ( ( GetTime()-LFGautoTimer ) >60*3+LFGdelay and LFGtoggleBool ) then
    LFG()
    LFGdelay=LFGdelay*0.81
    LFGautoTimer=GetTime()
    return true
  elseif not LFGtoggleBool then
    LFGautoTimer=0
    return
  elseif nil and (GetNumPartyMembers()+GetNumRaidMembers())>0 then
    LFGtoggleBool=nil
    return
  end
end








function LFGtoggle(toggle)
  TeamCount= ( GetNumPartyMembers()+GetNumRaidMembers() )
  if string.find(toggle,"force") then
    LFGtoggleBool=true
    LFG()
    DEFAULT_CHAT_FRAME:AddMessage(" Automatic LFG has been forced ON")
    return
  elseif string.find(toggle,"on") then
    LFGtoggleBool=true
  elseif string.find(toggle,"off") then
    LFGtoggleBool=nil
  elseif not LFGtoggleBool then
    LFGtoggleBool=true
  elseif LFGtoggleBool then
    LFGtoggleBool=nil
  end
  if LFGtoggleBool==true then
    DEFAULT_CHAT_FRAME:AddMessage(" Automatic LFG has been toggled ON")
  elseif LFGtoggleBool==nil then
    DEFAULT_CHAT_FRAME:AddMessage(" Automatic LFG has been toggled OFF")
  end
end









function Talk2Self()
  if not TalkSelf then TalkSelf=0 end
  if ( ( GetTime()-TalkSelf ) >120 ) then
    SendChatMessage(GetTime(),"WHISPER","Common",UnitName("player"));
    TalkSelf=GetTime()
    return true
  end
end






































--_oom/plus/event.lua
-----------------------------------------------------------------------------------------------------------------------

Plus_OnEvent = function (arg1,arg2,arg3,arg3,arg4,arg5,arg6,arg7,arg8,arg9)
  recordEvent(event)
  if ( not de_lag ) then
		return
	end

  if event=="CHAT_MSG_SAY" or event=="CHAT_MSG_WHISPER" or event=="CHAT_MSG_PARTY" then
    if arg1 and strfind( arg1, "#PING" ) then
      SendChatMessage("#PONG","WHISPER",nil,arg2)
    elseif arg2 and shadow_player and arg2==shadow_player and arg2~=UnitName("player") and shadow_player~=UnitName("player") then
      if event=="CHAT_MSG_SAY" then
        SendChatMessage(arg1,"SAY")
      elseif event=="CHAT_MSG_WHISPER" then
        SendChatMessage(arg1,"WHISPER",nil,arg2)
      elseif event=="CHAT_MSG_PARTY" then
        SendChatMessage(arg1,"PARTY")
      end
    end
  end
  
  if ( event=="CHAT_MSG_SAY" ) then 
    Event_ChatSay(arg1,arg2,arg3,arg4)
    DEFAULT_CHAT_FRAMEScrollToBottom()
    
  elseif ( event=="CHAT_MSG_SAY" or event=="CHAT_MSG_WHISPER") then 
    Event_ChatWhisper(arg1,arg2,arg3,arg4)
    DEFAULT_CHAT_FRAMEScrollToBottom()
    
  elseif nil and ( event=="BAG_UPDATE" or event=="LOOT_OPENED" ) then 
    Event_BagUpdate()
    
  elseif ( event=="CHAT_MSG_PARTY" ) then 
    Event_ShadowGame(arg1,arg2,arg3,arg4)
    DEFAULT_CHAT_FRAMEScrollToBottom()
    
  --BG auto invite
  elseif not preventBGAutoInvite and event=="CHAT_MSG_CHANNEL" and BattleGround() and not InRaid(arg2) and arg2~=UnitName("player") and type(arg2)=="string" and strlen(arg2)~=0 and ( string.find(arg3,"General") or string.find(arg3,"LocalDefense") ) and CanInvite() and UnitInRaid("player") then
    InviteUnit(arg2)
    DEFAULT_CHAT_FRAME:AddMessage(" Automatically inviting: " .. arg2)
  elseif not preventBGAutoInvite and event=="PLAYER_TARGET_CHANGED" and BattleGround() and not UnitInRaid("target") and UnitIsVisible("target") and UnitIsPlayer("target") and UnitIsFriend("target","player") and UnitInRaid("player") and UnitPlayerControlled("target") and CanInvite() then
    InviteUnit("target")
    DEFAULT_CHAT_FRAME:AddMessage(" Automatically inviting: " .. UnitName("target"))
    
    
  elseif arg1 and ( event=="CHAT_MSG_COMBAT_HOSTILE_DEATH" or event=="UPDATE_BATTLEFIELD_SCORE" ) and string.find(arg1,"slain") then
    if xtimer("Echo_Slain_Msg",120) then
      DEFAULT_CHAT_FRAME:AddMessage(arg1 ,15/16,15/16,15/16)
    elseif string.find(arg1,"You have slain ") and not strfind(arg1,"Rat") and xtimer("Echo_Slain_Msg",0.01) then
      DEFAULT_CHAT_FRAME:AddMessage(arg1 ,15/16,15/16,15/16)
      if BattleGround() then DoEmote("train") end
    end
    DEFAULT_CHAT_FRAMEScrollToBottom()
  elseif event=="PLAYER_LEVEL_UP" then
    DEFAULT_CHAT_FRAMEScrollToBottom()
    --RequestTimePlayed()
  end


  if ( GetMouseFocus() and GetMouseFocus():GetName() and GetMouseFocus():GetName()=="MinimapToggleButton" ) and ( echo_all ) then
    local argSTRING=""
    if arg1 then argSTRING=argSTRING .. arg1 .. "  " end
    if arg2 then argSTRING=argSTRING .. arg2 .. "  " end
    if arg3 then argSTRING=argSTRING .. arg3 .. "  " end
    if arg4 then argSTRING=argSTRING .. arg4 .. "  " end
    if arg5 then argSTRING=argSTRING .. arg5 .. "  " end
    if arg6 then argSTRING=argSTRING .. arg6 .. "  " end
    if arg7 then argSTRING=argSTRING .. arg7 .. "  " end
    if arg8 then argSTRING=argSTRING .. arg8 .. "  " end
    if arg9 then argSTRING=argSTRING .. arg9 .. "  " end
    DEFAULT_CHAT_FRAME:AddMessage(event .. "   " .. argSTRING )
  end

  if UnitExists("pet") then EchoPetExpChange() end

  if event and event=="CHAT_MSG_SPELL_SELF_DAMAGE" and arg1 and string.find(arg1,"immune") then
    echo("%"..arg1)
  elseif event and event=="CHAT_MSG_SPELL_SELF_DAMAGE" and arg1 and string.find(arg1,"interrupt") then
    echo("$"..arg1)
  elseif event and arg1 and type(arg1)=="string" and ( string.find(arg1,"immune") or string.find(arg1,"interrupt") or ( arg2 and type(arg2)=="string" and (string.find(arg2,"immune") or string.find(arg2,"interrupt") ) ) ) and event~="CHAT_MSG_CHANNEL" then
    if not string.find(arg1,"Thorns") and not string.find(arg1,"Fire Shield") then echo("$%".. arg1 .. event) end
  end


  t_Plus_OnEvent = GetTime()
end

-----------------------------------------------------------------------------------------------------------------------


















function Event_ChatSay(arg1,arg2)
  arg1 = strlower(arg1)
  if strfind(arg1,"invite") and strfind(arg1,"#") and arg2~=UnitName("player") and CanInvite() then
    InviteUnit(arg2)
    DEFAULT_CHAT_FRAME:AddMessage("Automatically inviting: " .. arg2)
	 
	elseif strfind(arg1,"invite") and strfind(arg1,"#") and arg2~=UnitName("player") then
		
		
	elseif strfind(arg1,"invite ") and arg2~=UnitName("player") and CanInvite() then
	  
  end
  DEFAULT_CHAT_FRAMEScrollToBottom()
end







function Event_ChatWhisper(arg1,arg2)
  arg1 = strlower(arg1)

	
  if string.find(arg1,"invite") and strfind(arg1,"#") and arg2~=UnitName("player") and CanInvite() then
    InviteUnit(arg2)
		InviteUnit( FindWhisperName(arg1) )
    DEFAULT_CHAT_FRAME:AddMessage("Automatically inviting: " .. arg2)
  end
  
  if     arg1 and inviteword1 and string.find(arg1,inviteword1) and arg2~=UnitName("player") and CanInvite() then
    InviteUnit(arg2)
		InviteUnit( FindWhisperName(arg1) )
    DEFAULT_CHAT_FRAME:AddMessage("Automatically inviting: " .. arg2)
  elseif arg1 and inviteword2 and string.find(arg1,inviteword2) and arg2~=UnitName("player") and CanInvite() then
    InviteUnit(arg2)
		InviteUnit( FindWhisperName(arg1) )
    DEFAULT_CHAT_FRAME:AddMessage("Automatically inviting: " .. arg2)
  end

  if string.find(arg1,"follow") and string.find(arg1,"#") and arg2~=UnitName("player") then
    FollowUnit(arg2)
    DEFAULT_CHAT_FRAME:AddMessage("Automatically Following: " .. arg2)
  end

	if string.find(arg1,"#make") and arg2~=UnitName("player") and UnitIsAFK("player") then
    PromoteToLeader(arg2)
    DEFAULT_CHAT_FRAME:AddMessage("Automatically Promoting to Leader: " .. arg2)
	end
	

  DEFAULT_CHAT_FRAMEScrollToBottom() 
end









function FindWhisperName(sMsg)
  if type(sMsg)~="string" then return (nil) end
  sMsg = strlower(sMsg)
  sMsg = gsub(sMsg,"invite","")
	sMsg = gsub(sMsg,"#","")
	sMsg = gsub(sMsg," ","")
	return (sMsg) 
end












function Event_ShadowGame(arg1,arg2)
  if not ShadowGameTimer then ShadowGameTimer=-9999 end
  if ( GetTime()-ShadowGameTimer>1 and arg2~=UnitName("player") and arg2==ShadowGame ) and CanInvite() and GetNumPartyMembers()>0 then
    SendChatMessage(arg1,"PARTY") 
    ShadowGameTimer=GetTime()
  end
  DEFAULT_CHAT_FRAMEScrollToBottom()
end







function EchoPetExpChange()
  if not UnitExists("pet") or not GetPetExperience() then
    return
  elseif not petCurrentExp then
    petCurrentExp,petNextExp=GetPetExperience()
  elseif petCurrentExp==0 or petCurrentExp<0 then
    petCurrentExp,petNextExp=GetPetExperience()
  elseif petCurrentExp < GetPetExperience() then
    DEFAULT_CHAT_FRAME:AddMessage("Your pet gains " .. GetPetExperience()-petCurrentExp .. " experience.     < " .. GetPetExperience() .. "/" .. petNextExp .. " >" )
    petCurrentExp,petNextExp=GetPetExperience()
  elseif petCurrentExp > GetPetExperience() then
    --DEFAULT_CHAT_FRAME:AddMessage("PET DING!!")
    petCurrentExp,petNextExp=GetPetExperience()
  end
end















































function ShardEcho()
    if not uShardCount then uShardCount=0 end
    if uShardCount ~= SoulShardCount() then
      uShardCount = SoulShardCount()
      DEFAULT_CHAT_FRAME:AddMessage("Soul Shards Remaining: " .. uShardCount ,1,0.1,1)
    end
end





function Event_BagUpdate()
  if not FreeBagSlotCount or not ShardSafetyDelay then
    FreeBagSlotCount=FREEBAGSLOTS()
    ShardSafetyDelay=GetTime()
    return nil
  end

  if not SE1 then SE1=0 end
  if not SE2 then SE2=0 end

  if SE1~=FREEBAGSLOTS() or SE2~=SoulShardCount() then
    SE1=FREEBAGSLOTS()
    SE2=SoulShardCount()
    ShardSafetyDelay=GetTime()
--  DEFAULT_CHAT_FRAME:AddMessage("Delaying Shard Calculation")
    return nil
  end

  if GetTime()-ShardSafetyDelay < 1 then
--  DEFAULT_CHAT_FRAME:AddMessage("Shard Calculation Delayed")
    return nil
  end

  ShardEcho()
  if FreeBagSlotCount~=FREEBAGSLOTS() then
    ShardSafetyDelay=GetTime()
    if ( FREEBAGSLOTS()<=0 ) and ( FREEBAGSLOTS()<FreeBagSlotCount ) and ( SoulShardCount()>10 ) then DeleteSoulShard() end
    FreeBagSlotCount=FREEBAGSLOTS()
  end
end







function DeleteSoulShard()
  DEFAULT_CHAT_FRAMEScrollToBottom()
  PutItemInBackpack()
  PutItemInBag(20)
  PutItemInBag(21)
  PutItemInBag(22)
  PutItemInBag(23)

  if CursorHasItem() then
    DEFAULT_CHAT_FRAME:AddMessage("Cannnot Delete Soul Shard due to Cursor Item",1,1,0)
    return nil
  end

  if FREEBAGSLOTS()>0 then
    DEFAULT_CHAT_FRAME:AddMessage("Error: Tried to Delete Soul Shard when you still had room",0,1,1)
    return nil
    end


  if not DeleteShardTimer then DeleteShardTimer=0 end

  if ( GetTime()-DeleteShardTimer <5 ) then
    DEFAULT_CHAT_FRAME:AddMessage("Too Soon to Delete another Soul Shard",0,1,1)
    return nil
  end


  DEFAULT_CHAT_FRAMEScrollToBottom()
  for bag=0,4 do
    for slot=1,GetContainerNumSlots(bag) do
      if ( GetContainerItemLink(bag,slot) ) then
        if ( string.find(GetContainerItemLink(bag,slot), "Soul Shard") ) then
          DeleteShardTimer=GetTime()
          DEFAULT_CHAT_FRAME:AddMessage("Deleting Soul Shard!",1,0,0)
	    PickupContainerItem(bag,slot);
          if GetContainerItemInfo(bag,slot) and string.find(GetContainerItemInfo(bag,slot),"Misc_Gem_Amethyst_02") then
            DeleteCursorItem()
		return true
            end
          return
        end
      end
    end
  end
return nil
end



--copy found in _Display\BDisplay.lua
function SoulShardCount()
SSC=0
  for bag=0,4 do
    for slot=1,GetContainerNumSlots(bag) do
      if (GetContainerItemLink(bag,slot)) then
        if (string.find(GetContainerItemLink(bag,slot), "Soul Shard")) then
          SSC=SSC+1
        end
      end
    end
  end
return SSC
end

