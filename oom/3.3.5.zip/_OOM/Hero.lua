Hero = {
	VERSION = 1
}














Hero_OnLoad = function()
  this:RegisterEvent("CHAT_MSG_COMBAT_FACTION_CHANGE");
  this:RegisterEvent("UPDATE_FACTION");
--  this:RegisterEvent("UNIT_FACTION");
  this:RegisterEvent("CHAT_MSG_MONSTER_EMOTE");
end







Hero_OnEvent = function(arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9)
	recordEvent(event)
  if ( not de_lag ) then
		return
	end


-- ***************************************************************************************************************
-- Find Events *** Find Events *** Find Events *** Find Events *** Find Events *** Find Events *** Find Events *** 
-- ***************************************************************************************************************

  mastereventstring=""
  if arg1 then mastereventstring=mastereventstring .. ">" .. arg1 end
  if arg2 then mastereventstring=mastereventstring .. ">" .. arg2 end
  if arg3 then mastereventstring=mastereventstring .. ">" .. arg3 end
  if arg4 then mastereventstring=mastereventstring .. ">" .. arg4 end
  if arg5 then mastereventstring=mastereventstring .. ">" .. arg5 end
  if arg6 then mastereventstring=mastereventstring .. ">" .. arg6 end
  if arg7 then mastereventstring=mastereventstring .. ">" .. arg7 end
  if arg8 then mastereventstring=mastereventstring .. ">" .. arg8 end
  if arg9 then mastereventstring=mastereventstring .. ">" .. arg9 end





  if not notset_WarnBatBomb and UnitName("player")=="Xkq" then
    WarnBatBomb =nil
    notset_WarnBatBomb=GetTime()
  end

  if ( event and event=="CHAT_MSG_MONSTER_EMOTE" and arg1 and arg2 ) and string.find(arg1,"fully engulfs in flame and a maddened look appears in his eyes!") and string.find(arg2,"Bat Rider") and WarnBatBomb then
    if WarnBatBomb and ( IsPartyLeader() or IsRaidOfficer() or IsRaidLeader() ) and xtimer("BombBat",3) then
      SendChatMessage( strsub(gsub(arg1,"%s",arg2.." ",1),3) , "RAID_WARNING" )
    elseif WarnBatBomb and xtimer("BombBat",3) then
      SendChatMessage( strsub(gsub(arg1,"%s",arg2.." ",1),3) , "RAID" )
    else
      DEFAULT_CHAT_FRAME:AddMessage( gsub(arg1,"%%s",arg2.." ",1) ,.9,.1,.2)
    end
  elseif nil and ( event and event=="CHAT_MSG_MONSTER_EMOTE" and arg1 and arg2 ) and not( string.find(arg1,"becomes enraged!") or string.find(arg1,"attempts to run away in fear!") or string.find(arg2,"Dark Iron Land Mine") ) then
    DEFAULT_CHAT_FRAME:AddMessage( gsub(arg1,"%%s",arg2,1) ,.1,.8,.6)
  end 






  if event and arg1 and event=="CHAT_MSG_COMBAT_FACTION_CHANGE" then
  s_faction_update = string.sub(arg1, 17 , -19 )
--DEFAULT_CHAT_FRAME:AddMessage( string.sub(arg1, 17 , -17 ) .."<")
    for hero_index=0,GetNumFactions()+1 do
	  FactionInfo = GetFactionInfo(hero_index)
      if FactionInfo and s_faction_update and string.find( FactionInfo,s_faction_update ) then
        SetWatchedFactionIndex(hero_index)
--      DEFAULT_CHAT_FRAME:AddMessage( s_faction_update )
        return hero_index
      elseif FactionInfo and s_faction_update and string.find( s_faction_update,FactionInfo ) then
        SetWatchedFactionIndex(hero_index)
--      DEFAULT_CHAT_FRAME:AddMessage( s_faction_update )  
        return hero_index
      end
    end
    if s_faction_update then
      DEFAULT_CHAT_FRAME:AddMessage("Faction not found:  " .. s_faction_update )
    end
  end


-- ***************************************************************************************************************

end

























-- 1) Yellow Star
-- 2) Orange Circle
-- 3) Purple Diamond
-- 4) Green Triangle
-- 5) Pale Moon
-- 6) Blue Square
-- 7) Red X "Cross"
-- 8) Skull



do_not_mark=1
locWhisperer=""

Hero_OnUpdate = function(arg1)
  --if do_not_mark then return end

	if locWhisperer and strlen(locWhisperer)>=2 and xtimer("AddonLocWhisper",0.3) then
		local posX, posY = GetPlayerMapPosition("player")
		if posX and posY and oldPosX and oldPosY then
		  whisperLocDelta = math.sqrt( (posX-oldPosX)^2 + (posY-oldPosY)^2 )*100
		else
		  whisperLocDelta = -1
	  end
		if not oldPosX or not oldPosY or whisperLocDelta > 1 or xtimer("refreshLocWhisper",35) then
		  if xtimer("AddonLocWhisper2",2) then
				SendAddonMessage("Loc^^",posX.." , "..posY,"WHISPER",locWhisperer)
				--dprint("Loc "..whisperLocDelta)
				oldPosX = posX
				oldPosY = posY
			end
	  end
	end
	
	
	
  if not do_not_mark then
	  AutoRaidMark("Kizrak",7)
  end
end








function AutoRaidMark(sname,smark)
  if not( sname and smark ) then return end
  if xtimer(sname,1) then return end
  if UnitName("player")==sname and UnitIsVisible("target") and GetRaidTargetIndex("target")==nil and not UnitIsPlayer("target") then
    SetRaidTarget("target",smark)
    return -1
  end
  for index=1,40 do
    if UnitName("raid"..index)==sname and UnitIsVisible("raid"..index.."target") and GetRaidTargetIndex("raid"..index.."target")==nil and not UnitIsPlayer("raid"..index.."target") then
      SetRaidTarget("raid"..index.."target",smark)
      return index
    end
  end
  for index=1,4 do
    if UnitName("party"..index)==sname and UnitIsVisible("party"..index.."target") and GetRaidTargetIndex("party"..index.."target")==nil and not UnitIsPlayer("party"..index.."target") then
      SetRaidTarget("party"..index.."target",smark)
      return index
    end
  end
  return
end



--and xtimer("AutoMark",0)

--[[
Hero.OnUpdate = function(arg1)
  if UnitName("raid1")=="Mirubelsa" and UnitIsVisible("raid1target") and not GetRaidTargetIndex("raid1target") then
    SetRaidTarget("raid1target",7)
  end
end
]]--






























function SetWatchedFactionIndexByString(faction_name)
  if not faction_name then return end

  for hero_index=0,GetNumFactions()+1 do
    if GetFactionInfo(hero_index) and GetFactionInfo(hero_index)==faction_name then
      SetWatchedFactionIndex(hero_index)
      DEFAULT_CHAT_FRAME:AddMessage( GetFactionInfo(hero_index) ,1,0,0)
    else
      DEFAULT_CHAT_FRAME:AddMessage( GetFactionInfo(hero_index) )
    end
  end

end