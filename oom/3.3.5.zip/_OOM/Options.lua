




-- OOM_Options = {}



function ShowOptionsOnce()
	if type(OOM_Options)~="table" then
		OOM_Options = {}
		dprint(" making OOM_Options[] ")
   end
	
	if not OOM_Options["ShowOnce"] then
		OOM_LoadOptions()
	  
	else
		dprint("  /list options "..ColorText(.8,.8,.8) .." to view OOM options")
	
	end
end




function OOM_LoadOptions()

	if type(OOM_Options)~="table" then
		OOM_Options = {}
		dprint(" making OOM_Options[] ")
   end
	
	OOMOptionsFrame:Show();	
	
	
	if OOM_Options["AutoSell"]==nil or OOM_Options["AutoSell"]==1 then
		getglobal("OOMOptionsFrame_CheckButtonAutoSellGreys"):SetChecked(1)
	else
		getglobal("OOMOptionsFrame_CheckButtonAutoSellGreys"):SetChecked(0) 
	end
		
		
		
	if OOM_Options["AutoXMark"]==nil or OOM_Options["AutoXMark"]==1 then
		getglobal("OOMOptionsFrame_CheckButtonAutoXMark"):SetChecked(1)
	else
		getglobal("OOMOptionsFrame_CheckButtonAutoXMark"):SetChecked(0) 
	end
	
	
	
	
	if not IsAddOnLoaded("_Combat") then
		getglobal("OOMOptionsFrame_CheckButtonCombat"):SetChecked(0) 
		getglobal("OOMOptionsFrame_CheckButtonCombatExtra"):SetChecked(0) 
		getglobal("OOMOptionsFrame_CheckButtonCombat"):Disable() 
		getglobal("OOMOptionsFrame_CheckButtonCombatExtra"):Disable() 
	
	elseif hide_customsearchs=="self" then
		getglobal("OOMOptionsFrame_CheckButtonCombat"):SetChecked(1) 
		getglobal("OOMOptionsFrame_CheckButtonCombatExtra"):SetChecked(0) 
		getglobal("OOMOptionsFrame_CheckButtonCombatExtra"):Enable()
		
	elseif hide_customsearchs then
		getglobal("OOMOptionsFrame_CheckButtonCombat"):SetChecked(0) 
		getglobal("OOMOptionsFrame_CheckButtonCombatExtra"):SetChecked(0) 
		getglobal("OOMOptionsFrame_CheckButtonCombatExtra"):Disable()
		
	else
		getglobal("OOMOptionsFrame_CheckButtonCombat"):SetChecked(1) 
		getglobal("OOMOptionsFrame_CheckButtonCombatExtra"):SetChecked(1) 
		getglobal("OOMOptionsFrame_CheckButtonCombatExtra"):Enable()
	
	end
	
end






function OOM_SaveOptions()
	OOM_Options["ShowOnce"] = 1
	
	if OOM_Options["AutoSell"] ~= NeverNil( getglobal("OOMOptionsFrame_CheckButtonAutoSellGreys"):GetChecked() ) then
		OOM_Options["ShowOnce"] = nil
	end
	
	if OOM_Options["AutoXMark"] ~= NeverNil( getglobal("OOMOptionsFrame_CheckButtonAutoXMark"):GetChecked() ) then
		OOM_Options["ShowOnce"] = nil
	end
	
	if hide_customsearchs ~= hide_customsearchs_Options() then
	  OOM_Options["ShowOnce"] = nil
	end
	
	

	OOM_Options["AutoSell"] = NeverNil( getglobal("OOMOptionsFrame_CheckButtonAutoSellGreys"):GetChecked() )
	
	OOM_Options["AutoXMark"] = NeverNil( getglobal("OOMOptionsFrame_CheckButtonAutoXMark"):GetChecked() )
	
	hide_customsearchs = hide_customsearchs_Options()

	
	OOMOptionsFrame:Hide();
	dprint("  /list options "..ColorText(.8,.8,.8) .." to view OOM options")
end












function hide_customsearchs_Options()
	if getglobal("OOMOptionsFrame_CheckButtonCombatExtra"):GetChecked() then
		return nil
	elseif getglobal("OOMOptionsFrame_CheckButtonCombat"):GetChecked() then
		return "self"
	else
		return true
	end
end





function MakeEscUber()
	if UnitAffectingCombat("player") then
	  dprint(" ESC key can not be bound while in combat",1,1,0)
	  
	elseif xtimer("Absolutely Sure Bind ESC key",6) then
	  dprint(" If you are absolutely sure you wish to re-bind your ESC key, press again in the next 6 seconds",1,0,0)
	  
	elseif xtimer("REBIND_ESC_KEY",60) then
		EscKeyLoaded=nil
		GLOBAL_REBIND_ESC_KEY = 1
		
	else
		dprint(" ESC key has recently been bound")
		
	end
end






function NeverNil(myBool)
	if myBool then
		return myBool
	else
		return 0
	end
end