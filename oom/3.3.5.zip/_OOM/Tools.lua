-- UIErrorsFrame:AddMessage("msg",0,1,.5,1,2)
-- string.find(UnitDebuff("target",i),sDebuffName)
-- DEFAULT_CHAT_FRAME:AddMessage("woot!")
-- DEFAULT_CHAT_FRAMEScrollToBottom() 

CT = ColorText

dprint = function(...)
  DEFAULT_CHAT_FRAME:AddMessage(...)
  DEFAULT_CHAT_FRAMEScrollToBottom() 
end




function printcat(...)
	local pcstring = ""
	for pci = 1,select('#',...) do
		argType = type(select(pci,...))

		if argType=="string" or argType=="number" then
			pcstring = pcstring .. select(pci,...)

		elseif argType=="boolean" then
		
			if select(pci,...) then
				pcstring = pcstring .. ColorText(1,0,0) .. "true" ..ColorText()
			else
				pcstring = pcstring .. ColorText(1,0,0) .. "false" ..ColorText()
			end

		else
			pcstring = pcstring .. ColorText(0,0,1) .. argType ..ColorText()
		end

		if pci ~= select('#',...) then
			pcstring = pcstring .. ColorText(0,1,0) .. "_" ..ColorText()
		end
		
	end

	dprint(pcstring)
end


function cat(...)
  printcat(...)
end


function returncat(...)
  local pcstring = ""
  for pci = 1,select('#',...) do
    argType = type(select(pci,...))
    if argType=="string" or argType=="number" then
      pcstring = pcstring .. select(pci,...)
      
    elseif argType=="boolean" then
      if select(pci,...) then
        pcstring = pcstring .. ColorText(1,0,0) .. "true" ..ColorText()

      else
        pcstring = pcstring .. ColorText(1,0,0) .. "false" ..ColorText()
        
      end
    
    end
  end
	
	return pcstring
end




function delimitcat(delim,...)
  local pcstring = ""
  for pci = 1,select('#',...) do
    argType = type(select(pci,...))
    if argType=="string" or argType=="number" then
      pcstring = pcstring .. delim .. select(pci,...)
      
    elseif argType=="boolean" then
      if select(pci,...) then
        pcstring = pcstring .. ColorText(1,0,0) .. "true" ..ColorText()

      else
        pcstring = pcstring .. ColorText(1,0,0) .. "false" ..ColorText()
        
      end
    
    end
  end
	
	return pcstring
end






--[[returns player buff duration, zero if does not exists
function PlayerBuffDuration(buffName)
  local _, _, _, _, _, _, expirationTime = UnitBuff("player", buffName)
  if expirationTime then
    return expirationTime-GetTime()
  else
    return 0
  end
end  ]]--




function recordEvent(aevent)
  if type(de_OnEvent)~="table" then
	  de_OnEvent = {}
	elseif not de_OnEvent[aevent] then
	  de_OnEvent[aevent]=1
	else
		de_OnEvent[aevent]=1+de_OnEvent[aevent]
	end
end








--name, rank, icon, count, debuffType, duration, expirationTime, _, isStealable = UnitBuff(

function Unit_Buff(sUnit,sBuffName)
  local buffCount = 0;
  for i=0,35 do
    buffName, buffRank, buffTexture, buffApplications = UnitBuff(sUnit,i)
    if ( buffName and buffName==sBuffName ) or ( buffTexture and string.find(buffTexture,sBuffName) ) then
      if buffApplications>0 then
        buffCount=buffCount+buffApplications
      else
        buffCount=buffCount+1
      end
    elseif not buffName and not UnitBuff(sUnit,i) and i>1 then
      return buffCount
    end
  end
  return buffCount
end






function Unit_Debuff(sUnit,sBuffName)
  local buffCount = 0;
  for i=0,35 do
    buffName, buffRank, buffTexture, buffApplications = UnitDebuff(sUnit,i)
    if ( buffName and string.find(buffName,sBuffName)  ) or ( buffTexture and string.find(buffTexture,sBuffName) ) then
      if buffApplications>0 then
        buffCount=buffCount+buffApplications
      else
        buffCount=buffCount+1
      end
    elseif not buffName and not UnitDebuff(sUnit,i) and not buffTexture and i>1 then
      return buffCount
    end
  end
  return buffCount
end



--name,          rank,          icon,              count,                      debuffType, duration, expirationTime, _, isStealable = UnitBuff(
--buffName, buffRank, buffTexture, buffApplications                       , duration, expirationTime
--name         , rank         , iconTexture, count                     , debuffType, duration, expirationTime
--buffName, buffRank, buffTexture, buffApplications, debuffType, duration, expirationTime
--[[
function Unit_Buff_Timeleft(sUnit,sBuffName)
  local buffLeft = 0;
  for i=0,35 do
    buffName, buffRank, buffTexture, buffApplications, debuffType, duration, expirationTime = UnitBuff(sUnit,i)
    
    if type(expirationTime)=="number" then
      timeleft = expirationTime - GetTime()
    end
    if timeLeft and ( ( buffName and buffName==sBuffName ) or ( buffTexture and string.find(buffTexture,sBuffName) ) ) then
      buffLeft = buffLeft + timeLeft
    elseif not buffName and not UnitBuff(sUnit,i) and i>1 and not timeLeft then
      return buffLeft 
    end
    
  end
  return buffLeft 
end
]]--



function Unit_Buff_Timeleft(sUnit,sBuffName)
  _, _, _, _, _, _, expirationTime = UnitBuff(sUnit,sBuffName)
  if type(expirationTime)=="number" then
    return expirationTime - GetTime()
  else
    return 0
  end 
end








function RemoveBuff(sBuffName)
  for i=0,70 do
    if GetPlayerBuffName(i) and GetPlayerBuffName(i)==sBuffName then
      CancelPlayerBuff(i)
      return i
    elseif GetPlayerBuffTexture(i) and string.find(GetPlayerBuffTexture(i),sBuffName) then
      CancelPlayerBuff(i)
      return i
    elseif GetPlayerBuffName(i)==nil and GetPlayerBuffTexture(i)==nil then
      --nil
    end
  end
  return nil
end





--wrath of the lich king fix
function GetPlayerBuffName(i)
  return UnitBuff("player",i)
end


--wrath of the lich king fix
function GetPlayerBuffTexture(i)
  name, rank, icon, count, debuffType, duration, expirationTime, _, isStealable = UnitBuff("player", i)
  return icon
end





function Aura()
  for auraindex=1,10 do
    icon, name, active = GetShapeshiftFormInfo(auraindex)
    if active then
      return name
    end
  end
  return nil
end











function echo(msg)
  if type(msg)~="string" and type(msg)~="number" then
		if type(msg)=="boolean" then
			if msg then
				DEFAULT_CHAT_FRAME:AddMessage( "true" ,9/16,12/16,7/16)
			else
				DEFAULT_CHAT_FRAME:AddMessage( "false" ,9/16,12/16,7/16)
			end
		else
			DEFAULT_CHAT_FRAME:AddMessage( type(msg) ,10/16,6/16,7/16)
		end
		return
  end
  DEFAULT_CHAT_FRAME:AddMessage(msg ,1/16,12/16,7/16)
  if ( ChatRefreshRate ) and ( not ChatRefresh or GetTime()-ChatRefresh>ChatRefreshRate ) then
    DEFAULT_CHAT_FRAMEScrollToBottom() 
    ChatRefresh=GetTime()
  end
end












function CanHeal()
  if PlayerBuff("Shadowform")>0 then
    return nil
  elseif UnitPowerType("player")~=0 then
    return nil
  elseif UnitClass("player")=="Priest" and PlayerBuff("Shadowform")<=0 then
    return 1
  elseif UnitClass("player")=="Druid" and UnitPowerType("player")==0 then
    return 2
  elseif UnitClass("player")=="Shaman" then
    return 3
  elseif UnitClass("player")=="Paladin" and Talent("Spiritual Focus")>=5 then
    return 4
  end
    return nil
end















function BattleGround()
  local e_zone = GetRealZoneText() .. GetZoneText() .. GetMinimapZoneText() .. GetSubZoneText()
  if string.find(e_zone,"Warsong Gulch") then
    return 10
  elseif string.find(e_zone,"Arathi Basin") then
    return 20
  elseif string.find(e_zone,"Alterac Valley") then
    return 51
	elseif string.find(e_zone,"Eye of the Storm") then
    return 61
  elseif string.find(e_zone,"Strand of the Ancients") then
    return 71
  elseif string.find(e_zone,"Wintergrasp") then
    return 80
  else
    return
  end
end



















function PVPing()
  pvp_count = 0
	total_count = 0
	
	for i=1,GetNumRaidMembers() do
	  if UnitIsPVP("raid"..i) then
		  pvp_count = pvp_count +1
		end
		if UnitIsConnected("raid"..i) then
		  total_count = total_count +1
		end
	end
	if GetNumRaidMembers()>0 then return (pvp_count/total_count) end
	
		for i=1,GetNumPartyMembers() do
	  if UnitIsPVP("raid"..i) then
		  pvp_count = pvp_count +1
		end
		if UnitIsConnected("raid"..i) then
		  total_count = total_count +1
		end
	end
	
	return (pvp_count/total_count)
end

















































-- given any number of args, returns the first one that exists!
function firstExists(...)
  for fei=1,select('#',...) do
    if select(fei,...) then
      return select(fei,...)
    end
  end 
end





--returns the sum of all number type arg's sent to it
function sumExists(...)
  sumE = 0
  for fei=1,select('#',...) do
    if type( select(fei,...) )=="number" then
      sumE = sumE + select(fei,...)
    end
  end 
  return sumE
end



































-- copied in EventFinder.lua
function ColorText(red,green,blue)
  red = tonumber( red )
  green = tonumber( green )
  blue = tonumber( blue )

  if type(red)=="number" and type(green)=="number" and type(blue)=="number" then
    if red<=0 then red=0 end
    if green<=0 then green=0 end
    if blue<=0 then blue=0 end

    if red<=1 and green<=1 and blue<=1 then
      red = red*256
      green = green*256
      blue = blue*256
    end

    red = round( red )
    green = round( green )
    blue = round( blue )

    if red>=255 then red=255 end
    if green>=255 then green=255 end
    if blue>=255 then blue=255 end

    return "\124cFF"..string.format("%02x%02x%02x", red, green, blue)
  else
    return "\124r"
  end
end








function runningAverage(n_value)
  if not rA_n      then rA_n     = 1         else rA_n = rA_n     + 1            end
  if not rA_sum    then rA_sum = n_value     else rA_sum = rA_sum + n_value      end
  if not rA_sSqr   then rA_sSqr = n_value^2  else rA_sSqr = rA_sSqr + n_value^2  end

  sd2 = 1/(rA_n-1)*(rA_sSqr - (rA_sum)^2/rA_n)
  sd  = sqrt( abs(sd2) )
  avg = rA_sum / rA_n
end






function echorunningAverage()
  if not rA_n    then return rA_n    end
  if rA_n <=1    then return rA_n    end
  if not rA_sum  then return rA_sum  end
  if not rA_sSqr then return rA_sSqr end

  sd2 = 1/(rA_n-1)*(rA_sSqr - (rA_sum)^2/rA_n)
  sd  = sqrt( abs(sd2) )
  avg = rA_sum / rA_n

  echo("<"..rA_n.."> Mean: ".. floor(avg+0.5) .."  SD: ".. floor(sd+0.5) .. " \124cFF00FFFF Mean+SD: " .. floor(avg+sd) )
end




--[[
? 	68.26894921371%
2? 	95.44997361036%
3? 	99.73002039367%
4? 	99.99366575163%
5? 	99.99994266969%
6? 	99.99999980268%
7? 	99.99999999974%
]]--

















--given unit and list of buffs, returns lowest duration of buff(s)
function Dur_Buff(sUnit,sBuffName,gBuffName,iBuffName,aBuffName,hBuffName)
  if not sBuffName then
	  return (60*60*24*7)
	elseif not UnitExists(sUnit) or not UnitIsVisible(sUnit) or UnitIsDeadOrGhost(sUnit) then
	  return (60*60*24*7)
	elseif IsSpellInRange(sBuffName,sUnit)~=1 then
	  return (60*60*24*7)
	elseif not UnitCanAssist("player",sUnit) then
	  return (60*60*24*7)
	elseif UnitAffectingCombat(sUnit) then
    return (60*60*24*7)
	elseif UnitCreatureType(sUnit)=="Totem" then
    return (60*60*24*7)
   elseif iBuffName and UnitBuff(sUnit,iBuffName) then
		return (60*60*24*7)
   elseif aBuffName and UnitBuff(sUnit,aBuffName) then
		return (60*60*24*7)
	elseif hBuffName and UnitBuff(sUnit,hBuffName) then
		return (60*60*24*7)
	end
	
  --name, rank, icon, count, debuffType, duration, expirationTime, _, isStealable = UnitBuff(
  
  local buffLeft = 0;
  for i=0,40 do
  
    buffName, rank, buffTexture, count, debuffType, duration, expirationTime, _, isStealable = UnitBuff(sUnit,i)
    if type(expirationTime)=="number" then
      timeLeft = expirationTime - GetTime()
    else
      timeLeft = nil;
    end
    
    if buffname and buffname==iBuffName then
      --iBuffName is true, ignore this person/buff
      return (60*60*24*7)
      
    elseif timeLeft and ( ( buffName and buffName==sBuffName ) or ( buffTexture and string.find(buffTexture,sBuffName) ) or ( buffName and buffName==gBuffName ) ) then
      buffLeft = buffLeft + timeLeft
      
    elseif not buffName and not UnitBuff(sUnit,i) and not UnitBuff(sUnit,i+1) and not UnitBuff(sUnit,i+2) and i>2 and not timeLeft then
		-- no more buffs
      return buffLeft 
      
		elseif ( buffName and buffName==sBuffName ) or ( buffTexture and string.find(buffTexture,sBuffName) ) or ( buffName and buffName==gBuffName ) then
		-- if the buff belongs to someone else
		  if not timeLeft then
			  -- seconds in week
			  return (60*60*24*7)
			end
    end
    
  end
  return buffLeft 
end





TotalBuffCheck = function(...)
  return FindLowestDurationOfMyBuffAmongAllies(...)
end




-- FLDOMBAA
--given the name of buff and its group_buff version, returns the duration and unit with lowest duration
function FindLowestDurationOfMyBuffAmongAllies(...)
  local lowestDuration = (60*60*24*7)
	local lowestUnit = "~"
	
	--Target
	if Dur_Buff("target",...)==0 then
	  return 0 , "target"
	elseif Dur_Buff("target",...)<lowestDuration then
	  lowestDuration=Dur_Buff("target",...)
		lowestUnit="target"
	end
	
	--Mouseover
  if Dur_Buff("mouseover",...)==0 then
	  return 0 , "mouseover"
	elseif Dur_Buff("mouseover",...)<lowestDuration then
	  lowestDuration=Dur_Buff("mouseover",...)
		lowestUnit="mouseover"
	end
	
	--Focus
  if Dur_Buff("focus",...)==0 then
	  return 0 , "focus"
	elseif Dur_Buff("focus",...)<lowestDuration then
	  lowestDuration=Dur_Buff("focus",...)
		lowestUnit="focus"
	end
	
	
	
	for i=0,5 do
		-- Party
		if Dur_Buff("party"..i,buffnamemgroupbuffname)==0 then
		  return 0 , "party"..i
		elseif Dur_Buff("party"..i,...)<lowestDuration then
		  lowestDuration=Dur_Buff("party"..i,...)
			lowestUnit="party"..i
		end
		--Party Pet
		if Dur_Buff("partypet"..i,...)==0 then
		  return 0 , "partypet"..i
		elseif Dur_Buff("partypet"..i,...)<lowestDuration then
		  lowestDuration=Dur_Buff("partypet"..i,...)
			lowestUnit="partypet"..i
		end
	end
	
	
	--Pet
  if Dur_Buff("pet",...)==0 then
	  return 0 , "pet"
	elseif Dur_Buff("pet",...)<lowestDuration then
	  lowestDuration=Dur_Buff("pet",...)
		lowestUnit="pet"
	end
	
	
	for i=0,40 do
		-- Raid
		if Dur_Buff("raid"..i,...)==0 then
		  return 0 , "raid"..i
		elseif Dur_Buff("raid"..i,...)<lowestDuration then
		  lowestDuration=Dur_Buff("raid"..i,...)
			lowestUnit="raid"..i
		end
		--Raid Pet
		if Dur_Buff("raidpet"..i,...)==0 then
		  return 0 , "raidpet"..i
		elseif Dur_Buff("raidpet"..i,...)<lowestDuration then
		  lowestDuration=Dur_Buff("raidpet"..i,...)
			lowestUnit="raidpet"..i
		end
	end
	
	
	--TargetTarget
	if Dur_Buff("targettarget",...)==0 then
	  return 0 , "targettarget"
	elseif Dur_Buff("targettarget",...)<lowestDuration then
	  lowestDuration=Dur_Buff("targettarget",...)
		lowestUnit="targettarget"
	end
	
	--FocusTarget
  if Dur_Buff("focustarget",...)==0 then
	  return 0 , "focustarget"
	elseif Dur_Buff("focustarget",...)<lowestDuration then
	  lowestDuration=Dur_Buff("focustarget",...)
		lowestUnit="focustarget"
	end
	
	--MouseoverTarget
  if Dur_Buff("mouseovertarget",...)==0 then
	  return 0 , "mouseovertarget"
	elseif Dur_Buff("mouseovertarget",...)<lowestDuration then
	  lowestDuration=Dur_Buff("mouseovertarget",...)
		lowestUnit="mouseovertarget"
	end
	
	
	--Player
	if Dur_Buff("player",...)==0 then
	  return 0 , "player"
	elseif Dur_Buff("player",...)<lowestDuration then
	  lowestDuration=Dur_Buff("player",...)
		lowestUnit="player"
	end
	
	return lowestDuration , lowestUnit
end




















































--patch 2.3
function SetTrackingByName(nTrack)
  for i=1,GetNumTrackingTypes() do 
    local name, texture, active, category = GetTrackingInfo(i)
    if name==nTrack then
      SetTracking(i)
      return i
    end
  end
end
































function FREEBAGSLOTS()
  local slotTotal=0
    for bag=0,4 do
      slotTotal=slotTotal+GetContainerNumSlots(bag)
      for slot=1,GetContainerNumSlots(bag) do
        if ( GetContainerItemLink(bag,slot) ) then
            slotTotal=slotTotal-1
        end
      end
    end
  return slotTotal
end













function HaveItem(nItem)
  for bag=0,4 do
    for slot=1,GetContainerNumSlots(bag) do
      iName = LinkToName( GetContainerItemLink(bag,slot) )
      if iName and strfind(iName,nItem) then
        return iName
      end
    end
  end
end

--[[
function HaveItem(nItem)
  for bag=0,4 do
    for slot=1,GetContainerNumSlots(bag) do
      HI(bag,slot,nItem)
    end
  end 
end

function HI(b,s,nItem)
  iLink = GetContainerItemLink(b,s)
  if iLink and strfind(iLink,nItem) then
    dprint( LinkToName(iLink) )
  end 
end
]]--



function LinkToName(iLink)
  if not iLink then return iLink end
  return strsub(iLink ,strfind(iLink,"\124h")+2, strfind(iLink,"\124h\124")-1 ) 
end
-- a copy is in _Banker/GuildBank.lua
















function CalcXp(arg1,arg2)
      t = UnitLevel("target");
      p = UnitLevel("player");
	if ( arg1 ) then t=arg1; end
	if ( arg2 ) then p=arg2; end
      if ( t == -1 ) then
           return 0;
      end
      if ( t == p ) then
           xp = ((p * 5) + 45);
      end
      if ( t > p ) then
           xp = ((p * 5) + 45) * (1 + 0.05 * (t - p));
      end
      if ( t < p ) then
           -- need gray level "g"
           if (p < 6) then g = 0; end
           if (p > 5 and p < 40) then
                g = p - 5 - floor(p/10);
           end
           if (p > 39) then
                g = p - 1 - floor(p/5);
           end
           if (t > g) then
                -- need zero difference "z"
                if (p < 8) then z = 5; end
                if (p > 7 and p < 10) then z = 6; end
                if (p > 9 and p < 12 ) then z = 7; end
                if (p > 11 and p < 16 ) then z = 8; end
                if (p > 15 and p < 20 ) then z = 9; end
                if (p > 19 and p < 40 ) then z = 9 + floor(p/10); end
                if (p > 39) then z = 5 + floor(p/5); end
                xp = (p * 5 + 45) * (1 - (p - t) / z);
           else 
                -- t <= g, mob is Gray
                xp = 0;
           end
      end
      xp = floor(xp+0.5);    -- result is rounded before calculating rest bonus
      if ( GetRestState() == 1 and nil ) then
           xp = xp * 2;
      end
      if ( UnitClassification("target") == "elite" and nil ) then
           xp = xp * 2;
           -- what about "worldboss", "rareelite"... not sure how the XP scales
      end
      if (xp > 0) then
           return xp;
      else
           return 0;
      end
end
























function SkillRank(sname)
  for k=1,GetNumSkillLines() do
    local skillName, header, isExpanded, skillRank, numTempPoints, skillModifier, skillMaxRank, isAbandonable, stepCost, rankCost, minLevel, skillCostType, skillDescription = GetSkillLineInfo(k);
    if skillName and skillName==sname then
      --DEFAULT_CHAT_FRAME:AddMessage(skillRank)
      return skillRank
    end
  end
  return -1
end
















--[[
function BindClearTarget(override)
  if ( b_ClearTargetBound and not override ) or UnitAffectingCombat("player") then return end
  while ( GetMacroInfo("Clear") ) do DeleteMacro("Clear") DeleteMacro("Clear") end
  CreateMacro("Clear", 2, "/cleartarget\n/stopcasting\n/scrolltobottom ",1,0)
  SetBindingMacro("ESCAPE", "Clear")
  DEFAULT_CHAT_FRAME:AddMessage("Clear Target Bound" ,3/4,3/4,3/4)
  b_ClearTargetBound=GetTime()
end
]]--





function BindTaunt(override)
  if ( TauntBound and not override ) or UnitAffectingCombat("player") then return end
  if UnitClass("player")~="Warrior" then return end

  if GetMacroIndexByName("Taunt") then
    EditMacro(GetMacroIndexByName("Taunt") ,"Taunt", 610, "#showtooltip Taunt\n/stopmacro [target=targettarget,noraid,group] ; [target=targettarget,noexists]\n/cast [exists,harm,nodead] Taunt",1,0)
  else
    CreateMacro("Taunt", 610, "#showtooltip Taunt\n/stopmacro [target=targettarget,noraid,group] ; [target=targettarget,noexists]\n/cast [exists,harm,nodead] Taunt",1,0)
  end

  TauntBound=GetTime()
end


--  597+13   =    610
--  CreateMacro("Taunt", 597, "#showtooltip Taunt\n/stopmacro [target=targettarget,noraid,group] ; [target=targettarget,noexists]\n/cast [exists,harm,nodead] Taunt",1,0)

--SetBindingMacro("ESCAPE", "Clear")
--DEFAULT_CHAT_FRAME:AddMessage("Taunt Bound" ,3/4,3/4,3/4)
































































-- SellGreys()
-- Sells Grey/Gray Items from Inventory
function SellGrays()
  local itemsSoldThusFar = 0;
	local itemsSeenThusFar = 0;

  DEFAULT_CHAT_FRAMEScrollToBottom() 
  if CursorHasItem() then
    DEFAULT_CHAT_FRAME:AddMessage("Cannnot sell grays due to item on Cursor",1,1,0)
    return
  elseif Merchant() then
    DEFAULT_CHAT_FRAME:AddMessage("Selling Gray Items...     "..Merchant() ,.62,.62,.62)
  else
    DEFAULT_CHAT_FRAME:AddMessage("Listing Gray Items...",.62,.62,.62)
  end

  for bag=0,4 do
    for slot=1,GetContainerNumSlots(bag) do
		
		  if itemsSoldThusFar>=11 then
			  dprint("SellGrays has sold 11 items and is now stopping " ,.5,0,0) 
				dprint("Please type /sgi to continue selling gray items " ,.5,0,0)
			  return
				
      elseif ( GetContainerItemLink(bag,slot) ) then
        local name = GetContainerItemLink(bag,slot)
        local texture, itemCount, locked, quality, readable = GetContainerItemInfo(bag,slot);

        if name and string.find(name,"\124cff9d9d9d\124Hitem:") and quality<1 then
          DEFAULT_CHAT_FRAME:AddMessage(" " .. GetContainerItemLink(bag,slot) )
          if strfind(name,"Empty Brew Bottle") then
					  --do not sell this grey/gray item
						dprint(" Skipping Empty Brew Bottle")
					elseif Merchant() and quality<1 and itemsSoldThusFar<=11 then
					  itemsSoldThusFar = itemsSoldThusFar + 1
					  UseContainerItem(bag,slot)
				  else
					  itemsSeenThusFar = itemsSeenThusFar + 1
					end
					
        elseif SellTrashItems(name) and quality<2 then
          DEFAULT_CHAT_FRAME:AddMessage(" @" .. GetContainerItemLink(bag,slot) .. "    " .. SellTrashItems(name))
          if Merchant() and quality<1 and itemsSoldThusFar<=11 then
					  itemsSoldThusFar = itemsSoldThusFar + 1
					  UseContainerItem(bag,slot)
				  else
						itemsSeenThusFar = itemsSeenThusFar + 1
					end
					
        end

      end
			
    end
  end
	
	if Merchant() then
	  dprint("\124cff9d9d9d"..itemsSoldThusFar .. " items sold" )
  else
	  dprint("\124cff9d9d9d"..itemsSeenThusFar .. " grey items" )
	end
	
end --end of SellGrays()





function Merchant()
	if OOM_Options["AutoSell"]==0 then
		return nil
	elseif CanMerchantRepair() then
		return 1
	elseif GetMerchantNumItems()>0 then
		return 2
	elseif GetRepairAllCost()>0 then
		return 4
	else
		return nil
	end
end

--elseif IsVendorActive() then return 3





function SellTrashItems(iname)
  if false then
	  return nil
		
  elseif strfind(iname, "Penny Pouch" )            and strfind(iname, "Hitem:37606:") then
    return "Penny Pouch"  	
		
	elseif strfind(iname, "Lesser Bloodstone Ore" )  and strfind(iname, "Hitem:4278:")  then
    return "Lesser Bloodstone Ore"
		
    
  elseif UnitFactionGroup("player")=="Alliance" then
	  return "Alliance"
		
  elseif strfind(iname, "Spider Ichor" )           and strfind(iname, "Hitem:3174:") then
    return "Spider Ichor"
  elseif strfind(iname, "Boar Intestines" )        and strfind(iname, "Hitem:3172:") then
    return "Boar Intestines"

  elseif strfind(iname, "Crisp Spider Meat" )      and strfind(iname, "Hitem:1081:") then
    return "Crisp Spider Meat"
  elseif strfind(iname, "Tough Condor Meat" )      and strfind(iname, "Hitem:1080:") then
    return "Tough Condor Meat"

  elseif strfind(iname, "Stringy Vulture Meat" )   and strfind(iname, "Hitem:729:") then
    return "Stringy Vulture Meat"
  elseif strfind(iname, "Murloc Eye" )             and strfind(iname, "Hitem:730:") then
    return "Murloc Eye"
  elseif strfind(iname, "Goretusk Snout" )         and strfind(iname, "Hitem:731:") then
    return "Goretusk Snout"
		
    
  end
end








































function Color()
  DEFAULT_CHAT_FRAMEScrollToBottom() 
  a=random()
  b=random()
  c=random()
  DEFAULT_CHAT_FRAME:AddMessage("RED "..floor(a*255).."    GREEN "..floor(b*255).."    BLUE "..floor(c*255) ,a,b,c)
end


















--think "Party"..i

function GetNumVisiblePartyMembers()
  PartyCount=0
  for i=0,6 do
    if UnitExists("party"..i) and UnitIsVisible("party"..i) and UnitIsConnected("party"..i) then
      PartyCount = PartyCount+1
    end 
  end 
  return ( PartyCount ) 
end

GetNumVisibleParty = GetNumVisiblePartyMembers








function GetNumVisibleTeam()
  TeamCount = 0

  for i=0,40 do
    if UnitExists("raid"..i) and UnitIsVisible("raid"..i) and UnitIsConnected("raid"..i) then
      TeamCount = TeamCount+1
    end 
  end 
  if TeamCount>0 then
    return ( TeamCount ) 
  end

  for i=0,6 do
    if UnitExists("party"..i) and UnitIsVisible("party"..i) and UnitIsConnected("party"..i) then
      TeamCount = TeamCount+1
    end
  end 
  return ( TeamCount ) 
end










function GetNumVisibleRaid()
  RaidCount = 0

  for i=0,40 do
    if UnitExists("raid"..i) and UnitIsVisible("raid"..i) and UnitIsConnected("raid"..i) then
      RaidCount = RaidCount+1
    end 
  end 
  if RaidCount>0 then
    return ( RaidCount ) 
  end

end












function TeamTalkType(loudness)
  if loudness=="RAIDWARNING" then
	  loudness = 4
	elseif loudness=="RAID" then
	  loudness = 3
  elseif loudness=="PARTY" then
	  loudness = 2
	elseif loudness=="SAY" then
	  loudness = 1
  end

  if type(loudness)~="number" then
	  if xtimer("Teamtalktypewarningwrongerrortype",60) then
		  dprint(" please call TeamTalkType(loudness) with number ")
		end
	  return "SAY"
		
	elseif GetNumVisibleTeam()==0 or loudness==1 then
	  return "SAY"
		
	elseif loudness>=4 and ( IsRaidOfficer() or GetNumRaidMembers()==0 ) then
	  return "RAID_WARNING"
		
	elseif loudness>=3 and GetNumRaidMembers()==0 then
	  return "RAID"
		
	elseif loudness>=2 then
	  return "PARTY"
	
	end
end

































































function AddonAlpha(a_name,enable)
  DEFAULT_CHAT_FRAMEScrollToBottom() 
  if a_name then
    if enable then EnableAddOn(a_name) end
    name, title, notes, enabled, loadable, reason, security = GetAddOnInfo(a_name)
    dep1, dep2, dep3, dep4, dep5, dep6, dep7 = GetAddOnDependencies(a_name)

    dep_string = "\124cFF1040FF "
    if dep1 then dep_string = dep_string.." "..dep1 ; if enable then EnableAddOn(dep1) end end
    if dep2 then dep_string = dep_string.." "..dep2 ; if enable then EnableAddOn(dep2) end end
    if dep3 then dep_string = dep_string.." "..dep3 ; if enable then EnableAddOn(dep3) end end
    if dep4 then dep_string = dep_string.." "..dep4 ; if enable then EnableAddOn(dep4) end end
    if dep5 then dep_string = dep_string.." "..dep5 ; if enable then EnableAddOn(dep5) end end
    if dep6 then dep_string = dep_string.." "..dep6 ; if enable then EnableAddOn(dep6) end end
    if dep7 then dep_string = dep_string.." "..dep7 ; if enable then EnableAddOn(dep7) end end

    if enable then
      DEFAULT_CHAT_FRAME:AddMessage("Enabling: " .. name .. " " .. dep_string)
      return enable
    end

    echo_string = name
    if title and name~=title then echo_string = echo_string .. "  {"..title.."}" end
    if notes then echo_string = echo_string .. "\124cFFFF0000 " .. notes end

    DEFAULT_CHAT_FRAME:AddMessage(echo_string .. dep_string)
    return a_name
  end




  for index=1,GetNumAddOns() do
    name, title, notes, enabled, loadable, reason, security = GetAddOnInfo(index)
    dep1, dep2, dep3, dep4, dep5, dep6, dep7 = GetAddOnDependencies(index)

    dep_string = "\124cFF1020FF "
    if dep1 then dep_string = dep_string.." "..dep1 end
    if dep2 then dep_string = dep_string.." "..dep2 end
    if dep3 then dep_string = dep_string.." "..dep3 end
    if dep4 then dep_string = dep_string.." "..dep4 end
    if dep5 then dep_string = dep_string.." "..dep5 end
    if dep6 then dep_string = dep_string.." "..dep6 end
    if dep7 then dep_string = dep_string.." "..dep7 end

    echo_string = name
    if name~=title then echo_string = echo_string .. "  {"..title.."}" end
    if notes then echo_string = echo_string .. "\124cFFFF0000 " .. notes end

    DEFAULT_CHAT_FRAME:AddMessage(echo_string .. dep_string)
    
  end
end




function RangeTest()
  for i=1,490 do
    if IsSpellInRange(i,"spell","target")==1 then
      echo( GetSpellName(i, "spell") .. "  " .. IsSpellInRange(i,"spell","target")  )
    end
  end
end




--[[
function DisableAllAddons()
  
end
]]--




























function GetNumTeamMembers()
  if type(GetNumRaidMembers())~="number" or type(GetNumPartyMembers())~="number" then
	  return -1
	elseif GetNumRaidMembers()>GetNumPartyMembers() then
	  return GetNumRaidMembers()
	elseif GetNumPartyMembers()>GetNumRaidMembers() then
	  return GetNumPartyMembers()
  elseif GetNumRaidMembers()==0 and GetNumPartyMembers()==0 then
	  return 0
	end
	
end

























SingList = { "target","focus","player","pet","focustarget","targettarget" }



function Singularity(nbuff) --returns duration of buff, and who its on, and the count

  for key,val in pairs(SingList) do  --commons
    name, rank, icon, count, debuffType, duration, expirationTime, bSource, isStealable = UnitBuff(val,nbuff)
    if name and expirationTime and bSource=="player" then
      return expirationTime-GetTime() , val, count
    end
  end
  
  if GetNumVisibleRaid() then  --raid
    --players
    for index=1,40 do
      name, rank, icon, count, debuffType, duration, expirationTime, bSource, isStealable = UnitBuff("raid"..index,nbuff)
      if name and expirationTime and bSource=="player" then
        return expirationTime-GetTime() , "raid"..index, count
      end
    end
    --pets
    for index=1,40 do
      name, rank, icon, count, debuffType, duration, expirationTime, bSource, isStealable = UnitBuff("raidpet"..index,nbuff)
      if name and expirationTime and bSource=="player" then
        return expirationTime-GetTime() , "raidpet"..index, count
      end
    end
    
  elseif GetNumVisibleParty() then --party
    for index=0,6 do
      --players
      name, rank, icon, count, debuffType, duration, expirationTime, bSource, isStealable = UnitBuff("party"..index,nbuff)
      if name and expirationTime and bSource=="player" then
        return expirationTime-GetTime() , "party"..index, count
      end
      --pets
      name, rank, icon, count, debuffType, duration, expirationTime, bSource, isStealable = UnitBuff("partypet"..index,nbuff)
      if name and expirationTime and bSource=="player" then
        return expirationTime-GetTime() , "partypet"..index, count
      end
    end
  end
  
end




















































--[[
 use GetItemCount(exactname)

function ItemCount(iname)
  itemCount=0
  for bag=0,4 do
    for slot=1,GetContainerNumSlots(bag) do
      if (GetContainerItemLink(bag,slot)) then
        if (string.find(GetContainerItemLink(bag,slot), iname)) then
          itemCount=itemCount+1
        end
      end
    end
  end
return itemCount
end
]]--





















function BrewRam()
  maxApp=0
  for i=1,15 do
    if GetPlayerBuffApplications(i)>maxApp then
      maxApp=GetPlayerBuffApplications(i)
    end
  end
  return maxApp
end

































--Blessing Recording

function RecordBlessingPreference(nperson,nblessing)
  if nperson and nblessing and type(nblessing)=="string" and strfind(nblessing,"Blessing of ") then
	  if not blessingTable then
		  blessingTable = {}
		end
		
		if strfind(nblessing,"Might") or strfind(nblessing,"Wisdom") or strfind(nblessing,"Kings") or strfind(nblessing,"Sanctuary") then
		  if blessingTable[nperson] == nblessing then
			  UIErrorsFrame:AddMessage(nblessing.." -> "..nperson ,0,1,1)
			else
			  UIErrorsFrame:AddMessage(nblessing.." -> "..nperson ,1,.5,.0)
			end
		  blessingTable[nperson] = stringRemoveGreater(nblessing)
		end
	else
	  dprint("error blessing recording -- improper call")
	end
end





function ebt()
  for k,v in pairs(blessingTable) do
	  dprint(k..": "..ColorText(1,0,0)..v)
	end 
end



function stringRemoveGreater(nblessing)
  if strfind(nblessing,"Greater") then
	  nblessing = strsub(nblessing,9)
	end
	return nblessing 
end
























--mailbox
--Titanium Ore x6
--Titanium Bar x3
--Eternal Fire Shadow Earth

function MakeStack(itemName, size)
  local somethingwaslocked = 0
  if FREEBAGSLOTS()<=0 then
    dprint( " OUT OF INVENTORY ROOM!" ,1,0,0)
		return -1
		
	elseif CursorHasItem() then
	  ClearCursor() 
		dprint( " CURSOR HAS ITEM!" ,1,0,0)
		return -3
		
	end
	
  for bag = 0,4 do
    for slot = 1,GetContainerNumSlots(bag) do
		 
      local item = GetContainerItemLink(bag,slot)
			local texture, itemCount, locked, quality, readable = GetContainerItemInfo(bag, slot)
			
			if FREEBAGSLOTS()<=0 then
				dprint( " OUT OF INVENTORY ROOM!" ,1,0.5,0)
				return -1
				
			elseif locked then
				somethingwaslocked = 1 + somethingwaslocked
				
      elseif item and strfind(item,itemName) and type(size)=="number" and type(itemCount)=="number" and itemCount>size and FREEBAGSLOTS()>0 then
			
        dprint(" ".. item )
				
				SplitContainerItem(bag,slot,size)
				PickupContainerItem( FindEmptySlot() )
				
				return 1
      end
			
    end
  end

	
	if somethingwaslocked>0 then
		dprint( " Items Locked by Server!" ,1,1,0)
		return -2
	end
	
	dprint(" Out of Items?")
	return 5
end




function FindEmptySlot()
  for bag = 0,4 do
    for slot = 1,GetContainerNumSlots(bag) do
		 
      local item = GetContainerItemLink(bag,slot)
			local texture, itemCount, locked, quality, readable = GetContainerItemInfo(bag, slot)
			
      if not item and not texture then
--				dprint(bag .. " " .. slot .. " is empty")
			  return bag,slot
      end
			
    end
  end
end











function MailStack(itemName, size, mailslot)
  local somethingwaslocked = 0
	local otherstacksaround = 0
  if CursorHasItem() then
	  ClearCursor() 
		dprint( " CURSOR HAS ITEM!" ,1,0,0)
		return -3
		
	elseif GetSendMailItem(mailslot) then
  	Name, Texture, Count, Quality = GetSendMailItem(mailslot)
		if type(itemName)=="string" and type(Name)=="string" and strfind(Name,itemName) and type(size)=="number" and size==Count then
			--Everything good !
		  return 0
		
		elseif type(itemName)~="string" or type(Name)~="string" or type(size)~="number" then
		  dprint(" Incorrect Type Given "..mailslot ,1,0,0)
			return -4
		
		elseif size~=Count then
		  dprint(" size and Count not correct", 1,0,0)
			return -4
			
		elseif not strfind(Name,itemName) then
		  dprint(" Name and itemName correct", 1,0,0)
			dprint(" "..Name.."  "..itemName ,1,0,0)
			return -4
		
		else		
			dprint(" Slot "..mailslot.." is full " ,1,0,0)
			return -4		
			
	  end
		
	end
	
  for bag = 0,4 do
    for slot = 1,GetContainerNumSlots(bag) do
		 
      local item = GetContainerItemLink(bag,slot)
			local texture, itemCount, locked, quality, readable = GetContainerItemInfo(bag, slot)
			
			if locked then
				somethingwaslocked = somethingwaslocked+1
				
      elseif item and strfind(item,itemName) and type(size)=="number" and type(itemCount)=="number" and itemCount==size then
			
        dprint(" ".. item )
				
				PickupContainerItem( bag,slot )
				ClickSendMailItemButton(mailslot)
				
				return 6
				
			elseif item and strfind(item,itemName) and type(size)=="number" and type(itemCount)=="number" and itemCount>size then
			  otherstacksaround = 1 + otherstacksaround
			
      end
			
    end
  end

	if otherstacksaround>0 then
	  dprint( " Unsplit stacks found: Splitting..." ,0,1,0)
		return MakeStack(itemName, size)
		
	elseif somethingwaslocked>0 then
		dprint( " Items Locked by Server!" ,1,0,0)
		return -5
		
	end
	
	--missing components?
	return 3
end












function ILoveProtector()
  local ms_var = MailStack("Titanium Bar",3,1)
	
  if ms_var==0 then
    if MailStack("Eternal Fire",1,2)==0 and MailStack("Eternal Earth",1,3)==0 and MailStack("Eternal Shadow",1,4)==0 then
		end
  elseif ms_var==3 then
	  if MailStack("Titanium Ore",6,1)==0 and MailStack("Eternal Fire",1,2)==0 and MailStack("Eternal Earth",1,3)==0 and MailStack("Eternal Shadow",1,4)==0 then
		end
	end
end





function ILoveProtectorOre()
  if MailStack("Titanium Ore",6,1)==0 and MailStack("Eternal Fire",1,2)==0 and MailStack("Eternal Earth",1,3)==0 and MailStack("Eternal Shadow",1,4)==0 then
	end
end

function ILoveProtectorBar()
  if MailStack("Titanium Bar",3,1)==0 and MailStack("Eternal Fire",1,2)==0 and MailStack("Eternal Earth",1,3)==0 and MailStack("Eternal Shadow",1,4)==0 then
	end
end



































function PlayerHealth()
  return (UnitHealth("player")/UnitHealthMax("player")*100)
end



function PlayerMana()
  if type(UnitPower("player",0))=="number" and UnitPower("player",0)>0 then
    return (UnitPower("player",0)/UnitPowerMax("player",0)*100)
  else
    return (UnitPower("player")/UnitPowerMax("player")*100)
  end
end



function PlayerRage()
  if type(UnitPower("player",1))=="number" then
	  return UnitPower("player",1)
	else
	  return (-1)
	end
end




function PetHealth()
  return (UnitHealth("pet")/UnitHealthMax("pet")*100)
end


function PetMana()
  return (UnitMana("pet")/UnitManaMax("pet")*100)
end



































--AddOns\_OOM\Tools.lua
function DEFAULT_CHAT_FRAMEScrollToBottom()
  if xtimer("ScrollToBottom",20) then
    DEFAULT_CHAT_FRAME:ScrollToBottom() 
    ChatRefresh = GetTime()
  else
    DEFAULT_CHAT_FRAME:ScrollDown() 
    ChatRefresh = GetTime()
  end
end

--[[
function DEFAULT_CHAT_FRAMEScrollToBottom()
  if not ChatRefreshRate then
    return
  elseif not ChatRefresh or GetTime()-ChatRefresh >ChatRefreshRate then
    DEFAULT_CHAT_FRAMEScrollToBottom() 
    ChatRefresh=GetTime()
  end
end
]]--




































function BloodRunes()
  runeCount = 0
  for id=1,6 do
    runeType = GetRuneType(id)
    start, duration, runeReady = GetRuneCooldown(id)
    if runeReady and ( runeType==1 or runeType==4 ) then
      runeCount = runeCount+1
    end
  end
  return runeCount
end


function FrostRunes()
  runeCount = 0
  for id=1,6 do
    runeType = GetRuneType(id)
    start, duration, runeReady = GetRuneCooldown(id)
    if runeReady and ( runeType==3 or runeType==4 ) then
      runeCount = runeCount+1
    end
  end
  return runeCount
end


function UnholyRunes()
  runeCount = 0
  for id=1,6 do
    runeType = GetRuneType(id)
    start, duration, runeReady = GetRuneCooldown(id)
    if runeReady and ( runeType==2 or runeType==4 ) then
      runeCount = runeCount+1
    end
  end
  return runeCount
end





































function BiSS2Text(spellSchool)
  if type(spellSchool)~="number" then
    return "Error"
  elseif spellSchool<=0 then
    return "Negative"
  end
  
  textout = ""
  
  if mod(spellSchool,2)==1 then
    textout = "Physical" .. textout
  end
  spellSchool = floor(spellSchool/2)
  
  if mod(spellSchool,2)==1 then
    textout = "Holy" .. textout
  end
  spellSchool = floor(spellSchool/2)
  
  if mod(spellSchool,2)==1 then
    textout = "Fire" .. textout
  end
  spellSchool = floor(spellSchool/2)
  
  if mod(spellSchool,2)==1 then
    textout = "Nature" .. textout
  end
  spellSchool = floor(spellSchool/2)
  
  if mod(spellSchool,2)==1 then
    textout = "Frost" .. textout
  end
  spellSchool = floor(spellSchool/2)
  
  if mod(spellSchool,2)==1 then
    textout = "Shadow" .. textout
  end
  spellSchool = floor(spellSchool/2)
  
  if mod(spellSchool,2)==1 then
    textout = "Arcane" .. textout
  end
  spellSchool = floor(spellSchool/2)
  
  return textout
end






































--given a value, determines 0-1 percent between bottom and top
function LinearC(value,bottom,top)
  if type(value)~="number" or type(bottom)~="number" or type(top)~="number" then
    return -1
  elseif bottom==top then
    return -1
  end
  
  --tempM = ( 1 / (top - bottom) )
  --tempB = ( 1 - top/(top-bottom) )
  --tempV = (value-bottom)*bottom/top
  --tempV = ( 1 / (top - bottom) )*value+( 1 - top/(top-bottom) )
  
  --return ( 1 / (top - bottom) )*value + ( 1 - top/(top-bottom) )
  return max(min(1, ( 1 / (top - bottom) )*value + ( 1 - top/(top-bottom) ) ) ,0)
end








































function CancelPlayerBuff(buffIndex)
  return CancelUnitBuff("player", buffIndex)
end



















































function CombatLogRange2000()
  ConsoleExec("SET CombatLogRangeParty \"2000\"")
	ConsoleExec("SET CombatLogRangePartyPet \"2000\"")
	
	ConsoleExec("SET CombatLogRangeFriendlyPlayers \"2000\"")
	ConsoleExec("SET CombatLogRangeFriendlyPlayersPets \"2000\"")

	ConsoleExec("SET CombatLogRangeHostilePlayers \"2000\"")
	ConsoleExec("SET CombatLogRangeHostilePlayersPets \"2000\"")

	ConsoleExec("SET CombatLogRangeCreature \"2000\"")
	
	t_CombatLogRange2000 = GetTime()
end






















--	DEFAULT_CHAT_FRAME:AddMessage( text )




function SpamTestTrack()
  cTrack = GetCurrentTrack()
  if GetNumTrackingTypes() == cTrack then
	  SetTracking(1)
	else
	  SetTracking(cTrack+1)
	end 
end



function GetCurrentTrack()
  local count = GetNumTrackingTypes();
  for i=1,count do 
  	local name, texture, active, category = GetTrackingInfo(i);
  	if active then
		  return i, name, texture, active, category
		end
  end
end

























function ThreeTargetEPGP(uName)
  uName = uName or UnitName("target")
	dprint(uName)
	
  for index=1,GetNumGuildMembers(true) do
	  name, rank, rankIndex, level, class, zone, note, officernote, online, status, classFileName = GetGuildRosterInfo(index)
		
		if uName==name then
		
		  cat(name, rank, rankIndex, level, class, zone, note, officernote, online, status, classFileName)
			if strfind(officernote,",") and strsub(officernote,1,strfind(officernote,",")-1) and tonumber( strsub(officernote,1,strfind(officernote,",")-1) ) and type( tonumber( strsub(officernote,1,strfind(officernote,",")-1) ) )=="number" then
			
				dprint(" Officer Note Prior to any mods: " .. officernote)
				
			  epValue = tonumber( strsub(officernote,1,strfind(officernote,",")-1) )
				newGuildNote = gsub(officernote,epValue,epValue+3,1)

--				GuildRosterSetOfficerNote(index, newGuildNote )
				SendChatMessage("ZOMGS, +3 EP for " .. name .. " for fishy!"  ,"GUILD")
				
				dprint(" Officer Note should be after mod: " .. newGuildNote)

				
			end
			
	  end
		
	end
end








































function ListGreens()
  for bagID=0,4 do
	  for slotID=1,GetContainerNumSlots(bagID) do
			itemLink = GetContainerItemLink(bagID, slotID)
		  if itemLink then
			
				local _, _, Color, Ltype, Id, Enchant, Gem1, Gem2, Gem3, Gem4, Suffix, Unique, LinkLvl, Name = string.find(itemLink, "|?c?f?f?(%x*)|?H?([^:]*):?(%d+):?(%d*):?(%d*):?(%d*):?(%d*):?(%d*):?(%-?%d*):?(%-?%d*):?(%d*)|?h?%[?([^%[%]]*)%]?|?h?|?r?")
				local texture, itemCount, locked, quality, readable = GetContainerItemInfo(bagID, slotID)
				local equippable = IsEquippableItem(itemLink)
				
				if equippable and type(Color)=="string" and Color=="1eff00" then
					--dprint( delimitcat("  " , gsub( itemLink , "\124", "\124\124") , itemLink  , bagID , slotID ) )
					dprint( " " .. itemLink .. "  bag="..bagID .. "  slot="..slotID )
				end
				
			end
		end
	end
end












function IsDisenchanting()
  for actSlot=0,132 do
	  local lActionTexture = GetActionTexture(actSlot)
	  if lActionTexture and IsCurrentAction(actSlot) and lActionTexture=="Interface\\Icons\\INV_Enchant_Disenchant" then
			--[[
			local lActionText = GetActionText(actSlot)
			lMessage = "Slot " .. actSlot .. ": [" .. lActionTexture .. "]";
			if lActionText then
				lMessage = lMessage .. " \"" .. lActionText .. "\"";
			end
			dprint( lMessage )
			]]--
			return actSlot
		end
	end
	return false
end



















function ListAllMailboxEP()
  for index=1,GetInboxNumItems() do
	  ListMailboxEP(index,true)
	end
end





-- mail box epgp
function ListMailboxEP(index,finalAndMissing)
  ep_sum = 0
  index = index or 1
	packageIcon, stationeryIcon, sender, subject, money, CODAmount, daysLeft, hasItem, wasRead, wasReturned, textCreated, canReply, isGM = GetInboxHeaderInfo(index)
	
	if type(sender)~="string" then
	   dprint("Mailbox index " .. index .. " has no sender")
		 return
		 
	elseif strfind(sender,"Auction House") then
		if not finalAndMissing then
			dprint("Mailbox index " .. index .. " is from " .. sender)
		end
		return
		 
	elseif CODAmount~=0 then
	  dprint("Mailbox index " .. index .. " from " .. sender .. " is asking for COD")
		return
		
	elseif not subject then
	  dprint("Mailbox index " .. index .. " from " .. sender .. " has no subject")
		
	end
	
	
	
	
	for itemIndex=1,13 do
		name, itemTexture, count, quality, canUse = GetInboxItem(index, itemIndex)
		
		if name then
			
			if type(mailbox_epgp_values[name])=="number" and count then
			
			  if not finalAndMissing then 
					dprint(" ".. name .. ColorText(0,1,0) .. " x" ..count .. ColorText() .." is worth " .. ColorText(1,0,0) .. mailbox_epgp_values[name]*count .. ColorText() .." ep")
				end
				ep_sum = ep_sum + mailbox_epgp_values[name]*count
			
			else
				dprint(" ".. name .. ColorText(0,1,0) .. " x" ..count .. ColorText() .." has no assigned value for ep")
			
			end
			
		end

	end

	if ep_sum>0 then
	  dprint("Mailbox index " .. index .. " from " .. CT(.5,.5,.5) .. sender .. CT() .. " with subject " .. CT(.8,.8,0) .. subject .. CT() .. " contained " .. CT(1,0,0) .. ep_sum .. CT() .. " worth of ep")
		return ep_sum
	end
	
end






mailbox_epgp_values = {
	["Cardinal Ruby"] = 20 ,
	["Majestic Zircon"] = 20 ,
	["King's Amber"] = 20 ,
	["Ametrine"] = 15 ,
	["Dreadstone"] = 15 ,
	["Eye of Zul"] = 15 ,
	
	["Skyflare Diamond"] = 8 ,
	["Earthsiege Diamond"] = 5 ,
	
	["Dream Shard"] = 8 ,
	["Abyss Crystal"] = 15 ,
	["Greater Cosmic Essence"] = 15/20 ,
	["Infinite Dust"] = 10/20 ,
	["Armor Vellum III"] = 5/20 ,
	["Weapon Vellum III"] = 10/20 ,	
	
	["Brilliant Spellthread"] = 15 ,
	["Sapphire Spellthread"] = 15 ,
	["Icescale Leg Armor"] = 17 ,
	["Earthen Leg Armor"] = 17 ,
	["Frosthide Leg Armor"] = 20 ,
	
	["Flask of Endless Rage"] = 5 ,
	["Flask of Stoneblood"] = 4 ,
	["Flask of the Frost Wyrm"] = 5 ,
	["Flask of Pure Mojo"] = 3 ,
	["Frost Lotus"] = 5 ,
	
	["Fish Feast"] = 3 ,
	["Runescroll of Fortitude"] = 18/20 ,
	
}































--/z x1,y1 = GetPlayerMapPosition("party1") printcat(x1,y1)

function mapDistance(unitA,unitB)
  local x0,y0 = GetPlayerMapPosition(unitA)
  local x1,y1 = GetPlayerMapPosition(unitB)
	
	if ( x0==0 and y0==0 ) or ( x1==0 and y1==0 ) then
		--error, but update for next attempt
		WorldMapFrame:Show()
		WorldMapFrame:Hide() 
		return -1
	end
	
	presquare = ( x1-x0 )^2 + ( y1-y0 )^2
	
	return 100*sqrt(presquare)
end





















function alan()
--	SetBinding("ALT-1","MULTIACTIONBAR1BUTTON1")
--	SetBinding("ALT-2","MULTIACTIONBAR1BUTTON2")
--	SetBinding("ALT-3","MULTIACTIONBAR1BUTTON3")
--	SetBinding("ALT-4","MULTIACTIONBAR1BUTTON4")
--	SetBinding("ALT-5","MULTIACTIONBAR1BUTTON5")
--	SetBinding("ALT-6","MULTIACTIONBAR1BUTTON6")
--	SetBinding("ALT-7","MULTIACTIONBAR1BUTTON7")
--	SetBinding("ALT-8","MULTIACTIONBAR1BUTTON8")
--	SetBinding("ALT-9","MULTIACTIONBAR1BUTTON9")
--	SetBinding("ALT-0","MULTIACTIONBAR1BUTTON10")
--	SetBinding("ALT--","MULTIACTIONBAR1BUTTON11")
--	SetBinding("ALT-=","MULTIACTIONBAR1BUTTON12")
	
	SetBinding("BUTTON4","TOGGLEAUTORUN")
	
	ConsoleExec("SET autoLootDefault 0")
	
	dprint(" alan()")
end

















function AutoGossip(npcName)
	if type(npcName)~="string" then
		npcName = "Dark Iron Brewer"
	end
	if UnitName("npc")==npcName and GetNumGossipOptions()==1 and select(2,GetGossipOptions())=="gossip" and GetGossipText() then
		SelectGossipOption(1)
		return 1
	else
		return false
	end
end







































function round(fnumber,rnum)
  if not fnumber then return fnumber end
  if not rnum then rnum=0 end
  divnum=10^rnum
  returnval=fnumber/divnum
  returnval=floor(returnval)
  returnval=returnval*divnum
  returnval=tonumber(returnval)
  return (returnval)
end
