-- UIErrorsFrame:AddMessage(msg ,0,1,.5,1,2)
-- string.find( string , search )
-- DEFAULT_CHAT_FRAME:AddMessage( text )



function OOM_SpellReflect(arg1)

  UnitCheckForSpellReflect("player")
  UnitCheckForSpellReflect("target")
  UnitCheckForSpellReflect("focus")
  UnitCheckForSpellReflect("pet")
  UnitCheckForSpellReflect("focustarget")

for i=1,GetNumRaidMembers() do
  UnitCheckForSpellReflect("raid"..i)
  UnitCheckForSpellReflect("raidpet"..i)
end
for i=1,GetNumPartyMembers() do
  UnitCheckForSpellReflect("party"..i)
  UnitCheckForSpellReflect("partypet"..i)
end


end







function UnitCheckForSpellReflect(unit)

  if UnitIsVisible(unit) and UnitIsVisible(unit.."target") and UnitIsUnit(unit.."targettarget","player") and UnitCanAttack(unit.."target","player") then
    if UnitCastingInfo(unit.."target") then
      spell, rank, displayName, icon, startTime, endTime = UnitCastingInfo(unit.."target")
    elseif UnitChannelInfo(unit.."target") then
      spell, rank, displayName, icon, startTime, endTime = UnitCastingInfo(unit.."target")
    end
    if UnitCastingInfo(unit.."target") or UnitChannelInfo(unit.."target") then
      if spell and rank and xtimer(spell..rank,12) then DEFAULT_CHAT_FRAME:AddMessage("   "..spell.." INCOMING!") end
    end
    
  end


end