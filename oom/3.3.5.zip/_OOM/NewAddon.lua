-- UIErrorsFrame:AddMessage("msg",0,1,.5,1,2)
-- string.find( sString, mString )
-- DEFAULT_CHAT_FRAME:AddMessage("Woot!")






function NewAddon_OnLoad()
  --DEFAULT_CHAT_FRAME:AddMessage("New Addon Loaded.")
end







the_combat_count=0
neo="nil"


function NewAddon_OnUpdate()
  a_combat_count=WhoCombat()
  if the_combat_count~=a_combat_count then
    if a_combat_count>0 and the_combat_count==0 and not BattleGround() and GetNumRaidMembers()==0 then
      echo("combat " .. a_combat_count .. "   " .. neo )
    end
    the_combat_count=a_combat_count
  end
end





function WhoCombat()
  local combat_count=0
  for i=1,5 do
    if UnitAffectingCombat("party"..i) then
      combat_count=combat_count+1
      neo=UnitName("party"..i)
    end
    if UnitAffectingCombat("partypet"..i) then
      combat_count=combat_count+1
      neo=UnitName("partypet"..i)
    end
  end
  return combat_count
end






























function AVscore()
  RequestBattlefieldScoreData()
  for i=1, GetNumBattlefieldScores() do
    local playerName = GetBattlefieldScore(i);
    local flagCaptures = GetBattlefieldStatData(i, 1);
    local flagReturns = GetBattlefieldStatData(i, 2);
    local f3 = GetBattlefieldStatData(i, 3);
    local f4 = GetBattlefieldStatData(i, 4);
    local f5 = GetBattlefieldStatData(i, 5);
    local f6 = GetBattlefieldStatData(i, 6);
    local f7 = GetBattlefieldStatData(i, 7);
    local f8 = GetBattlefieldStatData(i, 8);
    local f9 = GetBattlefieldStatData(i, 9);
    echo( playerName.."  "..flagCaptures.."  "..flagReturns.."  "..f4.."  "..f5.."  "..f6.."  "..f7.."  "..f8 )
  end 
end





function AVecho(i)
  name, killingBlows, honorKills, deaths, honorGained, faction, rank, race, class, CLASS, damageDone, healingDone = GetBattlefieldScore(i)
  echo(name.."  "..killingBlows.."  "..honorKills.."  "..deaths.." "..honorGained.." "..faction.." "..rank.." "..race.." "..class)
  echo(CLASS.."  "..damageDone.."   "..healingDone)

end






function AVheal()
  RequestBattlefieldScoreData()
  for i=1, GetNumBattlefieldScores() do
    name, killingBlows, honorKills, deaths, honorGained, faction, rank, race, class, CLASS, damageDone, healingDone = GetBattlefieldScore(i)
    if name==UnitName("player") then
      playerhealvalue=healingDone
      break
    end
  end

  horde_healing=0
  alliance_healing=0

  AVtable = {}
--DEFAULT_CHAT_FRAME:AddMessage("--Healing Done--")
  for i=1, GetNumBattlefieldScores() do

    name, killingBlows, honorKills, deaths, honorGained, faction, rank, race, class, CLASS, damageDone, healingDone = GetBattlefieldScore(i)

    AVtable[i]= {}
    AVtable[i]["name"]=name
    AVtable[i]["damageDone"]=damageDone
    AVtable[i]["healingDone"]=healingDone 
    AVtable[i]["faction"]=faction 

    if healingDone>0 and faction==0 then
      horde_healing = horde_healing+healingDone
    elseif healingDone>0 and faction==1 then
      alliance_healing = alliance_healing+healingDone
    end
--[[
    if healingDone>=playerhealvalue*0.3 and faction==0 then
      DEFAULT_CHAT_FRAME:AddMessage(name.."  "..healingDone  ,1,0,0)
    elseif healingDone>=playerhealvalue*0.3 and faction==1 then
      DEFAULT_CHAT_FRAME:AddMessage(name.."  "..healingDone  ,.2,.4,1)
    end
]]--
  end

  AVtop = {}
  for i=1,80 do
    AVtop[i] = {}
    AVtop[i]["damageDone"]= 0
    AVtop[i]["healingDone"]= 0
  end

  for j=1,80 do
    delete_i=-1
    for i=1,80 do
      if AVtable[i] and AVtable[i]["name"] and AVtable[i]["healingDone"] and AVtop[j] and AVtop[j]["healingDone"] and AVtable[i]["healingDone"]>AVtop[j]["healingDone"] then
        AVtop[j]["name"]=AVtable[i]["name"]
        AVtop[j]["healingDone"]=AVtable[i]["healingDone"]
		AVtop[j]["faction"]=AVtable[i]["faction"]
        delete_i=i
      end
    end
    if delete_i>0 then AVtable[delete_i]["healingDone"]=-1 end
  end



DEFAULT_CHAT_FRAME:AddMessage(" Total Horde Healing: "..horde_healing ,1,0,0)
DEFAULT_CHAT_FRAME:AddMessage(" Total Alliance Healing: "..alliance_healing ,.2,.4,1)


DEFAULT_CHAT_FRAME:AddMessage("--Top Healers--")

  for i=1,12 do
    if AVtop[i]["name"] and AVtop[i]["faction"]==0 and AVtop[i]["healingDone"] and AVtop[i]["healingDone"]>0 then
      DEFAULT_CHAT_FRAME:AddMessage(AVtop[i]["name"].."   "..AVtop[i]["healingDone"] ,1,0,0)
    elseif AVtop[i]["name"] and AVtop[i]["faction"]==1 and AVtop[i]["healingDone"] and AVtop[i]["healingDone"]>0 then
      DEFAULT_CHAT_FRAME:AddMessage(AVtop[i]["name"].."   "..AVtop[i]["healingDone"] ,.2,.4,1)
    end
  end

end