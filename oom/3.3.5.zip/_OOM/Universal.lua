-- DEFAULT_CHAT_FRAME:AddMessage(text,r,g,b)





dprint = function(...)
  DEFAULT_CHAT_FRAME:AddMessage(...)
end



uprint = function(...)
  UIErrorsFrame:AddMessage(...)
end








function FindUnitByName(nUnit)
  if not nUnit then
    return nUnit
  elseif UnitName("target")==nUnit then
    return "target"
  elseif UnitName("focus")==nUnit then
    return "focus"  
  elseif UnitName("targettarget")==nUnit then
    return "targettarget" 
  elseif UnitName("pettarget")==nUnit then
    return "pettarget" 
  elseif UnitName("focustarget")==nUnit then
    return "focustarget"  
  elseif UnitName("player")==nUnit then
    return "player" 
  elseif UnitName("pet")==nUnit then
    return "pet"
  elseif UnitName("focustargettarget")==nUnit then
    return "focustargettarget" 
  end

  for i=1,5 do
    if UnitName("party"..i)==nUnit then
      return "party"..i
    elseif UnitName("party"..i.."target")==nUnit then
      return "party"..i.."target"      
    end
  end

  for i=1,40 do
    if UnitName("raid"..i)==nUnit then
      return "raid"..i
    elseif UnitName("raid"..i.."target")==nUnit then
      return "raid"..i.."target"
    end
  end

  for i=1,5 do
    if UnitName("partypet"..i)==nUnit then
      return "partypet"..i
    elseif UnitName("partypet"..i.."target")==nUnit then
      return "partypet"..i.."target"
    end
  end

  for i=1,40 do
    if UnitName("raidpet"..i)==nUnit then
      return "raid"..i.."pet"
    elseif UnitName("raidpet"..i.."target")==nUnit then
      return "raidpet"..i.."target"
    end
  end

  return nil
end
















--[[

function AutoPet()
  if UnitCreatureFamily("pet")=="Succubus" and FindUnitDebuff("pettarget","Shadow_MindSteal") then
    return
  end
  if (not UnitExists("pettarget")) and (not UnitIsUnit("pettarget","target")) and UnitExists("pet") and UnitExists("target") then
    PetAttack()
  elseif UnitIsUnit("targettarget","player") and (not UnitIsUnit("pettarget","target")) and UnitExists("pet") and UnitExists("target") then
    PetAttack()
  end
end

]]--






function FindUnitDebuff(sUnit,sDebuffName)
  local debuffCount=0;
  for i=0,45 do
    local debuffTexture, debuffApplications = UnitDebuff(sUnit,i)
    if UnitDebuff(sUnit,i) and ( string.find(debuffTexture,sDebuffName) ) then
      debuffCount=debuffCount+debuffApplications+1
    end
  end
  if debuffCount==0 then return nil end
  return debuffCount
end









function UnitBuffCount(sUnit,sBuffName)
  local buffCount = 0;
  for i=0,30 do
    if UnitBuff(sUnit,i) and string.find(UnitBuff(sUnit,i),sBuffName) then
      buffCount=buffCount+1
    end
  end
  return buffCount
end





function UnitBuffTexture(sUnit,sBuffName)
  local buffCount = 0;
  for i=0,30 do
    name, rank, iconTexture, count =  UnitBuff(sUnit, i)
    if iconTexture and string.find(iconTexture,sBuffName) then
      buffCount=buffCount+1
    end
  end
  return buffCount
end







function TargetDebuff(sDebuffName)
  local debuffCount=0;
  for i=0,45 do
    local debuffTexture, debuffApplications = UnitDebuff("target",i)
    if UnitDebuff("target",i) and ( string.find(debuffTexture,sDebuffName) ) then
      debuffCount=debuffCount+debuffApplications+1
    end
  end
  if debuffCount==0 then return nil end
  return debuffCount
end




function TargetBuff(sBuffName)
  local buffCount = 0;
  for i=0,30 do
    if UnitBuff("target",i) and (string.find(UnitBuff("target",i),sBuffName)) then
      buffCount=buffCount+1
    end
  end
  if buffCount==0 then return nil end
  return buffCount
end





--returns player buff duration, zero if does not exists
function PlayerBuff(sBuffName)
  local durationCount=0
  for i=0,40 do
    if GetPlayerBuffTexture(i) and ( string.find(GetPlayerBuffTexture(i),sBuffName) or string.find(GetPlayerBuffName(i),sBuffName) ) then
	if GetPlayerBuffTimeLeft(i)==0 then durationCount=1 end
      durationCount=durationCount+GetPlayerBuffTimeLeft(i)
    end
  end
  return durationCount
end




--wrath of the lich king fix
function GetPlayerBuffTimeLeft(buffIndex)
  name, rank, icon, count, debuffType, duration, expirationTime, _, isStealable = UnitBuff("player", buffIndex)
  if expirationTime~=0 then
    return ( expirationTime - GetTime() ) 
  else
    return 1
  end
end








function AppCount(sBuffName)
  local durationCount=0
  for i=0,40 do
    if GetPlayerBuffTexture(i) and GetPlayerBuffApplications(i) and (string.find(GetPlayerBuffTexture(i),sBuffName)) then
	if GetPlayerBuffApplications(i)>0 then
        durationCount=durationCount+GetPlayerBuffApplications(i)
      else
        durationCount=durationCount+1
      end
    end
  end
  return durationCount
end







function PlayerDebuff(sDebuffName)
  local playerDebuff=0
  for i=0,20 do
    local debuffTexture, debuffApplications = UnitDebuff("target",i)
    if UnitDebuff("target",i) and (string.find(debuffTexture,sDebuffName)) then
      playerDebuff=playerDebuff+debuffApplications+1
    end
  end
  if playerDebuff==0 then return nil end
  return playerDebuff
end





function Track(sTrackName)
  if GetTrackingTexture() and sTrackName and string.find(GetTrackingTexture(),sTrackName) then
    return 1
  elseif not sTrackName then
      
    local count = GetNumTrackingTypes();
    for i=1,count do 
  	  local name, texture, active, category = GetTrackingInfo(i);
    	if active then
	  	  return name, texture, active, category, i
	  	end
    end

  else
    return nil
  end
end




function RemoveBuff(sBuffName)
  for i=0,40 do
    if GetPlayerBuffTexture(i) and (string.find(GetPlayerBuffTexture(i),sBuffName)) then
      CancelPlayerBuff(i)
      return true
    end
  end
  return nil
end






function PetBuff(sBuffName)
  local buffCount = 0;
  for i=0,30 do
    if UnitBuff("pet",i) and (string.find(UnitBuff("pet",i),sBuffName)) then
      buffCount=buffCount+1
    end
  end
  if buffCount==0 then return nil end
  return buffCount
end








function CountCondition(sUnit,sType)
  local c_condition=0
  for i_c=1,20 do
    if not UnitDebuff(sUnit, i_c) then break end
    debuffTexture, debuffApplications, debuffDispelType = UnitDebuff(sUnit, i_c)
    if debuffDispelType==sType and debuffApplications==0 then
      c_condition=c_condition+1
    elseif debuffDispelType==sType and debuffApplications>0 then
      c_condition=c_condition+debuffApplications
    end
  end
  return c_condition
end























-- DEFAULT_CHAT_FRAME:AddMessage(text,r,g,b)



function test()
  if UnitBuff("player",1) then DEFAULT_CHAT_FRAME:AddMessage("---Player Buffs---", 0,1,0) end
  for i=0,20 do
    if GetPlayerBuffTexture(i) then
      DEFAULT_CHAT_FRAME:AddMessage(GetPlayerBuffTexture(i) .. "     [ " .. GetPlayerBuffTimeLeft(i) .. " ]", 0,1,0)
    end
  end

  if UnitDebuff("target",1) then DEFAULT_CHAT_FRAME:AddMessage("---Target Debuffs---", 0.9,0,0) end
  for i=0,20 do
    if UnitDebuff("target",i) then
      DEFAULT_CHAT_FRAME:AddMessage(UnitDebuff("target",i), 0.9,0,0)
      end
    end

  if GetTrackingTexture() then
    DEFAULT_CHAT_FRAME:AddMessage("---Tracking Texture---", 0.7,0,0.7)
    DEFAULT_CHAT_FRAME:AddMessage(GetTrackingTexture(), 0.7,0,0.7)
  end

  if UnitBuff("target",1) and not UnitIsUnit("player","target") then
    DEFAULT_CHAT_FRAME:AddMessage("---Target Buffs---", 0,0.9,0.8)
    for i=0,40 do
      if UnitBuff("target",i) then
        DEFAULT_CHAT_FRAME:AddMessage( UnitBuff("target",i) , 0,0.9,0.8)
      end
    end
  end
end








function echoDistance()
  if not UnitExists("target") then return nil end
  local distanceString=""
  if CheckInteractDistance("target",5) then distanceString=distanceString .. "5 " end
  if CheckInteractDistance("target",4) then distanceString=distanceString .. "4 " end
  if CheckInteractDistance("target",3) then distanceString=distanceString .. "3 " end
  if CheckInteractDistance("target",2) then distanceString=distanceString .. "2 " end
  if CheckInteractDistance("target",1) then distanceString=distanceString .. "1 " end
  if CheckInteractDistance("target",0) then distanceString=distanceString .. "0 " end
  DEFAULT_CHAT_FRAME:AddMessage("Target Distance:  " .. distanceString)
  return true
end






--[[

function Attack(aValue)
  if aValue and aValue>0 then
    bValue=aValue
  else
    bValue=AttackActionValue()
  end
  if IsAttackAction(bValue) and IsCurrentAction(bValue)==nil then
    AttackTarget()
    return true
  end
end

]]--






--[[

function AttackOff()
  bValue=AttackActionValue()
  if IsAttackAction(bValue) and IsCurrentAction(bValue) then
    AttackTarget()
    return
  end
end

]]--








--[[

function AttackActionValue()
  for i=0,300 do
    if IsAttackAction(i) then return i end
    end
  return 0
end

]]--




--[[

function AnyAction()
  for i=0,120 do
    if IsCurrentAction(i) then return i end
  end
  for i=0,120 do
    if IsAutoRepeatAction(i) then return i end
  end
  return
end



function PlayerRanging()
  for i=0,120 do
    if IsAutoRepeatAction(i) and not IsAttackAction(i) then return i end
  end
  return
end

]]--













function SpellID(spellname)
  if type(spellname)~="string" then
    return -1
  end
  local ID=-1
  local i=1
  while GetSpellName(i,"Spell") do
    if GetSpellName(i,"Spell") and string.find(GetSpellName(i,"Spell"),spellname) then
      ID=i
    end
    i=i+1
  end
  if ID>0 then return ID end
  -- ELSE
  s_InvalidSpellName=spellname
  return -1
end



function Cooldown(spellname)
  SPELL_ID=SpellID(spellname)
  if SPELL_ID==-1 then return -1 end
  local start, duration = GetSpellCooldown(SPELL_ID,"Spell")
  if duration>0 then return (duration-(GetTime()-start)) end
  return 0
end









function SpellInRange(spellname)
  SPELL_ID=SpellID(spellname)
  if SPELL_ID==-1 then return end

  for i=0,120 do
    if GetActionTexture(i) and (i) and ActionHasRange(i) and IsActionInRange(i) and GetSpellTexture(SPELL_ID,"spell") and GetActionTexture(i)==GetSpellTexture(SPELL_ID,"spell") and IsActionInRange(i)==1 then
      return i
    elseif not ActionHasRange(i) and GetActionTexture(i) and (i) and GetSpellTexture(SPELL_ID,"spell") and GetActionTexture(i)==GetSpellTexture(SPELL_ID,"spell") then
      return -i
    end
  end
  return
end























function UseContainerItemByName(SearchString)
  for bag=0,4 do
    for slot=1,GetContainerNumSlots(bag) do
      if (GetContainerItemLink(bag,slot)) then
        if (string.find(GetContainerItemLink(bag,slot), SearchString)) then
          UseContainerItem(bag,slot)
          return true
        end
      end
    end
  end
  return nil
end






function FREEBAGSLOTS()
  local slotTotal=0
    for bag=0,4 do
      slotTotal=slotTotal+GetContainerNumSlots(bag)
      for slot=1,GetContainerNumSlots(bag) do
        if ( GetContainerItemLink(bag,slot) ) then
            slotTotal=slotTotal-1
        end
      end
    end
  return slotTotal
end







function Flag()
  DEFAULT_CHAT_FRAME:AddMessage("---Alliance---",0,0,255)
  text, icon, isFlashing, dynamicIcon, tooltip, dynamicTooltip = GetWorldStateUIInfo(1)
  DEFAULT_CHAT_FRAME:AddMessage(text,0,0,255)
  DEFAULT_CHAT_FRAME:AddMessage(icon,0,0,255)
  DEFAULT_CHAT_FRAME:AddMessage(isFlashing,0,0,255)
  DEFAULT_CHAT_FRAME:AddMessage(dynamicIcon,0,0,255)
  DEFAULT_CHAT_FRAME:AddMessage(tooltip,0,0,255)
  DEFAULT_CHAT_FRAME:AddMessage(dynamicTooltip,0,0,255)

  DEFAULT_CHAT_FRAME:AddMessage("---Horde---",255,0,0)
  text, icon, isFlashing, dynamicIcon, tooltip, dynamicTooltip = GetWorldStateUIInfo(2)
  DEFAULT_CHAT_FRAME:AddMessage(text,255,0,0)
  DEFAULT_CHAT_FRAME:AddMessage(icon,255,0,0)
  DEFAULT_CHAT_FRAME:AddMessage(isFlashing,255,0,0)
  DEFAULT_CHAT_FRAME:AddMessage(dynamicIcon,255,0,0)
  DEFAULT_CHAT_FRAME:AddMessage(tooltip,255,0,0)
  DEFAULT_CHAT_FRAME:AddMessage(dynamicTooltip,255,0,0)
end



























--[[


function FeedPet(SearchString)
  if not FeedPetTimeDelay then FeedPetTimeDelay=0 end
  if GetTime()-FeedPetTimeDelay <2 then return nil end
  for bag=0,4 do
    for slot=1,GetContainerNumSlots(bag) do
      if (GetContainerItemLink(bag,slot)) then
        if (string.find(GetContainerItemLink(bag,slot), SearchString)) then
          FeedPetTimeDelay=GetTime()
          PickupContainerItem(bag,slot)
          DropItemOnUnit("pet")
          return 1
        end
      end
    end
  end
  return 0
end

]]--























function NearbyPartyCount(d)
  local n=0
  for i=1,4 do
    if CheckInteractDistance("party" .. i,d) then n=n+1 end
  end
  for i=1,4 do
    if CheckInteractDistance("partypet" .. i,d) then n=n+1 end
  end
  for i=1,40 do
    if CheckInteractDistance("raid" .. i,d) then n=n+1 end
  end
  return n
end




function GetPartyVisible()
  local n=0
  for i=1,4 do
    if UnitIsVisible("party" .. i) then n=n+1 end
  end
  for i=1,4 do
    if UnitIsVisible("partypet" .. i) then n=n+1 end
  end
  for i=1,40 do
    if UnitIsVisible("raid" .. i) then n=n+1 end
  end
  return n
end



function NearbyGroupCount(d)
  local n=0
  for i=1,4 do
    if CheckInteractDistance("party" .. i,d) then n=n+1 end
  end
  for i=1,4 do
    if CheckInteractDistance("partypet" .. i,d) then n=n+1 end
  end
  return n
end
























--[[
function Mongoose()
  for i=0,300 do
    if GetActionTexture(i) and (string.find(GetActionTexture(i),"Hunter_SwiftStrike")) and IsUsableAction(i) and Cooldown("Mongoose Bite")==0 then
      CastSpellByName("Mongoose Bite")
      return true
    end
  end
  return nil
end
]]--





function SpellUsable(nspell)
  SPELL_ID=SpellID(nspell)
  if SPELL_ID==-1 then return end

  for i=0,120 do
    if GetActionTexture(i) and GetActionTexture(i)==GetSpellTexture(SPELL_ID,"spell") and IsUsableAction(i) and Cooldown(nspell)==0 then
      return i
    end
  end
  return
end

















function echo(msg)
  DEFAULT_CHAT_FRAME:AddMessage(msg ,1/16,12/16,7/16)
end


--[[
function echo(text,r0,g0,b0)
  if not text then DEFAULT_CHAT_FRAME:AddMessage("NIL",0,1,0) end
  if r0 and tonumber(r0) then r=r0/255 else r=1 end
  if g0 and tonumber(g0) then g=g0/255 else g=1 end
  if b0 and tonumber(b0) then b=b0/255 else b=1 end
  DEFAULT_CHAT_FRAME:AddMessage(text,r,g,b)
  return text
end
]]--


















































function BattleGround()
  local e_zone = GetRealZoneText() .. GetZoneText() .. GetMinimapZoneText() .. GetSubZoneText()
  if string.find(e_zone,"Warsong Gulch") then
    return 10
  elseif string.find(e_zone,"Arathi Basin") then
    return 20
  elseif string.find(e_zone,"Alterac Valley") then
    return 51
	elseif string.find(e_zone,"Eye of the Storm") then
    return 61
  elseif string.find(e_zone,"Strand of the Ancients") then
    return 71
  elseif string.find(e_zone,"Wintergrasp") then
    return 80
  else
    return
  end
end








function InRaid(mname)
  for i=1,40 do
    if UnitName("raid" .. i)==mname then
      return i
    end
  end
  return nil
end



-- raid or party
function InGroup(mname)
  for i=1,5 do
    if UnitName("party"..i)==mname then
      return "party"..i
    end
  end
  for i=1,40 do
    if UnitName("raid" .. i)==mname then
      return "raid"..i
    end
  end
  return nil
end
















function CalcXp(arg1,arg2)
      t = UnitLevel("target");
      p = UnitLevel("player");
	if ( arg1 ) then t=arg1; end
	if ( arg2 ) then p=arg2; end
      if ( t == -1 ) then
           return 0;
      end
      if ( t == p ) then
           xp = ((p * 5) + 45);
      end
      if ( t > p ) then
           xp = ((p * 5) + 45) * (1 + 0.05 * (t - p));
      end
      if ( t < p ) then
           -- need gray level "g"
           if (p < 6) then g = 0; end
           if (p > 5 and p < 40) then
                g = p - 5 - floor(p/10);
           end
           if (p > 39) then
                g = p - 1 - floor(p/5);
           end
           if (t > g) then
                -- need zero difference "z"
                if (p < 8) then z = 5; end
                if (p > 7 and p < 10) then z = 6; end
                if (p > 9 and p < 12 ) then z = 7; end
                if (p > 11 and p < 16 ) then z = 8; end
                if (p > 15 and p < 20 ) then z = 9; end
                if (p > 19 and p < 40 ) then z = 9 + floor(p/10); end
                if (p > 39) then z = 5 + floor(p/5); end
                xp = (p * 5 + 45) * (1 - (p - t) / z);
           else 
                -- t <= g, mob is Gray
                xp = 0;
           end
      end
      xp = floor(xp+0.5);    -- result is rounded before calculating rest bonus
      if ( GetRestState() == 1 and nil ) then
           xp = xp * 2;
      end
      if ( UnitClassification("target") == "elite" and nil ) then
           xp = xp * 2;
           -- what about "worldboss", "rareelite"... not sure how the XP scales
      end
      if (xp > 0) then
           return xp;
      else
           return 0;
      end
end

















function PromoteAll()
if not IsRaidLeader() then return nil end
  for i=1,40 do
    if UnitExists("raid" .. i) and IsRaidLeader() then PromoteToAssistant(UnitName("raid" .. i)) end
  end
end







function CanInvite()
  if type( GetNumRaidMembers() )=="number" and GetNumRaidMembers()>=40 then
    return false
  elseif IsRaidLeader() or IsRaidOfficer() or IsPartyLeader() then
    return 1
  elseif GetNumPartyMembers()==0 and GetNumRaidMembers()==0 then
    return 1
  else
    return false
  end
end
















function SkillRank(sname)
  for k=1,GetNumSkillLines() do
    local skillName, header, isExpanded, skillRank, numTempPoints, skillModifier, skillMaxRank, isAbandonable, stepCost, rankCost, minLevel, skillCostType, skillDescription = GetSkillLineInfo(k);
    if skillName and skillName==sname then
      --DEFAULT_CHAT_FRAME:AddMessage(skillRank)
      return skillRank
    end
  end
  return -1
end











function WeaponEnchant()
  local _,WpnEncDur = GetWeaponEnchantInfo()
  if type(WpnEncDur)=="number" then
	  return (WpnEncDur/1000)
	else
	  return (0)
	end
end






function PrimaryWeaponType()
  local mainHandLink = GetInventoryItemLink("player",GetInventorySlotInfo("MainHandSlot"))
  local _, _, itemCode = strfind(mainHandLink, "(%d+):")
  local _, _, _, _, _, itemType = GetItemInfo(itemCode)
  return itemType
end




function OffHandType()
  local secondaryHandLink = GetInventoryItemLink("player",GetInventorySlotInfo("SecondaryHandSlot"))
  if not( secondaryHandLink ) then return end
  local _, _, itemCode = strfind(secondaryHandLink , "(%d+):")
  if not( itemCode ) then return end
  local _, _, _, _, _, itemType = GetItemInfo(itemCode)
  if not( itemType ) then return end
  return itemType
end























function Talent(nTalent)
  for i=1,GetNumTalentTabs() do
    for j=1,GetNumTalents(i) do
      nameTalent, iconPath, tier, column, currentRank, maxRank, isExceptional, meetsPrereq = GetTalentInfo(i,j);
      if nameTalent==nTalent then
        return (currentRank)
      end
    end
  end
  return -1
end
















function SealDuration()
  for i=1,40 do
    name, rank = GetPlayerBuffName(i);
    if name and strfind(name,"Seal of ") then
      return GetPlayerBuffTimeLeft(i)
    end
  end
  return 0 
end







-- DEFAULT_CHAT_FRAME:AddMessage(text,r,g,b)





--  1001 1110

--  10011110
-- 2+4+8+16+0+0+128
--  =158




function Decode(bag,slot,argu)
  local name = GetContainerItemLink(bag,slot)
  local d_string=""

  for d_index=0,strlen(name)+999 do
    if string.byte(name,d_index) and string.char(string.byte(name,d_index)) then
      if argu then DEFAULT_CHAT_FRAME:AddMessage( d_index .. "      " .. string.char(string.byte(name,d_index)) .. "    " .. string.byte(name,d_index) ) end
      d_string=d_string.. string.char(string.byte(name,d_index)) .. " "
    end
  end
  DEFAULT_CHAT_FRAME:AddMessage(d_string)
end




--[[
	    UseContainerItem(bag,slot);

	    PickupContainerItem(bag,slot);
          if GetContainerItemInfo(bag,slot) and string.find(GetContainerItemInfo(bag,slot),"Misc_Gem_Amethyst_02") then
            DeleteCursorItem()
		return true
          end
]]--























function AuctionExpiredMail()
	for index=0,GetInboxNumItems()+1 do 
		packageIcon, stationeryIcon, sender, subject, money, CODAmount, daysLeft, hasItem, wasRead, wasReturned, textCreated, canReply, isGM = GetInboxHeaderInfo(index)
		
		if type(subject)=="string" and strfind(subject,"Auction expired") and type(sender)=="string" and strfind(sender," Auction House") then
			dprint(index.." "..sender.." "..subject.." ")
			AutoLootMailItem(index)
			return index
			
		end
		
	end
end