-- UIErrorsFrame:AddMessage("msg",0,1,.5,1,2)
-- string.find(UnitDebuff("target",i),sDebuffName)
-- DEFAULT_CHAT_FRAME:AddMessage("woot!")






function runningAverage(n_value)
  if not rA_n      then rA_n     = 1         else rA_n = rA_n     + 1            end
  if not rA_sum    then rA_sum = n_value     else rA_sum = rA_sum + n_value      end
  if not rA_sSqr   then rA_sSqr = n_value^2  else rA_sSqr = rA_sSqr + n_value^2  end

  sd2 = 1/(rA_n-1)*(rA_sSqr - (rA_sum)^2/rA_n)
  sd  = sqrt( abs(sd2) )
  avg = rA_sum / rA_n
end






function echorunningAverage()
  if not rA_n    then return rA_n    end
  if rA_n <=1    then return rA_n    end
  if not rA_sum  then return rA_sum  end
  if not rA_sSqr then return rA_sSqr end

  sd2 = 1/(rA_n-1)*(rA_sSqr - (rA_sum)^2/rA_n)
  sd  = sqrt( abs(sd2) )
  avg = rA_sum / rA_n

  echo("<"..rA_n.."> Mean: ".. floor(avg+0.5) .."  SD: ".. floor(sd+0.5) .. " \124cFF00FFFF Mean+SD: " .. floor(avg+sd) )
end




--[[
1? 	68.26894921371%
2? 	95.44997361036%
3? 	99.73002039367%
4? 	99.99366575163%
5? 	99.99994266969%
6? 	99.99999980268%
7? 	99.99999999974%
]]--




















function Deviation(s_name,number,max_n)
  if not s_name or type(s_name)~="string" then return s_name end


  if not Math_Records then
    Math_Records = {}
  end
  if not Math_Records[s_name] then
    Math_Records[s_name] = {}
  end

  if not number then
    return nil 
  elseif type(number)~="number" then
    if not Math_Records[s_name]["count"] or not Math_Records[s_name]["sum"] or not Math_Records[s_name]["sumsqr"] then return nil end

    if number=="count"   then return Math_Records[s_name]["count"]  end
    if number=="sum"     then return Math_Records[s_name]["sum"]    end
    if number=="sumsqr"  then return Math_Records[s_name]["sumsqr"] end

    if Math_Records[s_name]["count"]==0 then return nil end
    if number=="average" then return Math_Records[s_name]["sum"]/Math_Records[s_name]["count"] end

    if Math_Records[s_name]["count"]==1 then return nil end
    local D_sd2 = 1/(Math_Records[s_name]["count"]-1)*(Math_Records[s_name]["sumsqr"] - (Math_Records[s_name]["sum"])^2/Math_Records[s_name]["count"])
    local D_sd  = sqrt( abs(D_sd2) )

    if number=="standardDeviation" then return D_sd end

    return nil
  end



  if not Math_Records[s_name]["count"] then
    Math_Records[s_name]["count"] = 1
  else
    Math_Records[s_name]["count"] = Math_Records[s_name]["count"] + 1
  end
  if not Math_Records[s_name]["sum"] then
    Math_Records[s_name]["sum"] = number
  else
    Math_Records[s_name]["sum"] = Math_Records[s_name]["sum"] + number
  end
  if not Math_Records[s_name]["sumsqr"] then
    Math_Records[s_name]["sumsqr"] = number*number
  else
    Math_Records[s_name]["sumsqr"] = Math_Records[s_name]["sumsqr"] + number*number
  end



  if Math_Records[s_name]["count"] and Math_Records[s_name]["max_carry"] and Math_Records[s_name]["count"]>Math_Records[s_name]["max_carry"] then
    local magic_number = Math_Records[s_name]["max_carry"] / Math_Records[s_name]["count"]
    Math_Records[s_name]["count"] = magic_number*Math_Records[s_name]["count"]
    Math_Records[s_name]["sum"] = magic_number*Math_Records[s_name]["sum"]
    Math_Records[s_name]["sumsqr"] = magic_number*Math_Records[s_name]["sumsqr"]
  end
end


--[[ approx 33 times max_carry for AVERAGE to normalize      3 at 100
     or 180 at 6   <30>
        220 at 7   
        300 at 10  <30>

shelak with 673 mana:
max_carry 100 will NOT normailze, 99 will NOT normilize
HOWEVER 101 will normilze!!!!!!    /confused !@#$%
]]--











function echoDeviation(s_name)
  if not s_name then return s_name end

  if not Math_Records then return nil end
  if not Math_Records[s_name] then return nil end
  if not Math_Records[s_name]["count"] then return nil end
  if not Math_Records[s_name]["sum"] then return nil end
  if not Math_Records[s_name]["sumsqr"] then return nil end

  if Math_Records[s_name]["count"]==0 or Math_Records[s_name]["count"]==1 then return nil end

  local eD_sd2 = 1/(Math_Records[s_name]["count"]-1)*(Math_Records[s_name]["sumsqr"] - (Math_Records[s_name]["sum"])^2/Math_Records[s_name]["count"])
  local eD_sd  = sqrt( abs(eD_sd2) )
  DEFAULT_CHAT_FRAME:AddMessage( Math_Records[s_name]["count"] .. " \124cFFFF0000 " .. Math_Records[s_name]["sum"]/Math_Records[s_name]["count"] .. " \124cFF00FF00 " .. eD_sd )

end













function zeroDevation(s_name)
  if not s_name then return s_name end
  Math_Records[s_name]["count"]=0
  Math_Records[s_name]["sum"]=0
  Math_Records[s_name]["sumsqr"]=0
end













function Linear(max,min,value)
  
end
















































function round(fnumber,rnum)
  if not fnumber then return fnumber end
  if not rnum then rnum=0 end
  divnum=10^rnum
  returnval=fnumber/divnum + divnum/2
  returnval=floor(returnval)
  returnval=returnval*divnum
  return (returnval)
end