-- DEFAULT_CHAT_FRAME:AddMessage( text )
-- DEFAULT_CHAT_FRAMEScrollToBottom()




local Server = GetRealmName();



function searchBanker_OnLoad()
   SlashCmdList["SEARCHBANKER"] = searchBanker;
   SLASH_SEARCHBANKER1 = "/bfind";
   SLASH_SEARCHBANKER2 = "/bankfind";
   SLASH_SEARCHBANKER3 = "/searchbanker";
end






function searchBanker(n_item,hideSearch)
  if not n_item or strlen(n_item)==0 then n_item="cloth" end
  n_item = strlower(n_item)
  sBcount=0
	
  DEFAULT_CHAT_FRAME:ScrollToBottom() 
	if not hideSearch then
    DEFAULT_CHAT_FRAME:AddMessage( "\nSearching For:\124cFFFF0000 " .. n_item .. "\124r" )
	end


  for k,v in pairs(Inventory[Server]) do
    for j,w in pairs(Inventory[Server][k]) do

      if type(Inventory[Server][k][j])=="table" then
        for l,y in pairs(Inventory[Server][k][j]) do
          if l and ( strfind(n_item,strlower(l)) or strfind(strlower(l),n_item) ) and Inventory[Server][k][j][l] then
            sBcount = sBcount+1
            DEFAULT_CHAT_FRAME:AddMessage("\124cFF88FFFF "..k.."\124r has \124cFFFF4444" .. l .."\124cFFFFDDDD x".. Inventory[Server][k][j][l] )
            if sBcount>60 then
              DEFAULT_CHAT_FRAME:AddMessage("\124cFFFFFF00Too many items found.")
              return
            end
          end
        end
      end

    end
  end

end

















function whoBanker()
  DEFAULT_CHAT_FRAME:ScrollToBottom() 

  for k,v in pairs(CharRecords[Server]) do
    if k and v then
      DEFAULT_CHAT_FRAME:AddMessage(k..v)
    end
  end
end


















function PartyEchoAllItems()
  dir = Inventory[GetRealmName()][UnitName("player")]["Items"]
	x=0
	
	for k,v in pairs(dir) do
	  SendChatMessage(k .. "  x" ..v ,"PARTY")
		x=x+1
		if x>80 then return end 
	end 
end


















































function ListBankerGems()
  echo("Ore")
  searchBanker("Fel Iron Ore",1)
  searchBanker("Adamantite Ore",1)

	echo("Uncommon")
  searchBanker("Blood Garnet",1)  --red
	searchBanker("Flame Spessarite",1)  --orange
	searchBanker("Golden Draenite",1)  --yellow
	searchBanker("Deep Peridot",1)  --green
	searchBanker("Azure Moonstone",1)  --blue
	searchBanker("Shadow Draenite",1)  --purple
	
	echo("Rare")
	searchBanker("Living Ruby",1)  --red
	searchBanker("Noble Topaz",1)  --orange
	searchBanker("Dawnstone",1)  --yellow
	searchBanker("Talasite",1)  --green
	searchBanker("Star of Elune",1)  --blue
	searchBanker("Nightseye",1)  --purple
end

















function ListBankerWellFed()
  searchBanker("Tasty Lion Steak",1)
  searchBanker("Heavy Crocolisk Stew",1)
  searchBanker("Soothing Turtle Bisque",1)
	searchBanker("Roast Raptor",1)
  searchBanker("Mystery Stew",1)
	searchBanker("Jungle Stew",1)
  searchBanker("Hot Wolf Ribs",1)
	searchBanker("Giant Clam Scorcho",1)
  searchBanker("Carrion Surprise",1)
	searchBanker("Barbecued Buzzard Wing",1)
	searchBanker("Spider Sausage",1)
  searchBanker("Heavy Kodo Stew",1)
  searchBanker("Tender Wolf Steak",1)
  searchBanker("Spiced Chili Crab",1)
  searchBanker("Monster Omelet",1)
	searchBanker("Clamlette Surprise",1)
  searchBanker("Talbuk Steak",1)
  searchBanker("Spicy Crawdad",1)
  searchBanker("Dirge's Kickin' Chimaerok Chops",1)
  searchBanker("Mok'Nathal Shortribs",1)
	searchBanker("Feltail Delight",1)
	searchBanker("Clam Bar",1)
	searchBanker("Buzzard Bites",1)
	searchBanker("Fisherman's Feast",1) 
end

























function ListBankerInjectors()
  searchBanker("Runic Healing Potion",1)
  searchBanker("Runic Mana Potion",1)
	dprint(" ")
	searchBanker("Super Healing Potion",1)
  searchBanker("Super Mana Potion",1)
end




























function ListBankerEnchanting()

	searchBanker(" Abyss Crystal",1) 
  searchBanker(" Cosmic Essence",1) 
  searchBanker(" Infinite Dust",1) 
  searchBanker(" Dream Shard",1) 

	dprint(" ")
	searchBanker(" Void Crystal",1) 
  searchBanker(" Planar Essence",1) 
  searchBanker(" Arcane Dust",1) 
  searchBanker(" Prismatic Shard",1) 

	dprint(" ")
	searchBanker(" Nexus Crystal",1) 
  searchBanker(" Eternal Essence",1) 
  searchBanker(" Illusion Dust",1) 
  searchBanker(" Brilliant Shard",1) 
	
	dprint(" ")
  searchBanker(" Nether Essence",1) 
  searchBanker(" Dream Dust",1) 
  searchBanker(" Radiance Shard",1) 
	
	dprint(" ")
  searchBanker(" Mystic Essence",1) 
  searchBanker(" Vision Dust",1) 
  searchBanker(" Glowing Shard",1) 
	
	dprint(" ")
  searchBanker(" Astral Essence",1) 
  searchBanker(" Soul Dust",1) 
  searchBanker(" Glimmering Shard",1) 
	
	dprint(" ")
  searchBanker(" Magic Essence",1) 
  searchBanker(" Strange Dust",1) 
	
	dprint(" ")
  searchBanker(" Vellum",1) 
end
