-- UIErrorsFrame:AddMessage( "msg" ,0,1,.5,1,2 )
-- string.find( UnitDebuff("target",i),sDebuffName )
-- DEFAULT_CHAT_FRAME:AddMessage("woot!")
-- DEFAULT_CHAT_FRAMEScrollToBottom()


Banker = {
	VERSION = 1
}



-- Initialize the variables
local Server = GetRealmName();

CharRecords = {};
CharRecords[Server] = {};
CharRecords[Server][UnitName("player")] = {};

Inventory = {};
Inventory[Server] = {};
Inventory[Server][UnitName("player")] = {};

est_mail = -2








Banker_OnLoad = function()
   this:RegisterEvent("BANKFRAME_CLOSED");
   this:RegisterEvent("BANKFRAME_OPENED");

   this:RegisterEvent("PLAYERBANKBAGSLOTS_CHANGED");
   this:RegisterEvent("PLAYERBANKSLOTS_CHANGED");

   this:RegisterEvent("UNIT_INVENTORY_CHANGED");

   this:RegisterEvent("BAG_CLOSED");
   this:RegisterEvent("BAG_OPEN");
   this:RegisterEvent("BAG_UPDATE");
   this:RegisterEvent("BAG_UPDATE_COOLDOWN");
   
   this:RegisterEvent("LOOT_CLOSED");
   this:RegisterEvent("LOOT_OPENED");
   this:RegisterEvent("LOOT_SLOT_CLEARED");

   this:RegisterEvent("ITEM_PUSH");
   this:RegisterEvent("TRADE_PLAYER_ITEM_CHANGED");

   this:RegisterEvent("TRADE_PLAYER_ITEM_CHANGED");
   this:RegisterEvent("TRADE_PLAYER_ITEM_CHANGED");

   this:RegisterEvent("PLAYER_LEAVING_WORLD");
   this:RegisterEvent("PLAYER_CAMPING");

   this:RegisterEvent("MAIL_CLOSED");
   this:RegisterEvent("MAIL_SHOW");

   est_mail = -1

   BankerLoadTime = GetTime()
end












Banker_OnEvent = function(arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9)
  if event=="BANKFRAME_CLOSED" and ( GetInventoryItemLink("player", 40) or GetInventoryItemLink("player", 46) or GetInventoryItemLink("player", 61) or GetInventoryItemLink("player", 67) or GetInventoryItemLink("player", 68) or GetContainerItemLink(5,1) ) and ( not BankerDelay or GetTime()-BankerDelay>1 ) then
    UpdateBata()
    BankerDelay=GetTime()
    
    
  elseif event=="MAIL_CLOSED" then
	  est_mail = GetInboxNumItems()
    if GetInboxNumItems()>0 and xtimer("echoMailCount",20) then
      dprint(GetInboxNumItems().." items in the mailbox")
    end
    UpdateMailRecords()
    
    
	elseif UnitLevel("player")>0 and ( event=="PLAYER_LEAVING_WORLD" or event=="PLAYER_CAMPING" or ( not CharRecordDelay or GetTime()-CharRecordDelay>60*42 ) ) and GetTime()-BankerLoadTime>8 then
    SaveCharacterRecords()	
    
    
  end 
end







--not called while in combat
Banker_OnUpdate = function ()
  if GetInboxNumItems()~=r_mailcount then
	
	  if GetInboxNumItems() and r_mailcount then
	    dprint( r_mailcount .. " -> " .. GetInboxNumItems() )
		elseif GetInboxNumItems() then
		  dprint( "nil" .. " -> " .. GetInboxNumItems() )
		else
		  dprint( "mail count error" )
		end
	  r_mailcount = GetInboxNumItems()
	end
	
	if not IsInInstance() and ( not t_updateSkills or GetTime()-t_updateSkills > 60*8 ) then
		UpdateSkillSet()
		dprint("Updating Skill Set")
		t_updateSkills = GetTime()
		
	-- and IsAddOnLoaded("_OOM")
	elseif xtimer("Eldest",19) and haveListedEldest then
	  UpdateEldest()
		
	elseif not haveListedEldest and GetTime()-BankerLoadTime>2 then
	  ListEldest()
	  haveListedEldest = GetTime()

		UpdateEldest()
	end
	
end












































function SaveCharacterRecords()
  local GammaList = UnitLevel("player") .. " " .. UnitRace("player") .. " " .. UnitClass("player") .. "  "..date().."  "
  
  if est_mail then
    GammaList = GammaList .. " m: " .. est_mail
  else
    dprint("est_mail variable does not exists!")
  end
  
  if not CharRecords then CharRecords = {} end
  if not CharRecords[Server] then CharRecords[Server] = {} end
  if not CharRecords[Server][UnitName("player")] then CharRecords[Server][UnitName("player")] = {} end

  CharRecords[Server][UnitName("player")] = GammaList
  CharRecordDelay = GetTime()
  DEFAULT_CHAT_FRAMEScrollToBottom()
  DEFAULT_CHAT_FRAME:AddMessage( "[CharRecord][" .. Server .. "][" .. UnitName("player") .. "] Saved @ " .. date() .. "  " .. est_mail ,10/16,15/16,16/16)
	--dprint(GammaList)
end
























function UpdateMailRecords()
  if not Inventory                             then Inventory = {} end
  if not Inventory[Server]                     then Inventory[Server] = {} end
  if not Inventory[Server][UnitName("player")] then Inventory[Server][UnitName("player")] = {} end
  
         Inventory[Server][UnitName("player")]["Mail"] = est_mail
         
  UIErrorsFrame:AddMessage( "Mail Records Updated <"..est_mail..">" ,0,.5,1, 1,2 )
end














function RecoverCharRecord()
  if ( not CharRecords ) or ( not CharRecords[GetRealmName()] ) or ( not CharRecords[GetRealmName()][UnitName("player")] ) then return end

	return CharRecords[GetRealmName()][UnitName("player")] 
end


function CharRecordMail()
  theCharRecord = RecoverCharRecord()
	if theCharRecord and strfind(theCharRecord,"\*") then
	  mailRecord = strsub( theCharRecord , strfind(theCharRecord,"\*")-1 )
		mailRecord = strsub( mailRecord , 4 )
		return mailRecord
	end 
	return -1 
end


























--- Inventory[Server][UnitName("player")]

function UpdateBata()
  if not( GetInventoryItemLink("player", 40) or GetInventoryItemLink("player", 46) or GetInventoryItemLink("player", 61) or GetInventoryItemLink("player", 67) or GetInventoryItemLink("player", 68) or GetContainerItemLink(5,1) ) then
    DEFAULT_CHAT_FRAMEScrollToBottom()
    DEFAULT_CHAT_FRAME:AddMessage("Bank Window Must Be Open" ,1,0,0)
    return nil
  end

  local BataList = {};
  local BagSizes = {};
  local totalBags = 0;
  banker_freebagslots = 0;
  smallBagCount = 0;

-- All Containers --

  for bag=0,12 do

    if GetContainerNumSlots(bag)>0 then
      totalBags = totalBags+1
      if not BagSizes[GetContainerNumSlots(bag).." slot"] then
        BagSizes[GetContainerNumSlots(bag).." slot"] = 1
      elseif BagSizes[GetContainerNumSlots(bag).." slot"] then
        BagSizes[GetContainerNumSlots(bag).." slot"] = BagSizes[GetContainerNumSlots(bag).." slot"]+1
      end
      if GetContainerNumSlots(bag)<20 then
        smallBagCount = smallBagCount + 1
      end
    end

    for slot=1,GetContainerNumSlots(bag) do
      if ( GetContainerItemLink(bag,slot) ) then

        local MyItemName = string.sub( GetContainerItemLink(bag,slot) , string.find(GetContainerItemLink(bag,slot),"|h")+3 , -6)
				local texture, itemCount, locked, quality, readable = GetContainerItemInfo(bag,slot)
        if BataList[MyItemName] then
          BataList[MyItemName] = BataList[MyItemName] + itemCount
        else
          BataList[MyItemName] = itemCount
        end
			else
			  banker_freebagslots = banker_freebagslots + 1;
      end
    end
  end







-- Bank Items --

  for b_slot=40,67 do
    if GetInventoryItemLink("player", b_slot) then

      MyItemName = string.sub( GetInventoryItemLink("player",b_slot) , string.find(GetInventoryItemLink("player",b_slot),"|h")+3 , -6)
      itemCount = GetInventoryItemCount("player", b_slot)

        if BataList[MyItemName] then
          BataList[MyItemName] = BataList[MyItemName] + itemCount
        else
          BataList[MyItemName] = itemCount
        end
			else
			  banker_freebagslots = banker_freebagslots + 1;
    end
		
  end





--[[
  echo( totalBags )
  for k,v in pairs(BagSizes) do
    echo( k .. " " .. v )
  end
]]--

  if smallBagCount==0 then
    smallBagCount=nil
  end


--/script echo(round( UnitLevel("player") + UnitXP("player")/UnitXPMax("player") , -3) )
  if UnitLevel("player")>0 then
    local BataList = {
		Level= round( UnitLevel("player") + UnitXP("player")/UnitXPMax("player") , -3 ) ,
		Class=UnitClass("player"),
		Date=date(),
		Items=BataList,
		Bags=BagSizes,
		SmallBags=smallBagCount,
		Gold = floor(GetMoney())/10000,
		Mail = est_mail,
		FreeSlots = banker_freebagslots,
		GearScore = GetMyGearScore(),
    }
    if not Inventory then Inventory = {} end
    if not Inventory[Server] then Inventory[Server] = {} end
    if not Inventory[Server][UnitName("player")] then Inventory[Server][UnitName("player")] = {} end
    Inventory[Server][UnitName("player")] = BataList
  end


  

  BankerDelay=GetTime()
  DEFAULT_CHAT_FRAMEScrollToBottom()
  DEFAULT_CHAT_FRAME:AddMessage( "[Inventory][" .. Server .. "][" .. UnitName("player") .. "] Saved @ " .. date() .. "   [" .. banker_freebagslots .. "]" ,10/16,15/16,16/16)
end

















-- DEFAULT_CHAT_FRAMEScrollToBottom()
-- GetInventoryItemLink("player", b_slot)
-- DEFAULT_CHAT_FRAME:AddMessage( tempbag[bag][slot] )






-- copy'd from _OOM\Tools.lua
dprint = function(...)
  DEFAULT_CHAT_FRAME:AddMessage(...)
  DEFAULT_CHAT_FRAMEScrollToBottom() 
end










--AddOns\_OOM\Tools.lua
function DEFAULT_CHAT_FRAMEScrollToBottom()
  if xtimer("ScrollToBottom",20) then
    DEFAULT_CHAT_FRAME:ScrollToBottom() 
    ChatRefresh = GetTime()
  else
    DEFAULT_CHAT_FRAME:ScrollDown() 
    ChatRefresh = GetTime()
  end
end
























function BankerGold(minFind)
  goldsum = 0
  for key1,val1 in pairs( Inventory[GetRealmName()] ) do
	
    if minFind and type(minFind)=="number" then
	  currGold = Inventory[GetRealmName()][key1]["Gold"]
	  
			if type(currGold)=="number" and type(minFind)=="number" and currGold>minFind then
				dprint(" ".. key1 .." has "..ColorText(1,1,0).. minFind ..ColorText().." + "..ColorText(1,0,0) .. round(currGold-minFind,-4) )
				goldsum = goldsum + ( currGold - minFind )
					
			elseif currGold then
				dprint(" ".. key1 .." has "..ColorText(1,1,0).. currGold )
				goldsum = goldsum + 0
				
			end
	  
		elseif Inventory[GetRealmName()][key1]["Gold"] then
				dprint(" ".. key1 .." has "..ColorText(1,1,0).. Inventory[GetRealmName()][key1]["Gold"] )
				goldsum = goldsum + Inventory[GetRealmName()][key1]["Gold"]
				
		end
		
  end 
  
  dprint( "Total Gold: "..ColorText(1,1,0).. goldsum ) 
end






















--SkillListSet global saved 

function UpdateSkillSet()
  if not SkillListSet then
    SkillListSet = {}
  end
  if not SkillListSet[GetRealmName()] then
    SkillListSet[GetRealmName()] = {}
  end
  if not SkillListSet[GetRealmName()][UnitName("player")] then
    SkillListSet[GetRealmName()][UnitName("player")] = {}
  end
  
  local skillTable = {};
  
  ExpandSkillHeaders()
  
  for skillIndex = 1, GetNumSkillLines() do
    skillName, isHeader, isExpanded, skillRank, numTempPoints, skillModifier, skillMaxRank, isAbandonable, stepCost, rankCost, minLevel, skillCostType, skillDescription = GetSkillLineInfo(skillIndex)
    if isHeader == nil then
      if skillRank==1 and skillMaxRank==1 then
        --skip
      elseif strfind(skillName,"Language") then
        --skip
      else
        --DEFAULT_CHAT_FRAME:AddMessage(skillName .. " " .. skillRank .."/" .. skillMaxRank)
        skillTable[skillName] = skillRank .. " / " .. skillMaxRank
      end
    end
  end

  t_skilllistset = GetTime()
  SkillListSet[GetRealmName()][UnitName("player")] = skillTable
end



function ExpandSkillHeaders()
  tempNum = GetNumSkillLines()
  for skillIndex = GetNumSkillLines(),1,-1 do
    ExpandSkillHeader(skillIndex)
  end
  if GetNumSkillLines()~=tempNum then
    dprint("Recursive!")
    ExpandSkillHeaders()
  end
end


























-- Initialize the variables
Eldest = {};
Eldest[GetRealmName()] = {};
Eldest[GetRealmName()][UnitName("player")] = {};



function UpdateEldest()
	  if not Eldest then
		  Eldest = {}
		end
		if not Eldest[GetRealmName()] then
		  Eldest[GetRealmName()] = {}
		end
	  Eldest[GetRealmName()][UnitName("player")] = time()
		
--	dprint("UpdateEldest")
end



-- Also in _OOM/TestEvents.lua
function ListEldest()
  if not Eldest or not Eldest[GetRealmName()] then return end
	
	EldestSort = {}
	esID = 1
	
	for k2,v2 in pairs(Eldest) do
	  for k,v in pairs(Eldest[k2]) do
	    EldestSort[esID] = {}
			EldestSort[esID]["name"] = k
			EldestSort[esID]["server"] = k2
			EldestSort[esID]["value"] = v
			esID = esID+1
		end
	end
	
	table.sort(EldestSort , function (a,b) return (a["value"]>b["value"]) end)
	dprint("Listing Eldest" ,1,.5,0)
	
	  for k3,v3 in pairs(EldestSort) do
		  v = v3["value"]
			k = v3["name"]
			-- .. " " .. ColorText(0.5,0.5,0.5) .. v3["server"] .. ColorText()
			if v3["server"] == GetRealmName() then
			  k = k .. " " .. ColorText(0.5,0.5,0.5) .. v3["server"] .. ColorText()
			else
			  k = k .. " " .. ColorText(0.1,0.1,0.1) .. v3["server"] .. ColorText()
			end
          
			elderPrintString = "@!"
			if type(v)=="table" then
			  --ignore, no characters recorded
		  elseif (time()- v) > 60*60*24 *100 then
        --ignore, over 100 days old
      elseif (time()- v)>60*60*24 *8 then
			  elderPrintString = k .."  ".. round( (time()- v)/(60*60*24) ,-1) .. ColorText(1,0,0) .. " days"
		  elseif (time()- v)>60*60*24 *3 then
			  elderPrintString = k .."  ".. round( (time()- v)/(60*60*24) ,-1) .. ColorText(1,1,0) .. " days"
		  elseif (time()- v)>60*90 then
		      elderPrintString = k .."  ".. round( (time()- v)/(60*60) ,-1) .. ColorText(0,1,1) .. " hrs"
		  elseif (time()- v)>1 then
			  elderPrintString = k .."  ".. round( (time()- v)/(60) ,-1) .. ColorText(0,1,0) .. " mins"
		  else
			  elderPrintString = "@!!"
			end
		  
			if Inventory and Inventory[ v3["server"] ] and Inventory[ v3["server"] ][ v3["name"] ] and Inventory[ v3["server"] ][ v3["name"] ]["Mail"] then
		    eMailCount = Inventory[ v3["server"] ][ v3["name"] ]["Mail"]
			end
		  if eMailCount then
		    elderPrintString = elderPrintString .. ColorText() .. "    " .. eMailCount
		  end
			if elderPrintString and not strfind(elderPrintString,"@!") then
		    dprint( elderPrintString ) 
		  end
		end 
  --dprint("end of elder " ..GetTime())
end


--Inventory["Whisperwind"]["Xkq"]["Mail"]

































--prints list of items in bank that are tradable
function nonSoulBoundBank()
  
end



















--gear score
-- GS_Data
-- dprint( GS_Data["Whisperwind"]["Players"]["Hxt"]["GearScore"]  )

function GetMyGearScore()
  local Server = GetRealmName();
  local Player = UnitName("player");

	if GS_Data and GS_Data[Server] and GS_Data[Server]["Players"] and GS_Data[Server]["Players"][Player] and GS_Data[Server]["Players"][Player]["GearScore"] then
		return GS_Data[Server]["Players"][Player]["GearScore"]
	end

end