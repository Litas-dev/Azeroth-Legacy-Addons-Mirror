
function ColorText(red,green,blue)
  red = tonumber( red )
  green = tonumber( green )
  blue = tonumber( blue )

  if type(red)=="number" and type(green)=="number" and type(blue)=="number" then
    if red<=0 then red=0 end
    if green<=0 then green=0 end
    if blue<=0 then blue=0 end

    if red<=1 and green<=1 and blue<=1 then
      red = red*256
      green = green*256
      blue = blue*256
    end

    red = round( red )
    green = round( green )
    blue = round( blue )

    if red>=255 then red=255 end
    if green>=255 then green=255 end
    if blue>=255 then blue=255 end

    return "\124cFF"..string.format("%02x%02x%02x", red, green, blue)
  else
    return "\124r"
  end
end
