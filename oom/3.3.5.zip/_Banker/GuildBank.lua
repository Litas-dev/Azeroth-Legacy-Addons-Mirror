-- DEFAULT_CHAT_FRAME:AddMessage( text )
-- DEFAULT_CHAT_FRAME:ScrollToBottom()




function searchGuildBank_OnLoad()
   SlashCmdList["GUILDSEARCHBANK"] = ListGuildBankSearch;
   SLASH_GUILDSEARCHBANK1 = "/searchguildbank";
   SLASH_GUILDSEARCHBANK2 = "/sgb";
	 SLASH_GUILDSEARCHBANK3 = "/gbf";
	 
	 slash_guildbank = GetTime()
end







-- name, icon, isViewable, canDeposit, numWithdrawals, remainingWithdrawals = GetGuildBankTabInfo(1 to tabs)
-- GetNumGuildBankTabs()
-- GetCurrentGuildBankTab()

-- GetGuildBankItemLink(1 to tabs,1-98)
-- texture, itemCount, lockedState = GetGuildBankItemInfo(tab,slot)



function FindInGuildBank(itemName)
  if not itemName then return itemName end
  count = 0

  for gtab=1,GetNumGuildBankTabs() do
    for gslot=1,98 do
      slotName = LinkToName( GetGuildBankItemLink(gtab,gslot) )
      if slotName and strfind(slotName,itemName) then
        _, itemCount = GetGuildBankItemInfo(gtab,gslot)
        count = count + itemCount
      end
    end
  end
  dprint( count )
end







-- copyed from _OOM/tools.lua
function LinkToName(iLink)
  if not iLink then return iLInk end
  return strsub(iLink ,strfind(iLink,"\124h")+2, strfind(iLink,"\124h\124")-1 ) 
end












function ListGuildBankSearch(itemName)
  if not itemName then return itemName end
	itemName = strlower(itemName)
  countTable = {}

  for gtab=1,GetNumGuildBankTabs() do
    for gslot=1,98 do
      slotName = LinkToName( GetGuildBankItemLink(gtab,gslot) )
      if slotName and strfind(strlower(slotName),itemName) then
        _, itemCount = GetGuildBankItemInfo(gtab,gslot)
				if not countTable[GetGuildBankItemLink(gtab,gslot)] then
				  countTable[GetGuildBankItemLink(gtab,gslot)] = itemCount
				else
          countTable[GetGuildBankItemLink(gtab,gslot)] = countTable[GetGuildBankItemLink(gtab,gslot)] + itemCount
				end
      end
    end
  end
	
	
	
  lineCount = 1
	if type(maxSearchDisplay)~="number" then
	  maxSearchDisplay = 60
		--the max lines is about 125 or about, maybe 130
	end
	
	dprint(ColorText(.3,.3,.3) .. "Search Guild Bank: " ..ColorText(1,0,0) .. itemName)
	for index,value in pairs(countTable) do
	  dprint("  "..index.." x"..value)
		if lineCount>=maxSearchDisplay then
		  dprint(ColorText(1,1,0) .. "Too Many Results.")
			return (lineCount)
		end
		lineCount = lineCount + 1
	end
end
