-- string.find(UnitDebuff("target",i),sDebuffName) 
-- DEFAULT_CHAT_FRAME:AddMessage("\124cFF112233 woot")


function BDisplay_OnLoad()
  BDisplayBorder:Show()
  BDisplayBorder:SetAlpha(0.15)

   SLASH_FINDLOC1 = "/findloc";
   SlashCmdList["FINDLOC"] = FindLoc;  

end



function FindLoc(command)
  if command and string.find( command ,"clear") then
    findlocY = nil
    findlocX = nil
    setFindperson = nil
  elseif command and type(command)=="string" and not string.find(command," ") and not string.find(command,",") and not string.find(command,"%d") then
    setFindperson=command
    DEFAULT_CHAT_FRAME:AddMessage("Find Person: \124cFFFF4444" .. setFindperson)
    return setFindperson
  elseif not command then
    DEFAULT_CHAT_FRAME:AddMessage(" \124cFFFFFF00"..findlocX.." \124cFF00FFFF"..findlocY)
  end

  local theX, theX, theSpace
  cmd = gsub( command, "," , " ")

  if not cmd then return nil end
  theSpace = string.find(cmd," ")
  if not theSpace then return theSpace end
  theX = string.sub( cmd ,1,theSpace )
  theY = string.sub( cmd ,theSpace,-1)

  theX=tonumber(theX)
  theY=tonumber(theY)

  if theX and theY and type(theX)=="number" and type(theY)=="number" then
    findlocX = theX
    findlocY = theY
    DEFAULT_CHAT_FRAME:AddMessage(" \124cFFFFFF00"..findlocX.." \124cFF00FFFF"..findlocY)
  end
end











function BDisplay_OnUpdate()
  xxxx, yyyy = GetPlayerMapPosition("player")
  if xxxx~=oldxxxx or yyyy~=oldyyyy or not t_Moving then
    t_Moving = GetTime()
		oldxxxx=xxxx
		oldyyyy=yyyy		
  end    



  if IsAltKeyDown() then
    BDisplayFrame:EnableMouse(1);
  else
    BDisplayFrame:EnableMouse(0);
  end

  if UnitIsGhost("player") then t_ghost=GetTime() end



  if not onlyonce then
--  UIFrameFlash(BDisplayBorder ,  0.1, 0.5, 2, false, 0, 1.4);
    Movement()
    onlyonce=true
  end


	if GetUnitSpeed("target")>0 and UnitGUID("target")~=UnitGUID("player") then
		bdtext="Target " .. round( GetUnitSpeed("target")/7.0*100 +0.005,-2)
		
	elseif PlayerMoving() or GetUnitSpeed("player")>0 then
		bdtext="Moving " .. round( GetUnitSpeed("player")/7.0*100 +0.005,-2)
		
	else
		bdtext=" "
	end


  if UnitIsTalking("player") then
    bdtext=bdtext .. "\n" .. "VOICE"
  end


------------------------------------------------------------------------  
  if IsAddOnLoaded("_OOM") then

		Allaince_Suffix = FindUnitByName(AllainceFlagCarrier)
		if Allaince_Suffix and UnitExists(Allaince_Suffix) then
			Allaince_Suffix = " "..floor(UnitHealth(Allaince_Suffix)/UnitHealthMax(Allaince_Suffix)*100)
		else 
			Allaince_Suffix = "   "
		end
		
		Horde_Suffix = FindUnitByName(HordeFlagCarrier)
		if Horde_Suffix and UnitExists(Horde_Suffix) then
			Horde_Suffix = " "..floor(UnitHealth(Horde_Suffix)/UnitHealthMax(Horde_Suffix)*100)
		else 
			Horde_Suffix = "   "
		end


		local _, AllainceHasFlag, text, icon, isFlashing, dynamicIcon, tooltip, dynamicTooltip = GetWorldStateUIInfo(1);
		local _, HordeHasFlag, text, icon, isFlashing, dynamicIcon, tooltip, dynamicTooltip = GetWorldStateUIInfo(2);

		if AllainceFlagCarrier and BattleGround() and (AllainceHasFlag==2 or nil) then
		  bdtext=bdtext .. "\nA: " .. AllainceFlagCarrier .. Allaince_Suffix
		end
		if HordeFlagCarrier and BattleGround() and (HordeHasFlag==2 or nil) then
		  bdtext=bdtext .. "\nH: " .. HordeFlagCarrier .. Horde_Suffix
		end

	
	end
------------------------------------------------------------------------
	
	--[[
  if t_ghost and BattleGround() then
    bdtext=bdtext .. "\n\n" .. mod( floor( GetTime() - t_ghost ) , 30 )
  elseif t_ghost then
    bdtext=bdtext .. "\n\n" .. floor( GetTime() - t_ghost )
  end
	
	-- five second rule
	bdtext=bdtext .. FiveSecDisp() ]]--


  if setFindperson and ( GetNumRaidMembers()>0 or GetNumPartyMembers()>0 ) and UnitExists(setFindperson) then
		findlocX, findlocY = GetPlayerMapPosition(setFindperson)
		findlocX = findlocX*100
		findlocY = findlocY*100
		t_findLoc = GetTime()
	end

  if findlocX and findlocY then
    bdtext=bdtext .. "\n"
    if findlocY>yyyy*100 then bdtext=bdtext .. "Go South " .. round( findlocY-yyyy*100 ,-1) .. "\n" end
    if findlocY<yyyy*100 then bdtext=bdtext .. "Go North " .. round( yyyy*100-findlocY ,-1) .. "\n" end
    if findlocX>xxxx*100 then bdtext=bdtext .. "Go East " .. round( findlocX-xxxx*100 ,-1) end
    if findlocX<xxxx*100 then bdtext=bdtext .. "Go West " .. round( xxxx*100-findlocX ,-1) end
  end



  bdtext=bdtext.."\124r"
  BDisplayText:SetText(bdtext);
  return
end








function PrayerOfMending(u_name)
  if not UnitExists(u_name) then return "" end
  if not UnitIsVisible(u_name) then return "" end
	if not IsAddOnLoaded("_OOM") then return "" end
  if not Unit_Buff(u_name,"Prayer of Mending") then return "" end
  if Unit_Buff(u_name,"Prayer of Mending")==0 then return "" end
  if Unit_Buff_Timeleft(u_name,"Prayer of Mending")==0 then return "" end
  
  for i=1,45 do
    name, rank, iconTexture, count, debuffType, duration, timeLeft, isMine, isStealable = UnitBuff(u_name,i)
    if name and name=="Prayer of Mending" and isMine==nil then
      return ""
    end
  end
  
  if Unit_Buff(u_name,"Prayer of Mending")==1 then
    return "\n" .. ColorText(255,0,0) .. UnitName(u_name)
  elseif Unit_Buff(u_name,"Prayer of Mending")==2 then
    return "\n" .. ColorText(255,255,0) .. UnitName(u_name)
  else
    c_blue = tonumber( 255-Unit_Buff_Timeleft(u_name,"Prayer of Mending")/30*255 )
    return "\n" .. ColorText(0,255,c_blue) .. UnitName(u_name)
  end
end
















---------------------------------------------------------------------------------
-- copied to _OOM/Secure.lua
function PlayerMoving()
  if t_Moving and abs( GetTime()-t_Moving ) <0.1 then
    return (GetTime()-t_Moving)
  end
	return (false)
end

---------------------------------------------------------------------------------


-- /script UIFrameFlash(BDisplayBorder ,  0.1, 0.5, 2, false, 0, 1.4);








-- 5 second rule
function FiveSecDisp()
  if t_Cast and GetTime() and (GetTime() - t_Cast) <= 5 then
	  return " ^" .. round( (GetTime() - t_Cast) ,0)
	else
	  return " "
	end 
end



























function Movement()
  CS=CalcSpeed()
  if CS and CS>0 then
    lastMovement=GetTime()
  end
  if lastMovement then
    return lastMovement
  end
end




function StringDistance()
  local distanceString=""
  if UnitIsVisible("target")           then distanceString=distanceString .. "V " else distanceString=distanceString .. "  "  end
  if CheckInteractDistance("target",4) then distanceString=distanceString .. "4 " else distanceString=distanceString .. "  "  end
  if CheckInteractDistance("target",3) then distanceString=distanceString .. "3 " else distanceString=distanceString .. "  "  end
  if CheckInteractDistance("target",2) then distanceString=distanceString .. "2 " else distanceString=distanceString .. "  "  end
  if CheckInteractDistance("target",1) then distanceString=distanceString .. "1 " else distanceString=distanceString .. "  "  end
  return distanceString
end




















function CalcSpeed(testbool)
  if not lastx or not lasty or not lastt then
    lastx = 0
    lasty = 0
    lastt=GetTime()
    return -1
  end
  currx, curry = GetPlayerMapPosition("player")

  if testbool then
    _, textureHeight, textureWidth = GetMapInfo()
    currx=currx*textureWidth 
    curry=curry*textureHeight
  end

  dist = sqrt((lastx-currx)^2+(lasty-curry)^2)
  timepasted = GetTime()-lastt
  cspeed = dist/timepasted
  lastt=GetTime()
  lastx, lasty = GetPlayerMapPosition("player")

  if testbool then
    _, textureHeight, textureWidth = GetMapInfo()
    lastx=lastx*textureWidth
    lasty=lasty*textureHeight
  end

  if currx==0 or curry==0 or lastx==0 or lasty==0 then return -1 end
  return cspeed
end

























--copy found in _OOM\Plus\Events.lua
function SoulShardCount()
SSC=0
  for bag=0,4 do
    for slot=1,GetContainerNumSlots(bag) do
      if (GetContainerItemLink(bag,slot)) then
        if (string.find(GetContainerItemLink(bag,slot), "Soul Shard")) then
          SSC=SSC+1
        end
      end
    end
  end
return SSC
end






















function LinkAssistNear()
  local bestMember=nil
  local lowValue=100

    if CheckInteractDistance("targettarget",4) and UnitIsVisible("targettarget") and not UnitIsFriend("targettarget","player") and UnitHealth("targettarget")<lowValue and UnitHealth("targettarget")>0 then
      bestMember="target"
      lowValue=UnitHealth("targettarget")
    end

  for i=1,4 do
    if CheckInteractDistance("party" .. i .. "target",4) and UnitIsVisible("party" .. i .. "target") and not UnitIsFriend("party" .. i .. "target","player") and UnitHealth("party" .. i .. "target")<lowValue and UnitHealth("party" .. i .. "target")>0 then
      bestMember="party" .. i
      lowValue=UnitHealth("party" .. i .. "target")
    end
  end

  for i=1,40 do
    if CheckInteractDistance("raid" .. i .. "target",4) and UnitIsVisible("raid" .. i .. "target") and not UnitIsFriend("raid" .. i .. "target","player") and UnitHealth("raid" .. i .. "target")<lowValue and UnitHealth("raid" .. i .. "target")>0 then
      bestMember="raid" .. i
      lowValue=UnitHealth("raid" .. i .. "target")
    end
  end

  for i=1,4 do
    if CheckInteractDistance("partypet" .. i .. "target",4) and UnitIsVisible("partypet" .. i .. "target") and not UnitIsFriend("partypet" .. i .. "target","player") and UnitHealth("partypet" .. i .. "target")<lowValue and UnitHealth("partypet" .. i .. "target")>0 then
      bestMember="partypet" .. i
      lowValue=UnitHealth("partypet" .. i .. "target")
    end
  end

  for i=1,40 do
    if CheckInteractDistance("raidpet" .. i .. "target",4) and UnitIsVisible("raidpet" .. i .. "target") and not UnitIsFriend("raidpet" .. i .. "target","player") and UnitHealth("raidpet" .. i .. "target")<lowValue and UnitHealth("raidpet" .. i .. "target")>0 then
      bestMember="raidpet" .. i
      lowValue=UnitHealth("raidpet" .. i .. "target")
    end
  end

    if CheckInteractDistance("pettarget",4) and UnitIsVisible("pettarget") and not UnitIsFriend("pettarget","player") and UnitHealth("pettarget")<lowValue and UnitHealth("pettarget")>0 then
      bestMember="pet"
      lowValue=UnitHealth("pettarget")
    end

    if CheckInteractDistance("target",4) and UnitIsVisible("target") and not UnitIsFriend("target","player") and UnitHealth("target")<lowValue and UnitHealth("target")>0 then
      bestMember="player"
      lowValue=UnitHealth("target")
    end

  if bestMember and not UnitIsUnit("target",bestMember .. "target") then
    return UnitName(bestMember .. "target")
  elseif bestMember and UnitName(bestMember .. "target") then
    return UnitName(bestMember .. "target")
  elseif bestMember then
    return UnitName(bestMember)
  else
    return "  "
  end
end























function round(fnumber,rnum)
  if not fnumber then return fnumber end
  if not rnum then rnum=0 end
  divnum=10^rnum
  returnval=fnumber/divnum
  returnval=floor(returnval)
  returnval=returnval*divnum
  return (returnval)
end
