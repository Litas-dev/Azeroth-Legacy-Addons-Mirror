
local CT = ColorText

local dprint = function(...)
  DEFAULT_CHAT_FRAME:AddMessage(...)
end








function CannotHeal_OnEvent(...)
	if event=="COMBAT_LOG_EVENT_UNFILTERED" then

		if select(2,...)=="SPELL_INTERRUPT" and type( select(4,...) )=="string" and select(7,...)==UnitName("player") and type( select(10,...) )=="string" and type( select(13,...) )=="string" and IsHeal( select(13,...) ) then

		CH_attacker = select(4,...)
		CH_heal = select(13,...)
		CH_interrupt = select(10,...)
		CH_setup = ( CH_setup or 0 ) + 1
		t_CH = GetTime()

		--		dprint( "My " .. select(13,...) .. " was interrupted by " .. select(4,...) .. "'s " .. select(10,...) )


		end

		return



	elseif event=="UI_ERROR_MESSAGE" and type(select(1,...))=="string" and strfind(select(1,...),"Can't do that while ") then
		LastCannotHeal_Ailment = strsub( select(1,...) , 21 )
		t_CannotHeal_Ailment = GetTime()
		b_CannotHeal_Setup = ( b_CannotHeal_Setup or 0 ) + 1


	elseif event=="UNIT_SPELLCAST_FAILED" and select(1,...)=="player" and type(select(2,...))=="string" and IsHeal(select(2,...)) then
		LastCannotHeal_Spell = select(2,...)
		t_CannotHeal_Spell = GetTime()

		if LastCannotHeal_Ailment and type(b_CannotHeal_Setup)=="number" and b_CannotHeal_Setup>0 then

			if GetNumRaidMembers()<19 and IsAnyPartyVisible() and ( t_CannotHeal_Ailment and GetTime()-t_CannotHeal_Ailment<0.03 ) and LastCannotHeal_Ailment~="moving" and xtimer(LastCannotHeal_Ailment.."PreventedHeal",9) then
				SendChatMessage(" I cannot cast " ..LastCannotHeal_Spell.. " because I am " .. LastCannotHeal_Ailment .."." ,"PARTY")

			elseif t_CannotHeal_Ailment then

				local str_suffix = " "
				if GetTime()-t_CannotHeal_Ailment<0.03 then
					str_suffix=""
				else
					str_suffix = CT(1,0,0) .."  "..GetTime()-t_CannotHeal_Ailment
				end
				dprint(" I cannot cast " ..LastCannotHeal_Spell.. " because I am " .. LastCannotHeal_Ailment .. "." .. str_suffix )
				xtimerpass(LastCannotHeal_Ailment.."PreventedHeal",2)

			else
				dprint(CT(0.9,0.5,0.5).." t_CannotHeal_Ailment" .. CT() .. " is invalid")

			end

		end
		b_CannotHeal_Setup = nil






	elseif event=="ACTIONBAR_UPDATE_COOLDOWN" or event=="SPELL_UPDATE_COOLDOWN" then
		if CH_setup and CH_attacker and CH_heal and CH_interrupt and t_CH and HealCooldown()>1 then
			local divider = 2

			if GetNumRaidMembers()<19 and IsAnyPartyVisible() and xtimer("HealInterruptMsg",2) then
				SendChatMessage(" My " ..CH_heal.. " was interrupted by " ..CH_attacker.. "'s " ..CH_interrupt.. " for approximately "..ceil(HealCooldown()*divider)/divider .." seconds." ,"PARTY")
			else
				dprint(" My " ..CH_heal.. " was interrupted by " ..CH_attacker.. "'s " ..CH_interrupt.. " for approximately "..ceil(HealCooldown()*divider)/divider .." seconds." )
				xtimerpass("HealInterruptMsg",1)
			end

			CH_setup=nil
		end
	end



	t_CannotHeal_OnEvent = GetTime()
end






















function IsHeal(sName)
  if UnitClass("player")=="Paladin" and HasVariable(sName,PaladinHeals) then
	  return "Paladin"
	elseif UnitClass("player")=="Druid" and HasVariable(sName,DruidHeals) then
	  return "Druid"
  elseif UnitClass("player")=="Shaman" and HasVariable(sName,ShamanHeals) then
	  return "Shaman"
	elseif UnitClass("player")=="Priest" and HasVariable(sName,PriestHeals) then
	  return "Priest"
	end
end



-- HEALING SPELLS TABLES
PaladinHeals = { "Holy Light" , "Flash of Light" , "Cleanse" , "Divine Favor" , "Holy Shock" }
PriestHeals = { "Heal" , "Renew" , "Flash Heal" , "Greater Heal" , "Binding Heal" , "Prayer of Mending" , "Power Word: Shield" , "Lightwell" , "Pain Suppression" , "Circle of Healing" , "Abolish Disease" , "Penance" }
ShamanHeals = { "Healing Wave" , "Lesser Healing Wave" , "Chain Heal", "Riptide" , "Mana Tide Totem" , "Earth Shield" , "Cure Poison" , "Cure Disease" }
DruidHeals = { "Healing Touch" , "Rejuvenation" , "Regrowth" , "Rebirth" , "Remove Curse" , "Abolish Poison" , "Tranquility" , "Swiftmend" , "Lifebloom" , "Tree of Life", "Wild Growth" , "Nourish" }



function HasVariable(sName,nTable)
 	for key,val in pairs(nTable) do
	  if sName==val then
		  return (key)
		end 
	end 
  return (false)
end











function IsAnyPartyVisible()
  if UnitIsVisible("party1") then
	  return 1
	elseif UnitIsVisible("party2") then
	  return 1
	elseif UnitIsVisible("party3") then
	  return 1
	elseif UnitIsVisible("party4") then
	  return 1
	elseif UnitIsVisible("party5") then
	  return 1
	end
end







function HealCooldown()
  if UnitClass("player")=="Paladin" and GetSpellCooldown("Holy Light")~=0 then
	  local s,d,e = GetSpellCooldown("Holy Light") 
	  return s-GetTime()+d
		
	elseif UnitClass("player")=="Druid" and GetSpellCooldown("Healing Touch")~=0 then
	  local s,d,e = GetSpellCooldown("Healing Touch") 
	  return s-GetTime()+d
		
	elseif UnitClass("player")=="Priest" and GetSpellCooldown("Lesser Heal")~=0 then
	  local s,d,e = GetSpellCooldown("Lesser Heal") 
	  return s-GetTime()+d
		
	elseif UnitClass("player")=="Shaman" and GetSpellCooldown("Healing Wave")~=0 then
	  local s,d,e = GetSpellCooldown("Healing Wave") 
	  return s-GetTime()+d
	
	else
		return 0
	end
end

