-- UIErrorsFrame:AddMessage( "msg" ,0,1,.5,1,2)
-- string.find( UnitDebuff("target",i ), sDebuffName )
-- DEFAULT_CHAT_FRAME:AddMessage( "woot!" )





function Esc_OnUpdate(arg1)
	if UnitAffectingCombat("player") or EscKeyLoaded then return end
	if t_EscOnUpdate and GetTime()-t_EscOnUpdate < 1 then return end

	if ( IsAddOnLoaded("_OOM") and GLOBAL_REBIND_ESC_KEY ) or not IsAddOnLoaded("_OOM") then
		--continue
	else
		return
	end

	if not EscKeyLoaded and not UnitAffectingCombat("player") then
		SetBindingClick("ESCAPE","CLEARTARGET")

		DEFAULT_CHAT_FRAME:AddMessage(" Your" .. ColorText(0,0.5,1) .. " Esc" .. ColorText() .. " Key is now \195\156ber! ")
		EscKeyLoaded = GetTime()
		return
	end

	if IsAddOnLoaded("_OOM") then
		GLOBAL_REBIND_ESC_KEY = nil
	end
	
	t_EscOnUpdate = GetTime()
end
 
 
