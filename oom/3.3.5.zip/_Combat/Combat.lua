-- UIErrorsFrame:AddMessage("msg" ,0,1,.5,1,2)
-- string.find( UnitDebuff("target",i),sDebuffName )
-- DEFAULT_CHAT_FRAME:AddMessage("woot!")


local CT = ColorText

ignoreTable = {}



---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

function Combat_OnEvent(...)
  
  --Generage EventArg
  EventArg=event
  for esai = 1, select('#', ...) do
    EventStringAdder( select(esai , ...) ,esai)
  end




  --regenerate old args
  arg1  = select(1  , ...)
  arg2  = select(2  , ...)
  arg3  = select(3  , ...)
  arg4  = select(4  , ...)  
  arg5  = select(5  , ...)
  arg6  = select(6  , ...)
  arg7  = select(7  , ...)
  arg8  = select(8  , ...)  
  arg9  = select(9  , ...)
  arg10 = select(10 , ...)  
  arg11 = select(11 , ...)
  arg12 = select(12 , ...)
  arg13 = select(13 , ...)  


-- set hide_customsearchs to true to ignore all immune/resist/interrupt
-- set hide_customsearchs = "self" to show only immune/resist/interrupts that involve you
-- set hide_customsearchs to false to show all immune/resist/interrupt
	
if not hide_customsearchs or ( hide_customsearchs=="self" and strfind(EventArg,UnitName("player")) ) then
	
	
	
	
	
	
	--Custom Searchs
  --Resists
	if CustomSearch1(event,EventArg) then
		CustomSearchText1(arg4,arg7,arg10)
	end
	
  
  --Immunes
	if CustomSearch2(event,EventArg) and strfind( EventArg , "_MISSED" ) and not strfind( EventArg , "SWING_MISSED" ) then
    if strfind(EventArg,"SWING_MISSED") or not strfind(EventArg,UnitName("player")) then
      --ignore immune misses
			
    elseif type(arg4)=="string" and type(arg7)=="string" and type(arg10)=="string" then
    
      if xtimer(arg7.."immunebyname1",15) or xtimer(arg7.."immunebyname2",15) or xtimer(arg7.."immunebyname3",30) or xtimer(arg7.."immunebyname4",60) or xtimer(arg7.."immunebyname5",120) then
  		  CustomSearchText2(arg4,arg7,arg10)
      end
      
    else
      --DEFAULT_CHAT_FRAME:AddMessage(EventArg)
			
    end
	end
	
  
  
  --Interrupts
	if event=="COMBAT_LOG_EVENT_UNFILTERED" and strfind(strlower(EventArg),"interrupt") then
	  if arg2=="SPELL_CAST_FAILED" and arg4==UnitName("player") and type(arg10)=="string" and arg12=="Interrupted" then
      --player interrupted themselves
      DEFAULT_CHAT_FRAME:AddMessage("$i: "..arg10)

    elseif arg4 and arg7 and arg10 and arg13 and xtimer("i"..arg4..arg7..arg10..arg13,0) then
		  CustomSearchText3(arg4,arg7,arg10,arg13)
    
		elseif arg2=="SPELL_MISSED"and arg10=="Interrupt" and arg12=="IMMUNE" then
			dprint("plan to ignore")
		  --ignore
		
    elseif true then
      DEFAULT_CHAT_FRAME:AddMessage("i:"..EventArg)
			cat(arg2,arg10,arg12)
      
		end
    EventFinderSpam = GetTime()
	end
	
	
end
	
  
  --Clearcasting
	CustomSearch4(event,EventArg)
  
  
  
  
  
  
  
  
  
  
  if type(MinDispPercent)~="number" then
    MinDispPercent=13
  end
  if type(MaxRedDispPercent)~="number" then
    MaxRedDispPercent=50
  end
  
  --arg7 is destination, arg4 is sourcename, arg2 = damage type ("SWING_DAMAGE")
  if event=="COMBAT_LOG_EVENT_UNFILTERED" and strfind(EventArg,"_DAMAGE") and ( arg7==UnitName("player") or showAllCombat ) and arg2 and arg4 then
    local timestamp, combatevent, sourceGUID, sourceName, sourceFlags, destGUID, destName, destFlags = select(1, ...)
    
    if strfind(arg2,"SPELL_") or strfind(arg2,"RANGE_DAMAGE") then
      spellId, spellName, spellSchool = select(9, ...)
      amount, overkill, school, resisted, blocked, absorbed, critical, glancing, crushing = select(12, ...)
      
    elseif strfind(arg2,"SWING") then
      amount, overkill, school, resisted, blocked, absorbed, critical, glancing, crushing = select(9, ...)
      
    end
    

    post_text = " ("
    if critical then
      post_text = post_text.."Crit"
    end
    if glancing then
      post_text = post_text.."Glancing"
    end
    if crushing then
      post_text = post_text.."Crushing"
    end
    if absorbed then
      post_text = post_text.."absorb="..absorbed
    end
    if blocked then
      post_text = post_text.."block="..blocked
    end
    if resisted then
      post_text = post_text.."resist="..resisted
    end
    
    post_text = post_text..") "
    if post_text==" () " then
      post_text = ""
    end
    
    if school then
      post_text = post_text .. " ["..BiSS2Text(school).."]"
    end
    
    colorAmount = ColorText(1, LinearC(amount/UnitHealthMax("player")*100,MaxRedDispPercent,MinDispPercent) ,0) .. amount .. ColorText()
    
    
    if strfind(arg2,"SPELL_") and type(arg10)=="string" and type(arg12)=="number" then

      if amount > UnitHealthMax("player")*(MinDispPercent/100) then
        DEFAULT_CHAT_FRAME:AddMessage(sourceName .. " did " .. colorAmount .. " damage to you with "..spellName .. post_text)
      end
      
      
    elseif strfind(arg2,"RANGE_DAMAGE") and type(arg12)=="number" then

    
      if amount > UnitHealthMax("player")*(MinDispPercent/100) then
        DEFAULT_CHAT_FRAME:AddMessage(sourceName .. " did " .. colorAmount .. " range damage to you" .. post_text)
      end      
      
      
    elseif strfind(arg2,"SWING") and type(arg9)=="number" then
    
      if amount > UnitHealthMax("player")*(MinDispPercent/100) then
        DEFAULT_CHAT_FRAME:AddMessage(sourceName .. " did " .. colorAmount .. " damage to you" .. post_text)
      end
      --DEFAULT_CHAT_FRAME:AddMessage(EventArg)
      --echo( amount )
      
      
    else
      DEFAULT_CHAT_FRAME:AddMessage(EventArg)
      
    end

  end --end of high dmg hits
  
  
  
  
  
  
  
  --Serendipity
  if event=="COMBAT_LOG_EVENT_UNFILTERED" and arg2=="SPELL_ENERGIZE" and arg10=="Serendipity" and type(arg12)=="number" then
    if arg4==UnitName("player") and arg7==UnitName("player") then
      dprint("Serendipity returned " .. ColorText(0,.5,1) .. arg12 .. " mana")
    elseif arg4==UnitName("player") or arg7==UnitName("player") then
      DEFAULT_CHAT_FRAME:AddMessage(ColorText(0,1,0).."$"..ColorText()..EventArg)
    end
  end
  
  
  
  
  
  
  
  
  -- SEED OF CORRUPTION
  if event=="COMBAT_LOG_EVENT_UNFILTERED" and arg2=="SPELL_DAMAGE" and arg10=="Seed of Corruption" then
    local timestamp, combatevent, sourceGUID, sourceName, sourceFlags, destGUID, destName, destFlags = select(1, ...)
    local amount, overkill, school, resisted, blocked, absorbed, critical, glancing, crushing = select(12, ...)

    if sourceName==UnitName("player") and showSeedOfCorruption then
      DEFAULT_CHAT_FRAME:AddMessage("Your " ..ColorText(.8,.8,.8).. "Seed of Corruption" ..ColorText().. " hit " ..ColorText(1,.1,.1).. destName ..ColorText().. " for " ..ColorText(.5,.5,1).. amount)
    end
  end
  
  
  
  
  -- REFLECT
  if event=="COMBAT_LOG_EVENT_UNFILTERD" and strfind(EventArg,"REFLECT") then
    dprint( EventArg )
  end
  
  
  
  
  
  
  
  --COMBAT LOG EVENT!!
  if event=="COMBAT_LOG_EVENT_UNFILTERED"  then
    local timestamp, combatevent, sourceGUID, sourceName, sourceFlags, destGUID, destName, destFlags = select(1, ...)
    
    if strfind(combatevent,"SPELL") or strfind(combatevent,"RANGE")  then
      local spellId, spellName, spellSchool = select(9, ...)
			
      --HEAL SPELLS     
      if strfind(combatevent,"_HEAL") then
        local amount, overhealing, critical = select(12, ...)
        
        
				--Rune Tap
        --and arg2=="SPELL_HEAL" and arg10=="Rune Tap" and type(arg4)=="string" and type(arg7)=="string" and type(arg12)=="number"  
        if spellName=="Rune Tap" and type(sourceName)=="string" and type(destName)=="string" and type(amount)=="number" then
			    if not ignore_RuneTap and amount ~= overhealing then
            dprint(sourceName .. "'s Rune Tap healed " .. destName .. " for " .. amount .. " (overhealing=" .. overhealing ..")" )
				  end
        end
        
        
      elseif strfind(combatevent,"_DAMAGE") then
        local amount, overkill, school, resisted, blocked, absorbed, critical, glancing, crushing = select(12, ...)
        --DAMAGE SPELLS
        
        
      end
      
      
      
      
      
      
      
    --end of SPELL
    end 
    

    
    
    
    
    
  end --end of combat log event
  
  
  
  
  
end -- end of EventFinder_OnEvent()




















































function echoPrettyColors()
  echo( UnitHealthMax("player")*MinDispPercent/100 )
  echo( UnitHealthMax("player")*MaxRedDispPercent/100 )
end


















--COMBAT_LOG_EVENT_UNFILTERED

--CustomSearch

--resist
function CustomSearch1(event,EventArg)
  if strfind(EventArg,"RESIST") then
		if event=="COMBAT_LOG_EVENT_UNFILTERED" then
      lEArg = strlower(EventArg)
      if not strfind(lEArg,"molten armor") and not strfind(lEArg,"fire shield") and not strfind(lEArg," resistance aura") and not strfind(lEArg,"unit_resistances") then
        if xtimer(EventArg.."1",2) or xtimer(EventArg.."2",12) then
          EventFinderSpam = GetTime()
          return (EventArg)
        end
			end
		end
	end
end


--immune
function CustomSearch2(event,EventArg)
  if strfind(strlower(EventArg),"immune") then
		if event=="COMBAT_LOG_EVENT_UNFILTERED" then
      lEArg = strlower(EventArg)
      if not strfind(lEArg,"molten armor") and not strfind(lEArg,"fire shield") and not strfind(lEArg," resistance aura") and not strfind(lEArg,"unit_resistances") and not strfind(lEArg,"thorns") then 
        if xtimer(EventArg.."1",4) or xtimer(EventArg.."2",45) then
          EventFinderSpam = GetTime()
          return (EventArg)
        end
			end
		end
	end
end


--clearcasting
function CustomSearch4(event,EventArg)
  if strfind(EventArg,"COMBAT_LOG_EVENT_UNFILTERED") and strfind(EventArg,"Clearcasting") and strfind(EventArg,"SPELL_AURA_APPLIED") and strfind(EventArg,UnitName("player")) then
    --dprint(EventArg.."\n")
		UIErrorsFrame:AddMessage("Clearcasting" ,0,1,.5,1,2)
	end 
end


















--CustomSearchText

-- RESIST
function CustomSearchText1(arg4,arg7,arg10)
  if ignoreTable[arg10] then
	  return nil
	end
  if arg4 and xtimer(arg4..arg7..arg10,90) then
    dprint("  "..ColorText(.6,.6,1)..arg4..ColorText().."'s "..ColorText(0,1,0)..arg10..ColorText().." resisted by "..ColorText(1,.2,.2)..arg7..ColorText() ) 
  end 
end


-- IMMUNE
function CustomSearchText2(arg4,arg7,arg10)
  if arg4 and arg7 and arg10 and xtimer(arg4..arg7..arg10,90) then
	  -- victim is immune to caster's action
    dprint("  "..ColorText(1,.2,.2)..arg7..ColorText().." is immune to "..ColorText(.6,.6,1)..arg4..ColorText().."'s "..ColorText(0,1,0)..arg10..ColorText() ) 
  elseif not arg10 or not arg4 or not arg7 then
    dprint("  Error CustomSearchText2: " .. arg4.." "..arg7)  
	end 
end


-- INTERRUPT
function CustomSearchText3(arg4,arg7,arg10,arg13)
  --victims's spell interrupted by attacker's spell
  dprint("  "..CT(1,.7,.7)..arg7..CT().."'s "..CT(1,.2,.2)..arg13..CT().." interrupted by "..CT(.6,.6,1)..arg4..CT().."'s "..CT(0,1,0)..arg10..CT() ) 
end























































function EventStringAdder(arg,numarg)
  spacer = " "
  if numarg and arg then
    EventArg=EventArg..ColorText(1,0,0)..' '..numarg.."="..ColorText()
    spacer = ""
  end
  if arg and type(arg)~="boolean" and strlen(arg)>0 then
    EventArg=EventArg..spacer..arg
  elseif arg and type(arg)=="boolean" then
    EventArg=EventArg.." ".."TRUE"
  end
end
