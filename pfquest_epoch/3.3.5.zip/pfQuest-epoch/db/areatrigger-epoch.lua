pfDB["areatrigger"]["data-epoch"] = {
  [2726] = {
    ["coords"] = {
      [1] = { 23.9, 68.4, 139 },
    },
  },
  [10000] = {
    ["coords"] = {
      [1] = { 55.6, 35.2, 12 },
    },
  },
  [4000000] = { --Revils Camp
    ["coords"] = {
      [1] = { 74.7, 62.8, 10 },
    },
  },
  [4000001] = { --Manor Mistmantle
    ["coords"] = {
      [1] = { 77.1, 35.8, 10 },
    },
  },
  [4000002] = { --Rolands Doom
    ["coords"] = {
      [1] = { 73.4, 84.3, 10 },
    },
  },
  [4000003] = { --Blazing Hills
    ["coords"] = {
      [1] = { 78.91, 74.50, 45 },
    },
  },
  [4000004] = { --Hillsbrad Foothills Central Tower
    ["coords"] = {
      [1] = { 55.60, 34.73, 267 },
    },
  },
  [4000005] = { --Durnhold Escape
    ["coords"] = {
      [1] = { 76.47, 46.64, 267 },
    },
  },
  [4000006] = { --Minkrik\'s Village
    ["coords"] = {
      [1] = { 61.5, 23.8, 17 },
    },
  },
  [4000007] = { --Blazing Hills
    ["coords"] = {
      [1] = { 82.8, 57.3, 45 },
    },
  },
  [4000008] = { --Stonetalon Caverns
    ["coords"] = {
      [1] = { 30.7, 48.3, 406 },
    },
  },
  [4000009] = { --Shadowforge Excavation
    ["coords"] = {
      [1] = { 81.0, 33.1, 3 },
    },
  },
  [4000010] = { --Centar Artifact
    ["coords"] = {
      [1] = { 42.15, 34.78, 400 },
    },
  },
  [4000011] = { --Aru-Tails Site One
    ["coords"] = {
      [1] = { 38.8, 87.2, 490 },
    },
  },
  [4000012] = { --Meeting Location
    ["coords"] = {
      [1] = { 67.1, 78.7, 85 },
    },
  },
  [4000013] = { --Odor\'s Source
    ["coords"] = {
      [1] = { 60.6, 15.1, 618 },
    },
  },
  [4000014] = { --Blackmaw Village Overlook
    ["coords"] = {
      [1] = { 52.4, 13.1, 16, 0 },
    },
  },
  [4000015] = { --Tul\'Mari\'s Tomb
    ["coords"] = {
      [1] = { 46.3, 90.2, 440, 0 },
    },
  },
  [4000016] = { --Northshore Mine
    ["coords"] = {
      [1] = { 22.4, 50.9, 85, 0 },
    },
  },
  [4000017] = { --Stillwater Pond
    ["coords"] = {
      [1] = { 49.75, 52.0, 85, 0 },
    },
  },
}
