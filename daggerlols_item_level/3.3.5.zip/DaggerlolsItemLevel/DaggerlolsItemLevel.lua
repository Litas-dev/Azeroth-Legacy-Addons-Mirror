local SLOTIDS, FONTSIZE = {}, 12
for _,slot in pairs({"Head", "Neck", "Shoulder", "Back", "Chest", "Shirt", "Tabard", "Wrist", "Hands", "Waist", "Legs", "Feet", "Finger0", "Finger1", "Trinket0", "Trinket1", "MainHand", "SecondaryHand", "Ranged"}) do SLOTIDS[slot] = GetInventorySlotInfo(slot .. "Slot") end
local frame = CreateFrame("Frame", nil, CharacterFrame)
local _, class = UnitClass("player")
local t = RAID_CLASS_COLORS[class]
local r, g, b = t.r, t.g, t.b

local fontstrings = setmetatable({}, {
	__index = function(t,i)
		local gslot = _G["Character"..i.."Slot"]
		assert(gslot, "Character"..i.."Slot does not exist")
		
		local fstr = gslot:CreateFontString(nil, "OVERLAY")
		local font, _, flags = NumberFontNormal:GetFont()
		fstr:SetFont(font, FONTSIZE, flags)
		fstr:SetPoint("CENTER", gslot, "TOP", 0, -8)
		t[i] = fstr
		return fstr
	end,
})

function frame:OnEvent(event, arg1)
	if event == "ADDON_LOADED" and arg1:lower() ~= "DaggerlolsItemLevel" then
		for i,fstr in pairs(fontstrings) do

			local font, _, flags = NumberFontNormal:GetFont()
			fstr:SetFont(font, FONTSIZE, flags)
		end
		return
	end

	for slot,id in pairs(SLOTIDS) do
		local link = GetInventoryItemLink("player", id)
		
		if link then
			local _,_,_,ilevel,_,_,_,_,_,_ = GetItemInfo(link)
			if ilevel then
				local str = fontstrings[slot]
				str:SetTextColor(t.r, t.g, t.b)
				str:SetText(string.format("%s", ilevel))
			end
		else
			local str = rawget(fontstrings, slot)
			if str then str:SetText(nil) end
		end
	end
end


frame:SetScript("OnEvent", frame.OnEvent)
frame:RegisterEvent("ADDON_LOADED")
frame:RegisterEvent("UNIT_INVENTORY_CHANGED")
frame:RegisterEvent("UPDATE_INVENTORY_DURABILITY")
