﻿-- Author      : chris
-- Create Date : 11/28/2009 11:54:04 PM


TT_ERR_CHAT_PLAYER_NOT_FOUND_S = gsub(ERR_CHAT_PLAYER_NOT_FOUND_S, "%%s", "(.*)")
TT_ERR_FRIEND_OFFLINE_S = gsub(ERR_FRIEND_OFFLINE_S, "%%s", "(.*)")
TT_ERR_FRIEND_ONLINE_SS = gsub(ERR_FRIEND_ONLINE_SS, "%%s", "(.*)")

TellTrack_cmdlist = {
	enable			= { var="Enable",		help=TT_HELP_ENABLE,		[1]=TT_CHAT_ENABLED, [0]=TT_CHAT_DISABLED, },
	invert			= { var="ListInvert",	help=TT_HELP_INVERT,		[1]=TT_CHAT_INVERTED, [0]=TT_CHAT_NORMALIZED, },
	dontsavelist	= { var="ListSave",		help=TT_HELP_LISTSAVE,		[1]=TT_CHAT_LISTSAVE, [0]=TT_CHAT_LISTSAVE0, alias="listsave", },
	listsave		= { var="ListSave",		help=TT_HELP_LISTSAVE,		[1]=TT_CHAT_LISTSAVE, [0]=TT_CHAT_LISTSAVE0, },
	autocreate		= { var="AutoCreate",	help=TT_HELP_AUTOCREATE,	[1]=TT_CHAT_AUTOCREATE, [0]=TT_CHAT_AUTOCREATE0, },
	hidewhispers	= { var="HideWhispers", help=TT_HELP_HIDEWHISPERS,	[1]=TT_CHAT_HIDEWHISPERS, [0]=TT_CHAT_SHOWWHISPERS, },
	timestamps		= { var="TimeStamps",	help=TT_HELP_TIMESTAMPS,	[1]=TT_CHAT_TIMESTAMPS, [0]=TT_CHAT_NOTIMESTAMPS, },
	whisperfirst	= { var="WhisperFirst", help=TT_HELP_WHISPERFIRST,	[1]=TT_CHAT_WHISPERFIRST, [0]=TT_CHAT_LOGFIRST, },
	clearall		= { var=nil,			help=TT_HELP_CLEARALL,		[1]=nil, [0]=nil, },
	border			= { var="Border",		help=TT_HELP_BORDER,		[1]=TT_CHAT_HIDEBORDER, [0]=TT_CHAT_SHOWBORDER, },
	linenums		= { var="LineNums",		help=TT_HELP_LINENUMS,		[1]=TT_CHAT_SHOWLINENUMS, [0]=TT_CHAT_HIDELINENUMS, },
	showall			= { var=nil,			help=TT_HELP_SHOWALL,		[1]=nil, [0]=nil, },
	debug			= { var="DebugMode",	help=TT_HELP_ENABLE,		[1]="Debug Enabled", [0]="Debug Disabled", },
}

