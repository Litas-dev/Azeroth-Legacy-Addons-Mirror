local L = LibStub("AceLocale-3.0", true):NewLocale("TellTrack", "enUS", true)
if not L then return end

-- Version : English (by Sarf)
-- Last Update : 02/17/2005

-- player list
L["Empty"] = true
L["Tell Track"] = true
L["-- No Current Conversation with %s --"] = true
 
-- Chat Configuration
TT_CHAT_ENABLED			= "Tell Track enabled."
TT_CHAT_DISABLED		= "Tell Track disabled."
TT_CHAT_INVERTED		= "Tell Track list inverted."
TT_CHAT_NORMALIZED		= "Tell Track list normalized."
TT_CHAT_LISTSAVE		= "Tell Track list set to clear between sessions."
TT_CHAT_LISTSAVE0		= "Tell Track list set to save between sessions."
TT_CHAT_AUTOCREATE		= "The whisper chat frame will now be automaticly created when needed, if possible."
TT_CHAT_AUTOCREATE0	= "The whisper chat frame must now be created manually."
TT_CHAT_HIDEWHISPERS	= "The whispers in all chat frames except the TellTrack whisper frame, if it exists, will be hidden."
TT_CHAT_SHOWWHISPERS	= "Whispers will show in all chat frames like default behavior."
TT_CHAT_TIMESTAMPS		= "Whisper frame time stamps enabled."
TT_CHAT_NOTIMESTAMPS	= "Whisper frame time stamps disabled."
TT_CHAT_WHISPERFIRST	= "TellTrack OnClick set to: Whisper First."
TT_CHAT_LOGFIRST		= "TellTrack OnClick set to: Chat Log First."
TT_CHAT_HIDEBORDER		= "TellTrack border is now hidden."
TT_CHAT_SHOWBORDER		= "TellTrack border is now shown."
TT_CHAT_HIDELINENUMS	= "TellTrack line numbers are now hidden."
TT_CHAT_SHOWLINENUMS	= "TellTrack line numbers are now shown."
TT_CHAT_HIDEOTHER		= "TellTrack all whispers are now hidden."
TT_CHAT_SHOWALL			= "TellTrack all whispers are now shown."

TT_HELP_INFO		= "Tell Track Config Options"
TT_HELP_ENABLE		= "Enables/disables Tell Track."
TT_HELP_CLEARALL	= "Clears all Tell Track entries."
TT_HELP_INVERT		= "Inverts/Normalizes Tell Track list."
TT_HELP_LISTSAVE	= "Stops the TellTrack list from being saved between sessions."
TT_HELP_AUTOCREATE	= "Auto-Create Whisper Frame."
TT_HELP_HIDEWHISPERS	= "Hide whispers in all chat frames except the TellTrack whisper frame."
TT_HELP_TIMESTAMPS	= "Print time stamps on messages in the TellTrack whisper frame."
TT_HELP_WHISPERFIRST	= "First TellTrack name click will open a whisper, second will reveal their chat log."
TT_HELP_BORDER		= "Hide border and scroll buttons."
TT_HELP_LINENUMS	= "Show line numbers."
TT_HELP_SHOWALL		= "Show all whispers."

TT_CHAT_USEAGE		= "Usage: '/telltrack <SubCommand> [on/off/1/0]'"

TT_CHAT_INFO		= "Tell Track Help:"
TT_CHAT_INFO1		= "  On List: Left-Click Show Thread or Send Tell\nRight-Click Delete Player"
TT_CHAT_INFO2		= "  On Arrows: Left-Click scroll by page\nRight-Click first or last.\nMouse Wheel: Scroll (max 30)"
TT_CHAT_INFO3		= "  /telltrack options - for config options"

-- Interface Configuration
TT_TOOLTIP_INFO		= "Click here for more info."
TT_TOOLTIP_RESIZE	= "Drag here to resize."
TT_MENU_WHISPER		= "Whisper"
TT_MENU_SHOWCONV	= "Show Conversation"
TT_MENU_WHO			= "Who"
TT_MENU_GRPINV		= "Group Invite"
TT_MENU_ADDFRIEND	= "Add to Friends"
TT_MENU_DELETE		= "Delete"
TT_MENU_DELETE_ALL	= "Delete All"
TT_MENU_INVERT		= "Invert List"
TT_MENU_SHOWWHISPERS = "Show All Whispers"
TT_MENU_CREATEFRAME  = "Create Whisper Frame"
TT_MENU_CANCEL		= "Cancel"
