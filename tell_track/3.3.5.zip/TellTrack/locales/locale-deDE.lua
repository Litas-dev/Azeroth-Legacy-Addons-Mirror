local L = LibStub("AceLocale-3.0", true):NewLocale("TellTrack", "deDE", false)
if not L then return end

-- Version : German (by DrVanGogh, StarDust)
-- Last Update : 12/19/2006

-- player list
L["Tell Track"]						= "Laberbox"
L["-- No Current Conversation with %s --"]	= "-- Momentan keine Unterhaltung mit %s --"

-- Chat Configuration
TT_CHAT_ENABLED			= "Laberbox aktiviert.\nDas Laberbox Hilfe-Icon oben rechts anklicken um mehr Informationen zu erhalten."
TT_CHAT_DISABLED		= "Laberbox deaktiviert."
TT_CHAT_INVERTED		= "Kontaktliste umgekehrt."
TT_CHAT_NORMALIZED		= "Kontaktliste der Laberbox wieder normal sortiert."
TT_CHAT_LISTSAVE		= "Kontaktliste der Laberbock wird zwischen den Spielsessions nicht speichern."
TT_CHAT_LISTSAVE0		= "Kontaktliste der Laberbock wird zwischen den Spielsessions speichern."
TT_CHAT_AUTOCREATE		= "Das Fl\195\188stern-Chatfenster wird bei Bedarf automatisch erstellt."
TT_CHAT_AUTOCREATE0		= "Das Fl\195\188stern-Chatfenster muss bei Bedarf manuell erstellt werden."
TT_CHAT_HIDEWHISPERS	= "Fl\195\188stern-Nachrichten werden nur im Fl\195\188stern-Chatfenster anzeigen (sofern jenes vorhanden ist) und in allen anderen Chatfenstern ausgeblendet."
TT_CHAT_SHOWWHISPERS	= "Fl\195\188stern-Nachrichten werden in allen Chatfenstern angezeigt."
TT_CHAT_TIMESTAMPS		= "Fl\195\188stern-Nachrichten werden im Fl\195\188stern-Chatfenster mit einem Zeitstempel versehen."
TT_CHAT_NOTIMESTAMPS	= "Fl\195\188stern-Nachrichten werden mit keinem Zeitstempel versehen."
TT_CHAT_WHISPERFIRST	= "Laberbox BeiKlick gesetzt auf: zuerst Fl\195\188stern-Nachricht."
TT_CHAT_LOGFIRST		= "Laberbox BeiKlick gesetzt auf: zuerst Caht-Log."
TT_CHAT_HIDEBORDER		= "Rahmen der Laberbox ist jetzt ausgeblendet."
TT_CHAT_SHOWBORDER		= "Rahmen der Laberbox wird jetzt angezeigt."

TT_HELP_INFO	= "Einstellungen der Laberbox anzeigen."
TT_HELP_ENABLE			= "Laberbox aktivieren/deaktivieren."
TT_HELP_CLEARALL		= "Alle Eintr\195\164ge der Laberbox l\195\182schen."
TT_HELP_INVERT		= "Kontakliste der Laberbox umkehren/normal sortieren."
TT_HELP_LISTSAVE	= "Kontakliste der Laberbox nach Ende der Spielsession l\195\182schen."
TT_HELP_AUTOCREATE	= "Fl\195\188stern-Chatfenster automatisch erstellen."
TT_HELP_HIDEWHISPERS	= "Fl\195\188stern-Nachrichten in allen Chatfenstern abgesehn vom Fl\195\188stern-Chatfenster verbergen."
TT_HELP_TIMESTAMPS		= "Fl\195\188stern-Nachrichten mit Zeitstempel versehen."
TT_HELP_WHISPERFIRST	= "Der erste Klick auf den Namen startet eine Fl\195\188stern-Nachricht, der zweite zeigt das Chat-Log an."
TT_HELP_BORDER		= "Rahmen und Scroll-Buttons ausblenden."
TT_CHAT_INFO	= "Laberbox Help:"
TT_CHAT_INFO1	= "    Linke Maustaste auf Slot: Nachricht schicken\nRechte Maustaste auf Slot: Slot l\195\182schen\nMausrad: Scrollt einen Slot nach dem anderen durch (max. 20)"
TT_CHAT_INFO2	= "    Linke Maustaste auf Pfeile: Scrollt Slots seitenweise durch (max. 20)\nRechte Maustaste auf Pfeile: Springe zum ersten/letzten Slot."
TT_CHAT_INFO3	= "    '/telltrack' um das Fenster mit Optionen anzuzeigen."
TT_CHAT_USEAGE			= "Benutzung: '/telltrack <Befehl> [on/off/1/0]'"

-- Interface Configuration
TT_TOOLTIP_INFO		= "Hier klicken um weitere \nInformationen anzuzeigen."
TT_TOOLTIP_RESIZE		= "Hierklicken und ziehen um Gr\195\182\195\159e zu \195\164ndern."
TT_MENU_WHISPER			= "Fl\195\188stern"
TT_MENU_SHOWCONV		= "Unterhaltung anzeigen"
TT_MENU_WHO				= "Wer"
TT_MENU_GRPINV			= "Gruppeneinladung"
TT_MENU_ADDFRIEND			= "Freund hinzuf\195\188gen"
TT_MENU_DELETE			= "L\195\182schen"
TT_MENU_DELETE_ALL			= "Alle L\195\182schen"
TT_MENU_INVERT			= "Liste Umkehren"
TT_MENU_SHOWWHISPERS		= "Alle Fl\195\188stern-Nachrichten anzeigen"
TT_MENU_CREATEFRAME		= "Fl\195\188stern-Chatfenster erstellen"
TT_MENU_CANCEL			= "Abbrechen"


