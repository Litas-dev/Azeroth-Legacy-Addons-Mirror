local L = LibStub("AceLocale-3.0", true):NewLocale("TellTrack", "frFR", false)
if not L then return end

-- Version : French  ( by Elzix, Sasmira )
-- Last Update : 03/23/2005

L["-- No Current Conversation with %s --"]	= "-- Par de conversation avec %s --"

-- Chat Configuration
TT_CHAT_ENABLED		= "TellTrack activ\195\169.\nCliquer sur le point d\'interrogation pour plus de d\195\169tails."
TT_CHAT_DISABLED	= "TellTrack d\195\169sactiv\195\169."
TT_CHAT_INVERTED	= "Liste de TellTrack invers\195\169e."
TT_CHAT_NORMALIZED	= "Liste de TellTrack initialis\195\169e."
TT_HELP_ENABLE		= "Active/d\195\169sactive TellTrack.\nUtiliser la commande /telltrack clearall pour effacer toutes les entr\195\169es."
TT_TOOLTIP_INFO		= "Cliquer ici pour plus de d\195\169tails."
TT_CHAT_INFO		= "Tell Track Help:"
TT_CHAT_INFO1		= "    Clique gauche sur emplacement : Envoyer message\nClique droit sur emplacement : Effacer le nom\nRoulette : parcours les emplacements un \195\160 un (max 20)."
TT_CHAT_INFO2		= "    Clique gauche sur fl\195\168ches : parcours les emplacements pages par pages\nClique droit sur fl\195\168ches : va au premier ou au dernier emplacement."

-- Interface Configuration
TT_TOOLTIP_INFO		= "Cliquer ici pour plus d\'infos."
TT_TOOLTIP_RESIZE	= "Cliquer ici pour modifier la taille."
TT_MENU_WHISPER		= "Whisper"
TT_MENU_WHO			= "Who"
TT_MENU_GRPINV		= "Invitation dans un groupe"
TT_MENU_ADDFRIEND	= "Ajouter \195\160 la liste d\'amis"
TT_MENU_DELETE		= "Effacer"
TT_MENU_DELETE_ALL	= "Effacer tous"
TT_MENU_CANCEL		= "Annuler"
TT_MENU_SHOWCONV	= "Afficher la Conversation"
TT_MENU_INVERT		= "Inverser la listet"
TT_MENU_SHOWWHISPERS = "Afficher tous les chuchotement"
TT_MENU_CREATEFRAME  = "Cr\195\169er une fenpetre de chuchotement"
