local L = LibStub("AceLocale-3.0", true):NewLocale("TellTrack", "zhCN", false)
if not L then return end

-- Version : Chinese Simple (WOWUI.CN)
-- Last Update : 04/11/2005

-- player list
L["Empty"] = "(空)"

-- Chat Configuration
TT_CHAT_ENABLED		= "Tell Track 启用了。\n点击 Tell Track 右上角'?'按钮获得跟多信息。"
TT_CHAT_DISABLED	= "Tell Track 禁用了。"
TT_CHAT_INVERTED	= "反向显示 Tell Track 列表。"
TT_CHAT_NORMALIZED	= "正向显示 Tell Track 列表。"
TT_CHAT_INFO		= "Tell Track 汉化版 |cffffff00[WOWUI.CN汉化]|r"
TT_CHAT_INFO1		= "    左键点击：发送悄悄话。\n".."右键点击：删除人名。\n".."滚轮：按行滚动(最大20)。"
TT_CHAT_INFO2		= "    左键点击箭头：按页滚动。"
TT_CHAT_INFO3		= "    右键点击箭头：到最顶端或最底端。"

-- Interface Configuration
TT_TOOLTIP_INFO		= "点击这里获取更多信息"
TT_TOOLTIP_RESIZE	= "拖动这里来调整大小"

