local _, Private = ...

local _G = _G

_G.GameLimitedMode_IsActive = Private.False
_G.IsTrialAccount = Private.False
_G.IsVeteranTrialAccount = Private.False