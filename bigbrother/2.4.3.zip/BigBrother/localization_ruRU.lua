﻿local L = AceLibrary("AceLocale-2.2"):new("BigBrother")
-- Translated by StingerSoft/Argonavt
L:RegisterTranslations("ruRU", function() return {
	["Flask Check"] = "Проверка Фляг",
	["Checks for flasks, elixirs and food buffs."] = "Проверка Фляг и элексиров",

	["Quick Check"] = "Быстрая проверка",
	["A quick report that shows who does not have flasks, elixirs or food."] = "Быстро сообщает, у кого нет Фляг, элексиров или еды.",

	["Self"] = "Для себя",
	["Reports result only to yourself."] = "Сообщает результат проверки только вам",

	["Party"] = "Группа",
	["Reports result to your party."] = "Сообщает результат проверки в группу",

	["Raid"] = "Рейду",
	["Reports result to your raid."] = "Сообщает результат проверки в рейд",

	["Guild"] = "Гильдии",
	["Reports result to guild chat."] = "Сообщает результат проверки в чат гильдии",

	["Officer"] = "Офицерам",
	["Reports result to officer chat."] = "Сообщает результат проверки офицерам",

	["Whisper"] = "Шепнуть",
	["Reports result to the currently targeted individual."] = "Сообщает шопотом результаты текущей целе",

	["Reports if and which player breaks crowd control effects (like polymorph, shackle undead, etc.) on enemies."] = "Сообoщает если/и какой игрок сбил эффект контроля (таких как Превращение, Сковывание нежити, и т.д.) с врага.",

	["Misdirect"] = "Перенаправление",
	["Reports who gains misdirection."] = "Сообщает на кого применено Перенаправление",

	["BuffCheck"] = "Проверка баффов",
	["Pops up a window to check various raid/elixir buffs (drag the bottom to resize)."] = "Всплывающее окошко для проверки рейд/элексиров баффов (двигать кнопку для увеличения).",

	["Settings"] = "Настройки",
	["Mod Settings"] = "Настройки мода",
	["Raid Groups"] = "Рейд группы",
	["Set which raid groups are checked for buffs"] = "Установите какую рейд группу следует проверить на наличее баффов",
	["Group 1"] = "Группа 1",
	["Group 2"] = "Группа 2",
	["Group 3"] = "Группа 3",
	["Group 4"] = "Группа 4",
	["Group 5"] = "Группа 5",
	["Group 6"] = "Группа 6",
	["Group 7"] = "Группа 7",
	["Group 8"] = "Группа 8",

	["Checks"] = "Проверка",
	["Set whether Flasks, Elixirs and Food are included in flaskcheck/quickcheck"] = "Показывает использованные Фляги, злексиры и еду по команде flaskcheck/quickcheck",
	["Flasks"] = "Фляги",
	["Elixirs"] = "Элексиры",
	["Food Buffs"] = "Баффы Еды",

	["No Flask"] = "Нет Фляг",
	["No Flask or Elixir"] = "Нет Фляг или Элексиров",
	["Only One Elixir"] = "Только Один Элексир",
	["Well Fed"] = "Сытость",
	["\"Well Fed\""] = "\"Сытость\"",
	["Enlightened"] = "Просвещение",
	["Electrified"] = "Электризация",
	["No Food Buff"] = "Нет баффов Еды",

	["%s cast %s on %s"] = "%s применил(а) %s на %s.",
	["Polymorph/Misdirect Output"] = "Вывод Превращения/Перенаправления",
	["Set where the polymorph/misdirect output is sent"] = "Установите куда выводить сообщения о Превращении/Перенаправлении.",
	["Polymorph"] = "Превращение",
	["Shackle"] = "Оковы",
	["Hibernate"] = "Спячка",
	["%s on %s removed by %s's %s"] = "%s своим %s снял %s с %s.",
	["%s on %s removed by %s"] = "%s снял %s с %s.",
	["CC on %s removed too frequently.  Throttling announcements."] = "CC на %s снемается слишком часто. Заглушать сообщения",

	["Raid Buffs"] = "Баффы рейда",
	["Paladin Buffs"] = "Баффы паладина",
	["Consumables"] = "Расходуемые",

	-- Consumables
	["Flask of Supreme Power"] = "Настой Великой силы",
	["Shattrath Flask of Mighty Restoration"] = "Шаттратская склянка Могучего восстановления",
	["Shattrath Flask of Fortification"] = "Шаттратская склянка Укрепления",
	["Shattrath Flask of Relentless Assault"] = "Шаттратская склянка Безжалостного убийства",
	["Shattrath Flask of Supreme Power"] = "Шаттратская склянка Великой силы",
	["Shattrath Flask of Pure Death"] = "Шатраттский настой Чистой смерти",
	["Shattrath Flask of Blinding Light"] = "Шатраттский настой Слепящего света",

	--Battle Elixirs
	["Fel Strength Elixir"] = "Оскверненный эликсир Силы",
	["Onslaught Elixir"] = "Эликсир натиска",
	["Elixir of Major Strength"] = "Хороший эликсир Силы",
	["Elixir of Major Agility"] = "Хороший эликсир Ловкости",
	["Elixir of Mastery"] = "Эликсир Власти",
	["Elixir of Major Firepower"] = "Хороший эликсир Огневой мощи",
	["Elixir of Major Shadow Power"] = "Хороший эликсир Силы теней",
	["Elixir of Major Frost Power"] = "Хороший эликсир Силы льда",
	["Elixir of Healing Power"] = "Эликсир Исцеления",
	["Elixir of the Mongoose"] = "Эликсир Мангуста",
	["Elixir of Greater Firepower"] = "Сильный эликсир Огневой мощи",
	["Bloodberry Elixir"] = "Эликсир из кровяники",
	--["Bloodberry Elixir"] = "",

	-- Guardian Elixirs
	["Elixir of Major Defense"] = "Хороший эликсир Защиты",
	["Elixir of Superior Defense"] = "Наилучший эликсир защиты",
	["Elixir of Major Mageblood"] = "Хороший эликсир крови волшебника",
	["Mageblood Potion"] = "Зелье крови волшебника",
	["Elixir of Greater Intellect"] = "Сильный эликсир Интеллекта",
	["Elixir of Empowerment"] = "Эликсир Полномочий",
} end)
