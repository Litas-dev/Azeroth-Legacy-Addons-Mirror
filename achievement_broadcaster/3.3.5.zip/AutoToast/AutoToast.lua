local LOOT_SELF_REGEX = gsub(LOOT_ITEM_SELF, "%%s", "(.+)")
local LOOT_REGEX = gsub(LOOT_ITEM, "%%s", "(.+)")

local TmpAchive,TmpDing,TmpLoot,Tmpilvl

local function AutoToast_ConfigClick(Which,checked)

	if (Which == "AutoToastAchive") then
		TmpAchive = checked
	elseif (Which == "AutoToastDing") then
		TmpDing = checked;
	elseif (Which == "AutoToastLoot") then
		TmpLoot = checked;
	end

end


local function CreateConfigUI()
	--[[ Create a frame to use as the panel ]] --
	local panel = CreateFrame("FRAME", "ExamplePanel");
	panel.name = "Auto Toast";


	local text = panel:CreateFontString(nil, 'ARTWORK', 'GameFontNormalLarge')
	text:SetPoint('TOPLEFT', 16, -16)
	text:SetText("Auto Toast")


	local subtext = panel:CreateFontString(nil, 'ARTWORK', 'GameFontHighlightSmall')
	subtext:SetHeight(32)
	subtext:SetPoint('TOPLEFT', text, 'BOTTOMLEFT', 0, -8)
	subtext:SetPoint('RIGHT', panel, -32, 0)
	subtext:SetNonSpaceWrap(true)
	subtext:SetJustifyH('LEFT')
	subtext:SetJustifyV('TOP')
	subtext:SetText("Alert your battle.net friends!")



	local f = CreateFrame("CheckButton","ATLoot",ExamplePanel,"UICheckButtonTemplate")
	f:SetPoint("TopLeft", ExamplePanel,16,-64);
	f:SetScript("OnClick",  function(...) AutoToast_ConfigClick("AutoToastLoot",f:GetChecked())end )
	f:Show()
	f:SetChecked(AutoToastLoot)
	ATLootText:SetText("Update status on receiving an item")


	local f = CreateFrame("CheckButton","ATDing",ExamplePanel,"UICheckButtonTemplate")
	f:SetPoint("TopLeft", ExamplePanel,16,-96);
	f:SetScript("OnClick", function(...)  AutoToast_ConfigClick("AutoToastDing",f:GetChecked())end )
	f:Show()
	f:SetChecked(AutoToastDing)
	ATDingText:SetText("Update status on leveling")

	local f = CreateFrame("CheckButton","ATAchive",ExamplePanel,"UICheckButtonTemplate")
	f:SetPoint("TopLeft", ExamplePanel,16,-128);
	f:SetScript("OnClick", function(...)  AutoToast_ConfigClick("AutoToastAchive",f:GetChecked())end )
	f:Show()
	f:SetChecked(AutoToastAchive)
	ATAchiveText:SetText("Update status on earning an achivement")

	local f = CreateFrame("EditBox","ATiLVL",ExamplePanel,"InputBoxTemplate")
	f:SetWidth(32)
	f:SetHeight(32)
	f:SetPoint("TopLeft", ExamplePanel,16,-160);
	f:SetAutoFocus(false)
	f:SetNumeric()
	f:SetMaxLetters(3)
	ATiLVL:SetNumber(AutoToastilvl)
	ATiLVL:SetCursorPosition(0)
	f:Show()

	local ATiLVLLabel = ATiLVL:CreateFontString("ATiLVLLabel", "ARTWORK", "GameFontNormal")
	ATiLVLLabel:SetPoint("left", ATiLVL, "RIGHT");
	ATiLVLLabel:SetText("Item level needed to update status")


	panel.okay =
	 function (self)
	   AutoToast_UpdateHandles()
	end

	panel.cancel =
	 function (self)
	   AutoToast_RevertHandles()
	end


	-- [[ Add the panel to the Interface Options ]] --
	InterfaceOptions_AddCategory(panel,"Auto Toast"); 
end




--This funciton will update the global variables that get saved, and register/unregister events
local function AutoToast_UpdateHandles()

	AutoToastAchive = TmpAchive
	AutoToastDing = TmpDing
	AutoToastLoot = TmpLoot
	AutoToastilvl = ATiLVL:GetNumber()

	if (AutoToastAchive) then
		AutoToastFrame:RegisterEvent("ACHIEVEMENT_EARNED");
	else
		AutoToastFrame:UnregisterEvent("ACHIEVEMENT_EARNED");
	end
		
	if (AutoToastLoot) then
		AutoToastFrame:RegisterEvent("CHAT_MSG_LOOT");
	else
		AutoToastFrame:UnregisterEvent("CHAT_MSG_LOOT");
	end
		
	if (AutoToastDing) then
		AutoToastFrame:RegisterEvent("PLAYER_LEVEL_UP");
	else
		AutoToastFrame:UnregisterEvent("PLAYER_LEVEL_UP");
	end
end

local function AutoToast_RevertHandles()
		TmpAchive = AutoToastAchive
		TmpDing = AutoToastDing
		TmpLoot = AutoToastLoot
		Tmpilvl = AutoToastilvl
end


local function AutoToast_ProcessAchivement(arg1)
		--Arg1 = achivementid
		local TempLink = GetAchievementLink(arg1)
		--BNSetCustomMessage has a max message size of 127 characters
		if (#(TempLink) > 127) then
			--print("Too long, pass one")
			--Blizzard uses the number 4294967295 to indicate that progress has been made on an achivement....GG?
			--We can try replacing 4294967295 with 1 to make the message smaller first, so that people can still click on them.
			--It seems that only the first 4294967295 is required to light up all the parts
			TempLink = string.gsub(TempLink, 4294967295, "xXXx",1)
			TempLink = string.gsub(TempLink, 4294967295, 0)
			--Put the first 4294967295 back in
			TempLink = string.gsub(TempLink,"xXXx",4294967295,1)
			--Check the length again...
			--print(TempLink)
			if (#(TempLink) > 127) then
				--print("Too long, pass two")
				--Lets take out that 4294967295...
				TempLink = string.gsub(TempLink, 4294967295, 0)
				--Check again...
				if (#(TempLink) > 127) then
					--print("Too long, pass three")
					--GRRRR, well just send the achivement name
					local _,Name = GetAchievementInfo(arg1)
					TempLink = "["..Name.."] has been completed!"
				end
				
			end
			
			
		end
		
		--print(#(TempLink))
		BNSetCustomMessage(TempLink)
end

local function AutoToast_Events(self, event, arg1, arg2, arg3, arg4, ...)
	
	if (event=="ADDON_LOADED" and arg1=="AutoToast") then
		--Setup the variables
		--print("Setting up variables")
		if (AutoToastilvl == nil) then
			AutoToastilvl = 264
			AutoToastDing = true
			AutoToastAchive = true
			AutoToastLoot = true
		end
		TmpAchive = AutoToastAchive
		TmpDing = AutoToastDing
		TmpLoot = AutoToastLoot
		Tmpilvl = AutoToastilvl
	
	
		if (AutoToastAchive) then
			AutoToastFrame:RegisterEvent("ACHIEVEMENT_EARNED");
		end
		
		if (AutoToastLoot) then
			AutoToastFrame:RegisterEvent("CHAT_MSG_LOOT");
		end
		
		if (AutoToastDing) then
			AutoToastFrame:RegisterEvent("PLAYER_LEVEL_UP");
		end
		CreateConfigUI()
	elseif (event=="ACHIEVEMENT_EARNED") then
		AutoToast_ProcessAchivement(arg1)
		
	elseif (event=="PLAYER_LEVEL_UP") then
		BNSetCustomMessage("I have just reached level "..arg1)
	elseif (event=="CHAT_MSG_LOOT") then
		local lootmsg = arg1;
		local _, _, sPlayer, itemlink = string.find(lootmsg, LOOT_REGEX)
		if not sPlayer then 
			--Then it was you who looted the item!
			_, _, itemlink = string.find(lootmsg, LOOT_SELF_REGEX) 
			if not itemlink then 
				--self:debug("No item link") 
				return 
			else
				--local _, _, itemId = string.find(itemlink, "item:(%d+):")
				
				local _, sLink, _, iLevel, _, _, _, _ = GetItemInfo(itemlink);
				if (iLevel >= AutoToastilvl) then
					BNSetCustomMessage("OMG I JUST GOT:"..itemlink);
				end
				
			end
			
		end

		
	end
end

local AutoToast = CreateFrame("Frame", "AutoToastFrame");
AutoToast:SetScript("OnEvent", AutoToast_Events);
AutoToast:RegisterEvent("ADDON_LOADED");


