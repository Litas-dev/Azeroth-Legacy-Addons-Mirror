FuBar - RaidSaveFu

Current Maintainer: jokeyrhyme (jokeyrhyme@gmail.com)
Original Author: jokeyrhyme (jokeyrhyme@gmail.com)

Keeps track of the raid IDs saved against your characters.

TO INSTALL: Put the FuBar_RaidSaveFu folder into
	\World of Warcraft\Interface\AddOns\
	
Acknowledgements:
RiciLake at lua-users.org for some ideas about leap year detection.
The Gnome Seahorse project, from whence I stole the keys icon.

