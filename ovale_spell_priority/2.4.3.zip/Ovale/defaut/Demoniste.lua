function Ovale:ChargerDefautDemoniste()
	local arbre =
	{
		[1] =
		{
			type = "condition",
			classe = "buff",
			sort = 28176, -- Gangrarmure
			expiration = 5,
			fils =
			{
				[1] =
				{
					type = "sort",
					priorite = 3,
					sort = self:GetSpellIdRangMax(28176) -- Gangrarmure
				}
			}
		},
		--[[[2] =
		{
			type = "condition",
			classe = "petPresent",
			present = true,
			fils =
			{
				[1]=
				{
					type = "condition",
					classe = "buff",
					sort = 19028,
					expiration = 0,
					fils =
					{
						[1]=
						{
							type = "sort",
							sort = 19028, -- lien spirituel
							priorite = 3
						}
					}
				}
			}
		},]]
		[2] = 
		{
			type = "condition",
			classe = "caseOn",
			case = { [1] = true }, -- malédiction de témérité
			fils = 
			{
				[1]=
				{
					type = "condition",
					classe = "debuff",
					sort = 704, -- malédiction de témérité
					expiration = 2,
					fils =
					{
						[1]=
						{
							type = "sort",
							sort = self:GetSpellIdRangMax(704),
							priorite = 3,
							nePasRepeter = true
						}
					}
				}
			}
		},
		[3] = 
		{
			type = "condition",
			classe = "caseOn",
			case = { [2] = true }, -- malédiction des éléments
			fils = 
			{
				[1]=
				{
					type = "condition",
					classe = "debuff",
					sort = 1490, -- malédiction des éléments
					expiration = 2,
					fils =
					{
						[1]=
						{
							type = "sort",
							sort = self:GetSpellIdRangMax(1490),
							priorite = 3,
							nePasRepeter = true
						}
					}
				}
			}
		},
		[4] = 
		{
			type = "condition",
			classe = "caseOn",
			case = { [3] = true }, -- malédiction funeste
			fils = 
			{
				[1]=
				{
					type = "condition",
					classe = "debuff",
					sort = 603, -- malédiction funeste
					expiration = 0,
					amoi = true,
					fils =
					{
						[1]=
						{
							type = "sort",
							sort = self:GetSpellIdRangMax(603),
							priorite = 3,
							nePasRepeter = true
						}
					}
				}
			}
		},
		[5] = 
		{
			type = "condition",
			classe = "caseOff",
			case = { [1]=true, [2] = true, [3]= true },
			fils = 
			{
				[1]=
				{
					type = "condition",
					classe = "debuff",
					sort = 980, -- malédiction d'agonie
					expiration = 0,
					amoi = true,
					fils =
					{
						[1]=
						{
							type = "sort",
							sort = self:GetSpellIdRangMax(980),
							priorite = 3,
							nePasRepeter = true
						}
					}
				}
			}
		},
		[6] =
		{
			type = "condition",
			classe = "debuff",
			sort = 18265, -- siphon de vie
			expiration = 0,
			amoi = true,
			fils =
			{
				[1]=
				{
					type = "sort",
					sort = self:GetSpellIdRangMax(18265),
					priorite = 3,
					nePasRepeter = true
				}
			}
		},
		[7] =
		{
			type = "condition",
			classe = "debuff",
			sort = 30108, -- affliction instable
			expiration = 0,
			amoi = true,
			fils =
			{
				[1]=
				{
					type = "sort",
					sort = self:GetSpellIdRangMax(30108),
					priorite = 3,
					nePasRepeter = true
				}
			}
		},
		[8] =
		{
			type = "condition",
			classe = "talent",
			talent = 1003, -- corruption améliorée
			points = 2,
			comparaison = 2,
			fils =
			{
				[1] =
				{
					type = "condition",
					classe = "debuff",
					sort = 172, -- corruption
					expiration = 0,
					amoi = true,
					fils =
					{
						[1]=
						{
							type = "sort",
							sort = self:GetSpellIdRangMax(172),
							priorite = 3,
							nePasRepeter = true
						}
					}
				}
			}
		},
		[9] =
		{
			type = "condition",
			classe = "talent",
			talent = 1670, -- on n'a pas affliction instable
			points = 1,
			comparaison = 1,
			fils =
			{
				[1] =
				{
					type = "condition",
					classe = "talent",
					talent = 944, -- on n'a pas trait de l'ombre amélioré
					points = 1,
					comparaison = 1,
					fils =
					{
						[1] =
						{
							type = "condition",
							classe = "debuff",
							sort = 348, -- immolation
							expiration = 0,
							amoi = true,
							fils =
							{
								[1]=
								{
									type = "sort",
									sort = self:GetSpellIdRangMax(348),
									priorite = 3,
									nePasRepeter = true
								}
							}
						}
					}
				}
			}
		},
		[10] =
		{
			type = "condition",
			classe = "talent",
			talent = 961, -- on a immolation améliorée
			points = 0,
			comparaison = 2,
			fils =
			{
				[1] =
				{
					type = "condition",
					classe = "debuff",
					sort = 348, -- immolation
					expiration = 0,
					amoi = true,
					fils =
					{
						[1]=
						{
							type = "sort",
							sort = self:GetSpellIdRangMax(348),
							priorite = 3,
							nePasRepeter = true
						}
					}
				}
			}
		},
		[11] =
		{
			type = "condition",
			classe = "talent",
			talent = 966, -- tempête ardente
			points = 0,
			comparaison = 2,
			fils =
			{
				[1]=
				{
					type = "sort",
					sort = self:GetSpellIdRangMax(6353), -- feu de l'âme
					priorite = 3
				}
			}
		},
		[12] =
		{
			type = "sort",
			sort = self:GetSpellIdRangMax(686), -- trait de l'ombre
			priorite = 3
		}
	}
	
		-- /script Ovale:Print(Ovale.talentNameToId["Corruption améliorée"])
	self.arbre = 
	{
		type = 'racine',
		fils =	arbre
	}
	
	
	self.casesACocher =
	{
		"Malédiction de témérité",
		"Malédiction des éléments",
		"Malédiction funeste"
	}
end
