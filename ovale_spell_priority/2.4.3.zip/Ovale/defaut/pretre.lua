function Ovale:ChargerDefautPretre()
	local arbre =
	{
		[1] =
		{
			type = "condition",
			classe = "buff",
			sort = 1243, -- Mot de pouvoir : Robustesse
			expiration = 5,
			fils =
			{
				[1] =
				{
					type = "condition",
					classe = "buff",
					sort = 21562, -- prière de robustesse
					expiration = 5,
					fils =
					{
						[1] =
						{
							type = "sort",
							priorite = 3,
							sort = self:GetSpellIdRangMax(1243) -- robustesse
						}
					}
				}
			}
		},
		[2] =
		{
			type = "condition",
			classe = "buff",
			sort = 15473,
			expiration = 0,
			fils =
			{
				[1]=
				{
					type = "sort",
					sort = 15473, -- forme d'ombre
					priorite = 3
				}
			}
		},
		[3] = 
		{
			type = "condition",
			classe = "caseOn",
			case = { [1] = true }, -- étreinte vampirique
			fils = 
			{
				[1]=
				{
					type = "condition",
					classe = "debuff",
					sort = 15286, -- étreinte vampirique
					amoi = true,
					expiration = 0,
					fils =
					{
						[1]=
						{
							type = "sort",
							sort = self:GetSpellIdRangMax(15286),
							priorite = 3,
							nePasRepeter = true
						}
					}
				}
			}
		},
		[4] =
		{
			type = "condition",
			classe = "debuff",
			sort = 34914, -- toucher vampirique
			expiration = 1,
			amoi = true,
			fils =
			{
				[1]=
				{
					type = "sort",
					sort = self:GetSpellIdRangMax(34914),
					priorite = 3,
					nePasRepeter = true
				}
			}
		},
		[5] =
		{
			type = "condition",
			classe = "debuff",
			sort = 589, -- mot de l'ombre : douleur
			expiration = 0,
			amoi = true,
			fils =
			{
				[1]=
				{
					type = "sort",
					sort = self:GetSpellIdRangMax(589),
					priorite = 3,
					nePasRepeter = true
				}
			}
		},
		[6] = 
		{
			type = "condition",
			classe = "talent",
			talent = 1181, -- Fureur divine
			points = 1,
			comparaison = 1,
			fils =
			{
				[1] =
				{
					type = "sort",
					sort = self:GetSpellIdRangMax(8092), --attaque mentale
					priorite = 3
				}
			}
		},
		[7] =
		{
			type = "condition",
			classe = "caseOn",
			case = { [2] = true }, -- Mot de l'ombre : Mort
			fils = 
			{
				[1] =
				{
					type = "condition",
					classe = "vieJoueur",
					vie = 95,
					comparaison = 2,
					fils =
					{
						[1] =
						{
							type = "sort",
							sort = self:GetSpellIdRangMax(32379),
							priorite = 3
						}
					}
				}
			}
		},
		[8] =
		{
			type = "sort",
			sort = self:GetSpellIdRangMax(15407), -- fouet mental
			priorite = 3
		},
		[9] =
		{
			type = "condition",
			classe = "debuff",
			sort = 14914, -- flammes sacrées
			expiration = 0,
			amoi = true,
			fils =
			{
				[1]=
				{
					type = "sort",
					sort = self:GetSpellIdRangMax(14914),
					priorite = 3
				}
			}
		},
		[10] =
		{
			type = "sort",
			sort = self:GetSpellIdRangMax(585), -- châtiment
			priorite = 3
		}
	}
	
		
	self.arbre = 
	{
		type = 'racine',
		fils =	arbre
	}
	
	
	self.casesACocher =
	{
		"Étreinte vampirique",
		"Mot de l'ombre : Mort"
	}
end
