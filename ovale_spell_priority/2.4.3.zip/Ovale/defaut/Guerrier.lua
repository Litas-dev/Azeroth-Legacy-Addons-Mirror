function Ovale:ChargerDefautGuerrier()
	local arbre =
	{
		[1] =
		{
			type = "condition",
			classe = "caseOff",
			case = {[3]=true}, -- cri de guerre
			fils =
			{
				[1]=
				{
					type = "condition",
					classe = "buff",
					sort = 469, -- cri de commandement
					expiration = 3,
					fils =
					{
						[1]=
						{
							type = "sort",
							sort = self:GetSpellIdRangMax(469),
							priorite = 3
						}
					}
				},
			}
		},
		[2] =
		{
			type = "condition",
			classe = "caseOn",
			case = {[3]=true}, -- cri de guerre
			fils =
			{
				[1]=
				{
					type = "condition",
					classe = "buff",
					sort = 2048, -- cri de guerre
					expiration = 3,
					fils =
					{
						[1]=
						{
							type = "sort",
							sort = self:GetSpellIdRangMax(2048),
							priorite = 3
						}
					}
				},
			}
		},
		[3]=
		{
			type = "condition",
			classe = "classification",
			classification = 3, -- world boss
			fils =
			{
				[1]=
				{
					type = "condition",
					classe = "caseOn",
					case = {[2]=true}, -- cri démoralisant
					fils =
					{
						[1] =
						{
							type = "condition",
							classe = "debuff",
							sort = 1160,
							expiration = 2,
							stacks = 0,
							fils =
							{
								[1]=
								{
									type = "sort",
									sort = self:GetSpellIdRangMax(1160), -- cri démoralisant
									priorite = 3
								}
							}
						},
					}
				}
			}
		},				
		[4] =
		{
			type = "condition",
			classe = "posture",
			forme = 2, -- défensive
			fils =
			{
				
				[1]=
				{
					type = "condition",
					classe = "classification",
					classification = 3, -- world boss
					fils =
					{
						[1] = 
						{
							type = "condition",
							classe = "debuff",
							sort = 6343,
							expiration = 2,
							stacks = 0,
							fils =
							{
								[1]=
								{
									type = "sort",
									sort = self:GetSpellIdRangMax(6343), -- coup de tonnerre
									priorite = 3
								}
							}
						},
					}
				},
				[2]=
				{
					type = "condition",
					classe = "niveau",
					difference = 1,
					comparaison = 2,
					fils = 
					{
						[1] =
						{
							type = "condition",
							classe = "cible",
							cible = true,
							fils =
							{
								[1]=
								{
									type = "sort",
									sort = 2565, -- maîtrise du blocage
									priorite = 3
								}
							}
						}
					}
				},
				[3]=
				{
					type = "condition",
					classe = "caseOn",
					case = {[1]=true}, -- multicible
					fils =
					{
						[1]=
						{
							type = "sort",
							sort = self:GetSpellIdRangMax(6343), -- coup de tonnerre
							priorite = 3
						}
					}
				},
				[4]=
				{
					type = "sort",
					sort = self:GetSpellIdRangMax(6572), -- vengeance
					priorite = 3,
					utilisable = true
				},
				[5]=
				{
					type = "sort",
					sort = self:GetSpellIdRangMax(23922), -- heurt de bouclier
					priorite = 3
				},
				[6]=
				{
					type = "condition",
					classe = "mana",
					mana = 10,
					comparaison = 2,
					fils = 
					{
						[1] =
						{
							type = "sort",
							sort = self:GetSpellIdRangMax(20243), -- dévaster
							priorite = 2
						}
					}
				}
			}
		},
		[5]=
		{
			type = "condition",
			classe = "posture",
			forme = 3, -- berserker
			fils =
			{
				[1]=
				{
					type = "condition",
					classe = "buff",
					sort = 29801, -- saccager
					expiration = 4,
					fils =
					{
						[1]=
						{
							type = "sort",
							sort = self:GetSpellIdRangMax(29801),
							priorite = 3,
							utilisable = true
						}
					}
				},
				[2]=
				{
					type ="sort",
					sort = 34428, -- ivresse de la victoire
					utilisable = true,
					priorite = 3,
				},
				[3]=
				{
					type = "condition",
					classe = "vieCible",
					comparaison = 1,
					vie = 20,
					fils =
					{
						[1] =
						{
							type = "sort",
							sort = self:GetSpellIdRangMax(5308), --exécution
							priorite = 3
						}
					}				
				},
				[4]=
				{
					type = "sort",
					sort = self:GetSpellIdRangMax(23881), -- sanguinaire
					priorite = 3
				},
				[5]=
				{
					type = "condition",
					classe = "caseOn",
					case = {[4]=true}, -- tourbillon
					fils = 
					{
						[1] =
						{
							type = "sort",
							sort = self:GetSpellIdRangMax(1680), -- tourbillon
							priorite = 3
						}
					}
				},
				[6] =
				{
					type = "sort",
					sort = self:GetSpellIdRangMax(12294), -- frappe mortelle
					priorite = 3
				},
				[7] =
				{
					type = "sort",
					sort = self:GetSpellIdRangMax(20243), -- dévaster
					priorite = 3
				},
				[8] =
				{
					type = "condition",
					classe = "talent",
					talent = 168, -- heurtoir amélioré
					points = 1,
					comparaison = 2,
					fils =
					{
						[1] =
						{
							type = "condition",
							classe = "coupBlanc",
							max = 0.2,
							fils =
							{
								[1] =
								{
									type = "sort",
									sort = self:GetSpellIdRangMax(1464), -- heurtoir
									priorite = 3
								}
							}
						}
					}
				}
			}
		},
		[6]=
		{
			type = "condition",
			classe = "mana",
			mana = 40,
			comparaison = 2,
			fils =
			{
				[1] = 
				{
					type = "condition",
					classe = "caseOn",
					case = {[1]=true}, -- multicible
					fils =
					{
						[1] =
						{
							type = "sort",
							sort = self:GetSpellIdRangMax(845), -- enchaînement
							priorite = 3
						}
					}
				},
				[2] = 
				{
					type = "condition",
					classe = "caseOff",
					case = {[1]=true}, -- multicible
					fils =
					{
						[1] =
						{
							type = "sort",
							sort = self:GetSpellIdRangMax(78), -- frappe héroïque
							priorite = 3,
							nePasRepeter = true
						}
					}
				}
			}
		},
		[7] =
		{
			type = "condition",
			classe = "debuff",
			sort = 7386,
			expiration = 2,
			stacks = 5,
			fils = 
			{
				[1]=
				{
					type = "sort",
					sort = self:GetSpellIdRangMax(7386), -- fracasser armure
					priorite = 3
				}
			}
		}
	}
	
		
	self.arbre = 
	{
		type = 'racine',
		fils =	arbre
	}
	
	
	self.casesACocher =
	{
		"Multicible",
		"Cri démoralisant",
		"Cri de guerre",
		"Tourbillon"
	}
end