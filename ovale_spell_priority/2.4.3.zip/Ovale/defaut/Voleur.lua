function Ovale:ChargerDefautVoleur()
	local arbre =
	{
		-- d�biter va expirer, on le remet d�s qu'on a un point de combo
		[1] =
		{
			type = "condition",
			classe = "buff",
			sort = 6774,
			expiration = 2,
			fils =
			{
				[1] = 
				{
					type = "condition",
					classe = "combo",
					nombre = 0,
					comparaison = 2,
					fils = 
					{
						[1]=
						{
							type = "sort",
							sort = self:GetSpellIdRangMax(6774), -- D�biter
							priorite = 3
						}
					}	
				}
			}
		},
		-- On a 5 pts de combo
		[2] = 
		{
			type = "condition",
			classe = "combo",
			nombre = 4,
			comparaison = 2,
			fils = 
			{
				-- Rupture
				[1] =
				{
					type = "condition",
					classe = "caseOn",
					case = { [1] = true }, -- Rupture
					fils = 
					{
						[1]=
						{
							type = "condition",
							classe = "debuff",
							sort = 1943, -- rupture
							amoi = true,
							expiration = 5,
							fils =
							{
						
								[1]=
								{
									type = "sort",
									sort = self:GetSpellIdRangMax(1943),
									priorite = 3
								}
							}
						}
					}
				},
				-- Evisc�ration
				[2] =
				{
					type = "sort",
					sort = self:GetSpellIdRangMax(2098),
					priorite = 3
				}
			}
		},
		-- sinon, on monte nos points de combo
		[3] =
		{
			type = "condition",
			classe = "talent",
			talent = 681, -- h�morragie
			comparaison = 2,
			points = 0,
			fils = 
			{
				[1] =
				{
					type = "sort",
					sort = self:GetSpellIdRangMax(16511),
					priorite = 3
				}
			}
		},
		[4] =
		{
			type = "sort",
			sort = self:GetSpellIdRangMax(1752),
			priorite = 3
		}
	}
		
	self.arbre = 
	{
		type = 'racine',
		fils =	arbre
	}
		
	self.casesACocher =
	{
		"Rupture"
	}

end