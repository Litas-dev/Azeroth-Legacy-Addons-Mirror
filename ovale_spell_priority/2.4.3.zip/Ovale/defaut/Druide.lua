function Ovale:ChargerDefautDruide()

	local arbre =
	{
		[1]=
		{
			type= "condition",
			classe = "posture",
			forme = 1, -- Ours
			fils =
			{
				[1] =
				{
					type = "condition",
					classe = "caseOn",
					case = { [4] = true}, -- luciole
					fils =
					{
						[1] =
						{
							type = "condition",
							classe = "debuff",
							sort = 16857,
							expiration = 2,
							fils =
							{
								[1] =
								{
									type = "sort",
									sort = self:GetSpellIdRangMax(16857), -- Luciole (farouche)
									priorite = 3
								}
							}
						}
					}
				},
				[2]=
				{
					type = "sort",
					sort = self:GetSpellIdRangMax(33878), -- Mutilation (Ours)
					priorite = 3
				},
				[3] =
				{
					type = "condition",
					classe = "caseOn",
					case = { [3] = true }, -- Rugissement démoralisant
					fils =
					{
						[1] =
						{
							type = "condition",
							classe = "debuff",
							sort = 99,
							expiration = 2,
							fils =
							{
								[1] = 
								{
									type  = "sort",
									sort = self:GetSpellIdRangMax(779), -- Balayage
									priorite = 3
								}
							}
						}
					}
				},
				[4]=
				{
					type = "condition",
					classe = "caseOn",
					case = { [1] = true }, -- Multicible
					fils =
					{
						[1] =
						{
							type  = "sort",
							sort = self:GetSpellIdRangMax(779), -- Balayage
							priorite = 3
						}
					}
				},
				[5]=
				{
					type = "condition",
					classe = "caseOn",
					case = { [2] = true }, -- Saignement
					fils =
					{
						[1] = 
						{
							type = "condition",
							classe = "mana",
							mana = 10,
							comparaison = 2,
							fils =
							{
								[1] =
								{
									type = "sort",
									sort = self:GetSpellIdRangMax(33745), -- Lacérer
									priorite = 2
								}
							}
						}
					}
				},
				[6]=
				{
					type = "condition",
					classe = "mana",
					mana = 50,
					comparaison = 2,
					fils = 
					{
						[1] =
						{
							type = "sort",
							sort = self:GetSpellIdRangMax(6807), -- Mutiler
							priorite = 3,
							nePasRepeter = true
						}
					}
				}
			}
		},
		[2] =
		{
			type= "condition",
			classe = "posture",
			forme = 3, -- chat
			fils =
			{
				[1] =
				{
					type = "condition",
					classe = "caseOn",
					case = { [4] = true}, -- luciole
					fils =
					{
						[1] =
						{
							type = "condition",
							classe = "debuff",
							sort = 16857,
							expiration = 2,
							fils =
							{
								[1] =
								{
									type = "sort",
									sort = self:GetSpellIdRangMax(16857), -- Luciole (farouche)
									priorite = 3
								}
							}
						}
					}
				},
				[2] =
				{
					type = "condition",
					classe = "combo",
					nombre = 4,
					comparaison = 2,
					fils =
					{	
						[1] =
						{
							type = "condition",
							classe = "mana",
							mana = 70,
							comparaison = 2,
							fils =
							{
								[1] =
								{
									type = "sort",
									sort = self:GetSpellIdRangMax(1079), -- Déchirure = coup de grâce
									priorite = 3
								}
							}
						}
					}
				},
				[3] =
				{
					type = "condition",
					classe = "combo",
					nombre = 5,
					comparaison = 1,
					fils =
					{
						[1] =
						{
							type = "condition",
							classe = "debuff",
							sort = 33876,
							expiration = 0,
							fils =
							{
								[1] =
								{
									type = "sort",
									sort = self:GetSpellIdRangMax(33876), -- Mutilation (félin) (augmente les dégâts de lambeau)
								}
							}
						},
						[2] =
						{
							type = "sort",
							sort = self:GetSpellIdRangMax(5221), -- lambeau +1 combo
							priorite = 3
						}
					}
				}				
			}
		},
		[3] =
		{
			type = "condition",
			classe = "mana",
			mana = 100,
			comparaison = 2,
			fils =
			{
				[1] =
				{
					type = "condition",
					classe = "caseOn",
					case = { [4] = true}, -- luciole
					fils =
					{
						[1] =
						{
							type = "condition",
							classe = "debuff",
							sort = 770,
							expiration = 2,
							fils =
							{
								[1] = 
								{
									type = "sort",
									sort = self:GetSpellIdRangMax(770),
									priorite = 3
								}
							}
						}
					}
				},
				[2] =
				{
					type = "condition",
					classe = "debuff",
					amoi = true,
					sort = 27013,
					expiration = 0,
					fils =
					{
						[1] = 
						{
							type = "sort",
							sort = self:GetSpellIdRangMax(27013), -- essaim d'insectes
							priorite = 3
						}
					}
				},
				[3] =
				{
					type = "condition",
					classe = "debuff",
					amoi = true,
					sort = 8921,
					expiration = 0,
					fils =
					{
						[1] = 
						{
							type = "sort",
							sort = self:GetSpellIdRangMax(8921), -- éclat lunaire
							priorite = 3
						}
					}
				},
				[4] =
				{
					type = "sort",
					sort = self:GetSpellIdRangMax(2912), -- feu stellaire
					priorite = 3
				},
				[5] =
				{
					type = "sort",
					sort = self:GetSpellIdRangMax(5176), -- colère
					priorite = 3
				}
			}
		}
	}
	
	self.arbre = 
	{
		type = 'racine',
		fils =	arbre
	}
	
	
	self.casesACocher =
	{
		"Multicible",
		"Saignement",
		"Rugissement démoralisant",
		"Lucioles"
	}
end

	