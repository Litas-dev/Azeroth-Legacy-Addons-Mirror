OvaleEquipement = LibStub("AceAddon-3.0"):NewAddon("OvaleEquipement", "AceEvent-3.0")

OvaleEquipement.nombre = {}
OvaleEquipement.classe = nil

function OvaleEquipement:OnEnable()
	self:RegisterEvent("UNIT_INVENTORY_CHANGED")
	local classeLoc
	classeLoc, self.classe = UnitClass("player")
end

function OvaleEquipement:OnDisable()
end

function OvaleEquipement:GetItemId(slot)
	local link = GetInventoryItemLink("player", GetInventorySlotInfo(slot))
	local a, b, itemId = string.find(link, "item:(%d+)");
	return tonumber(itemId);
end

function OvaleEquipement:UNIT_INVENTORY_CHANGED(arg1)
	if (arg1 == "player") then
		if (self.classe == "ROGUE") then
			nombre["T4"] = 0
			local tete = self:GetItemId("HeadSlot")
			if (tete == 29044) then
				nombre["T4"] = nombre["T4"] +1
			end
			local epaules = self:GetItemId("ShoulderSlot")
			if (epaules == 29047) then
				nombre["T4"] = nombre["T4"] +1
			end
			local plastron = self:GetItemId("ChestSlot")
			if (plastron == 29045) then
				nombre["T4"] = nombre["T4"] +1
			end
			local gants =  self:GetItemId("HandsSlot")
			if (gants == 29048) then
				nombre["T4"] = nombre["T4"] +1
			end
			local jambes =  self:GetItemId("LegsSlot")
			if (jambes == 29046) then
				nombre["T4"] = nombre["T4"] +1
			end
		end	
	end
end