--[[
	MiniMount
	English Localization File
	Version 1.8
]]

MINIMOUNT_TITLE = "MiniMount";
MINIMOUNT_VERSION = "Version";
MINIMOUNT_NOWLOADED = "is now loaded!";
MINIMOUNT_ERROR = "Error";
MINIMOUNT_DEBUG = "Debug Message";
MINIMOUNT_TOOLTIP = "Call a Random Mount./n/nMount selection changes according/nto location and skill.";
MINIMOUNT_NONE = "None";

MINIMOUNT_MACROCREATED = "A MiniMount Macro has been created for you! This will always update and show you the next mount that will be summoned!";

MINIMOUNT_ERROR_WRONGOPTION = "Incorrect Variables submitted. Operation Failed.";
MINIMOUNT_ERROR_LEVELNOTHIGHENOUGH = "You are not a high enough level to have a mount.";
MINIMOUNT_ERROR_SKILLNOTHIGHENOUGH = "Your riding skill isn't high enough to ride a mount.";
MINIMOUNT_ERROR_SKILLNOTHIGHENOUGHFLY = "Your riding skill isn't high enough to ride a flying mount. We are giving you an ground mount instead.";
MINIMOUNT_ERROR_ISFLYING = "You are currently flying. Please land before calling a new mount.";
MINIMOUNT_ERROR_MOUNTDATABASEEMPTY = "An error occured while generating the mount database. Operation aborted.";
MINIMOUNT_ERROR_NOFLYZONE = "You can not fly here. Aborting.";

MINIMOUNT_NOMOUNTS_ANY = "No mounts found. You might want to go learn some!";
MINIMOUNT_NOMOUNTS_USABLE = "No usable mounts found. Please try again.";
MINIMOUNT_NOMOUNTS_REGULAR = "It seems you don't have any Regular mounts. Please try again.";
MINIMOUNT_NOMOUNTS_EPIC = "It seems you don't have any Epic mounts. Please try again.";
MINIMOUNT_NOMOUNTS_FLYREGULAR = "It seems you don't have any Regular Flying mounts. Please try again.";
MINIMOUNT_NOMOUNTS_FLYEPIC = "It seems you don't have any Epic Flying mounts. Please try again.";

MINIMOUNT_UNKNOWNMOUNTSFOUND = "You have one or more mounts that are not in our database! Please send a message to the author of MiniMount, saying if the mounts are epic flyers, regular flyers, epic land mounts, or regular land mounts. Also include the following information:";
MINIMOUNT_REPORTMOUNT = "This Mount was not found: ";

--==Zones, Subzones and Instances=-
-- Zones
MINIMOUNT_ZONE_DALARAN = "Dalaran";
MINIMOUNT_ZONE_WINTERGRASP = "Wintergrasp";
MINIMOUNT_ZONE_ALTERACVALLEY = "Alterac Valley"

-- Subzones
MINIMOUNT_SUBZONE_DALARAN_KRASUSLANDING = "Krasus' Landing";
MINIMOUNT_SUBZONE_DALARAN_THEVIOLETCITADEL = "The Violet Citadel";

-- Instances
MINIMOUNT_INSTANCE_THEOCULUS = "The Oculus";

-- Raids
MINIMOUNT_RAID_THEOBSIDIANSANCTUM = "The Obsidian Sanctum";
MINIMOUNT_RAID_THEEYEOFETERNITY = "The Eye of Eternity";

--==Name Adjustment Database==--
-- This is used to fix any name problems that may result in the macro not showing the proper icon.
-- Format:
--	["Incorrect Name"] = "Correct Name",

MiniMount_NameAdjustment = {
	["Blue Drake Mount"] = "Blue Drake",
	["Bronze Drake Mount"] = "Bronze Drake",
}