--[[
	MiniMount Database
	Version 1.8
]]

MiniMount_Mounts = {
	["Slow"] = {
		"30174",	-- Riding Turtle
	},
	["Regular"] = {
		"458",		-- Brown Horse
		"470",		-- Black Stallion
		"472",		-- Pinto
		"580",		-- Timber Wolf
		"5784",		-- Felsteed (Warlock Summons)
		"6648",		-- Chestnut Mare
		"6653",		-- Dire Wolf
		"6654",		-- Brown Wolf
		"6777",		-- Gray Ram
		"6898",		-- White Ram
		"6899",		-- Brown Ram
		"8394",		-- Striped Frostsaber
		"8395",		-- Emerald Raptor
		"10789",	-- Spotted Frostsaber
		"10793",	-- Striped Nightsaber
		"10796",	-- Turquoise Raptor
		"10799",	-- Violet Raptor
		"10873",	-- Red Mechanostrider
		"10969",	-- Blue Mechanostrider
		"13819",	-- Warhorse (Alliance Paladin Summons)
		"17453",	-- Green Mechanostrider
		"17454",	-- Unpainted Mechanostrider
		"17462",	-- Red Skeletal Horse
		"17463",	-- Blue Skeletal Horse
		"17464",	-- Brown Skeletal Horse
		"18989",	-- Gray Kodo
		"18990",	-- Brown Kodo
		"34406",	-- Brown Elekk
		"34769",	-- Warhorse (Horde Paladin Summons)
		"34795",	-- Red Hawkstrider
		"35018",	-- Purple Hawkstrider
		"35020",	-- Blue Hawkstrider
		"35022",	-- Black Hawkstrider
		"35710",	-- Gray Elekk
		"35711",	-- Purple Elekk
		"42776",	-- Spectral Tiger
		"43899",	-- Brewfest Ram
		"64657",	-- White Kodo
		"64658",	-- Black Wolf
		"64659",	-- Venomhide Ravasaur (Doubled for Speed/Req diff)
		"64977",	-- Black Skeletal Horse
		"66847",	-- Striped Dawnsaber
	},
	["Epic"] = {
		"15779", 	-- White Mechanostrider Mod B
		"16055",	-- Black Nightsaber
		"16056",	-- Ancient Frostsaber
		"16080", 	-- Red Wolf
		"16081",	-- Winter Wolf
		"16082",	-- Palomino
		"16083",	-- White Stallion
		"16084",	-- Mottled Red Raptor
		"17229",	-- Winterspring Frostsaber
		"17450",	-- Ivory Raptor
		"17459",	-- Icy Blue Mechanostrider Mod A
		"17460",	-- Frost Ram
		"17461",	-- Black Ram
		"17465",	-- Green Skeletal Warhorse
		"17481",	-- Rivendare's Deathcharger
		"18991",	-- Green Kodo
		"18992",	-- Teal Kodo
		"22717",	-- Black War Steed
		"22718",	-- Black War Kodo
		"22719",	-- Black Battlestrider
		"22720",	-- Black War Ram
		"22721",	-- Black War Raptor
		"22722",	-- Red Skeletal Warhorse
		"22723",	-- Black War Tiger
		"22724",	-- Black War Wolf
		"23161",	-- Dreadsteed (Warlock Summons)
		"23214",	-- Charger (Alliance Paladin Summons)
		"23219",	-- Swift Mistsaber
		"23221",	-- Swift Frostsaber
		"23222",	-- Swift Yellow Mechanostrider
		"23223",	-- Swift White Mechanostrider
		"23225",	-- Swift Green Mechanostrider
		"23227",	-- Swift Palomino
		"23228",	-- Swift White Steed
		"23229",	-- Swift Brown Steed
		"23238",	-- Swift Brown Ram
		"23239",	-- Swift Gray Ram
		"23240",	-- Swift White Ram
		"23241",	-- Swift Blue Raptor
		"23242",	-- Swift Olive Raptor
		"23243",	-- Swift Orange Raptor
		"23246",	-- Purple Skeletal Warhorse
		"23247",	-- Great White Kodo
		"23248", 	-- Great Gray Kodo
		"23249", 	-- Great Brown Kodo
		"23250",	-- Swift Brown Wolf
		"23251",	-- Swift Timber Wolf
		"23252",	-- Swift Gray Wolf
		"23338",	-- Swift Stormsaber
		"23509",	-- Frostwolf Howler
		"23510",	-- Stormpike Battle Charger
		"24242",	-- Swift Razzashi Raptor
		"24252",	-- Swift Zulian Tiger
		"26656",	-- Black Qiraji Battle Tank
		"33660",	-- Swift Pink Hawkstrider
		"34767",	-- Charger (Horde Paladin Summons)
		"34790",	-- Dark War Talbuk
		"34896",	-- Cobalt War Talbuk
		"34897",	-- White War Talbuk
		"34898",	-- Silver War Talbuk
		"34899",	-- Tan War Talbuk
		"35025",	-- Swift Green Hawkstrider
		"35027",	-- Swift Purple Hawkstrider
		"35028",	-- Swift Warstrider
		"35712",	-- Great Green Elekk
		"35713",	-- Great Blue Elekk
		"35714",	-- Great Purple Elekk
		"36702", 	-- Firey Warhorse
		"39315",	-- Cobalt Riding Talbuk
		"39316",	-- Dark Riding Talbuk
		"39317",	-- Silver Riding Talbuk
		"39318",	-- Tan Riding Talbuk
		"39319",	-- White Riding Talbuk
		"41252",	-- Raven Lord
		"42777",	-- Swift Spectral Tiger
		"43688",	-- Amani War Bear
		"43900",	-- Swift Brewfest Ram
		"46628",	-- Swift White Hawkstrider
		"48027",	-- Black War Elekk
		"48778",	-- Acherus Deathcharger (Death Knight Mount)
		"49322",	-- Swift Zhevra
		"49379", 	-- Great Brewfest Kodo
		"51412",	-- Big Battle Bear
		"54753",	-- White Polar Bear Mount
		"55531",	-- Mechano-hog (Horde Motorcycle)
		"59785",	-- Black War Mammoth (Alliance)
		"59788",	-- Black War Mammoth (Horde)
		"59791",	-- Wooly Mammoth (Alliance)
		"59793",	-- Wooly Mammoth (Horde)
		"59797",	-- Ice Mammoth (Horde)
		"59799",	-- Ice Mammoth (Alliance)
		"60114",	-- Armored Brown Bear (Alliance)
		"60116",	-- Armored Brown Bear (Horde)
		"60118",	-- Black War Bear (Alliance)
		"60119",	-- Black War Bear (Horde)
		"60424", 	-- Mekgineer's Chopper (Alliance Motorcycle)
		"61425",	-- Traveler's Tundra Mammoth (Alliance)
		"61447",	-- Traveler's Tundra Mammoth (Horde)
		"61465",	-- Grand Black War Mammoth (Alliance)
		"61467",	-- Grand Black War Mammoth (Horde)
		"61469",	-- Grand Ice Mammoth (Horde)
		"61470",	-- Grand Ice Mammoth (Alliance)
		"63232",	-- Stormwind Steed
		"63635",	-- Darkspear Raptor
		"63636",	-- Ironforge Ram
		"63637",	-- Darnassian Nightsaber
		"63638",	-- Gnomeregan Mechanostrider
		"63639",	-- Exodar Elekk
		"63640",	-- Orgrimmar Wolf
		"63641",	-- Thunder Bluff Kodo
		"63642",	-- Silvermoon Hawkstrider
		"63643",	-- Forsaken Warhorse
		"64656",	-- Blue Skeletal Warhorse
		"64657",	-- White Kodo
		"64659",	-- Venomhide Ravasaur (Doubled for Speed/Req diff)
		"65637",	-- Great Red Elekk
		"65638",	-- Swift Moonsaber
		"65639",	-- Swift Red Hawkstrider
		"65640",	-- Swift Gray Steed
		"65641",	-- Great Golden Kodo
		"65642", 	-- Turbostrider
		"65643",	-- Swift Violet Ram
		"65644",	-- Swift Purple Raptor
		"65645",	-- White Skeletal Warhorse
		"65646",	-- Swift Burgundy Wolf
		"65917",	-- Magic Rooster
		"66090",	-- Quel'dorei Steed
		"66091",	-- Sunreaver Hawkstrider
		"66122",	-- Magic Rooster
		"66123",	-- Magic Rooster
		"66124",	-- Magic Rooster
		"66846",	-- Ochre Skeletal Warhorse
		"66906",	-- Argent Charger (Paladin)
		"66907",	-- Argent Warhorse (Paladin)
		"67466",	-- Argent Warhorse
		"68056",	-- Swift Horde Wolf
		"68057",	-- Swift Alliance Steed
		"68187",	-- Crusader's White Warhorse
		"68188",	-- Crusader's Black Warhorse
		"73313",	-- Crimson Deathcharger
		"74918",	-- Wooly White Rhino
	},
	["FlyRegular"] = {
		"32235",	-- Golden Gryphon
		"32239",	-- Ebon Gryphon
		"32240",	-- Snowy Gryphon
		"32243",	-- Tawny Wind Rider
		"32244",	-- Blue Wind Rider
		"32245",	-- Green Wind Rider
		"44153",	-- Flying Machine
		"46197",	-- X-51 Nether-Rocket
		"61451",	-- Flying Carpet
	},
	["FlyEpic"] = {
		"32242",	-- Swift Blue Gryphon
		"32246",	-- Swift Red Wind Rider
		"32289",	-- Swift Red Gryphon
		"32290",	-- Swift Green Gryphon
		"32292",	-- Swift Purple Gryphon
		"32295",	-- Swift Green Wind Rider
		"32296",	-- Swift Yellow Wind Rider
		"32297",	-- Swift Purple Wind Rider
		"39798",	-- Green Riding Nether Ray
		"39800",	-- Red Riding Nether Ray
		"39801",	-- Purple Riding Nether Ray
		"39802",	-- Silver Riding Nether Ray
		"39803",	-- Blue Riding Nether Ray
		"41513",	-- Onyx Netherwing Drake
		"41514",	-- Azure Netherwing Drake
		"41515",	-- Cobalt Netherwing Drake
		"41516",	-- Purple Netherwing Drake
		"41517",	-- Veridian Netherwing Drake
		"41518",	-- Violet Netherwing Drake
		"43927",	-- Cenarion War Hippogryph
		"44151",	-- Turbo-Charged Flying Machine
		"44744",	-- Merciless Nether Drake
		"46199",	-- X-51 Nether-Rocket X-TREME
		"49193",	-- Vengeful Nether Drake
		"58615",	-- Brutal Nether Drake
		"59567",	-- Azure Drake
		"59568",	-- Blue Drake
		"59569",	-- Bronze Drake
		"59570",	-- Red Drake
		"59571",	-- Twilight Drake Mount
		"59650",	-- Black Drake
		"59961",	-- Red Proto-Drake
		"59996",	-- Blue Proto-Drake
		"60002",	-- Time-Lost Proto-Drake
		"60025",	-- Albino Drake
		"60975",	-- Swift Ebonweave Carpet
		"61229",	-- Armored Snowy Gryphon
		"61230",	-- Armored Blue Wind Rider
		"61294",	-- Green Proto-Drake
		"61309",	-- Magnificent Flying Carpet
		"61996",	-- Blue Dragonhawk
		"61997",	-- Red Dragonhawk
		"62048",	-- Black Dragonhawk Mount
		"63844",	-- Argent Hippogryph
		"63796",	-- Mimiron's Head
		"66087",	-- Silver Covenant Hippogryph
		"66088",	-- Sunreaver Dragonhawk
		"75596",	-- Frosty Flying Carpet
	},
	["FlyEpicFast"] = {
		"37015",	-- Swift Nether Drake
		"40192",	-- Ashes of Al'ar
		"59976",	-- Black Proto-Drake
		"60021",	-- Plagued Proto-Drake
		"60024",	-- Violet Proto-Drake
		"63796",	-- Mimiron's Head
		"63956",	-- Ironbound Proto-Drake
		"63963",	-- Rusted Proto-Drake
		"64927",	-- Deadly Gladiator's Frost Wyrm
		"65439",	-- Furious Gladiator's Frost Wyrm
		"67336",	-- Relentless Gladiator's Frost Wyrm
		"69395",	-- Onyxian Drake
		"71810",	-- Wrathful Gladiator's Frost Wyrm
		"72807",	-- Icebound Frostbrood Vanquisher
		"72808",	-- Bloodbathed Frostbrood Vanquisher
	},
	-- Ground Only Shifting Mounts
	["Shifting"] = {
		"58983",	-- Big Blizzard Bear
	},
	-- Flying Only Shifting Mounts
	["FlyShifting"] = {
		"54729",	-- Winged Steed of the Ebon Blade (Death Knight Flying Mount)
		"75973",	-- X-53 Touring Rocket
	},
	-- Shifting Mounts that can be anything!
	["FullShifting"] = {
		"48025",	-- Headless Horseman's Mount
		"71342",	-- Big Love Rocket
		"72286",	-- Invincible
		"74856",	-- Blazing Hippogryph
		"75614",	-- Celestial Steed
	},
	-- Regular-Swimming-Speed Mounts
	["SwimRegular"] = {
		"64731",	-- Sea Turtle
	}
}

-- For mounts that are Zone-Specific
MiniMount_MountZones = {
	-- Regular Speed Mounts
	["Ahn'Qiraj"] = {
		["Regular"] = {
			"25953",	-- Blue Qiraji Battle Tank
			"26054",	-- Red Qiraji Battle Tank
			"26055",	-- Yellow Qiraji Battle Tank
			"26056",	-- Green Qiraji Battle Tank
		},
		["Epic"] = {
			-- The AQ mounts are listed twice, because they require the Regular mount training, but are of Epic speed.
			"25953",	-- Blue Qiraji Battle Tank
			"26054",	-- Red Qiraji Battle Tank
			"26055",	-- Yellow Qiraji Battle Tank
			"26056",	-- Green Qiraji Battle Tank
		},
	}
}