function MiniMount_Mount_Hook()
	-- hook some of the functions we need to track.
	hooksecurefunc("PetPaperDollFrame_SetTab",MiniMount_Mount_SetTab);
end

function MiniMount_Mount_SetTab(id)
	if ((id == 3) and (GetNumCompanions("MOUNT") > 0)) then
		MiniMount_Mount_PerferedFlyCheckButton:Show();
		MiniMount_Mount_PerferedGroundCheckButton:Show();
	else
		MiniMount_Mount_PerferedFlyCheckButton:Hide();
		MiniMount_Mount_PerferedGroundCheckButton:Hide();
	end
end