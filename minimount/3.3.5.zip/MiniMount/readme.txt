MiniMount v1.8

A simple addon to choose a random mount, based on location and skill.

-= Command-line List =-
/minimount
/mount
/mm
	(No Further Commands) = Automatically choose your highest level mounts, and randomly choose one.
	new or newmount or new mount = Choose a new mount for your next mount.
	reg or regular = Choose only non-epic ground mounts.
	epic = Choose only epic ground mounts.
	ground = Choose the best ground-only mount you can.
	fly = Choose only random flying mounts.
	fly reg or fly regular = Choose only slow-flying mounts.
	fly epic = Choose only epic flying mounts.
	fly epic fast = Choose only 310% epic flying mounts.
	random = Choose a totally random mount from any of the mounts you have.

-= Update History =-
v1.8
 - Updated for 3.3.5!
 - Reworked the flying detection method. You can now fly from the top of the Violet Citadel, and use a ground mount at the bottom!
 - Added several new and forgetten mounts, including the Celestrial Steed!
 - Mounts that change flying speed will now show up with your other fast epic flying mounts!
 - The MiniMount Macro now supports the Dragon Essences in The Oculus!
 - Fixed a bug with the Blue Drake and the MiniMount Macro.
 - Added German Localization! Thanks eNBeWe!

v1.7.1
 - Minor Bugfixes

v1.7.0
 - Added several new/forgotten mounts to the Database, including the new Onyxian Mount!
 - 310% speed Mounts are now in a new Fast Epic Flying category!
 - Fixed the AQ bug where it shows up in the rotation, however, I had to disable the AQ mounts for the time being.
 - MiniMount will now only complain about a lack of mounts when it's called, not when the macro wants to change.

v1.6.8
 - MiniMount will now work properly if you are in Wintergrasp during it's combat phase.

v1.6.7b
 - Fixed a bug that wouldn't let toons fly in Northrend if they had Northrend Flying, but were not yet level 77.

v1.6.7a
 - MiniMount's Command-line options will now accept Macro Conditionals!
 - Fixed a bug in the new macro that wouldn't display the proper mount when updated.

v1.6.7
 - Updated for Patch 3.2
 - Added the new 3.2 mounts to the Database.
 - Removed Wintergrasp's Flying restriction.
 - Added the "New" commandline to cycle through next mounts.
 - You can now Middle-Click the macro to choose a different next mount!
 - Fixed a bug that wouldn't generate an options database.
 - Fixed a bug where if you don't have mounts to match your riding skill, MiniMount will choose the next available mount.

v1.6.6
 - Fixed a bug that would occasionally give people an error upon logging in.

v1.6.5
 - Updated TOC for 3.1
 - Added a multitude of new mounts to the database.
 - Removed the swimming error.
 - Added a localized Name Adjustment Database for mis-named mounts. This will correct the mount names so the macro correctly shows which mount is next.
 - Added the Bronze Drake to the English Name Adjustment Database.
 - Fixed a bug that would refresh the macro far more often than it should of done.

v1.6
 - Added several new mounts to the Database.
 - The Obsidian Sanctum and Eye of Eternity is now on the No-Fly Zone list.
 - You can now mount your flying mount at the top of the Violet Citadel.
 - Druids & Shamans Rejoice! The MiniMount Macro will now cancel shapeshift forms!
 - Changed the "Detect New Mount" function. It should now only run when you learn a new mount.
 - MiniMount will no longer attempt to run if you are not yet level 30.
 - Fixed a bug that wouldn't make it so the options wouldn't update.
 - Moved the Options to a Per-Character Database, as all options would be specific to the characters.
 - Fixed a bug that would sometimes report an error when first logging into WoW.
 - Fixed a bug that would spew an error if you only had shifting mounts.
 - Known Bug: AQ Mounts will occaisionally get thrown into the mount rotation.

v1.5b
 - Added The Occulus to the No-Fly Zone list.
 - Added White Polar Bear Mount to the Database.
 - Fixed a bug that would break MiniMount if it detected a Death Knight's flyer, until you reloaded the UI.
 - Fixed a bug that generated an error when entering Krasus' Landing if you could fly, but didn't have Northrend Flying.

v1.5a
 - Added Wintergrasp as a No-Fly zone.
 - Added the Armored Snowy Gryphon to the database.
 - Fixed a bug that would screw things up if you could fly in Northrend.
 - Fixed the mount function so that unknown mounts WILL be added to the mount list, as was originally intended.

v1.5
 - MiniMount now knows if you've gotten your Northrend Flying training or not!
 - Added a "Ground" function to the MiniMount_Mount function. This will select the appropriate ground mount for you.
 - Moved the Winged Steed of the Ebon Blade to the proper Shifting group, since this mount scales with a Death Knight's Riding Skill.
 - The Swimming Error is now properly named in the localization file.
 - You can now right-click the macro to dismount. You must hold down the ctrl button to dismount in the air. Holding down ctrl when pressing the button will always dismount you.
 - Minimount will now update when changing continents.
 - The Macro will now auto-update with the proper mounts when logging on a toon.
 - Added "No Fly Zones", allowing MiniMount to call up a new mount if you've entered an area that may or may not support flying. (Most of Dalaran, for example.) This needs to be localized for non-English clients!
 - Cleaned up some internal code to make things easier on everyone.

v1.4b
 - Major bugfixes involving multiple toons & the new macro.

v1.4a
 - Fixed a bug that would occur if you had no mounts.

v1.4
 - MiniMount will no longer attempt to run if you are swimming.
 - Added Riding Skill name localization for every locale. This should enable MiniMount to work with any client. (If it does not work with your client, send me the proper name for the Riding skill.)
 - Added the DeathKnight Mount to the database.
 - MiniMount will now create a mounting macro for you! This macro (called "MiniMount") will automagically update to show you which mount you will have next!

v1.3
 - Added the Ahn'Qiraj mounts to a special database. These mounts will only show up in the rotation while in AQ40.
 - Added a feature that will record which mounts are reported as Unknown Mounts, so you won't get spammed by the message everytime you mount.
 - Fixed a bug that would occur if you specifically called for a mount-type you didn't have any mounts of.
 - MiniMount will now auto-update itself when you learn new mounts. (Note: This may also occur when learning non-combat pets.)

v1.2a
 - Bugfix for previous release.

v1.2
 - Added Paladin & Warlock Mounts to the Database.
 - Fixed a bug in the Scaling Mount code that wouldn't add it to the Mount Arrays.

v1.1
 - Fixed a bug that would result in an error, not letting you mount.
 - Added extra redundancies, to either mount you, or give you an error on similar problems.

v1.0
 - Initial Release
 - Partial WotLK support