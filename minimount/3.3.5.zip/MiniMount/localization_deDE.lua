--[[
	MiniMount
	German Localization File
	Version 1.8
]]

if (GetLocale() == "deDE") then

MINIMOUNT_TITLE = "MiniMount";
MINIMOUNT_VERSION = "Version";
MINIMOUNT_NOWLOADED = "wurde geladen!";
MINIMOUNT_ERROR = "Fehler";
MINIMOUNT_DEBUG = "Fehlermeldung";
MINIMOUNT_TOOLTIP = "Ruft ein zuf�lliges Reittier./n/nDas Reittier wird anhand der/nPosition und Reitf�higkeit ausgew�hlt.";
MINIMOUNT_NONE = "Keins";

MINIMOUNT_MACROCREATED = "Ein MiniMount Makro wurde erstellt! Das Makro wird automatisch aktualisiert und zeigt das n�chste Reittier an, das gerufen wird.";

MINIMOUNT_ERROR_WRONGOPTION = "Fehlerhafte Variablns �bertragen. Operation fehlgeschlagen.";
MINIMOUNT_ERROR_LEVELNOTHIGHENOUGH = "Dein Level ist nicht hoch genug um ein Reittier zu besitzen.";
MINIMOUNT_ERROR_SKILLNOTHIGHENOUGH = "Deine Reitf�higkeit ist nicht hoch genug um reiten zu k�nnen.";
MINIMOUNT_ERROR_SKILLNOTHIGHENOUGHFLY = "Deine Reitf�higkeit ist nicht hoch genug um ein Flugreittier reiten zu k�nnen. Es wird ein normales Reittier statt dessen gerufen.";
MINIMOUNT_ERROR_ISFLYING = "Du fliegst. Bitte lande bevor du ein neues Reittier rufst.";
MINIMOUNT_ERROR_MOUNTDATABASEEMPTY = "Bei der Erstellung der Reittier-Datenbank ist ein Fehler aufgetreten. Operation abgebrochen.";
MINIMOUNT_ERROR_NOFLYZONE = "Du kannst hier nicht fliegen. Breche ab.";

MINIMOUNT_NOMOUNTS_ANY = "Keine Reittiere gefunden. Geh und kauf dir ein Reittier!";
MINIMOUNT_NOMOUNTS_USABLE = "Kein benutzbares Reittier gefunden. Bitte versuche es erneut.";
MINIMOUNT_NOMOUNTS_REGULAR = "Anscheinend hast du kein normales Reittier. Bitte versuche es erneut.";
MINIMOUNT_NOMOUNTS_EPIC = "Anscheinend hast du kein episches Reittier. Bitte versuche es erneut.";
MINIMOUNT_NOMOUNTS_FLYREGULAR = "Anscheinend hast du kein normales Flugtier. Bitte versuche es erneut.";
MINIMOUNT_NOMOUNTS_FLYEPIC = "Anscheinend hast du kein episches Flugtier. Bitte versuche es erneut.";

MINIMOUNT_UNKNOWNMOUNTSFOUND = "Du besitzt ein oder mehrere Reittiere die nicht in der Datenbank vorhanden sind. Bitte informiere den Autor von MiniMount und teile ihm mit ob es sich um ein episches Flugtier, ein normales Flugtier, ein episches Reittier oder ein normales Reittier handelt. Bitte gib auch die folgenden Informationen an:";
MINIMOUNT_REPORTMOUNT = "Dieses Reittier wurde gefunden: ";

--==Zones, Subzones and Instances=-
-- Zones
MINIMOUNT_ZONE_DALARAN = "Dalaran";
MINIMOUNT_ZONE_WINTERGRASP = "Tausendwintersee";
MINIMOUNT_ZONE_ALTERACVALLEY = "Alteractal"

-- Subzones
MINIMOUNT_SUBZONE_DALARAN_KRASUSLANDING = "Krasus' Landeplatz";
MINIMOUNT_SUBZONE_DALARAN_THEVIOLETCITADEL = "Die Violette Zitadelle";

-- Instances
MINIMOUNT_INSTANCE_THEOCULUS = "Der Oculus";

-- Raids
MINIMOUNT_RAID_THEOBSIDIANSANCTUM = "Das Obsidiansanktum";
MINIMOUNT_RAID_THEEYEOFETERNITY = "Das Auge der Ewigkeit";

--==Name Adjustment Database==--
-- This is used to fix any name problems that may result in the macro not showing the proper icon.
-- Format:
--	["Incorrect Name"] = "Correct Name",

MiniMount_NameAdjustment = {
	["Bronzefarbener Reitdrache"] = "Bronzedrache",
}

end