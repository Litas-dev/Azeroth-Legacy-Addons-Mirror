if not Watcher then return end

if select(2, UnitClass('player')) ~= "PRIEST" then return end

local LBF = LibStub("LibButtonFacade", true)
local L = LibStub("AceLocale-3.0"):GetLocale("Watcher")
local media = LibStub:GetLibrary("LibSharedMedia-3.0");
local C = Watcher.constants

C["Mind Blast"], _,C["Mind Blast Icon"] = GetSpellInfo(48127)
C["Mind Flay"], _,C["Mind Flay Icon"] = GetSpellInfo(48156)
C["Vampiric Touch"], _,C["Vampiric Touch Icon"] = GetSpellInfo(48160)
C["Devouring Plague"], _,C["Devouring Plague Icon"] = GetSpellInfo(48300)
C["Shadow Word: Pain"], _,C["Shadow Word: Pain Icon"] = GetSpellInfo(48125)


--FrameName, optionnum, typedot, dotfunction, typeShortDot, shortDotTime, usehealthpc, SpellName, powerthreshold, countreq, dotthreshold, combocost, isproc, findcount
function Watcher:addClassSpells()
Watcher:MindBlast()
Watcher:MindFlay()
Watcher:DevouringPlague()
Watcher:VampiricTouch()
Watcher:SWP()

end

function Watcher:MindBlast()
		local def = Watcher.defaults.char.spell
	def.spellname[C["Mind Blast"]] = C["Mind Blast"]
	def.name[C["Mind Blast"]] = C["Mind Blast"]
	def.icon[C["Mind Blast"]] =  C["Mind Blast Icon"]
	def.stockspell[C["Mind Blast"]] = true
end

function Watcher:MindFlay()
	local def = Watcher.defaults.char.spell
	local name = "Mind Flay"
	def.spellname[C[name]] = C[name]
	def.name[C[name]] = C[name]
	def.icon[C[name]] =  C[name.." Icon"]
	def.stockspell[C[name]] = true
end	
function Watcher:DevouringPlague()
	local def = Watcher.defaults.char.spell
	local name = "Devouring Plague"
	def.spellname[C[name]] = C[name]
	def.name[C[name]] = C[name]
	def.icon[C[name]] =  C[name.." Icon"]
	def.typedot[C[name]] = true
	def.trackspell[C[name]] = C[name]
	def.stockspell[C[name]] = true
end	

function Watcher:VampiricTouch()
	local def = Watcher.defaults.char.spell
	local name = "Vampiric Touch"
	def.spellname[C[name]] = C[name]
	def.name[C[name]] = C[name]
	def.icon[C[name]] =  C[name.." Icon"]
	def.typedot[C[name]] = true
	def.trackspell[C[name]] = C[name]
	def.stockspell[C[name]] = true
end	

function Watcher:SWP()
	local def = Watcher.defaults.char.spell
	local name = "Shadow Word: Pain"
	def.spellname[C[name]] = C[name]
	def.name[C[name]] = C[name]
	def.icon[C[name]] =  C[name.." Icon"]
	def.typedot[C[name]] = true
	def.trackspell[C[name]] = C[name]
	def.stockspell[C[name]] = true
end	