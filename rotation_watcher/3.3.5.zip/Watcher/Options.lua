if not Watcher then return end

local L = LibStub("AceLocale-3.0"):GetLocale("Watcher")
local media = LibStub:GetLibrary("LibSharedMedia-3.0");
local C = Watcher.constants -- Defined in Watcher LUA no locale needed.

Watcher.fonteffects = {
	["none"] = L["None"],
	["OUTLINE"] = L["OUTLINE"],
	["THICKOUTLINE"] = L["THICKOUTLINE"],
	["MONOCHROME"] = L["MONOCHROME"],
}

function Watcher:SetOptions()
		local AceConfigDialog = LibStub("AceConfigDialog-3.0")
		LibStub("AceConfig-3.0"):RegisterOptionsTable("Watcher", self:GetOptions())
		
		self.optionsFrame = AceConfigDialog:AddToBlizOptions("Watcher","Watcher")
		LibStub("AceConfig-3.0"):RegisterOptionsTable("Watcher CMD", self:getCmdLineTable(), {"watcher", "Watcher", "wa"})
		--self:addClassSpells()
		LibStub("AceConfig-3.0"):RegisterOptionsTable("Watcher SS", self:SpellOptions())
		self.optionsFrame["Spells"] = AceConfigDialog:AddToBlizOptions("Watcher SS","Spell Settings", "Watcher")
		LibStub("AceConfig-3.0"):RegisterOptionsTable("Watcher DS", self:DisplayOptions())
		self.optionsFrame["Display"] = AceConfigDialog:AddToBlizOptions("Watcher DS","Display Settings", "Watcher")
		LibStub("AceConfig-3.0"):RegisterOptionsTable("Watcher S1", self:spec1Options())
		self.optionsFrame["S1"] = AceConfigDialog:AddToBlizOptions("Watcher S1","Primary Spec Settings", "Watcher")
		LibStub("AceConfig-3.0"):RegisterOptionsTable("Watcher S2", self:spec2Options())
		self.optionsFrame["S2"] = AceConfigDialog:AddToBlizOptions("Watcher S2","Secondary Spec Settings", "Watcher")
		self.optionsFrame[L["About"]] = LibStub("LibAboutPanel").new("Watcher", "Watcher")
		
		
end


function Watcher:addTime()
	local indices = self.db.char.indices
	tinsert(indices, newValue)
	sort(indices)
end

function Watcher:wipeTime()
	local indices = self.db.char.indices
	table.wipe(self.db.char.indices)
	indices = {0, 1.5}
end

local function deepcopy(object)
	local lookup_table = {}
	local function _copy(object)
		if type(object) ~= "table" then
			return object
		elseif lookup_table[object] then
			return lookup_table[object]
		end
		local new_table = {}
		lookup_table[object] = new_table
		for index, value in pairs(object) do
			new_table[_copy(index)] = _copy(value)
		end
		return setmetatable(new_table, getmetatable(object))
	end
	return _copy(object)
end


local options
function Watcher:GetOptions()
	options = { 
		name = "Watcher",
		handler = Watcher,
		type='group',
		childGroups ='tree',
		args = {
			
		enable = {
				type = 'toggle',
				name = L["Enable"],
				desc = L["help_enable"],
				get = "EnableQuery",
				set = "ActivateEnable",
				order = 10,
			},			
			moveframes = {
				type = 'toggle',
				name = L["Move Frames"],
				desc = L["help_display"],
				get = "BarShowQuery",
				set = "ShowHideFrame",
				order = 10,
			},
			config = {
				type = 'execute',
				guiHidden = true,
				name = L["Configure Options"],
				desc = L["help_config"],
				func = "OpenConfig",
				order = 13,
			},
			version = {
				type = 'execute',
				name = L["Version"],
				desc = L["help_version"],
				func = "DisplayVersion",
				order = 15,
			},
			help = {
				type = 'description',
				name = L["help"],
				guiHidden = true,
				order = 16,
			},
			reset = {
				type = 'execute',
				name = L["Reset"],
				desc = L["help_reset_priority"],
				func = "ResetPriority",
				order = 36,
					},
			},
		
	}
	return options
end

local cmdline




function Watcher:SpellOptions()
	cmdline.args.spell = 
	{
		name = L["Spell Settings"],
		type = 'group',
		childGroups = 'select',
		handler = Watcher,
		order = 1, 
		args = {
			addspell = {
				name = "Add Spell",
				type = 'input',
				set = 'AddSpell',
				order = 1,
			},
	},
	}
	

	local spell = self.db.char.spell
		local num = 1
		for i,v in pairs(self.db.char.spell.name) do
		num = num + 1	
		--self:Print(i,v, self.db.char.spell.spellname[i])
		cmdline.args.spell.args["spell"..i] = {
							
								type = 'group',
							
								name = self.db.char.spell.name[i],
								order = num,
								args = {
									name = {
										type = 'input',
										name = "Set Name(Identifier)",
										get = function() return self.db.char.spell.name[i] end,
										set = function(info, newValue) 
										self.db.char.spell.name[i] = newValue
										self:CreatePriorityFrame()
										LibStub("AceConfig-3.0"):RegisterOptionsTable("Watcher SS", self:SpellOptions())
										end,
										order = 1,
										},
									spell = {
										type = 'input',
										name = "Set Spell",
										get = function() return self.db.char.spell.spellname[i] end,
										set = function(info, newValue) 
										self.db.char.spell.spellname[i], self.cd.char.spell.icon[i] = GetSpellInfo(newValue)
										--self:CreatePriorityFrame()
										LibStub("AceConfig-3.0"):RegisterOptionsTable("Watcher SS", self:SpellOptions())
										end,
										order = 2,
										},
									
									aura = {
										type = 'header',
										name = "Aura Settings",
										order = 3,
									
									},
									isdot = {
										type = 'toggle',
										name = "Is Aura",
										get = function() return self.db.char.spell.typedot[i] end,
										set = function() self.db.char.spell.typedot[i] = not self.db.char.spell.typedot[i]
										--self:CreatePriorityFrame()
										end	,
										order = 4,
									},
									isbuff = {
										type = 'toggle',
										name = "Aura exists on player, not target",
										desc = "Is a buff as opposed to debuff (default)",
										get = function() return self.db.char.spell.isbuff[i] end,
										set = function() self.db.char.spell.isbuff[i] = not self.db.char.spell.isbuff[i]
										--self:CreatePriorityFrame()
										end	,
										order = 5,
									},
									isproc = {
										type = 'toggle',
										name = "Show Spell only when Aura exists",
										get = function() return self.db.char.spell.isproc[i] end,
										set = function() self.db.char.spell.isproc[i] = not self.db.char.spell.isproc[i]
										--self:CreatePriorityFrame()
										end,
										order = 6,
									},	
									shortdot = {
										type = 'toggle',
										name = "Dot has a short length",
										desc = "Ideal for dots like explosive shot, leave unchecked otherwise",
										get = function() return self.db.char.spell.typeshortdot[i] end,
										set = function() 
										self.db.char.spell.typeshortdot[i] = not self.db.char.spell.typeshortdot[i]
										self.db.char.spell.typedot[i] = false
										--self:CreatePriorityFrame()
										end	,
										order = 8,
									},
									trackspell = {
										type = 'input',
										name = "Name of Aura to track",
										get = function() return self.db.char.spell.trackspell[i] end,
										set = function(info, newValue) 
										self.db.char.spell.trackspell[i] = newValue
										--self:CreatePriorityFrame()
										end,
										order = 6,
										},
									
									nocd = {
										type = 'toggle',
										name = "Aura has no Expiration time",
										desc = "A Hunter's aspects are an example of this",
										get = function() return self.db.char.spell.nocd[i] end,
										set = function() self.db.char.spell.nocd[i] = not self.db.char.spell.nocd[i]
										--self:CreatePriorityFrame()
										end	,
										order = 7,
									},	
									shortlen = {
										type = 'range',
										name = "Time Length for a Short Length DOT",
										desc = "e.g. 2 for Explosive Short",
										get = function() return self.db.char.spell.dotlength[i] end,
										set = function(info, newValue) 
										self.db.char.spell.dotlength[i] = newValue
										--self:CreatePriorityFrame()
										end,
										min = 0,
										max = 6,
										step = 0.5,
										order = 8,
										},
										
									dotthreshold = {
										type = 'range',
										name = "Adjust Time from Dot threshold",
										desc = "When based on the timing of the aura should the spell be used again (usually 0)",
										get = function() return self.db.char.spell.dotthreshold[i] end,
										set = function(info, newValue) 
										self.db.char.spell.dotthreshold[i] = newValue
										--self:CreatePriorityFrame()
										end,
										min = 0,
										max = 9,
										step = 1.5,
										order = 9,
									},
									countreq = {
										type = 'range',
										name = "Number of stacks of Aura required for max dps",
										get = function() return self.db.char.spell.countreq[i] end,
										set = function(info, newValue) 
										self.db.char.spell.countreq[i] = newValue
										--self:CreatePriorityFrame()
										end,
										min = 1,
										max = 10,
										step = 1,
										order = 9,
										},
									
									caster = {
										type = 'toggle',
										name = "Only track player's auras on the target",
										get = function() return self.db.char.spell.caster[i] end,
										set = function() self.db.char.spell.caster[i] = not self.db.char.spell.caster[i]
										--self:CreatePriorityFrame()
										end	,
										order = 9,
									},
									header = {
										type = 'header',
										name = "Power Settings",
										order = 9,
									
									},
									powerthresh = {
										type = 'range',
										name = "Power Required",
										desc = "Percentage of power (e.g. Mana/Energy) before an ability should be used",
										get = function() return self.db.char.spell.powerthresh[i] end,
										set = function(info, newValue) 
										self.db.char.spell.powerthresh[i] = newValue
										--self:CreatePriorityFrame()
										end,
										min = 1,
										max = 100,
										step = 1,
										order = 11,
										},
									combocost = {
										type = 'range',
										name = "Number of combo points require before using ability",
										get = function() return self.db.char.spell.combocost[i] end,
										set = function(info, newValue) 
										self.db.char.spell.combocost[i] = newValue
										--self:CreatePriorityFrame()
										end,
										min = 0,
										max = 5,
										step = 1,
										order = 11,
										},
									negthreshold = {
										type = 'toggle',
										name = "Power must be less than Power Required",
										desc = "e.g. Player must have less than 5% mana before a spell should be case as opposed to the default greater than setting.",
										get = function() if self.db.char.spell.negthreshold[i] == nil then self.db.char.spell.negthreshold[i] = false end 
															return self.db.char.spell.negthreshold[i] end,
										set = function() self.db.char.spell.negthreshold[i] = not self.db.char.spell.negthreshold[i]
										--self:CreatePriorityFrame()
										end	,
										order = 12,
										},
									
									
									
									
									
								},
							
								}
							
								cmdline.args.spell.args["spell"..i].args.DELETE = {
										type = 'execute',
										name = "Delete Spell",
										func = function() 
										for j = 1, 8 do 
										
										if self.db.char.spell.name[i] == self.db.char.priority.option1[j] then 
										self.db.char.priority.option1[j] = "none"
										end
										if self.db.char.spell.name[i] == self.db.char.priority.option2[j] then 
										self.db.char.priority.option2[j] = "none"
										end
										end
										
										self.priorityTable.name[self.db.char.spell.name[i]] = nil
										--table.remove(self.priorityTable.name, i)
										self:SwitchTalents()
										self.db.char.spell.name[i] = nil
										spell.negthreshold[i] = nil
										spell.nocd[i] = nil
										spell.combocost[i] = nil
										spell.powerthresh[i] = nil
										spell.dotlength[i] = nil
										spell.caster[i] = nil
										spell.countreq[i] = nil
										spell.spellname[i] = nil
										spell.isproc[i] = nil
										spell.typedot[i] = nil
										spell.trackspell[i] = nil
										spell.icon[i] = nil
										spell.typeshortdot[i] = nil
										LibStub("AceConfig-3.0"):RegisterOptionsTable("Watcher SS", self:SpellOptions())
										end,
										order = 14,
									}
									cmdline.args.spell.args["spell"..i].args.deleteheader = {
										type = 'header',
										name = "Delete Button",
										order = 13,
										}
								
							end
	--end
	--options.args["spell"] = spell
	return cmdline.args.spell
end


function Watcher:DisplayOptions()	
	cmdline.args.display = {
		name = L["Display Settings"],
		type = 'group',
		handler = Watcher,
		childGroups = 'tab',
		order = 1, 
		args = {
			text = {
				name = L["Text Settings"],
				type = 'group',
				order = 1, 
				args = {
					text = {
						type = 'toggle',
						name = L["Display CD text"],
						get = "priorityTextQuery",
						set = "ActivatePriorityText",
						order = 1,
					},
					bartext = {
						
						type = 'toggle',
						name = "Show text on bar",
						get = "GetShowBarText",
						set = "ShowBarText",
						order = 1,
					},
					textsize = {
						type = 'range',
						name = L["CD text size"],
						min = 6,
						max = 36,
						step = 2,
						get = "textsizeQuery",
						set = "Settextsize",
						order = 2,
					},
					textpoint = {
						type = 'select',
						name = L["Text Anchor"],
						desc = L["help_Dir"],
						get = "GetTextPoint",
						set = "SetTextPoint",
						values = self.textpoint,
						order = 3,	
					},
					font = {
						type = 'select',
						name = L["Font"],
						get = "GetFont",
						set = "SetFont",
						values = Watcher.fonts,
						order = 4,
					},
					effect = {
						type = 'select',
						name = L["Font Effect"],
						get = "GetFontEffect",
						set = "SetFontEffect",
						values = Watcher.fonteffects,
						order = 5,
					},
					activlabel = {
						type = 'toggle',
						name = L["Show Labels"],
						get = "LabelQuery",
						set = "ActivateLabel",
						order = 1,
					},
					barpos = {
						type = 'range',
						name = "Position of Bar Text",
						min = -1,
						max = 1,
						step = 1,
						get = function() return Watcher.db.char.barTxtPos end,
						set = function(info, newValue) 
						Watcher.db.char.barTxtPos = newValue
						Watcher:CreatePriorityFrame()
						end,
						order = 5,
					},
					vertlabelpos = {
						type = 'range',
						name = L["Label Vertical Position"],
						min = -60,
						max = 60,
						step = 2,
						get = "GetLabelVert",
						set = "SetLabelVert",
						order = 6,	
					},
					horlabelpos = {
						type = 'range',
						name = L["Label Horizontal Position"],
						min = -60,
						max = 60,
						step = 2,
						get = "GetLabelHori",
						set = "SetLabelHori",
						order = 6,
					},
					vertkeypos = {
						type = 'range',
						name = L["Keybindings Vertical Position"],
						min = -60,
						max = 60,
						step = 2,
						get = "GetKeyVert",
						set = "SetKeyVert",
						order = 6,	
					},
					horkeypos = {
						type = 'range',
						name = L["Keybindings Horizontal Position"],
						min = -60,
						max = 60,
						step = 2,
						get = "GetKeyHori",
						set = "SetKeyHori",
						order = 6,
					},
					labelcol = {
						type = 'color',
						name = L["Label Color"],
						get = "GetLabelCol",
						set = "SetLabelCol",
						order = 6,
					},
					keycol = {
						type = 'color',
						name = L["Keybindings Color"],
						get = "GetKeyCol",
						set = "SetKeyCol",
						order = 6,
					},
				},
			},
			bar = {
				type = 'group',
				name = L["Bar Settings"],
				order = 7,
				args = {
					statusbar = {
							type = 'toggle',
							name = L["Show Statusbar"],
							--desc = L["help_gcd"],
							get = "GetStatusbar",
							set = "ActivateStatusbar",
							order = 1,
						},
					bar1col = {
						type = 'color',
						name = L["1st Bar Colour"],
						get = "GetBar1Col",
						set = "SetBar1Col",
						order = 2,
					},
					bar2col = {
						type = 'color',
						name = L["2nd Bar Colour"],
						get = "GetBar2Col",
						set = "SetBar2Col",
						order = 2,
					},
					bar3col = {
						type = 'color',
						name = L["3rd Bar Colour"],
						get = "GetBar3Col",
						set = "SetBar3Col",
						order = 3,
					},
					bar4col = {
						type = 'color',
						name = L["4th Bar Colour"],
						get = "GetBar4Col",
						set = "SetBar4Col",
						order = 4,
					},
					bar5col = {
						type = 'color',
						name = L["5th Bar Colour"],
						get = "GetBar5Col",
						set = "SetBar5Col",
						order = 5,
					},
					bar6col = {
						type = 'color',
						name = L["6th Bar Colour"],
						get = "GetBar6Col",
						set = "SetBar6Col",
						order = 6,
					},
					bar7col = {
						type = 'color',
						name = L["7th Bar Colour"],
						get = "GetBar7Col",
						set = "SetBar7Col",
						order = 7,
					},
					bar8col = {
						type = 'color',
						name = L["8th Bar Colour"],
						get = "GetBar8Col",
						set = "SetBar8Col",
						order = 8,
					},
					baralpha = {
						type = 'range',
						name = L["Alpha of bars"],
						min = 0,
						max = 1,
						step = 0.05,
						get = "GetBarAlpha",
						set = "SetBarAlpha",
					},
				},
			},
			icon = {
				type = 'group',
				name = "Icon Settings",
				order = 6,
				args = {
					hide = {
						type = 'toggle',
						name = "Hide unusable spells",
						get = function() return self.db.char.icon.hide end,
						set = function() self.db.char.icon.hide = not self.db.char.icon.hide end,
						order = 1
					},
					grey = {
						type = 'toggle',
						name = "Set unusable spell's icon as Greyscale",
						get = function() return self.db.char.icon.grey end,
						set = function() self.db.char.icon.grey = not self.db.char.icon.grey end,
						order = 2,
					},
					color = {
						type = 'color',
						name = "Set alpha and colour of unusable spells",
						get = function()
							local colours = self.db.char.icon.col
							return colours.r, colours.g, colours.b, colours.a
							end,
						set = function(info, r,g,b,a)
							self.db.char.icon.col.r = r
							self.db.char.icon.col.g = g
							self.db.char.icon.col.b = b
							self.db.char.icon.col.a = a
							self:CreatePriorityFrame()
							end,
						order = 3,
					},
				},
			},
			general = {
				type = 'group',
				name = "General",
				order = 1,
				args = {
						combat = {
							type = 'toggle',
							name = L["Show only in combat"],
							get = "GetShowCombat",
							set = "ActivateShowCombat",
							order = 1,
						},
						target = {
							type = 'toggle',
							name = L["Show only if target exists"],
							get = "GetShowTarget",
							set = "ActivateShowTarget",
							order = 1,
						},
					--[[	isdot = {
							type = 'toggle',
							name = "isDot",
							get = "GetisDot",
							set = "ActivateisDot",
							order = 1,
						},]]
						party = {
							type = 'toggle',
							name = L["Show only in party"],
							get = "GetShowParty",
							set = "ActivateShowParty",
							order = 2,
						},
						raid = {
							type = 'toggle',
							name = L["Show only in raid"],
							get = "GetShowRaid",
							set = "ActivateShowRaid",
							order = 3,
						},
						pvp = {
							type = 'toggle',
							name = L["Enable in PVP"],
							get = "GetShowPVP",
							set = "ActivateShowPVP",
							order = 3,
						},
						moving = {
							type = 'toggle',
							name = L["Stack moving frames that overlap"],
							get = "MovingStackQuery",
							set = "ActivateMovingStack",
							order = 25,
						},
						scale = {
							type = 'range',
							name = L["Bar Scale"],
							desc = L["help_scale"],
							min = 0.25,
							max = 3.00,
							step = 0.05,
							get = "GetScale",
							set = "SetScale",
							order = 32,
						},
						iconsize = {
							type = 'range',
							name = L["Icon Size"],
							desc = L["help_size"],
							min = 10,
							max = 75,
							step = 5,
							get = "GetSize",
							set = "SetSize",
							order = 33,
						},
						barsize = {
							type = 'range',
							name = "Bar Segment Width",
							desc = "Alter Bar Height",
							min = 10,
							max = 100,
							step = 5,
							get = "GetSegmentSize",
							set = "SetSegmentSize",
							order = 33,
						},
						alpha = {
							type = 'range',
							name = L["Alpha"],
							desc = L["help_alpha"],
							min = 0,
							max = 1,
							step = 0.05,
							get = "GetAlpha",
							set = "SetAlpha",
							order = 34,
						},
						balpha = {
							type = 'range',
							name = L["Background Alpha"],
							desc = L["help_balpha"],
							min = 0,
							max = 1,
							step = 0.05,
							get = "GetBAlpha",
							set = "SetBAlpha",
							order = 35,
						},
						addtime = {
							type = 'input',
							name = "Add Bar Time Segment",
							desc = "Add a point in time (in seconds) to the timing bar.",
							get = function() return "" end,
							set = function(info, newValue)
							for k,v in pairs(self.db.char.indices) do
							if v == newValue then return end end
							table.insert(self.db.char.indices, tonumber(newValue))
							table.sort(self.db.char.indices)
							self:CreatePriorityFrame()
							end,
							order = 37,
						},
						removetime = {
							type = 'input',
							name = "Remove Bar Time Segment",
							desc = "Remove a point in time (in seconds) from the timing bar.",
							get = function() return "" end,
							set = function(info, newValue)
							for k,v in pairs(self.db.char.indices) do
							if v == tonumber(newValue) then 
							table.remove(self.db.char.indices,k)--self.db.char.indices[k] = nil
							break
							end
							end
							table.sort(self.db.char.indices)
							self:CreatePriorityFrame()
							end,
							order = 38,
						},
						resetsegments = {
							type = 'execute',
							name = "Reset Time Segments",
							desc = "Reset the time segments to the default configuration.",
							
							func = function() table.wipe(self.db.char.indices)
							self.db.char.indices = {0,1.5, 3,4.5, 6, 7.5,15,60, 300} 
							self:CreatePriorityFrame()
							end,
					
							order = 39,
							},
						axis =  {
							type = 'toggle',
							name = L["Show axis"],
							desc = L["help_axis"],
							get = "Getaxis",
							set = "Activateaxis",
							order = 35,
						},
						gcd = {
							type = 'toggle',
							name = L["Show GCD"],
							desc = L["help_gcd"],
							get = "GetGCD",
							set = "ActivateGCD",
							order = 40,
						},
						swingtimer = {
							type = 'toggle',
							name = L["Show Swing Timer"],
							--desc = L["help_gcd"],
							get = "GetSwing",
							set = "ActivateSwing",
							order = 41,
						},
					
					--[[	statusbartexture = {
							type = 'select',
							name = L["Bar Texture"],
							get = "GetBarTexture",
							set = "SetBarTexture",
							values = self.textures,
							order = 40,
						},]]
					direction = {
				type = 'select',
				name = L["Direction"],
				desc = L["help_Dir"],
				get = "GetDirection",
				set = "SetDirection",
				values = self.dir,
				order = 42,
			},
			}
			}
		},
	}
	return cmdline.args.display
end




function Watcher:spec1Options()
	cmdline.args.s1 = { 
	
		name = "Primary Spec Settings",
		handler = Watcher,
		type='group',
		childGroups ='tab',
		args = 
		{
			hide = {
					type = 'toggle',
					name = "Hide addon for Primary Spec",
					get = "hideprimary",
					set = "sethideprimary",
					order = 1,
					},
			num = {
					type = 'input',
					name = "Number of Priorities",
					get = function() return self.db.char.priority.p1num end,
					set = function(info, newValue) 
					if tonumber(newValue) > 15 then 
					self:Print("I can't let you do that Dave.")
					return
					end
					if tonumber(newValue) < self.db.char.priority.p1num then
					for i= tonumber(newValue)+1,self.db.char.priority.p1num do
						table.remove(self.db.char.priority.option1,i)
						--Watcher.timeLeft[i] = -1
						--Watcher.timeLeft[i] = -1
					end
					end
					self.db.char.priority.p1num = tonumber(newValue) 
					LibStub("AceConfig-3.0"):RegisterOptionsTable("Watcher S1", self:spec1Options())
					Watcher:CreatePriorityFrame()
					end,
					order = 1,
				},
			pt = {
			name = L["Priority Table 1"],
			order = 1,
			type = 'group',
			args = {},
				},
			kb = {
			name = L["Keybind Settings - Primary Spec"],
			type = 'group',
			order = 3, 
			args = {
						unbind = {
						type = 'execute',
						name = "Unbind Keys",
						func = "unbindkeys1",
						order = 1
						},
					},
		
				
				
			
				},
			label = {
			name = "Labels",
			type = 'group',
			order =2, 
			args = {},
			},
				}
				}
			
			for i= 1, self.db.char.priority.p1num do
				cmdline.args.s1.args.pt.args["h"..i] = {
				type = 'header',
				name = "Priority "..i,
				order = (3*i),
				}
				cmdline.args.s1.args.pt.args["p"..i] = {
					type = 'select',
					name = "Priority "..i,
					get = function() return self.db.char.priority.option1[i+1] end,
					set = function(info, newValue) 
						self.db.char.priority.option1[i+1] = newValue
						self:SwitchTalents()
						self:CreatePriorityFrame() 
						end,
					values = self.priorityTable.name,
					order = (3*i)+1,
				}
		
				cmdline.args.s1.args.pt.args["rb"..i] = {
					type = 'toggle',
					name = L["showraidboss1"],
					get = function() return self.db.char.priority.onlyboss1[i+1] end,
					set = function() 
						self.db.char.priority.onlyboss1[i+1] = not self.db.char.priority.onlyboss1[i+1]
						Watcher:SwitchTalents()
						end,
					order = (3*i)+2,
				
				}
				cmdline.args.s1.args.kb.args["kb"..i] = {
						type = 'keybinding',
						name = "Keybind for Priority "..i,
						get = function() if self.db.char.priority.keybindings1[i] ~= nil then return self.db.char.priority.keybindings1[i] end return "" end,
						set = function(info, newValue)	if self.combat ~= true then
								if self.db.char.priority.keybindings[i] ~= nil then
								SetBinding(self.db.char.priority.keybindings[i], nil)
								end
								self.db.char.priority.keybindings1[i] = newValue
								self:CreatePriorityFrame()
								else
									self:Print("Unable to bind inside combat")
								end
							end,
						order = i+1,
						}
				cmdline.args.s1.args.label.args["label"..i]= {
						type = 'input',
						name = "Label "..i,
						get = function() return self.db.char.priority.label[i+1] end,
						set = function(info, newValue)
							self.db.char.priority.label[i+1] = newValue
							self:CreatePriorityFrame()
						end,
						order = i,
					}

	end
	return cmdline.args.s1
	end



function Watcher:getCmdLineTable()
	cmdline = deepcopy(options)
	return cmdline
end


function Watcher:spec2Options()
 		cmdline.args.s2 = { 
	
		name = "Secondary Spec Settings",
		handler = Watcher,
		type='group',
		childGroups ='tab',
		args = 
		{
			hide = {
					type = 'toggle',
					name = "Hide addon for Secondary Spec",
					get = "hidesecondary",
					set = "sethidesecondary",
					order = 1,
					},
			num = {
					type = 'input',
					name = "Number of Priorities",
					get = function() return self.db.char.priority.p2num end,
					set = function(info, newValue) 
					if tonumber(newValue) > 15 then 
					self:Print("I can't let you do that Dave.")
					return
					end
					if tonumber(newValue) < self.db.char.priority.p2num then
					for i= tonumber(newValue)+1,self.db.char.priority.p2num do
						table.remove(self.db.char.priority.option2,i)
					end
					end
					self.db.char.priority.p2num = tonumber(newValue) 
					LibStub("AceConfig-3.0"):RegisterOptionsTable("Watcher S2", self:spec2Options())
					Watcher:CreatePriorityFrame()
					end,
					order = 1,
				},
			pt = {
			name = L["Priority Table 2"],
			order = 1,
			type = 'group',
			args = {},
				},
			kb = {
			name = L["Keybind Settings - Primary Spec"],
			type = 'group',
			order = 3, 
			args = {
						unbind = {
						type = 'execute',
						name = "Unbind Keys",
						func = "unbindkeys2",
						order = 1
						},
					},
		
				
				
			
				},
			label = {
			name = "Labels",
			type = 'group',
			order =2, 
			args = {},
			},
				}
				}
			
			for i= 1, self.db.char.priority.p2num do
				cmdline.args.s2.args.pt.args["h"..i] = {
				type = 'header',
				name = "Priority "..i,
				order = 3*i,
				}
				cmdline.args.s2.args.pt.args["p"..i] = {
					type = 'select',
					name = "Priority "..i,
					get = function() return self.db.char.priority.option2[i+1] end,
					set = function(info, newValue) 
						self.db.char.priority.option2[i+1] = newValue
						self:SwitchTalents()
						self:CreatePriorityFrame() 
						end,
					values = self.priorityTable.name,
					order = (3*i) +1,
				}
		
				cmdline.args.s2.args.pt.args["rb"..i] = {
					type = 'toggle',
					name = L["showraidboss2"],
					get = function() return self.db.char.priority.onlyboss2[i+1] end,
					set = function() 
						self.db.char.priority.onlyboss2[i+1] = not self.db.char.priority.onlyboss2[i+1]
						Watcher:SwitchTalents()
						end,
					order = (3*i)+2,
				
				}
				cmdline.args.s2.args.kb.args["kb"..i] = {
						type = 'keybinding',
						name = "Keybind for Priority "..i,
						get = function() return self.db.char.priority.keybindings2[i] end,
						set = function(info, newValue)	if self.combat ~= true then
								if self.db.char.priority.keybindings[i] ~= nil then
								SetBinding(self.db.char.priority.keybindings[i], nil)
								end
								self.db.char.priority.keybindings2[i] = newValue
								self:CreatePriorityFrame()
								else
									self:Print("Unable to bind inside combat")
								end
							end,
						order = i+1,
						}
				cmdline.args.s2.args.label.args["label"..i]= {
						type = 'input',
						name = "Label "..i,
						get = function() return self.db.char.priority.label2[i+1] end,
						set = function(info, newValue)
							self.db.char.priority.label2[i+1] = newValue
							self:CreatePriorityFrame()
						end,
						order = i,
					}

	end
	return cmdline.args.s2
	end



function Watcher:AddSpell(info, newValue)
	local i = table.getn(self.db.char.spell.name) + 1
	for j = 1, table.getn(self.db.char.spell.name) do
		if self.db.char.spell.name[j] == "SKIP" then
			i = j
		end
	end
	self.db.char.spell.name[i] = newValue
	self.db.char.spell.spellname[i], _, self.db.char.spell.icon[i] = GetSpellInfo(newValue)
	self.db.char.spell.typedot[i] = false
	self.db.char.spell.typeshortdot[i] = false
	self.db.char.spell.isbuff[i] = false
	self.db.char.spell.isproc[i] = false
	--self.db.char.spell.typedot[newValue] = false
	self.db.char.spell.powerthresh[i] = 0
	self.db.char.spell.countreq[i] = 0
	self.db.char.spell.dotthreshold[i] = 0
	self.db.char.spell.dotlength[i] = 0
	self.db.char.spell.dottime[i] = 0
	self.db.char.spell.combocost[i] = 0
	self.db.char.spell.trackspell[i] = self.db.char.spell.name[i]
	self.db.char.spell.negthreshold[i] = false
	self.db.char.spell.nocd[i] = false
	self.db.char.spell.caster[i] = false
	Watcher.priorityTable.name[i] = self.db.char.spell.name[i]
	Watcher.priorityTable.icon[i] = self.db.char.spell.icon[i]
	Watcher.priorityTable.check[i] = function (FrameName, optionnum)
	Watcher:UpdateSpell(FrameName, optionnum, self.db.char.spell.typedot[i], Watcher:BuffInfo(i, self.db.char.spell.trackspell[i]), self.db.char.spell.typeshortdot[i], self.db.char.spell.dottime[i],0, self.db.char.spell.spellname[i].."()", self.db.char.spell.powerthresh[i], self.db.char.spell.countreq[i], self.db.char.spell.dotthreshold[i], self.db.char.spell.combocost[i], self.db.char.spell.isproc[i], Watcher:CountInfo(i, self.db.char.spell.trackspell[i]), self.db.char.spell.negthreshold[i], self.db.char.spell.nocd[i])	
	end
	
	LibStub("AceConfig-3.0"):RegisterOptionsTable("Watcher SS", self:SpellOptions())
end

function Watcher:SetSpellInfo(info, newValue)
self.db.char.spell.spellname[i], _, self.db.char.spell.icon[i] = GetSpellInfo(newValue)
end

	
function Watcher:SetBarTexture(info, newValue)
	self.db.char.texture = newValue
	local barTexture = media:Fetch('statusbar', newValue)
	if self.db.char.showbars then
		self.PriorityFrame.statusbar:SetTexture(bartexture)
	end
end

function Watcher:GetBarTexture()
	return self.db.char.texture
end

function Watcher:GetShowBarText()
	return self.db.char.bartext
end
function Watcher:ShowBarText()
	self.db.char.bartext = not self.db.char.bartext
	for i = 1, table.getn(self.db.char.indices) do
		if not self.db.char.bartext then
			self.PriorityFrame.text[i]:Hide()
		else
			self.PriorityFrame.text[i]:Show()
		end
	end
end



function Watcher:ActivateGCD()
	self.db.char.showgcd = not self.db.char.showgcd
	self:CreatePriorityFrame()
	if (self.db.char.showgcd) then
		self:Print(L["config_GCD_on"])
	else
		self:Print(L["config_GCD_off"])
	end
end

function Watcher:ActivateisDot(i)
	self.db.char.priority.isDot[i] = not self.db.char.priority.isDot[i]
	self:CreatePriorityFrame()
	if (self.db.char.priority.isDot[i]) then
		self:Print(Watcher.priorityTable.name[i])
	else
		self:Print(Watcher.priorityTable.name[i])
	end
end

function Watcher:ActivateMovingStack()
	self.db.char.stackmoving = not self.db.char.stackmoving
	--self:CreatePriorityFrame()
	if (self.db.char.stackmoving) then
		--self:Print(L["config_GCD_on"])
	else
		--self:Print(L["config_GCD_off"])
	end
end

function Watcher:ActivateEnable()
	self.db.char.enable = not self.db.char.enable
	--self:CreatePriorityFrame()
	if (self.db.char.enable) then
		self:Print(L["config_enable_on"])
		self.PriorityFrame:Show()
		self:CreatePriorityFrame()
	else
		self:Print(L["config_enable_off"])
		self.PriorityFrame:Hide()
	end
end

function Watcher:GetGCD()
	return self.db.char.showgcd
end


function Watcher:GetSwing()
	return self.db.char.showswing
end

function Watcher:GetStatusbar()
	return self.db.char.showbars
end
function Watcher:GetisDot(i)
	self:Print(self.db.char.priority.isDot[i])
	return self.db.char.priority.isDot[i]
end

function Watcher:MovingStackQuery()
	return self.db.char.stackmoving
end

function Watcher:EnableQuery()
	return self.db.char.enable
end

function Watcher:LabelQuery()
	return self.db.char.priority.showlabel
end

function Watcher:ActivateLabel()
	self.db.char.priority.showlabel = not self.db.char.priority.showlabel
	self:CreatePriorityFrame()
end


function Watcher:ActivateSwing()
	self.db.char.showswing = not self.db.char.showswing
	self:CreatePriorityFrame()
end


function Watcher:ActivateStatusbar()
	self.db.char.showbars = not self.db.char.showbars
	self:CreatePriorityFrame()
end

function Watcher:ActivateDebug()
	self.db.char.debug = not self.db.char.debug
	if (self.db.char.debug) then
		self:Print(L["config_debug_on"])
	else
		self:Print(L["config_debug_off"])
	end
end

function Watcher:ActivateShowCombat()
	self.db.char.showcombat = not self.db.char.showcombat
	self:CreatePriorityFrame()
end

function Watcher:ActivateShowTarget()
	self.db.char.showtarget = not self.db.char.showtarget
	self:CreatePriorityFrame()
end

function Watcher:ActivateShowParty()
	self.db.char.showparty = not self.db.char.showparty
	self:CreatePriorityFrame()
end
  
function Watcher:ActivateShowRaid()
	self.db.char.showraid = not self.db.char.showraid
	self:CreatePriorityFrame()
end

function Watcher:ActivateShowPVP()
	self.db.char.enablepvp = not self.db.char.enablepvp
	self:CreatePriorityFrame()
end

function Watcher:ActivatelnlIcon()
	self.db.char.priority.lnlIcon = not self.db.char.priority.lnlIcon
	if (self.db.char.priority.lnlIcon) then
		for index = 1, 2 do
			self.PriorityFrame.lnl[index].frame:Show()
		end
		self:Print(L["config_lnlIcon_on"])
	else
		for index = 1, 2 do
			self.PriorityFrame.lnl[index].frame:Hide()
		end
		self:Print(L["config_lnlIcon_off"])
	end
end

function Watcher:ShowHideFrame()
	self.db.char.barshow = not self.db.char.barshow
	if self.db.char.barshow then
		self.PriorityFrame:EnableMouse(1)
		self.PriorityFrame:Show()
	else
		self.PriorityFrame:EnableMouse(0);
		if self.db.char.showcombat and combat then
			self.PriorityFrame:Show()
		elseif not self.db.char.showcombat then
			self.PriorityFrame:Show()
		else
		self.PriorityFrame:Hide()
		end
	end
end

function Watcher:FinishedMoving(var, frame)
	local point, relativeTo, relativePoint, xOffset, yOffset = frame:GetPoint();
	var.point = point
	var.relativeTo = relativeTo
	var.relativePoint = relativePoint
	var.xOffset = xOffset
	var.yOffset = yOffset
end

function Watcher:GetShowCombat()
	return self.db.char.showcombat
end


function Watcher:GetShowTarget()
	return self.db.char.showtarget
end

function Watcher:GetShowParty()
	return self.db.char.showparty
end

function Watcher:GetShowRaid()
	return self.db.char.showraid
end

function Watcher:GetShowPVP()
	return self.db.char.enablepvp
end

function Watcher:BarShowQuery()
	return self.db.char.barshow
end

function Watcher:lnlIconQuery()
	return self.db.char.priority.lnlIcon
end

function Watcher:disableQuery()
	return self.db.char.disablebars
end

function Watcher:bariconsQuery()
	return self.db.char.showicons
end

function Watcher:debugQuery()
	return self.db.char.debug
end

function Watcher:GetScale()
    return self.db.char.scale
end

function Watcher:GetSize()
    return self.db.char.priority.IconSize
end

function Watcher:GetSegmentSize()
    return self.db.char.priority.fWidth
end

function Watcher:GetBAlpha()
    return self.db.char.balpha
end

function Watcher:GetBarAlpha()
    return self.db.char.baralpha
end

function Watcher:GetAlpha()
    return self.db.char.alpha
end

function Watcher:GetLabel1()
    return self.db.char.priority.label[1]
end

function Watcher:GetLabel2()
    return self.db.char.priority.label[2]
end

function Watcher:GetLabel3()
    return self.db.char.priority.label[3]
end

function Watcher:GetLabel4()
    return self.db.char.priority.label[4]
end

function Watcher:GetLabel5()
    return self.db.char.priority.label[5]
end

function Watcher:GetLabel6()
    return self.db.char.priority.label[6]
end

function Watcher:GetLabel7()
    return self.db.char.priority.label[7]
end

function Watcher:GetLabel8()
    return self.db.char.priority.label[8]
end

function Watcher:GetLabel21()
    return self.db.char.priority.label2[1]
end

function Watcher:GetLabel22()
    return self.db.char.priority.label2[2]
end

function Watcher:GetLabel23()
    return self.db.char.priority.label2[3]
end

function Watcher:GetLabel24()
    return self.db.char.priority.label2[4]
end

function Watcher:GetLabel25()
    return self.db.char.priority.label2[5]
end

function Watcher:GetLabel26()
    return self.db.char.priority.label2[6]
end

function Watcher:GetLabel27()
    return self.db.char.priority.label2[7]
end

function Watcher:GetLabel28()
    return self.db.char.priority.label2[8]
end

function Watcher:GetLabelVert()
	return self.db.char.priority.labelvert
end

function Watcher:GetLabelHori()
	return self.db.char.priority.labelhori
end

function Watcher:GetLabelCol()
	local colours = self.db.char.priority.labelcol
	return colours.r, colours.g, colours.b, colours.a
end


function Watcher:GetKeyVert()
	return self.db.char.priority.keyvert
end

function Watcher:GetKeyHori()
	return self.db.char.priority.keyhori
end

function Watcher:GetKeyCol()
	local colours = self.db.char.priority.keycol
	return colours.r, colours.g, colours.b, colours.a
end

function Watcher:GetBar1Col()
	local colours = self.db.char.barcol.bar1
	return colours.r, colours.g, colours.b, colours.a
end

function Watcher:GetBar2Col()
	local colours = self.db.char.barcol.bar2
	return colours.r, colours.g, colours.b, colours.a
end

function Watcher:GetBar3Col()
	local colours = self.db.char.barcol.bar3
	return colours.r, colours.g, colours.b, colours.a
end

function Watcher:GetBar4Col()
	local colours = self.db.char.barcol.bar4
	return colours.r, colours.g, colours.b, colours.a
end

function Watcher:GetBar5Col()
	local colours = self.db.char.barcol.bar5
	return colours.r, colours.g, colours.b, colours.a
end

function Watcher:GetBar6Col()
	local colours = self.db.char.barcol.bar6
	return colours.r, colours.g, colours.b, colours.a
end

function Watcher:GetBar7Col()
	local colours = self.db.char.barcol.bar7
	return colours.r, colours.g, colours.b, colours.a
end

function Watcher:GetBar8Col()
	local colours = self.db.char.barcol.bar8
	return colours.r, colours.g, colours.b, colours.a
end

function Watcher:Getmaxtime()

    return self.db.char.priority.maxtime
end

function Watcher:Setmaxtime(info, newValue)
	for i = 1, (self.db.char.priority.maxtime / self.db.char.priority.interval) do	
	Watcher.PriorityFrame.text[i]:SetText("")
	end
	self.db.char.priority.maxtime = newValue
	Watcher:CreatePriorityFrame()
	self:Print(L["config_maxtime"]..newValue)
end


function Watcher:Getinterval()

    return self.db.char.priority.interval
end

function Watcher:Setinterval(info, newValue)
	for i = 1, (self.db.char.priority.maxtime / self.db.char.priority.interval) do	
	Watcher.PriorityFrame.axisbase.text[i]:SetText("")
	end
	self.db.char.priority.interval = newValue
	Watcher:CreatePriorityFrame()
	self:Print(L["config_interval"]..newValue)
end

function Watcher:SetHS(info, newValue)
	
	self.db.char.warrior.hsragethresh = newValue
	self:CreatePriorityFrame()
end	

function Watcher:SetSRCombo(info, newValue)
	self.db.char.druid.srcombo = newValue
	self:CreatePriorityFrame()
end	

function Watcher:SetDH(info, newValue)
	self.db.char.hunter.dh = newValue
--	self:CreatePriorityFrame()
end	

function Watcher:SetV(info, newValue)
	self.db.char.hunter.v = newValue
--	self:CreatePriorityFrame()
end

function Watcher:SetRipCombo(info, newValue)
	self.db.char.druid.ripcombo = newValue
	self:CreatePriorityFrame()
end	

function Watcher:SetFBCombo(info, newValue)
	self.db.char.druid.fbcombo = newValue
	self:CreatePriorityFrame()
end	

function Watcher:GetHS()
	return self.db.char.warrior.hsragethresh
end	

function Watcher:SetSA(info, newValue)
	self.db.char.warrior.sunderarmor = newValue
	self:CreatePriorityFrame()
end	

function Watcher:GetSA()
	return self.db.char.warrior.sunderarmor
end	

function Watcher:SetLabelVert(info, newValue)
	self.db.char.priority.labelvert = newValue
	self:CreatePriorityFrame()
end	

function Watcher:SetLabelHori(info, newValue)
	self.db.char.priority.labelhori = newValue
	self:CreatePriorityFrame()
end	

function Watcher:SetKeyVert(info, newValue)
	self.db.char.priority.keyvert = newValue
	self:CreatePriorityFrame()
end	

function Watcher:SetKeyHori(info, newValue)
	self.db.char.priority.keyhori = newValue
	self:CreatePriorityFrame()
end	

function Watcher:SetLabelCol(info, r,g,b,a)
	self.db.char.priority.labelcol.r = r
	self.db.char.priority.labelcol.g = g
	self.db.char.priority.labelcol.b = b
	self.db.char.priority.labelcol.a = a
	self:CreatePriorityFrame()
end	

function Watcher:SetKeyCol(info, r,g,b,a)
	self.db.char.priority.keycol.r = r
	self.db.char.priority.keycol.g = g
	self.db.char.priority.keycol.b = b
	self.db.char.priority.keycol.a = a
	self:CreatePriorityFrame()
end	

function Watcher:SetBar1Col(info, r,g,b,a)
	self.db.char.barcol.bar1.r = r
	self.db.char.barcol.bar1.g = g
	self.db.char.barcol.bar1.b = b
	self.db.char.barcol.bar1.a = a
	self:CreatePriorityFrame()
end	

function Watcher:SetBar2Col(info, r,g,b,a)
	self.db.char.barcol.bar2.r = r
	self.db.char.barcol.bar2.g = g
	self.db.char.barcol.bar2.b = b
	self.db.char.barcol.bar2.a = a
	self:CreatePriorityFrame()
end	

function Watcher:SetBar3Col(info, r,g,b,a)
	self.db.char.barcol.bar3.r = r
	self.db.char.barcol.bar3.g = g
	self.db.char.barcol.bar3.b = b
	self.db.char.barcol.bar3.a = a
	self:CreatePriorityFrame()
end	

function Watcher:SetBar4Col(info, r,g,b,a)
	self.db.char.barcol.bar4.r = r
	self.db.char.barcol.bar4.g = g
	self.db.char.barcol.bar4.b = b
	self.db.char.barcol.bar4.a = a
	self:CreatePriorityFrame()
end	

function Watcher:SetBar5Col(info, r,g,b,a)
	self.db.char.barcol.bar5.r = r
	self.db.char.barcol.bar5.g = g
	self.db.char.barcol.bar5.b = b
	self.db.char.barcol.bar5.a = a
	self:CreatePriorityFrame()
end	

function Watcher:SetBar6Col(info, r,g,b,a)
	self.db.char.barcol.bar6.r = r
	self.db.char.barcol.bar6.g = g
	self.db.char.barcol.bar6.b = b
	self.db.char.barcol.bar6.a = a
	self:CreatePriorityFrame()
end	

function Watcher:SetBar7Col(info, r,g,b,a)
	self.db.char.barcol.bar7.r = r
	self.db.char.barcol.bar7.g = g
	self.db.char.barcol.bar7.b = b
	self.db.char.barcol.bar7.a = a
	self:CreatePriorityFrame()
end	

function Watcher:SetBar8Col(info, r,g,b,a)
	self.db.char.barcol.bar8.r = r
	self.db.char.barcol.bar8.g = g
	self.db.char.barcol.bar8.b = b
	self.db.char.barcol.bar8.a = a
	self:CreatePriorityFrame()
end	

function Watcher:SetLabel1(info, newValue)
	self.db.char.priority.label[1] = newValue
	self:CreatePriorityFrame()
end	
--Watcher:UpdateSpell(FrameName, optionnum, self.db.char.priority.isBuff["Spell "..Watcher.usedspells], self.db.char.priority.isDot["Spell "..Watcher.usedspells], false, 0, 1, C[name].."()", 0, 0, 0)
--FrameName, optionnum, typedot, dotfunction, typeShortDot, shortDotTime, usehealthpc, SpellName, powerthreshold, countreq, dotthreshold, combocost) 	


function Watcher:SetLabel2(info, newValue)
	
	self.db.char.priority.label[2] = newValue
	self:CreatePriorityFrame()
end	

function Watcher:SetLabel3(info, newValue)
	
	self.db.char.priority.label[3] = newValue
	self:CreatePriorityFrame()
end	

function Watcher:SetLabel4(info, newValue)
	
	self.db.char.priority.label[4] = newValue
	self:CreatePriorityFrame()
end	

function Watcher:SetLabel5(info, newValue)
	
	self.db.char.priority.label[5] = newValue
	self:CreatePriorityFrame()
end	

function Watcher:SetLabel6(info, newValue)
	
	self.db.char.priority.label[6] = newValue
	self:CreatePriorityFrame()
end	

function Watcher:SetLabel7(info, newValue)
	
	self.db.char.priority.label[7] = newValue
	self:CreatePriorityFrame()
end	

function Watcher:SetLabel8(info, newValue)
	
	self.db.char.priority.label[8] = newValue
	self:CreatePriorityFrame()
end	

function Watcher:SetLabel21(info, newValue)
	
	self.db.char.priority.label2[1] = newValue
	self:CreatePriorityFrame()
end	

function Watcher:SetLabel22(info, newValue)
	
	self.db.char.priority.label2[2] = newValue
	self:CreatePriorityFrame()
end	

function Watcher:SetLabel23(info, newValue)
	
	self.db.char.priority.label2[3] = newValue
	self:CreatePriorityFrame()
end	

function Watcher:SetLabel24(info, newValue)
	
	self.db.char.priority.label2[4] = newValue
	self:CreatePriorityFrame()
end	

function Watcher:SetLabel25(info, newValue)
	
	self.db.char.priority.label2[5] = newValue
	self:CreatePriorityFrame()
end	

function Watcher:SetLabel26(info, newValue)
	
	self.db.char.priority.label2[6] = newValue
	self:CreatePriorityFrame()
end	

function Watcher:SetLabel27(info, newValue)
	self.db.char.priority.label2[7] = newValue
	self:CreatePriorityFrame()
end	

function Watcher:SetLabel28(info, newValue)
	
	self.db.char.priority.label2[8] = newValue
	self:CreatePriorityFrame()
end	

function Watcher:Activateaxis()
	self.db.char.showaxis = not self.db.char.showaxis
	--self:CreatePriorityFrame()
	if (self.db.char.showaxis) then
		self.PriorityFrame.axisbase:SetAlpha(1)
		self:Print(L["config_axis_on"])
	else
		self.PriorityFrame.axisbase:SetAlpha(0)
		self:Print(L["config_axis_off"])
	end
end

function Watcher:Getaxis()
	return self.db.char.showaxis
end

function Watcher:GetDirection(info)
	return self.db.char.growdir
end

function Watcher:GetTextPoint(info)
	return self.db.char.textpoint
end

function Watcher:SetDirection(info, newValue)
	for i = 1, (self.db.char.priority.maxtime / self.db.char.priority.interval) do	
	self.PriorityFrame.text[i]:SetText("")
	end
	self:Print(self.db.char.growdir)
	self.db.char.growdir = self.dir[newValue]	
	self:CreatePriorityFrame()
end

function Watcher:SetTextPoint(info, newValue)
	self.db.char.textpoint = newValue
	self:CreatePriorityFrame()
end

function Watcher:SetScale(info,newValue)
	self.db.char.scale = newValue
	self.PriorityFrame:SetScale(self.db.char.scale)
	self:Print("Scale set to : "..self.db.char.scale)
end

function Watcher:SetSize(info,newValue)
	self.db.char.priority.IconSize = newValue
	self:CreatePriorityFrame()
	self:Print("Icon Size set to : "..self.db.char.priority.IconSize)
end

function Watcher:SetSegmentSize(info,newValue)
	self.db.char.priority.fWidth = newValue
	self:CreatePriorityFrame()
	self:Print("Bar height set to : "..self.db.char.priority.fWidth)
end


function Watcher:Settextsize(info,newValue)
	self.db.char.iconfontsize = newValue
	self:CreatePriorityFrame()
	--self:Print("Icon Size set to : "..self.db.char.priority.IconSize)
end

function Watcher:SetAlpha(info,newValue)
	self.db.char.alpha = newValue
	self.PriorityFrame:SetAlpha(self.db.char.alpha)
	self:Print("Alpha set to : "..self.db.char.alpha)
end

function Watcher:SetBAlpha(info,newValue)
	self.db.char.balpha = newValue
	self.PriorityFrame:SetBackdropColor(0, 0, 0, self.db.char.balpha)
	self:Print("Backdrop Alpha set to : "..self.db.char.balpha)
end

function Watcher:SetBarAlpha(info,newValue)
	self.db.char.baralpha = newValue
	self:CreatePriorityFrame()
end

function Watcher:Get1Keybind1()
	return self.db.char.priority.keybindings1[1]
end

function Watcher:Set1Keybind1(info, newValue)
	if self.combat ~= true then
	if self.db.char.priority.keybindings[1] ~= nil then
	SetBinding(self.db.char.priority.keybindings[1], nil)
	end
	self.db.char.priority.keybindings1[1] = newValue
	self:CreatePriorityFrame()
	else
		self:Print("Unable to bind inside combat")
	end
end

function Watcher:Get2Keybind1()
	return self.db.char.priority.keybindings1[2]
end

function Watcher:Set2Keybind1(info, newValue)
	if self.combat ~= true then
	if self.db.char.priority.keybindings[2] ~= nil then
	SetBinding(self.db.char.priority.keybindings[2], nil)
	end
	self.db.char.priority.keybindings1[2] = newValue
	self:CreatePriorityFrame()
	else
		self:Print("Unable to bind inside combat")
	end
end

function Watcher:Get3Keybind1()
	return self.db.char.priority.keybindings1[3]
end

function Watcher:Set3Keybind1(info, newValue)
if self.combat ~= true then
	if self.db.char.priority.keybindings[3] ~= nil then
	SetBinding(self.db.char.priority.keybindings[3], nil)
	end
	self.db.char.priority.keybindings1[3] = newValue
	self:CreatePriorityFrame()
	else
		self:Print("Unable to bind inside combat")
	end
end

function Watcher:Get4Keybind1()
	return self.db.char.priority.keybindings1[4]
end

function Watcher:Set4Keybind1(info, newValue)
	if self.combat ~= true then
	if self.db.char.priority.keybindings[4] ~= nil then
	SetBinding(self.db.char.priority.keybindings[4], nil)
	end
	self.db.char.priority.keybindings1[4] = newValue
	self:CreatePriorityFrame()
	else
		self:Print("Unable to bind inside combat")
	end
end

function Watcher:Get5Keybind1()
	return self.db.char.priority.keybindings1[5]
end

function Watcher:Set5Keybind1(info, newValue)
if self.combat ~= true then
	if self.db.char.priority.keybindings[5] ~= nil then
	SetBinding(self.db.char.priority.keybindings[5], nil)
	end
	self.db.char.priority.keybindings1[5] = newValue
	self:CreatePriorityFrame()
	else
		self:Print("Unable to bind inside combat")
	end
end

function Watcher:Get6Keybind1()
	return self.db.char.priority.keybindings1[6]
end

function Watcher:Set6Keybind1(info, newValue)
	if self.combat ~= true then
	if self.db.char.priority.keybindings[6] ~= nil then
	SetBinding(self.db.char.priority.keybindings[6], nil)
	end
	self.db.char.priority.keybindings1[6] = newValue
	self:CreatePriorityFrame()
	else
		self:Print("Unable to bind inside combat")
	end
end

function Watcher:Get7Keybind1()
	return self.db.char.priority.keybindings1[7]
end

function Watcher:Set7Keybind1(info, newValue)
	if self.combat ~= true then
	if self.db.char.priority.keybindings[7] ~= nil then
	SetBinding(self.db.char.priority.keybindings[7], nil)
	end
	self.db.char.priority.keybindings1[7] = newValue
	self:CreatePriorityFrame()
	else
		self:Print("Unable to bind inside combat")
	end
end

function Watcher:Get8Keybind1()
	return self.db.char.priority.keybindings1[8]
end

function Watcher:Set8Keybind1(info, newValue)
	if self.combat ~= true then
	if self.db.char.priority.keybindings[8] ~= nil then
	SetBinding(self.db.char.priority.keybindings[8], nil)
	end
	self.db.char.priority.keybindings1[8] = newValue
	self:CreatePriorityFrame()
	else
		self:Print("Unable to bind inside combat")
	end
end

function Watcher:unbindkeys1()
	if self.combat ~= true then
		for i=1, self.db.char.priority.p1num do
		if self.db.char.priority.keybindings[i] ~= nil then
			SetBinding(self.db.char.priority.keybindings[i], nil)
	--		Watcher:Print(GetBindingAction(self.db.char.priority.keybindings[i]))
		end
		end
		--self.db.char.priority.keybindings = { "", "", "", "", "", "", "", ""}
		self.db.char.priority.keybindings1 = nil
		local groupIndex = GetActiveTalentGroup()
		if groupIndex == 1 then 
			self.db.char.priority.keybindings = self.db.char.priority.keybindings1
		end
	else
		self:Print("Unable to unbind inside combat")
	end
end

function Watcher:Get1Keybind2()
	return self.db.char.priority.keybindings2[1]
end

function Watcher:Set1Keybind2(info, newValue)
	if self.combat ~= true then
	if self.db.char.priority.keybindings[1] ~= nil then
	SetBinding(self.db.char.priority.keybindings[1], nil)
	end
	self.db.char.priority.keybindings2[1] = newValue
	self:CreatePriorityFrame()
	else
		self:Print("Unable to bind inside combat")
	end
end

function Watcher:Get2Keybind2()
	return self.db.char.priority.keybindings2[2]
end

function Watcher:Set2Keybind2(info, newValue)
	if self.combat ~= true then
	if self.db.char.priority.keybindings[2] ~= nil then
	SetBinding(self.db.char.priority.keybindings[2], nil)
	end
	self.db.char.priority.keybindings2[2] = newValue
	self:CreatePriorityFrame()
	else
		self:Print("Unable to bind inside combat")
	end
end

function Watcher:Get3Keybind2()
	return self.db.char.priority.keybindings2[3]
end

function Watcher:Set3Keybind2(info, newValue)
if self.combat ~= true then
	if self.db.char.priority.keybindings[3] ~= nil then
	SetBinding(self.db.char.priority.keybindings[3], nil)
	end
	self.db.char.priority.keybindings2[3] = newValue
	self:CreatePriorityFrame()
	else
		self:Print("Unable to bind inside combat")
	end
end

function Watcher:Get4Keybind2()
	return self.db.char.priority.keybindings2[4]
end

function Watcher:Set4Keybind2(info, newValue)
	if self.combat ~= true then
	if self.db.char.priority.keybindings[4] ~= nil then
	SetBinding(self.db.char.priority.keybindings[4], nil)
	end
	self.db.char.priority.keybindings2[4] = newValue
	self:CreatePriorityFrame()
	else
		self:Print("Unable to bind inside combat")
	end
end

function Watcher:Get5Keybind2()
	return self.db.char.priority.keybindings2[5]
end

function Watcher:Set5Keybind2(info, newValue)
if self.combat ~= true then
	if self.db.char.priority.keybindings[5] ~= nil then
	SetBinding(self.db.char.priority.keybindings[5], nil)
	end
	self.db.char.priority.keybindings2[5] = newValue
	self:CreatePriorityFrame()
	else
		self:Print("Unable to bind inside combat")
	end
end

function Watcher:Get6Keybind2()
	return self.db.char.priority.keybindings2[6]
end

function Watcher:Set6Keybind2(info, newValue)
	if self.combat ~= true then
	if self.db.char.priority.keybindings[6] ~= nil then
	SetBinding(self.db.char.priority.keybindings[6], nil)
	end
	self.db.char.priority.keybindings2[6] = newValue
	self:CreatePriorityFrame()
	else
		self:Print("Unable to bind inside combat")
	end
end

function Watcher:Get7Keybind2()
	return self.db.char.priority.keybindings2[7]
end

function Watcher:Set7Keybind2(info, newValue)
	if self.combat ~= true then
	if self.db.char.priority.keybindings[7] ~= nil then
	SetBinding(self.db.char.priority.keybindings[7], nil)
	end
	self.db.char.priority.keybindings2[7] = newValue
	self:CreatePriorityFrame()
	else
		self:Print("Unable to bind inside combat")
	end
end

function Watcher:Get8Keybind2()
	return self.db.char.priority.keybindings2[8]
end

function Watcher:Set8Keybind2(info, newValue)
	if self.combat ~= true then
	if self.db.char.priority.keybindings[8] ~= nil then
	SetBinding(self.db.char.priority.keybindings[8], nil)
	end
	self.db.char.priority.keybindings2[8] = newValue
	self:CreatePriorityFrame()
	else
		self:Print("Unable to bind inside combat")
	end
end



function Watcher:unbindkeys2()
	if self.combat ~= true then
		for i=1, 8 do
		if self.db.char.priority.keybindings[i] ~= nil then
			SetBinding(self.db.char.priority.keybindings[i], nil)
		--	Watcher:Print(GetBindingAction(self.db.char.priority.keybindings[i]))
		end
		end
		--self.db.char.priority.keybindings = { "", "", "", "", "", "", "", ""}
		self.db.char.priority.keybindings2 = { nil, nil, nil, nil, nil, nil, nil, nil}
		local groupIndex = GetActiveTalentGroup()
		if groupIndex == 1 then 
			self.db.char.priority.keybindings = self.db.char.priority.keybindings1
		end
		for i=1, 8 do
		--Watcher:Print(self.db.char.priority.keybindings[i])
		end
		--self:SwitchTalents()
		self:CreatePriorityFrame()
	else
		self:Print("Unable to unbind inside combat")
	end
end

-----------------------------------------
-- Priority Choices
-----------------------------------------

function Watcher:GetFirstPriority(info)
	return self.db.char.priority.option1[2] 
end

function Watcher:SetFirstPriority(info, priorityValue)

end

function Watcher:GetFirstshowraidboss()
	return self.db.char.priority.onlyboss1[2] 
end

function Watcher:SetFirstshowraidboss()
	
end

function Watcher:GetSecondPriority(info)
	return self.db.char.priority.option1[3] 
end

function Watcher:SetSecondPriority(info, priorityValue)
	self.db.char.priority.option1[3] = priorityValue
	self:SwitchTalents()
	self:CreatePriorityFrame()
end
function Watcher:GetSecondshowraidboss()
	return self.db.char.priority.onlyboss1[3] 
end

function Watcher:SetSecondshowraidboss()
	self.db.char.priority.onlyboss1[3] = not self.db.char.priority.onlyboss1[3]
	self:Print(self.db.char.priority.onlyboss1[3])
	--self:CreatePriorityFrame()
end

function Watcher:GetThirdPriority(info)
	return self.db.char.priority.option1[4] 
end

function Watcher:SetThirdPriority(info, priorityValue)
	self.db.char.priority.option1[4] = priorityValue
	self:SwitchTalents()
	self:CreatePriorityFrame()
end


function Watcher:GetThirdshowraidboss()
	return self.db.char.priority.onlyboss1[4] 
end

function Watcher:SetThirdshowraidboss()
	self.db.char.priority.onlyboss1[4] = not self.db.char.priority.onlyboss1[4]
	--self:CreatePriorityFrame()
end

function Watcher:GetFourthPriority(info)
	return self.db.char.priority.option1[5] 
end

function Watcher:SetFourthPriority(info, priorityValue)
	self.db.char.priority.option1[5] = priorityValue
	self:SwitchTalents()
	self:CreatePriorityFrame()
end


function Watcher:GetFourthshowraidboss()
	return self.db.char.priority.onlyboss1[5] 
end

function Watcher:SetFourthshowraidboss()
	self.db.char.priority.onlyboss1[5] = not self.db.char.priority.onlyboss1[5]
	--self:CreatePriorityFrame()
end

function Watcher:GetFifthPriority(info)
	return self.db.char.priority.option1[6] 
end

function Watcher:SetFifthPriority(info, priorityValue)
	self.db.char.priority.option1[6] = priorityValue
	self:SwitchTalents()
	self:CreatePriorityFrame()
end

function Watcher:GetFifthshowraidboss()
	return self.db.char.priority.onlyboss1[6] 
end

function Watcher:SetFifthshowraidboss()
	self.db.char.priority.onlyboss1[6] = not self.db.char.priority.onlyboss1[6]
	--self:CreatePriorityFrame()
end

function Watcher:GetSixthPriority(info)
	return self.db.char.priority.option1[7] 
end

function Watcher:SetSixthPriority(info, priorityValue)
	self.db.char.priority.option1[7] = priorityValue
	self:SwitchTalents()
	self:CreatePriorityFrame()
end

function Watcher:GetSixthshowraidboss()
	return self.db.char.priority.onlyboss1[7] 
end

function Watcher:SetSixthshowraidboss()
	self.db.char.priority.onlyboss1[7] = not self.db.char.priority.onlyboss1[7]
	--self:CreatePriorityFrame()
end

function Watcher:GetSeventhshowraidboss()
	return self.db.char.priority.onlyboss1[8] 
end

function Watcher:SetSeventhshowraidboss()
	self.db.char.priority.onlyboss1[8] = not self.db.char.priority.onlyboss1[8]
	--self:CreatePriorityFrame()
end

function Watcher:GetSeventhPriority(info)
	return self.db.char.priority.option1[8] 
end

function Watcher:SetSeventhPriority(info, priorityValue)
	self.db.char.priority.option1[8] = priorityValue
	self:SwitchTalents()
	self:CreatePriorityFrame()
end

function Watcher:GetEighthPriority(info)
	return self.db.char.priority.option1[9] 
end

function Watcher:SetEighthPriority(info, priorityValue)
	self.db.char.priority.option1[9] = priorityValue
	self:Print(self.db.char.priority.option1[9])
	self:SwitchTalents()
	self:CreatePriorityFrame()
	end
	
function Watcher:GetEighthshowraidboss()
	return self.db.char.priority.onlyboss1[9] 
end

function Watcher:SetEighthshowraidboss()
	self.db.char.priority.onlyboss1[9] = not self.db.char.priority.onlyboss1[9]
	--self:CreatePriorityFrame()
end


function Watcher:GetFirstPriority2(info)
	return self.db.char.priority.option2[2] 
end

function Watcher:SetFirstPriority2(info, priorityValue)
	self.db.char.priority.option2[2] = priorityValue
	self:SwitchTalents()
	self:CreatePriorityFrame()
end


function Watcher:GetSecondPriority2(info)
	return self.db.char.priority.option2[3] 
end

function Watcher:SetSecondPriority2(info, priorityValue)
	self.db.char.priority.option2[3] = priorityValue
	self:SwitchTalents()
	self:CreatePriorityFrame()
end

function Watcher:GetThirdPriority2(info)
	return self.db.char.priority.option2[4] 
end

function Watcher:SetThirdPriority2(info, priorityValue)
	self.db.char.priority.option2[4] = priorityValue
	self:SwitchTalents()
	self:CreatePriorityFrame()
end

function Watcher:GetFourthPriority2(info)
	return self.db.char.priority.option2[5] 
end

function Watcher:SetFourthPriority2(info, priorityValue)
	self.db.char.priority.option2[5] = priorityValue
	self:SwitchTalents()
	self:CreatePriorityFrame()
end

function Watcher:GetFifthPriority2(info)
	return self.db.char.priority.option2[6] 
end

function Watcher:SetFifthPriority2(info, priorityValue)
	self.db.char.priority.option2[6] = priorityValue
	self:SwitchTalents()
	self:CreatePriorityFrame()
end

function Watcher:GetSixthPriority2(info)
	return self.db.char.priority.option2[7] 
end

function Watcher:SetSixthPriority2(info, priorityValue)
	self.db.char.priority.option2[7] = priorityValue
	self:SwitchTalents()
	self:CreatePriorityFrame()
end

function Watcher:GetSeventhPriority2(info)
	return self.db.char.priority.option2[8] 
end

function Watcher:SetSeventhPriority2(info, priorityValue)
	self.db.char.priority.option2[8] = priorityValue
	self:SwitchTalents()
	self:CreatePriorityFrame()
end

function Watcher:GetEighthPriority2(info)
	return self.db.char.priority.option2[9] 
end

function Watcher:SetEighthPriority2(info, priorityValue)
	self.db.char.priority.option2[9] = priorityValue
	--self:Print(self.db.char.priority.option2[9])
	self:SwitchTalents()
	self:CreatePriorityFrame()
	end

function Watcher:GetEighthshowraidboss2()
	return self.db.char.priority.onlyboss2[9] 
end

function Watcher:SetEighthshowraidboss2()
	self.db.char.priority.onlyboss2[9] = not self.db.char.priority.onlyboss2[9]
	--self:CreatePriorityFrame()
end

function Watcher:GetSixthshowraidboss2()
	return self.db.char.priority.onlyboss2[7] 
end

function Watcher:SetSixthshowraidboss2()
	self.db.char.priority.onlyboss2[7] = not self.db.char.priority.onlyboss2[7]
	--self:CreatePriorityFrame()
end

function Watcher:GetSeventhshowraidboss2()
	return self.db.char.priority.onlyboss2[8] 
end

function Watcher:SetSeventhshowraidboss2()
	self.db.char.priority.onlyboss2[8] = not self.db.char.priority.onlyboss2[8]
	--self:CreatePriorityFrame()
end


function Watcher:GetFifthshowraidboss2()
	return self.db.char.priority.onlyboss2[6] 
end

function Watcher:SetFifthshowraidboss2()
	self.db.char.priority.onlyboss2[6] = not self.db.char.priority.onlyboss2[6]
	--self:CreatePriorityFrame()
end

function Watcher:GetFourthshowraidboss2()
	return self.db.char.priority.onlyboss2[5] 
end

function Watcher:SetFourthshowraidboss2()
	self.db.char.priority.onlyboss2[5] = not self.db.char.priority.onlyboss2[5]
	--self:CreatePriorityFrame()
end

function Watcher:GetThirdshowraidboss2()
	return self.db.char.priority.onlyboss2[4] 
end

function Watcher:SetThirdshowraidboss2()
	self.db.char.priority.onlyboss2[4] = not self.db.char.priority.onlyboss2[4]
	--self:CreatePriorityFrame()
end

function Watcher:GetSecondshowraidboss2()
	return self.db.char.priority.onlyboss2[3] 
end

function Watcher:SetSecondshowraidboss2()
	self.db.char.priority.onlyboss2[3] = not self.db.char.priority.onlyboss2[3]
	self:Print(self.db.char.priority.onlyboss2[3])
	--self:CreatePriorityFrame()
end

function Watcher:GetFirstshowraidboss2()
	return self.db.char.priority.onlyboss2[2] 
end

function Watcher:SetFirstshowraidboss2()
	self.db.char.priority.onlyboss2[2] = not self.db.char.priority.onlyboss2[2]
	self:Print(self.db.char.priority.onlyboss2[2])
	Watcher:SwitchTalents()
end	
	
function Watcher:priorityTextQuery()
	return self.db.char.priority.textshow
end

function Watcher:textsizeQuery()
	return self.db.char.iconfontsize
end

function Watcher:SetFont(info, newValue)
	self.db.char.iconfont = newValue
	self:Print(self.db.char.iconfont)
	self:CreatePriorityFrame()
end

function Watcher:SetFontEffect(info, newValue)
	self.db.char.iconfonteffect = newValue
	self:Print(self.db.char.iconfonteffect)
	self:CreatePriorityFrame()
end

function Watcher:GetFont()
	return self.db.char.iconfont
end

function Watcher:GetFontEffect()
	return self.db.char.iconfonteffect
end

function Watcher:ActivatePriorityText()
	self.db.char.priority.textshow = not self.db.char.priority.textshow
	if self.db.char.priority.textshow then
		for k,v in pairs(self.Priority) do 
		
		self.Priority[k].Text:Show()
		self:Print(L["config_prioritytitle_on"])
		end
	else
		for k,v in pairs(self.Priority) do 
		
		self.Priority[k].Text:Hide()
		self:Print(L["config_prioritytitle_off"])
		end
	end
end

function Watcher:OpenConfig()
	  if InterfaceOptionsFrame_OpenToCategory then
	    InterfaceOptionsFrame_OpenToCategory("Watcher");
    else
        InterfaceOptionsFrame_OpenToFrame("Watcher");
    end
end

function Watcher:hideprimary()
	return self.db.char.hideprimary
end

function Watcher:hidesecondary()
	return self.db.char.hidesecondary
end

function Watcher:sethideprimary()
	self.db.char.hideprimary = not self.db.char.hideprimary
	self:CreatePriorityFrame()
end

function Watcher:sethidesecondary()
	self.db.char.hidesecondary = not self.db.char.hidesecondary
	self:CreatePriorityFrame()
end
