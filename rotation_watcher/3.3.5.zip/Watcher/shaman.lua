--if not Watcher then return end

if select(2, UnitClass('player')) ~= "SHAMAN" then return end

local LBF = LibStub("LibButtonFacade", true)
local L = LibStub("AceLocale-3.0"):GetLocale("Watcher")
local media = LibStub:GetLibrary("LibSharedMedia-3.0");
local C = Watcher.constants

C["Feral Spirit"], _,C["Feral Spirit Icon"] = GetSpellInfo(51533)
C["Shamanistic Rage"], _,C["Shamanistic Rage Icon"] = GetSpellInfo(30823)
C["Lightning Bolt"], _,C["Lightning Bolt Icon"] = GetSpellInfo(49238)
C["Stormstrike"], _,C["Stormstrike Icon"] = GetSpellInfo(17364)
C["Flame Shock"], _,C["Flame Shock Icon"] = GetSpellInfo(49233)
C["Earth Shock"], _,C["Earth Shock Icon"] = GetSpellInfo(49231)
C["Lava Lash"], _,C["Lava Lash Icon"] = GetSpellInfo(60103)
C["Fire Nova"], _,C["Fire Nova Icon"] = GetSpellInfo(61654)
C["Searing Totem"], _,C["Searing Totem Icon"] = GetSpellInfo(58704)
C["Lightning Shield"], _,C["Lightning Shield Icon"] = GetSpellInfo(61570)
C["Maelstrom Weapon"], _,C["Maelstrom Weapon Icon"] = GetSpellInfo(51532)


function Watcher:addClassSpells()
Watcher:FS()
Watcher:SR()
Watcher:LB()
Watcher:SS()
Watcher:FlameShock()
Watcher:EarthShock()
Watcher:ST()
Watcher:LL()
Watcher:LS()
end

function Watcher:FS()
	local def = Watcher.defaults.char.spell
	local name = "Feral Spirit"
	def.spellname[C[name]] = C[name]
	def.name[C[name]] = C[name]
	def.icon[C[name]] =  C[name.." Icon"]
	def.stockspell[C[name]] = true
end	

function Watcher:SR()
	local def = Watcher.defaults.char.spell
	local name = "Shamanistic Rage"
	def.spellname[C[name]] = C[name]
	def.name[C[name]] = C[name]
	def.icon[C[name]] =  C[name.." Icon"]
	def.stockspell[C[name]] = true
end	

function Watcher:LB()
	local def = Watcher.defaults.char.spell
	local name = "Lightning Bolt"
	def.spellname[C[name]] = C[name]
	def.name[C[name]] = C[name]
	def.icon[C[name]] =  C[name.." Icon"]
	def.typedot[C[name]] = true
	def.isbuff[C[name]] = true
	def.isproc[C[name]] = true
	def.countreq[C[name]] = 5
	def.trackspell[C[name]] = C["Maelstrom Weapon"]
	def.stockspell[C[name]] = true
end	
function Watcher:SS()
	local def = Watcher.defaults.char.spell
	local name = "Stormstrike"
	def.spellname[C[name]] = C[name]
	def.name[C[name]] = C[name]
	def.icon[C[name]] =  C[name.." Icon"]
	def.stockspell[C[name]] = true
end	
function Watcher:FlameShock()
	local def = Watcher.defaults.char.spell
	local name = "Flame Shock"
	def.spellname[C[name]] = C[name]
	def.name[C[name]] = C[name]
	def.icon[C[name]] =  C[name.." Icon"]
	def.typedot[C[name]] =  true
	def.trackspell[C[name]] = C[name]
	def.stockspell[C[name]] = true
end	
function Watcher:EarthShock()
	local def = Watcher.defaults.char.spell
	local name = "Earth Shock"
	def.spellname[C[name]] = C[name]
	def.name[C[name]] = C[name]
	def.icon[C[name]] =  C[name.." Icon"]
	def.typedot[C[name]] =  true
	def.trackspell[C[name]] = C[name]
	def.stockspell[C[name]] = true
end	
function Watcher:ST()
	local def = Watcher.defaults.char.spell
	local name = "Searing Totem"
	def.spellname[C[name]] = C[name]
	def.name[C[name]] = C[name]
	def.icon[C[name]] =  C[name.." Icon"]
	def.trackspell[C[name]] = true
	def.nocd[C[name]] = true
	def.stockspell[C[name]] = true
end	
function Watcher:LL()
	local def = Watcher.defaults.char.spell
	local name = "Lava Lash"
	def.spellname[C[name]] = C[name]
	def.name[C[name]] = C[name]
	def.icon[C[name]] =  C[name.." Icon"]

	def.stockspell[C[name]] = true
end	
function Watcher:LS()
	local def = Watcher.defaults.char.spell
	local name = "Lightning Shield"
	def.spellname[C[name]] = C[name]
	def.name[C[name]] = C[name]
	def.icon[C[name]] =  C[name.." Icon"]
	def.stockspell[C[name]] = true
end	