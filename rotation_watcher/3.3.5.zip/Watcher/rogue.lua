if not Watcher then return end

if select(2, UnitClass('player')) ~= "ROGUE" then return end

local LBF = LibStub("LibButtonFacade", true)
local L = LibStub("AceLocale-3.0"):GetLocale("Watcher")
local media = LibStub:GetLibrary("LibSharedMedia-3.0");
local C = Watcher.constants
	
C["Sinister Strike"], _, C["Sinister Strike Icon"], C["Sinister Strike Cost"] = GetSpellInfo(48638)
C["Eviscerate"], _, C["Eviscerate Icon"], C["Eviscerate Cost"] = GetSpellInfo(48668)
C["Slice and Dice"], _, C["Slice and Dice Icon"], C["Slice and Dice Cost"] = GetSpellInfo(6774)

function Watcher:addClassSpells()
	Watcher:SS()
	Watcher:Eviscerate()
	Watcher:SD()
end
		
function Watcher:SS()
	local def = Watcher.defaults.char.spell
	local name = "Sinister Strike"
	def.spellname[C[name]] = C[name]
	def.name[C[name]] = C[name]
	def.icon[C[name]] =  C[name.." Icon"]
	def.stockspell[C[name]] = true
end	
	
function Watcher:Eviscerate()
	local def = Watcher.defaults.char.spell
	local name = "Eviscerate"
	def.spellname[C[name]] = C[name]
	def.name[C[name]] = C[name]
	def.icon[C[name]] =  C[name.." Icon"]
	def.combocost[C[name]] = 3
	def.stockspell[C[name]] = true
end	

function Watcher:SD()
	local def = Watcher.defaults.char.spell
	local name = "Slice and Dice"
	def.spellname[C[name]] = C[name]
	def.name[C[name]] = C[name]
	def.icon[C[name]] =  C[name.." Icon"]
	def.combocost[C[name]] = 1
	def.caster[C[name]] = true
	def.typedot[C[name]] = true
	def.trackspell[C[name]] = C[name]
	def.stockspell[C[name]] = true
end	
	
		
Watcher.priorityTable.name["gcd"] = C["Sinsiter Strike"]
Watcher.priorityTable.icon["gcd"] = C["Sinister Strike"]
Watcher.priorityTable.check["gcd"] =  
	function (FrameName, optionnum) 	
		local start, duration = GetSpellCooldown(C["Sinister Strike"])
		if duration > 0 then
			FrameName:SetAlpha(1)
			local timeleft = start + duration - GetTime()
			Watcher:MoveGCD(FrameName, timeleft)
			return
		end
		if start == 0 then
			FrameName:SetAlpha(0)
		end
	end 
