if not Watcher then return end

if select(2, UnitClass('player')) ~= "DEATHKNIGHT" then return end

local LBF = LibStub("LibButtonFacade", true)
local L = LibStub("AceLocale-3.0"):GetLocale("Watcher")
local media = LibStub:GetLibrary("LibSharedMedia-3.0");
local C = Watcher.constants
	
C["Plague Strike"], _, C["Plague Strike Icon"] = GetSpellInfo(45462)
C["Death Strike"], _, C["Death Strike Icon"] = GetSpellInfo(49998)
C["Blood Strike"], _, C["Blood Strike Icon"] = GetSpellInfo(45902)
C["Frost Strike"], _, C["Frost Strike Icon"] = GetSpellInfo(49143)
C["Scourge Strike"], _, C["Scourge Strike Icon"] = GetSpellInfo(55090)
C["Icy Touch"], _, C["Icy Touch Icon"] = GetSpellInfo(45477)
C["Death Coil"], _, C["Death Coil Icon"] = GetSpellInfo(47541)
C["Horn of Winter"], _, C["Horn of Winter Icon"] = GetSpellInfo(57330)
C["Blood Plague"], _, C["Blood Plague Icon"] = GetSpellInfo(55078)
C["Frost Fever"], _, C["Frost Fever Icon"] = GetSpellInfo(55095)

function Watcher:addClassSpells()
Watcher:PS()
Watcher:DS()
Watcher:BS()
Watcher:FS()
Watcher:SS()
Watcher:IcyTouch()
Watcher:DC()
Watcher:HoWS()
Watcher:HoW()
end
		
function Watcher:PS()
	local def = Watcher.defaults.char.spell
	local name = "Plague Strike"
	def.spellname[C[name]] = C[name]
	def.name[C[name]] = C[name]
	def.icon[C[name]] =  C[name.." Icon"]
	def.typedot[C[name]] = true
	def.trackspell[C[name]] = C["Blood Plague"]
	def.stockspell[C[name]] = true
end	

function Watcher:DS()
	local def = Watcher.defaults.char.spell
	local name = "Death Strike"
	def.spellname[C[name]] = C[name]
	def.name[C[name]] = C[name]
	def.icon[C[name]] =  C[name.." Icon"]
	def.stockspell[C[name]] = true
end	

function Watcher:BS()
	local def = Watcher.defaults.char.spell
	local name = "Blood Strike"
	def.spellname[C[name]] = C[name]
	def.name[C[name]] = C[name]
	def.icon[C[name]] =  C[name.." Icon"]
	def.stockspell[C[name]] = true
end	

function Watcher:FS()
	local def = Watcher.defaults.char.spell
	local name = "Frost Strike"
	def.spellname[C[name]] = C[name]
	def.name[C[name]] = C[name]
	def.icon[C[name]] =  C[name.." Icon"]
	def.stockspell[C[name]] = true
end	

function Watcher:SS()
	local def = Watcher.defaults.char.spell
	local name = "Scourge Strike"
	def.spellname[C[name]] = C[name]
	def.name[C[name]] = C[name]
	def.icon[C[name]] =  C[name.." Icon"]
	def.stockspell[C[name]] = true
end	

function Watcher:IcyTouch()
	local def = Watcher.defaults.char.spell
	local name = "Icy Touch"
	def.spellname[C[name]] = C[name]
	def.name[C[name]] = C[name]
	def.icon[C[name]] =  C[name.." Icon"]
	def.typedot[C[name]] = true
	def.trackspell[C[name]] = C["Frost Fever"]
	def.stockspell[C[name]] = true
end	

function Watcher:DC()
	local def = Watcher.defaults.char.spell
	local name = "Death Coil"
	def.spellname[C[name]] = C[name]
	def.name[C[name]] = C[name]
	def.icon[C[name]] =  C[name.." Icon"]
	def.stockspell[C[name]] = true
end	

function Watcher:HoWS()
	local def = Watcher.defaults.char.spell
	local name = "Horn of Winter"
	def.spellname[C[name]] = C[name]
	def.name[C[name]] = C[name].. " Spam"
	def.icon[C[name]] =  C[name.." Icon"]
	def.stockspell[C[name]] = true
end	

function Watcher:HoW()
	local def = Watcher.defaults.char.spell
	local name = "Horn of Winter"
	def.spellname[C[name]] = C[name]
	def.name[C[name]] = C[name]
	def.icon[C[name]] =  C[name.." Icon"]
	def.typedot[C[name]] = true
	def.isbuff[C[name]] = true
	def.trackspell[C[name]] = C[name]
	def.stockspell[C[name]] = true
end	
