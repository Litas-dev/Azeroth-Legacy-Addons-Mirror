if not Watcher then return end

if select(2, UnitClass('player')) ~= "WARRIOR" then return end

local LBF = LibStub("LibButtonFacade", true)
local L = LibStub("AceLocale-3.0"):GetLocale("Watcher")
local media = LibStub:GetLibrary("LibSharedMedia-3.0");
local C = Watcher.constants
	
C["Shield Slam"], _, C["Shield Slam Icon"], C["Shield Slam Cost"] = GetSpellInfo(47488)
C["Revenge"], _, C["Revenge Icon"], C["Revenge Cost"] = GetSpellInfo(57823)
C["Hamstring"], _, C["Hamstring Icon"], C["Hamstring Cost"] = GetSpellInfo(1715)
C["Devastate"], _, C["Devastate Icon"], C["Devastate Cost"] = GetSpellInfo(47498)
C["Concussion Blow"], _, C["Concussion Blow Icon"], C["Concussion Blow Cost"] = GetSpellInfo(12809)
C["Shockwave"], _, C["Shockwave Icon"], C["Shockwave Cost"] = GetSpellInfo(46968)
C["Rend"], _, C["Rend Icon"], C["Rend Cost"] = GetSpellInfo(47465)
C["Cleave"], _, C["Cleave Icon"], C["Cleave Cost"] = GetSpellInfo(845)
C["Thunderclap"], _, C["Thunderclap Icon"], C["Thunderclap Cost"] = GetSpellInfo(47502)
C["Mortal Strike"], _, C["Mortal Strike Icon"], C["Mortal Strike Cost"] = GetSpellInfo(47486)
C["Heroic Strike"], _, C["Heroic Strike Icon"], C["Heroic Strike Cost"] = GetSpellInfo(47450)
C["Slam"], _, C["Slam Icon"], C["Slam Cost"] = GetSpellInfo(47475)
C["Whirlwind"], _, C["Whirlwind Icon"], C["Whirlwind Cost"] = GetSpellInfo(1680)
C["Bloodthirst"], _, C["Bloodthirst Icon"], C["Bloodthirst Cost"] = GetSpellInfo(23881)
C["Overpower"], _, C["Overpower Icon"], C["Overpower Cost"] = GetSpellInfo(7384)
C["Execute"], _, C["Execute Icon"], C["Execute Cost"] = GetSpellInfo(47471)
C["Death Wish"], _, C["Death Wish Icon"], C["Death Wish Cost"] = GetSpellInfo(12292)
C["Bladestorm"], _, C["Bladestorm Icon"], C["Bladestorm Cost"] = GetSpellInfo(46924)
C["Sunder Armor"], _, C["Sunder Armor Icon"], C["Sunder Armor Cost"] = GetSpellInfo(2687)
C["Sunder Armor"], _, C["Sunder Armor Icon"], C["Sunder Armor Cost"] = GetSpellInfo(7386)
C["Berserker Rage"], _, C["Berserker Rage Icon"], C["Berserker Rage Cost"] = GetSpellInfo(18499)
C["Taste for Blood"] = GetSpellInfo(56638)
C["Slam!"] = GetSpellInfo(46916)
C["Sudden Death"] = GetSpellInfo(52437)

function Watcher:addClassSpells()
Watcher:SS()
Watcher:Revenge()
Watcher:Rend()
Watcher:HS()
Watcher:Devastate()
Watcher:BR()
Watcher:CB()
Watcher:Shockwave()
Watcher:Bladestorm()
Watcher:DW()
Watcher:MS()
Watcher:HamS()
Watcher:Bloodthirst()
Watcher:WW()
Watcher:Overpower()
Watcher:Slam()
Watcher:SlamI()
Watcher:Execute()
Watcher:SA()
Watcher:Cleave()
Watcher:Thunderclap()
end

function Watcher:SS()
	local def = Watcher.defaults.char.spell
	local name = "Shield Slam"
	def.spellname[C[name]] = C[name]
	def.name[C[name]] = C[name]
	def.icon[C[name]] =  C[name.." Icon"]
	def.stockspell[C[name]] = true
end	
	
function Watcher:Revenge()
	local def = Watcher.defaults.char.spell
	local name = "Revenge"
	def.spellname[C[name]] = C[name]
	def.name[C[name]] = C[name]
	def.icon[C[name]] =  C[name.." Icon"]
	def.stockspell[C[name]] = true
end	

function Watcher:Rend()
	local def = Watcher.defaults.char.spell
	local name = "Rend"
	def.spellname[C[name]] = C[name]
	def.name[C[name]] = C[name]
	def.icon[C[name]] =  C[name.." Icon"]
	def.typedot[C[name]] = true
	def.trackspell[C[name]] = C[name]
	def.stockspell[C[name]] = true
end	

function Watcher:HamS()
	local def = Watcher.defaults.char.spell
	local name = "Hamstring"
	def.spellname[C[name]] = C[name]
	def.name[C[name]] = C[name]
	def.icon[C[name]] =  C[name.." Icon"]
	def.typedot[C[name]] = true
	def.trackspell[C[name]] = C[name]
	def.stockspell[C[name]] = true
end			

function Watcher:Devastate()
	local def = Watcher.defaults.char.spell
	local name = "Devastate"
	def.spellname[C[name]] = C[name]
	def.name[C[name]] = C[name]
	def.icon[C[name]] =  C[name.." Icon"]
	def.stockspell[C[name]] = true
end	
	
function Watcher:BR()
	local def = Watcher.defaults.char.spell
	local name = "Berserker Rage"
	def.spellname[C[name]] = C[name]
	def.name[C[name]] = C[name]
	def.icon[C[name]] =  C[name.." Icon"]
	def.stockspell[C[name]] = true
end	

function Watcher:CB()
	local def = Watcher.defaults.char.spell
	local name = "Concussion Blow"
	def.spellname[C[name]] = C[name]
	def.name[C[name]] = C[name]
	def.icon[C[name]] =  C[name.." Icon"]
	def.stockspell[C[name]] = true
end	
	
function Watcher:Shockwave()
	local def = Watcher.defaults.char.spell
	local name = "Shockwave"
	def.spellname[C[name]] = C[name]
	def.name[C[name]] = C[name]
	def.icon[C[name]] =  C[name.." Icon"]
	def.stockspell[C[name]] = true
end	
	
function Watcher:Bladestorm()
	local def = Watcher.defaults.char.spell
	local name = "Bladestorm"
	def.spellname[C[name]] = C[name]
	def.name[C[name]] = C[name]
	def.icon[C[name]] =  C[name.." Icon"]
	def.stockspell[C[name]] = true
end	
	
function Watcher:DW()
	local def = Watcher.defaults.char.spell
	local name = "Death Wish"
	def.spellname[C[name]] = C[name]
	def.name[C[name]] = C[name]
	def.icon[C[name]] =  C[name.." Icon"]
	def.stockspell[C[name]] = true
end	
	
function Watcher:MS()
	local def = Watcher.defaults.char.spell
	local name = "Mortal Strike"
	def.spellname[C[name]] = C[name]
	def.name[C[name]] = C[name]
	def.icon[C[name]] =  C[name.." Icon"]
	def.stockspell[C[name]] = true
end	

function Watcher:HS()
	local def = Watcher.defaults.char.spell
	local name = "Heroic Strike"
	def.spellname[C[name]] = C[name]
	def.name[C[name]] = C[name]
	def.icon[C[name]] =  C[name.." Icon"]
	def.powerthresh[C[name]] = 0
	def.stockspell[C[name]] = true
end	
	
function Watcher:Bloodthirst()
	local def = Watcher.defaults.char.spell
	local name = "Bloodthirst"
	def.spellname[C[name]] = C[name]
	def.name[C[name]] = C[name]
	def.icon[C[name]] =  C[name.." Icon"]
	def.stockspell[C[name]] = true
end	

function Watcher:WW()
	local def = Watcher.defaults.char.spell
	local name = "Whirlwind"
	def.spellname[C[name]] = C[name]
	def.name[C[name]] = C[name]
	def.icon[C[name]] =  C[name.." Icon"]
	def.stockspell[C[name]] = true
end	
	
function Watcher:Overpower()
	local def = Watcher.defaults.char.spell
	local name = "Overpower"
	def.spellname[C[name]] = C[name]
	def.name[C[name]] = C[name]
	def.icon[C[name]] =  C[name.." Icon"]
	def.stockspell[C[name]] = true
end	

function Watcher:Slam()
	local def = Watcher.defaults.char.spell
	local name = "Slam"
	def.spellname[C[name]] = C[name]
	def.name[C[name]] = C[name]
	def.icon[C[name]] =  C[name.." Icon"]
	def.stockspell[C[name]] = true
end	
	
function Watcher:SlamI()
	local def = Watcher.defaults.char.spell
	local name = "Slam"
	def.spellname[name.."!"] = C[name]
	def.name[name.."!"] = C[name].. " (Instant)" --L[name.." Instant"]
	def.icon[name.."!"] =  C[name.." Icon"]
	def.typedot[name.."!"] =  true
	def.isbuff[name.."!"] =  true
	def.caster[name.."!"] =  true
	def.isproc[name.."!"] =  true
	def.trackspell[name.."!"] =  C["Slam!"]
	def.stockspell[name.."!"] = true
end	
	
function Watcher:Execute()
	local def = Watcher.defaults.char.spell
	local name = "Execute"
	def.spellname[C[name]] = C[name]
	def.name[C[name]] = C[name]
	def.icon[C[name]] =  C[name.." Icon"]
	def.stockspell[C[name]] = true
end	

function Watcher:SA()
	local def = Watcher.defaults.char.spell
	local name = "Sunder Armor"
	def.spellname[C[name]] = C[name]
	def.name[C[name]] = C[name]
	def.icon[C[name]] =  C[name.." Icon"]
	def.typedot[C[name]] = true
	def.trackspell[C[name]] = C[name]
	def.dotthreshold[C[name]] = 1.5
	def.stockspell[C[name]] = true
end	
	
function Watcher:Cleave()
	local def = Watcher.defaults.char.spell
	local name = "Cleave"
	def.spellname[C[name]] = C[name]
	def.name[C[name]] = C[name]
	def.icon[C[name]] =  C[name.." Icon"]
	def.stockspell[C[name]] = true
end	
		
function Watcher:Thunderclap()
	local def = Watcher.defaults.char.spell
	local name = "Thunderclap"
	def.spellname[C[name]] = C[name]
	def.name[C[name]] = C[name]
	def.icon[C[name]] =  C[name.." Icon"]
	def.stockspell[C[name]] = true
end	
	
			
Watcher.priorityTable.name["gcd"] = "GCD"
Watcher.priorityTable.icon["gcd"] = C["Heroic Strike Icon"]
Watcher.priorityTable.check["gcd"] =  
	function (FrameName, optionnum) 	
		local start, duration = GetSpellCooldown(C["Heroic Strike"])
		if duration == nil  or start == nil then
		duration = 0
		start = 0
		end
		if duration > 0 then
			FrameName:SetAlpha(1)
			local timeleft = start + duration - GetTime()
			Watcher:MoveGCD(FrameName, timeleft)
			return
		end
		if start == 0 then

			FrameName:SetAlpha(0)
		end
	end 
