if not Watcher then return end

if select(2, UnitClass('player')) ~= "DRUID" then return end

local LBF = LibStub("LibButtonFacade", true)
local L = LibStub("AceLocale-3.0"):GetLocale("Watcher")
local media = LibStub:GetLibrary("LibSharedMedia-3.0");
local C = Watcher.constants



C["Mangle"], _, C["Mangle Icon"] = GetSpellInfo(33876)
C["Rake"], _, C["Rake Icon"] = GetSpellInfo(48574)
C["Rip"], _, C["Rip Icon"] = GetSpellInfo(49800)
C["Ferocious Bite"], _, C["Ferocious Bite Icon"] = GetSpellInfo(48577)
C["Moonfire"], _, C["Moonfire Icon"] = GetSpellInfo(48463)
C["Ferocious Bite"], _, C["Ferocious Bite Icon"] = GetSpellInfo(48577)
C["Savage Roar"], _, C["Savage Roar Icon"] = GetSpellInfo(52610)
C["Claw"], _, C["Claw Icon"] = GetSpellInfo(48570)
C["Shred"], _, C["Shred Icon"] = GetSpellInfo(48572)

C["Faerie Fire"], _,C["Faerie Fire Icon"] = GetSpellInfo(16857)
function Watcher:addClassSpells()
Watcher:SR()
Watcher:Rake()
Watcher:FF()
Watcher:Rip()
Watcher:Claw()
Watcher:Shred()
Watcher:FB()
Watcher:Mangle()
Watcher:MDOT()
end

function Watcher:SR()
	local def = Watcher.defaults.char.spell
	local name = "Savage Roar"
	def.spellname[C[name]] = C[name]
	def.name[C[name]] = C[name]
	def.trackspell[C[name]] = C[name]
	def.icon[C[name]] =  C[name.." Icon"]
	
	def.typedot[C[name]] = true
	def.combocost[C[name]] = 1
	def.stockspell[C[name]] = true
end		

function Watcher:Rake()
	local def = Watcher.defaults.char.spell
	local name = "Rake"
	def.spellname[C[name]] = C[name]
	def.name[C[name]] = C[name]
	def.trackspell[C[name]] = C[name]
	def.icon[C[name]] =  C[name.." Icon"]
	
	def.typedot[C[name]] = true
	def.stockspell[C[name]] = true
end	
	
function Watcher:FF()
	local def = Watcher.defaults.char.spell
	local name = "Faerie Fire"
	def.spellname[C[name]] = C[name]
	def.name[C[name]] = C[name]
	def.trackspell[C[name]] = C[name]
	def.icon[C[name]] =  C[name.." Icon"]
	
	def.typedot[C[name]] = true
	def.stockspell[C[name]] = true
end	

function Watcher:Rip()
	local def = Watcher.defaults.char.spell
	local name = "Rip"
	def.spellname[C[name]] = C[name]
	def.name[C[name]] = C[name]
	def.trackspell[C[name]] = C[name]
	def.icon[C[name]] =  C[name.." Icon"]
	
	def.typedot[C[name]] = true
	def.combocost[C[name]] = 5
	def.stockspell[C[name]] = true
end	
	
function Watcher:Claw()
	local def = Watcher.defaults.char.spell
	local name = "Claw"
	def.spellname[C[name]] = C[name]
	def.name[C[name]] = C[name]
	def.icon[C[name]] =  C[name.." Icon"]
	def.stockspell[C[name]] = true
end	
		
function Watcher:Shred()
	local def = Watcher.defaults.char.spell
	local name = "Shred"
	def.spellname[C[name]] = C[name]
	def.name[C[name]] = C[name]
	def.icon[C[name]] =  C[name.." Icon"]
	def.stockspell[C[name]] = true
end	

function Watcher:FB()
	local def = Watcher.defaults.char.spell
	local name = "Ferocious Bite"
	def.spellname[C[name]] = C[name]
	def.name[C[name]] = C[name]
	def.icon[C[name]] =  C[name.." Icon"]
	def.stockspell[C[name]] = true
	def.combocost[C[name]] = 5
end	
	
function Watcher:Mangle()
	local def = Watcher.defaults.char.spell
	local name = "Mangle"
	def.spellname[C[name]] = C[name]
	def.name[C[name]] = C[name]
	def.icon[C[name]] =  C[name.." Icon"]
	def.stockspell[C[name]] = true
end	
	
function Watcher:MDOT()
	local def = Watcher.defaults.char.spell
	local name = "Mangle"
	def.spellname[C[name].."DOT"] = C[name]
	def.typedot[C[name].."DOT"] = true
	def.trackspell[C[name].."DOT"] = C[name]
	def.name[C[name].."DOT"] = C[name].." DOT"
	def.icon[C[name].."DOT"] =  C[name.." Icon"]
	def.stockspell[C[name].."DOT"] = true
end	
			
		
Watcher.priorityTable.name["gcd"] = "GCD"
Watcher.priorityTable.icon["gcd"] = C["Moonfire Icon"]
Watcher.priorityTable.check["gcd"] =  
	function (FrameName, optionnum) 	
		local start, duration = GetSpellCooldown(C["Moonfire"])
		if duration > 0 then
			FrameName:SetAlpha(1)
			local timeleft = start + duration - GetTime()
			Watcher:MoveGCD(FrameName, timeleft)
			return
		end
		if start == 0 then
			FrameName:SetAlpha(0)
		end
	end 