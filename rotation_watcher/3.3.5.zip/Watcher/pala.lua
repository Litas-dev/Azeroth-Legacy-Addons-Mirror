if not Watcher then return end

if select(2, UnitClass('player')) ~= "PALADIN" then return end

local LBF = LibStub("LibButtonFacade", true)
local L = LibStub("AceLocale-3.0"):GetLocale("Watcher")
local media = LibStub:GetLibrary("LibSharedMedia-3.0");
local C = Watcher.constants
	
C["Crusader Strike"], _, C["Crusader Strike Icon"] = GetSpellInfo(35395)
C["Blessing of Might"], _, C["Blessing of Might Icon"] = GetSpellInfo(48932)
C["Hammer of Wrath"], _, C["Hammer of Wrath Icon"] = GetSpellInfo(48806)
C["Holy Shield"], _, C["Holy Shield Icon"] = GetSpellInfo(48952)
C["Hammer of the Righteous"], _, C["Hammer of the Righteous Icon"] = GetSpellInfo(53595)
C["Divine Storm"], _, C["Divine Storm Icon"] = GetSpellInfo(53385)
C["Judgement of Wisdom"], _, C["Judgement of Wisdom Icon"] = GetSpellInfo(53408)
C["Judgement of Light"], _, C["Judgement of Light Icon"] = GetSpellInfo(20271)
C["Holy Wrath"], _, C["Holy Wrath Icon"] = GetSpellInfo(2812)
C["Avenging Wrath"], _, C["Avenging Wrath Icon"] = GetSpellInfo(31884)
C["Exorcism"], _, C["Exorcism Icon"] = GetSpellInfo(48801)
C["Consecration"], _, C["Consecration Icon"] = GetSpellInfo(48819)
C["Avenger's Shield"], _, C["Avenger's Shield Icon"] = GetSpellInfo(48827)
C["Shield of Righteousness"], _, C["Shield of Righteousness Icon"] = GetSpellInfo(61411)

function Watcher:addClassSpells()
Watcher:CS()
Watcher:SOR()
Watcher:HS()
Watcher:Consecration()
Watcher:AW()
Watcher:HOW()
Watcher:HOR()
Watcher:JOL()
Watcher:JOW()
Watcher:HW()
Watcher:DS()
Watcher:Ex()
Watcher:ExI()
Watcher:AS()
end
		
function Watcher:CS()
	local def = Watcher.defaults.char.spell
	local name = "Crusader Strike"
	def.spellname[C[name]] = C[name]
	def.name[C[name]] = C[name]
	def.icon[C[name]] =  C[name.." Icon"]
	def.stockspell[C[name]] = true
end	
	
function Watcher:SOR()
	local def = Watcher.defaults.char.spell
	local name = "Shield of Righteousness"
	def.spellname[C[name]] = C[name]
	def.name[C[name]] = C[name]
	def.icon[C[name]] =  C[name.." Icon"]
	def.stockspell[C[name]] = true
end	
	
function Watcher:HS()
	local def = Watcher.defaults.char.spell
	local name = "Holy Shield"
	def.spellname[C[name]] = C[name]
	def.name[C[name]] = C[name]
	def.icon[C[name]] =  C[name.." Icon"]
	def.stockspell[C[name]] = true
end	

function Watcher:Consecration()
	local def = Watcher.defaults.char.spell
	local name = "Consecration"
	def.spellname[C[name]] = C[name]
	def.name[C[name]] = C[name]
	def.icon[C[name]] =  C[name.." Icon"]
	def.stockspell[C[name]] = true
end	
		
function Watcher:AW()
	local def = Watcher.defaults.char.spell
	local name = "Avenging Wrath"
	def.spellname[C[name]] = C[name]
	def.name[C[name]] = C[name]
	def.icon[C[name]] =  C[name.." Icon"]
	def.stockspell[C[name]] = true
end	

function Watcher:HOW()
	local def = Watcher.defaults.char.spell
	local name = "Hammer of Wrath"
	def.spellname[C[name]] = C[name]
	def.name[C[name]] = C[name]
	def.icon[C[name]] =  C[name.." Icon"]
	def.stockspell[C[name]] = true
end		
	
function Watcher:HOR()
	local def = Watcher.defaults.char.spell
	local name = "Hammer of the Righteous"
	def.spellname[C[name]] = C[name]
	def.name[C[name]] = C[name]
	def.icon[C[name]] =  C[name.." Icon"]
	def.stockspell[C[name]] = true
end	
	
function Watcher:JOL()
	local def = Watcher.defaults.char.spell
	local name = "Judgement of Light"
	def.spellname[C[name]] = C[name]
	def.name[C[name]] = C[name]
	def.icon[C[name]] =  C[name.." Icon"]
	def.stockspell[C[name]] = true
end	
	
function Watcher:JOW()
	local def = Watcher.defaults.char.spell
	local name = "Judgement of Wisdom"
	def.spellname[C[name]] = C[name]
	def.name[C[name]] = C[name]
	def.icon[C[name]] =  C[name.." Icon"]
	def.stockspell[C[name]] = true
end	

function Watcher:HW()
	local def = Watcher.defaults.char.spell
	local name = "Holy Wrath"
	def.spellname[C[name]] = C[name]
	def.name[C[name]] = C[name]
	def.icon[C[name]] =  C[name.." Icon"]
	def.stockspell[C[name]] = true
end	
		
function Watcher:DS()
	local def = Watcher.defaults.char.spell
	local name = "Divine Storm"
	def.spellname[C[name]] = C[name]
	def.name[C[name]] = C[name]
	def.icon[C[name]] =  C[name.." Icon"]
	def.stockspell[C[name]] = true
end	
	
function Watcher:Ex()
	local def = Watcher.defaults.char.spell
	local name = "Exorcism"
	def.spellname[C[name]] = C[name]
	def.name[C[name]] = C[name]
	def.icon[C[name]] =  C[name.." Icon"]
	def.stockspell[C[name]] = true
end	

function Watcher:ExI()
	local def = Watcher.defaults.char.spell
	local name = "Exorcism"
	def.spellname[C[name].." Instant"] = C[name]
	def.name[C[name].." Instant"] = C[name].." Instant"
	def.icon[C[name].." Instant"] =  C[name.." Icon"]
	def.typedot[C[name].." Instant"] =  true
	def.trackspell[C[name].." Instant"] =  "The Art of War"
	def.isproc[C[name].." Instant"] =  true
	def.isbuff[C[name].." Instant"] =  true
	def.stockspell[C[name].." Instant"] = true
end	
		
function Watcher:AS()
	local def = Watcher.defaults.char.spell
	local name = "Avenger's Shield"
	def.spellname[C[name]] = C[name]
	def.name[C[name]] = C[name]
	def.icon[C[name]] =  C[name.." Icon"]
	def.stockspell[C[name]] = true
end	
		
Watcher.priorityTable.name["gcd"] = "GCD"--C["Blessing of Might"]
Watcher.priorityTable.icon["gcd"] = C["Blessing of Might"]
Watcher.priorityTable.check["gcd"] =  
	function (FrameName, optionnum) 	
		local start, duration = GetSpellCooldown(C["Blessing of Might"])
		if duration > 0 then
			FrameName:SetAlpha(1)
			local timeleft = start + duration - GetTime()
			Watcher:MoveGCD(FrameName, timeleft)
			return
		end
		if start == 0 then
			FrameName:SetAlpha(0)
		end
	end 
