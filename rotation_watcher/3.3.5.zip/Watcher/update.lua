if not Watcher then return end

local L = LibStub("AceLocale-3.0"):GetLocale("Watcher")
local media = LibStub:GetLibrary("LibSharedMedia-3.0");
local C = Watcher.constants -- Defined in Watcher LUA no locale needed.


	function Watcher:expires(expiresin, dotthreshold, typedot, typeShortDot, buffproc, count, countreq)
		if buffproc and expiresin > 0 then
			return true
		elseif count < countreq  and expiresin > dotthreshold then
			return true	
		elseif typeShortDot and expiresin > dotthreshold then
			return true
		elseif typedot and expiresin > dotthreshold then
			return true
		end
			return false
	end

	function Watcher:countcheck(count, countreq, timeleft, buffproc)

		if countreq == 0 or countreq == 1 then
			return true
		elseif count < countreq  and not buffproc or timeleft > 0 then
			return true
		elseif count >= countreq or timeleft > 0 then
			return true
		end
		return false
	end

	function Watcher:Power(power, powerthreshold, negthreshold)
	if not negthreshold then
	return power >= powerthreshold
	end
	return power <= powerthreshold
	end
	
	function Watcher:UpdateSpell(FrameName, optionnum, typedot, dotfunction, typeShortDot, shortDotTime, usehealthpc, SpellName, powerthreshold, countreq, dotthreshold, combocost, isproc, findcount, negthreshold, noCD) 
		if negthreshold == nil then
		negthreshold = false end
		local usable = IsUsableSpell(SpellName)
		local expiresin
		local Count = 0
		powerthreshold = powerthreshold / 100
		if combocost == nil then combocost = 0 end
		local buffproc = true
		local typeaura = false
		if typedot and isproc then
			buffproc = dotfunction
			
			Count = findcount
		elseif typedot and not typeShortDot then
			
			--self:Print(SpellName)
			expiresin, Count = dotfunction
			if Count == nil then 
				Count = findcount or 0 
			end
			if expiresin == true then
				typeaura = true
			end
		elseif typeShortDot then
			expiresin = shortDotTime - GetTime()
			Count = 0
		else
			expiresin = 0
			Count = 0
		end
		
		local start, duration = GetSpellCooldown(SpellName)
		if start == nil then
		start = 0
		duration = 0
		end
		if Watcher:bossmob(optionnum) and not typeaura and buffproc and ((Watcher:Power(Watcher.power, powerthreshold, negthreshold) and noCD) or not noCD ) and Count >= countreq then
			local usable = IsUsableSpell(SpellName)
			local timeleft = start + duration - GetTime()
			if not isproc and not noCD then 
				if timeleft < expiresin and not isproc and not noCD then
					timeleft = expiresin
				end
			end
			
			if timeleft <= 0 then 
				timeleft = 0
				FrameName.Text:Hide()
			elseif Watcher.db.char.priority.textshow then
					FrameName.Text:SetText(Watcher:DurationString(timeleft))
					FrameName.Text:Show()
			end
			Watcher.timeLeft[optionnum] = timeleft
			Watcher.timeLeft[optionnum+8] = timeleft
			if timeleft <= dotthreshold then timeleft = 0 
			else timeleft = timeleft - dotthreshold end

			if timeleft > self.db.char.indices[table.getn(self.db.char.indices)]then
				FrameName:SetAlpha(0)
				Watcher.timeLeft[optionnum] = -1
				Watcher.timeLeft[optionnum+self.db.char.priority.num] = -1
				return
			end
			if usable == 1 and Watcher:Power(Watcher.power, powerthreshold, negthreshold)  and Watcher.combo >= combocost then
				Watcher.timeLeft[ optionnum+self.db.char.priority.num] = -1
				Watcher:MoveIcon(FrameName, timeleft, optionnum)
				--FrameName:SetAlpha(1)
				Watcher:ColorFrame(FrameName)--FrameName.texture:SetDesaturated(nil)
			else 
				Watcher.timeLeft[optionnum] = -1
				Watcher:MoveIcon(FrameName, timeleft,  optionnum+self.db.char.priority.num)
				--FrameName.texture:SetDesaturated(1)
				Watcher:ColorUFrame(FrameName)
				--FrameName.texture:SetVertexColor(0.5,0.5,0.5)--FrameName:SetAlpha(0.3)
			end
			
			
			return
			
			--[[FrameName.Text:Hide()
			if usable == 1 and Watcher:Power(Watcher.power, powerthreshold, negthreshold)  and Watcher.combo >= combocost then
					Watcher.timeLeft[optionnum] = 0
					Watcher.timeLeft[ optionnum+self.db.char.priority.num] = -1
					Watcher:MoveIcon(FrameName, 0, optionnum)
					FrameName:SetAlpha(1)
					FrameName.texture:SetDesaturated(nil)
			else 
					Watcher.timeLeft[optionnum] = -1
					Watcher.timeLeft[ optionnum+self.db.char.priority.num] = 0
					Watcher:MoveIcon(FrameName, 0, optionnum+self.db.char.priority.num)
					FrameName.texture:SetDesaturated(1)--SetAlpha(0.3)
					--FrameName.texture:SetVertexColor(0.2,0.2,0.2)--SetAlpha(0.3)
			end
			return]]
		end 
		FrameName:SetAlpha(0)
		if self.db.char.showbars then
			FrameName.statusbar:SetAlpha(0)
		end
		Watcher.timeLeft[optionnum] = -1
		Watcher.timeLeft[optionnum+self.db.char.priority.num] = -1
	end
	
	
	function Watcher:MoveIcon(FrameName, timeleft, optionnum)
		local Offset = 0
		FrameName:SetFrameLevel(self.db.char.priority.num*30- ((optionnum-1)*10))
		if self.db.char.stackmoving or timeleft == 0 and optionnum > 2 then
			for i = 2, optionnum - 1 do
				if Watcher.timeLeft[i] >= 0 then
					if ((timeleft) - Watcher.timeLeft[i]) >= -1.5 and ((timeleft) - Watcher.timeLeft[i]) <=1.50 then
						Offset = Offset + 1
					end
				end
			end
		end
		if self.db.char.showbars then
			local movingprio = 0
			local movingnum = 0
			for i=2, self.db.char.priority.num do
				if Watcher.timeLeft[i] > 1.5 then movingnum = movingnum + 1 end
			end
			for i=optionnum, self.db.char.priority.num do
				if Watcher.timeLeft[i] > 1.5 then movingprio = movingprio + 1 end
			end
			if timeleft <= 1.5 then
				FrameName.statusbar:SetAlpha(0)
			else
				FrameName.statusbar:SetAlpha(self.db.char.baralpha)
			end
			local offset
			if timeleft <= self.db.char.priority.maxtime then
				offset = timeleft
			else
				offset = self.db.char.priority.maxtime
			end
			FrameName.statusbar:ClearAllPoints()	
			if self.db.char.growdir == "left" or self.db.char.growdir == "right" then
				FrameName.statusbar:SetWidth(offset*Watcher.db.char.priority.IconSize/1.5)
				FrameName.statusbar:SetHeight(Watcher.db.char.priority.IconSize/movingnum)
				FrameName.statusbar:SetPoint("BOTTOMLEFT", self.PriorityFrame, "BOTTOMLEFT", self.db.char.priority.IconSize, self.db.char.priority.IconSize*(movingnum-movingprio)/movingnum)
			else
				FrameName.statusbar:SetWidth(Watcher.db.char.priority.IconSize/movingnum - 1)
				FrameName.statusbar:SetHeight(offset*Watcher.db.char.priority.IconSize/1.5)
				FrameName.statusbar:SetPoint("BOTTOMLEFT", self.PriorityFrame, "BOTTOMLEFT", -self.db.char.priority.IconSize*(movingnum-movingprio)/movingnum, self.db.char.priority.IconSize)
			end
		end
		local stackPos = (Watcher.db.char.priority.IconSize * 0.2) * (Offset)
		local barPos = self:LogPosition(timeleft)
		if self.db.char.growdir == "up" then 
			FrameName:SetPoint("BOTTOMRIGHT", Watcher.PriorityFrame, "BOTTOMRIGHT",  -stackPos , barPos)
		elseif self.db.char.growdir == "down" then 
			FrameName:SetPoint("TOPLEFT", Watcher.PriorityFrame, "TOPLEFT",  -stackPos , -barPos)
		elseif self.db.char.growdir == "right" then 
			FrameName:SetPoint("BOTTOMLEFT", Watcher.PriorityFrame, "BOTTOMLEFT",  barPos , stackPos)
		elseif self.db.char.growdir == "left" then 
			FrameName:SetPoint("BOTTOMRIGHT", Watcher.PriorityFrame, "BOTTOMRIGHT",  -barPos, stackPos)
		end
	end
	
	
	function Watcher:MoveGCD(FrameName, timeleft)
		local stackPos = 0
		local barPos = self:LogPosition(timeleft)
				if self.db.char.growdir == "up" then 
			FrameName:SetPoint("BOTTOMRIGHT", Watcher.PriorityFrame, "BOTTOMRIGHT",  -stackPos , barPos)
		elseif self.db.char.growdir == "down" then 
			FrameName:SetPoint("TOPLEFT", Watcher.PriorityFrame, "TOPLEFT",  -stackPos , -barPos)
		elseif self.db.char.growdir == "right" then 
			FrameName:SetPoint("BOTTOMLEFT", Watcher.PriorityFrame, "BOTTOMLEFT",  barPos , stackPos)
		elseif self.db.char.growdir == "left" then 
			FrameName:SetPoint("BOTTOMRIGHT", Watcher.PriorityFrame, "BOTTOMRIGHT",  -barPos, stackPos)
		end
	end
	
	function Watcher:LogPosition(timeleft)

	if not self.db.char.logtiming then 
		return
	end
	local indices = self.db.char.indices
	local dist = (Watcher.db.char.priority.fWidth)
	for num = table.getn(indices), 2, -1 do 
			
			if timeleft <= indices[num] and timeleft > indices[num-1] then
				
				local t = timeleft - indices[num-1]
				local i = indices[num] - indices[num-1]
			
				local pos = dist*(num-2) + (t/i)*dist
				
				return pos
			end
	end
	return 0
end


	function Watcher:CountInfo(i, trackspell)
		local index = 1
		if self.db.char.spell.isbuff[i] then
		while UnitBuff("PLAYER", index) do
		local name, _, _, count, _, _, buffexpires = UnitBuff("PLAYER", index)
		if name == trackspell then
			--self:Print(name, trackspell, count)
			return count
		end
		index = index + 1
		end
		else
		while UnitDebuff("TARGET", index) do
		local name, _, _, count, _, dur, buffexpires, caster = UnitDebuff("TARGET", index)
		if name == trackspell and Watcher:Caster(i, caster) then
			if count == nil then count = 0 end
			return count
		end
		index = index + 1
		end
	end
	return 0, 0 
	end
	
	function Watcher:BuffInfo(i, trackspell, noCD, isbuff)
		local index = 1
		if self.db.char.spell.isbuff[i] then
		while UnitBuff("PLAYER", index) do
		local name, _, _, count, _, _, buffexpires = UnitBuff("PLAYER", index)
		if name == trackspell then
		--	self:Print(name,count)
			if count == nil then count = 0	end
			if self.db.char.spell.nocd[i] or self.db.char.spell.isproc[i] then
			
			return true, count
			else
			return buffexpires - GetTime(), count
			end
		end
		index = index + 1
		end
		else
		while UnitDebuff("TARGET", index) do
		local name, _, _, count, _, dur, buffexpires, caster = UnitDebuff("TARGET", index)
		if name == trackspell and Watcher:Caster(i, caster) then
			--self:Print(count)
			if count == nil then count = 0	end
			if self.db.char.spell.nocd[i] or self.db.char.spell.isproc[i] then
			
			return true, count
			else
			return buffexpires - GetTime(), count
			end
		end
		index = index + 1
		end
	end
	if self.db.char.spell.nocd[i] or self.db.char.spell.isproc[i] then return false,0 end
	return 0, 0 
	end
	
	function Watcher:Caster(i, caster)
		if self.db.char.spell.caster[i] and caster == "player" then
			return true
		elseif not self.db.char.spell.caster[i] then
			return true
		else 
			return false
		end
	end
	
	
	function Watcher:ColorUFrame(FrameName)
		if self.db.char.icon.hide then FrameName:SetAlpha(0) return end
		if self.db.char.icon.grey then FrameName.texture:SetDesaturated(1) return end
		if FrameName.texture:IsDesaturated() then FrameName.texture:SetDesaturated(nil) end
		FrameName.texture:SetVertexColor(self.db.char.icon.col.r, self.db.char.icon.col.r, self.db.char.icon.col.b, 1)
		FrameName:SetAlpha(self.db.char.icon.col.a)
	end
	
	
	function Watcher:ColorFrame(FrameName)
		FrameName:SetAlpha(1)
		FrameName.texture:SetDesaturated(nil)
		FrameName.texture:SetVertexColor(1,1,1,1)
	end