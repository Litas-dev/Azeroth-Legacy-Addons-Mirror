if not Watcher then return end

local LBF = LibStub("LibButtonFacade", true)
local L = LibStub("AceLocale-3.0"):GetLocale("Watcher")
local media = LibStub:GetLibrary("LibSharedMedia-3.0");
local C = Watcher.constants


C["Plague Strike"], _, C["Plague Strike Icon"] = GetSpellInfo(49921)
C["Lightning Shield"], _, C["Lightning Shield Icon"] = GetSpellInfo(324)
C["Arcane Intellect"], _, C["Arcane Intellect Icon"] = GetSpellInfo(1459)
C["Fortitude"], _, C["Fortitude Icon"] = GetSpellInfo(1243)
C["Curse of Agony"], _, C["Curse of Agony Icon"] = GetSpellInfo(980)

if select(2, UnitClass('player')) == "MAGE" then 
Watcher.priorityTable.name["gcd"] = "GCD"
Watcher.priorityTable.icon["gcd"] = C["Arcane Intellect Icon"]
Watcher.priorityTable.check["gcd"] =  
	function (FrameName, optionnum) 	
		local start, duration = GetSpellCooldown(C["Arcane Intellect"])
		if duration > 0 then
			FrameName:SetAlpha(1)
			local timeleft = start + duration - GetTime()
			Watcher:MoveGCD(FrameName, timeleft)
			return
		end
		if start == 0 then
			FrameName:SetAlpha(0)
		end
	end  
	end
	
	
if select(2, UnitClass('player')) == "WARLOCK" then 
Watcher.priorityTable.name["gcd"] = "GCD"
Watcher.priorityTable.icon["gcd"] = C["Curse of Agony Icon"]
Watcher.priorityTable.check["gcd"] =  
	function (FrameName, optionnum) 	
		local start, duration = GetSpellCooldown(C["Curse of Agony"])
		if duration > 0 then
			FrameName:SetAlpha(1)
			local timeleft = start + duration - GetTime()
			Watcher:MoveGCD(FrameName, timeleft)
			return
		end
		if start == 0 then
			FrameName:SetAlpha(0)
		end
	end  
	end
	
	
if select(2, UnitClass('player')) == "PRIEST" then 
Watcher.priorityTable.name["gcd"] = "GCD"
Watcher.priorityTable.icon["gcd"] = C["Fortitude Icon"]
Watcher.priorityTable.check["gcd"] =  
	function (FrameName, optionnum) 	
		local start, duration = GetSpellCooldown(C["Fortitude"])
		if duration > 0 then
			FrameName:SetAlpha(1)
			local timeleft = start + duration - GetTime()
			Watcher:MoveGCD(FrameName, timeleft)
			return
		end
		if start == 0 then
			FrameName:SetAlpha(0)

		end
	end  
	end
	
	
if select(2, UnitClass('player')) == "SHAMAN" then 
Watcher.priorityTable.name["gcd"] = "GCD"
Watcher.priorityTable.icon["gcd"] = C["Lightning Shield Icon"]
Watcher.priorityTable.check["gcd"] =  
	function (FrameName, optionnum) 	
		local start, duration = GetSpellCooldown(C["Lightning Shield"])
		if duration > 0 then
			FrameName:SetAlpha(1)
			local timeleft = start + duration - GetTime()
			Watcher:MoveGCD(FrameName, timeleft)
			return
		end
		if start == 0 then
			FrameName:SetAlpha(0)

		end
	end  
	end
	
if select(2, UnitClass('player')) == "DEATHKNIGHT" then 
Watcher.priorityTable.name["gcd"] = "GCD"
Watcher.priorityTable.icon["gcd"] = C["Plague Strike Icon"]
Watcher.priorityTable.check["gcd"] =  
	function (FrameName, optionnum) 	
		local start, duration = GetSpellCooldown(C["Plague Strike"])
		if duration > 0 then
			FrameName:SetAlpha(1)
			local timeleft = start + duration - GetTime()
			Watcher:MoveGCD(FrameName, timeleft, optionnum)
			return
		end
		if start == 0 then
			FrameName:SetAlpha(0)
		end
	end  
	end