
	local LBF = LibStub("LibButtonFacade", true)
	local L = LibStub("AceLocale-3.0"):GetLocale("Watcher")
	local AceAddon = LibStub("AceAddon-3.0")
	local media = LibStub:GetLibrary("LibSharedMedia-3.0");
	Watcher = AceAddon:NewAddon("Watcher", "AceConsole-3.0", "AceEvent-3.0", "AceTimer-3.0")
	local SCT = SCT
	local REVISION = tonumber(("$Revision: 28 $"):match("%d+"))
	local _, _, _, clientVersion = GetBuildInfo()
	Watcher.constants = {}
	local C = Watcher.constants -- Defined in Watcher LUA no locale needed.
	local called = 0
	Watcher.combat = false
	local pvpinstance = false
	Watcher.isBoss = true
	Watcher.fonts = {}
	Watcher.dir = {}
	Watcher.dir["right"] = "right"
	Watcher.dir["left"] = "left"
	Watcher.dir["up"] = "up"
	Watcher.dir["down"] = "down"
	Watcher.swing = nil
	Watcher.PriorityFrame = CreateFrame("Frame", "Watcher_PriorityFrame", UIParent)
	Watcher.PriorityFrame.axisbase = CreateFrame("Frame", "Watcher_PriorityFrameAB", Watcher.PriorityFrame)
	Watcher.Priority = {}
	Watcher.PriorityS = CreateFrame("Frame", "Watcher_PriorityFrameSwing", Watcher.PriorityFrame)
	Watcher.PriorityGCD = CreateFrame("Frame", "Watcher_PriorityFrameGCD", Watcher.PriorityFrame)
	Watcher.swingtype = 0
	Watcher.usedspells = 0
	Watcher.offset = 0
	Watcher.timeLeft = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0 , 0 ,0, 0, 0, 0, 0, 0, 0, 0,0}
	Watcher.targetex = false
	Watcher.textpoint = {}
	Watcher.textpoint["top"] = "top"
	Watcher.textpoint["bottom"] = "bottom"
	Watcher.textpoint["center"] = "center"
	Watcher.priorityTable = {}
	Watcher.priorityTable.name = {}
	Watcher.priorityTable.icon = {}
	Watcher.priorityTable.check = {}
	Watcher.textures = {}
	Watcher.fonts = {}
	
	Watcher.power = 0
	Watcher.health = 0
	Watcher.combo = 0	
	Watcher.maxtime = {}
	
	Watcher.priorityTable.name["none"] = L["None"]
	_, _, Watcher.priorityTable.icon["none"] = "Interface/Tooltips/UI-Tooltip-Background"
			Watcher.priorityTable.check["none"] = function (FrameName, optionnum)
		
			
			end 

Watcher.defaults = {}
function Watcher:SetDefaults()
 Watcher.defaults = {
		char = {
			logtiming = true,
			indices = {},--0,1.5, 3,4.5, 6, 7.5,15,60, 300},
			enable = true,
			message = "Welcome Home!",
			barshow = false,
			bartext = true,
			showtarget = false,
			showraid = false,
			showparty = false,
			enablepvp = false,
			alpha = 1,
			balpha = 0.6,
			showcombat = false,
			showicons = true,
			relativeTo = "UIParent",
			relativePoint = "CENTER",
			point = "CENTER",
			iconfont = "Friz Quadrata TT",
			bartexture = "Flat",
			iconfontsize = 24,
			barfontsize = 12,
			iconfonteffect = "outline",
			xOffset = 0,
			yOffset = -100,
			resetOn = true,
			barTxtPos = 0,
			scale = 1,
			showgcd = true,
			showswing = true,
			showbars = false,
			textpoint =  "center",
			showaxis = false,
			growdir = "right",
			disablebars = false,
			debug = false,
			stackmoving = true,  
			hideprimary = false,
			hidesecondary = false,
			barcol = {
			bar1 = {r = 1, g = 0, b = 0, a = 1},
			bar2 = {r = 0, g = 1, b = 0, a = 1},
			bar3 = {r = 0, g = 0, b = 1, a = 1},
			bar4 = {r = 1, g = 1, b = 0, a = 1},
			bar5 = {r = 1, g = 0, b = 1, a = 1},
			bar6 = {r = 0, g = 1, b = 1, a = 1},
			bar7 = {r = 1, g = 0.5, b = 0, a = 1},
			bar8 = {r = 1, g = 0, b = 0.5, a = 1},
			},
			baralpha = 0.7,
			
			icon = {
				col = {r = 1, g = 0, b = 0, a = 1},
				hide = false,
				grey = true,
			},
			stock_spells = {
				check = {},
				spellname = {},
				name = {},
				typedot = {},
				typeshortdot = {},
				dotlength = {},
				dottime = {},
				isbuff = {},
				icon = {},
				powerthresh = {},
				countreq = {},
				dotthreshold = {},
				combocost = {},
				trackspell = {},
				nocd = {},
				caster = {},
				isproc = {},
			},
			spell = {
				check = {},
				spellname = {},
				name = {},
				typedot = {['*'] = false},
				typeshortdot = {['*'] = false},
				dotlength = {['*'] = 0},
				dottime = {['*'] = 0},
				isbuff = {['*'] = false},
				icon = {},
				powerthresh = {['*'] = 0},
				countreq = {['*'] = 0},
				dotthreshold = {['*'] = 0},
				combocost = {['*'] = 0},
				trackspell = {['*'] = ""},
				nocd = {['*'] = false},
				negthreshold = {['*'] = false},
				caster = {['*'] = true},
				isproc = {['*'] = false},
				stockspell = {['*'] = false},
			},
			warrior = {
				sunderarmor = 1.5,
				hsragethresh = 0,
				},
			druid = {
				srcombo = 1,
				ripcombo = 5,
				fbcombo = 3,
				},
			hunter = {
				dh = 95,
				v = 5,
			},
			priority = {
				p1num = 8,
				p2num = 8,
				num = 8,
				show = true,
				textshow = true,
				relativeTo = "UIParent",
				relativePoint = "CENTER",
				point = "CENTER",
				fWidth = 50,
				fHeight = 50,
				skin = "Blizzard",
				backdrop = 0,
				gloss = 0,
				IconSize = 50,
				alpha = 0.4,
				scale = 1,	
				Label = {"", "", "", "", "", "", "", ""},
				label = {"", "", "", "", "", "", "", ""},
				label2 = {"", "", "", "", "", "", "", ""},
				showlabel = true,
				onlyboss = {['*'] = false },
				onlyboss1 = { ['*'] = false},
				onlyboss2 = { ['*'] = false},
				option1 = {['*'] = "none" ,[1] = "gcd" },
				option2 = { ['*'] = "none",[1] = "gcd"},
				option = { ['*'] = "none",[1] = "gcd" },
				keybindings1 = { ['*'] = nil},
				keybindings2 = { ['*'] = nil},
				isDot = {},
				isBuff = {},
				maxtime = 10,
				labelvert = 0,
				keyvert = 0,
				labelhori = 0,
				keyhori = 0,
				interval = 1.5,
				
				labelcol = {r = 1,g = 1,b = 1,a = 1},
				keycol = {r = 1,g = 1,b = 1,a = 1},
			},
		},
		--class 
	}
	Watcher:addClassSpells()
	return Watcher.defaults
	
	
end

function Watcher:addClassSpells() end
	-------------
	--Set Up / Event Functions
	-------------
	function Watcher:OnInitialize()
		local AceConfigReg = LibStub("AceConfigRegistry-3.0")
		local AceConfigDialog = LibStub("AceConfigDialog-3.0")
		self.db = LibStub("AceDB-3.0"):New("WatcherDBPC", Watcher:SetDefaults(), true)
		self.db:RegisterDefaults(self.defaults)
		self.db.RegisterCallback(self, "OnNewProfile", "OnNewProfile")
		media.RegisterCallback(self, "LibSharedMedia_Registered")
		Watcher:SetOptions()
		--self:Print(self.db:GetCurrentProfile())
		if next(self.db.char.indices) == nil then self.db.char.indices = {0,1.5, 3,4.5, 6, 7.5,15,60, 300} end
		Watcher:SwitchTalents()
		Watcher:AddCustomSpells()
		if LBF then
		LBF:RegisterSkinCallback("Watcher", self.SkinChanged, self)	
		end
		local version = GetAddOnMetadata("Watcher","Version")
		self.version = ("Watcher v%s (r%s)"):format(version, REVISION)
		self:Print(self.version.." Loaded.")
		if LBF then
		local group = LBF:Group("Watcher","Watcher1")
		group:Skin(self.db.char.priority.skin, self.db.char.priority.gloss, self.db.char.priority.backdrop)
		end
	end

	Watcher.SkinChanged = function(arg, SkinID, Gloss, Backdrop, Group, Button, Colors)
	Watcher.db.char.priority.skin = SkinID
	Watcher.db.char.priority.gloss = Gloss
	Watcher.db.char.priority.backdrop = Backdrop
	Watcher:CreatePriorityFrame()
	end
	
	function Watcher:hidespec()
	local groupIndex = GetActiveTalentGroup()
	if groupIndex == 1 and self.db.char.hideprimary then
	self.PriorityFrame:Hide()
		return true
	elseif groupIndex == 2 and self.db.char.hidesecondary then
	self.PriorityFrame:Hide()
		return true
	end
	self.PriorityFrame:Show()
	return false
	end
	
	function Watcher:AddCustomSpells()	
		for k,v in pairs(self.db.char.spell.name) do
				self.priorityTable.name[self.db.char.spell.name[k]] = v
				self.priorityTable.icon[self.db.char.spell.name[k]] = self.db.char.spell.icon[k]
				self.priorityTable.check[self.db.char.spell.name[k]] = function (FrameName, optionnum)
					Watcher:UpdateSpell(FrameName, optionnum, self.db.char.spell.typedot[k], Watcher:BuffInfo(k, self.db.char.spell.trackspell[k], self.db.char.spell.nocd[k],self.db.char.spell.isbuff[k]), self.db.char.spell.typeshortdot[k], self.db.char.spell.dottime[k],0, self.db.char.spell.spellname[k].."()", self.db.char.spell.powerthresh[k], self.db.char.spell.countreq[k], self.db.char.spell.dotthreshold[k], self.db.char.spell.combocost[k], self.db.char.spell.isproc[k], Watcher:CountInfo(k, self.db.char.spell.trackspell[k]), self.db.char.spell.negthreshold[k], self.db.char.spell.nocd[k])	
				end
		end
	end
	
	function Watcher:OnNewProfile (db, profile)
	self:Print("HELLO")
	end
	
	function Watcher:OnEnable()
		self:LibSharedMedia_Registered()
		self:RegisterEvent("PLAYER_ENTERING_WORLD")
		self:RegisterEvent("PLAYER_REGEN_DISABLED")
		self:RegisterEvent("PLAYER_REGEN_ENABLED")
		self:RegisterEvent("PLAYER_TALENT_UPDATE")
		self:RegisterEvent("RAID_ROSTER_UPDATE")
		self:RegisterEvent("PARTY_MEMBERS_CHANGED")
		self:RegisterEvent("UNIT_ENTERED_VEHICLE")
		self:RegisterEvent("UNIT_EXITED_VEHICLE")
		self:RegisterEvent("UNIT_SPELLCAST_SUCCEEDED")
		self:RegisterEvent("PLAYER_TARGET_CHANGED")
		self:RegisterEvent("COMBAT_LOG_EVENT_UNFILTERED")

	end


	function Watcher:DisplayVersion()
		self:Print(self.version)
	end

	function Watcher:COMBAT_LOG_EVENT_UNFILTERED()
	if arg3 == UnitGUID("player") and arg6 == UnitGUID("playertarget")  then
		if arg2 == "SWING_DAMAGE" or arg2 == "SWING_MISS" then
				Watcher.swingtype = 0
				Watcher.swing = GetTime()
		elseif arg2 == "RANGE_DAMAGE" or arg2 == "RANGE_MISS" then
				Watcher.swingtype = 1
				Watcher.swing = GetTime()
		end
		end
	end
		
	function Watcher:PLAYER_ENTERING_WORLD()
		local ininstance, instance = IsInInstance()
		if (instance == "pvp" or instance == "arena") then
		pvpinstance = true
		self:CreatePriorityFrame()
		else
		pvpinstance = false
		
		self:CreatePriorityFrame()
		end
	end

	function Watcher:PLAYER_REGEN_DISABLED()
		if Watcher:scan() then
			Watcher.isBoss = true
		else
			Watcher.isBoss = false
		end
		Watcher.combat = true
		self:CreatePriorityFrame()
	end

	function Watcher:PLAYER_REGEN_ENABLED()
		Watcher.combat = false
		self:CreatePriorityFrame()
	end

	function Watcher:PLAYER_TALENT_UPDATE()
		self:SwitchTalents()	
		self:CreatePriorityFrame()
	end

	function Watcher:PLAYER_TARGET_CHANGED()	
		local pretarget = Watcher.isBoss
		if UnitExists("target") then	
			Watcher.targetex = true
		else
			Watcher.targetex = false
		end
		if Watcher:scan() then
			Watcher.isBoss = true
			--self:Print(Watcher.isBoss)
		else
			Watcher.isBoss = false
			--self:Print(Watcher.isBoss)
		end
		if pretarget ~= Watcher.isBoss or self.db.char.showtarget then
		self:CreatePriorityFrame()
		end
	end

	function Watcher:UNIT_SPELLCAST_SUCCEEDED()
	if arg1 == "player" then
		for k,v in pairs(self.db.char.spell.name) do
			if self.db.char.spell.typeshortdot[k] then
				if arg2 == self.db.char.spell.spellname[k] then
					self.db.char.spell.dottime[k] = self.db.char.spell.dotlength[k] + GetTime()
				end
			end
		end
	end
	end

	function Watcher:LibSharedMedia_Registered()
		for k, v in pairs(media:List("font")) do
			self.fonts[v] = v
		end
		for k, v in pairs(media:List("statusbar")) do
			self.textures[v] = v
		end
	end

	function Watcher:scan()
		if Watcher:checkTarget("target") then return true end
		if Watcher:checkTarget("focus") then return true end
		if UnitInRaid("player") then
			for i = 1, GetNumRaidMembers() do
				if Watcher:checkTarget("raid"..i.."target") then return true end
			end
		else
			for i = 1, 5 do
				if Watcher:checkTarget("party"..i.."target") then return true end
			end
		end
		return false
	end

	function Watcher:checkTarget(id)
		return UnitExists(id) and UnitClassification(id) == "worldboss"
	end

	function Watcher:SwitchTalents()	
		local groupIndex = GetActiveTalentGroup()
		if groupIndex == 1 then 
			self.db.char.priority.num = self.db.char.priority.p1num
			self.db.char.priority.option = self.db.char.priority.option1
			self.db.char.priority.onlyboss = self.db.char.priority.onlyboss1
			self.db.char.priority.Label = self.db.char.priority.label
			self.db.char.priority.keybindings = self.db.char.priority.keybindings1
		elseif groupIndex == 2 then 
			self.db.char.priority.num = self.db.char.priority.p2num
			self.db.char.priority.option = self.db.char.priority.option2
			self.db.char.priority.onlyboss = self.db.char.priority.onlyboss2
			self.db.char.priority.Label = self.db.char.priority.label2
			self.db.char.priority.keybindings = self.db.char.priority.keybindings2
		end
		
	end

	function Watcher:UNIT_ENTERED_VEHICLE()
		self:CreatePriorityFrame()
	end

	function Watcher:UNIT_EXITED_VEHICLE()
		self:CreatePriorityFrame()
	end

	function Watcher:CheckRaidParty()
		local raidnum = GetNumRaidMembers()
		local partynum = GetNumPartyMembers()
		if partynum > 0 and self.db.char.showparty == true then
			self.PriorityFrame:Show()
		elseif raidnum >= 1 and self.db.char.showraid == true then
			self.PriorityFrame:Show()
		else
			self.PriorityFrame:Hide()
		end
	end

	function Watcher:RAID_ROSTER_UPDATE()
		self:CreatePriorityFrame()
	end

	function Watcher:PARTY_MEMBERS_CHANGED()
		self:CreatePriorityFrame()
	end

	function Watcher:bossmob(optionnum)
		if self.db.char.priority.onlyboss[optionnum] and Watcher.isBoss then
			return true
		elseif not self.db.char.priority.onlyboss[optionnum] then
			return true
		else
			return false
		end
	end


	-------------------------------
	-- Priority functions
	-------------------------------

	function Watcher:DurationString(duration)
		local string = (("%1.1f"):format(duration % 120));
		
		if (duration >= 120) then
			duration = floor(duration - (duration % 60)) / 60; -- minutes
			
			string = ((duration % 60) 	) .."m " --.. string;
			
			if (duration >= 120) then
				duration = (duration - (duration % 60)) / 60; -- hours
				string = (duration + 1).. "h " --.. string;
			end
		end
		return string
	end
	--------------------------
	--- Layout Functions
	--------------------------
	function Watcher:CreatePriorityFrame()
		if not self.db.char.enable or self:hidespec() then
			return
		end
		self.PriorityFrame:ClearAllPoints()
		self.PriorityFrame:SetScale(self.db.char.scale)
		self.PriorityFrame:SetFrameStrata("BACKGROUND")
		self.PriorityFrame:SetAlpha(self.db.char.alpha)
		local barlength = Watcher.db.char.priority.fWidth * table.getn(self.db.char.indices)
		local iconsize = self.db.char.priority.IconSize
		if self.db.char.growdir == "right" then
		self.PriorityFrame:SetWidth(barlength)
		
		self.PriorityFrame:SetHeight(iconsize)
		elseif self.db.char.growdir == "down" then
		self.PriorityFrame:SetHeight(barlength)
		self.PriorityFrame:SetWidth(iconsize)
		elseif self.db.char.growdir == "left" then
		self.PriorityFrame:SetWidth(barlength)
		self.PriorityFrame:SetHeight(iconsize)
		elseif self.db.char.growdir == "up" then
		self.PriorityFrame:SetHeight(barlength)
		self.PriorityFrame:SetWidth(iconsize)
		end
		self.PriorityFrame:SetBackdrop({
			bgFile = "Interface/Tooltips/UI-Tooltip-Background",
			--edgeFile = "Interface/Tooltips/UI-Tooltip-Border",
			tile = false, tileSize = 0, edgeSize = 0,
			insets = { left = 0, right = 0, top = 0, bottom = 0 }
		})
		self.PriorityFrame:SetBackdropColor(0, 0, 0, self.db.char.balpha);
		self.PriorityFrame:SetMovable(true);
		self.PriorityFrame:RegisterForDrag("LeftButton");
		self.PriorityFrame:SetPoint(self.db.char.point, self.db.char.relativeTo, self.db.char.relativePoint, self.db.char.xOffset, self.db.char.yOffset)
		self.PriorityFrame:SetScript("OnDragStart", 
			function()
				self.PriorityFrame:StartMoving();
			end );
		self.PriorityFrame:SetScript("OnDragStop",
			function()
				self.PriorityFrame:StopMovingOrSizing();
				
				self:FinishedMoving(self.db.char, self.PriorityFrame);
			end );
		self.PriorityFrame:SetScript("OnUpdate", 
		function()
			self.combo = GetComboPoints("player", "target")
			self.power = UnitPower("player")/UnitPowerMax("player")
		
		end);
		if self.db.char.showgcd then
			Watcher:SetGCD(self.PriorityGCD)
			self.PriorityGCD:Show()
		else
			self.PriorityGCD:Hide()
		end
		if self.db.char.showswing then
		Watcher:SwingTimer(self.PriorityS)
		self.PriorityS:Show()
		else
		self.PriorityS:Hide()
		end
		for i = 1,self.db.char.priority.num do
			if not Watcher.Priority[i] then
			Watcher.Priority[i] = CreateFrame("Button", "Watcher_PriorityFrame"..i, Watcher.PriorityFrame)
			end
			Watcher:SetPriorityFrame(self.Priority[i],i + 1)
		end
		self:Axis()
		self:AxisText()
		if self.db.char.showcombat == true then
			if self.combat == true then
				self.PriorityFrame:Show()
			else
				self.PriorityFrame:Hide()
			end
		else 
			self.PriorityFrame:Show()
		end
		if self.db.char.showtarget and not Watcher.targetex then
			self.PriorityFrame:Hide()
		end
		if pvpinstance == true and not self.db.char.enablepvp then
			self.PriorityFrame:Hide()
		end
		if UnitInVehicle("player") then
			self.PriorityFrame:Hide()
		end
		if self.db.char.showraid == true or self.db.char.showparty == true then
			self:CheckRaidParty()
		
		end
		--self.PriorityFrame:Show()
		--self:Print("FUCK")
	end
		
	function Watcher:AxisText()
			if not self.PriorityFrame.text then
			self.PriorityFrame.text = {}
			end
			foreach(self.PriorityFrame.text, function(k,v) self.PriorityFrame.text[k]:SetText("") end)
			for i = 1, table.getn(self.db.char.indices) do
			if not self.PriorityFrame.text[i] then
			self.PriorityFrame.text[i] = Watcher.PriorityFrame:CreateFontString(nil, "OVERLAY")
			end
			self.PriorityFrame.text[i]:SetFont(media:Fetch("font", self.db.char.iconfont), self.db.char.barfontsize, self.db.char.iconfonteffect)
			self.PriorityFrame.text[i]:ClearAllPoints()
			local txtPos = Watcher.db.char.barTxtPos 
			if self.db.char.growdir == "right" then
			self.PriorityFrame.text[i]:SetPoint("CENTER", self.PriorityFrame, "BOTTOMLEFT" ,Watcher.db.char.priority.IconSize/2 + Watcher.db.char.priority.fWidth * (i-1),txtPos* Watcher.db.char.priority.IconSize/6 + (txtPos+1)* Watcher.db.char.priority.IconSize/2)
			elseif self.db.char.growdir == "left" then
			self.PriorityFrame.text[i]:SetPoint("CENTER", self.PriorityFrame, "BOTTOMRIGHT" , -Watcher.db.char.priority.IconSize/2 - Watcher.db.char.priority.fWidth * (i-1), txtPos* Watcher.db.char.priority.IconSize/6 + (txtPos+1)* Watcher.db.char.priority.IconSize/2)
			elseif self.db.char.growdir == "up" then
			self.PriorityFrame.text[i]:SetPoint("CENTER", self.PriorityFrame, "BOTTOMRIGHT" ,-(txtPos* Watcher.db.char.priority.IconSize/6 + (txtPos+1)* Watcher.db.char.priority.IconSize/2), Watcher.db.char.priority.IconSize/2 + Watcher.db.char.priority.fWidth * (i-1))
			elseif self.db.char.growdir == "down" then
			self.PriorityFrame.text[i]:SetPoint("CENTER", self.PriorityFrame, "TOPRIGHT" ,-(txtPos* Watcher.db.char.priority.IconSize/6 + (txtPos+1)* Watcher.db.char.priority.IconSize/2), -Watcher.db.char.priority.IconSize/2 - Watcher.db.char.priority.fWidth * (i-1))
			end
			self.PriorityFrame.text[i]:SetText(self:DurationString(self.db.char.indices[i]))
			if not self.db.char.bartext then
				self.PriorityFrame.text[i]:Hide()
			else
				self.PriorityFrame.text[i]:Show()
			end
			end
			
		end	

		
	function Watcher:SwingTimer(FrameName)
		FrameName:ClearAllPoints()
		FrameName:SetFrameStrata("BACKGROUND")
		FrameName:SetWidth(Watcher.db.char.priority.IconSize)
		FrameName:SetHeight(self.db.char.priority.IconSize)
		FrameName:EnableMouse(0)

		if self.db.char.growdir == "right" then
			FrameName:SetPoint("BOTTOMLEFT", self.PriorityFrame, "BOTTOMLEFT", 0, 0)
			elseif self.db.char.growdir == "up"  then
			FrameName:SetPoint("BOTTOMRIGHT", self.PriorityFrame, "BOTTOMRIGHT", 0, 0)
			elseif self.db.char.growdir == "left" then
			FrameName:SetPoint("BOTTOMRIGHT", self.PriorityFrame, "BOTTOMRIGHT", 0, 0)	
			elseif self.db.char.growdir == "down" then
			FrameName:SetPoint("TOPRIGHT", self.PriorityFrame, "TOPRIGHT", 0, 0)
			end
		if not FrameName.swingtexture then
				FrameName.swingtexture = FrameName:CreateTexture(nil, "OVERLAY")
		end
		FrameName.swingtexture:ClearAllPoints()
		FrameName.swingtexture:SetWidth(self.db.char.priority.fHeight / 10)
		FrameName.swingtexture:SetHeight(self.db.char.priority.fHeight / 10)
		if self.db.char.growdir == "right" then
		FrameName.swingtexture:SetPoint("TOPLEFT", FrameName, "BOTTOMRIGHT", 0, 0)
		elseif self.db.char.growdir == "up"  then
		FrameName.swingtexture:SetPoint("BOTTOMLEFT", FrameName, "TOPRIGHT", 0, 0)
		elseif self.db.char.growdir == "left" then
		FrameName.swingtexture:SetPoint("TOPRIGHT", FrameName, "BOTTOMLEFT", 0, 0)	
		elseif self.db.char.growdir == "down" then
		FrameName.swingtexture:SetPoint("TOPLEFT", FrameName, "BOTTOMRIGHT", 0, 0)
		end
		FrameName.swingtexture:SetTexture(1,0,0,1)
		FrameName.swingtexture:SetAlpha(0)
		
		FrameName:SetScript("OnUpdate", 
			function()
					if Watcher.swing ~= nil then
					local AttackSpeed
					if Watcher.swingtype == 1 then
					AttackSpeed, _ = UnitRangedDamage("player")
					else
					AttackSpeed, _ = UnitAttackSpeed("player")
					end
					local time_since_swing = GetTime() - Watcher.swing
					if time_since_swing <= AttackSpeed then
					FrameName.swingtexture:SetAlpha(1)
					if self.db.char.growdir == "right" then
						FrameName.swingtexture:SetPoint("TOPLEFT", FrameName, "BOTTOMRIGHT",((AttackSpeed - time_since_swing) * Watcher.db.char.priority.fWidth / 1.5), 0)
					elseif self.db.char.growdir == "up"  then
						FrameName.swingtexture:SetPoint("BOTTOMLEFT", FrameName, "TOPRIGHT", 0, ((AttackSpeed - time_since_swing) * Watcher.db.char.priority.fWidth / 1.5))
					elseif self.db.char.growdir == "left" then
						FrameName.swingtexture:SetPoint("TOPRIGHT", FrameName, "BOTTOMLEFT", ((AttackSpeed - time_since_swing) * -Watcher.db.char.priority.fWidth / 1.5), 0)	
					elseif self.db.char.growdir == "down" then
						FrameName.swingtexture:SetPoint("TOPLEFT", FrameName, "BOTTOMRIGHT", 0, -((AttackSpeed - time_since_swing) * Watcher.db.char.priority.fWidth / 1.5))
					end
					else
					FrameName.swingtexture:SetAlpha(0)
					end
					end
			end	);		
	end	
		
	function Watcher:Axis()
		self.PriorityFrame.axisbase:ClearAllPoints()
		if not self.PriorityFrame.axis then
			self.PriorityFrame.axis = self.PriorityFrame.axisbase:CreateTexture(nil, "OVERLAY")
		end
		self.PriorityFrame.axisbase:ClearAllPoints()
		self.PriorityFrame.axis:ClearAllPoints()
		if self.db.char.growdir == "right" then
		self.PriorityFrame.axis:SetWidth(Watcher.db.char.priority.fWidth * (table.getn(self.db.char.indices)) - self.db.char.priority.IconSize)
		self.PriorityFrame.axis:SetHeight(self.db.char.priority.fHeight / 10)
		self.PriorityFrame.axis:SetPoint("TOPLEFT", self.PriorityFrame, "BOTTOMLEFT", Watcher.db.char.priority.IconSize, 0)
		elseif self.db.char.growdir == "left" then
		self.PriorityFrame.axis:SetWidth(Watcher.db.char.priority.fWidth * (table.getn(self.db.char.indices))- self.db.char.priority.IconSize)
		self.PriorityFrame.axis:SetHeight(self.db.char.priority.fHeight / 10)
		self.PriorityFrame.axis:SetPoint("TOPRIGHT", self.PriorityFrame, "BOTTOMRIGHT", -Watcher.db.char.priority.IconSize, 0)
		elseif self.db.char.growdir == "down" then
		self.PriorityFrame.axis:SetHeight(Watcher.db.char.priority.fWidth * (table.getn(self.db.char.indices))- self.db.char.priority.IconSize)
		self.PriorityFrame.axis:SetWidth(self.db.char.priority.fHeight / 10)
		self.PriorityFrame.axis:SetPoint("TOPLEFT", self.PriorityFrame, "TOPRIGHT", 0, -Watcher.db.char.priority.IconSize)
		elseif self.db.char.growdir == "up" then
		self.PriorityFrame.axis:SetHeight(Watcher.db.char.priority.fWidth * (table.getn(self.db.char.indices))- self.db.char.priority.IconSize)
		self.PriorityFrame.axis:SetWidth(self.db.char.priority.fHeight / 10)
		self.PriorityFrame.axis:SetPoint("TOPLEFT", self.PriorityFrame, "TOPRIGHT", 0,0)
		end
		self.PriorityFrame.axis:SetTexture(1, 1, 1, 1)
		self.PriorityFrame.axis:Show()
		if not self.PriorityFrame.axisgcd then -- "Finish Line"
			self.PriorityFrame.axisgcd = self.PriorityFrame.axisbase:CreateTexture(nil, "OVERLAY")
		end
		--self.PriorityFrame.axisgcd:SetFrameLevel(10)
		self.PriorityFrame.axisgcd:ClearAllPoints()
		if self.db.char.growdir == "right" then
		self.PriorityFrame.axisgcd:SetHeight(Watcher.db.char.priority.IconSize)
		self.PriorityFrame.axisgcd:SetWidth(self.db.char.priority.fHeight / 10)
		self.PriorityFrame.axisgcd:SetPoint("BOTTOMLEFT", self.PriorityFrame, "BOTTOMLEFT",Watcher.db.char.priority.IconSize, 0)
		end
		if self.db.char.growdir == "left" then
		self.PriorityFrame.axisgcd:SetHeight(Watcher.db.char.priority.IconSize)
		self.PriorityFrame.axisgcd:SetWidth(self.db.char.priority.fHeight / 10)
		self.PriorityFrame.axisgcd:SetPoint("BOTTOMRIGHT", self.PriorityFrame, "BOTTOMRIGHT",-Watcher.db.char.priority.IconSize, 0)
		end
		if self.db.char.growdir == "down" then
		self.PriorityFrame.axisgcd:SetWidth(Watcher.db.char.priority.IconSize)
		self.PriorityFrame.axisgcd:SetHeight(self.db.char.priority.fHeight / 10)
		self.PriorityFrame.axisgcd:SetPoint("TOPRIGHT", self.PriorityFrame, "TOPRIGHT",0, -Watcher.db.char.priority.IconSize)
		end
		if self.db.char.growdir == "up" then
		self.PriorityFrame.axisgcd:SetWidth(Watcher.db.char.priority.IconSize)
		self.PriorityFrame.axisgcd:SetHeight(self.db.char.priority.fHeight / 10)
		self.PriorityFrame.axisgcd:SetPoint("BOTTOMLEFT", self.PriorityFrame, "BOTTOMLEFT",0, Watcher.db.char.priority.IconSize)
		end
		self.PriorityFrame.axisgcd:SetTexture(0, 0, 0, 1)
		self.PriorityFrame.axisgcd:Show()
		
		if (self.db.char.showaxis) then
			self.PriorityFrame.axisbase:SetAlpha(1)
		else
			self.PriorityFrame.axisbase:SetAlpha(0)
		end
	end

function Watcher:SetGCD(FrameName)
			FrameName:ClearAllPoints()
		FrameName:SetFrameStrata("BACKGROUND")
		FrameName:SetWidth(Watcher.db.char.priority.IconSize)
		FrameName:SetHeight(self.db.char.priority.IconSize)
		--FrameName:SetAlpha(1)
		FrameName:EnableMouse(0)
			if not FrameName.texture then
				FrameName.texture = FrameName:CreateTexture(nil, "OVERLAY")
			end
			FrameName:Show()
			FrameName.texture:ClearAllPoints()
			FrameName.texture:SetWidth(self.db.char.priority.IconSize/10)
			FrameName.texture:SetHeight(self.db.char.priority.IconSize/10)
			if self.db.char.growdir == "right" then
			FrameName.texture:SetPoint("TOPRIGHT", FrameName, "BOTTOMRIGHT", 0, 0)
			elseif self.db.char.growdir == "up"  then
			FrameName.texture:SetPoint("TOPLEFT", FrameName, "TOPRIGHT", 0, 0)
			elseif self.db.char.growdir == "left" then
			FrameName.texture:SetPoint("TOPLEFT", FrameName, "BOTTOMLEFT", 0, 0)	
			elseif self.db.char.growdir == "down" then
			FrameName.texture:SetPoint("BOTTOMLEFT", FrameName, "BOTTOMRIGHT", 0, 0)
			end
			FrameName:SetFrameLevel(self.db.char.priority.num * 10)
			FrameName.texture:SetTexture(0,0,0,1)
			FrameName:SetScript("OnUpdate", 
			function()
					if (self.combat or not self.db.char.showcombat) then
		
						Watcher.priorityTable.check[self.db.char.priority.option[1]](FrameName, 1)
					end
			end	);		
			
end
	
function Watcher:SetPriorityFrame(FrameName, optionnum)
		
		FrameName:ClearAllPoints()
		FrameName:SetFrameStrata("BACKGROUND")
		FrameName:SetWidth(Watcher.db.char.priority.IconSize)
		FrameName:SetHeight(self.db.char.priority.IconSize)
		FrameName:EnableMouse(0)
		-- Configure Icon texture and if LBF set normal texture
		if not FrameName.texture then
			FrameName.texture = FrameName:CreateTexture(nil, "OVERLAY")
		end
		FrameName.texture:SetWidth(Watcher.db.char.priority.IconSize)
		FrameName.texture:SetHeight(self.db.char.priority.IconSize)
		FrameName.texture:SetPoint("CENTER", FrameName, "CENTER", 0, 0)
		FrameName.texture:SetTexture(Watcher.priorityTable.icon[self.db.char.priority.option[optionnum]])
		if LBF then
			if not FrameName.ntexture then
			FrameName.ntexture = FrameName:CreateTexture(nil)
			end
			local group = LBF:Group("Watcher","Watcher1")
			group:AddButton(FrameName, {Icon = FrameName.texture, Normal = FrameName.ntexture})
		end
		-- set frame level so correct frames overlap
		FrameName:SetFrameLevel((self.db.char.priority.num * 20) - ((optionnum-1)*10))
		
		
		-- Set KeyBindings
		if self.db.char.priority.keybindings ~= nil and self.db.char.priority.keybindings[optionnum - 1] ~=  nil then
		SetBindingSpell(self.db.char.priority.keybindings[optionnum - 1], Watcher.priorityTable.name[self.db.char.priority.option[optionnum]].."()")
		end
		-- create overlay text related to keybindings
		if not FrameName.keybind then
				FrameName.keybind = FrameName:CreateFontString(nil, "OVERLAY")
			end
			FrameName.keybind:Show()
			FrameName.keybind:ClearAllPoints()
			FrameName.keybind:SetTextColor(self.db.char.priority.keycol.r, self.db.char.priority.keycol.g, self.db.char.priority.keycol.b, self.db.char.priority.keycol.a)
			FrameName.keybind:SetFont(media:Fetch("font", self.db.char.iconfont), self.db.char.iconfontsize, self.db.char.iconfonteffect)
			FrameName.keybind:SetPoint("CENTER", FrameName, "CENTER", self.db.char.priority.keyhori, self.db.char.priority.keyvert)
			if self.db.char.priority.keybindings ~= nil then 
				if self.db.char.priority.keybindings[optionnum-1] == "BUTTON4" then
					FrameName.keybind:SetText("B4")
				elseif self.db.char.priority.keybindings[optionnum-1] == "BUTTON3" then
					FrameName.keybind:SetText("B3")
				elseif self.db.char.priority.keybindings[optionnum-1] == "BUTTON5" then
					FrameName.keybind:SetText("B5")
				else
					FrameName.keybind:SetText(self.db.char.priority.keybindings[optionnum-1])
				end
			end
		
		
		--if using a key label then create
		if self.db.char.priority.showlabel then
			if not FrameName.Label then
				FrameName.Label = FrameName:CreateFontString(nil, "OVERLAY")
			end
			FrameName.Label:Show()
			FrameName.Label:ClearAllPoints()
			FrameName.Label:SetTextColor(self.db.char.priority.labelcol.r, self.db.char.priority.labelcol.g, self.db.char.priority.labelcol.b, self.db.char.priority.labelcol.a)
			FrameName.Label:SetFont(media:Fetch("font", self.db.char.iconfont), self.db.char.iconfontsize, self.db.char.iconfonteffect)
			FrameName.Label:SetPoint("CENTER", FrameName, "CENTER", self.db.char.priority.labelhori, self.db.char.priority.labelvert)
			FrameName.Label:SetText(self.db.char.priority.Label[optionnum])
		else
			if FrameName.Label then
			FrameName.Label:Hide()
			end
			end	

			
		-- create cooldown text
		if not FrameName.Text then
			FrameName.Text = FrameName:CreateFontString(nil, "OVERLAY")
		end
		FrameName.Text:ClearAllPoints()
		FrameName.Text:SetTextColor(1,1,1,1)
		FrameName.Text:SetFont(media:Fetch("font", self.db.char.iconfont), self.db.char.iconfontsize, self.db.char.iconfonteffect)
		if self.db.char.textpoint == "top" then
		FrameName.Text:SetPoint("TOP", FrameName, "TOP", 0, self.db.char.iconfontsize + 2)
		elseif self.db.char.textpoint == "bottom" then
		FrameName.Text:SetPoint("BOTTOM", FrameName, "BOTTOM", 0, -self.db.char.iconfontsize + 2)
		elseif self.db.char.textpoint == "center" then
		FrameName.Text:SetPoint("CENTER", FrameName, "CENTER", 0, 0)
		end
		if self.db.char.showbars then
			Watcher:SetBack(FrameName, optionnum)
		else
			if FrameName.status then 
				FrameName.status:Hide()
			end
		end
		
		-- set update function
		if self.db.char.priority.option[optionnum] == "none" or self.db.char.priority.option[optionnum] == nil then
			FrameName:SetAlpha(0)
			Watcher.timeLeft[optionnum+self.db.char.priority.num] = -1
			Watcher.timeLeft[optionnum] = -1
		else 
			Watcher.priorityTable.check[self.db.char.priority.option[optionnum]](FrameName, optionnum)
		end
		FrameName:SetScript("OnUpdate", 
			function()
					if (self.combat or not self.db.char.showcombat) then
					if self.db.char.priority.option[optionnum] ~= "none" then
						Watcher.priorityTable.check[self.db.char.priority.option[optionnum]](FrameName, optionnum)
					else
						FrameName:SetAlpha(0)
						Watcher.timeLeft[optionnum+self.db.char.priority.num] = -1
						Watcher.timeLeft[optionnum] = -1
					
					end
					end
			end	);		

		if self.db.char.priority.iconcd then
			FrameName.Text:Show()
		else
			FrameName.Text:Hide()
		end
	end


	function Watcher:SetBack(FrameName, num)
		if not FrameName.status then
			FrameName.status =  CreateFrame("Frame", "Watcher_PriorityFrameStatus", self.PriorityFrame)
			
		end
		FrameName.status:Show()
		FrameName.status:ClearAllPoints()
		FrameName.status:SetFrameStrata("BACKGROUND")
		FrameName.status:EnableMouse(0)
		FrameName.status:SetWidth(Watcher.db.char.priority.IconSize)
		FrameName.status:SetHeight(self.db.char.priority.IconSize)
		FrameName.status:SetFrameLevel(self.db.char.priority.num*2-num)
		FrameName.status:SetBackdropColor(0,0,0,0)
		if not FrameName.statusbar then
			FrameName.statusbar =  FrameName.status:CreateTexture(nil, "BACKGROUND")
		end
		FrameName.statusbar:ClearAllPoints()
		FrameName.statusbar:SetWidth(self.db.char.priority.IconSize)
		FrameName.statusbar:SetHeight(self.db.char.priority.IconSize)
		local Number = num - 1
		if Number == 1 then
		FrameName.statusbar:SetTexture(self.db.char.barcol.bar1.r, self.db.char.barcol.bar1.g, self.db.char.barcol.bar1.b, self.db.char.barcol.bar1.a)
		elseif Number == 2 then
		FrameName.statusbar:SetTexture(self.db.char.barcol.bar2.r, self.db.char.barcol.bar2.g, self.db.char.barcol.bar2.b, self.db.char.barcol.bar2.a)
		elseif Number == 3 then
		FrameName.statusbar:SetTexture(self.db.char.barcol.bar3.r, self.db.char.barcol.bar3.g, self.db.char.barcol.bar3.b, self.db.char.barcol.bar3.a)
		elseif Number == 4 then
		FrameName.statusbar:SetTexture(self.db.char.barcol.bar4.r, self.db.char.barcol.bar4.g, self.db.char.barcol.bar4.b, self.db.char.barcol.bar4.a)
		elseif Number == 5 then
		FrameName.statusbar:SetTexture(self.db.char.barcol.bar5.r, self.db.char.barcol.bar5.g, self.db.char.barcol.bar5.b, self.db.char.barcol.bar5.a)
		elseif Number == 6 then
		FrameName.statusbar:SetTexture(self.db.char.barcol.bar6.r, self.db.char.barcol.bar6.g, self.db.char.barcol.bar6.b, self.db.char.barcol.bar6.a)
		elseif Number == 7 then
		FrameName.statusbar:SetTexture(self.db.char.barcol.bar7.r, self.db.char.barcol.bar7.g, self.db.char.barcol.bar7.b, self.db.char.barcol.bar7.a)
		elseif Number == 8 then
		FrameName.statusbar:SetTexture(self.db.char.barcol.bar8.r, self.db.char.barcol.bar8.g, self.db.char.barcol.bar8.b, self.db.char.barcol.bar8.a)
		end
		FrameName.statusbar:SetAlpha(0)
		if self.db.char.growdir == "left" then
		FrameName.statusbar:SetPoint("BOTTOMRIGHT", self.PriorityFrame, "BOTTOMRIGHT", -Watcher.db.char.priority.IconSize, 0)
		elseif self.db.char.growdir == "right" then
		FrameName.statusbar:SetPoint("BOTTOMLEFT", self.PriorityFrame, "BOTTOMLEFT", Watcher.db.char.priority.IconSize, 0)
		elseif self.db.char.growdir == "up" then
		FrameName.statusbar:SetPoint("BOTTOMRIGHT", self.PriorityFrame, "BOTTOMRIGHT", 0, Watcher.db.char.priority.IconSize)
		elseif self.db.char.growdir == "down" then
		FrameName.statusbar:SetPoint("TOPRIGHT", self.PriorityFrame, "TOPRIGHT", 0, -Watcher.db.char.priority.IconSize)
		end
		end
		
	function Watcher:ResetPriority()
		self.db:ResetDB()
	--	self.db = Watcher.defaults
		if next(self.db.char.indices) == nil then self.db.char.indices = {0,1.5, 3,4.5, 6, 7.5,15,60, 300} end
		--self.db = LibStub("AceDB-3.0"):New("WatcherDBPC", Watcher:SetDefaults(), true)
		self:SwitchTalents()
		self:CreatePriorityFrame()
		self:Print(L["priority_reset"])
	end
