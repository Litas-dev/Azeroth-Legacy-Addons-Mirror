
local L = LibStub("AceLocale-3.0"):NewLocale("Watcher", "enUS", true);
if not L then return end

L["About"] = true
L["Version"] = true 
L["__URL__"] = "http://wow.curse.com/downloads/wow-addons/details/Watcher.aspx"
L["Enable"] = "Enable"
------------------
-- Help section
------------------

L["help"] = "All options can be configured more easily using the Blizzard options menu. Press ESC and select addons then click on Watcher to configure."
L["help1"] = "All options can be configured more easily using the Blizzard options menu."
L["help2"] = "Press ESC and select addons then click on Watcher to configure."
L["help_scale"] = "Use this to scale bars frame. Valid scale multiplier values are 0.25 to 3"
L["help_size"] = "Use this to change the size of spell icons. Valid size values are 10 to 50"
L["help_reset_priority"] = "Reset priority frame to default values"
L["help_display"] = "Hide or unhide the bar frames to reposition them.  When displayed, left click to drag the bars."
L["help_version"] = "Show version information" 
L["help_threat"] = "Percentage threat that triggers display of windshock warning" 
L["help_debug"] = "Activate or deactivate debug messages" 
L["help_gcd"] = "Activate or deactivate display of global cooldown"
L["help_axis"] = "Activate or deactivate display of axis"
L["help_maxtime"] = "Set the max time"
L["help_interval"] = "Set the interval of time between units displayed on the axis."
L["help_cooldown"] = "Seconds left on cooldown to consider showing priority. eg: 0 means wait until Cooldown over before option available. Whereas 0.25 means any skill with 0.25 sec or less of Cooldown show it as next priority."
L["help_disable"] = "Tick to disable the display of timer bars out of combat"
L["help_config"] = "Display easy to use graphical config panel"
L["help_lnlIcon"] = "Show two icons representing current Lock and Load buffs present on player"
L["help_Dir"] = "Set direction moved by icons"
L["help_alpha"] = "Set Alpha"
L["help_balpha"] = "Set Background Alpha"
L["help_enable"] = "Enable or disable the displaying of the addon for this character."
----------------
-- Menu section
----------------
L["Priority Table 1"] = "Priorities"
L["Bar Texture"] = true
L["Stack moving frames that overlap"] = true
L["Priority Table 2"] = "Priorities"
L["Display Settings"] = true
L["Keybind Settings - Primary Spec"] = "Keybindings"
L["Keybind Settings - Secondary Spec"] = "Keybindings"
L["Text Settings"] = true
L["Spell Settings"] = true
L["Show only in combat"] = true
L["Show only if target exists"] = true
L["Direction"] = true
L["MaxTime"] = true
L["Interval"] = true
L["Alpha"] = true
L["Show only in party"] = true
L["Show only in raid"] = true
L["Enable in PVP"] = true
L["Background Alpha"] = true
L["Disable out of combat"] =true
L["Text Display"] = true
L["Bar Scale"] = true
L["Reset"] = true
L["Version"] = true
L["Move Frames"] = true
L["Icon Size"] = true
L["Bars Section"] = true
L["Priority Section"] = true
L["Display CD text"] = true
L["Display News"] = true
L["OUTLINE"] = true
L["THICKOUTLINE"] = true
L["MONOCHROME"] = true
L["Show GCD"] = "Show Global Cooldown" 
L["Show Statusbar"] = true
L["Show Swing Timer"] = "Show Swing Timer" 
L["Show axis"] = "Show Axis" 
L["Show axis text"] = "Show Axis Text" 
L["Explosive Shot DOT Time Left"] = true 
L["Configure Options"] = true
L["lnl Icon"] = "Lock and Load Icons"
L["Show bar icons"] = true
L["CD text size"] = true
L["Text Anchor"] = true
L["Undead"] = true
L["Font"] = true
L["Font Effect"] = true
L["Show Labels"] = true
L["Label Vertical Position"] = true
L["Label Horizontal Position"] = true
L["Label Color"] = true
L["Keybindings Vertical Position"] = true
L["Keybindings Horizontal Position"] = true
L["Keybindings Color"] = true
L["Rage before Heroic Strike"] = true
L["Sunder Armor warning time"] = true
L["1st Bar Colour"] = "Colour of bar for first priority"
L["2nd Bar Colour"] = "Colour of bar for second priority"
L["3rd Bar Colour"] = "Colour of bar for thrid priority"
L["4th Bar Colour"] = "Colour of bar for fourth priority"
L["5th Bar Colour"] = "Colour of bar for fifth priority"
L["6th Bar Colour"] = "Colour of bar for sixth priority"
L["7th Bar Colour"] = "Colour of bar for seventh priority"
L["8th Bar Colour"] = "Colour of bar for eighth priority"
L["Bar Settings"] = true
L["Alpha of bars"] = true
------------------
-- Config section
------------------

L["config_lnlicon_on"] = "LnL icons will be displayed"
L["config_lnlicon_off"] = "LnL icons will be displayed"
L["config_axis_on"] = "The axis will now be displayed"
L["config_axis_off"] = "The axis will NOT now be displayed"
L["config_GCD_on"] = "Global Cooldown bar will now be displayed"
L["config_GCD_off"] = "Global Cooldown bar will NOT now be displayed"
L["config_debug_on"] = "Debug info will now be displayed"
L["config_debug_off"] = "Debug info will NOT now be displayed"
L["config_Barstext_on"] = "Text info on bars will now be displayed"
L["config_Barstext_off"] = "Text info on bars will NOT now be displayed"
L["config_reset"] = "Reset bar frame to default values"
L["config_priority_on"] = "Priority Frame is enabled"
L["config_priority_off"] = "Priority Frame is disabled"
L["config_prioritytitle_on"] = "Priority Frame's title will now be displayed"
L["config_prioritytitle_off"] = "Priority Frame's title will NOT now be displayed"
L["config_disable_on"] = "Timer bars will now be hidden out of combat"
L["config_disable_off"] = "Timer bars will remain displayed out of combat"
L["config_combopoints_on"] = "LnL proc combo points will now be shown on the priority frame"
L["config_combopoints_off"] = "LnL proc combo points will NOT now be shown on the priority frame"
L["config_baricons_on"] = "Icons will now be shown next to each timer bar"
L["config_baricons_off"] = "Icons will NOT now be shown next to each timer bar"
L["config_maxtime"] = "Maximum time displayed on axis set to : "
L["config_interval"] = "Interval of time between units on axis set to : "
L["config_enable_on"] = "Watcher enabled"
L["config_enable_off"] = "Watcher disabled"


-------------
-- Priority Table
-------------
L["None"] = true
L["Execute SD proc"] = true
L["Slam Instant"] = true
L["Priority Frame"] = true
L["First Priority"] = true
L["Second Priority"] = true
L["Third Priority"] = true
L["Fourth Priority"] = true
L["Fifth Priority"] = true
L["Sixth Priority"] = true
L["Seventh Priority"] = true
L["Eighth Priority"] = true
L["Ninth Priority"] = true
L["Next Priority"] = true
L["showraidboss1"] = "Show priority 1 only at raid boss"
L["showraidboss2"] = "Show priority 2 only at raid boss"
L["showraidboss3"] = "Show priority 3 only at raid boss"
L["showraidboss4"] = "Show priority 4 only at raid boss"
L["showraidboss5"] = "Show priority 5 only at raid boss"
L["showraidboss6"] = "Show priority 6 only at raid boss"
L["showraidboss7"] = "Show priority 7 only at raid boss"
L["showraidboss8"] = "Show priority 8 only at raid boss"
L["priority_reset"] = "Your priority choices have been reverted to the defaults"
-----------
-- News
-----------

L["Website"] = true
L["Command"] = true
L["Config"] = true
L["help_command"] = "Or if you are feeling machocistic - Use /watcher for command line configuration"

