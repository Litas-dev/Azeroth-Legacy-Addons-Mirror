if not Watcher then return end

if select(2, UnitClass('player')) ~= "HUNTER" then return end
local LBF = LibStub("LibButtonFacade", true)
local L = LibStub("AceLocale-3.0"):GetLocale("Watcher")
local media = LibStub:GetLibrary("LibSharedMedia-3.0");
local C = Watcher.constants

C["Serpent Sting"], _, C["Serpent Sting Icon"] = GetSpellInfo(49001)

C["Explosive Shot"], _, C["Explosive Shot Icon"] = GetSpellInfo(60053)
C["Aimed Shot"], _, C["Aimed Shot Icon"] = GetSpellInfo(49050)
C["Lock and Load"], _, C["Lock and Load Icon"] = GetSpellInfo(56453)
C["Beast Lore"], _, C["Beast Lore Icon"] = GetSpellInfo(1462)
C["Black Arrow"], _, C["Black Arrow Icon"] = GetSpellInfo(63672)
C["Kill Shot"], _, C["Kill Shot Icon"] = GetSpellInfo(61006)
C["Steady Shot"], _, C["Steady Shot Icon"] = GetSpellInfo(49052)
C["Chimera Shot"], _, C["Chimera Shot Icon"] = GetSpellInfo(53209)
C["Multi-Shot"], _, C["Multi-Shot Icon"] = GetSpellInfo(49048)
C["Aspect of the Dragonhawk"], _, C["Aspect of the Dragonhawk Icon"] = GetSpellInfo(61847)
C["Aspect of the Viper"], _, C["Aspect of the Viper Icon"] = GetSpellInfo(34074)
C["Hunter's Mark"], _, C["Hunter's Mark Icon"] = GetSpellInfo(53338)
C["Rapid Fire"], _, C["Rapid Fire Icon"] = GetSpellInfo(3045)
C["Bestial Wrath"], _, C["Bestial Wrath Icon"] = GetSpellInfo(19574)
C["Blood Fury"], _, C["Blood Fury Icon"] = GetSpellInfo(20572)
C["Readiness"], _, C["Readiness Icon"] = GetSpellInfo(23989)
C["Kill Command"], _, C["Kill Command Icon"] = GetSpellInfo(34026)
C["Arcane Shot"], _, C["Arcane Shot Icon"] = GetSpellInfo(49045)
C["Auto Shot"], _, C["Auto Shot Icon"] = GetSpellInfo(75)
C["Silencing Shot"], _, C["Silencing Shot Icon"] = GetSpellInfo(34490)
C["Misdirection"], _, C["Misdirection Icon"] = GetSpellInfo(34477)

local esDotTime = 0
function Watcher:addClassSpells()
Watcher:AimedShot()--
Watcher:ExplosiveShot()--
Watcher:BlackArrow()--
Watcher:KillCommand()--
Watcher:HM()--
Watcher:Misdirection()--
Watcher:ADH()--
Watcher:AVH()--
Watcher:ArcaneShot()--
Watcher:MultiShot()--
Watcher:SerpentSting()--
Watcher:SteadyShot()--
Watcher:ChimeraShot()
Watcher:KillShot()--
Watcher:SilencingShot()--
Watcher:RapidFire()--
Watcher:BloodFury()--
Watcher:BestialWrath()--
Watcher:Readiness()--
end			


function Watcher:AimedShot()
	Watcher.defaults.char.spell.spellname[C["Aimed Shot"]] = C["Aimed Shot"]
	Watcher.defaults.char.spell.name[C["Aimed Shot"]] = C["Aimed Shot"]
	Watcher.defaults.char.spell.icon[C["Aimed Shot"]] =  C["Aimed Shot Icon"]
	Watcher.defaults.char.spell.stockspell[C["Aimed Shot"]] = true	
end

function Watcher:ExplosiveShot()
	local def = Watcher.defaults.char.spell
	def.spellname[C["Explosive Shot"]] = C["Explosive Shot"]
	def.name[C["Explosive Shot"]] = C["Explosive Shot"]
	def.typeshortdot[C["Explosive Shot"]] = true
	def.dotlength[C["Explosive Shot"]] = 2
	def.icon[C["Explosive Shot"]] =  C["Explosive Shot Icon"]
	def.stockspell[C["Explosive Shot"]] = true
end

function Watcher:SerpentSting()
	local def = Watcher.defaults.char.spell
	def.spellname[C["Serpent Sting"]] = C["Serpent Sting"]
	def.name[C["Serpent Sting"]] = C["Serpent Sting"]
	def.typedot[C["Serpent Sting"]] = true
	def.icon[C["Serpent Sting"]] =  C["Serpent Sting Icon"]
	def.trackspell[C["Serpent Sting"]] = C["Serpent Sting"]
	def.stockspell[C["Serpent Sting"]] = true
end

function Watcher:BlackArrow()
	local def = Watcher.defaults.char.spell
	def.spellname[C["Black Arrow"]] = C["Black Arrow"]
	def.name[C["Black Arrow"]] = C["Black Arrow"]
	def.icon[C["Black Arrow"]] =  C["Black Arrow Icon"]
	def.stockspell[C["Black Arrow"]] = true
end
function Watcher:KillCommand()
	local def = Watcher.defaults.char.spell
	def.spellname[C["Kill Command"]] = C["Kill Command"]
	def.name[C["Kill Command"]] = C["Kill Command"]
	def.icon[C["Kill Command"]] =  C["Kill Command Icon"]
	def.stockspell[C["Kill Command"]] = true
end

function Watcher:HM()
	local def = Watcher.defaults.char.spell
	def.spellname[C["Hunter's Mark"]] = C["Hunter's Mark"]
	def.name[C["Hunter's Mark"]] = C["Hunter's Mark"]
	def.icon[C["Hunter's Mark"]] = C["Hunter's Mark Icon"]
	def.typedot[C["Hunter's Mark"]] = true
	def.trackspell[C["Hunter's Mark"]] = C["Hunter's Mark"]
	def.stockspell[C["Hunter's Mark"]] = true
end

function Watcher:Misdirection()
	local def = Watcher.defaults.char.spell
	def.spellname[C["Misdirection"]] = C["Misdirection"]
	def.name[C["Misdirection"]] = C["Misdirection"]
	def.typedot[C["Misdirection"]] = false
	def.typeshortdot[C["Misdirection"]] = false
	def.dotlength[C["Misdirection"]] = 0
	def.dottime[C["Misdirection"]] = 0
	def.isbuff[C["Misdirection"]] = false
	def.icon[C["Misdirection"]] =  C["Misdirection Icon"]
	def.powerthresh[C["Misdirection"]] = 0
	def.countreq[C["Misdirection"]] = 0
	def.dotthreshold[C["Misdirection"]] = 0
	def.combocost[C["Misdirection"]] = 0
	def.trackspell[C["Misdirection"]] = nil
	def.nocd[C["Misdirection"]] = false
	def.caster[C["Misdirection"]] = false
	def.isproc[C["Misdirection"]] = false
	def.negthreshold[C["Misdirection"]] = false
	def.stockspell[C["Misdirection"]] = true
end

function Watcher:ADH()
	local def = Watcher.defaults.char.spell
	def.spellname[C["Aspect of the Dragonhawk"]] = C["Aspect of the Dragonhawk"]
	def.name[C["Aspect of the Dragonhawk"]] = C["Aspect of the Dragonhawk"]
	def.typedot[C["Aspect of the Dragonhawk"]] = true
	def.typeshortdot[C["Aspect of the Dragonhawk"]] = false
	def.dotlength[C["Aspect of the Dragonhawk"]] = 0
	def.dottime[C["Aspect of the Dragonhawk"]] = 0
	def.isbuff[C["Aspect of the Dragonhawk"]] = true
	def.icon[C["Aspect of the Dragonhawk"]] =  C["Aspect of the Dragonhawk Icon"]
	def.powerthresh[C["Aspect of the Dragonhawk"]] = 95
	def.countreq[C["Aspect of the Dragonhawk"]] = 0
	def.dotthreshold[C["Aspect of the Dragonhawk"]] = 0
	def.combocost[C["Aspect of the Dragonhawk"]] = 0
	def.trackspell[C["Aspect of the Dragonhawk"]] = C["Aspect of the Dragonhawk"]
	def.nocd[C["Aspect of the Dragonhawk"]] = true
	def.caster[C["Aspect of the Dragonhawk"]] = false
	def.isproc[C["Aspect of the Dragonhawk"]] = false
	def.negthreshold[C["Aspect of the Dragonhawk"]] = false
	def.stockspell[C["Aspect of the Dragonhawk"]] = true
end

function Watcher:AVH()
	local def = Watcher.defaults.char.spell
	def.spellname[C["Aspect of the Viper"]] = C["Aspect of the Viper"]
	def.name[C["Aspect of the Viper"]] = C["Aspect of the Viper"]
	def.typedot[C["Aspect of the Viper"]] = true
	def.typeshortdot[C["Aspect of the Viper"]] = false
	def.dotlength[C["Aspect of the Viper"]] = 0
	def.dottime[C["Aspect of the Viper"]] = 0
	def.isbuff[C["Aspect of the Viper"]] = true
	def.icon[C["Aspect of the Viper"]] =  C["Aspect of the Viper Icon"]
	def.powerthresh[C["Aspect of the Viper"]] = 5
	def.countreq[C["Aspect of the Viper"]] = 0
	def.dotthreshold[C["Aspect of the Viper"]] = 0
	def.combocost[C["Aspect of the Viper"]] = 0
	def.trackspell[C["Aspect of the Viper"]] = C["Aspect of the Viper"]
	def.nocd[C["Aspect of the Viper"]] = true
	def.caster[C["Aspect of the Viper"]] = false
	def.isproc[C["Aspect of the Viper"]] = false
	def.negthreshold[C["Aspect of the Viper"]] = true
	def.stockspell[C["Aspect of the Viper"]] = true
end

function Watcher:ChimeraShot()
	local def = Watcher.defaults.char.spell
	def.spellname[C["Chimera Shot"]] = C["Chimera Shot"]
	def.name[C["Chimera Shot"]] = C["Chimera Shot"]
	def.typedot[C["Chimera Shot"]] = false
	def.typeshortdot[C["Chimera Shot"]] = false
	def.dotlength[C["Chimera Shot"]] = 0
	def.dottime[C["Chimera Shot"]] = 0
	def.isbuff[C["Chimera Shot"]] = false
	def.icon[C["Chimera Shot"]] =  C["Chimera Shot Icon"]
	def.powerthresh[C["Chimera Shot"]] = 0
	def.countreq[C["Chimera Shot"]] = 0
	def.dotthreshold[C["Chimera Shot"]] = 0
	def.combocost[C["Chimera Shot"]] = 0
	def.trackspell[C["Chimera Shot"]] = C["Chimera Shot"]
	def.nocd[C["Chimera Shot"]] = false
	def.caster[C["Chimera Shot"]] = false
	def.isproc[C["Chimera Shot"]] = false
	def.negthreshold[C["Chimera Shot"]] = false
	def.stockspell[C["Chimera Shot"]] = true
end

function Watcher:ArcaneShot()
	local def = Watcher.defaults.char.spell
	def.spellname[C["Arcane Shot"]] = C["Arcane Shot"]
	def.name[C["Arcane Shot"]] = C["Arcane Shot"]
	def.typedot[C["Arcane Shot"]] = false
	def.typeshortdot[C["Arcane Shot"]] = false
	def.dotlength[C["Arcane Shot"]] = 0
	def.dottime[C["Arcane Shot"]] = 0
	def.isbuff[C["Arcane Shot"]] = false
	def.icon[C["Arcane Shot"]] =  C["Arcane Shot Icon"]
	def.powerthresh[C["Arcane Shot"]] = 0
	def.countreq[C["Arcane Shot"]] = 0
	def.dotthreshold[C["Arcane Shot"]] = 0
	def.combocost[C["Arcane Shot"]] = 0
	def.trackspell[C["Arcane Shot"]] = C["Arcane Shot"]
	def.nocd[C["Arcane Shot"]] = false
	def.caster[C["Arcane Shot"]] = false
	def.isproc[C["Arcane Shot"]] = false
	def.negthreshold[C["Arcane Shot"]] = false
	def.stockspell[C["Arcane Shot"]] = true
end


function Watcher:MultiShot()
	local def = Watcher.defaults.char.spell
	def.spellname[C["Multi-Shot"]] = C["Multi-Shot"]
	def.name[C["Multi-Shot"]] = C["Multi-Shot"]
	def.typedot[C["Multi-Shot"]] = false
	def.typeshortdot[C["Multi-Shot"]] = false
	def.dotlength[C["Multi-Shot"]] = 0
	def.dottime[C["Multi-Shot"]] = 0
	def.isbuff[C["Multi-Shot"]] = false
	def.icon[C["Multi-Shot"]] =  C["Multi-Shot Icon"]
	def.powerthresh[C["Multi-Shot"]] = 0
	def.countreq[C["Multi-Shot"]] = 0
	def.dotthreshold[C["Multi-Shot"]] = 0
	def.combocost[C["Multi-Shot"]] = 0
	def.trackspell[C["Multi-Shot"]] = C["Multi-Shot"]
	def.nocd[C["Multi-Shot"]] = false
	def.caster[C["Multi-Shot"]] = false
	def.isproc[C["Multi-Shot"]] = false
	def.negthreshold[C["Multi-Shot"]] = false
	def.stockspell[C["Multi-Shot"]] = true
end

function Watcher:SteadyShot()
	local def = Watcher.defaults.char.spell
	def.spellname[C["Steady Shot"]] = C["Steady Shot"]
	def.name[C["Steady Shot"]] = C["Steady Shot"]
	def.typedot[C["Steady Shot"]] = false
	def.typeshortdot[C["Steady Shot"]] = false
	def.dotlength[C["Steady Shot"]] = 0
	def.dottime[C["Steady Shot"]] = 0
	def.isbuff[C["Steady Shot"]] = false
	def.icon[C["Steady Shot"]] =  C["Steady Shot Icon"]
	def.powerthresh[C["Steady Shot"]] = 0
	def.countreq[C["Steady Shot"]] = 0
	def.dotthreshold[C["Steady Shot"]] = 0
	def.combocost[C["Steady Shot"]] = 0
	def.trackspell[C["Steady Shot"]] = C["Steady Shot"]
	def.nocd[C["Steady Shot"]] = false
	def.caster[C["Steady Shot"]] = false
	def.isproc[C["Steady Shot"]] = false
	def.negthreshold[C["Steady Shot"]] = false
	def.stockspell[C["Steady Shot"]] = true
end


function Watcher:KillShot()
	local def = Watcher.defaults.char.spell
	def.spellname[C["Kill Shot"]] = C["Kill Shot"]
	def.name[C["Kill Shot"]] = C["Kill Shot"]
	def.typedot[C["Kill Shot"]] = false
	def.typeshortdot[C["Kill Shot"]] = false
	def.dotlength[C["Kill Shot"]] = 0
	def.dottime[C["Kill Shot"]] = 0
	def.isbuff[C["Kill Shot"]] = false
	def.icon[C["Kill Shot"]] =  C["Kill Shot Icon"]
	def.powerthresh[C["Kill Shot"]] = 0
	def.countreq[C["Kill Shot"]] = 0
	def.dotthreshold[C["Kill Shot"]] = 0
	def.combocost[C["Kill Shot"]] = 0
	def.trackspell[C["Kill Shot"]] = nil
	def.nocd[C["Kill Shot"]] = false
	def.caster[C["Kill Shot"]] = false
	def.isproc[C["Kill Shot"]] = false
	def.negthreshold[C["Kill Shot"]] = false
	def.stockspell[C["Kill Shot"]] = true
end


function Watcher:Readiness()
	local def = Watcher.defaults.char.spell
	--self:Print(C["Readiness"])
	def.spellname[C["Readiness"]] = C["Readiness"]
	def.name[C["Readiness"]] = C["Readiness"]
	def.typedot[C["Readiness"]] = false
	def.typeshortdot[C["Readiness"]] = false
	def.dotlength[C["Readiness"]] = 0
	def.dottime[C["Readiness"]] = 0
	def.isbuff[C["Readiness"]] = false
	def.icon[C["Readiness"]] =  C["Readiness Icon"]
	def.powerthresh[C["Readiness"]] = 0
	def.countreq[C["Readiness"]] = 0
	def.dotthreshold[C["Readiness"]] = 0
	def.combocost[C["Readiness"]] = 0
	def.trackspell[C["Readiness"]] = C["Readiness"]
	def.nocd[C["Readiness"]] = false
	def.caster[C["Readiness"]] = false
	def.isproc[C["Readiness"]] = false
	def.negthreshold[C["Readiness"]] = false
	def.stockspell[C["Readiness"]] = true
end

function Watcher:SilencingShot()
	local def = Watcher.defaults.char.spell
	def.spellname[C["Silencing Shot"]] = C["Silencing Shot"]
	def.name[C["Silencing Shot"]] = C["Silencing Shot"]
	def.typedot[C["Silencing Shot"]] = false
	def.typeshortdot[C["Silencing Shot"]] = false
	def.dotlength[C["Silencing Shot"]] = 0
	def.dottime[C["Silencing Shot"]] = 0
	def.isbuff[C["Silencing Shot"]] = false
	def.icon[C["Silencing Shot"]] =  C["Silencing Shot Icon"]
	def.powerthresh[C["Silencing Shot"]] = 0
	def.countreq[C["Silencing Shot"]] = 0
	def.dotthreshold[C["Silencing Shot"]] = 0
	def.combocost[C["Silencing Shot"]] = 0
	def.trackspell[C["Silencing Shot"]] = C["Silencing Shot"]
	def.nocd[C["Silencing Shot"]] = false
	def.caster[C["Silencing Shot"]] = false
	def.isproc[C["Silencing Shot"]] = false
	def.negthreshold[C["Silencing Shot"]] = false
	def.stockspell[C["Silencing Shot"]] = true
end
function Watcher:RapidFire()
	local def = Watcher.defaults.char.spell
	def.spellname[C["Rapid Fire"]] = C["Rapid Fire"]
	def.name[C["Rapid Fire"]] = C["Rapid Fire"]
	def.typedot[C["Rapid Fire"]] = false
	def.typeshortdot[C["Rapid Fire"]] = false
	def.dotlength[C["Rapid Fire"]] = 0
	def.dottime[C["Rapid Fire"]] = 0
	def.isbuff[C["Rapid Fire"]] = false
	def.icon[C["Rapid Fire"]] =  C["Rapid Fire Icon"]
	def.powerthresh[C["Rapid Fire"]] = 0
	def.countreq[C["Rapid Fire"]] = 0
	def.dotthreshold[C["Rapid Fire"]] = 0
	def.combocost[C["Rapid Fire"]] = 0
	def.trackspell[C["Rapid Fire"]] = C["Rapid Fire"]
	def.nocd[C["Rapid Fire"]] = false
	def.caster[C["Rapid Fire"]] = false
	def.isproc[C["Rapid Fire"]] = false
	def.negthreshold[C["Rapid Fire"]] = false
	def.stockspell[C["Rapid Fire"]] = true
end
function Watcher:BloodFury()
	local def = Watcher.defaults.char.spell
	def.spellname[C["Blood Fury"]] = C["Blood Fury"]
	def.name[C["Blood Fury"]] = C["Blood Fury"]
	def.typedot[C["Blood Fury"]] = false
	def.typeshortdot[C["Blood Fury"]] = false
	def.dotlength[C["Blood Fury"]] = 0
	def.dottime[C["Blood Fury"]] = 0
	def.isbuff[C["Blood Fury"]] = false
	def.icon[C["Blood Fury"]] =  C["Blood Fury Icon"]
	def.powerthresh[C["Blood Fury"]] = 0
	def.countreq[C["Blood Fury"]] = 0
	def.dotthreshold[C["Blood Fury"]] = 0
	def.combocost[C["Blood Fury"]] = 0
	def.trackspell[C["Blood Fury"]] = C["Blood Fury"]
	def.nocd[C["Blood Fury"]] = false
	def.caster[C["Blood Fury"]] = false
	def.isproc[C["Blood Fury"]] = false
	def.negthreshold[C["Blood Fury"]] = false
	def.stockspell[C["Blood Fury"]] = true
end

function Watcher:BestialWrath()
	local def = Watcher.defaults.char.spell
	def.spellname[C["Bestial Wrath"]] = C["Bestial Wrath"]
	def.name[C["Bestial Wrath"]] = C["Bestial Wrath"]
	def.typedot[C["Bestial Wrath"]] = false
	def.typeshortdot[C["Bestial Wrath"]] = false
	def.dotlength[C["Bestial Wrath"]] = 0
	def.dottime[C["Bestial Wrath"]] = 0
	def.isbuff[C["Bestial Wrath"]] = false
	def.icon[C["Bestial Wrath"]] =  C["Bestial Wrath Icon"]
	def.powerthresh[C["Bestial Wrath"]] = 0
	def.countreq[C["Bestial Wrath"]] = 0
	def.dotthreshold[C["Bestial Wrath"]] = 0
	def.combocost[C["Bestial Wrath"]] = 0
	def.trackspell[C["Bestial Wrath"]] = C["Bestial Wrath"]
	def.nocd[C["Bestial Wrath"]] = false
	def.caster[C["Bestial Wrath"]] = false
	def.isproc[C["Bestial Wrath"]] = false
	def.negthreshold[C["Bestial Wrath"]] = false
	def.stockspell[C["Bestial Wrath"]] = true
end


Watcher.priorityTable.name["gcd"] = "GCD"
Watcher.priorityTable.icon["gcd"] = C["Beast Lore Icon"]
Watcher.priorityTable.check["gcd"] =  
	function (FrameName, optionnum) 	
		local start, duration = GetSpellCooldown(C["Beast Lore"])
		if duration > 0 then
			FrameName:SetAlpha(1)
			local timeleft = start + duration - GetTime()
			Watcher:MoveGCD(FrameName, timeleft)
			return
		end
		if start == 0 then
			FrameName:SetAlpha(0)
		end
	end 
	