local L = LibStub("AceLocale-3.0"):NewLocale("Details_ChartViewer", "esES")
if not L then return end

--[[Translation missing --]]
--[[ L["STRING_ADDEDOKAY"] = ""--]]
--[[Translation missing --]]
--[[ L["STRING_CONFIRM"] = ""--]]
--[[Translation missing --]]
--[[ L["STRING_NEWTAB"] = ""--]]
--[[Translation missing --]]
--[[ L["STRING_OPTIONS"] = ""--]]
--[[Translation missing --]]
--[[ L["STRING_OPTIONS_SHOWICON"] = ""--]]
--[[Translation missing --]]
--[[ L["STRING_OPTIONS_WINDOWSCALE"] = ""--]]
--[[Translation missing --]]
--[[ L["STRING_PLUGIN_DESC"] = ""--]]
--[[Translation missing --]]
--[[ L["STRING_PLUGIN_NAME"] = ""--]]
--[[Translation missing --]]
--[[ L["STRING_TOOLTIP"] = ""--]]
--[[Translation missing --]]
--[[ L["STRING_TOOSHORTNAME"] = ""--]]

