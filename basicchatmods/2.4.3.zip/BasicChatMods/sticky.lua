
--[[		Sticky Channels		]]--


--[[		Following are on(1) by default, uncomment them to turn them off		]]--
--ChatTypeInfo.SAY.sticky = 0
--ChatTypeInfo.PARTY.sticky = 0
--ChatTypeInfo.GUILD.sticky = 0
--ChatTypeInfo.RAID.sticky = 0
--ChatTypeInfo.BATTLEGROUND.sticky = 0


--[[		Following are off(0) by default so we turn them on, comment them(--) to turn them off		]]--
ChatTypeInfo.EMOTE.sticky = 1
ChatTypeInfo.YELL.sticky = 1
ChatTypeInfo.OFFICER.sticky = 1
ChatTypeInfo.RAID_WARNING.sticky = 1
ChatTypeInfo.WHISPER.sticky = 1
ChatTypeInfo.CHANNEL.sticky = 1
