--[[
	Watto v1.3
	English Localization
]]

-- Base Info
WATTO_TITLE = "Watto";
WATTO_VERSION = "Version";
WATTO_VERSION_SMALL = "v";
WATTO_ERROR = "Error";

-- Errors
WATTO_ERROR_NOITEMS = "There are no items to sell.";
WATTO_ERROR_UNKNOWNCOMMAND = "I didn't recognize that command.";
WATTO_ERROR_LIST_BADITEM = "Sorry, but %s is not sellable.";

--Listing
WATTO_LIST_ADDGENERAL_SUCCESS = "%s has been added to the general exclusion list.";
WATTO_LIST_ADDGENERAL_FAIL = "%s is already in the general exclusion list.";
WATTO_LIST_ADDPERSONAL_SUCCESS = "%s has been added to your personal exclusion list.";
WATTO_LIST_ADDPERSONALBUTINGENERAL_SUCCESS = "%s has been added, but is already in the general exclusion list. This item will no longer be sold.";
WATTO_LIST_ADDPERSONAL_FAIL = "%s is already in your personal exclusion list.";
WATTO_LIST_REMGENERAL_SUCCESS = "%s has been removed from the general exclusion list.";
WATTO_LIST_REMGENERAL_FAIL = "%s is not in the general exclusion list.";
WATTO_LIST_REMPERSONAL_SUCCESS = "%s has been removed from your personal exclusion list.";
WATTO_LIST_REMPERSONAL_FAIL = "%s is not in your personal exclusion list.";
WATTO_LIST_EMPTYGENERAL = "The general exclusion list is empty.";
WATTO_LIST_EMPTYPERSONAL = "Your personal exclusion list is empty.";
WATTO_LIST_GENERALLISTING = "General Exclusion List:";
WATTO_LIST_PERSONALLISTING = "Personal Exclusion List:";
WATTO_LIST_ADDFOOD_SUCCESS = "Food items are automatically sold to vendors. %s will no longer be sold to vendors.";
WATTO_LIST_ADDPERSONALBUTINGENERALFOOD_SUCCESS = "Food items are automatically sold to vendors. %s is now in both exclusion lists, and will be sold to vendors. You may wish to remove it from both lists instead.";
WATTO_LIST_REMALL = "Every item on the general exclusion list has been removed.";
WATTO_LIST_REMMEALL = "Every item on your personal exclusion list has been removed.";

-- Buying Localization
WATTO_BUY_TITLE = "Watto's Bulk Supplies";
WATTO_BUY_STACK = "Add Stack";
WATTO_BUY_CANAFFORD = "Can Afford";
WATTO_BUY_FILLSTACKS = "Fill Stacks";
WATTO_BUY_FILLBAGS = "Fill Bags";
WATTO_BUY_PURCHASE = "Purchase";
WATTO_BUY_COST = "Cost:";

WATTO_BUY_ERROR_TOOMANY = "You do not have enough bag space for that many items.";
WATTO_BUY_ERROR_TOOEXPENSIVE = "You can not afford that.";

-- Item Types
WATTO_ITEMTYPE_CONSUMABLE = "Consumable";

-- Item Subtypes
WATTO_ITEMSUBTYPE_FOODANDDRINK = "Food & Drink";

-- Selling Localization
WATTO_SELL_ITEM = "Selling: %s";

--Sell Text
WATTO_SELL_TOTALGAINSNUM = 17; -- This should equal the total number of WATTO_SELL_TOTALGAINS lines, not counting WATTO_SELL_TOTALGAINS00.
WATTO_SELL_TOTALGAINS00 = "Profit Earned: %s"; 		-- Non-Random Text.
-- Randomized Text. If RandomText == on, then these show. Otherwise, only show WATTO_SELL_TOTALGAINS00.
-- Feel free to add your own. The translations don't have to match these at all! But I would like them too...
WATTO_SELL_TOTALGAINS01 = "Here's your %s.";
WATTO_SELL_TOTALGAINS02 = "I suppose I could give you %s for all that...";
WATTO_SELL_TOTALGAINS03 = "%s! That's my final offer!";
WATTO_SELL_TOTALGAINS04 = "I know a good way to invest that %s...";
WATTO_SELL_TOTALGAINS05 = "If I had %s, I'd bet it on Sebulba!";
WATTO_SELL_TOTALGAINS06 = "%s, huh? So... Care to make a wager?";
WATTO_SELL_TOTALGAINS07 = "%s, it's a good deal, yeah?";
WATTO_SELL_TOTALGAINS08 = "Okay, %s, but YOU have do the shlepping!";
WATTO_SELL_TOTALGAINS09 = random(2,7).." minutes ago, I could of gotten you more than %s... ";
WATTO_SELL_TOTALGAINS10 = "What?! Anakin gave you %s for that?!";
WATTO_SELL_TOTALGAINS11 = "Another day, another %s...";
WATTO_SELL_TOTALGAINS12 = "You see %s, I see a price hike!";
WATTO_SELL_TOTALGAINS13 = "Demand for that is low... I'll give you %s.";
WATTO_SELL_TOTALGAINS14 = "I have a customer that wants all that for %s! With my 10%% fee of course...";
WATTO_SELL_TOTALGAINS15 = "You won't find a better deal than %s, I think.";
WATTO_SELL_TOTALGAINS16 = "I'm feeling generious. I'll give you %s.";
WATTO_SELL_TOTALGAINS17 = "%s?! Ha! I'd get more for selling my Chancecube!";


-- Command-Line Options
WATTO_CMD_ADD = "add";
WATTO_CMD_ADD_ME = WATTO_CMD_ADD.." me";
WATTO_CMD_REM = "rem";
WATTO_CMD_REM_ALL = WATTO_CMD_REM.." all";
WATTO_CMD_REMOVE = "remove";
WATTO_CMD_REMOVE_ALL = WATTO_CMD_REMOVE.." all";
WATTO_CMD_REM_ME =  WATTO_CMD_REM.." me";
WATTO_CMD_REM_ME_ALL =  WATTO_CMD_REM_ME.." all";
WATTO_CMD_REMOVE_ME = WATTO_CMD_REMOVE.." me";
WATTO_CMD_REMOVE_ME_ALL = WATTO_CMD_REMOVE_ME.." all";
WATTO_CMD_LIST = "list";
WATTO_CMD_LIST_ME = WATTO_CMD_LIST.." me";
WATTO_CMD_OPTIONS = "options";
WATTO_CMD_OPTIONS_AUTOSELL = WATTO_CMD_OPTIONS.." autosell";
WATTO_CMD_OPTIONS_AUTOSELL_ON = WATTO_CMD_OPTIONS_AUTOSELL.." on";
WATTO_CMD_OPTIONS_AUTOSELL_OFF = WATTO_CMD_OPTIONS_AUTOSELL.." off";
WATTO_CMD_OPTIONS_SELLNOTIFY = WATTO_CMD_OPTIONS.." notify";
WATTO_CMD_OPTIONS_SELLNOTIFY_ON = WATTO_CMD_OPTIONS_SELLNOTIFY.." on";
WATTO_CMD_OPTIONS_SELLNOTIFY_OFF = WATTO_CMD_OPTIONS_SELLNOTIFY.." off";
WATTO_CMD_OPTIONS_RANDOMSELLTEXT = WATTO_CMD_OPTIONS.." randomtext";
WATTO_CMD_OPTIONS_RANDOMSELLTEXT_ON = WATTO_CMD_OPTIONS_RANDOMSELLTEXT.." on";
WATTO_CMD_OPTIONS_RANDOMSELLTEXT_OFF = WATTO_CMD_OPTIONS_RANDOMSELLTEXT.." off";
WATTO_CMD_OPTIONS_AUTOSELL_FOOD = WATTO_CMD_OPTIONS_AUTOSELL.." food";
WATTO_CMD_OPTIONS_AUTOSELL_FOOD_ON = WATTO_CMD_OPTIONS_AUTOSELL_FOOD.." on";
WATTO_CMD_OPTIONS_AUTOSELL_FOOD_OFF = WATTO_CMD_OPTIONS_AUTOSELL_FOOD.." off";

-- Help
WATTO_HELP_TITLE = "Help:";
WATTO_HELP_OPTIONS_TITLE = "Options Help:";
WATTO_HELP_ADD = "add (Item) = Add an item to the Global List.";
WATTO_HELP_ADD_ME = "add (Item) = Add an item to your Personal List.";
WATTO_HELP_REM = "rem (Item) or remove (Item) = Remove an item to the Global List.";
WATTO_HELP_REM_ME = "rem me (Item) or remove me (Item) = Remove an item to your Personal List.";
WATTO_HELP_REM_ALL = "rem all = Remove everything from the Global List.";
WATTO_HELP_REM_ME_ALL = "rem me all = Remove everything from your Personal List.";
WATTO_HELP_LIST = "list = List the items currently being globablly excluded."
WATTO_HELP_LIST_ME = "list me = List the items currently being excluded by only you."
WATTO_HELP_OPTIONS_DESCRIPTION = "options = get help on the various Option settings.";
WATTO_HELP_OPTIONS_AUTOSELL = "autosell [on/off] = Toggle the automatic selling of your junk items.";
WATTO_HELP_OPTIONS_AUTOSELL_FOOD = "autosell food [on/off] = Toggle the automatic selling of food and drink items.";
WATTO_HELP_OPTIONS_SELLNOTIFY = "notify [on/off] = Toggle the showing of the items you sell to the vendor.";
WATTO_HELP_OPTIONS_RANDOMSELLTEXT = "randomtext [on/off] = Toggle Watto's Random saying when you sell items.";

WATTO_HELP = WATTO_HELP_TITLE.."\r"..WATTO_HELP_ADD_ME.."\r"..WATTO_HELP_REM.."\r"..WATTO_HELP_REM_ME.."\r"..WATTO_HELP_REM_ALL.."\r"..WATTO_HELP_REM_ME_ALL.."\r"..WATTO_HELP_LIST.."\r"..WATTO_HELP_LIST_ME.."\r"..WATTO_HELP_OPTIONS_DESCRIPTION;
WATTO_HELP_OPTIONS = WATTO_HELP_OPTIONS_TITLE.."\r"..WATTO_HELP_OPTIONS_AUTOSELL.."\r"..WATTO_HELP_OPTIONS_AUTOSELL_FOOD.."\r"..WATTO_HELP_OPTIONS_SELLNOTIFY.."\r"..WATTO_HELP_OPTIONS_RANDOMSELLTEXT;
WATTO_HELP_ADD_TEXT = WATTO_HELP_TITLE.."\r"..WATTO_HELP_ADD;
WATTO_HELP_ADD_ME_TEXT = WATTO_HELP_TITLE.."\r"..WATTO_HELP_ADD_ME;
WATTO_HELP_REM_TEXT = WATTO_HELP_TITLE.."\r"..WATTO_HELP_REM;
WATTO_HELP_REM_ME_TEXT = WATTO_HELP_TITLE.."\r"..WATTO_HELP_REM_ME;

-- Money
WATTO_COPPER_S = "c";
WATTO_SILVER_S = "s";
WATTO_GOLD_S = "g";

-- Commandline Replies
WATTO_CMDTXT_OPTIONS_AUTOSELL_ON = "Autosell is now on.";
WATTO_CMDTXT_OPTIONS_AUTOSELL_OFF = "Autosell is now off.";
WATTO_CMDTXT_OPTIONS_SELLNOTIFY_ON = "Selling Notification is now on.";
WATTO_CMDTXT_OPTIONS_SELLNOTIFY_OFF = "Selling Notification is now off.";
WATTO_CMDTXT_OPTIONS_RANDOMSELLTEXT_ON = "Random Text is now on.";
WATTO_CMDTXT_OPTIONS_RANDOMSELLTEXT_OFF = "Random Text is now off.";

-- Tooltip
WATTO_TOOLTIP_SELL_TITLE = "Watto's Junkyard";
WATTO_TOOLTIP_SELL_TEXT = "Estimated Profit: %s";