--[[
	Sick Of Clicking Dailies? - Locale file for frFR
	Written By: OrionShock
	
	Please Visit: http://www.wowace.com/addons/sick-of-clicking-dailies/pages/how-to-add-localizations/
	to contribute to localizations :)
]]--
local addonName = ...





local genderMale = UnitSex("player") == 2

local L = LibStub("AceLocale-3.0"):NewLocale(addonName, "frFR", false)

if L then

L["Argent Crusade"] = "La Croisade d'argent"
L["Auto Complete Daily or Weekly?"] = "Rendu automatique des journalières ou hebdomadaires ?"
L["Bombing Quests in Icecrown"] = "Quêtes de bombardement dans la Couronne de glace"
L["Brewfest"] = "Fête des Brasseurs"
L["Burning Crusade"] = true
L["Candy Bucket"] = "Seau de bonbons"
L["Click: Left for Quest Log"] = "Click : Gauche pour le Journal des quêtes"
L["Cooking"] = "Cuisine"
L["Dailies On Alts"] = "Journalières des rerolls"
L["Dailies for all Characters"] = "Journalières de tous les personnages"
L["Dailies reset in"] = "Réinitialisation des journalières dans"
L["Gossip Options"] = "Options de discussion"
L["Innkeeper Trick or treating"] = "Un bonbon ou une blague de l'aubergiste"
L["Jousting Challenge"] = "Challenge de joute"
L["MainOptionsDesc"] = "Ces options ne concernent maintenant que les quêtes qui ont des récompenses. Si vous cherchez à activer ou désactiver des quêtes particulières, parlez au donneur de quête, une case à cocher de rendu automatique sera présente. N'oubliez pas de maintenir la touche Maj enfoncée pour désactiver le rendu automatique."
L["Only Works for Daily and Weekly Quests"] = "Ne fonctionne que pour les quêtes journalières et hebdomadaires"
L["Right for SOCD Options"] = "Droit pour les options de SOCD"
L["SSO Quests"] = "Quêtes OSB"
L["Still Setting up localizations please wait"] = "Mise en place de la traduction en cours, merci de patienter"
L["Wrath of the Lich King"] = true


end

local GT = LibStub("AceLocale-3.0"):NewLocale(addonName.."GossipText", "frFR", false)
	if GT then

-- GT["Do you still need some help moving kegs from the crash site near Razor Hill?"] = ""
GT["Do you still need some help shipping kegs from Kharanos?"] = "Avez-vous encore besoin d'aide pour faire venir des tonneaux de Kharanos ?"
GT["Get out there and make those Scourge wish they were never reborn!"] = "Allez-y, et faites regretter à ces abominations du Fléau d'être re-nés !"
GT["Give me a bomber!"] = "Donnez-moi un bombardier !"
GT["Go on, you're free.  Get out of here!"] = "Allez-y, vous êtes libre. Sortez d'ici !"
GT["I am ready to fight!(F)"] = "Je suis prête à me battre!"
GT["I am ready to fight!(M)"] = "Je suis prêt à me battre!"
GT["I'm ready to begin. What is the first ingredient you require?(F)"] = "Je suis prête. Quel est le premier ingrédient ?"
GT["I'm ready to begin. What is the first ingredient you require?(M)"] = "Je suis prêt. Quel est le premier ingrédient ?"
-- GT["I'm ready to join your squad on the way to Ymirheim. Let's get moving."] = ""
GT["I'm ready to work for you today!  Give me that ram!"] = "Je suis prêt à travailler pour vous aujourd'hui ! Donnez-moi ce bélier !"
GT["I'm ready to work for you today!  Give me the good stuff!"] = "Je suis prêt à travailler pour vous aujourd'hui ! Donnez-moi le matos !"
GT["Let's do this, sister."] = "Allons-y, sœurette."
GT["Mount the Hippogryph and prepare for battle!"] = "Montez votre hippogriffe et préparez-vous au combat !"
GT["Trick or Treat!"] = "Un bonbon ou une blague !"
GT["We need to get into the fight. Are you ready?"] = "Nous devons rejoindre la bataille. Êtes-vous prêt ?"



	local GT_R = LibStub("AceLocale-3.0"):GetLocale(addonName.."GossipText")
	if genderMale then	--Masculine Context
		GT["I'm ready to begin. What is the first ingredient you require?"] = GT_R["I'm ready to begin. What is the first ingredient you require?(M)"]:gsub("[%(MF%)]+$", "")
		GT["I am ready to fight!"] = GT_R["I am ready to fight!(M)"]:gsub("[%(MF%)]+$", "")

	else			--Feminine Context
		GT["I'm ready to begin. What is the first ingredient you require?"] = GT_R["I'm ready to begin. What is the first ingredient you require?(F)"]:gsub("[%(MF%)]+$", "")
		GT["I am ready to fight!"] = GT_R["I am ready to fight!(F)"]:gsub("[%(MF%)]+$", "")
	end
end



---Localization Counter-- Bump to generate new zip for locale changes = 16
