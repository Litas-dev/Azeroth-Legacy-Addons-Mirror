--[[
	Sick Of Clicking Dailies? - Locale file for enUS
	Written By: OrionShock
	
	Please Visit: http://www.wowace.com/addons/sick-of-clicking-dailies/pages/how-to-add-localizations/
	to contribute to localizations :)
]]--
local addonName = ...
local debug = false
--[===[@debug@
debug = true
--@end-debug@]===]

local genderMale = UnitSex("player") == 2

local L = LibStub("AceLocale-3.0"):NewLocale(addonName, "enUS", true, debug)

if L then

L["Argent Crusade"] = true
L["Auto Complete Daily or Weekly?"] = true
L["Bombing Quests in Icecrown"] = true
L["Brewfest"] = true
L["Burning Crusade"] = true
L["Candy Bucket"] = true
L["Click: Left for Quest Log"] = true
L["Cooking"] = true
L["Dailies On Alts"] = true
L["Dailies for all Characters"] = true
L["Dailies reset in"] = true
L["Gossip Options"] = true
L["Innkeeper Trick or treating"] = true
L["Jousting Challenge"] = true
L["MainOptionsDesc"] = "These Options now consist of just Quests that have rewards. If your looking for enabling or disabling specific quests, please go to the Quest Giver as there is now a check box there. Remember to hold down the shift key to stop it from Auto Completing though"
L["Only Works for Daily and Weekly Quests"] = true
L["Right for SOCD Options"] = true
L["SSO Quests"] = true
L["Still Setting up localizations please wait"] = true
L["Wrath of the Lich King"] = true


end

local GT = LibStub("AceLocale-3.0"):NewLocale(addonName.."GossipText", "enUS", true, debug)
	if GT then

GT["Do you still need some help moving kegs from the crash site near Razor Hill?"] = true
GT["Do you still need some help shipping kegs from Kharanos?"] = true
GT["Get out there and make those Scourge wish they were never reborn!"] = true
GT["Give me a bomber!"] = true
GT["Go on, you're free.  Get out of here!"] = true
GT["I am ready to fight!(F)"] = true
GT["I am ready to fight!(M)"] = true
GT["I'm ready to begin. What is the first ingredient you require?(F)"] = true
GT["I'm ready to begin. What is the first ingredient you require?(M)"] = true
GT["I'm ready to join your squad on the way to Ymirheim. Let's get moving."] = true
GT["I'm ready to work for you today!  Give me that ram!"] = true
GT["I'm ready to work for you today!  Give me the good stuff!"] = true
GT["Let's do this, sister."] = true
GT["Mount the Hippogryph and prepare for battle!"] = true
GT["Trick or Treat!"] = true
GT["We need to get into the fight. Are you ready?"] = true



	local GT_R = LibStub("AceLocale-3.0"):GetLocale(addonName.."GossipText")
	if genderMale then	--Masculine Context
		GT["I'm ready to begin. What is the first ingredient you require?"] = GT_R["I'm ready to begin. What is the first ingredient you require?(M)"]:gsub("[%(MF%)]+$", "")
		GT["I am ready to fight!"] = GT_R["I am ready to fight!(M)"]:gsub("[%(MF%)]+$", "")

	else			--Feminine Context
		GT["I'm ready to begin. What is the first ingredient you require?"] = GT_R["I'm ready to begin. What is the first ingredient you require?(F)"]:gsub("[%(MF%)]+$", "")
		GT["I am ready to fight!"] = GT_R["I am ready to fight!(F)"]:gsub("[%(MF%)]+$", "")
	end
end



---Localization Counter-- Bump to generate new zip for locale changes = 18
