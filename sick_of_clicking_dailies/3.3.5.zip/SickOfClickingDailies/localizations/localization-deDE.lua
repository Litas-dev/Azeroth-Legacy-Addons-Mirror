--[[
	Sick Of Clicking Dailies? - Locale file for deDE
	Written By: OrionShock
	
	Please Visit: http://www.wowace.com/addons/sick-of-clicking-dailies/pages/how-to-add-localizations/
	to contribute to localizations :)
]]--
local addonName = ...





local genderMale = UnitSex("player") == 2

local L = LibStub("AceLocale-3.0"):NewLocale(addonName, "deDE", false)

if L then

L["Argent Crusade"] = "Argentumkreuzzug"
L["Auto Complete Daily or Weekly?"] = "Quest automatisch Annehmen und Abgeben?"
L["Bombing Quests in Icecrown"] = "Bomberquests in Eiskrone"
L["Brewfest"] = "Braufest"
L["Burning Crusade"] = true
L["Candy Bucket"] = "Eimer mit Süßigkeiten"
L["Click: Left for Quest Log"] = "Klicken: Links für Questlog"
L["Cooking"] = "Kochkunst"
L["Dailies On Alts"] = "Dailies auf Twinks"
L["Dailies for all Characters"] = "Dailies für alle Charaktere"
L["Dailies reset in"] = "Dailies Reset in"
L["Gossip Options"] = "Tratsch-Optionen"
L["Innkeeper Trick or treating"] = "Süßes oder Saures bei Gastwirten"
L["Jousting Challenge"] = "Tunierkämpfe"
L["MainOptionsDesc"] = "Diese Optionen enthalten nun nur Quests, die Belohnungen haben. Wenn du spezifische Quests deaktivieren willst, geh bitte zum Questgeber, dort ist nun eine Option. Vergiss aber nicht die Umschalttaste gedrückt zu halten um die Automatik zu deaktivieren."
L["Only Works for Daily and Weekly Quests"] = "Funktioniert nur mit täglichen und wöchentlichen Quests"
L["Right for SOCD Options"] = "Rechts für SOCD Optionen"
L["SSO Quests"] = "Offensive der Zerschmetterten Sonne"
L["Still Setting up localizations please wait"] = "Lokalisierungen werden noch geladen, bitte warten."
L["Wrath of the Lich King"] = true


end

local GT = LibStub("AceLocale-3.0"):NewLocale(addonName.."GossipText", "deDE", false)
	if GT then

GT["Do you still need some help moving kegs from the crash site near Razor Hill?"] = "Braucht Ihr immer noch jemanden, der Euch hilft, Fässchen von der Unfallstelle bei Klingenhügel abzuholen?"
GT["Do you still need some help shipping kegs from Kharanos?"] = "Benötigt Ihr immer noch Hilfe, um die Fässer aus Kharanos abzutransportieren?"
GT["Get out there and make those Scourge wish they were never reborn!"] = "Raus mit Euch und verpasst der Geißel eine Abreibung, auf dass sie sich wünschen werden, niemals wiedergeboren zu sein!"
GT["Give me a bomber!"] = "Gebt mir einen Bomber!"
GT["Go on, you're free.  Get out of here!"] = "Geht schon, Ihr seid frei! Verschwindet von hier!"
GT["I am ready to fight!(F)"] = "Ich bin bereit für den Kampf!"
GT["I am ready to fight!(M)"] = "Ich bin bereit für den Kampf!"
GT["I'm ready to begin. What is the first ingredient you require?(F)"] = "Ich bin bereit, anzufangen. Was ist die erste Zutat, die Ihr benötigt?"
GT["I'm ready to begin. What is the first ingredient you require?(M)"] = "Ich bin bereit, anzufangen. Was ist die erste Zutat, die Ihr benötigt?"
GT["I'm ready to join your squad on the way to Ymirheim. Let's get moving."] = "Ich bin bereit, mich Eurer Truppe auf dem Weg nach Ymirheim anzuschließen. Gehen wir."
GT["I'm ready to work for you today!  Give me that ram!"] = "Ich will heute für Euch arbeiten! Überlasst mir den Widder!"
GT["I'm ready to work for you today!  Give me the good stuff!"] = "Ich würde Euch heute gerne bei Eurer Arbeit unterstützen! Packen wir's an!"
GT["Let's do this, sister."] = "Legen wir los, Schwester."
GT["Mount the Hippogryph and prepare for battle!"] = "Schwingt Euch auf den Hippogryphen und macht Euch bereit zum Kampf!"
GT["Trick or Treat!"] = "Süßes oder Saures!"
GT["We need to get into the fight. Are you ready?"] = "Wir müssen uns am Kampf beteiligen. Seid Ihr bereit?"



	local GT_R = LibStub("AceLocale-3.0"):GetLocale(addonName.."GossipText")
	if genderMale then	--Masculine Context
		GT["I'm ready to begin. What is the first ingredient you require?"] = GT_R["I'm ready to begin. What is the first ingredient you require?(M)"]:gsub("[%(MF%)]+$", "")
		GT["I am ready to fight!"] = GT_R["I am ready to fight!(M)"]:gsub("[%(MF%)]+$", "")

	else			--Feminine Context
		GT["I'm ready to begin. What is the first ingredient you require?"] = GT_R["I'm ready to begin. What is the first ingredient you require?(F)"]:gsub("[%(MF%)]+$", "")
		GT["I am ready to fight!"] = GT_R["I am ready to fight!(F)"]:gsub("[%(MF%)]+$", "")
	end
end



---Localization Counter-- Bump to generate new zip for locale changes = 16
