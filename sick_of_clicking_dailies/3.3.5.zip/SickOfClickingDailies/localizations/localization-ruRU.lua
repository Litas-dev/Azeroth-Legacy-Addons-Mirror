--[[
	Sick Of Clicking Dailies? - Locale file for ruRU
	Written By: OrionShock
	
	Please Visit: http://www.wowace.com/addons/sick-of-clicking-dailies/pages/how-to-add-localizations/
	to contribute to localizations :)
]]--
local addonName = ...





local genderMale = UnitSex("player") == 2

local L = LibStub("AceLocale-3.0"):NewLocale(addonName, "ruRU", false)

if L then

-- L["Argent Crusade"] = ""
-- L["Auto Complete Daily or Weekly?"] = ""
-- L["Bombing Quests in Icecrown"] = ""
-- L["Brewfest"] = ""
-- L["Burning Crusade"] = ""
-- L["Candy Bucket"] = ""
-- L["Click: Left for Quest Log"] = ""
-- L["Cooking"] = ""
-- L["Dailies On Alts"] = ""
-- L["Dailies for all Characters"] = ""
-- L["Dailies reset in"] = ""
-- L["Gossip Options"] = ""
-- L["Innkeeper Trick or treating"] = ""
-- L["Jousting Challenge"] = ""
-- L["MainOptionsDesc"] = ""
-- L["Only Works for Daily and Weekly Quests"] = ""
-- L["Right for SOCD Options"] = ""
-- L["SSO Quests"] = ""
-- L["Still Setting up localizations please wait"] = ""
-- L["Wrath of the Lich King"] = ""


end

local GT = LibStub("AceLocale-3.0"):NewLocale(addonName.."GossipText", "ruRU", false)
	if GT then

-- GT["Do you still need some help moving kegs from the crash site near Razor Hill?"] = ""
-- GT["Do you still need some help shipping kegs from Kharanos?"] = ""
-- GT["Get out there and make those Scourge wish they were never reborn!"] = ""
-- GT["Give me a bomber!"] = ""
-- GT["Go on, you're free.  Get out of here!"] = ""
-- GT["I am ready to fight!(F)"] = ""
-- GT["I am ready to fight!(M)"] = ""
-- GT["I'm ready to begin. What is the first ingredient you require?(F)"] = ""
-- GT["I'm ready to begin. What is the first ingredient you require?(M)"] = ""
-- GT["I'm ready to join your squad on the way to Ymirheim. Let's get moving."] = ""
-- GT["I'm ready to work for you today!  Give me that ram!"] = ""
-- GT["I'm ready to work for you today!  Give me the good stuff!"] = ""
-- GT["Let's do this, sister."] = ""
-- GT["Mount the Hippogryph and prepare for battle!"] = ""
-- GT["Trick or Treat!"] = ""
-- GT["We need to get into the fight. Are you ready?"] = ""



	local GT_R = LibStub("AceLocale-3.0"):GetLocale(addonName.."GossipText")
	if genderMale then	--Masculine Context
		GT["I'm ready to begin. What is the first ingredient you require?"] = GT_R["I'm ready to begin. What is the first ingredient you require?(M)"]:gsub("[%(MF%)]+$", "")
		GT["I am ready to fight!"] = GT_R["I am ready to fight!(M)"]:gsub("[%(MF%)]+$", "")

	else			--Feminine Context
		GT["I'm ready to begin. What is the first ingredient you require?"] = GT_R["I'm ready to begin. What is the first ingredient you require?(F)"]:gsub("[%(MF%)]+$", "")
		GT["I am ready to fight!"] = GT_R["I am ready to fight!(F)"]:gsub("[%(MF%)]+$", "")
	end
end



---Localization Counter-- Bump to generate new zip for locale changes = 16
