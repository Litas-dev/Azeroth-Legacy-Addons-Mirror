local L = LibStub("AceLocale-3.0"):NewLocale("EveryQuest", "esES")
if not L then return end

-- L[": No longer in DB"] = ""
-- L["Close"] = ""
-- L["Create waypoint"] = ""
-- L["Data Loading"] = ""
-- L["DataLoadWarning"] = ""
-- L["Enable: "] = ""
-- L["Enables Quest Names in tooltips and category filtering"] = ""
-- L["Hide Quest Giver"] = ""
-- L["Icon Alpha"] = ""
-- L["Icon Scale"] = ""
-- L["Icon Settings"] = ""
-- L["Load Data from EveryQuest database"] = ""
-- L["Query the EveryQuest database for quest names"] = ""
-- L["Quest Givers"] = ""
-- L["Show Quest Names in tooltip"] = ""
-- L["The alpha transparency of the icons"] = ""
-- L["The scale of the icons"] = ""
-- L["These settings control the look and feel of the Quest Givers icons."] = ""
-- L["Toggle Showing of Categories"] = ""
-- L["Toggle the display of quests by quest giver based on faction availability."] = ""

