if not ( GetLocale()=="ruRU" ) then
    return;
end

ABBREVIATED_STATUS_OPTION_VERSION   = "Версия: %s";

ABBREVIATED_STATUS_OPTION_REMAINDER = "Остаток после точки"

ABBREVIATED_STATUS_OPTION_PLAYER    = "Игрок";
ABBREVIATED_STATUS_OPTION_PET       = "Питомец игрока";
ABBREVIATED_STATUS_OPTION_TARGET    = "Цель";
ABBREVIATED_STATUS_OPTION_FOCUS     = "Фокус";
ABBREVIATED_STATUS_OPTION_PARTY     = "Группа";
ABBREVIATED_STATUS_OPTION_PARTYPET  = "Питомец группы";
ABBREVIATED_STATUS_OPTION_ARENA     = "Арена";

ABBREVIATED_STATUS_OPTION_HEALTH    = "Здоровье";
ABBREVIATED_STATUS_OPTION_MANA      = "Мана";

ABBREVIATED_STATUS_OPTION_STATUS    = "Текущее значение"
ABBREVIATED_STATUS_OPTION_PERCENT   = "Процентное значение"

ABBREVIATED_STATUS_OPTION_XOFF      = "Сдвинуть"
ABBREVIATED_STATUS_OPTION_YOFF      = "Сдвинуть"

ABBREVIATED_STATUS_OPTION_LEFT      = "Левее";
ABBREVIATED_STATUS_OPTION_RIGHT     = "Правее";

ABBREVIATED_STATUS_OPTION_UP        = "Выше";
ABBREVIATED_STATUS_OPTION_DOWN      = "Ниже";

ABBREVIATED_LOCK_STATUS             = "Откл.";

ABBREVIATED_STATUS_OPTION_PREFIX    = "Отображать префикс от: %s"

FOURTH_NUMBER_CAP_NO_SPACE          = "T";
THIRD_NUMBER_CAP_NO_SPACE           = "МЛРД";
SECOND_NUMBER_CAP_NO_SPACE          = "М";
FIRST_NUMBER_CAP_NO_SPACE           = "к";

DEFAULT_ABBREVIATED_STATUS          = "Вы хотите сбросить настройки по умолчанию этого раздела или весь профиль?"
DEFAULT_ABBREVIATED_ALL_PROFILE     = "Весь профиль"
