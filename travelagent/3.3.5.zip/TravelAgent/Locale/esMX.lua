﻿local L = LibStub("AceLocale-3.0"):NewLocale("TravelAgent", "esMX", false)

if not L then return end

