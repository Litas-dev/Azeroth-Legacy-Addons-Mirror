local L = AceLibrary("AceLocale-2.2"):new("Elephant")

L:RegisterTranslations("zhTW", function() return {
	--[[ Common messages ]]
	['chatlog']			= "將聊天記錄保存為檔案",
	['chatlog_desc']		= "Logs the chat (not the combat log) to Logs\\WoWChatLog.txt.\n\nNote: If this option is activated, the file logging will automatically be enabled back at login.",
	['combatlog']		= "將戰鬥記錄保存為檔案",
	['combatlog_desc']		= "Logs the combat chat to Logs\\WoWCombatLog.txt.\n\nNote: If this option is activated, the file logging will automatically be enabled back at login.",
	['disabled']		= "已停用",
	['enabled']			= "已啓用",
	['enableddefault']	= "記錄新頻道",
	['enableddefault_desc']	= "Automaticaly starts logging when you join a new channel.",
	['noprat']			= "你選擇根據 Prat 格式保存記錄，但 Prat 並未載入。會使用 Elephant 格式記錄訊息。",
	['reset']			= "重設",
	['reset_desc']			= "Reset options.",
	['toggle']			= "顯示 Elephant",
	['toggle_desc']			= "Shows or hides the main window.",
	
	--[[ Options menu elements ]]
	['activate']			= "Activate",
	['activate_desc']		= "Let Elephant control file logging. Disabling this option will leave the current logging status unchanged.\n\nWarning: You shouldn't let two different addons control the file logging.",
	['clearallhelp']		= "清除所有記錄",
	['clearallhelp_desc']	= "Clears all the saved logs.",
	['files']				= "File logging",
	['files_desc']			= "Options to save the logs into files.",
	['Filters']				= "過濾器",
	['Filters_desc']		= "Filters are used to avoid the logging of specific channels.",
	['filterusage']			= "頻道全名。你也可用通配字元 (*)。例: <AceComm*>",
	['filtererror']			= "不能增加過濾器「%s」。過濾器只能包括非空白字元及通配字元 (*)。",
	['filterregex']			= "^[%S%*]+$",
	['newfilter_desc']		= "Creates a new filter.",
	['deletefilter_desc']	= "Deletes a previously created filter.",
	['logs']				= "記錄",
	['logs_desc']			= "Logging options.",
	['maxcombatlogwords']	= "戰鬥最多記錄",
	['maxlogwords']			= "聊天最多記錄",
	['maxlogwords_desc']	= "Maximum size of each log.",
	['prat']				= "根據 Prat 格式保存記錄",
	['prat_desc']			= "Saves the logs the same way than Prat. Logs saved with this option enabled cannot be brought back to Elephant's default logging style.\n\nThis option is only available if you have Prat currently enabled.",
	['resethelp']			= "重設所有設定及聊天記錄",
	['resethelp_desc']		= "Resets all settings and chats.",
	['resetloc']			= "重設 Elephant 視窗位置",
	['resetloc_desc']		= "Resets Elephant's main window position.",
	['showbutton']			= "顯示按鈕",
	['showbutton_desc']		= "Displays a button over the normal chat buttons to toggle Elephant.",
	
	--[[ Main/Copy frame elements ]]
	-- Main
	['catchers']	= {
		[1]	= "訊息捕捉器",
		[2]	= "在這個記錄保存什麼訊息?",
		[3]	= "灰色的訊息類型不能被停用。"
	},
	['clearall']	= "清除所有",
	['copy']		= "複製",
	['Disable']		= "停用",
	['Empty']		= "清除",
	['Enable']		= "啓用",
	['maxlog']		= "最多記錄: %s行。",
	['nblines']		= "行: %s",
	['scroll']		= {
		['bottom']		= {
			[1]	= "最後一頁",
		},
		['linedown']	= {
			[1]	= "下一行",
		},
		['lineup']		= {
			[1]	= "上一行",
		},
		['pagedown']	= {
			[1]	= "下一頁",
		},
		['pageup']		= {
			[1]	= "上一頁",
		},
		['top']			= {
			[1]	= "第一頁",
		},
	},
	
	-- Copy
	['copywindow']	= "複製視窗",
	
	--[[ Special log messages ]]
	['logstartedon']	= "記錄開始日期: %s，時間: %s。",
	['logstopped']		= "記錄停止。",
	['monstersay']		= "%s說",
	['monsteryell']		= "%s大喊",
	['whisperfrom']		= "%s悄悄地說",
	['whisperto']		= "告訴%s",
	
	--[[ Addon messages ]]
	['clearallconfirm']		= "已清除所有聊天記錄。",
	['combatlogdisabled']	= "戰鬥記錄被停用。",
	['deleteconfirm']		= "已刪除聊天記錄: %s",
	['emptyconfirm']		= "已清除聊天記錄: %s",
	['lootmethod']			= {
		['freeforall']		= ERR_SET_LOOT_FREEFORALL,
		['group']			= ERR_SET_LOOT_GROUP,
		['master']			= ERR_SET_LOOT_MASTER,
		['needbeforegreed']	= ERR_SET_LOOT_NBG,
		['roundrobin']		= ERR_SET_LOOT_ROUNDROBIN,
	},
	['masterlooterchanged']	=  ERR_NEW_LOOT_MASTER_S,
	['resetconfirm']		= "已重設所有設定及聊天記錄。",
	
	--[[ Tooltips ]]
	['togglebuttontooltip']		= {
		[1]	= "|cffeda55f左擊: |r顯示 Elephant。",
		[2]	= "|cffeda55f中擊: |r重設按鈕位置。",
		[3]	= "|cffeda55f右擊: |r移動位置。",
	},
	['toggletooltip']			= "\n|cffeda55f左擊: |r顯示 Elephant。",
	
	--[[ Popup windows ]]
	['clearallpopup']	= {
		[1]	= "是否要清除所有記錄?",
		[2]	= "確定",
		[3]	= "取消",
	},
	['emptypopup']		= {
		[1]	= "是否清除目前的聊天記錄?",
		[2]	= "確定",
		[3]	= "取消",
	},
	['resetpopup']		= {
		[1]	= "是否要重設所有設定及聊天記錄?",
		[2]	= "確定",
		[3]	= "取消",
	},
	
	--[[ Default chat names to be displayed ]]
	['chatnames']	= {
		['combat']	= "戰鬥",
		['custom']	= "自訂頻道",
		['general']	= "綜合頻道",
		['guild']	= CHAT_MSG_GUILD,
		['loot']	= CHAT_MSG_LOOT,
		['misc']	= "雜項",
		['officer']	= CHAT_MSG_OFFICER,
		['party']	= CHAT_MSG_PARTY,
		['raid']	= CHAT_MSG_RAID,
		['say']		= CHAT_MSG_SAY,
		['system']	= SYSTEM_MESSAGES,
		['whisper']	= WHISPER,
		['yell']	= YELL_MESSAGE,
	},
	
	--[[ General chats (= that you cannot leave) names and strings that identify them ]]
	['generalchats']	= {
		['本地防務']		= {
			['name']	= "本地防務",
			['string']	= "本地防務",
		},
		['綜合']			= {
			['name']	= "綜合",
			['string']	= "綜合",
		},
		['公會招募']		= {
			['name']	= "公會招募",
			['string']	= "公會招募",
		},
		['交易']			= {
			['name']	= "交易",
			['string']	= "交易",
		},
		['世界防務']		= {
			['name']	= "世界防務",
			['string']	= "世界防務",
		},
	},
	
	--[[ Custom chats special log messages ]]
	['customchat']	= {
		['join']	= "你進入了頻道。",
		['leave']	= "你離開了頻道。",
	},
} end)