﻿	--Chinese Local : CWDG Translation Team 月色狼影
	--CWDG site: http://cwowaddon.com  Chinese Addon/UI download center.
	--$Rev: 62552 $
	--$Date: 2008-02-22 12:03:30 -0500 (Fri, 22 Feb 2008) $

local L = AceLibrary("AceLocale-2.2"):new("Elephant")

L:RegisterTranslations("zhCN", function() return {
	--[[ Common messages ]]
	['chatlog']			= "将聊天记录保存为文件",
	['chatlog_desc']		= "Logs the chat (not the combat log) to Logs\\WoWChatLog.txt.\n\nNote: If this option is activated, the file logging will automatically be enabled back at login.",
	['combatlog']		= "将战斗记录保存为文件",
	['combatlog_desc']		= "Logs the combat chat to Logs\\WoWCombatLog.txt.\n\nNote: If this option is activated, the file logging will automatically be enabled back at login.",
	['disabled']		= "被禁用",
	['enabled']			= "已启用",
	['enableddefault']	= "记录新频道",
	['enableddefault_desc']	= "Automaticaly starts logging when you join a new channel.",
	['noprat']			= "你选择使用Prat的格式记录但Prat未记录.信息将被记录成Elephant格式.",
	['reset']			= "重置",
	['reset_desc']			= "Reset options.",
	['toggle']			= "显示Elephant",
	['toggle_desc']			= "Shows or hides the main window.",
	
	--[[ Options menu elements ]]
	['activate']			= "Activate",
	['activate_desc']		= "Let Elephant control file logging. Disabling this option will leave the current logging status unchanged.\n\nWarning: You shouldn't let two different addons control the file logging.",
	['clearallhelp']		= "清除所有记录",
	['clearallhelp_desc']	= "Clears all the saved logs.",
	['files']				= "File logging",
	['files_desc']			= "Options to save the logs into files.",
	['Filters']				= "过滤器",
	['Filters_desc']		= "Filters are used to avoid the logging of specific channels.",
	['filterusage']			= "频道全称. 你也可以使用通配符(*). 例: <AceComm*>",
	['filtererror']			= "不能呢个增加过滤器 ‘%s’. 过滤器只能包括非空白字符以及通配符(*).",
	['filterregex']			= "^[%S%*]+$",
	['newfilter_desc']		= "Creates a new filter.",
	['deletefilter_desc']	= "Deletes a previously created filter.",
	['logs']				= "日志",
	['logs_desc']			= "Logging options.",
	['maxlogwords']			= "最大记录长度",
	['maxlogwords_desc']	= "Maximum size of each log.",
	['prat']				= "保存记录为Prat格式",
	['prat_desc']			= "Saves the logs the same way than Prat. Logs saved with this option enabled cannot be brought back to Elephant's default logging style.\n\nThis option is only available if you have Prat currently enabled.",
	['resethelp']			= "重置所有设置及聊天频道",
	['resethelp_desc']		= "Resets all settings and chats.",
	['resetloc']			= "重置所有窗口位置",
	['resetloc_desc']		= "Resets Elephant's main window position.",
	['showbutton']			= "显示按钮",
	['showbutton_desc']		= "Displays a button over the normal chat buttons to toggle Elephant.",
	
	--[[ Main/Copy frame elements ]]
	-- Main
	['catchers']	= {
		[1]	= "信息收集罐",
		[2]	= "在记录器中想保存哪些信息?",
		[3]	= "灰色的信息类型不能被禁用."
	},
	['clearall']		= "清除所有记录",
	['copy']			= "复制",
	['Disable']			= "禁用",
	['Empty']			= "清除",
	['Enable']			= "启用",
	['maxlog']			= "最大记录： %s 行。",
	['nblines']			= "行： %s",
	['scroll']			= {
		['bottom']		= {
			[1]	= "下翻到最后一页",
		},
		['linedown']	= {
			[1]	= "下翻一行",
		},
		['lineup']		= {
			[1]	= "上翻一行",
		},
		['pagedown']	= {
			[1]	= "下翻一页",
		},
		['pageup']		= {
			[1]	= "上翻一页",
		},
		['top']			= {
			[1]	= "上翻到第一页",
		},
	},
	
	-- Copy
	['copywindow']	= "复制窗口",
	
	--[[ Special log messages ]]
	['logstartedon']	= "记录开始于 %s  的 %s。",
	['logstopped']		= "记录停止。",
	['monstersay']		= "%s 说",
	['monsteryell']		= "%s 喊话",
	['whisperfrom']		= "%s 密语",
	['whisperto']		= "发送给 %s",
	
	--[[ Addon messages ]]
	['clearallconfirm']		= "所有聊天清除。",
	['combatlogdisabled']	= "战斗记录被禁用",
	['deleteconfirm']		= "聊天被删除： %s",
	['emptyconfirm']		= "聊天被清除： %s",
	['lootmethod']			= {
		['freeforall']		= ERR_SET_LOOT_FREEFORALL,
		['group']			= ERR_SET_LOOT_GROUP,
		['master']			= ERR_SET_LOOT_MASTER,
		['needbeforegreed']	= ERR_SET_LOOT_NBG,
		['roundrobin']		= ERR_SET_LOOT_ROUNDROBIN,
	},
	['masterlooterchanged']	=  ERR_NEW_LOOT_MASTER_S,
	['resetconfirm']		= "所有设置及聊天频道被重置。",
	
	--[[ Tooltips ]]
	['togglebuttontooltip']		= {
		[1]	= "左击显示Elephant界面",
		[2]	= "中键点击重置按钮位置.",
		[3]	= "右击拖动按钮.",
	},
	['toggletooltip']			= "左击显示Elephant界面.",
	
	--[[ Popup windows ]]
	['clearallpopup']	= {
		[1]	= "是否要清除所有记录？",
		[2]	= "确定",
		[3]	= "取消",
	},
	['emptypopup']		= {
		[1]	= "是否清除当前聊天记录？",
		[2]	= "确定",
		[3]	= "取消",
	},
	['resetpopup']		= {
		[1]	= "是否要重置所有设置及聊天频道？",
		[2]	= "确定",
		[3]	= "取消",
	},
	
	--[[ Default chat names to be displayed ]]
	['chatnames']	= {
		['combat']	= "战斗记录",
		['custom']	= "自定义频道",
		['general']	= "综合",
		['guild']	= CHAT_MSG_GUILD,
		['loot']	= CHAT_MSG_LOOT,
		['misc']	= "分配物品界限",
		['officer']	= CHAT_MSG_OFFICER,
		['party']	= CHAT_MSG_PARTY,
		['raid']	= CHAT_MSG_RAID,
		['say']		= CHAT_MSG_SAY,
		['system']	= SYSTEM_MESSAGES,
		['whisper']	= WHISPER,
		['yell']	= YELL_MESSAGE,
	},
	
	--[[ General chats (= that you cannot leave) names and strings that identify them ]]
	['generalchats']	= {
		['综合']		= {
			['name']	= "综合",
			['string']	= "综合",
		},
		['交易']		= {
			['name']	= "交易",
			['string']	= "交易",
		},
		['本地防务']	= {
			['name']	= "本地防务",
			['string']	= "本地防务",
		},
		['世界防务']	= {
			['name']	= "世界防务",
			['string']	= "世界防务",
		},
		['公会招募']	= {
			['name']	= "公会招募",
			['string']	= "公会招募",
		},
	},
	
	--[[ Custom chats special log messages ]]
	['customchat']	= {
		['join']	= "你加入了频道。",
		['leave']	= "你离开了频道。",
	},
} end)