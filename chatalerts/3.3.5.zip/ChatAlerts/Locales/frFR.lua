﻿local ADDON_NAME, namespace = ...

local L = LibStub("AceLocale-3.0"):NewLocale(ADDON_NAME, "frFR")

if not L then return end

L["Active"] = "Actif"
L["Alert"] = "Alerte"
L["Alert Options"] = "Options d'alerte"
L["Always Show"] = "Toujours afficher"
L["Bold Outline"] = "Contour gras"
L["Changes the appearance of the pulsing alert flash."] = "Change l'apparence du flash d'alerte."
L["Disables the pulsing alert flash."] = "Désactive le flash d'alerte."
L["Fade Inactive"] = "Décoloration désactivé"
L["Fades the name of inactive tabs."] = "Décolore le nom des onglets inactifs."
L["Font Colors"] = "Couleur de la poilice"
L["Hide Border"] = "Cacher le bord"
L["Hides the tab border, leaving only the text visible."] = "Cache le bord de l'onglet, ne laissant que le texte visible."
L["Inactive"] = "Inactif"
L["Large"] = "Grand"
L["Outline"] = "Contour"
L["Tab Options"] = "Options des onglets"
L["Toggles between always showing the tab or only showing it on mouse-over."] = "Bascule entre toujours afficher l'onglet ou ne l'afficher qu'au survol."
