﻿
local L = LibStub("AceLocale-3.0"):NewLocale("ShamanFriend", "koKR", false);
if not L then return end

-- Options
L["Options for ShamanFriend"] = "ShamanFriend를 위한 옵션을 설정합니다"

L["Show UI"] = "UI 표시"
L["Shows the Graphical User Interface"] = "GUI 설정을 표시합니다"

L["Alerts"] = "경보"
L["Settings for Elemental Shields and Weapon Enchants."] = "기본적인 보호막과 무기 버프 효과을 위한 설정합니다."
L["Elemental Shield"] = "보호막"
L["Toggle check for Elemental Shield."] = "보호막 체크를 사용합니다."
L["Toggle Earth Shield tracking on other targets than yourself."] = "자신이 아닌 다른 대상의 대지의 보호막 추적을 전환합니다."
L["Weapon Enchant"] = "무기 버프"
L["Toggle check for Weapon Enchants."] = "무기 버프 체크를 사용합니다."
L["Enter Combat"] = true
L["Notify when entering combat."] = true
L["After Combat"] = "전투 종료 후"
L["Notify after the end of combat."] = "전투 종료 후 알립니다."
L["No Mounted"] = "승마"
L["No Vehicle"] = true
L["Disable notifications when mounted."] = "승마 상태에서는 알리지 않습니다."
L["Disable notifications when in a vehicle."] = true
L["Sound"] = "소리"
L["Play a sound when a buff is missing."] = "버프가 사라질 때 소리를 재생합니다."
L["Ding"] = "Ding"
L["Dong"] = "Dong"
L["Dodo"] = "Dodo"
L["Bell"] = "Bell"
L["None"] = "없음"
		
L["Display"] = "표시"
L["Settings for how to display the message."] = "메시지 표시 방법을 설정합니다."
L["Color"] = "색상"
L["Sets the color of the text when displaying messages."] = "메시지를 표시할 글꼴 색상을 설정합니다."
L["Scroll output"] = "스크롤"
L["Toggle showing messages in scrolling text. (Settings are in the 'Output Category')"] = true
L["Frames output"] = "프레임"
L["Toggle whether the message will show up in the frames. (Settings are in the 'General Display' category.)"] = true
L["Time to display message"] = "메시지 표시 시간"
L["Set the time the message will be displayed (5=default)"] = "메시지를 표시할 시간을 설정합니다. (기본=5)"
						
L["Spells"] = "주문"
L["Settings regarding different spells."] = "여러가지 주문을 위한 설정을 합니다."
L["Purge"] = "정화"
L["Toggle Purge information."] = "정화 정보를 사용합니다."
L["Broadcast Purge"] = "정화 방송"
L["Broadcast Purge message to the following chat. (Above option must be enabled)"] = "대화창에 정화 메시지를 방송합니다. (옵션이 사용으로 되어 있어야 합니다.)"
L["Raid"] = "공격대"
L["Party"] = "파티"
L["Raid Warning"] = "공격대 경보"
L["Interrupt"] = "대지 충격"
L["Toggle Interrupt information."] = "대지 충격 정보를 사용합니다."
L["Broadcast Interrupt"] = "대지 충격 방송"
L["Broadcast Interrupt message to the following chat. (Above option must be enabled)"] = "대화창에 대지 충격을 방송합니다. (옵션이 사용으로 되어 있어야 합니다.)"
L["Grounding Totem"] = "마법정화 토템"
L["Toggle message when Grounding Totem absorbs a spell."] = " 마법정화 토템의 흡수 주문 메시지를 표시합니다."
L["Ground self only"] = true
L["Only show grounding message for your own Grounding Totem"] = true
L["Broadcast Grounding Totem"] = "마법정화 토템 방송"
L["Broadcast Grounding Totem message to the following chat. (Above option must be enabled)"] = "대화창에 마법정화 토템 메시지를 방송합니다. (옵션이 사용으로 되어 있어야 합니다.)"
L["Add target"] = true
L["Add the target to the end of the message when broadcasting."] = true
L["Bloodlust message"] = true
L["Send a message when Bloodlust/Heroism is cast."] = true
L["Bloodlust text"] = true
L["The text in the message when Bloodlust/Heroism is cast."] = true
L["Bloodlust chat"] = true
L["Chat for the Bloodlust/Heroism message."] = true
L["Yell"] = true
L["Say"] = true
L["Mana Tide message"] = true
L["Send a message when Mana Tide is cast."] = true
L["Mana Tide text"] = true
L["The text in the message when Mana Tide is cast."] = true
L["Mana Tide chat"] = true
L["Chat for the Mana Tide message."] = true
L["Feral Spirit message"] = true
L["Send a message when Feral Spirit is cast."] = true
L["Feral Spirit text"] = true
L["The text in the message when Feral Spirit is cast."] = true
L["Feral Spirit chat"] = true
L["Chat for the Feral Spirit message."] = true
L["Maelstrom Weapon"] = true
L["Toggle Maelstrom information."] = true
		
L["General Display"] = "일반적 표시"
L["General Display settings and options for the Custom Message Frame."] = "일반적인 표시 설정과 사용자 메시지 프레임을 위한 옵션을 설정합니다."
L["In Chat"] = "대화"
L["Display message in Chat Frame."] = "메시지를 대화창에 표시합니다."
L["Chat number"] = "대화창 번호"
L["Choose which chat to display the messages in (0=default)."] = "메시지를 출력할 대화창을 선택합니다. (0=기본)"
L["On Screen"] = "오류 창"
L["Display message in Blizzard UI Error Frame."] = "메시지를 기본 UI 오류 창에 표시합니다."
L["Custom Frame"] = "사용자 창"
L["Display message in Custom Message Frame."] = "메시지를 사용자 창에 표시합니다."
L["Font Size"] = "글꼴 크기"
L["Set the font size in the Custom Message Frame."] = "사용자 메시지 창의 글꼴 크기를 설정합니다."
L["Font Face"] = "글꼴체"
L["Set the font face in the Custom Message Frame."] = "사용자 메시지 창의 글꼴체를 설정합니다."
L["Normal"] = "기본 글꼴"
L["Arial"] = "두꺼운 글꼴"
L["Skurri"] = "데미지 글꼴"
L["Morpheus"] = "퀘스트 글꼴"
L["Font Effect"] = "글꼴 효과"
L["Set the font effect in the Custom Message Frame."] = "사용자 메시지 창의 글꼴 효과를 설정합니다."
L["OUTLINE"] = "외각선"
L["THICKOUTLINE"] = "두꺼운 외각선"
L["MONOCHROME"] = "단색"
L["Lock"] = "잠금"
L["Toggle locking of the Custom Message Frame."] = "사용자 메시지 창의 위치를 고정시킵니다."
L["BG Announce"] = true
L["Announce when in battlegrounds."] = true
L["Arena Announce"] = true
L["Announce when in arena."] = true
L["5-man Announce"] = true
L["Announce when in a 5-man instance."] = true
L["Raid Announce"] = true
L["Announce when in a raid instance."] = true
L["World Announce"] = true
L["Announce when not in instances."] = true

L["Windfury"] = "질풍"
L["Settings for Windfury counter."] = "질풍 카운터를 설정합니다."
L["Enable"] = "사용"
L["Enable WF hit counter."] = "질풍 합계 카운터를 사용합니다."
L["Crit"] = "치명타"
L["Enable display of WF crits."] = "질풍 치명타 표시를 사용합니다."
L["Miss"] = "피함"
L["Enable display of WF misses."] = "질풍 피함 표시를 사용합니다."
L["Hand"] = true
L["Show which hand the proc comes from"] = true

L["Lightning Overload"] = "넘치는 정기"
L["Settings for Lightning Overload."] = "넘치는 정기를 위한 설정을 합니다."
L["Toggle whether to show a message when Lightning Overload procs."] = "넘치는 정기 발동시 메시지를 표시를 전환합니다."
L["Use alternative method"] = "대체 방법 사용"
L["Uses an alternative method to detect LO procs. (Works better in raids, but can be delayed, and damage will probably break)"] = "넘치는 정기 발동을 탐지하기 위해 대체 방법을 사용합니다. (공격대시 잘 작동하지만 늦어질 수 있습니다. 그리고 손상시킨 피해가 정확하지 않을 수 있습니다.)"
L["Damage"] = "피해"
L["Enable display of Lightning Overload total damage."] = "넘치는 정기의 전체 피해 표시를 사용합니다."
L["Enable display of Lightning Overload crits."] = "넘치는 정기 치명상 피해 표시를 사용합니다."
L["No Lightning Capacitator"] = "번개 축전기 없음"
L["Attempt to remove procs coming from the Lightning Capacitator trinket. (Does not always work, and can cause the damage from dual procs to be a bit off)"] = "번개 축전기의 장신구 발동을 제거합니다. (이중 발동으로 인한 피해를 방지합니다.)"

L["Earth Shield"] = true
L["Settings for Earth Shield."] = true
L["Toggle Earth Shield tracker"] = true
L["Lock tracker"] = true
L["Lock Earth Shield tracker."] = true
L["Disable tooltip"] = true
L["Disable Earth Shield tracker tooltip."] = true
L["Alert when fading"] = true
L["Alert me when Earth Shield fades from my target."] = true
L["Play a sound when Earth Shield fades from my target."] = true

L["Hex"] = true
L["Settings for Hex."] = true
L["Success"] = true
L["Display when successfully hexing a target."] = true
L["Success text"] = true
L["TARGET = Hex target"] = true
L["The text in the message when Hex succeeds."] = true
L["Fail"] = true
L["Display when hexing a target fails."] = true
L["Fail text"] = true
L["The text in the message when Hex fails."] = true
L["Remove"] = true
L["Display when hex is removed from a target."] = true
L["Remove text"] = true
L["The text in the message when Hex is removed."] = true
L["Broadcast Hex"] = true
L["Broadcast Hex message to the following chat. (Above option must be enabled)"] = true
L["Broken"] = true
L["Display when Hex is broken."] = true
L["Broken text"] = true
L["The text in the message when Hex is broken."] = true
L["Broadcast Broken Hex"] = true
L["Broadcast Broken Hex message to the following chat. (Above option must be enabled)"] = true
L["Play a sound when Hex fades from my target."] = true
L["SOURCE = Source of break, TARGET = Hex target"] = true
L["Hex faded from "] = true
L[" broke Hex on "] = true

-- L["Totems"] = true
-- L["Settings for Totems."] = true
-- L["Warn on kill"] = true
-- L["Shows a message whenether one of your totems are killed."] = true
-- L["Broadcast on kill"] = true
-- L["Broadcast to the following chat when one of your totems are killed. (Above option must be enabled)"] = true

L["Miscellaneous"] = "기타"
L["Various other small notices/usefull functions."] = "다양한 작은 통지/유용한 기능을 알려줍니다."
L["Elemental T5 2-piece bonus"] = "T5 2-세트 보너스 효과(기본)"
L["Show a message when you get the proc from the Elemental Tier5 2-piece bonus"] = "5단계 방어구 2세트의 기본적인 보너스 반응을 얻을 때 메시지를 표시합니다."
L["Enhancement T5 2-piece bonus"] = "T5 2-세트 보너스 효과(향상)"
L["Show a message when you get the proc from the Enhancement Tier5 2-piece bonus"] = "5단계 방어구 2세트의 향상된 보너스 반응을 얻을 때 메시지를 표시합니다."
L["Restoration T5 4-piece bonus"] = "T5 4-세트 보너스 효과(회복)"
L["Show a message when you get the proc from the Restoration Tier5 4-piece bonus"] = "5단계 방어구 4세트의 회복 보너스 반응을 얻을 때 메시지를 표시합니다."

-- More
L[" faded"] = " 사라짐"
L["Main Hand Enchant faded"] = "주무기 버프 효과 사라짐"
L["Off Hand Enchant faded"] = "보조무기 버프 효과 사라짐"
L["Weapon Enchant faded"] = true
L["Your Earth Shield faded from %s"] = "%s의 몸에서 대지의 보호막 효과 사라짐"

L["Interrupted: %s"] = "주문 차단: %s"
L["Killed: "] = true

-- LO
L["Lightning Bolt"] = "번개 화살"
L["Chain Lightning"] = "연쇄 번개"
L["Lightning Overload"] = "넘치는 정기"
L["DOUBLE Lightning Overload"] = "이중 넘치는 정기"
L["Chain Lightning Overload"] = true
L["DOUBLE Chain Lightning Overload"] = true
L["TRIPLE Chain Lightning Overload"] = true
L[" CRIT"] = " 치명타"
L[" DOUBLE CRIT"] = " 이중 치명타"
L["Electrical Charge"] = "전하 충전"
	
-- WF
L["Windfury"] = "질풍"
L["MH Windfury"] = true
L["OH Windfury"] = true
L[" Single crit: "] = " 질풍 치명타: "
L[" DOUBLE crit: "] = " 질풍 치명타: "
L[" TRIPLE crit: "] = " 질풍 치명타: "
L[" QUADRUPLE crit: "] = true
L[" miss"] = " 피함"
	
-- Purge
L["Purge"] = "정화"
L["Purge: "] = "정화: "
	
-- Grounding Totem
L["Ground: " ] = "마법정화: "
	
-- Cooldowns
L["Elemental Mastery"] = "정기의 깨달음"
L["Mana Tide Totem"] = "마나 해일 토템"
L["Bloodlust"] = "피의 욕망"
L["Windfury"] = "질풍"
L["Nature's Swiftness"] = "자연의 신속함"
L["Reincarnation"] = "윤회"
L["Chain Lightning"] = "연쇄 번개"
L["Shocks"] = "충격"
L["Fire Elemental Totem"] = "불의 정령 토템"
L["Earth Elemental Totem"] = "대지의 정령 토템"
L["Grounding Totem"] = "마법정화 토템"
L["Eartbind Totem"] = "속박의 토템"
L["Stoneclaw Totem"] = "돌발톱 토템"
L["Fire Nova Totem"] = "불꽃 회오리 토템"
L["Astral Recall"] = "영혼의 귀환"
L["Healthstone"] = "생명석"
L["Potions"] = "물약"
L["Stormstrike"] = "폭풍의 일격"
	
-- Missing
L["Missing: Elemental Shield"] = "사라짐: 보호막"
L["Missing: Main Hand Enchant"] = "사라짐: 주무기 버프"
L["Missing: Off Hand Enchant"] = "사라짐: 보조무기 버프"

-- T5 2-piece set bonus
L["Gained set bonus"] = true
	
-- Earth Shield frame
L["Charges: "] = true
L["Target: "] = true
L["Time: "] = true
L["Outside group"] = true
L[" min"] = true
L["Shaman Friend ES Tracker"] = true
L["Earth Shield faded from "] = true
L["Killed: "] = true
	
-- Font Face
L["FRIZQT__.TTF"] = "2002.TTF"
L["ARIALN.TTF"] = "2002b.TTF"
L["skurri.ttf"] = "K_Damage.TTF"
L["MORPHEUS.ttf"] = "K_Pagetext.TTF"
