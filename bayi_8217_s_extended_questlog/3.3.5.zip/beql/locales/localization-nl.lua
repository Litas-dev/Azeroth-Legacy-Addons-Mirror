﻿--[[
************************************************************************

localization-nl.lua

File date: 2009-09-16T22:44:56Z
File revision: 225
Project revision: 237
Project version: Locale update


Author: Angelike
Translators: mickman

************************************************************************
]]--

do return end -- not finished, exit

if not beql_lang then
	beql_lang = {}
end
	
function beql_lang:nlNL()
	local L = LibStub("AceLocale-3.0"):GetLocale("beql");
	
	if not L then return end
	
	-- fallback to english
	for k in pairs(L) do
		L[k] = k
	end
	

end

-- EoF --