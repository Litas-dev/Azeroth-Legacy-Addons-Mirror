--[[
************************************************************************

debug_locale.lua

File date: 2009-11-24T21:37:56Z
File revision: 228
Project revision: 237
Project version: Locale update


Author: Angelike

************************************************************************
]]--

local L = LibStub("AceLocale-3.0"):GetLocale("beql")

local i = 0
for k in pairs(L) do
	i = i + 1
end

if i ~= 0 then
	return
end


beql_langdebug = true

local L = LibStub("AceLocale-3.0"):NewLocale("beql", "enUS", true)
	L["Minimap"] = true
	L["Bayi's Extended Quest Log"] = true
	L["No Objectives!"] = true
	L["(Done)"] = true
	L["Click to open Quest Log"] = true
	L["Completed!"] = true
	L[" |cffff0000Disabled by|r"] = true
	L["Reload UI ?"] = true
	L["FubarPlugin Config"] = true
	L["Requires Interface Reload"] = true


	L["Quest Log Options"] = true
	L["Options related to the Quest Log"] = true
	L["Lock Quest Log"] = true
	L["Makes the quest log unmovable"] = true
	L["Always Open Minimized"] = true
	L["Force the quest log to open minimized"] = true
	L["Always Open Maximized"] = true
	L["Force the quest log to open maximized"] = true
	L["Show Quest Level"] = true
	L["Shows the quests level"] = true
	L["Info on Quest Completion"] = true
	L["Shows a message and plays a sound when you complete a quest"] = true
	L["Auto Complete Quest"] = true
	L["Automatically Complete Quests"] = true
	L["Mob Tooltip Quest Info"] = true
	L["Show quest info in mob tooltips"] = true
	L["Item Tooltip Quest Info"] = true
	L["Show quest info in item tooltips"] = true
	L["Simple Quest Log"] = true
	L["Uses the default Blizzard Quest Log"] = true
	L["Quest Log Alpha"] = true
	L["Sets the Alpha of the Quest Log"] = true

	L["Quest Tracker"] = true
	L["Quest Tracker Options"] = true
	L["Options related to the Quest Tracker"] = true
	L["Lock Tracker"] = true
	L["Makes the quest tracker unmovable"] = true
	L["Show Tracker Header"] = true
	L["Shows the trackers header"] = true
	L["Hide Completed Objectives"] = true
	L["Automatical hide completed objectives in tracker"] = true
	L["Remove Completed Quests"] = true
	L["Automatical remove completed quests from tracker"] = true
	L["Font Size"] = true
	L["Changes the font size of the tracker"] = true
	L["Sort Tracker Quests"] = true
	L["Sort the quests in tracker"] = true
	L["Show Quest Zones"] = true
	L["Show the quests zone it belongs to above its name"] = true
	L["Add New Quests"] = true
	L["Automatical add new Quests to tracker"] = true
	L["Add Untracked"] = true
	L["Automatical add quests with updated objectives to tracker"] = true
	L["Reset tracker position"] = true
	L["Active Tracker"] = true
	L["Showing on mouseover tooltips, clicking opens the tracker, rightclicking removes the quest from tracker"] = true
	L["Hide Objectives for Completed only"] = true
	L["Hide objectives only for completed quests"] = true

	L["Markers"] = true
	L["Customize the Objective/Quest Markers"] = true
	L["Show Objective Markers"] = true
	L["Display Markers before objectives"] = true
	L["Use Listing"] = true
	L["User Listing rather than symbols"] = true
	L["List Type"] = true
	L["Set the type of listing"] = true
	L["Symbol Type"] = true
	L["Set the type of symbol"] = true

	L["Colors"] = true
	L["Set tracker Colors"] = true
	L["Background"] = true
	L["Use Background"] = true
	L["Custom Background Color"] = true
	L["Use custom color for background"] = true
	L["Background Color"] = true
	L["Sets the Background Color"] = true
	L["Background Corner Color"] = true
	L["Sets the Background Corner Color"] = true
	L["Use Quest Level Colors"] = true
	L["Use the colors to indicate quest difficulty"] = true
	L["Custom Zone Color"] = true
	L["Use custom color for Zone names"] = true
	L["Zone Color"] = true
	L["Sets the zone color"] = true
	L["Fade Colors"] = true
	L["Fade the objective colors"] = true
	L["Custom Objective Color"] = true
	L["Use custom color for objective text"] = true
	L["Objective Color"] = true
	L["Sets the color for objectives"] = true
	L["Completed Objective Color"] = true
	L["Sets the color for completed objectives"] = true
	L["Custom Header Color"] = true
	L["Use custom color for headers"] = true
	L["Completed Header Color"] = true
	L["Sets the color for completed headers"] = true
	L["Failed Header Color"] = true
	L["Sets the color for failed quests"] = true
	L["Header Color"] = true
	L["Sets the color for headers"] = true
	L["Disable Tracker"] = true
	L["Disable the Tracker"] = true
	L["Quest Tracker Alpha"] = true
	L["Sets the Alpha of the Quest Tracker"] = true
	L["Auto Resize Tracker"] = true
	L["Automatical resizes the tracker depending on the lenght of the text in it"] = true
	L["Fixed Tracker Width"] = true
	L["Sets the fixed width of the tracker if auto resize is disabled"] = true

	L["Pick Locale"] = true
	L["Change Locale (needs Interface Reload)"] = true

	L["|cffffffffQuests|r"] = true
	L["|cffff8000Tracked Quests|r"] = true
	L["|cff00d000Completed Quests|r"] = true
	L["|cffeda55fClick|r to open Quest Log and |cffeda55fShift+Click|r to open Waterfall config"] = true

	L["Tooltip"] = true
	L["Tooltip Options"] = true
	L["Tracker Tooltip"] = true
	L["Showing mouseover tooltips in tracker"] = true
	L["Quest Description in Tracker Tooltip"] = true
	L["Displays the actual quest's description in the tracker tooltip"] = true
	L["Party Quest Progression info"] = true
	L["Displays Party members quest status in the tooltip - Quixote must be installed on the partymembers client"] = true
	L["Enable Left Click"] = true
	L["Left clicking a quest in the tracker opens the Quest Log"] = true
	L["Enable Right Click"] = true
	L["Right clicking a quest in the tracker removes it from the tracker"] = true
	L["Quest Log Scale"] = true
	L["Sets the Scale of the Quest Log"] = true
	L["Force Tracker Unlock"] = true
	L["Make the Tracker movable even with CTMod loaded. Please check your CTMod config before using it"] = true
	L["Quest Progression to Party Chat"] = true
	L["Prints the Quest Progression Status to the Party Chat"] = true
	L["Completion Sound"] = true
	L["Select the sound to be played when a quest is completed"] = true

	L["Quest Description Color"] = true
	L["Sets the color for the Quest description"] = true
	L["Party Member Color"] = true
	L["Party Member with Quixote Color"] = true
	L["Sets the color for Party member"] = true

-- new with 3.0
	L["Main Options"] = true
	L["Enable Addon"] = true
	L["Enable this Addon"] = true
	L["General Quest Log Options"] = true
	L["No sound"] = true
	L["Don't play a sound"] = true
	L["Watch Options"] = true
	L["Zones"] = true
	L["NPC color"] = true
	L["Title color"] = true

-- Fubar
	L["Show icon"] = true
	L["Show the plugins icon on the panel."] = true
	L["Show text"] = true
	L["Show the plugins text on the panel."] = true
	L["Show colored text"] = true
	L["Allow the plugin to color its text."] = true
	L["Detach tooltip"] = true
	L["Detach the tooltip from the panel."] = true
	L["Lock tooltip"] = true
	L["Lock the tooltips position. When the tooltip is locked, you must use Alt to access it with your mouse."] = true
	L["Position"] = true
	L["Position the plugin on the panel."] = true
	L["Left"] = true
	L["Right"] = true
	L["Center"] = true
	L["Attach to minimap"] = true
	L["Attach the plugin to the minimap instead of the panel."] = true
	L["Hide plugin"] = true
	L["Hidden"] = true
	L["Hide the plugin from the panel or minimap, leaving the addon running."] = true
	L["Other"] = true
	L["Close"] = true
	L["Close the menu."] = true
	L["Minimap position"] = true
	L[". |cffeda55fRightclick|r to open FuBar config."] = true
	L["Shows the tooltip on mousover this plugin"] = true
	L["Show FuBar Tooltip"] = true

-- Profiles
	L["Profiles"] = true

-- Achievement Tracker
	L["Achievement Tracker"] = true
	L["Enable Achievement Tracker"] = true
	L["Enables the Achievement Tracker, which can be moved an collapsed."] = true
	L["Makes the achievement tracker unmovable"] = true
	L["Show Achievement Tracker Header"] = true
	L["Shows the header of the Achievementtracker"] = true
	L["Save tracked Achievement"] = true
	L["Save last tracked Achievement and resore it after login"] = true
	L["Remove Completed Achievement"] = true
	L["Automatical remove the completed Achievement from tracker"] = true
	L["Achievement Tracker Alpha"] = true
	L["Sets the Alpha of the Achievement Tracker"] = true
	L["Achievement Tracker Scale"] = true
	L["Sets the Scale of the Achievement Tracker"] = true

	L["Manage Achievement Lines"] = true
	L["Mange count of Lines to optimal display objectives from the achievement"] = true
	L["Number of Lines"] = true
	L["Number of lines that can be used by the Linemanger"] = true


	-- 3.2
	L['Mouse Events'] = true
	L['Show tooltip'] = true
	L['Show tooltip on achievemet tracker'] = true
	L['Show hint tooltip'] = true
	L['Show tooltip hint in the achievemet tracker tooltip'] = true
	L['Enable Left+Click to open achievement'] = true
	L['Enables Right-Click on the achievementtracker to remove a tracked acheivement'] = true
	L["|cffeda55fRight-Click|r click to toggle watch for this Achievement"] = true
	L['|cffeda55fRight-Click|r to cancel tracking of this achievement'] = true
	L['|cffeda55fClick|r to open achievement, |cffeda55fShift+Click|r to link achievement to chat.'] = true

	-- r224
	L['Enable Language support'] = true
	L['Enables the language support for non-natural Languages.'] = true


	-- r226
	L['Enable Quest Progression to Party Chat'] = true
	L['Select chattype'] = true
	L['The chattype to post progress massages.'] = true
	L["Default chat for actual group"] = true
	L["Group chat"]= true
	L["say quest progession"] = true
	L['Accept a new quest'] = true
	L['Print a chat massage when you accept a new quest.'] = true
	L['Quest accepted: '] = true
	L['Progess of a quest'] = true
	L['Quest objective updated: '] = true
	L['Print a chat massage when an objective of a quest is updated.'] = true
	L['Complete a quest'] = true
	L['Print a chat massage when you complete all quest objectives.'] = true
	L['Quest %d finished.'] = true
	L['Finalize a quest.'] = true
	L['Print a chat massage when you deliver a completed quest to the NPC.'] = true
	L['Quest %d done.'] = true
	L['Quest Accepted: '] = true
	L["Abandon a quest"] = true
	L["Print a chat massage when you abandon a quest."] = true
	L['Quest finalized: '] = true
	L['Quest abandoned: '] = true
	L['Reset questlog position'] = true
	L['Questlog Layout'] = true
	
	-- r227
	L['GameTooltip'] = true
	L['Color Objectives'] = true
	L['Incomplete'] = true
	L['Complete'] = true
	L['Use Fade-Step-Color'] = true
	L['Fade-Step-Color'] = true
	L['Non Objective'] = true
	L[''] = true


BINDING_HEADER_beqlTITLE = "Bayi's Extended Questlog"
BINDING_NAME_TrackerToggle = "Toggle Tracker"

--[[

-- Adding this to the L[] locales soon...
BEQL_COMPLETE = "%(Complete%)"
-- This isnt needed anymore removing soon...
BEQL_QUEST_ACCEPTED = "Quest accepted:"
-- This needs to be defined only here, if u need it expand it but dont set it to nil in other locales!
BEQL_PostTransFunc = {}--]]