﻿local L = IGAS:NewLocal("IGAS_Special", "zhTW")
if not L then return end

L["Okay"] = "是"
L["No"] = "否"
L["Cancel"] = "取消"
L["Color Picker"] = "顏色選擇器"