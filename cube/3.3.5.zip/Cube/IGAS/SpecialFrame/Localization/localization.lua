﻿local L = IGAS:NewLocal("IGAS_Special", "enUS", true)
if not L then return end

L["Okay"] = true
L["No"] = true
L["Cancel"] = true
L["Color Picker"] = true