﻿-- Author      : Kurapica
-- Create Date : 6/27/2008
-- ChangeLog   :

--[[
    Base for GUI
--]]
do
	local version = 1

	if not IGAS:NewAddon("IGAS.GUI", version) then
		return
	end

	------------------------------------------------------
	------------------- Naming Space ---------------------
	------------------------------------------------------
	IGAS.GUI = IGAS.GUI or {}
	IGAS.GUI.Enum = IGAS.GUI.Enum or {}
	IGAS.GUI.PropertyType = IGAS.GUI.PropertyType or {}

	IGAS.GUI.Widget = IGAS.GUI.Widget or {}
end