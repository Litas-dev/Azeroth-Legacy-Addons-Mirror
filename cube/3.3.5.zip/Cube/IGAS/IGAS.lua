﻿do
	local version = 1

	if not IGAS:NewAddon("IGAS", version) then
		return
	end

	-- Keep this setting for gui lib, no need to set _AutoWrapper in other addons.
	_AutoWrapper = false
	
	Log = IGAS:NewLogger("IGAS")
	Log.LogLevel = 3
	
	Log:AddHandler(print)
end