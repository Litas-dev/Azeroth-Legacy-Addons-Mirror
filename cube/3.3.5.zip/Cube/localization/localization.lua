﻿local L = IGAS:NewLocal("Cube", "enUS", true)
if not L then return end

-- this no need to translate
L["Cube"] = true

L["Simple Bug List"] = true
L["Simple Dev Tool"] = true
L["Simple Debug Tool"] = true
L["Simple Log View"] = true

L["Debug"] = true
L["Code"] = true
L["BugList"] = true

L["Clear"] = true
L["Clear All"] = true
L["Enabled"] = true
L["Disabled"] = true

L["AutoRun"] = true
L["New"] = true
L["Save"] = true
L["Del"] = true
L["Run"] = true
L["Unit Test"] = true
L["Must set code name."] = true
L["Must set code."] = true

L["Commit"] = true
L["Show in new page"] = true
L["Show metatable in new page"] = true
L["Show key in new page"] = true
L["Delete this"] = true
L["Are you sure to delete this key?"] = true
L["Are you sure to change the value?"] = true
L["Error Input."] = true

L["Log View"] = true
L["Add Logger"] = true
L["Remove Logger"] = true
L["Clear Logger"] = true
L["Please input the logger's name"] = true
L["Do you want remove the logger : "] = true
L["Do you want clear the logger : "] = true

L["Open the code editor"] = true
L["Open the buglist"] = true
L["Open the debug tool"] = true
L["Open the log view"] = true