if GetLocale() ~= "frFR" then
	return
end

local L = BUYEMALL_LOCALS

-- Thanks to Layrajha
-- L.MAX 			= "Max"
L.STACK 		= "Pile"
L.CONFIRM 		= "Voulez-vous vraiment acheter\n %d � %s?"
-- L.STACK_PURCH	= "Stack Purchase"
L.STACK_SIZE 	= "Taille de pile"
-- L.PARTIAL 		= "Partial stack"
L.MAX_PURCH		= "Achat maximum"
L.FIT			= "Vous pouvez transporter"
L.AFFORD		= "Vous pouvez payer"
L.AVAILABLE		= "Le marchand a"
