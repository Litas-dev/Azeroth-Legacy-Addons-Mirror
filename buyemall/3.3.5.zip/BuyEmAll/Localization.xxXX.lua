-- Please e-mail localization files to MuaDragon@gmail.com
if GetLocale() ~= "xxXX" then
	return
end

local L = BUYEMALL_LOCALS

--L.MAX 			= "Max"
--L.STACK 		= "Stack"
--L.CONFIRM 		= "Are you sure you want to buy\n %d � %s?"
--L.STACK_PURCH	= "Stack Purchase"
--L.STACK_SIZE 	= "Stack size"
--L.PARTIAL 		= "Partial stack"
--L.MAX_PURCH		= "Maximum purchase"
--L.FIT			= "You can fit"
--L.AFFORD		= "You can afford"
--L.AVAILABLE		= "Vendor has"