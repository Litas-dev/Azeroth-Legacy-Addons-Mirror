To disable certain functionality you need to edit the wChat.LUA

all Setting descriptions:Can be found also in the LUA.