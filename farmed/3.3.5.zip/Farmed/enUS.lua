---Application messages
farmed_lang_loaded="Farmed is loaded, type /farmed to access options";
farmed_lang_optmain="Farmed Commands:";
farmed_lang_optcom1="     show - show farmed window";
farmed_lang_optcom2="     hide - hide farmed window";
farmed_lang_optcom3="     options - configure farmed";

--Dialog Titles
farmed_lang_bags="Bag slots free:";
farmed_lang_money="Money:";
farmed_lang_gathered="Gathered";
farmed_lang_ore="Metal & Stone";
farmed_lang_meat="Meat";
farmed_lang_gem="Gem";
farmed_lang_herb="Herb";
farmed_lang_cloth="Cloth";
farmed_lang_leather="Leather";
farmed_lang_element="Elemental";
farmed_lang_enchanting="Enchanting";
farmed_lang_other="Other Items";
farmed_lang_othercat="Trade Goods";
farmed_lang_othercat1="Materials";
farmed_lang_othercat2="Parts";
farmed_lang_items="Items";
farmed_lang_consumable="Consumable";

--Inventory Item Filter
farmed_lang_ItemFilter="Armor,Container,Miscellaneous,Recipe,Quest,Weapon";

----Option Window Text

farmed_opt_general="General Option";
farmed_opt_show="Show Farmed";
farmed_opt_money="Show Money";
farmed_opt_bags="Show Bag Summary";

farmed_opt_items="Item Options";
farmed_opt_uncommon="Show Uncommon";
farmed_opt_rare="Show Rare/Epic";

farmed_opt_materials="Material Options";
farmed_opt_ore="Show Metal/Stone";
farmed_opt_meat="Show Meat";
farmed_opt_herbs="Show Herbs";
farmed_opt_elements="Show Elementals";
farmed_opt_gems="Show Gems";
farmed_opt_enchanting="Show Enchanting";
farmed_opt_cloth="Show Cloth";
farmed_opt_leather="Show Leather";
farmed_opt_other="Show Other Items";
farmed_opt_consumable="Show Consumables";
farmed_opt_announce="Annouce Loot";
farmed_opt_announcechat="Annouce Loot in Chat";

----Key Binding

BINDING_HEADER_FARMED_TITLE = "Farmed Bindings";
BINDING_NAME_FARMED_TOGGLE = "Toggle Farmed";




