LH_QIDMap = {
  [1] = 2,
  [2] = 3063,
  [3] = 9358,
  [4] = 11001,
  [5] = 12619,
  ["vars"] = {
    [1] = "LH_Data_A",
    [2] = "LH_Data_B",
    [3] = "LH_Data_C",
    [4] = "LH_Data_D",
    [5] = "LH_Data_E",
  },
  ["addons"] = {
    [1] = "LightHeaded_Data_A",
    [2] = "LightHeaded_Data_B",
    [3] = "LightHeaded_Data_C",
    [4] = "LightHeaded_Data_D",
    [5] = "LightHeaded_Data_E",
  },
}
