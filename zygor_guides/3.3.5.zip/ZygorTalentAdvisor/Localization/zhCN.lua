if GetLocale()~="zhCN" then return end

ZygorTalentAdvisor_L("Main", "zhCN", function() return {
	-- ["English"] = "Localized",
} end)
