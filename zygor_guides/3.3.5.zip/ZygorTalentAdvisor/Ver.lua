ZygorTalentAdvisor.revision = tonumber(string.sub("$Revision: 1293 $", 12, -3))
ZygorTalentAdvisor.version = "2.0." .. ZygorTalentAdvisor.revision
ZygorTalentAdvisor.date = string.sub("$Date: 2010-04-27 07:42:01 -0500 (Tue, 27 Apr 2010) $", 8, 17)
--2010/04/27 14:40:08.52442
