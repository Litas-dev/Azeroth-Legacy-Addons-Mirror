if GetLocale()~="zhCN" then return end

ZygorGuidesViewer_L("Main", "zhCN", function() return {
	--LocaleFont = [[Fonts\ZYKai_T.ttf]],
	MainFont = [[Fonts\bHE101B.TTF]],
	MainFontBold = [[Fonts\bHE101B.TTF]],
} end)
