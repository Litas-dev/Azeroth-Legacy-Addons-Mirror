if GetLocale()~="koKR" then return end

ZygorGuidesViewer.LocaleFont = [[Fonts\2002.TTF]]

ZygorGuidesViewer_L("Main", "koKR", function() return {
	-- ["English"] = "Localized",
} end)
