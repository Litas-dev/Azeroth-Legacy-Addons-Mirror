local ZygorGuidesViewer=ZygorGuidesViewer
if not ZygorGuidesViewer then return end


ZygorGuidesViewer:RegisterGuideSorting({
	"BETA",
	"Leveling",
	"Loremaster",
	"Dailies",
	"Events",
	"Dungeons",
	"Gear",
	"Professions",
	"Achievements",
	"Pets & Mounts",
	"Titles",
	"Reputations",
	"Macros",
})

