Place your guides in files Guide01.lua, Guide02.lua, ... in this directory, to have them auto-loaded on startup.
