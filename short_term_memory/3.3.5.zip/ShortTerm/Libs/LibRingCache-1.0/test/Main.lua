require("os");
dofile("Wowcompat.lua");
dofile("LibStub.lua");
dofile("../LibRingCache-1.0.lua");

-- run test(s)
dofile("Test.lua");
