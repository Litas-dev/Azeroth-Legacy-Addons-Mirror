for k,v in pairs(string) do
	_G["str"..k] = v;
end

function wipe(tbl)
	for k,v in pairs(tbl) do
		tbl[k] = nil;
	end
end

table.wipe = wipe;

local lasttime = 0;

function debugprofilestart()
	lasttime = os.clock()*1000;
end

function debugprofilestop()
	return os.clock()*1000-lasttime;
end
