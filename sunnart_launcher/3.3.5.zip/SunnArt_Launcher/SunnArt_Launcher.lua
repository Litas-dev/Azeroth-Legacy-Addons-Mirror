local Launcher = LibStub('LibDataBroker-1.1'):NewDataObject('SunnArt', {
	type = "launcher",
	icon = "Interface\\Addons\\SunnArt_Launcher\\icon",
	OnClick = function(clickedframe, button)
		InterfaceOptionsFrame_OpenToCategory(SunnArt.optionsFrame)
	end,
	text = 'SunnArt',
})
