﻿local L = LibStub("AceLocale-3.0"):NewLocale("VisualHeal", "enUS", true);

if not L then return end

-- Menu name --
L["Dump Guild Versions"] = true;
L["Dump Group Versions"] = true;
L["Config"] = true;
L["Show HealBar"] = true;
L["Show PlayerBar"] = true;
L["Sticky HealBar"] = true;
L["Scale of the HealBar"] = true;
L["Scale of the PlayerBar"] = true;
L["Reset Bars"] = true;
L["Show Bars"] = true;
	
-- Menu description --
L["Print the versions of LibHealComm-3.0 used by guild members"] = true;
L["Print the versions of LibHealComm-3.0 used by group members"] = true;
L["Configuration"] = true;
L["Toggles display of the HealBar when you are healing"] = true;
L["Toggles display of the PlayerBar when heals are incoming to you"] = true;
L["If enabled the HealBar will stay on screen when your heal completes"] = true;
L["Set the scale of the HealBar"] = true;
L["Set the scale of the PlayerBar"] = true;
L["Reset the HealBar and PlayerBar to default positions and scales"] = true;
L["Show the HealBar and PlayerBar to allow moving them around"] = true;

-- Interface --
L["HealBar: Shows your healing to others"] = true;
L["PlayerBar: Shows incoming heals to you"] = true;
L["|cFFCCCCCCLeft-click to drag."] = true;
L["Shift-left-click to re-attach to Casting Bar."] = true;
L["Right-click to hide."] = true;
