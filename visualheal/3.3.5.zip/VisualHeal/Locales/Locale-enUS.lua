﻿local L = LibStub("AceLocale-3.0"):NewLocale("VisualHeal", "enUS", true);
if not L then return end

L["DESCRIPTION"] = "VisualHeal is a small and simple but powerful tool for all classes that visually shows your heals to others and heals incoming to you from others by means of two information-packed, yet intuitive bars. VisualHeal uses LibHealComm-4.0 to communicate healing with other clients that also have this library running (either explicitly installed or embedded in some addon).";

-- Menu name --
L["General Options"] = true;
L["Appearance Options"] = true;
L["Bar Texture"] = true;
L["Border Brightness"] = true;
L["Border Texture"] = true;
L["Config"] = true;
L["Enable HealBar"] = true;
L["Enable PlayerBar"] = true;
L["Sticky HealBar"] = true;
L["Scale of the HealBar"] = true;
L["Scale of the PlayerBar"] = true;
L["Reset Bars"] = true;
L["Show Bars"] = true;

-- Menu description --
L["Select texture to use for the HealBar and PlayerBar"] = true;
L["Select texture to use for the border of the HealBar and PlayerBar"] = true;
L["Set the brightness of the border of the HealBar and PlayerBar"] = true;
L["Configuration"] = true;
L["Toggles display of the HealBar when you are healing"] = true;
L["Toggles display of the PlayerBar when heals are incoming to you"] = true;
L["If enabled the HealBar will stay on screen when your heal completes"] = true;
L["Set the scale of the HealBar"] = true;
L["Set the scale of the PlayerBar"] = true;
L["Reset the HealBar and PlayerBar to default positions and scales"] = true;
L["Show the HealBar and PlayerBar to allow moving them around"] = true;

-- Interface --
L["HealBar: Shows your healing to others"] = true;
L["PlayerBar: Shows incoming heals to you"] = true;
L["|cFFCCCCCCLeft-click to drag."] = true;
L["Shift-left-click to re-attach to Casting Bar."] = true;
L["Right-click to hide."] = true;
