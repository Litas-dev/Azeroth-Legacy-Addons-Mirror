﻿local L = LibStub("AceLocale-3.0"):NewLocale("VisualHeal", "frFR");
if not L then return end

L["DESCRIPTION"] = "VisualHeal is a small and simple but powerful tool for all classes that visually shows your heals to others and heals incoming to you from others by means of two information-packed, yet intuitive bars. VisualHeal uses LibHealComm-4.0 to communicate healing with other clients that also have this library running (either explicitly installed or embedded in some addon).";

-- Menu name --
L["General Options"] = true;
L["Appearance Options"] = true;
L["Bar Texture"] = true;
L["Border Brightness"] = true;
L["Border Texture"] = true;
L["Config"] = "Config";
L["Enable HealBar"] = "Activé la HealBar";
L["Enable PlayerBar"] = "Activé la PlayerBar";
L["Sticky HealBar"] = "HealBar collante";
L["Scale of the HealBar"] = "Echelle HealBar";
L["Scale of the PlayerBar"] = "Echelle PlayerBar";
L["Reset Bars"] = "Réinit. barres";
L["Show Bars"] = "Afficher barres";

-- Menu description --
L["Select texture to use for the HealBar and PlayerBar"] = true;
L["Select texture to use for the border of the HealBar and PlayerBar"] = true;
L["Set the brightness of the border of the HealBar and PlayerBar"] = true;
L["Configuration"] = "Configuration";
L["Toggles display of the HealBar when you are healing"] = "Affiche/Masque la HealBar lorsque vous soignez";
L["Toggles display of the PlayerBar when heals are incoming to you"] = "Affiche/Masque la PlayerBar lorsque des soins vous sont destinés";
L["If enabled the HealBar will stay on screen when your heal completes"] = "Si activé, la HealBar restera à l'écran à la fin de votre soin";
L["Set the scale of the HealBar"] = "Définit l'échelle de la HealBar";
L["Set the scale of the PlayerBar"] = "Définit l'échelle de la PlayerBar";
L["Reset the HealBar and PlayerBar to default positions and scales"] = "Réinitialise la HealBar et la PlayerBar aux positions et échelles par défaut";
L["Show the HealBar and PlayerBar to allow moving them around"] = "Affiche la HealBar et la PlayerBar afin de les déplacer";

-- Interface --
L["HealBar: Shows your healing to others"] = "HealBar : Affiche vos soins sur les autres";
L["PlayerBar: Shows incoming heals to you"] = "PlayerBar : Affiche les soins vous étant destinés";
L["|cFFCCCCCCLeft-click to drag."] = "Clic-gauche pour déplacer";
L["Shift-left-click to re-attach to Casting Bar."] = "Shift-Clic-gauche pour réattacher à la barre d'incantation";
L["Right-click to hide."] = "Clic-droit pour masquer";
