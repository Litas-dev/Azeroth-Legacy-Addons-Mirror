﻿local L = LibStub("AceLocale-3.0"):NewLocale("VisualHeal", "enUS", true);
if not L then return end

L["DESCRIPTION"] = "VisualHeal is a small and simple but powerful tool for all classes that visually shows your heals to others and heals incoming to you from others by means of two information-packed, yet intuitive bars. VisualHeal uses LibHealComm-4.0 to communicate healing with other clients that also have this library running (either explicitly installed or embedded in some addon).";

-- Menu name --
L["General Options"] = "一般選項";
L["Appearance Options"] = true;
L["Bar Texture"] = true;
L["Border Brightness"] = "邊界亮度";
L["Border Texture"] = "邊界紋理";
L["Config"] = "配置";
L["Enable HealBar"] = "啟用 HealBar";
L["Enable PlayerBar"] = "啟用 PlayerBar";
L["Sticky HealBar"] = true;
L["Scale of the HealBar"] = "HealBar 比例";
L["Scale of the PlayerBar"] = "PlayerBar 比例";
L["Reset Bars"] = "重設動作條";
L["Show Bars"] = "顯示動作條";

-- Menu description --
L["Select texture to use for the HealBar and PlayerBar"] = true;
L["Select texture to use for the border of the HealBar and PlayerBar"] = true;
L["Set the brightness of the border of the HealBar and PlayerBar"] = true;
L["Configuration"] = "表面配置";
L["Toggles display of the HealBar when you are healing"] = true;
L["Toggles display of the PlayerBar when heals are incoming to you"] = true;
L["If enabled the HealBar will stay on screen when your heal completes"] = true;
L["Set the scale of the HealBar"] = true;
L["Set the scale of the PlayerBar"] = true;
L["Reset the HealBar and PlayerBar to default positions and scales"] = true;
L["Show the HealBar and PlayerBar to allow moving them around"] = true;

-- Interface --
L["HealBar: Shows your healing to others"] = "HealBar: 顯示你對其他人的治療";
L["PlayerBar: Shows incoming heals to you"] = true;
L["|cFFCCCCCCLeft-click to drag."] = "|cFFCCCCCC左鍵-點擊 拖曳.";
L["Shift-left-click to re-attach to Casting Bar."] = true;
L["Right-click to hide."] = "右鍵-點擊 隱藏.";
