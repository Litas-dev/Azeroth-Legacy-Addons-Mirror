-- ChatTranslator Addon for WoW WOTLK 3.3.5a (Warmane)
-- Purpose: Translates incoming chat messages into a user-selected language, displayed in a dedicated UI box.
-- Features: Language detection, phrase and word translation, movable/resizable UI, minimap button, config panel.
-- Focus: Incoming messages only, with persistent settings.

-- Addon namespace
local addonName, ChatTranslator = ...

-- UI Frames
local frame = CreateFrame("Frame", "ChatTranslatorFrame", UIParent)
local outputBox, minimapButton, configFrame, opacitySlider, lockCheckBox, dropdown, resizeBtn, msgFrame

-- Default settings
local targetLanguage = "en"
local languageNames = {
    en = "English", es = "Spanish", fr = "French", pt = "Portuguese",
    ru = "Russian", de = "German", pl = "Polish", hu = "Hungarian", sk = "Slovak"
}

-- Translations table: This table is crucial for correct functionality.
-- Structure: [lemma] = { lemma = "lemma", lang1 = "translation1", lang2 = "translation2", ... }
-- Example:
-- translations = {
--     ["little"] = { lemma = "little", es = "poco", fr = "petit", de = "klein" },
--     ["few"] = { lemma = "few", es = "pocos", fr = "quelques", de = "wenige" },
--     ["gold"] = { lemma = "gold", es = "oro", fr = "or", de = "Gold" },
--     ["guide to make gold"] = { lemma = "guide to make gold", es = "guía para hacer oro", fr = "guide pour faire de l'or", de = "Anleitung zum Goldmachen" },
-- }
-- Make sure every single word you want translated (like "poco", "oro") has a corresponding lemma entry.
local translations = {
	["be"] = { lemma = "be", es = "ser", fr = "être", pt = "ser", ru = "быть", de = "sein", pl = "być", hu = "lenni", sk = "byť" },
    ["am"] = { lemma = "be", es = "soy", fr = "suis", pt = "sou", ru = "есть", de = "bin", pl = "jestem", hu = "vagyok", sk = "som" },
    ["is"] = { lemma = "be", es = "es", fr = "est", pt = "é", ru = "есть", de = "ist", pl = "jest", hu = "van", sk = "je" },
	["portal"] = { lemma = "portal", es = "portal", fr = "portail", pt = "portal", ru = "портал", de = "Portal", pl = "portal", hu = "portál", sk = "portál" },
["dala"] = { lemma = "Dalaran", es = "Dalaran", fr = "Dalaran", pt = "Dalaran", ru = "Даларан", de = "Dalaran", pl = "Dalaran", hu = "Dalaran", sk = "Dalaran" },
["community"] = { lemma = "community", es = "comunidad", fr = "communauté", pt = "comunidade", ru = "сообщество", de = "Gemeinschaft", pl = "społeczność", hu = "közösség", sk = "komunita" },
["most"] = { lemma = "most", es = "más", fr = "plus", pt = "mais", ru = "наиболее", de = "meisten", pl = "najwięcej", hu = "legtöbb", sk = "najviac" },
["spot"] = { lemma = "spot", es = "sitio", fr = "endroit", pt = "local", ru = "место", de = "Ort", pl = "miejsce", hu = "hely", sk = "miesto" },
["dm"] = { lemma = "direct message", es = "mensaje directo", fr = "message privé", pt = "mensagem direta", ru = "личное сообщение", de = "Direktnachricht", pl = "prywatna wiadomość", hu = "közvetlen üzenet", sk = "priama správa" },
["smoke"] = { lemma = "smoke", es = "humo", fr = "fumée", pt = "fumaça", ru = "дым", de = "Rauch", pl = "dym", hu = "füst", sk = "dym" },
["event"] = { lemma = "event", es = "evento", fr = "événement", pt = "evento", ru = "событие", de = "Ereignis", pl = "wydarzenie", hu = "esemény", sk = "udalosť" },
["title"] = { lemma = "title", es = "título", fr = "titre", pt = "título", ru = "звание", de = "Titel", pl = "tytuł", hu = "cím", sk = "titul" },
["information"] = { lemma = "information", es = "información", fr = "informations", pt = "informação", ru = "информация", de = "Informationen", pl = "informacje", hu = "információ", sk = "informácie" },
["boost"] = { lemma = "boost", es = "impulso", fr = "coup de pouce", pt = "impulso", ru = "ускорение", de = "Schub", pl = "wzmocnienie", hu = "gyorsítás", sk = "posilnenie" },
    ["trinkets"] = { lemma = "trinkets", es = "baratijas", fr = "bijoux", pt = "berloques", ru = "аксессуары", de = "Schmuckstücke", pl = "bibeloty", hu = "ékszerek", sk = "drobnosti" },
    ["trinket"] = { lemma = "trinket", es = "baratija", fr = "bijou", pt = "berloque", ru = "аксессуар", de = "Schmuckstück", pl = "bibelot", hu = "ékszer", sk = "drobnosť" },
    ["items"] = { lemma = "items", es = "objetos", fr = "objets", pt = "itens", ru = "предметы", de = "Gegenstände", pl = "przedmioty", hu = "tárgyak", sk = "predmety" },
    ["item"] = { lemma = "item", es = "objeto", fr = "objet", pt = "item", ru = "предмет", de = "Gegenstand", pl = "przedmiot", hu = "tárgy", sk = "predmet" },
    ["wts"] = { lemma = "wts", es = "deseo vender", fr = "prêt à vendre", pt = "quero vender", ru = "готов продать", de = "bereit zu verkaufen", pl = "chcę sprzedać", hu = "eladásra kész", sk = "chcem predať" },
    ["weapon"] = { lemma = "weapon", es = "arma", fr = "arme", pt = "arma", ru = "оружие", de = "Waffe", pl = "broń", hu = "fegyver", sk = "zbraň" },
    ["weapons"] = { lemma = "weapons", es = "armas", fr = "armes", pt = "armas", ru = "оружия", de = "Waffen", pl = "bronie", hu = "fegyverek", sk = "zbrane" },
    ["bis"] = { lemma = "bis", es = "mejor en ranura", fr = "meilleur dans l'emplacement", pt = "melhor em slot", ru = "лучший в слоте", de = "best in slot", pl = "najlepsze w slocie", hu = "legjobb slotban", sk = "najlepšie v slote" },
    ["naxx"] = { lemma = "naxx", es = "Naxxramas", fr = "Naxxramas", pt = "Naxxramas", ru = "Наксрамас", de = "Naxxramas", pl = "Naxxramas", hu = "Naxxramas", sk = "Naxxramas" },
    ["icc"] = { lemma = "icc", es = "Ciudadela de la Corona de Hielo", fr = "Citadelle de la Couronne de glace", pt = "Cidadela da Coroa de Gelo", ru = "Цитадель Ледяной Короны", de = "Eiskronenzitadelle", pl = "Cytadela Lodowej Korony", hu = "Jégkorona Citadella", sk = "Citadela Ľadovej Koruny" },
    ["casted"] = { lemma = "cast", es = "lanzado", fr = "lancé", pt = "lançado", ru = "применен", de = "gewirkt", pl = "rzucany", hu = "elvarázsolt", sk = "zaklinaný" },
["fool"] = { lemma = "fool", es = "tonto", fr = "fou", pt = "tolo", ru = "дурак", de = "Narr", pl = "głupiec", hu = "bolond", sk = "blázon" },
["dont"] = { lemma = "do not", es = "no", fr = "ne pas", pt = "não", ru = "не", de = "nicht", pl = "nie", hu = "ne", sk = "nie" },
["bubble"] = { lemma = "bubble", es = "burbuja", fr = "bulle", pt = "bolha", ru = "пузырь", de = "Blase", pl = "bańka", hu = "buborék", sk = "bublina" },
["feral"] = { lemma = "feral", es = "feral", fr = "farouche", pt = "feral", ru = "дикий", de = "wild", pl = "dziki", hu = "vad", sk = "divoký" },
["hello"] = { lemma = "hello", es = "hola", fr = "bonjour", pt = "olá", ru = "привет", de = "hallo", pl = "cześć", hu = "helló", sk = "ahoj" },
    ["yea"] = { lemma = "yes", es = "sí", fr = "oui", pt = "sim", ru = "да", de = "ja", pl = "tak", hu = "igen", sk = "áno" },
["nah"] = { lemma = "no", es = "no", fr = "non", pt = "não", ru = "нет", de = "nein", pl = "nie", hu = "nem", sk = "nie" },
["traded"] = { lemma = "trade", es = "intercambiado", fr = "échangé", pt = "trocado", ru = "обменял", de = "gehandelt", pl = "handlował", hu = "elcserélt", sk = "obchodoval" },
["fought"] = { lemma = "fight", es = "luchó", fr = "combattu", pt = "lutou", ru = "сражался", de = "kämpfte", pl = "walczył", hu = "harcolt", sk = "bojoval" },
["thing"] = { lemma = "thing", es = "cosa", fr = "chose", pt = "coisa", ru = "вещь", de = "Sache", pl = "rzecz", hu = "dolog", sk = "vec" },
["things"] = { lemma = "thing", es = "cosas", fr = "choses", pt = "coisas", ru = "вещи", de = "Sachen", pl = "rzeczy", hu = "dolgok", sk = "veci" },
["bro"] = { lemma = "brother", es = "hermano", fr = "frère", pt = "irmão", ru = "братан", de = "Bruder", pl = "brat", hu = "tesó", sk = "brať" },
["goodbye"] = { lemma = "goodbye", es = "adiós", fr = "au revoir", pt = "adeus", ru = "до свидания", de = "auf Wiedersehen", pl = "do widzenia", hu = "viszlát", sk = "zbohom" },
    ["please"] = { lemma = "please", es = "por favor", fr = "s'il vous plaît", pt = "por favor", ru = "пожалуйста", de = "bitte", pl = "proszę", hu = "kérem", sk = "prosím" },
    ["thank you"] = { lemma = "thank you", es = "gracias", fr = "merci", pt = "obrigado", ru = "спасибо", de = "danke", pl = "dziękuję", hu = "köszönöm", sk = "ďakujem" },
    ["yes"] = { lemma = "yes", es = "sí", fr = "oui", pt = "sim", ru = "да", de = "ja", pl = "tak", hu = "igen", sk = "áno" },
    ["no"] = { lemma = "no", es = "no", fr = "non", pt = "não", ru = "нет", de = "nein", pl = "nie", hu = "nem", sk = "nie" },
    ["pull now"] = { lemma = "pull now", es = "tira ahora", fr = "pull maintenant", pt = "puxa agora", ru = "пулл сейчас", de = "jetzt pullen", pl = "ciągnij teraz", hu = "húzz most", sk = "ťiahni teraz" },
    ["watch aggro"] = { lemma = "watch aggro", es = "cuidado con el aggro", fr = "attention à l'aggro", pt = "cuidado com o aggro", ru = "следите за аггро", de = "auf Aggro achten", pl = "uważaj na aggro", hu = "figyelj az aggróra", sk = "dávaj pozor na aggro" },
    ["pop cooldowns"] = { lemma = "pop cooldowns", es = "usa enfriamientos", fr = "lancez les cooldowns", pt = "usa cooldowns", ru = "используйте кулдауны", de = "Cooldowns aktivieren", pl = "użyj cooldownów", hu = "használd a cooldownokat", sk = "použi cooldowny" },
    ["wipe it"] = { lemma = "wipe it", es = "wipeamos", fr = "on wipe", pt = "wipe", ru = "вайп", de = "wischen", pl = "wipe", hu = "wipe-olunk", sk = "wipe-neme" },
    ["stack up"] = { lemma = "stack up", es = "juntaos", fr = "groupez-vous", pt = "juntem-se", ru = "соберитесь", de = "zusammenstellen", pl = "zbierzcie się", hu = "álljatok össze", sk = "zhromaždite sa" },
    ["spread out"] = { lemma = "spread out", es = "separaros", fr = "dispersez-vous", pt = "espalhem-se", ru = "рассредоточьтесь", de = "verteilen", pl = "rozproszcie się", hu = "szétszóródjatok", sk = "rozostúpte sa" },
    ["kick interrupt"] = { lemma = "kick interrupt", es = "interrumpe", fr = "interrompez", pt = "interrompa", ru = "прерви", de = "unterbrechen", pl = "przerwij", hu = "szakítsd meg", sk = "prerušiť" },
    ["taunt now"] = { lemma = "taunt now", es = "provoca ahora", fr = "provoque maintenant", pt = "provoca agora", ru = "таунт сейчас", de = "jetzt spotten", pl = "taunt teraz", hu = "tauntolj most", sk = "tauntni teraz" },
    ["swap target"] = { lemma = "swap target", es = "cambia de objetivo", fr = "changez de cible", pt = "troca de alvo", ru = "смените цель", de = "Ziel wechseln", pl = "zmień cel", hu = "cserélj célpontot", sk = "zmeň cieľ" },
    ["focus boss"] = { lemma = "focus boss", es = "focaliza al jefe", fr = "concentrez-vous sur le boss", pt = "foco no chefe", ru = "фокус на боссе", de = "Boss fokussieren", pl = "skup się na bossie", hu = "fókuszálj a bossra", sk = "sústreď sa na bossa" },
    ["clear adds"] = { lemma = "clear adds", es = "limpia adds", fr = "nettoyez les adds", pt = "limpa os adds", ru = "зачисть аддов", de = "Adds beseitigen", pl = "wyczyść addy", hu = "tisztítsd meg az addokat", sk = "vyčisti addy" },
    ["stay alive"] = { lemma = "stay alive", es = "mantente vivo", fr = "restez en vie", pt = "fique vivo", ru = "оставайся живым", de = "am Leben bleiben", pl = "pozostań przy życiu", hu = "maradj életben", sk = "zostaň nažive" },
    ["big heal"] = { lemma = "big heal", es = "cura grande", fr = "gros soin", pt = "cura grande", ru = "большое исцеление", de = "große Heilung", pl = "duże leczenie", hu = "nagy heal", sk = "veľké liečenie" },
    ["dispel now"] = { lemma = "dispel now", es = "disipa ahora", fr = "dissipez maintenant", pt = "dispela agora", ru = "диспел сейчас", de = "jetzt dispellen", pl = "dispel teraz", hu = "dispel most", sk = "dispelni teraz" },
    ["move out"] = { lemma = "move out", es = "sal de ahí", fr = "sortez", pt = "saia daí", ru = "отойди", de = "rausgehen", pl = "wyjdź", hu = "mozdulj ki", sk = "vypadni" },
    ["watch floor"] = { lemma = "watch floor", es = "cuidado con el suelo", fr = "attention au sol", pt = "cuidado com o chão", ru = "смотри под ноги", de = "auf den Boden achten", pl = "patrz na podłogę", hu = "figyelj a talajra", sk = "dávaj pozor na podlahu" },
    ["drop portal"] = { lemma = "drop portal", es = "suelta portal", fr = "posez un portail", pt = "coloca portal", ru = "ставь портал", de = "Portal setzen", pl = "postaw portal", hu = "tegyél portált", sk = "polož portál" },
    ["lust now"] = { lemma = "lust now", es = "heroísmo ahora", fr = "héroïsme maintenant", pt = "lust agora", ru = "ласт сейчас", de = "jetzt Lust", pl = "lust teraz", hu = "lust most", sk = "lust teraz" },
    ["save mana"] = { lemma = "save mana", es = "guarda maná", fr = "économisez le mana", pt = "guarda mana", ru = "береги ману", de = "Mana sparen", pl = "oszczędzaj manę", hu = "spórolj a manával", sk = "šetri manu" },
    ["full focus"] = { lemma = "full focus", es = "foco total", fr = "concentration totale", pt = "foco total", ru = "полный фокус", de = "voller Fokus", pl = "pełne skupienie", hu = "teljes fókusz", sk = "plné sústredenie" },
    ["burn phase"] = { lemma = "burn phase", es = "fase de burst", fr = "phase de burst", pt = "fase de burst", ru = "фаза бурста", de = "Burn-Phase", pl = "faza burstu", hu = "burn fázis", sk = "burn fáza" },
    ["hold dps"] = { lemma = "hold dps", es = "para daño", fr = "arrêtez le DPS", pt = "segura o DPS", ru = "держите ДПС", de = "DPS zurückhalten", pl = "wstrzymaj DPS", hu = "tartsd vissza a DPS-t", sk = "zadrž DPS" },
    ["go hard"] = { lemma = "go hard", es = "dale fuerte", fr = "tapez fort", pt = "vai com tudo", ru = "жёстко вали", de = "hart rangehen", pl = "bij mocno", hu = "menj keményen", sk = "choď tvrdo" },
    ["nice pull"] = { lemma = "nice pull", es = "buen pull", fr = "beau pull", pt = "bom pull", ru = "хороший пулл", de = "guter Pull", pl = "dobry pull", hu = "szép húzás", sk = "pekný pull" },
    ["huge crit"] = { lemma = "huge crit", es = "crítico enorme", fr = "énorme crit", pt = "crit gigante", ru = "огромный крит", de = "riesiger Krit", pl = "ogromny krytyk", hu = "óriási krit", sk = "obrovský krit" },
    ["we got this"] = { lemma = "we got this", es = "lo tenemos", fr = "on gère", pt = "nós temos isso", ru = "мы справимся", de = "wir schaffen das", pl = "damy radę", hu = "megvan ez", sk = "máme to" },
    ["one shot"] = { lemma = "one shot", es = "de un golpe", fr = "one-shot", pt = "one-shot", ru = "ваншот", de = "One-Shot", pl = "one-shot", hu = "egy lövés", sk = "one-shot" },
    ["bad call"] = { lemma = "bad call", es = "mala decisión", fr = "mauvais call", pt = "chamada ruim", ru = "плохой колл", de = "schlechter Call", pl = "zły call", hu = "rossz döntés", sk = "zlý call" },
    ["clutch heal"] = { lemma = "clutch heal", es = "cura clave", fr = "soin clutch", pt = "cura clutch", ru = "клатч хил", de = "Clutch-Heilung", pl = "clutch heal", hu = "kulcsheal", sk = "clutch heal" },
    ["tank down"] = { lemma = "tank down", es = "tanque caído", fr = "tank à terre", pt = "tanque caiu", ru = "танк упал", de = "Tank down", pl = "tank padł", hu = "tank elesett", sk = "tank padol" },
    ["rez now"] = { lemma = "rez now", es = "resucita ahora", fr = "réz maintenant", pt = "ress agora", ru = "рез сейчас", de = "jetzt rezen", pl = "rez teraz", hu = "resz most", sk = "rezni teraz" },
    ["cc broke"] = { lemma = "cc broke", es = "control roto", fr = "CC brisé", pt = "CC quebrou", ru = "СС сломан", de = "CC gebrochen", pl = "CC złamane", hu = "CC megtört", sk = "CC zlomené" },
    ["gear check"] = { lemma = "gear check", es = "revisión de equipo", fr = "check d'équipement", pt = "checagem de gear", ru = "проверка шмоток", de = "Gear-Check", pl = "sprawdzenie gearu", hu = "felszerelés ellenőrzés", sk = "kontrola výbavy" },
    ["chill out"] = { lemma = "chill out", es = "tranqui", fr = "calme-toi", pt = "relaxa", ru = "успокойся", de = "entspann dich", pl = "wyluzuj", hu = "nyugodj meg", sk = "ukľudni sa" },
    ["tight fight"] = { lemma = "tight fight", es = "pelea ajustada", fr = "combat serré", pt = "luta apertada", ru = "тяжёлый бой", de = "knapper Kampf", pl = "ciasna walka", hu = "szoros harc", sk = "tesný boj" },
    ["sick loot"] = { lemma = "sick loot", es = "botín épico", fr = "butin génial", pt = "loot insano", ru = "крутой лут", de = "krasses Loot", pl = "super loot", hu = "király loot", sk = "skvelý loot" },
    ["noob move"] = { lemma = "noob move", es = "movida de novato", fr = "coup de noob", pt = "jogada de noob", ru = "нубский ход", de = "Noob-Zug", pl = "ruch nooba", hu = "noob húzás", sk = "noob ťah" },
    ["gank alert"] = { lemma = "gank alert", es = "alerta de gank", fr = "alerte gank", pt = "alerta de gank", ru = "ганк алерт", de = "Gank-Alarm", pl = "alert gank", hu = "gank figyelmeztetés", sk = "gank varovanie" },
    ["camped hard"] = { lemma = "camped hard", es = "campeado fuerte", fr = "campé fort", pt = "campado pesado", ru = "жестко кемпят", de = "hart gecampt", pl = "mocno kampowany", hu = "keményen campelnek", sk = "tvrdo kempovaný" },
    ["pvp time"] = { lemma = "pvp time", es = "hora de PvP", fr = "c'est l'heure du PvP", pt = "hora do PvP", ru = "время ПвП", de = "PvP-Zeit", pl = "czas na PvP", hu = "PvP idő", sk = "čas na PvP" },
    ["arena pop"] = { lemma = "arena pop", es = "arena lista", fr = "arène prête", pt = "arena pronta", ru = "арена готова", de = "Arena startet", pl = "arena gotowa", hu = "aréna indul", sk = "aréna pripravená" },
    ["lock down"] = { lemma = "lock down", es = "control total", fr = "verrouillage", pt = "lockdown", ru = "локдаун", de = "Lockdown", pl = "lockdown", hu = "lezárás", sk = "uzamknutie" },
    ["peel for"] = { lemma = "peel for", es = "protege a", fr = "peel pour", pt = "peel pro", ru = "пил для", de = "peelen für", pl = "peel dla", hu = "védj meg", sk = "peel pre" },
    ["burst him"] = { lemma = "burst him", es = "búrstealo", fr = "burst-le", pt = "bursta ele", ru = "бурсть его", de = "ihn bursten", pl = "burstnij go", hu = "burstöld le", sk = "burstni ho" },
    ["kite away"] = { lemma = "kite away", es = "kitea lejos", fr = "kite au loin", pt = "kite pra longe", ru = "кайт подальше", de = "weglocken", pl = "kite z dala", hu = "kiteolj távol", sk = "kite ďaleko" },
    ["call inc"] = { lemma = "call inc", es = "avisa llegada", fr = "annoncez l'inc", pt = "chama inc", ru = "кричи инк", de = "Inc melden", pl = "zgłoś inc", hu = "jelezd az incet", sk = "ohlás inc" },
    ["heal me"] = { lemma = "heal me", es = "cúrame", fr = "soigne-moi", pt = "cura-me", ru = "хиль меня", de = "heil mich", pl = "ulecz mnie", hu = "healelj meg", sk = "vylieč ma" },
    ["watch back"] = { lemma = "watch back", es = "cuidado atrás", fr = "attention derrière", pt = "cuidado atrás", ru = "смотри сзади", de = "hinten aufpassen", pl = "patrz za siebie", hu = "figyelj hátul", sk = "dávaj pozor vzadu" },
    ["good try"] = { lemma = "good try", es = "buen intento", fr = "bel essai", pt = "boa tentativa", ru = "хорошая попытка", de = "guter Versuch", pl = "dobra próba", hu = "jó próbálkozás", sk = "dobrý pokus" },
    ["next pull"] = { lemma = "next pull", es = "siguiente pull", fr = "prochain pull", pt = "próximo pull", ru = "следующий пулл", de = "nächster Pull", pl = "następny pull", hu = "következő húzás", sk = "ďalší pull" },
    ["raid up"] = { lemma = "raid up", es = "raid lista", fr = "raid prêt", pt = "raid pronto", ru = "рейд готов", de = "Raid bereit", pl = "raid gotowy", hu = "raid kész", sk = "raid pripravený" },
["sorry"] = { lemma = "sorry", es = "lo siento", fr = "désolé", pt = "desculpe-me", ru = "извини", de = "entschuldigung", pl = "przepraszam", hu = "bocsánat", sk = "prepáč" },
    ["excuse me"] = { lemma = "excuse me", es = "disculpe", fr = "excusez-moi", pt = "com licença", ru = "извините", de = "entschuldigung", pl = "przepraszam", hu = "elnézést", sk = "ospravedlnte ma" },
    ["good morning"] = { lemma = "good morning", es = "Buenos días", fr = "bonjour", pt = "bom dia", ru = "доброе утро", de = "guten Morgen", pl = "dzień dobry", hu = "jó reggelt", sk = "dobré ráno" },
    ["good night"] = { lemma = "good night", es = "buenas noches", fr = "bonne nuit", pt = "boa noite", ru = "спокойной ночи", de = "gute Nacht", pl = "dobranoc", hu = "jó éjszakát", sk = "dobrú noc" },
    ["how are you"] = { lemma = "how are you", es = "cómo estás", fr = "comment vas-tu", pt = "como você está", ru = "как дела", de = "wie geht's", pl = "jak się masz", hu = "hogy vagy", sk = "ako sa máš" },
    ["my name is"] = { lemma = "my name is", es = "mi nombre es", fr = "je m'appelle", pt = "meu nome é", ru = "меня зовут", de = "mein Name ist", pl = "mam na imię", hu = "a nevem", sk = "moje meno je" },
    ["friend"] = { lemma = "friend", es = "amigo", fr = "ami", pt = "amigo", ru = "друг", de = "Freund", pl = "przyjaciel", hu = "barát", sk = "priateľ" },
    ["family"] = { lemma = "family", es = "familia", fr = "famille", pt = "família", ru = "семья", de = "Familie", pl = "rodzina", hu = "család", sk = "rodina" },
    ["love"] = { lemma = "love", es = "amor", fr = "amour", pt = "amor", ru = "любовь", de = "Liebe", pl = "miłość", hu = "szeretet", sk = "láska" },
    ["home"] = { lemma = "home", es = "casa", fr = "maison", pt = "casa", ru = "дом", de = "Haus", pl = "dom", hu = "otthon", sk = "domov" },
    ["school"] = { lemma = "school", es = "escuela", fr = "école", pt = "escola", ru = "школа", de = "Schule", pl = "szkoła", hu = "iskola", sk = "škola" },
    ["teacher"] = { lemma = "teacher", es = "profesor", fr = "professeur", pt = "professor", ru = "учитель", de = "Lehrer", pl = "nauczyciel", hu = "tanár", sk = "učiteľ" },
    ["student"] = { lemma = "student", es = "estudiante", fr = "étudiant", pt = "estudante", ru = "студент", de = "Student", pl = "student", hu = "diák", sk = "študent" },
    ["book"] = { lemma = "book", es = "libro", fr = "livre", pt = "livro", ru = "книга", de = "Buch", pl = "książka", hu = "könyv", sk = "kniha" },
    ["pen"] = { lemma = "pen", es = "bolígrafo", fr = "stylo", pt = "caneta", ru = "ручка", de = "Stift", pl = "długopis", hu = "toll", sk = "pero" },
    ["paper"] = { lemma = "paper", es = "papel", fr = "papier", pt = "papel", ru = "бумага", de = "Papier", pl = "papier", hu = "papír", sk = "papier" },
    ["table"] = { lemma = "table", es = "mesa", fr = "table", pt = "mesa", ru = "стол", de = "Tisch", pl = "stół", hu = "asztal", sk = "stôl" },
    ["chair"] = { lemma = "chair", es = "silla", fr = "chaise", pt = "cadeira", ru = "стул", de = "Stuhl", pl = "krzesło", hu = "szék", sk = "stolička" },
    ["door"] = { lemma = "door", es = "puerta", fr = "porte", pt = "porta", ru = "дверь", de = "Tür", pl = "drzwi", hu = "ajtó", sk = "dvere" },
    ["window"] = { lemma = "window", es = "ventana", fr = "fenêtre", pt = "janela", ru = "окно", de = "Fenster", pl = "okno", hu = "ablak", sk = "okno" },
    ["time"] = { lemma = "time", es = "tiempo", fr = "temps", pt = "tempo", ru = "время", de = "Zeit", pl = "czas", hu = "idő", sk = "čas" },
    ["day"] = { lemma = "day", es = "día", fr = "jour", pt = "dia", ru = "день", de = "Tag", pl = "dzień", hu = "nap", sk = "deň" },
    ["night"] = { lemma = "night", es = "noche", fr = "nuit", pt = "noite", ru = "ночь", de = "Nacht", pl = "noc", hu = "éjszaka", sk = "noc" },
    ["week"] = { lemma = "week", es = "semana", fr = "semaine", pt = "semana", ru = "неделя", de = "Woche", pl = "tydzień", hu = "hét", sk = "týždeň" },
    ["month"] = { lemma = "month", es = "mes", fr = "mois", pt = "mês", ru = "месяц", de = "Monat", pl = "miesiąc", hu = "hónap", sk = "mesiac" },
    ["year"] = { lemma = "year", es = "año", fr = "année", pt = "ano", ru = "год", de = "Jahr", pl = "rok", hu = "év", sk = "rok" },
    ["today"] = { lemma = "today", es = "hoy", fr = "aujourd'hui", pt = "hoje", ru = "сегодня", de = "heute", pl = "dzisiaj", hu = "ma", sk = "dnes" },
    ["tomorrow"] = { lemma = "tomorrow", es = "mañana", fr = "demain", pt = "amanhã", ru = "завтра", de = "morgen", pl = "jutro", hu = "holnap", sk = "zajtra" },
    ["yesterday"] = { lemma = "yesterday", es = "ayer", fr = "hier", pt = "ontem", ru = "вчера", de = "gestern", pl = "wczoraj", hu = "tegnap", sk = "včera" },
    ["mother"] = { lemma = "mother", es = "madre", fr = "mère", pt = "mãe", ru = "мать", de = "Mutter", pl = "matka", hu = "anya", sk = "matka" },
    ["father"] = { lemma = "father", es = "padre", fr = "père", pt = "pai", ru = "отец", de = "Vater", pl = "ojciec", hu = "apa", sk = "otec" },
    ["brother"] = { lemma = "brother", es = "hermano", fr = "frère", pt = "irmão", ru = "брат", de = "Bruder", pl = "brat", hu = "fivér", sk = "brat" },
    ["sister"] = { lemma = "sister", es = "hermana", fr = "sœur", pt = "irmã", ru = "сестра", de = "Schwester", pl = "siostra", hu = "nővér", sk = "sestra" },
    ["child"] = { lemma = "child", es = "niño", fr = "enfant", pt = "criança", ru = "ребёнок", de = "Kind", pl = "dziecko", hu = "gyermek", sk = "dieťa" },
    ["food"] = { lemma = "food", es = "comida", fr = "nourriture", pt = "comida", ru = "еда", de = "Essen", pl = "jedzenie", hu = "étel", sk = "jedlo" },
    ["water"] = { lemma = "water", es = "agua", fr = "eau", pt = "água", ru = "вода", de = "Wasser", pl = "woda", hu = "víz", sk = "voda" },
    ["bread"] = { lemma = "bread", es = "pan", fr = "pain", pt = "pão", ru = "хлеб", de = "Brot", pl = "chleb", hu = "kenyér", sk = "chlieb" },
    ["milk"] = { lemma = "milk", es = "leche", fr = "lait", pt = "leite", ru = "молоко", de = "Milch", pl = "mleko", hu = "tej", sk = "mlieko" },
    ["apple"] = { lemma = "apple", es = "manzana", fr = "pomme", pt = "maçã", ru = "яблоко", de = "Apfel", pl = "jabłko", hu = "alma", sk = "jablko" },
    ["house"] = { lemma = "house", es = "casa", fr = "maison", pt = "casa", ru = "дом", de = "Haus", pl = "dom", hu = "ház", sk = "dom" },
    ["car"] = { lemma = "car", es = "coche", fr = "voiture", pt = "carro", ru = "машина", de = "Auto", pl = "samochód", hu = "autó", sk = "auto" },
    ["dog"] = { lemma = "dog", es = "perro", fr = "chien", pt = "cão", ru = "собака", de = "Hund", pl = "pies", hu = "kutya", sk = "pes" },
    ["cat"] = { lemma = "cat", es = "gato", fr = "chat", pt = "gato", ru = "кошка", de = "Katze", pl = "kot", hu = "macska", sk = "mačka" },
    ["bird"] = { lemma = "bird", es = "pájaro", fr = "oiseau", pt = "pássaro", ru = "птица", de = "Vogel", pl = "ptak", hu = "madár", sk = "vták" },
    ["tree"] = { lemma = "tree", es = "árbol", fr = "arbre", pt = "árvore", ru = "дерево", de = "Baum", pl = "drzewo", hu = "fa", sk = "strom" },
    ["flower"] = { lemma = "flower", es = "flor", fr = "fleur", pt = "flor", ru = "цветок", de = "Blume", pl = "kwiat", hu = "virág", sk = "kvet" },
    ["sun"] = { lemma = "sun", es = "sol", fr = "soleil", pt = "sol", ru = "солнце", de = "Sonne", pl = "słońce", hu = "nap", sk = "slnko" },
    ["moon"] = { lemma = "moon", es = "luna", fr = "lune", pt = "lua", ru = "луна", de = "Mond", pl = "księżyc", hu = "hold", sk = "mesiac" },
    ["star"] = { lemma = "star", es = "estrella", fr = "étoile", pt = "estrela", ru = "звезда", de = "Stern", pl = "gwiazda", hu = "csillag", sk = "hviezda" },
    ["sky"] = { lemma = "sky", retorika = "cielo", fr = "ciel", pt = "céu", ru = "небо", de = "Himmel", pl = "niebo", hu = "ég", sk = "nebo" },
    ["cloud"] = { lemma = "cloud", es = "nube", fr = "nuage", pt = "nuvem", ru = "облако", de = "Wolke", pl = "chmura", hu = "felhő", sk = "oblak" },
    ["rain"] = { lemma = "rain", es = "lluvia", fr = "pluie", pt = "chuva", ru = "дождь", de = "Regen", pl = "deszcz", hu = "eső", sk = "dážď" },
    ["wind"] = { lemma = "wind", es = "viento", fr = "vent", pt = "vento", ru = "ветер", de = "Wind", pl = "wiatr", hu = "szél", sk = "vietor" },
    ["big"] = { lemma = "big", es = "grande", fr = "grand", pt = "grande", ru = "большой", de = "groß", pl = "duży", hu = "nagy", sk = "veľký" },
    ["small"] = { lemma = "small", es = "pequeño", fr = "petit", pt = "pequeno", ru = "маленький", de = "klein", pl = "mały", hu = "kicsi", sk = "malý" },
    ["hot"] = { lemma = "hot", es = "caliente", fr = "chaud", pt = "quente", ru = "горячий", de = "heiß", pl = "gorący", hu = "forró", sk = "horúci" },
    ["cold"] = { lemma = "cold", es = "frío", fr = "froid", pt = "frio", ru = "холодный", de = "kalt", pl = "zimny", hu = "hideg", sk = "chladný" },
    ["happy"] = { lemma = "happy", es = "feliz", fr = "heureux", pt = "feliz", ru = "счастливый", de = "glücklich", pl = "szczęśliwy", hu = "boldog", sk = "šťastný" },
    ["sad"] = { lemma = "sad", es = "triste", fr = "triste", pt = "triste", ru = "грустный", de = "traurig", pl = "smutny", hu = "szomorú", sk = "smutný" },
    ["good"] = { lemma = "good", es = "bueno", fr = "bon", pt = "bom", ru = "хороший", de = "gut", pl = "dobry", hu = "jó", sk = "dobrý" },
    ["bad"] = { lemma = "bad", es = "malo", fr = "mauvais", pt = "mau", ru = "плохой", de = "schlecht", pl = "zły", hu = "rossz", sk = "zlý" },
    ["eat"] = { lemma = "eat", es = "comer", fr = "manger", pt = "comer", ru = "есть", de = "essen", pl = "jeść", hu = "enni", sk = "jesť" },
    ["drink"] = { lemma = "drink", es = "beber", fr = "boire", pt = "beber", ru = "пить", de = "trinken", pl = "pić", hu = "inni", sk = "piť" },
    ["sleep"] = { lemma = "sleep", es = "dormir", fr = "dormir", pt = "dormir", ru = "спать", de = "schlafen", pl = "spać", hu = "aludni", sk = "spať" },
    ["walk"] = { lemma = "walk", es = "caminar", fr = "marcher", pt = "caminhar", ru = "идти", de = "gehen", pl = "chodzić", hu = "sétálni", sk = "chodiť" },
    ["run"] = { lemma = "run", es = "correr", fr = "courir", pt = "correr", ru = "бежать", de = "laufen", pl = "biegać", hu = "futni", sk = "bežať" },
    ["read"] = { lemma = "read", es = "leer", fr = "lire", pt = "ler", ru = "читать", de = "lesen", pl = "czytać", hu = "olvasni", sk = "čítať" },
    ["write"] = { lemma = "write", es = "escribir", fr = "écrire", pt = "escrever", ru = "писать", de = "schreiben", pl = "pisać", hu = "írni", sk = "písať" },
    ["speak"] = { lemma = "speak", es = "hablar", fr = "parler", pt = "falar", ru = "говорить", de = "sprechen", pl = "mówić", hu = "beszélni", sk = "hovoriť" },
    ["listen"] = { lemma = "listen", es = "escuchar", fr = "écouter", pt = "ouvir", ru = "слушать", de = "hören", pl = "słuchać", hu = "hallgatni", sk = "počúvať" },
    ["see"] = { lemma = "see", es = "ver", fr = "voir", pt = "ver", ru = "видеть", de = "sehen", pl = "widzieć", hu = "látni", sk = "vidieť" },
    ["one"] = { lemma = "one", es = "uno", fr = "un", pt = "um", ru = "один", de = "eins", pl = "jeden", hu = "egy", sk = "jeden" },
    ["two"] = { lemma = "two", es = "dos", fr = "deux", pt = "dois", ru = "два", de = "zwei", pl = "dwa", hu = "kettő", sk = "dva" },
    ["three"] = { lemma = "three", es = "tres", fr = "trois", pt = "três", ru = "три", de = "drei", pl = "trzy", hu = "három", sk = "tri" },
    ["four"] = { lemma = "four", es = "cuatro", fr = "quatre", pt = "quatro", ru = "четыре", de = "vier", pl = "cztery", hu = "négy", sk = "štyri" },
    ["five"] = { lemma = "five", es = "cinco", fr = "cinq", pt = "cinco", ru = "пять", de = "fünf", pl = "pięć", hu = "öt", sk = "päť" },
    ["red"] = { lemma = "red", es = "rojo", fr = "rouge", pt = "vermelho", ru = "красный", de = "rot", pl = "czerwony", hu = "piros", sk = "červený" },
    ["blue"] = { lemma = "blue", es = "azul", fr = "bleu", pt = "azul", ru = "синий", de = "blau", pl = "niebieski", hu = "kék", sk = "modrý" },
    ["green"] = { lemma = "green", es = "verde", fr = "vert", pt = "verde", ru = "зелёный", de = "grün", pl = "zielony", hu = "zöld", sk = "zelený" },
    ["yellow"] = { lemma = "yellow", es = "amarillo", fr = "jaune", pt = "amarelo", ru = "жёлтый", de = "gelb", pl = "żółty", hu = "sárga", sk = "žltý" },
    ["black"] = { lemma = "black", es = "negro", fr = "noir", pt = "preto", ru = "чёрный", de = "schwarz", pl = "czarny", hu = "fekete", sk = "čierny" },
    ["white"] = { lemma = "white", es = "blanco", fr = "blanc", pt = "branco", ru = "белый", de = "weiß", pl = "biały", hu = "fehér", sk = "biely" },
    ["man"] = { lemma = "man", es = "hombre", fr = "homme", pt = "homem", ru = "мужчина", de = "Mann", pl = "mężczyzna", hu = "férfi", sk = "muž" },
    ["woman"] = { lemma = "woman", es = "mujer", fr = "femme", pt = "mulher", ru = "женщина", de = "Frau", pl = "kobieta", hu = "nő", sk = "žena" },
    ["city"] = { lemma = "city", es = "ciudad", fr = "ville", pt = "cidade", ru = "город", de = "Stadt", pl = "miasto", hu = "város", sk = "mesto" },
    ["country"] = { lemma = "country", es = "país", fr = "pays", pt = "país", ru = "страна", de = "Land", pl = "kraj", hu = "ország", sk = "krajina" },
    ["street"] = { lemma = "street", es = "calle", fr = "rue", pt = "rua", ru = "улица", de = "Straße", pl = "ulica", hu = "utca", sk = "ulica" },
["fresh"] = { lemma = "fresh", es = "nuevo", fr = "nouveau", pt = "novo", ru = "новый", de = "frisch", pl = "świeży", hu = "friss", sk = "čerstvý" },
    ["mr"] = { lemma = "mr", es = "señor", fr = "monsieur", pt = "senhor", ru = "господин", de = "Herr", pl = "pan", hu = "úr", sk = "pán" },
    ["mrs"] = { lemma = "mrs", es = "señora", fr = "madame", pt = "senhora", ru = "госпожа", de = "Frau", pl = "pani", hu = "asszony", sk = "pani" },
    ["i want"] = { lemma = "i want", es = "quiero", fr = "je veux", pt = "eu quero", ru = "я хочу", de = "ich will", pl = "chcę", hu = "akarok", sk = "chcem" },
["inv"] = { lemma = "inv", es = "invitar", fr = "inviter", pt = "convidar", ru = "пригласить", de = "einladen", pl = "zaprosić", hu = "meghívni", sk = "pozvať" },
    ["add"] = { lemma = "add", es = "añadir", fr = "ajouter", pt = "adicionar", ru = "добавить", de = "hinzufügen", pl = "dodać", hu = "hozzáadni", sk = "pridať" },
    ["remove"] = { lemma = "remove", es = "eliminar", fr = "supprimer", pt = "remover", ru = "удалить", de = "entfernen", pl = "usunąć", hu = "eltávolítani", sk = "odstrániť" },
    ["yo"] = { lemma = "yo", es = "hola", fr = "salut", pt = "oi", ru = "привет", de = "hey", pl = "cześć", hu = "helló", sk = "ahoj" },
    ["ty"] = { lemma = "ty", es = "gracias", fr = "merci", pt = "obrigado", ru = "спасибо", de = "danke", pl = "dzięki", hu = "köszönöm", sk = "ďakujem" },
["are"] = { lemma = "be", es = "son", fr = "sont", pt = "são", ru = "есть", de = "sind", pl = "są", hu = "vannak", sk = "sú" },
    ["was"] = { lemma = "be", es = "fue", fr = "était", pt = "foi", ru = "был", de = "war", pl = "był", hu = "volt", sk = "bol" },
    ["have"] = { lemma = "have", es = "tener", fr = "avoir", pt = "ter", ru = "иметь", de = "haben", pl = "mieć", hu = "birtokol", sk = "mať" },
    ["had"] = { lemma = "have", es = "tenía", fr = "avait", pt = "tinha", ru = "имел", de = "hatte", pl = "miał", hu = "volt", sk = "mal" },
    ["lfm"] = { lemma = "look for more", es = "buscando más", fr = "cherche plus", pt = "procurando mais", ru = "ищу еще", de = "suche mehr", pl = "szukam więcej", hu = "többeket keres", sk = "hľadám ďalších" },
["player"] = { lemma = "player", es = "jugador", fr = "joueur", pt = "jogador", ru = "игрок", de = "Spieler", pl = "gracz", hu = "játékos", sk = "hráč" },
["players"] = { lemma = "player", es = "jugadores", fr = "joueurs", pt = "jogadores", ru = "игроки", de = "Spieler", pl = "gracze", hu = "játékosok", sk = "hráči" },
["skilled"] = { lemma = "skilled", es = "hábil", fr = "compétent", pt = "habilidoso", ru = "опытный", de = "erfahren", pl = "doświadczony", hu = "tapasztalt", sk = "skúsený" },
["free"] = { lemma = "free", es = "libre", fr = "libre", pt = "livre", ru = "свободен", de = "frei", pl = "wolny", hu = "szabad", sk = "voľný" },
["here"] = { lemma = "here", es = "aquí", fr = "ici", pt = "aqui", ru = "здесь", de = "hier", pl = "tutaj", hu = "itt", sk = "tu" },
    ["equal"] = { lemma = "equal", es = "igual", fr = "égal", pt = "igual", ru = "равный", de = "gleich", pl = "równy", hu = "egyenlő", sk = "rovnaký" },
 ["someone"] = { lemma = "someone", es = "alguien", fr = "quelqu'un", pt = "alguém", ru = "кто-то", de = "jemand", pl = "ktoś", hu = "valaki", sk = "niekto" },
["me"] = { lemma = "me", es = "me", fr = "me", pt = "me", ru = "меня", de = "mich", pl = "mnie", hu = "engem", sk = "mňa" },
["help"] = { lemma = "help", es = "ayuda", fr = "aider", pt = "ajuda", ru = "помощь", de = "Hilfe", pl = "pomoc", hu = "segítség", sk = "pomoc" },
["with"] = { lemma = "with", es = "con", fr = "avec", pt = "com", ru = "с", de = "mit", pl = "z", hu = "val", sk = "s" },
["a"] = { lemma = "a", es = "un", fr = "un", pt = "um", ru = "один", de = "ein", pl = "jeden", hu = "egy", sk = "jeden" },
["little"] = { lemma = "little", es = "poco", fr = "peu", pt = "pouco", ru = "немного", de = "wenig", pl = "mało", hu = "kevés", sk = "málo" },
["gold"] = { lemma = "gold", es = "oro", fr = "or", pt = "ouro", ru = "золото", de = "Gold", pl = "złoto", hu = "arany", sk = "zlato" },
["please"] = { lemma = "please", es = "por favor", fr = "s'il vous plaît", pt = "por favor", ru = "пожалуйста", de = "bitte", pl = "proszę", hu = "kérlek", sk = "prosím" },
["need"] = { lemma = "need", es = "necesitar", fr = "besoin", pt = "precisar", ru = "нужно", de = "brauchen", pl = "potrzebować", hu = "szükség", sk = "potrebovať" },
["give"] = { lemma = "give", es = "dar", fr = "donner", pt = "dar", ru = "дать", de = "geben", pl = "dać", hu = "adni", sk = "dať" },
["can you"] = { lemma = "can you", es = "puedes", fr = "peux-tu", pt = "podes", ru = "можешь", de = "kannst du", pl = "czy możesz", hu = "tudsz", sk = "môžeš" },
["trade"] = { lemma = "trade", es = "comerciar", fr = "échanger", pt = "trocar", ru = "обмен", de = "handeln", pl = "handlować", hu = "kereskedni", sk = "obchodovať" },
["more"] = { lemma = "more", es = "más", fr = "plus", pt = "mais", ru = "больше", de = "mehr", pl = "więcej", hu = "több", sk = "viac" },
["some"] = { lemma = "some", es = "algún", fr = "quelque", pt = "algum", ru = "некоторые", de = "einige", pl = "niektóre", hu = "néhány", sk = "niektoré" },
["now"] = { lemma = "now", es = "ahora", fr = "maintenant", pt = "agora", ru = "сейчас", de = "jetzt", pl = "teraz", hu = "most", sk = "teraz" },
	["info"] = { lemma = "info", es = "info", fr = "info", pt = "info", ru = "инфо", de = "Info", pl = "info", hu = "infó", sk = "info" },
["do"] = { lemma = "do", es = "hacer", fr = "faire", pt = "fazer", ru = "делать", de = "tun", pl = "robić", hu = "csinál", sk = "robiť" },
    ["did"] = { lemma = "do", es = "hizo", fr = "fait", pt = "fez", ru = "сделал", de = "tat", pl = "zrobił", hu = "tett", sk = "urobil" },
    ["say"] = { lemma = "say", es = "decir", fr = "dire", pt = "dizer", ru = "сказать", de = "sagen", pl = "mówić", hu = "mond", sk = "hovoriť" },
    ["said"] = { lemma = "say", es = "dijo", fr = "dit", pt = "disse", ru = "сказал", de = "sagte", pl = "powiedział", hu = "mondta", sk = "povedal" },
    ["get"] = { lemma = "get", es = "conseguir", fr = "obtenir", pt = "obter", ru = "получить", de = "bekommen", pl = "dostać", hu = "szerez", sk = "zohnať" },
    ["got"] = { lemma = "get", es = "consiguió", fr = "obtenu", pt = "obteve", ru = "получил", de = "bekam", pl = "dostał", hu = "kapott", sk = "dostal" },
    ["make"] = { lemma = "make", es = "hacer", fr = "faire", pt = "fazer", ru = "сделать", de = "machen", pl = "zrobić", hu = "készít", sk = "urobiť" },
    ["made"] = { lemma = "make", es = "hizo", fr = "fait", pt = "fez", ru = "сделал", de = "machte", pl = "zrobił", hu = "készített", sk = "urobil" },
    ["go"] = { lemma = "go", es = "ir", fr = "aller", pt = "ir", ru = "идти", de = "gehen", pl = "iść", hu = "megy", sk = "ísť" },
    ["went"] = { lemma = "go", es = "fue", fr = "allé", pt = "foi", ru = "пошёл", de = "ging", pl = "poszedł", hu = "ment", sk = "išiel" },
    ["know"] = { lemma = "know", es = "saber", fr = "savoir", pt = "saber", ru = "знать", de = "wissen", pl = "wiedzieć", hu = "tud", sk = "vedieť" },
    ["knew"] = { lemma = "know", es = "supo", fr = "su", pt = "soube", ru = "знал", de = "wusste", pl = "wiedział", hu = "tudott", sk = "vedel" },
    ["think"] = { lemma = "think", es = "pensar", fr = "penser", pt = "pensar", ru = "думать", de = "denken", pl = "myśleć", hu = "gondol", sk = "myslieť" },
["thought"] = { lemma = "think", es = "pensó", fr = "pensé", pt = "pensou", ru = "думал", de = "dachte", pl = "myślał", hu = "gondolta", sk = "myslel" },
   ["quest"] = { lemma = "quest", es = "misión", fr = "quête", pt = "missão", ru = "квест", de = "Quest", pl = "zadanie", hu = "küldetés", sk = "úloha" },
["damn"] = { lemma = "damn", es = "maldita sea", fr = "merde", pt = "droga", ru = "чёрт", de = "verdammt", pl = "cholera", hu = "átkozott", sk = "do čerta" },
["shit"] = { lemma = "shit", es = "mierda", fr = "merde", pt = "merda", ru = "дерьмо", de = "Scheiße", pl = "gówno", hu = "szar", sk = "sračka" },
["fuck"] = { lemma = "fuck", es = "joder", fr = "putain", pt = "foda", ru = "блять", de = "Scheiß", pl = "pierdolić", hu = "baszd meg", sk = "do prdele" },
["asshole"] = { lemma = "asshole", es = "imbécil", fr = "connard", pt = "idiota", ru = "придурок", de = "Arschloch", pl = "dupek", hu = "seggfej", sk = "kretén" },
["bitch"] = { lemma = "bitch", es = "perra", fr = "salope", pt = "vadia", ru = "сука", de = "Schlampe", pl = "suka", hu = "kurva", sk = "kurva" },
["noob"] = { lemma = "noob", es = "novato", fr = "noob", pt = "novato", ru = "нуб", de = "Noob", pl = "noob", hu = "újonc", sk = "nováčik" },
["suck"] = { lemma = "suck", es = "apesta", fr = "naze", pt = "é uma merda", ru = "отстой", de = "scheiße", pl = "do bani", hu = "szar", sk = "na nič" },
["trash talk"] = { lemma = "trash talk", es = "hablar basura", fr = "parler poubelle", pt = "falar lixo", ru = "треш-ток", de = "Trash-Talk", pl = "gadać bzdury", hu = "szemétbeszéd", sk = "hlúpe reči" },
["get good"] = { lemma = "get good", es = "mejora", fr = "deviens meilleur", pt = "melhora", ru = "стань лучше", de = "werd besser", pl = "bądź lepszy", hu = "javulj fel", sk = "zlepši sa" },
["you suck"] = { lemma = "you suck", es = "tú apestas", fr = "tu es nul", pt = "você é péssimo", ru = "ты отстой", de = "du bist scheiße", pl = "jesteś do bani", hu = "szar vagy", sk = "si na nič" },
["dungeon"] = { lemma = "dungeon", es = "mazmorra", fr = "donjon", pt = "masmorra", ru = "подземелье", de = "Dungeon", pl = "loch", hu = "kazamata", sk = "dungeon" },
 ["take"] = { lemma = "take", es = "tomar", fr = "prendre", pt = "tomar", ru = "взять", de = "nehmen", pl = "wziąć", hu = "vesz", sk = "vziať" },
    ["took"] = { lemma = "take", es = "tomó", fr = "pris", pt = "tomou", ru = "взял", de = "nahm", pl = "wziął", hu = "vett", sk = "vzal" },
    ["see"] = { lemma = "see", es = "ver", fr = "voir", pt = "ver", ru = "видеть", de = "sehen", pl = "widzieć", hu = "lát", sk = "vidieť" },
    ["saw"] = { lemma = "see", es = "vio", fr = "vu", pt = "viu", ru = "увидел", de = "sah", pl = "widział", hu = "látott", sk = "videl" },
    ["come"] = { lemma = "come", es = "venir", fr = "venir", pt = "vir", ru = "прийти", de = "kommen", pl = "przyjść", hu = "jön", sk = "prísť" },
    ["came"] = { lemma = "come", es = "vino", fr = "venu", pt = "veio", ru = "пришёл", de = "kam", pl = "przyszedł", hu = "jött", sk = "prišiel" },
    ["want"] = { lemma = "want", es = "querer", fr = "vouloir", pt = "querer", ru = "хотеть", de = "wollen", pl = "chcieć", hu = "akar", sk = "chcieť" },
    ["wanted"] = { lemma = "want", es = "quiso", fr = "voulu", pt = "quis", ru = "хотел", de = "wollte", pl = "chciał", hu = "akart", sk = "chcel" },
    ["look"] = { lemma = "look", es = "mirar", fr = "regarder", pt = "olhar", ru = "смотреть", de = "schauen", pl = "patrzeć", hu = "néz", sk = "pozrieť" },
    ["use"] = { lemma = "use", es = "usar", fr = "utiliser", pt = "usar", ru = "использовать", de = "benutzen", pl = "używać", hu = "használ", sk = "použiť" },
    ["find"] = { lemma = "find", es = "encontrar", fr = "trouver", pt = "encontrar", ru = "найти", de = "finden", pl = "znaleźć", hu = "talál", sk = "nájsť" },
    ["found"] = { lemma = "find", es = "encontró", fr = "trouvé", pt = "encontrou", ru = "нашёл", de = "fand", pl = "znalazł", hu = "talált", sk = "našiel" },
    ["give"] = { lemma = "give", es = "dar", fr = "donner", pt = "dar", ru = "дать", de = "geben", pl = "dać", hu = "ad", sk = "dať" },
    ["gave"] = { lemma = "give", es = "dio", fr = "donné", pt = "deu", ru = "дал", de = "gab", pl = "dał", hu = "adott", sk = "dal" },
    ["tell"] = { lemma = "tell", es = "decir", fr = "dire", pt = "dizer", ru = "сказать", de = "erzählen", pl = "powiedzieć", hu = "mond", sk = "povedať" },
    ["told"] = { lemma = "tell", es = "dijo", fr = "dit", pt = "disse", ru = "сказал", de = "erzählte", pl = "powiedział", hu = "mondta", sk = "povedal" },
    ["work"] = { lemma = "work", es = "trabajar", fr = "travailler", pt = "trabalhar", ru = "работать", de = "arbeiten", pl = "pracować", hu = "dolgozik", sk = "pracovať" },
    ["call"] = { lemma = "call", es = "llamar", fr = "appeler", pt = "chamar", ru = "звонить", de = "anrufen", pl = "dzwonić", hu = "hív", sk = "volať" },
    ["try"] = { lemma = "try", es = "intentar", fr = "essayer", pt = "tentar", ru = "пытаться", de = "versuchen", pl = "próbować", hu = "próbál", sk = "skúšať" },
    ["ask"] = { lemma = "ask", es = "preguntar", fr = "demander", pt = "perguntar", ru = "спросить", de = "fragen", pl = "pytać", hu = "kérdez", sk = "pýtať" },
    ["need"] = { lemma = "need", es = "necesitar", fr = "besoin", pt = "precisar", ru = "нужен", de = "brauchen", pl = "potrzebować", hu = "szükség", sk = "potrebovať" },
    ["feel"] = { lemma = "feel", es = "sentir", fr = "ressentir", pt = "sentir", ru = "чувствовать", de = "fühlen", pl = "czuć", hu = "érez", sk = "cítiť" },
    ["become"] = { lemma = "become", es = "convertirse", fr = "devenir", pt = "tornar-se", ru = "становиться", de = "werden", pl = "stać się", hu = "válik", sk = "stať sa" },
    ["leave"] = { lemma = "leave", es = "salir", fr = "partir", pt = "sair", ru = "уходить", de = "verlassen", pl = "wyjść", hu = "elmegy", sk = "odísť" },
    ["put"] = { lemma = "put", es = "poner", fr = "mettre", pt = "colocar", ru = "класть", de = "legen", pl = "położyć", hu = "tesz", sk = "položiť" },
    ["mean"] = { lemma = "mean", es = "significar", fr = "signifier", pt = "significar", ru = "означать", de = "bedeuten", pl = "znaczyć", hu = "jelent", sk = "znamená" },
    ["keep"] = { lemma = "keep", es = "mantener", fr = "garder", pt = "manter", ru = "держать", de = "behalten", pl = "trzymać", hu = "tart", sk = "držať" },
    ["let"] = { lemma = "let", es = "dejar", fr = "laisser", pt = "deixar", ru = "позволять", de = "lassen", pl = "pozwolić", hu = "enged", sk = "nechať" },
    ["run"] = { lemma = "run", es = "correr", fr = "courir", pt = "correr", ru = "бежать", de = "laufen", pl = "biegać", hu = "fut", sk = "bežať" },
    ["running"] = { lemma = "run", es = "corriendo", fr = "courant", pt = "correndo", ru = "бегущий", de = "laufend", pl = "biegający", hu = "futó", sk = "bežiaci" },
    ["ran"] = { lemma = "run", es = "corrió", fr = "couru", pt = "correu", ru = "бежал", de = "lief", pl = "biegał", hu = "futott", sk = "bežal" },
    ["talk"] = { lemma = "talk", es = "hablar", fr = "parler", pt = "falar", ru = "говорить", de = "sprechen", pl = "mówić", hu = "beszél", sk = "hovoriť" },
    ["talking"] = { lemma = "talk", es = "hablando", fr = "parlant", pt = "falando", ru = "говорящий", de = "sprechend", pl = "mówiący", hu = "beszélő", sk = "hovoriaci" },
    ["wait"] = { lemma = "wait", es = "esperar", fr = "attendre", pt = "esperar", ru = "ждать", de = "warten", pl = "czekać", hu = "vár", sk = "čakať" },
    ["waiting"] = { lemma = "wait", es = "esperando", fr = "attendant", pt = "esperando", ru = "ждущий", de = "wartend", pl = "czekający", hu = "váró", sk = "čakajúci" },
    ["play"] = { lemma = "play", es = "jugar", fr = "jouer", pt = "jogar", ru = "играть", de = "spielen", pl = "grać", hu = "játszik", sk = "hrať" },
    ["playing"] = { lemma = "play", es = "jugando", fr = "jouant", pt = "jogando", ru = "играющий", de = "spielend", pl = "grający", hu = "játszó", sk = "hrajúci" },
    ["meet"] = { lemma = "meet", es = "encontrar", fr = "rencontrer", pt = "encontrar", ru = "встречать", de = "treffen", pl = "spotkać", hu = "találkozik", sk = "stretnúť" },
    ["start"] = { lemma = "start", es = "empezar", fr = "commencer", pt = "começar", ru = "начать", de = "beginnen", pl = "zacząć", hu = "kezd", sk = "začať" },
    ["stop"] = { lemma = "stop", es = "parar", fr = "arrêter", pt = "parar", ru = "остановить", de = "stoppen", pl = "zatrzymać", hu = "megáll", sk = "zastaviť" },
    ["move"] = { lemma = "move", es = "mover", fr = "bouger", pt = "mover", ru = "двигаться", de = "bewegen", pl = "ruszać", hu = "mozog", sk = "pohybovať" },
    ["like"] = { lemma = "like", es = "gustar", fr = "aimer", pt = "gostar", ru = "нравиться", de = "mögen", pl = "lubić", hu = "szeret", sk = "mať rád" },
    ["live"] = { lemma = "live", es = "vivir", fr = "vivre", pt = "viver", ru = "жить", de = "leben", pl = "żyć", hu = "él", sk = "žiť" },
    ["believe"] = { lemma = "believe", es = "creer", fr = "croire", pt = "acreditar", ru = "верить", de = "glauben", pl = "wierzyć", hu = "hinni", sk = "veriť" },
    ["heals"] = { lemma = "heal", es = "sana", fr = "soigne", pt = "cura", ru = "лечит", de = "heilt", pl = "leczy", hu = "gyógyít", sk = "lieči" },
["needs"] = { lemma = "need", es = "necesita", fr = "a besoin", pt = "precisa", ru = "нуждается", de = "braucht", pl = "potrzebuje", hu = "szüksége van", sk = "potrebuje" },
["makes"] = { lemma = "make", es = "hace", fr = "fait", pt = "faz", ru = "делает", de = "macht", pl = "robi", hu = "készít", sk = "robí" },
["goes"] = { lemma = "go", es = "va", fr = "va", pt = "vai", ru = "идёт", de = "geht", pl = "idzie", hu = "megy", sk = "ide" },
["knows"] = { lemma = "know", es = "sabe", fr = "sait", pt = "sabe", ru = "знает", de = "weiß", pl = "wie", hu = "tud", sk = "vie" },
["thinks"] = { lemma = "think", es = "piensa", fr = "pense", pt = "pensa", ru = "думает", de = "denkt", pl = "myśli", hu = "gondol", sk = "myslí" },
["takes"] = { lemma = "take", es = "toma", fr = "prend", pt = "toma", ru = "берёт", de = "nimmt", pl = "bierze", hu = "vesz", sk = "berie" },
["sees"] = { lemma = "see", es = "ve", fr = "voit", pt = "vê", ru = "видит", de = "sieht", pl = "widzi", hu = "lát", sk = "vidí" },
["comes"] = { lemma = "come", es = "viene", fr = "vient", pt = "vem", ru = "приходит", de = "kommt", pl = "przychodzi", hu = "jön", sk = "príde" },
["wants"] = { lemma = "want", es = "quiere", fr = "veut", pt = "quer", ru = "хочет", de = "will", pl = "chce", hu = "akar", sk = "chce" },
["looks"] = { lemma = "look", es = "mira", fr = "regarde", pt = "olha", ru = "смотрит", de = "schaut", pl = "patrzy", hu = "néz", sk = "pozerá" },
["uses"] = { lemma = "use", es = "usa", fr = "utilise", pt = "usa", ru = "использует", de = "benutzt", pl = "używa", hu = "használ", sk = "používa" },
["finds"] = { lemma = "find", es = "encuentra", fr = "trouve", pt = "encontra", ru = "находит", de = "findet", pl = "znajduje", hu = "talál", sk = "nájde" },
["gives"] = { lemma = "give", es = "da", fr = "donne", pt = "dá", ru = "даёт", de = "gibt", pl = "daje", hu = "ad", sk = "dá" },
["tells"] = { lemma = "tell", es = "dice", fr = "dit", pt = "diz", ru = "рассказывает", de = "erzählt", pl = "mówi", hu = "mond", sk = "povie" },
["works"] = { lemma = "work", es = "trabaja", fr = "travaille", pt = "trabalha", ru = "работает", de = "arbeitet", pl = "pracuje", hu = "dolgozik", sk = "pracuje" },
["calls"] = { lemma = "call", es = "llama", fr = "appelle", pt = "chama", ru = "звонит", de = "ruft an", pl = "dzwoni", hu = "hív", sk = "volá" },
["tries"] = { lemma = "try", es = "intenta", fr = "essaie", pt = "tenta", ru = "пытается", de = "versucht", pl = "próbuje", hu = "próbál", sk = "skúša" },
["asks"] = { lemma = "ask", es = "pregunta", fr = "demande", pt = "pergunta", ru = "спрашивает", de = "fragt", pl = "pyta", hu = "kérdez", sk = "pýta" },
["feels"] = { lemma = "feel", es = "siente", fr = "ressent", pt = "sente", ru = "чувствует", de = "fühlt", pl = "czuje", hu = "érez", sk = "cíti" },
["becomes"] = { lemma = "become", es = "se convierte", fr = "devient", pt = "se torna", ru = "становится", de = "wird", pl = "staje się", hu = "válik", sk = "stane sa" },
["leaves"] = { lemma = "leave", es = "sale", fr = "part", pt = "sai", ru = "уходит", de = "verlässt", pl = "wychodzi", hu = "elmegy", sk = "odíde" },
["puts"] = { lemma = "put", es = "pone", fr = "met", pt = "coloca", ru = "кладёт", de = "legt", pl = "kładzie", hu = "tesz", sk = "položí" },
["means"] = { lemma = "mean", es = "significa", fr = "signifie", pt = "significa", ru = "означает", de = "bedeutet", pl = "znaczy", hu = "jelent", sk = "znamená" },
["keeps"] = { lemma = "keep", es = "mantiene", fr = "garde", pt = "mantém", ru = "держит", de = "behält", pl = "trzyma", hu = "tart", sk = "drží" },
["lets"] = { lemma = "let", es = "deja", fr = "laisse", pt = "deixa", ru = "позволяет", de = "lässt", pl = "pozwala", hu = "enged", sk = "nechá" },
["runs"] = { lemma = "run", es = "corre", fr = "court", pt = "corre", ru = "бежит", de = "läuft", pl = "biegnie", hu = "fut", sk = "beží" },
["talks"] = { lemma = "talk", es = "habla", fr = "parle", pt = "fala", ru = "говорит", de = "spricht", pl = "mówi", hu = "beszél", sk = "hovorí" },
["waits"] = { lemma = "wait", es = "espera", fr = "attend", pt = "espera", ru = "ждёт", de = "wartet", pl = "czeka", hu = "vár", sk = "čaká" },
["plays"] = { lemma = "play", es = "juega", fr = "joue", pt = "joga", ru = "играет", de = "spielt", pl = "gra", hu = "játszik", sk = "hrá" },
["meets"] = { lemma = "meet", es = "encuentra", fr = "rencontre", pt = "encontra", ru = "встречает", de = "trifft", pl = "spotyka", hu = "találkozik", sk = "stretne" },
["starts"] = { lemma = "start", es = "empieza", fr = "commence", pt = "começa", ru = "начинает", de = "beginnt", pl = "zaczyna", hu = "kezd", sk = "začne" },
["stops"] = { lemma = "stop", es = "para", fr = "arrête", pt = "para", ru = "останавливает", de = "stoppt", pl = "zatrzymuje", hu = "megáll", sk = "zastaví" },
["moves"] = { lemma = "move", es = "mueve", fr = "bouge", pt = "move", ru = "двигается", de = "bewegt", pl = "rusza", hu = "mozog", sk = "pohybuje" },
["likes"] = { lemma = "like", es = "gusta", fr = "aime", pt = "gosta", ru = "нравится", de = "mag", pl = "lubi", hu = "szeret", sk = "má rád" },
["lives"] = { lemma = "live", es = "vive", fr = "vit", pt = "mora", ru = "живёт", de = "lebt", pl = "żyje", hu = "él", sk = "žije" },
["believes"] = { lemma = "believe", es = "cree", fr = "croit", pt = "acredita", ru = "верит", de = "glaubt", pl = "wierzy", hu = "hisz", sk = "verí" },
["brings"] = { lemma = "bring", es = "trae", fr = "apporte", pt = "traz", ru = "приносит", de = "bringt", pl = "przynosi", hu = "hoz", sk = "prinesie" },
["writes"] = { lemma = "write", es = "escribe", fr = "écrit", pt = "escreve", ru = "пишет", de = "schreibt", pl = "pisze", hu = "ír", sk = "píše" },
["sits"] = { lemma = "sit", es = "se sienta", fr = "s'assoit", pt = "senta", ru = "сидит", de = "sitzt", pl = "siedzi", hu = "ül", sk = "sedí" },
["stands"] = { lemma = "stand", es = "está de pie", fr = "se tient", pt = "fica de pé", ru = "стоит", de = "steht", pl = "stoi", hu = "áll", sk = "stojí" },
["loses"] = { lemma = "lose", es = "pierde", fr = "perd", pt = "perde", ru = "теряет", de = "verliert", pl = "przegrywa", hu = "veszít", sk = "stratí" },
["pays"] = { lemma = "pay", es = "paga", fr = "paie", pt = "paga", ru = "платит", de = "zahlt", pl = "płaci", hu = "fizet", sk = "platí" },
["buys"] = { lemma = "buy", es = "compra", fr = "achète", pt = "compra", ru = "покупает", de = "kauft", pl = "kupuje", hu = "vásárol", sk = "kúpi" },
["sells"] = { lemma = "sell", es = "vende", fr = "vend", pt = "vende", ru = "продаёт", de = "verkauft", pl = "sprzedaje", hu = "elad", sk = "predá" },
["walks"] = { lemma = "walk", es = "camina", fr = "marche", pt = "caminha", ru = "идёт", de = "geht", pl = "chodzi", hu = "sétál", sk = "chodí" },
["reads"] = { lemma = "read", es = "lee", fr = "lit", pt = "lê", ru = "читает", de = "liest", pl = "czyta", hu = "olvas", sk = "číta" },
["sends"] = { lemma = "send", es = "envía", fr = "envoie", pt = "envia", ru = "отправляет", de = "sendet", pl = "wysyła", hu = "küld", sk = "posiela" },
["builds"] = { lemma = "build", es = "construye", fr = "construit", pt = "constrói", ru = "строит", de = "baut", pl = "buduje", hu = "épít", sk = "stavia" },
["stays"] = { lemma = "stay", es = "se queda", fr = "reste", pt = "fica", ru = "остаётся", de = "bleibt", pl = "zostaje", hu = "marad", sk = "zostáva" },
["falls"] = { lemma = "fall", es = "cae", fr = "tombe", pt = "cai", ru = "падает", de = "fällt", pl = "upada", hu = "esik", sk = "padne" },
["changes"] = { lemma = "change", es = "cambia", fr = "change", pt = "muda", ru = "меняет", de = "ändert", pl = "zmienia", hu = "változik", sk = "mení" },
["opens"] = { lemma = "open", es = "abre", fr = "ouvre", pt = "abre", ru = "открывает", de = "öffnet", pl = "otwiera", hu = "nyit", sk = "otvorí" },
["closes"] = { lemma = "close", es = "cierra", fr = "ferme", pt = "fecha", ru = "закрывает", de = "schließt", pl = "zamyka", hu = "bezár", sk = "zavrie" },
["watches"] = { lemma = "watch", es = "mira", fr = "regarde", pt = "assiste", ru = "смотрит", de = "schaut", pl = "ogląda", hu = "néz", sk = "pozerá" },
["follows"] = { lemma = "follow", es = "sigue", fr = "suit", pt = "segue", ru = "следует", de = "folgt", pl = "podąża", hu = "követ", sk = "nasleduje" },
["begins"] = { lemma = "begin", es = "comienza", fr = "commence", pt = "começa", ru = "начинает", de = "anfängt", pl = "zaczyna", hu = "kezd", sk = "začne" },
["ends"] = { lemma = "end", es = "termina", fr = "termine", pt = "termina", ru = "заканчивает", de = "endet", pl = "kończy", hu = "befejez", sk = "skončí" },
["finishes"] = { lemma = "finish", es = "termina", fr = "finit", pt = "termina", ru = "заканчивает", de = "beendet", pl = "kończy", hu = "befejez", sk = "dokončí" },
["joins"] = { lemma = "join", es = "se une", fr = "rejoint", pt = "se junta", ru = "присоединяется", de = "tritt bei", pl = "dołącza", hu = "csatlakozik", sk = "pridá sa" },
["breaks"] = { lemma = "break", es = "rompe", fr = "casse", pt = "quebra", ru = "ломает", de = "bricht", pl = "łamie", hu = "tör", sk = "zlomí" },
["checks"] = { lemma = "check", es = "verifica", fr = "vérifie", pt = "verifica", ru = "проверяет", de = "prüft", pl = "sprawdza", hu = "ellenőriz", sk = "skontroluje" },
["fights"] = { lemma = "fight", es = "lucha", fr = "se bat", pt = "luta", ru = "сражается", de = "kämpft", pl = "walczy", hu = "harcol", sk = "bojuje" },
["defends"] = { lemma = "defend", es = "defiende", fr = "défend", pt = "defende", ru = "защищает", de = "verteidigt", pl = "broni", hu = "véd", sk = "bráni" },
["attacks"] = { lemma = "attack", es = "ataca", fr = "attaque", pt = "ataca", ru = "атакует", de = "greift an", pl = "atakuje", hu = "támad", sk = "útočí" },
["casts"] = { lemma = "cast", es = "lanza", fr = "lance", pt = "lança", ru = "кастует", de = "zaubert", pl = "rzuca", hu = "varázsol", sk = "vrhá" },
["summons"] = { lemma = "summon", es = "invoca", fr = "invoque", pt = "invoca", ru = "призывает", de = "beschwört", pl = "przywołuje", hu = "idéz", sk = "privoláva" },
["loots"] = { lemma = "loot", es = "saquea", fr = "pille", pt = "saqueia", ru = "лутает", de = "plündert", pl = "łupi", hu = "zsákmányol", sk = "vyplieni" },
["equips"] = { lemma = "equip", es = "equipa", fr = "équipe", pt = "equipa", ru = "экипирует", de = "rüstet aus", pl = "wyposaża", hu = "felszerel", sk = "vybaví" },
["trades"] = { lemma = "trade", es = "comercia", fr = "échange", pt = "troca", ru = "торгует", de = "handelt", pl = "handluje", hu = "kereskedik", sk = "obchoduje" },
["invites"] = { lemma = "invite", es = "invita", fr = "invite", pt = "convida", ru = "приглашает", de = "lädt ein", pl = "zaprasza", hu = "meghív", sk = "pozýva" },
["kicks"] = { lemma = "kick", es = "patea", fr = "expulse", pt = "expulsa", ru = "кикает", de = "rausschmeißt", pl = "wyrzuca", hu = "kirúg", sk = "vyhodí" },
["wins"] = { lemma = "win", es = "gana", fr = "gagne", pt = "ganha", ru = "побеждает", de = "gewinnt", pl = "wygrywa", hu = "győz", sk = "vyhrá" },
["dies"] = { lemma = "die", es = "muere", fr = "meurt", pt = "morre", ru = "умирает", de = "stirbt", pl = "umiera", hu = "meghal", sk = "zomrie" },
["kills"] = { lemma = "kill", es = "mata", fr = "tue", pt = "mata", ru = "убивает", de = "tötet", pl = "zabija", hu = "megöl", sk = "zabije" },
["revives"] = { lemma = "revive", es = "revive", fr = "ressuscite", pt = "revive", ru = "оживляет", de = "wiederbelebt", pl = "ożywia", hu = "feltámaszt", sk = "oživí" },
["escapes"] = { lemma = "escape", es = "escapa", fr = "s'échappe", pt = "escapa", ru = "сбегает", de = "entkommt", pl = "ucieka", hu = "megszökik", sk = "unikne" },
["hides"] = { lemma = "hide", es = "se esconde", fr = "se cache", pt = "se esconde", ru = "прячется", de = "versteckt sich", pl = "ukrywa się", hu = "elbújik", sk = "schová sa" },
["searches"] = { lemma = "search", es = "busca", fr = "cherche", pt = "procura", ru = "ищет", de = "sucht", pl = "szuka", hu = "keres", sk = "hľadá" },
["explores"] = { lemma = "explore", es = "explora", fr = "explore", pt = "explora", ru = "исследует", de = "erforscht", pl = "bada", hu = "felfedez", sk = "preskúmava" },
["crafts"] = { lemma = "craft", es = "fabrica", fr = "fabrique", pt = "fabrica", ru = "крафтит", de = "stellt her", pl = "wytwarza", hu = "kézműveskedik", sk = "vyrába" },
["gathers"] = { lemma = "gather", es = "recoge", fr = "ramasse", pt = "coletar", ru = "собирает", de = "sammelt", pl = "zbiera", hu = "gyűjt", sk = "zbiera" },
["mines"] = { lemma = "mine", es = "mina", fr = "mine", pt = "minera", ru = "добывает", de = "abbaut", pl = "wydobywa", hu = "bányászik", sk = "ťaží" },
["fishes"] = { lemma = "fish", es = "pesca", fr = "pêche", pt = "pesca", ru = "ловит рыбу", de = "angelt", pl = "łowi ryby", hu = "halászik", sk = "loví ryby" },
["cooks"] = { lemma = "cook", es = "cocina", fr = "cuisine", pt = "cozinha", ru = "готовит", de = "kocht", pl = "gotuje", hu = "főz", sk = "varí" },
["enchants"] = { lemma = "enchant", es = "encanta", fr = "enchante", pt = "encanta", ru = "зачаровывает", de = "verzaubert", pl = "oczarowuje", hu = "elbűvöl", sk = "očarúva" },
["disenchants"] = { lemma = "disenchant", es = "desencanta", fr = "désenchante", pt = "desencanta", ru = "распыляет", de = "entzaubert", pl = "odczarowuje", hu = "elbűvöl", sk = "odčarúva" },
["repairs"] = { lemma = "repair", es = "repara", fr = "répare", pt = "repara", ru = "чинит", de = "repariert", pl = "naprawia", hu = "javít", sk = "opravuje" },
["upgrades"] = { lemma = "upgrade", es = "mejora", fr = "améliore", pt = "melhora", ru = "улучшает", de = "verbessert", pl = "ulepsza", hu = "fejleszt", sk = "vylepší" },
["resurrects"] = { lemma = "resurrect", es = "resucita", fr = "ressuscite", pt = "ressuscita", ru = "воскрешает", de = "wiederbelebt", pl = "wskrzesi", hu = "feltámaszt", sk = "vzkriesi" },
	["bring"] = { lemma = "bring", es = "traer", fr = "apporter", pt = "trazer", ru = "принести", de = "bringen", pl = "przynieść", hu = "hoz", sk = "priniesť" },
    ["happen"] = { lemma = "happen", es = "ocurrir", fr = "arriver", pt = "acontecer", ru = "случаться", de = "passieren", pl = "zdarzyć się", hu = "történik", sk = "stať sa" },
    ["write"] = { lemma = "write", es = "escribir", fr = "écrire", pt = "escrever", ru = "писать", de = "schreiben", pl = "pisać", hu = "ír", sk = "písať" },
    ["sit"] = { lemma = "sit", es = "sentarse", fr = "s'asseoir", pt = "sentar", ru = "сидеть", de = "sitzen", pl = "siedzieć", hu = "ül", sk = "sedieť" },
    ["stand"] = { lemma = "stand", es = "estar de pie", fr = "se tenir", pt = "ficar de pé", ru = "стоять", de = "stehen", pl = "stać", hu = "áll", sk = "stáť" },
    ["lose"] = { lemma = "lose", es = "perder", fr = "perdre", pt = "perder", ru = "терять", de = "verlieren", pl = "przegrać", hu = "veszít", sk = "stratiť" },
    ["pay"] = { lemma = "pay", es = "pagar", fr = "payer", pt = "pagar", ru = "платить", de = "zahlen", pl = "płacić", hu = "fizet", sk = "platiť" },
    ["buy"] = { lemma = "buy", es = "comprar", fr = "acheter", pt = "comprar", ru = "покупать", de = "kaufen", pl = "kupić", hu = "vásárol", sk = "kúpiť" },
    ["sell"] = { lemma = "sell", es = "vender", fr = "vendre", pt = "vender", ru = "продавать", de = "verkaufen", pl = "sprzedać", hu = "elad", sk = "predať" },
    ["walk"] = { lemma = "walk", es = "caminar", fr = "marcher", pt = "caminhar", ru = "идти", de = "gehen", pl = "chodzić", hu = "sétál", sk = "chodiť" },
    ["read"] = { lemma = "read", es = "leer", fr = "lire", pt = "ler", ru = "читать", de = "lesen", pl = "czytać", hu = "olvas", sk = "čítať" },
    ["send"] = { lemma = "send", es = "enviar", fr = "envoyer", pt = "enviar", ru = "отправлять", de = "senden", pl = "wysłać", hu = "küld", sk = "poslať" },
    ["build"] = { lemma = "build", es = "construir", fr = "construire", pt = "construir", ru = "строить", de = "bauen", pl = "budować", hu = "épít", sk = "stavať" },
    ["stay"] = { lemma = "stay", es = "quedarse", fr = "rester", pt = "ficar", ru = "оставаться", de = "bleiben", pl = "zostać", hu = "marad", sk = "zostať" },
    ["fall"] = { lemma = "fall", es = "caer", fr = "tomber", pt = "cair", ru = "падать", de = "fallen", pl = "upaść", hu = "esik", sk = "padnúť" },
    ["change"] = { lemma = "change", es = "cambiar", fr = "changer", pt = "mudar", ru = "менять", de = "ändern", pl = "zmienić", hu = "változik", sk = "zmeniť" },
    ["open"] = { lemma = "open", es = "abrir", fr = "ouvrir", pt = "abrir", ru = "открывать", de = "öffnen", pl = "otworzyć", hu = "nyit", sk = "otvoriť" },
    ["close"] = { lemma = "close", es = "cerrar", fr = "fermer", pt = "fechar", ru = "закрывать", de = "schließen", pl = "zamknąć", hu = "bezár", sk = "zavrieť" },
    ["watch"] = { lemma = "watch", es = "mirar", fr = "regarder", pt = "assistir", ru = "смотреть", de = "schauen", pl = "oglądać", hu = "néz", sk = "pozerať" },
    ["follow"] = { lemma = "follow", es = "seguir", fr = "suivre", pt = "seguir", ru = "следовать", de = "folgen", pl = "podążać", hu = "követ", sk = "nasledovať" },
    ["begin"] = { lemma = "begin", es = "comenzar", fr = "commencer", pt = "começar", ru = "начинать", de = "anfangen", pl = "zacząć", hu = "kezd", sk = "začať" },
    ["end"] = { lemma = "end", es = "terminar", fr = "terminer", pt = "terminar", ru = "заканчивать", de = "enden", pl = "zakończyć", hu = "befejez", sk = "skončiť" },
    ["finish"] = { lemma = "finish", es = "terminar", fr = "finir", pt = "terminar", ru = "заканчивать", de = "beenden", pl = "zakończyć", hu = "befejez", sk = "dokončiť" },
    ["join"] = { lemma = "join", es = "unirse", fr = "joindre", pt = "juntar-se", ru = "присоединяться", de = "beitreten", pl = "dołączyć", hu = "csatlakozik", sk = "pridať sa" },
    ["break"] = { lemma = "break", es = "romper", fr = "casser", pt = "quebrar", ru = "ломать", de = "brechen", pl = "złamać", hu = "tör", sk = "zlomiť" },
    ["check"] = { lemma = "check", es = "verificar", fr = "vérifier", pt = "verificar", ru = "проверять", de = "prüfen", pl = "sprawdzić", hu = "ellenőriz", sk = "skontrolovať" },
    -- Pronouns
    ["I"] = { lemma = "I", es = "yo", fr = "je", pt = "eu", ru = "я", de = "ich", pl = "ja", hu = "én", sk = "ja" },
    ["you"] = { lemma = "you", es = "tú", fr = "tu", pt = "você", ru = "ты", de = "du", pl = "ty", hu = "te", sk = "ty" },
    ["he"] = { lemma = "he", es = "él", fr = "il", pt = "ele", ru = "он", de = "er", pl = "on", hu = "ő", sk = "on" },
    ["she"] = { lemma = "she", es = "ella", fr = "elle", pt = "ela", ru = "она", de = "sie", pl = "ona", hu = "ő", sk = "ona" },
    ["it"] = { lemma = "it", es = "ello", fr = "il", pt = "ele", ru = "оно", de = "es", pl = "ono", hu = "ez", sk = "to" },
    ["we"] = { lemma = "we", es = "nosotros", fr = "nous", pt = "nós", ru = "мы", de = "wir", pl = "my", hu = "mi", sk = "my" },
    ["they"] = { lemma = "they", es = "ellos", fr = "ils", pt = "eles", ru = "они", de = "sie", pl = "oni", hu = "ők", sk = "oni" },
    ["me"] = { lemma = "I", es = "mí", fr = "moi", pt = "mim", ru = "меня", de = "mich", pl = "mnie", hu = "engem", sk = "mňa" },
    ["him"] = { lemma = "he", es = "él", fr = "lui", pt = "ele", ru = "его", de = "ihn", pl = "jego", hu = "őt", sk = "ho" },
    ["her"] = { lemma = "she", es = "ella", fr = "elle", pt = "ela", ru = "её", de = "sie", pl = "ją", hu = "őt", sk = "ju" },
    ["us"] = { lemma = "we", es = "nosotros", fr = "nous", pt = "nós", ru = "нас", de = "uns", pl = "nas", hu = "minket", sk = "nás" },
    ["them"] = { lemma = "they", es = "ellos", fr = "eux", pt = "eles", ru = "их", de = "sie", pl = "ich", hu = "őket", sk = "ich" },
    ["my"] = { lemma = "I", es = "mi", fr = "mon", pt = "meu", ru = "мой", de = "mein", pl = "mój", hu = "enyém", sk = "môj" },
    ["your"] = { lemma = "you", es = "tu", fr = "ton", pt = "teu", ru = "твой", de = "dein", pl = "twój", hu = "tiéd", sk = "tvoj" },
    ["his"] = { lemma = "he", es = "su", fr = "son", pt = "seu", ru = "его", de = "sein", pl = "jego", hu = "övé", sk = "jeho" },
    ["our"] = { lemma = "we", es = "nuestro", fr = "notre", pt = "nosso", ru = "наш", de = "unser", pl = "nasz", hu = "miénk", sk = "náš" },
    ["their"] = { lemma = "they", es = "su", fr = "leur", pt = "seu", ru = "их", de = "ihr", pl = "ich", hu = "övék", sk = "ich" },
    -- Articles
    ["a"] = { lemma = "a", es = "un", fr = "un", pt = "um", ru = "один", de = "ein", pl = "jeden", hu = "egy", sk = "jeden" },
    ["an"] = { lemma = "a", es = "un", fr = "un", pt = "um", ru = "один", de = "ein", pl = "jeden", hu = "egy", sk = "jeden" },
    ["the"] = { lemma = "the", es = "el", fr = "le", pt = "o", ru = "этот", de = "der", pl = "ten", hu = "a", sk = "ten" },
    -- Prepositions
    ["in"] = { lemma = "in", es = "en", fr = "dans", pt = "em", ru = "в", de = "in", pl = "w", hu = "ban", sk = "v" },
    ["on"] = { lemma = "on", es = "en", fr = "sur", pt = "em", ru = "на", de = "auf", pl = "na", hu = "on", sk = "na" },
    ["at"] = { lemma = "at", es = "en", fr = "à", pt = "em", ru = "на", de = "an", pl = "przy", hu = "nál", sk = "pri" },
    ["to"] = { lemma = "to", es = "a", fr = "à", pt = "para", ru = "к", de = "zu", pl = "do", hu = "hoz", sk = "do" },
    ["for"] = { lemma = "for", es = "para", fr = "pour", pt = "para", ru = "для", de = "für", pl = "dla", hu = "ért", sk = "pre" },
    ["with"] = { lemma = "with", es = "con", fr = "avec", pt = "com", ru = "с", de = "mit", pl = "z", hu = "val", sk = "s" },
    ["by"] = { lemma = "by", es = "por", fr = "par", pt = "por", ru = "по", de = "durch", pl = "przez", hu = "által", sk = "od" },
    ["of"] = { lemma = "of", es = "de", fr = "de", pt = "de", ru = "из", de = "von", pl = "z", hu = "ból", sk = "z" },
    ["from"] = { lemma = "from", es = "de", fr = "de", pt = "de", ru = "от", de = "von", pl = "od", hu = "tól", sk = "od" },
    ["up"] = { lemma = "up", es = "arriba", fr = "en haut", pt = "acima", ru = "вверх", de = "auf", pl = "w górę", hu = "fel", sk = "hore" },
    ["down"] = { lemma = "down", es = "abajo", fr = "en bas", pt = "abaixo", ru = "вниз", de = "ab", pl = "w dół", hu = "le", sk = "dole" },
    ["over"] = { lemma = "over", es = "sobre", fr = "au-dessus", pt = "sobre", ru = "над", de = "über", pl = "nad", hu = "fölött", sk = "nad" },
    ["under"] = { lemma = "under", es = "debajo", fr = "sous", pt = "sob", ru = "под", de = "unter", pl = "pod", hu = "alatt", sk = "pod" },
    ["between"] = { lemma = "between", es = "entre", fr = "entre", pt = "entre", ru = "между", de = "zwischen", pl = "między", hu = "között", sk = "medzi" },
    ["through"] = { lemma = "through", es = "a través", fr = "à travers", pt = "através", ru = "через", de = "durch", pl = "przez", hu = "keresztül", sk = "cez" },
    ["into"] = { lemma = "into", es = "en", fr = "dans", pt = "em", ru = "в", de = "in", pl = "do", hu = "bele", sk = "do" },
    ["out"] = { lemma = "out", es = "fuera", fr = "dehors", pt = "fora", ru = "из", de = "aus", pl = "z", hu = "ki", sk = "von" },
    ["off"] = { lemma = "off", es = "apagado", fr = "éteint", pt = "desligado", ru = "выключено", de = "aus", pl = "wyłączony", hu = "ki", sk = "vypnutý" },
    ["about"] = { lemma = "about", es = "sobre", fr = "sur", pt = "sobre", ru = "о", de = "über", pl = "o", hu = "körül", sk = "o" },
    -- Conjunctions
    ["and"] = { lemma = "and", es = "y", fr = "et", pt = "e", ru = "и", de = "und", pl = "i", hu = "és", sk = "a" },
    ["but"] = { lemma = "but", es = "pero", fr = "mais", pt = "mas", ru = "но", de = "aber", pl = "ale", hu = "de", sk = "ale" },
    ["or"] = { lemma = "or", es = "o", fr = "ou", pt = "ou", ru = "или", de = "oder", pl = "lub", hu = "vagy", sk = "alebo" },
    -- Conditionals and Adverbs
    ["if"] = { lemma = "if", es = "si", fr = "si", pt = "se", ru = "если", de = "wenn", pl = "jeśli", hu = "ha", sk = "ak" },
    ["when"] = { lemma = "when", es = "cuando", fr = "quand", pt = "quando", ru = "когда", de = "wann", pl = "kiedy", hu = "mikor", sk = "kedy" },
    ["because"] = { lemma = "because", es = "porque", fr = "parce que", pt = "porque", ru = "потому что", de = "weil", pl = "ponieważ", hu = "mert", sk = "pretože" },
    ["since"] = { lemma = "since", es = "desde", fr = "depuis", pt = "desde", ru = "с", de = "seit", pl = "od", hu = "óta", sk = "od" },
    ["while"] = { lemma = "while", es = "mientras", fr = "pendant", pt = "enquanto", ru = "пока", de = "während", pl = "podczas", hu = "míg", sk = "kým" },
    ["although"] = { lemma = "although", es = "aunque", fr = "bien que", pt = "embora", ru = "хотя", de = "obwohl", pl = "chociaż", hu = "bár", sk = "hoci" },
    ["now"] = { lemma = "now", es = "ahora", fr = "maintenant", pt = "agora", ru = "сейчас", de = "jetzt", pl = "teraz", hu = "most", sk = "teraz" },
    ["then"] = { lemma = "then", es = "entonces", fr = "alors", pt = "então", ru = "тогда", de = "dann", pl = "wtedy", hu = "akkor", sk = "potom" },
    ["here"] = { lemma = "here", es = "aquí", fr = "ici", pt = "aqui", ru = "здесь", de = "hier", pl = "tu", hu = "itt", sk = "tu" },
    ["there"] = { lemma = "there", es = "allí", fr = "là", pt = "lá", ru = "там", de = "dort", pl = "tam", hu = "ott", sk = "tam" },
    ["very"] = { lemma = "very", es = "muy", fr = "très", pt = "muito", ru = "очень", de = "sehr", pl = "bardzo", hu = "nagyon", sk = "veľmi" },
    ["really"] = { lemma = "really", es = "realmente", fr = "vraiment", pt = "realmente", ru = "действительно", de = "wirklich", pl = "naprawdę", hu = "tényleg", sk = "skutočne" },
    ["just"] = { lemma = "just", es = "sólo", fr = "juste", pt = "apenas", ru = "просто", de = "nur", pl = "tylko", hu = "csak", sk = "len" },
    ["still"] = { lemma = "still", es = "todavía", fr = "encore", pt = "ainda", ru = "ещё", de = "noch", pl = "jeszcze", hu = "még", sk = "ešte" },
    ["always"] = { lemma = "always", es = "siempre", fr = "toujours", pt = "sempre", ru = "всегда", de = "immer", pl = "zawsze", hu = "mindig", sk = "vždy" },
    ["never"] = { lemma = "never", es = "nunca", fr = "jamais", pt = "nunca", ru = "никогда", de = "nie", pl = "nigdy", hu = "soha", sk = "nikdy" },
    -- Adjectives
    ["good"] = { lemma = "good", es = "bueno", fr = "bon", pt = "bom", ru = "хороший", de = "gut", pl = "dobry", hu = "jó", sk = "dobrý" },
    ["bad"] = { lemma = "bad", es = "malo", fr = "mauvais", pt = "mau", ru = "плохой", de = "schlecht", pl = "zły", hu = "rossz", sk = "zlý" },
    ["new"] = { lemma = "new", es = "nuevo", fr = "nouveau", pt = "novo", ru = "новый", de = "neu", pl = "nowy", hu = "új", sk = "nový" },
    ["old"] = { lemma = "old", es = "viejo", fr = "vieux", pt = "velho", ru = "старый", de = "alt", pl = "stary", hu = "régi", sk = "starý" },
    ["big"] = { lemma = "big", es = "grande", fr = "grand", pt = "grande", ru = "большой", de = "groß", pl = "duży", hu = "nagy", sk = "veľký" },
    ["small"] = { lemma = "small", es = "pequeño", fr = "petit", pt = "pequeno", ru = "маленький", de = "klein", pl = "mały", hu = "kicsi", sk = "malý" },
    ["fast"] = { lemma = "fast", es = "rápido", fr = "rapide", pt = "rápido", ru = "быстрый", de = "schnell", pl = "szybki", hu = "gyors", sk = "rýchly" },
    ["slow"] = { lemma = "slow", es = "lento", fr = "lent", pt = "lento", ru = "медленный", de = "langsam", pl = "wolny", hu = "lassú", sk = "pomalý" },
    ["easy"] = { lemma = "easy", es = "fácil", fr = "facile", pt = "fácil", ru = "лёгкий", de = "einfach", pl = "łatwy", hu = "könnyű", sk = "ľahký" },
    ["hard"] = { lemma = "hard", es = "difícil", fr = "difficile", pt = "difícil", ru = "трудный", de = "schwer", pl = "trudny", hu = "nehéz", sk = "ťažký" },
    -- Nouns
    ["time"] = { lemma = "time", es = "tiempo", fr = "temps", pt = "tempo", ru = "время", de = "Zeit", pl = "czas", hu = "idő", sk = "čas" },
    ["place"] = { lemma = "place", es = "lugar", fr = "lieu", pt = "lugar", ru = "место", de = "Ort", pl = "miejsce", hu = "hely", sk = "miesto" },
    ["way"] = { lemma = "way", es = "camino", fr = "chemin", pt = "caminho", ru = "путь", de = "Weg", pl = "droga", hu = "út", sk = "cesta" },
    ["thing"] = { lemma = "thing", es = "cosa", fr = "chose", pt = "coisa", ru = "вещь", de = "Ding", pl = "rzecz", hu = "dolog", sk = "vec" },
    ["day"] = { lemma = "day", es = "día", fr = "jour", pt = "dia", ru = "день", de = "Tag", pl = "dzień", hu = "nap", sk = "deň" },
    ["night"] = { lemma = "night", es = "noche", fr = "nuit", pt = "noite", ru = "ночь", de = "Nacht", pl = "noc", hu = "éjszaka", sk = "noc" },
    ["people"] = { lemma = "people", es = "gente", fr = "gens", pt = "pessoas", ru = "люди", de = "Leute", pl = "ludzie", hu = "emberek", sk = "ľudia" },
    ["problem"] = { lemma = "problem", es = "problema", fr = "problème", pt = "problema", ru = "проблема", de = "Problem", pl = "problem", hu = "probléma", sk = "problém" },
    ["question"] = { lemma = "question", es = "pregunta", fr = "question", pt = "pergunta", ru = "вопрос", de = "Frage", pl = "pytanie", hu = "kérdés", sk = "otázka" },
    ["answer"] = { lemma = "answer", es = "respuesta", fr = "réponse", pt = "resposta", ru = "ответ", de = "Antwort", pl = "odpowiedź", hu = "válasz", sk = "odpoveď" },
    ["game"] = { lemma = "game", es = "juego", fr = "jeu", pt = "jogo", ru = "игра", de = "Spiel", pl = "gra", hu = "játék", sk = "hra" },
    ["world"] = { lemma = "world", es = "mundo", fr = "monde", pt = "mundo", ru = "мир", de = "Welt", pl = "świat", hu = "világ", sk = "svet" },
    ["life"] = { lemma = "life", es = "vida", fr = "vie", pt = "vida", ru = "жизнь", de = "Leben", pl = "życie", hu = "élet", sk = "život" },
    ["death"] = { lemma = "death", es = "muerte", fr = "mort", pt = "morte", ru = "смерть", de = "Tod", pl = "śmierć", hu = "halál", sk = "smrť" },
    ["home"] = { lemma = "home", es = "casa", fr = "maison", pt = "casa", ru = "дом", de = "Haus", pl = "dom", hu = "otthon", sk = "dom" },
    ["city"] = { lemma = "city", es = "ciudad", fr = "ville", pt = "cidade", ru = "город", de = "Stadt", pl = "miasto", hu = "város", sk = "mesto" },
    ["area"] = { lemma = "area", es = "área", fr = "zone", pt = "área", ru = "область", de = "Gebiet", pl = "obszar", hu = "terület", sk = "oblasť" },
    ["room"] = { lemma = "room", es = "habitación", fr = "chambre", pt = "quarto", ru = "комната", de = "Zimmer", pl = "pokój", hu = "szoba", sk = "izba" },
    ["water"] = { lemma = "water", es = "agua", fr = "eau", pt = "água", ru = "вода", de = "Wasser", pl = "woda", hu = "víz", sk = "voda" },
    ["food"] = { lemma = "food", es = "comida", fr = "nourriture", pt = "comida", ru = "еда", de = "Essen", pl = "jedzenie", hu = "étel", sk = "jedlo" },
    ["money"] = { lemma = "money", es = "dinero", fr = "argent", pt = "dinheiro", ru = "деньги", de = "Geld", pl = "pieniądze", hu = "pénz", sk = "peniaze" },
    ["friend"] = { lemma = "friend", es = "amigo", fr = "ami", pt = "amigo", ru = "друг", de = "Freund", pl = "przyjaciel", hu = "barát", sk = "priateľ" },
    ["enemy"] = { lemma = "enemy", es = "enemigo", fr = "ennemi", pt = "inimigo", ru = "враг", de = "Feind", pl = "wróg", hu = "ellenség", sk = "nepriateľ" },
    ["power"] = { lemma = "power", es = "poder", fr = "puissance", pt = "poder", ru = "сила", de = "Kraft", pl = "moc", hu = "erő", sk = "sila" },
    ["light"] = { lemma = "light", es = "luz", fr = "lumière", pt = "luz", ru = "свет", de = "Licht", pl = "światło", hu = "fény", sk = "svetlo" },
    ["dark"] = { lemma = "dark", es = "oscuro", fr = "sombre", pt = "escuro", ru = "тёмный", de = "dunkel", pl = "ciemny", hu = "sötét", sk = "tmavý" },
    ["fire"] = { lemma = "fire", es = "fuego", fr = "feu", pt = "fogo", ru = "огонь", de = "Feuer", pl = "ogień", hu = "tűz", sk = "oheň" },
    ["earth"] = { lemma = "earth", es = "tierra", fr = "terre", pt = "terra", ru = "земля", de = "Erde", pl = "ziemia", hu = "föld", sk = "zem" },
    ["air"] = { lemma = "air", es = "aire", fr = "air", pt = "ar", ru = "воздух", de = "Luft", pl = "powietrze", hu = "levegő", sk = "vzduch" },
    -- Time-Related Terms
    ["hour"] = { lemma = "hour", es = "hora", fr = "heure", pt = "hora", ru = "час", de = "Stunde", pl = "godzina", hu = "óra", sk = "hodina" },
    ["minute"] = { lemma = "minute", es = "minuto", fr = "minute", pt = "minuto", ru = "минута", de = "Minute", pl = "minuta", hu = "perc", sk = "minúta" },
    ["today"] = { lemma = "today", es = "hoy", fr = "aujourd'hui", pt = "hoje", ru = "сегодня", de = "heute", pl = "dzisiaj", hu = "ma", sk = "dnes" },
    ["tomorrow"] = { lemma = "tomorrow", es = "mañana", fr = "demain", pt = "amanhã", ru = "завтра", de = "morgen", pl = "jutro", hu = "holnap", sk = "zajtra" },
    ["yesterday"] = { lemma = "yesterday", es = "ayer", fr = "hier", pt = "ontem", ru = "вчера", de = "gestern", pl = "wczoraj", hu = "tegnap", sk = "včera" },
    ["week"] = { lemma = "week", es = "semana", fr = "semaine", pt = "semana", ru = "неделя", de = "Woche", pl = "tydzień", hu = "hét", sk = "týždeň" },
    ["month"] = { lemma = "month", es = "mes", fr = "mois", pt = "mês", ru = "месяц", de = "Monat", pl = "miesiąc", hu = "hónap", sk = "mesiac" },
    ["year"] = { lemma = "year", es = "año", fr = "an", pt = "ano", ru = "год", de = "Jahr", pl = "rok", hu = "év", sk = "rok" },
    ["morning"] = { lemma = "morning", es = "mañana", fr = "matin", pt = "manhã", ru = "утро", de = "Morgen", pl = "rano", hu = "reggel", sk = "ráno" },
    ["evening"] = { lemma = "evening", es = "tarde", fr = "soir", pt = "tarde", ru = "вечер", de = "Abend", pl = "wieczór", hu = "este", sk = "večer" },
    -- Quantifiers and Determiners
    ["this"] = { lemma = "this", es = "este", fr = "ce", pt = "este", ru = "этот", de = "dieser", pl = "ten", hu = "ez", sk = "tento" },
    ["that"] = { lemma = "that", es = "ese", fr = "cela", pt = "esse", ru = "тот", de = "jener", pl = "tamten", hu = "az", sk = "ten" },
    ["all"] = { lemma = "all", es = "todo", fr = "tout", pt = "tudo", ru = "всё", de = "alles", pl = "wszystko", hu = "minden", sk = "všetko" },
    ["some"] = { lemma = "some", es = "alguno", fr = "quelque", pt = "algum", ru = "некоторые", de = "einige", pl = "niektóre", hu = "néhány", sk = "niektoré" },
    ["any"] = { lemma = "any", es = "cualquier", fr = "n'importe quel", pt = "qualquer", ru = "любой", de = "irgendwelche", pl = "jakikolwiek", hu = "bármely", sk = "akýkoľvek" },
    ["no"] = { lemma = "no", es = "no", fr = "non", pt = "não", ru = "нет", de = "nein", pl = "nie", hu = "nem", sk = "nie" },
    ["yes"] = { lemma = "yes", es = "sí", fr = "oui", pt = "sim", ru = "да", de = "ja", pl = "tak", hu = "igen", sk = "áno" },
    ["one"] = { lemma = "one", es = "uno", fr = "un", pt = "um", ru = "один", de = "eins", pl = "jeden", hu = "egy", sk = "jeden" },
    ["two"] = { lemma = "two", es = "dos", fr = "deux", pt = "dois", ru = "два", de = "zwei", pl = "dwa", hu = "kettő", sk = "dva" },
    ["three"] = { lemma = "three", es = "tres", fr = "trois", pt = "três", ru = "три", de = "drei", pl = "trzy", hu = "három", sk = "tri" },
    ["first"] = { lemma = "first", es = "primero", fr = "premier", pt = "primeiro", ru = "первый", de = "erster", pl = "pierwszy", hu = "első", sk = "prvý" },
    ["last"] = { lemma = "last", es = "último", fr = "dernier", pt = "último", ru = "последний", de = "letzter", pl = "ostatni", hu = "utolsó", sk = "posledný" },
    ["next"] = { lemma = "next", es = "siguiente", fr = "prochain", pt = "próximo", ru = "следующий", de = "nächster", pl = "następny", hu = "következő", sk = "ďalší" },
    ["other"] = { lemma = "other", es = "otro", fr = "autre", pt = "outro", ru = "другой", de = "anderer", pl = "inny", hu = "más", sk = "iný" },
    ["same"] = { lemma = "same", es = "mismo", fr = "même", pt = "mesmo", ru = "тот же", de = "gleiche", pl = "taki sam", hu = "ugyanaz", sk = "rovnaký" },
    ["different"] = { lemma = "different", es = "diferente", fr = "différent", pt = "diferente", ru = "разный", de = "verschieden", pl = "różny", hu = "különböző", sk = "iný" },
    ["many"] = { lemma = "many", es = "muchos", fr = "beaucoup", pt = "muitos", ru = "многие", de = "viele", pl = "wiele", hu = "sok", sk = "mnoho" },
    ["few"] = { lemma = "few", es = "pocos", fr = "peu", pt = "poucos", ru = "немногие", de = "wenige", pl = "niewiele", hu = "kevés", sk = "málo" },
    ["more"] = { lemma = "more", es = "más", fr = "plus", pt = "mais", ru = "больше", de = "mehr", pl = "więcej", hu = "több", sk = "viac" },
    ["less"] = { lemma = "less", es = "menos", fr = "moins", pt = "menos", ru = "меньше", de = "weniger", pl = "mniej", hu = "kevesebb", sk = "menej" },
    -- Interrogatives
    ["what"] = { lemma = "what", es = "qué", fr = "quoi", pt = "o que", ru = "что", de = "was", pl = "co", hu = "mi", sk = "čo" },
    ["who"] = { lemma = "who", es = "quién", fr = "qui", pt = "quem", ru = "кто", de = "wer", pl = "kto", hu = "ki", sk = "kto" },
    ["where"] = { lemma = "where", es = "dónde", fr = "où", pt = "onde", ru = "где", de = "wo", pl = "gdzie", hu = "hol", sk = "kde" },
    ["why"] = { lemma = "why", es = "por qué", fr = "pourquoi", pt = "por que", ru = "почему", de = "warum", pl = "dlaczego", hu = "miért", sk = "prečo" },
    ["how"] = { lemma = "how", es = "cómo", fr = "comment", pt = "como", ru = "как", de = "wie", pl = "jak", hu = "hogyan", sk = "ako" },
    -- Gameplay Roles
    ["DPS"] = { lemma = "DPS", es = "DPS", fr = "DPS", pt = "DPS", ru = "ДД", de = "DPS", pl = "DPS", hu = "DPS", sk = "DPS" },
    ["damage dealer"] = { lemma = "damage dealer", es = "destructor", fr = "dégâts", pt = "causador de dano", ru = "дамаг дилер", de = "Schadensverursacher", pl = "zadający obrażenia", hu = "sebzésosztó", sk = "spôsobovač škôd" },
    ["DD"] = { lemma = "DD", es = "destructor", fr = "dégâts", pt = "causador de dano", ru = "ДД", de = "Schadensverursacher", pl = "DD", hu = "DD", sk = "DD" },
    ["tank"] = { lemma = "tank", es = "tanque", fr = "tank", pt = "tanque", ru = "танк", de = "Tank", pl = "tank", hu = "tank", sk = "tank" },
    ["healer"] = { lemma = "healer", es = "curador", fr = "soigneur", pt = "curandeiro", ru = "хил", de = "Heiler", pl = "lekarz", hu = "gyógyító", sk = "liečiteľ" },
    ["main tank"] = { lemma = "main tank", es = "tanque principal", fr = "tank principal", pt = "tanque principal", ru = "главный танк", de = "Haupt-Tank", pl = "główny tank", hu = "fő tank", sk = "hlavný tank" },
    ["off tank"] = { lemma = "off tank", es = "tanque secundario", fr = "tank secondaire", pt = "tanque secundário", ru = "второй танк", de = "Neben-Tank", pl = "pomocniczy tank", hu = "másodlagos tank", sk = "vedľajší tank" },
    -- Combat Mechanics
    ["aggro"] = { lemma = "aggro", es = "aggro", fr = "aggro", pt = "aggro", ru = "аггро", de = "Aggro", pl = "aggro", hu = "aggro", sk = "aggro" },
    ["threat"] = { lemma = "threat", es = "amenaza", fr = "menace", pt = "ameaça", ru = "угроза", de = "Bedrohung", pl = "zagrożenie", hu = "fenyegetés", sk = "hrozba" },
    ["taunt"] = { lemma = "taunt", es = "provocar", fr = "provoquer", pt = "provocar", ru = "таунт", de = "Hohn", pl = "prowokacja", hu = "gúny", sk = "provokácia" },
    ["pull"] = { lemma = "pull", es = "tirar", fr = "pull", pt = "puxar", ru = "пул", de = "ziehen", pl = "przyciągnięcie", hu = "húzás", sk = "ťahanie" },
    ["wipe"] = { lemma = "wipe", es = "wipe", fr = "wipe", pt = "wipe", ru = "вайп", de = "Wipe", pl = "wipe", hu = "wipe", sk = "wipe" },
    ["cooldown"] = { lemma = "cooldown", es = "enfriamiento", fr = "temps de recharge", pt = "cooldown", ru = "перезарядка", de = "Abklingzeit", pl = "czas odnowienia", hu = "lehűlési idő", sk = "čas obnovenia" },
    ["CC"] = { lemma = "CC", es = "CC", fr = "CC", pt = "CC", ru = "КК", de = "CC", pl = "CC", hu = "CC", sk = "CC" },
    ["crowd control"] = { lemma = "crowd control", es = "control de masas", fr = "contrôle de foule", pt = "controle de multidão", ru = "контроль толпы", de = "Massenkontrolle", pl = "kontrola tłumu", hu = "tömegirányítás", sk = "kontrola davu" },
    ["interrupt"] = { lemma = "interrupt", es = "interrumpir", fr = "interrompre", pt = "interromper", ru = "прервать", de = "unterbrechen", pl = "przerwać", hu = "megszakít", sk = "prerušiť" },
    ["dispel"] = { lemma = "dispel", es = "disipar", fr = "dissiper", pt = "dissipar", ru = "рассеять", de = "bannen", pl = "rozproszyć", hu = "oszlat", sk = "rozptýliť" },
    ["kiting"] = { lemma = "kiting", es = "kiting", fr = "kiting", pt = "kiting", ru = "кайтинг", de = "Kiten", pl = "kiting", hu = "kiting", sk = "kiting" },
    ["stack"] = { lemma = "stack", es = "apilar", fr = "stack", pt = "empilhar", ru = "стак", de = "stacken", pl = "stakować", hu = "halmoz", sk = "stohovať" },
    ["spread out"] = { lemma = "spread out", es = "dispersarse", fr = "se disperser", pt = "espalhar-se", ru = "разойтись", de = "verteilen", pl = "rozproszyć się", hu = "szétszóródni", sk = "rozostúpiť sa" },
    ["move out of fire"] = { lemma = "move out of fire", es = "sal del fuego", fr = "sortez du feu", pt = "saia do fogo", ru = "выйди из огня", de = "aus dem Feuer gehen", pl = "wyjdź z ognia", hu = "menj ki a tűzből", sk = "výjdi z ohňa" },
    ["focus"] = { lemma = "focus", es = "enfoque", fr = "foco", pt = "foco", ru = "фокус", de = "Fokus", pl = "skupienie", hu = "fókusz", sk = "sústredenie" },
    ["focus target"] = { lemma = "focus target", es = "objetivo focado", fr = "cible focale", pt = "alvo focado", ru = "цель фокуса", de = "Fokusziel", pl = "cel skupienia", hu = "fókusz cél", sk = "cieľ sústredenia" },
    ["buff"] = { lemma = "buff", es = "beneficio", fr = "buff", pt = "buff", ru = "бафф", de = "Buff", pl = "buff", hu = "buff", sk = "buff" },
    ["debuff"] = { lemma = "debuff", es = "perjuicio", fr = "debuff", pt = "debuff", ru = "дебафф", de = "Debuff", pl = "debuff", hu = "debuff", sk = "debuff" },
    ["mana"] = { lemma = "mana", es = "mana", fr = "mana", pt = "mana", ru = "мана", de = "Mana", pl = "mana", hu = "mana", sk = "mana" },
    ["rage"] = { lemma = "rage", es = "rabia", fr = "rage", pt = "raiva", ru = "ярость", de = "Wut", pl = "wściekłość", hu = "düh", sk = "hnev" },
    ["runic power"] = { lemma = "runic power", es = "poder rúnico", fr = "puissance runique", pt = "poder rúnico", ru = "руническая сила", de = "Runenmacht", pl = "moc runiczna", hu = "rúnikus erő", sk = "runová sila" },
    ["critic"] = { lemma = "critic", es = "crítico", fr = "critique", pt = "crítico", ru = "крит", de = "Krit", pl = "krytyk", hu = "kritikus", sk = "kritický" },
    ["haste"] = { lemma = "haste", es = "celeridad", fr = "hâte", pt = "pressa", ru = "скорость", de = "Tempo", pl = "pośpiech", hu = "gyorsaság", sk = "rýchlosť" },
    ["melee"] = { lemma = "melee", es = "cuerpo a cuerpo", fr = "mêlée", pt = "corpo a corpo", ru = "ближний бой", de = "Nahkampf", pl = "walka wręcz", hu = "közelharc", sk = "boj zblízka" },
    ["ranged"] = { lemma = "ranged", es = "a distancia", fr = "à distance", pt = "a distância", ru = "дальний бой", de = "Fernkampf", pl = "dystansowy", hu = "távolsági", sk = "na diaľku" },
    ["attack"] = { lemma = "attack", es = "ataque", fr = "attaque", pt = "ataque", ru = "атака", de = "Angriff", pl = "atak", hu = "támadás", sk = "útok" },
    ["damage"] = { lemma = "damage", es = "daño", fr = "dégâts", pt = "dano", ru = "урон", de = "Schaden", pl = "obrażenia", hu = "sebzés", sk = "škoda" },
    ["stun"] = { lemma = "stun", es = "aturdir", fr = "étourdir", pt = "atordoar", ru = "оглушить", de = "Betäubung", pl = "ogłuszenie", hu = "kábítás", sk = "omráčenie" },
    ["silence"] = { lemma = "silence", es = "silenciar", fr = "silence", pt = "silenciar", ru = "заглушить", de = "Stille", pl = "uciszenie", hu = "csend", sk = "umlčanie" },
    ["root"] = { lemma = "root", es = "enraizar", fr = "enraciner", pt = "enraizar", ru = "укоренить", de = "Wurzeln", pl = "zakorzenienie", hu = "gyökerezés", sk = "zakorenenie" },
    ["fear"] = { lemma = "fear", es = "miedo", fr = "peur", pt = "medo", ru = "страх", de = "Angst", pl = "strach", hu = "félelem", sk = "strach" },
    -- Healing and Resurrection
    ["heal"] = { lemma = "heal", es = "sanar", fr = "soigner", pt = "curar", ru = "лечить", de = "heilen", pl = "leczyć", hu = "gyógyít", sk = "liečiť" },
    ["revive me"] = { lemma = "revive me", es = "revíveme", fr = "ressuscitez-moi", pt = "reviver-me", ru = "воскреси меня", de = "wiederbelebe mich", pl = "ożyw mnie", hu = "élessz fel", sk = "oživ ma" },
    ["resurrect"] = { lemma = "resurrect", es = "resucitar", fr = "ressusciter", pt = "ressuscitar", ru = "воскрешать", de = "wiederbeleben", pl = "wskrzesić", hu = "feltámaszt", sk = "vzkriesiť" },
    ["resurrection"] = { lemma = "resurrection", es = "resurrección", fr = "résurrection", pt = "ressurreição", ru = "воскресение", de = "Wiederbelebung", pl = "wskrzeszenie", hu = "feltámadás", sk = "vzkriesenie" },
    ["need heal"] = { lemma = "need heal", es = "necesito sanar", fr = "besoin de soin", pt = "preciso de cura", ru = "нужен хил", de = "brauche Heilung", pl = "potrzebuję leczenia", hu = "gyógyítás kell", sk = "potrebujem liečenie" },
    ["need tank"] = { lemma = "need tank", es = "necesito tanque", fr = "besoin de tank", pt = "preciso de tanque", ru = "нужен танк", de = "brauche Tank", pl = "potrzebuję tanka", hu = "tank kell", sk = "potrebujem tank" },
    ["heal me"] = { lemma = "heal me", es = "sáname", fr = "soignez-moi", pt = "cure-me", ru = "похиль меня", de = "heil mich", pl = "ulecz mnie", hu = "gyógyíts meg", sk = "vylieč ma" },
    ["healing"] = { lemma = "healing", es = "curación", fr = "soin", pt = "cura", ru = "исцеление", de = "Heilung", pl = "leczenie", hu = "gyógyítás", sk = "liečenie" },
    ["out of mana"] = { lemma = "out of mana", es = "sin mana", fr = "à court de mana", pt = "sem mana", ru = "нет маны", de = "kein Mana", pl = "brak many", hu = "nincs mana", sk = "bez many" },
    ["low mana"] = { lemma = "low mana", es = "bajo en mana", fr = "faible en mana", pt = "pouco mana", ru = "мало маны", de = "wenig Mana", pl = "mało many", hu = "kevés mana", sk = "málo many" },
    ["rez"] = { lemma = "rez", es = "rez", fr = "rez", pt = "rez", ru = "рез", de = "Rez", pl = "rez", hu = "rez", sk = "rez" },
    ["battle rez"] = { lemma = "battle rez", es = "resurrección en combate", fr = "résurrection en combat", pt = "ressurreição em combate", ru = "боевой рез", de = "Kampfwiederbelebung", pl = "wskrzeszenie w walce", hu = "harci feltámadás", sk = "bojové vzkriesenie" },
    ["mass resurrection"] = { lemma = "mass resurrection", es = "resurrección en masa", fr = "résurrection de masse", pt = "ressurreição em massa", ru = "массовое воскресение", de = "Massenwiederbelebung", pl = "masowe wskrzeszenie", hu = "tömeges feltámadás", sk = "hromadné vzkriesenie" },
    ["need rez"] = { lemma = "need rez", es = "necesito rez", fr = "besoin de rez", pt = "preciso de rez", ru = "нужен рез", de = "brauche Rez", pl = "potrzebuję rez", hu = "rez kell", sk = "potrebujem rez" },
    ["hot"] = { lemma = "hot", es = "curación con el tiempo", fr = "soin sur la durée", pt = "cura ao longo do tempo", ru = "ХоТ", de = "HoT", pl = "leczenie z czasem", hu = "időbeli gyógyítás", sk = "liečenie v čase" },
    ["direct heal"] = { lemma = "direct heal", es = "curación directa", fr = "soin direct", pt = "cura direta", ru = "прямое исцеление", de = "direkte Heilung", pl = "bezpośrednie leczenie", hu = "közvetlen gyógyítás", sk = "priame liečenie" },
    ["big heal"] = { lemma = "big heal", es = "gran curación", fr = "gros soin", pt = "cura grande", ru = "большой хил", de = "große Heilung", pl = "duże leczenie", hu = "nagy gyógyítás", sk = "veľké liečenie" },
    ["quick heal"] = { lemma = "quick heal", es = "curación rápida", fr = "soin rapide", pt = "cura rápida", ru = "быстрый хил", de = "schnelle Heilung", pl = "szybkie leczenie", hu = "gyors gyógyítás", sk = "rýchle liečenie" },
    ["heal tank"] = { lemma = "heal tank", es = "sanar al tanque", fr = "soigner le tank", pt = "curar o tanque", ru = "хилить танка", de = "Tank heilen", pl = "ulecz tanka", hu = "tank gyógyítása", sk = "vylieč tank" },
    ["full health"] = { lemma = "full health", es = "salud completa", fr = "santé pleine", pt = "saúde completa", ru = "полное здоровье", de = "volle Gesundheit", pl = "pełne zdrowie", hu = "teljes egészség", sk = "plné zdravie" },
    ["low health"] = { lemma = "low health", es = "poca salud", fr = "faible santé", pt = "pouca saúde", ru = "мало здоровья", de = "wenig Gesundheit", pl = "mało zdrowia", hu = "alacsony egészség", sk = "málo zdravia" },
    -- Mana Management
    ["mana regen"] = { lemma = "mana regen", es = "regeneración de mana", fr = "régénération de mana", pt = "regeneração de mana", ru = "восстановление маны", de = "Mana-Regeneration", pl = "regeneracja many", hu = "mana regeneráció", sk = "regenerácia many" },
    ["need mana"] = { lemma = "need mana", es = "necesito mana", fr = "besoin de mana", pt = "preciso de mana", ru = "нужна мана", de = "brauche Mana", pl = "potrzebuję many", hu = "mana kell", sk = "potrebujem manu" },
    ["mana pot"] = { lemma = "mana pot", es = "poción de mana", fr = "potion de mana", pt = "poção de mana", ru = "зелье маны", de = "Manatrank", pl = "mikstura many", hu = "mana ital", sk = "elixír many" },
    ["innervate"] = { lemma = "innervate", es = "estimular", fr = "innervation", pt = "inervar", ru = "иннервейт", de = "Innervieren", pl = "innervacja", hu = "innerválás", sk = "inervácia" },
    ["mana tide"] = { lemma = "mana tide", es = "mareas de mana", fr = "totem de vague de mana", pt = "maré de mana", ru = "прилив маны", de = "Manawoge", pl = "fala many", hu = "mana áradat", sk = "príliv many" },
    ["evocation"] = { lemma = "evocation", es = "evocación", fr = "évocation", pt = "evocação", ru = "эвокейшн", de = "Hervorrufung", pl = "ewokacja", hu = "idézés", sk = "vyvolanie" },
    -- Miscellaneous
    ["please"] = { lemma = "please", es = "por favor", fr = "s'il vous plaît", pt = "por favor", ru = "пожалуйста", de = "bitte", pl = "proszę", hu = "kérlek", sk = "prosím" },
    -- Original ChatTranslator.lua Terms
    ["health"] = { lemma = "health", es = "salud", fr = "santé", pt = "saúde", ru = "здоровье", de = "Gesundheit", pl = "zdrowie", hu = "egészség", sk = "zdravie" },
    ["potion"] = { lemma = "potion", es = "poción", fr = "potion", pt = "poção", ru = "зелье", de = "Trank", pl = "mikstura", hu = "bájital", sk = "elixír" },
    ["stunned"] = { lemma = "stun", es = "aturdido", fr = "étourdi", pt = "atordoado", ru = "оглушён", de = "betäubt", pl = "ogłuszony", hu = "kábult", sk = "omráčený" },
	-- Action Verbs
	["fight"] = { lemma = "fight", es = "luchar", fr = "se battre", pt = "lutar", ru = "сражаться", de = "kämpfen", pl = "walczyć", hu = "harcol", sk = "bojovať" },
	["defend"] = { lemma = "defend", es = "defender", fr = "défendre", pt = "defender", ru = "защищать", de = "verteidigen", pl = "bronić", hu = "védeni", sk = "brániť" },
	["attack"] = { lemma = "attack", es = "atacar", fr = "attaquer", pt = "atacar", ru = "атаковать", de = "angreifen", pl = "atakować", hu = "támadni", sk = "útočiť" },
	["cast"] = { lemma = "cast", es = "lanzar", fr = "lancer", pt = "lançar", ru = "кастовать", de = "zaubern", pl = "rzucać", hu = "varázsol", sk = "vrhať" },
	["summon"] = { lemma = "summon", es = "invocar", fr = "invoquer", pt = "invocar", ru = "призвать", de = "beschwören", pl = "przywołać", hu = "idézni", sk = "privolať" },
	["loot"] = { lemma = "loot", es = "saquear", fr = "piller", pt = "saquear", ru = "лутать", de = "plündern", pl = "grabież", hu = "zsákmányol", sk = "vyplieniť" },
	["equip"] = { lemma = "equip", es = "equipar", fr = "équiper", pt = "equipar", ru = "экипировать", de = "ausrüsten", pl = "wyposażyć", hu = "felszerel", sk = "vybaviť" },
	["trade"] = { lemma = "trade", es = "comerciar", fr = "échanger", pt = "trocar", ru = "торговать", de = "handeln", pl = "handlować", hu = "kereskedni", sk = "obchodovať" },
	["invite"] = { lemma = "invite", es = "invitar", fr = "inviter", pt = "convidar", ru = "пригласить", de = "einladen", pl = "zaprosić", hu = "meghívni", sk = "pozvať" },
	["kick"] = { lemma = "kick", es = "patear", fr = "expulser", pt = "expulsar", ru = "кикнуть", de = "rausschmeißen", pl = "wyrzucić", hu = "kirúgni", sk = "vyhodiť" },
	["win"] = { lemma = "win", es = "ganar", fr = "gagner", pt = "ganhar", ru = "победить", de = "gewinnen", pl = "wygrać", hu = "győzni", sk = "vyhrať" },
	["die"] = { lemma = "die", es = "morir", fr = "mourir", pt = "morrer", ru = "умереть", de = "sterben", pl = "umrzeć", hu = "meghalni", sk = "zomrieť" },
	["kill"] = { lemma = "kill", es = "matar", fr = "tuer", pt = "matar", ru = "убить", de = "töten", pl = "zabić", hu = "megölni", sk = "zabiť" },
	["revive"] = { lemma = "revive", es = "revivir", fr = "ressusciter", pt = "reviver", ru = "оживить", de = "wiederbeleben", pl = "ożywić", hu = "feltámasztani", sk = "oživiť" },
	["escape"] = { lemma = "escape", es = "escapar", fr = "s'échapper", pt = "escapar", ru = "сбежать", de = "entkommen", pl = "uciec", hu = "megszökni", sk = "uniknúť" },
	["hide"] = { lemma = "hide", es = "esconderse", fr = "se cacher", pt = "esconder-se", ru = "прятаться", de = "sich verstecken", pl = "ukryć się", hu = "elbújni", sk = "schovať sa" },
	["search"] = { lemma = "search", es = "buscar", fr = "chercher", pt = "procurar", ru = "искать", de = "suchen", pl = "szukać", hu = "keresni", sk = "hľadať" },
	["explore"] = { lemma = "explore", es = "explorar", fr = "explorer", pt = "explorar", ru = "исследовать", de = "erforschen", pl = "badać", hu = "felfedezni", sk = "preskúmať" },
	["craft"] = { lemma = "craft", es = "fabricar", fr = "fabriquer", pt = "fabricar", ru = "крафтить", de = "herstellen", pl = "wytworzyć", hu = "kézműveskedni", sk = "vyrobiť" },
	["gather"] = { lemma = "gather", es = "recoger", fr = "ramasser", pt = "coletar", ru = "собирать", de = "sammeln", pl = "zbierać", hu = "gyűjteni", sk = "zbierať" },
	["mine"] = { lemma = "mine", es = "minar", fr = "miner", pt = "minerar", ru = "добывать", de = "abbauen", pl = "wydobywać", hu = "bányászni", sk = "ťažiť" },
	["fish"] = { lemma = "fish", es = "pescar", fr = "pêcher", pt = "pescar", ru = "ловить рыбу", de = "angeln", pl = "łowić ryby", hu = "halászni", sk = "loviť ryby" },
	["cook"] = { lemma = "cook", es = "cocinar", fr = "cuisiner", pt = "cozinhar", ru = "готовить", de = "kochen", pl = "gotować", hu = "főzni", sk = "variť" },
	["enchant"] = { lemma = "enchant", es = "encantar", fr = "enchanter", pt = "encantar", ru = "зачаровать", de = "verzaubern", pl = "oczarować", hu = "elbűvölni", sk = "očarovať" },
	["disenchant"] = { lemma = "disenchant", es = "desencantar", fr = "désenchanter", pt = "desencantar", ru = "распылить", de = "entzaubern", pl = "odczarować", hu = "elbűvölni", sk = "odčarovať" },
	["repair"] = { lemma = "repair", es = "reparar", fr = "réparer", pt = "reparar", ru = "починить", de = "reparieren", pl = "naprawić", hu = "javítani", sk = "opraviť" },
	["upgrade"] = { lemma = "upgrade", es = "mejorar", fr = "améliorer", pt = "melhorar", ru = "улучшить", de = "verbessern", pl = "ulepszyć", hu = "fejleszteni", sk = "vylepšiť" },
	-- Descriptive Adjectives
	["strong"] = { lemma = "strong", es = "fuerte", fr = "fort", pt = "forte", ru = "сильный", de = "stark", pl = "silny", hu = "erős", sk = "silný" },
	["weak"] = { lemma = "weak", es = "débil", fr = "faible", pt = "fraco", ru = "слабый", de = "schwach", pl = "słaby", hu = "gyenge", sk = "slabý" },
	["powerful"] = { lemma = "powerful", es = "poderoso", fr = "puissant", pt = "poderoso", ru = "мощный", de = "mächtig", pl = "potężny", hu = "hatalmas", sk = "mocný" },
	["magical"] = { lemma = "magical", es = "mágico", fr = "magique", pt = "mágico", ru = "магический", de = "magisch", pl = "magiczny", hu = "varázslatos", sk = "magický" },
	["legendary"] = { lemma = "legendary", es = "legendario", fr = "légendaire", pt = "lendário", ru = "легендарный", de = "legendär", pl = "legendarny", hu = "legendás", sk = "legendárny" },
	["rare"] = { lemma = "rare", es = "raro", fr = "rare", pt = "raro", ru = "редкий", de = "selten", pl = "rzadki", hu = "ritka", sk = "vzácny" },
	["common"] = { lemma = "common", es = "común", fr = "commun", pt = "comum", ru = "обычный", de = "gewöhnlich", pl = "powszechny", hu = "gyakori", sk = "bežný" },
	["epic"] = { lemma = "epic", es = "épico", fr = "épique", pt = "épico", ru = "эпический", de = "episch", pl = "epicki", hu = "epikus", sk = "epický" },
	["unique"] = { lemma = "unique", es = "único", fr = "unique", pt = "único", ru = "уникальный", de = "einzigartig", pl = "unikalny", hu = "egyedi", sk = "jedinečný" },
	["cursed"] = { lemma = "cursed", es = "maldito", fr = "maudit", pt = "amaldiçoado", ru = "проклятый", de = "verflucht", pl = "przeklęty", hu = "átkozott", sk = "prekliaty" },
	["blessed"] = { lemma = "blessed", es = "bendecido", fr = "béni", pt = "abençoado", ru = "благословенный", de = "gesegnet", pl = "błogosławiony", hu = "áldott", sk = "požehnaný" },
	["enchanted"] = { lemma = "enchanted", es = "encantado", fr = "enchanté", pt = "encantado", ru = "зачарованный", de = "verzaubert", pl = "oczarowany", hu = "elbűvölt", sk = "očarovaný" },
	["broken"] = { lemma = "broken", es = "roto", fr = "cassé", pt = "quebrado", ru = "сломанный", de = "kaputt", pl = "zepsuty", hu = "törött", sk = "zlomený" },
	["damaged"] = { lemma = "damaged", es = "dañado", fr = "endommagé", pt = "danificado", ru = "повреждённый", de = "beschädigt", pl = "uszkodzony", hu = "sérült", sk = "poškodený" },
	["repaired"] = { lemma = "repaired", es = "reparado", fr = "réparé", pt = "reparado", ru = "починенный", de = "repariert", pl = "naprawiony", hu = "javított", sk = "opravený" },
	["upgraded"] = { lemma = "upgraded", es = "mejorado", fr = "amélioré", pt = "melhorado", ru = "улучшенный", de = "verbessert", pl = "ulepszony", hu = "fejlesztett", sk = "vylepšený" },
	["shiny"] = { lemma = "shiny", es = "brillante", fr = "brillant", pt = "brilhante", ru = "блестящий", de = "glänzend", pl = "błyszczący", hu = "fényes", sk = "lesklý" },
	["dull"] = { lemma = "dull", es = "opaco", fr = "terne", pt = "opaco", ru = "тусклый", de = "matt", pl = "matowy", hu = "tompa", sk = "matný" },
	["bright"] = { lemma = "bright", es = "brillante", fr = "brillant", pt = "brilhante", ru = "яркий", de = "hell", pl = "jasny", hu = "fényes", sk = "jasný" },
	["heavy"] = { lemma = "heavy", es = "pesado", fr = "lourd", pt = "pesado", ru = "тяжёлый", de = "schwer", pl = "ciężki", hu = "nehéz", sk = "ťažký" },
	["quick"] = { lemma = "quick", es = "rápido", fr = "rapide", pt = "rápido", ru = "быстрый", de = "schnell", pl = "szybki", hu = "gyors", sk = "rýchly" },
	["agile"] = { lemma = "agile", es = "ágil", fr = "agile", pt = "ágil", ru = "ловкий", de = "agil", pl = "zwinny", hu = "fürge", sk = "obratný" },
	["clumsy"] = { lemma = "clumsy", es = "torpe", fr = "maladroit", pt = "desajeitado", ru = "неуклюжий", de = "ungeschickt", pl = "niezdarny", hu = "ügyetlen", sk = "nešikovný" },
	["smart"] = { lemma = "smart", es = "inteligente", fr = "intelligent", pt = "inteligente", ru = "умный", de = "klug", pl = "mądry", hu = "okos", sk = "chytrý" },
	["wise"] = { lemma = "wise", es = "sabio", fr = "sage", pt = "sábio", ru = "мудрый", de = "weise", pl = "mądry", hu = "bölcs", sk = "múdry" },
	-- Gaming Terms
	["quest"] = { lemma = "quest", es = "misión", fr = "quête", pt = "missão", ru = "квест", de = "Quest", pl = "zadanie", hu = "küldetés", sk = "úloha" },
	["level"] = { lemma = "level", es = "nivel", fr = "niveau", pt = "nível", ru = "уровень", de = "Level", pl = "poziom", hu = "szint", sk = "úroveň" },
	["experience"] = { lemma = "experience", es = "experiencia", fr = "expérience", pt = "experiência", ru = "опыт", de = "Erfahrung", pl = "doświadczenie", hu = "tapasztalat", sk = "skúsenosť" },
	["guild"] = { lemma = "guild", es = "gremio", fr = "guilde", pt = "guilda", ru = "гильдия", de = "Gilde", pl = "gildia", hu = "céh", sk = "cech" },
	["raid"] = { lemma = "raid", es = "incursión", fr = "raid", pt = "raid", ru = "рейд", de = "Schlachtzug", pl = "rajd", hu = "raid", sk = "raid" },
	["dungeon"] = { lemma = "dungeon", es = "mazmorra", fr = "donjon", pt = "masmorra", ru = "подземелье", de = "Dungeon", pl = "loch", hu = "kazamata", sk = "žalár" },
	["boss"] = { lemma = "boss", es = "jefe", fr = "boss", pt = "chefe", ru = "босс", de = "Boss", pl = "boss", hu = "főellenség", sk = "boss" },
	["minion"] = { lemma = "minion", es = "esbirro", fr = "serviteur", pt = "lacaio", ru = "прислужник", de = "Diener", pl = "sługa", hu = "csatlós", sk = "prisluhovač" },
	["ally"] = { lemma = "ally", es = "aliado", fr = "allié", pt = "aliado", ru = "союзник", de = "Verbündeter", pl = "sojusznik", hu = "szövetséges", sk = "spojenec" },
	["opponent"] = { lemma = "opponent", es = "oponente", fr = "adversaire", pt = "oponente", ru = "противник", de = "Gegner", pl = "przeciwnik", hu = "ellenfél", sk = "súper" },
	["victory"] = { lemma = "victory", es = "victoria", fr = "victoire", pt = "vitória", ru = "победа", de = "Sieg", pl = "zwycięstwo", hu = "győzelem", sk = "víťazstvo" },
	["defeat"] = { lemma = "defeat", es = "derrota", fr = "défaite", pt = "derrota", ru = "поражение", de = "Niederlage", pl = "porażka", hu = "vereség", sk = "porážka" },
	["strategy"] = { lemma = "strategy", es = "estrategia", fr = "stratégie", pt = "estratégia", ru = "стратегия", de = "Strategie", pl = "strategia", hu = "stratégia", sk = "stratégia" },
	["tactic"] = { lemma = "tactic", es = "táctica", fr = "tactique", pt = "tática", ru = "тактика", de = "Taktik", pl = "taktyka", hu = "taktika", sk = "taktika" },
	["skill"] = { lemma = "skill", es = "habilidad", fr = "compétence", pt = "habilidade", ru = "навык", de = "Fähigkeit", pl = "umiejętność", hu = "képesség", sk = "zručnosť" },
	["ability"] = { lemma = "ability", es = "capacidad", fr = "capacité", pt = "capacidade", ru = "способность", de = "Fähigkeit", pl = "zdolność", hu = "képesség", sk = "schopnosť" },
	["talent"] = { lemma = "talent", es = "talento", fr = "talent", pt = "talento", ru = "талант", de = "Talent", pl = "talent", hu = "tehetség", sk = "talent" },
	["profession"] = { lemma = "profession", es = "profesión", fr = "profession", pt = "profissão", ru = "профессия", de = "Beruf", pl = "profesja", hu = "szakma", sk = "profesia" },
	["crafting"] = { lemma = "crafting", es = "artesanía", fr = "artisanat", pt = "artesanato", ru = "крафтинг", de = "Handwerk", pl = "rzemiosło", hu = "kézművesség", sk = "remeslo" },
	["gathering"] = { lemma = "gathering", es = "recolección", fr = "collecte", pt = "coleta", ru = "сбор", de = "Sammeln", pl = "zbieranie", hu = "gyűjtés", sk = "zbieranie" },
	["auction"] = { lemma = "auction", es = "subasta", fr = "enchère", pt = "leilão", ru = "аукцион", de = "Auktion", pl = "aukcja", hu = "árverés", sk = "aukcia" },
	["bank"] = { lemma = "bank", es = "banco", fr = "banque", pt = "banco", ru = "банк", de = "Bank", pl = "bank", hu = "bank", sk = "banka" },
	["mailbox"] = { lemma = "mailbox", es = "buzón", fr = "boîte aux lettres", pt = "caixa de correio", ru = "почтовый ящик", de = "Briefkasten", pl = "skrzynka pocztowa", hu = "postaláda", sk = "poštová schránka" },
	["vendor"] = { lemma = "vendor", es = "vendedor", fr = "vendeur", pt = "vendedor", ru = "торговец", de = "Händler", pl = "sprzedawca", hu = "árus", sk = "predajca" },
	["trainer"] = { lemma = "trainer", es = "entrenador", fr = "entraîneur", pt = "treinador", ru = "тренер", de = "Lehrer", pl = "trener", hu = "oktató", sk = "tréner" },
	["inn"] = { lemma = "inn", es = "posada", fr = "auberge", pt = "estalagem", ru = "таверна", de = "Gasthaus", pl = "karczma", hu = "fogadó", sk = "hostinec" },
	["arena"] = { lemma = "arena", es = "arena", fr = "arène", pt = "arena", ru = "арена", de = "Arena", pl = "arena", hu = "aréna", sk = "aréna" },
	["battleground"] = { lemma = "battleground", es = "campo de batalla", fr = "champ de bataille", pt = "campo de batalha", ru = "поле боя", de = "Schlachtfeld", pl = "pole bitwy", hu = "csatatér", sk = "bojové pole" },
	-- WoW-Specific Terms
	["Azeroth"] = { lemma = "Azeroth", es = "Azeroth", fr = "Azeroth", pt = "Azeroth", ru = "Азерот", de = "Azeroth", pl = "Azeroth", hu = "Azeroth", sk = "Azeroth" },
	["Horde"] = { lemma = "Horde", es = "Horda", fr = "Horde", pt = "Horda", ru = "Орда", de = "Horde", pl = "Horda", hu = "Horda", sk = "Horda" },
	["Alliance"] = { lemma = "Alliance", es = "Alianza", fr = "Alliance", pt = "Aliança", ru = "Альянс", de = "Allianz", pl = "Przymierze", hu = "Szövetség", sk = "Aliancia" },
	["warrior"] = { lemma = "warrior", es = "guerrero", fr = "guerrier", pt = "guerreiro", ru = "воин", de = "Krieger", pl = "wojownik", hu = "harcos", sk = "bojovník" },
	["paladin"] = { lemma = "paladin", es = "paladín", fr = "paladin", pt = "paladino", ru = "паладин", de = "Paladin", pl = "paladyn", hu = "paladin", sk = "paladin" },
	["hunter"] = { lemma = "hunter", es = "cazador", fr = "chasseur", pt = "caçador", ru = "охотник", de = "Jäger", pl = "łowca", hu = "vadász", sk = "lovec" },
	["rogue"] = { lemma = "rogue", es = "pícaro", fr = "voleur", pt = "ladino", ru = "разбойник", de = "Schurke", pl = "łotr", hu = "zsivány", sk = "lupič" },
	["priest"] = { lemma = "priest", es = "sacerdote", fr = "prêtre", pt = "sacerdote", ru = "жрец", de = "Priester", pl = "kapłan", hu = "pap", sk = "kňaz" },
	["shaman"] = { lemma = "shaman", es = "chamán", fr = "chaman", pt = "xamã", ru = "шаман", de = "Schamane", pl = "szaman", hu = "sámán", sk = "šaman" },
	["mage"] = { lemma = "mage", es = "mago", fr = "mage", pt = "mago", ru = "маг", de = "Magier", pl = "mag", hu = "mágus", sk = "mág" },
	["warlock"] = { lemma = "warlock", es = "brujo", fr = "démoniste", pt = "bruxo", ru = "чернокнижник", de = "Hexenmeister", pl = "czarnoksiężnik", hu = "boszorkánymester", sk = "černokňažník" },
	["druid"] = { lemma = "druid", es = "druida", fr = "druide", pt = "druida", ru = "друид", de = "Druide", pl = "druid", hu = "druida", sk = "druid" },	
	-- Greetings
	["hello"] = { lemma = "hello", es = "hola", fr = "bonjour", pt = "olá", ru = "привет", de = "hallo", pl = "cześć", hu = "szia", sk = "ahoj" },
	["hi"] = { lemma = "hi", es = "hola", fr = "salut", pt = "oi", ru = "привет", de = "hallo", pl = "cześć", hu = "szia", sk = "ahoj" },
	["good morning"] = { lemma = "good morning", es = "buenos días", fr = "bonjour", pt = "bom dia", ru = "доброе утро", de = "guten Morgen", pl = "dzień dobry", hu = "jó reggelt", sk = "dobré ráno" },
	-- Politeness
	["please"] = { lemma = "please", es = "por favor", fr = "s'il vous plaît", pt = "por favor", ru = "пожалуйста", de = "bitte", pl = "proszę", hu = "kérlek", sk = "prosím" },
	["thank you"] = { lemma = "thank you", es = "gracias", fr = "merci", pt = "obrigado", ru = "спасибо", de = "danke", pl = "dziękuję", hu = "köszönöm", sk = "ďakujem" },
	["sorry"] = { lemma = "sorry", es = "lo siento", fr = "désolé", pt = "desculpe", ru = "извините", de = "Entschuldigung", pl = "przepraszam", hu = "bocsánat", sk = "prepáčte" },
	-- Basic Communication
	["yes"] = { lemma = "yes", es = "sí", fr = "oui", pt = "sim", ru = "да", de = "ja", pl = "tak", hu = "igen", sk = "áno" },
	["no"] = { lemma = "no", es = "no", fr = "non", pt = "não", ru = "нет", de = "nein", pl = "nie", hu = "nem", sk = "nie" },
	["help"] = { lemma = "help", es = "ayuda", fr = "aide", pt = "ajuda", ru = "помощь", de = "Hilfe", pl = "pomoc", hu = "segítség", sk = "pomoc" },
	["goodbye"] = { lemma = "goodbye", es = "adiós", fr = "au revoir", pt = "adeus", ru = "до свидания", de = "auf Wiedersehen", pl = "do widzenia", hu = "viszlát", sk = "dovidenia" },
	-- Gaming-Specific Terms
	["group"] = { lemma = "group", es = "grupo", fr = "groupe", pt = "grupo", ru = "группа", de = "Gruppe", pl = "grupa", hu = "csoport", sk = "skupina" },
	["invite"] = { lemma = "invite", es = "invitar", fr = "inviter", pt = "convidar", ru = "пригласить", de = "einladen", pl = "zaprosić", hu = "meghívni", sk = "pozvať" },
	["trade"] = { lemma = "trade", es = "comerciar", fr = "échanger", pt = "trocar", ru = "торговать", de = "handeln", pl = "handlować", hu = "kereskedni", sk = "obchodovať" },
	["buy"] = { lemma = "buy", es = "comprar", fr = "acheter", pt = "comprar", ru = "покупать", de = "kaufen", pl = "kupić", hu = "vásárolni", sk = "kúpiť" },
	["sell"] = { lemma = "sell", es = "vender", fr = "vendre", pt = "vender", ru = "продавать", de = "verkaufen", pl = "sprzedać", hu = "eladni", sk = "predať" },
	-- Weapon Types
	["sword"] = { lemma = "sword", es = "espada", fr = "épée", pt = "espada", ru = "меч", de = "Schwert", pl = "miecz", hu = "kard", sk = "meč" },
	["axe"] = { lemma = "axe", es = "hacha", fr = "hache", pt = "machado", ru = "топор", de = "Axt", pl = "topór", hu = "balta", sk = "sekera" },
	["mace"] = { lemma = "mace", es = "maza", fr = "masse", pt = "maça", ru = "булава", de = "Streitkolben", pl = "buława", hu = "buzogány", sk = "kyjak" },
	["dagger"] = { lemma = "dagger", es = "daga", fr = "dague", pt = "adaga", ru = "кинжал", de = "Dolch", pl = "sztylet", hu = "tőr", sk = "dýka" },
	["staff"] = { lemma = "staff", es = "bastón", fr = "bâton", pt = "cajado", ru = "посох", de = "Stab", pl = "kostur", hu = "bot", sk = "palica" },
	["bow"] = { lemma = "bow", es = "arco", fr = "arc", pt = "arco", ru = "лук", de = "Bogen", pl = "łuk", hu = "íj", sk = "luk" },
	["crossbow"] = { lemma = "crossbow", es = "ballesta", fr = "arbalète", pt = "besta", ru = "арбалет", de = "Armbrust", pl = "kusza", hu = "számszeríj", sk = "kuša" },
	["gun"] = { lemma = "gun", es = "arma de fuego", fr = "arme à feu", pt = "arma", ru = "ружьё", de = "Schusswaffe", pl = "pistolet", hu = "fegyver", sk = "zbraň" },
	["polearm"] = { lemma = "polearm", es = "arma de asta", fr = "arme d'hast", pt = "arma de haste", ru = "древковое оружие", de = "Stangenwaffe", pl = "broń drzewcowa", hu = "szálfegyver", sk = "tyčová zbraň" },
	["fist weapon"] = { lemma = "fist weapon", es = "arma de puño", fr = "arme de pugilat", pt = "arma de punho", ru = "кастет", de = "Faustwaffe", pl = "broń pięściowa", hu = "ökölfegyver", sk = "pästná zbraň" },
	["thrown weapon"] = { lemma = "thrown weapon", es = "arma arrojadiza", fr = "arme de jet", pt = "arma de arremesso", ru = "метательное оружие", de = "Wurfwaffe", pl = "broń miotana", hu = "hajítófegyver", sk = "vrhacia zbraň" },
	["shield"] = { lemma = "shield", es = "escudo", fr = "bouclier", pt = "escudo", ru = "щит", de = "Schild", pl = "tarcza", hu = "pajzs", sk = "štít" },
	-- Armor Types
	["cloth"] = { lemma = "cloth", es = "tela", fr = "tissu", pt = "pano", ru = "ткань", de = "Stoff", pl = "tkanina", hu = "szövet", sk = "látka" },
	["leather"] = { lemma = "leather", es = "cuero", fr = "cuir", pt = "couro", ru = "кожа", de = "Leder", pl = "skóra", hu = "bőr", sk = "koža" },
	["mail"] = { lemma = "mail", es = "malla", fr = "mailles", pt = "malha", ru = "кольчуга", de = "Kette", pl = "kolczuga", hu = "láncing", sk = "brnenie" },
	["plate"] = { lemma = "plate", es = "placas", fr = "plaques", pt = "placas", ru = "латы", de = "Platte", pl = "płyty", hu = "lemez", sk = "plát" },
	["helm"] = { lemma = "helm", es = "yelmo", fr = "casque", pt = "elmo", ru = "шлем", de = "Helm", pl = "hełm", hu = "sisak", sk = "prilba" },
	["shoulders"] = { lemma = "shoulders", es = "hombreras", fr = "épaulières", pt = "ombreiras", ru = "наплечники", de = "Schultern", pl = "naramienniki", hu = "vállvért", sk = "náplecníky" },
	["chest"] = { lemma = "chest", es = "pechera", fr = "plastron", pt = "peitoral", ru = "нагрудник", de = "Brust", pl = "napierśnik", hu = "mellvért", sk = "hrudník" },
	["bracers"] = { lemma = "bracers", es = "brazales", fr = "brassards", pt = "braçadeiras", ru = "наручи", de = "Armschienen", pl = "karwasze", hu = "karszár", sk = "náramenníky" },
	["gloves"] = { lemma = "gloves", es = "guantes", fr = "gants", pt = "luvas", ru = "перчатки", de = "Handschuhe", pl = "rękawice", hu = "kesztyű", sk = "rukavice" },
	["belt"] = { lemma = "belt", es = "cinturón", fr = "ceinture", pt = "cinto", ru = "пояс", de = "Gürtel", pl = "pas", hu = "öv", sk = "opasok" },
	["legs"] = { lemma = "legs", es = "piernas", fr = "jambières", pt = "pernas", ru = "ноги", de = "Beine", pl = "nogawice", hu = "lábvért", sk = "nohy" },
	["boots"] = { lemma = "boots", es = "botas", fr = "bottes", pt = "botas", ru = "сапоги", de = "Stiefel", pl = "buty", hu = "csizma", sk = "čižmy" },
	["ring"] = { lemma = "ring", es = "anillo", fr = "anneau", pt = "anel", ru = "кольцо", de = "Ring", pl = "pierścień", hu = "gyűrű", sk = "prsteň" },
	["trinket"] = { lemma = "trinket", es = "abalorio", fr = "bijou", pt = "berloque", ru = "безделушка", de = "Schmuckstück", pl = "bibelot", hu = "csecsebecse", sk = "prívesok" },
	["cloak"] = { lemma = "cloak", es = "capa", fr = "cape", pt = "manto", ru = "плащ", de = "Umhang", pl = "płaszcz", hu = "köpeny", sk = "plášť" },
	["back"] = { lemma = "back", es = "espalda", fr = "dos", pt = "costas", ru = "спина", de = "Rücken", pl = "plecy", hu = "hát", sk = "chrbát" },
	["wrist"] = { lemma = "wrist", es = "muñeca", fr = "poignet", pt = "pulso", ru = "запястье", de = "Handgelenk", pl = "nadgarstek", hu = "csukló", sk = "zápästie" },
	-- General WoW & Combat Terms
	["questing"] = { lemma = "questing", es = "haciendo misiones", fr = "quête", pt = "fazendo missões", ru = "квестинг", de = "Questen", pl = "wykonywanie zadań", hu = "küldetésezés", sk = "plnenie úloh" },
	["grinding"] = { lemma = "grinding", es = "farmeo", fr = "farm", pt = "grinding", ru = "фарм", de = "Grinden", pl = "farmienie", hu = "grindelés", sk = "farmenie" },
	["raid leader"] = { lemma = "raid leader", es = "líder de raid", fr = "chef de raid", pt = "líder de raide", ru = "рейд лидер", de = "Schlachtzugsleiter", pl = "lider rajdu", hu = "raid vezető", sk = "vedúci raidu" },
	["dungeon finder"] = { lemma = "dungeon finder", es = "buscador de mazmorras", fr = "outil de recherche de donjons", pt = "localizador de masmorras", ru = "поиск подземелий", de = "Dungeonbrowser", pl = "wyszukiwarka lochów", hu = "kazamata kereső", sk = "vyhľadávač žalára" },
	["party sync"] = { lemma = "party sync", es = "sincronización de grupo", fr = "synchronisation de groupe", pt = "sincronização de grupo", ru = "синхронизация группы", de = "Gruppensynchronisierung", pl = "synchronizacja grupy", hu = "csoport szinkronizáció", sk = "synchronizácia skupiny" },
	["transmog"] = { lemma = "transmog", es = "transfigurar", fr = "transmogrification", pt = "transmog", ru = "трансмог", de = "Transmogrifikation", pl = "transmog", hu = "transzmog", sk = "transmog" },
	["addon"] = { lemma = "addon", es = "addon", fr = "addon", pt = "addon", ru = "аддон", de = "Addon", pl = "dodatek", hu = "kiegészítő", sk = "doplnok" },
	["macro"] = { lemma = "macro", es = "macro", fr = "macro", pt = "macro", ru = "макрос", de = "Makro", pl = "makro", hu = "makró", sk = "makro" },
	["talent tree"] = { lemma = "talent tree", es = "árbol de talentos", fr = "arbre de talents", pt = "árvore de talentos", ru = "древо талантов", de = "Talentbaum", pl = "drzewko talentów", hu = "tehetségfa", sk = "strom talentov" },
	["spell"] = { lemma = "spell", es = "hechizo", fr = "sort", pt = "feitiço", ru = "заклинание", de = "Zauber", pl = "zaklęcie", hu = "varázslat", sk = "kúzlo" },
	["ability"] = { lemma = "ability", es = "habilidad", fr = "capacité", pt = "habilidade", ru = "способность", de = "Fähigkeit", pl = "zdolność", hu = "képesség", sk = "schopnosť" },
	["quest giver"] = { lemma = "quest giver", es = "dador de misiones", fr = "donneur de quête", pt = "doador de missão", ru = "квестгивер", de = "Questgeber", pl = "dawca zadań", hu = "küldetésadó", sk = "zadávateľ úloh" },
	["mob"] = { lemma = "mob", es = "mob", fr = "mob", pt = "mob", ru = "моб", de = "Mob", pl = "potwór", hu = "mob", sk = "mob" },
	["NPC"] = { lemma = "NPC", es = "PNJ", fr = "PNJ", pt = "NPC", ru = "НПС", de = "NPC", pl = "NPC", hu = "NPC", sk = "NPC" },
	["player"] = { lemma = "player", es = "jugador", fr = "joueur", pt = "jogador", ru = "игрок", de = "Spieler", pl = "gracz", hu = "játékos", sk = "hráč" },
	["emote"] = { lemma = "emote", es = "emote", fr = "emote", pt = "emote", ru = "эмоция", de = "Emote", pl = "emotka", hu = "érzelem", sk = "emócia" },
	["whisper"] = { lemma = "whisper", es = "susurrar", fr = "chuchoter", pt = "sussurrar", ru = "шептать", de = "flüstern", pl = "szeptać", hu = "suttog", sk = "šepkať" },
	["channel"] = { lemma = "channel", es = "canal", fr = "canal", pt = "canal", ru = "канал", de = "Kanal", pl = "kanał", hu = "csatorna", sk = "kanál" },
	["trade chat"] = { lemma = "trade chat", es = "chat de comercio", fr = "canal de commerce", pt = "chat de comércio", ru = "торговый чат", de = "Handelschat", pl = "czat handlowy", hu = "kereskedelmi chat", sk = "obchodný kanál" },
	["general chat"] = { lemma = "general chat", es = "chat general", fr = "canal général", pt = "chat geral", ru = "общий чат", de = "Allgemeiner Chat", pl = "ogólny czat", hu = "általános chat", sk = "všeobecný kanál" },
	["looking for group"] = { lemma = "looking for group", es = "buscando grupo", fr = "recherche groupe", pt = "procurando grupo", ru = "ищу группу", de = "Suche Gruppe", pl = "szukam grupy", hu = "csoportot keres", sk = "hľadám skupinu" },
	["LFG"] = { lemma = "LFG", es = "LFG", fr = "LFG", pt = "LFG", ru = "ЛФГ", de = "LFG", pl = "LFG", hu = "LFG", sk = "LFG" },
	["WTS"] = { lemma = "WTS", es = "WTS", fr = "WTS", pt = "WTS", ru = "ПРОДАЮ", de = "WTS", pl = "WTS", hu = "ELADÓ", sk = "PREDÁM" },
	["WTB"] = { lemma = "WTB", es = "WTB", fr = "WTB", pt = "WTB", ru = "КУПЛЮ", de = "WTB", pl = "WTB", hu = "VESZEK", sk = "KÚPIM" },
	["WTT"] = { lemma = "WTT", es = "WTT", fr = "WTT", pt = "WTT", ru = "ОБМЕН", de = "WTT", pl = "WTT", hu = "CSERE", sk = "VYMENÍM" },
	["AFK"] = { lemma = "AFK", es = "AFK", fr = "AFK", pt = "AFK", ru = "АФК", de = "AFK", pl = "AFK", hu = "AFK", sk = "AFK" },
	["BRB"] = { lemma = "BRB", es = "BRB", fr = "BRB", pt = "BRB", ru = "ЩАС ВЕРНУСЬ", de = "BRB", pl = "BRB", hu = "AZONNAL JÖVÖK", sk = "HNEĎ SOM SPÄŤ" },
	["GG"] = { lemma = "GG", es = "GG", fr = "GG", pt = "GG", ru = "ГГ", de = "GG", pl = "GG", hu = "GG", sk = "GG" },
	["GL"] = { lemma = "GL", es = "GL", fr = "GL", pt = "GL", ru = "УДАЧИ", de = "GL", pl = "GL", hu = "SOK SIKERT", sk = "VEĽA ŠŤASTIA" },
	["HF"] = { lemma = "HF", es = "HF", fr = "HF", pt = "HF", ru = "УДАЧИ И ВЕСЕЛЬЯ", de = "HF", pl = "HF", hu = "JÓ SZÓRAKOZÁST", sk = "PRÍJEMNÚ ZÁBAVU" },
	["PvP"] = { lemma = "PvP", es = "JcJ", fr = "PvP", pt = "PvP", ru = "ПвП", de = "PvP", pl = "PvP", hu = "PvP", sk = "PvP" },
	["PvE"] = { lemma = "PvE", es = "JcE", fr = "PvE", pt = "PvE", ru = "ПвЕ", de = "PvE", pl = "PvE", hu = "PvE", sk = "PvE" },
	["gank"] = { lemma = "gank", es = "emboscar", fr = "gank", pt = "emboscar", ru = "ганкать", de = "ganken", pl = "gankować", hu = "gank", sk = "gank" },
	["dot"] = { lemma = "dot", es = "daño con el tiempo", fr = "dot", pt = "dano ao longo do tempo", ru = "дот", de = "DoT", pl = "obrażenia z czasem", hu = "időbeli sebzés", sk = "poškodenie v čase" },
	["HoT"] = { lemma = "HoT", es = "sanación con el tiempo", fr = "HoT", pt = "cura ao longo do tempo", ru = "хот", de = "HoT", pl = "leczenie z czasem", hu = "időbeli gyógyítás", sk = "liečenie v čase" },
	["AoE"] = { lemma = "AoE", es = "AoE", fr = "AoE", pt = "AoE", ru = "АоЕ", de = "AoE", pl = "AoE", hu = "AoE", sk = "AoE" },
	["NPC"] = { lemma = "NPC", es = "PNJ", fr = "PNJ", pt = "NPC", ru = "НПС", de = "NPC", pl = "NPC", hu = "NPC", sk = "NPC" },
	["mob"] = { lemma = "mob", es = "mob", fr = "mob", pt = "mob", ru = "моб", de = "Mob", pl = "potwór", hu = "mob", sk = "mob" },
	["respawn"] = { lemma = "respawn", es = "reaparecer", fr = "réapparaître", pt = "reaparecer", ru = "респавн", de = "respawnen", pl = "odradzać się", hu = "újjáéled", sk = "znovu sa objaviť" },
	["emote"] = { lemma = "emote", es = "gesto", fr = "emote", pt = "gesto", ru = "эмоция", de = "Emote", pl = "emotka", hu = "érzelem", sk = "emócia" },
	["whisper"] = { lemma = "whisper", es = "susurro", fr = "chuchotement", pt = "sussurro", ru = "шепот", de = "Flüstern", pl = "szept", hu = "suttogás", sk = "šepot" },
	["loot spec"] = { lemma = "loot spec", es = "especialización de botín", fr = "spéc. de butin", pt = "espec. de saque", ru = "специализация добычи", de = "Beutespezialisierung", pl = "specjalizacja łupu", hu = "zsákmány specializáció", sk = "špecializácia lúpu" },
	["dungeon group"] = { lemma = "dungeon group", es = "grupo de mazmorra", fr = "groupe de donjon", pt = "grupo de masmorra", ru = "группа подземелья", de = "Dungeongruppe", pl = "grupa lochów", hu = "kazamata csoport", sk = "žalárna skupina" },
	["raid group"] = { lemma = "raid group", es = "grupo de raid", fr = "groupe de raid", pt = "grupo de raide", ru = "рейд группа", de = "Schlachtzugsgruppe", pl = "grupa rajdowa", hu = "raid csoport", sk = "raid skupina" },
	["pvp group"] = { lemma = "pvp group", es = "grupo JcJ", fr = "groupe PvP", pt = "grupo PvP", ru = "ПвП группа", de = "PvP-Gruppe", pl = "grupa PvP", hu = "PvP csoport", sk = "PvP skupina" },
	["battleground group"] = { lemma = "battleground group", es = "grupo de campo de batalla", fr = "groupe de champ de bataille", pt = "grupo de campo de batalha", ru = "группа поля боя", de = "Schlachtfeldgruppe", pl = "grupa pola bitwy", hu = "csatatér csoport", sk = "bojisková skupina" },
	["arena team"] = { lemma = "arena team", es = "equipo de arena", fr = "équipe d'arène", pt = "equipe de arena", ru = "команда арены", de = "Arenateam", pl = "drużyna areny", hu = "aréna csapat", sk = "aréna tím" },
	["gear"] = { lemma = "gear", es = "equipo", fr = "équipement", pt = "equipamento", ru = "экипировка", de = "Ausrüstung", pl = "sprzęt", hu = "felszerelés", sk = "výstroj" },
	["item level"] = { lemma = "item level", es = "nivel de objeto", fr = "niveau d'objet", pt = "nível de item", ru = "уровень предмета", de = "Gegenstandsstufe", pl = "poziom przedmiotu", hu = "tárgyszint", sk = "úroveň predmetu" },
	["talent point"] = { lemma = "talent point", es = "punto de talento", fr = "point de talent", pt = "ponto de talento", ru = "очко таланта", de = "Talentpunkt", pl = "punkt talentu", hu = "tehetségpont", sk = "talentový bod" },
	["glyph"] = { lemma = "glyph", es = "glifo", fr = "glyphe", pt = "glifo", ru = "глиф", de = "Glyphe", pl = "glif", hu = "glifa", sk = "glyf" },
	["mount"] = { lemma = "mount", es = "montura", fr = "monture", pt = "montaria", ru = "маунт", de = "Reittier", pl = "wierzchowiec", hu = " hátas", sk = "mount" },
	["pet"] = { lemma = "pet", es = "mascota", fr = "familier", pt = "mascote", ru = "питомец", de = "Haustier", pl = "zwierzę", hu = "háziállat", sk = "domáce zviera" },
	["companion"] = { lemma = "companion", es = "compañero", fr = "compagnon", pt = "companheiro", ru = "спутник", de = "Begleiter", pl = "towarzysz", hu = "társ", sk = "spoločník" },
	["profession skill"] = { lemma = "profession skill", es = "habilidad de profesión", fr = "compétence de profession", pt = "habilidade de profissão", ru = "профессиональный навык", de = "Berufsfähigkeit", pl = "umiejętność profesji", hu = "szakmai képesség", sk = "profesijná zručnosť" },
	["gathering node"] = { lemma = "gathering node", es = "nodo de recolección", fr = "point de collecte", pt = "nó de coleta", ru = "узел сбора", de = "Sammelknoten", pl = "węzeł zbierania", hu = "gyűjtőpont", sk = "zberný uzol" },
	["resource"] = { lemma = "resource", es = "recurso", fr = "ressource", pt = "recurso", ru = "ресурс", de = "Ressource", pl = "zasób", hu = "erőforrás", sk = "zdroj" },
	["vendor trash"] = { lemma = "vendor trash", es = "basura para vender", fr = "déchet de vendeur", pt = "lixo para vender", ru = "мусор для продажи", de = "Verkäufer-Müll", pl = "śmieci do sprzedania", hu = "eladható szemét", sk = "odpad na predaj" },
	-- General Conversational Terms for Fluency
	["awesome"] = { lemma = "awesome", es = "genial", fr = "génial", pt = "incrível", ru = "потрясающе", de = "super", pl = "świetnie", hu = "fantasztikus", sk = "úžasné" },
	["cool"] = { lemma = "cool", es = "guay", fr = "cool", pt = "legal", ru = "круто", de = "cool", pl = "fajnie", hu = "menő", sk = "super" },
	["no worries"] = { lemma = "no worries", es = "no te preocupes", fr = "pas de soucis", pt = "não se preocupe", ru = "не беспокойся", de = "keine Sorge", pl = "nie ma problemu", hu = "ne aggódj", sk = "žiadne starosti" },
	["glad to help"] = { lemma = "glad to help", es = "encantado de ayudar", fr = "ravi d'aider", pt = "feliz em ajudar", ru = "рад помочь", de = "gerne geholfen", pl = "chętnie pomogłem", hu = "örülök, hogy segíthettem", sk = "rád pomôžem" },
	["my pleasure"] = { lemma = "my pleasure", es = "es un placer", fr = "avec plaisir", pt = "de nada", ru = "с удовольствием", de = "gern geschehen", pl = "cała przyjemność po mojej stronie", hu = "örömmel", sk = "s potešením" },
	["cheers mate"] = { lemma = "cheers mate", es = "saludos amigo", fr = "salut l'ami", pt = "saúde amigo", ru = "спасибо друг", de = "danke Kumpel", pl = "dzięki stary", hu = "egészségedre barátom", sk = "na zdravie kamoš" },
	["what's happening"] = { lemma = "what's happening", es = "qué pasa", fr = "que se passe-t-il", pt = "o que está acontecendo", ru = "что происходит", de = "was passiert", pl = "co się dzieje", hu = "mi történik", sk = "čo sa deje" },
	["gotta go"] = { lemma = "gotta go", es = "tengo que irme", fr = "je dois y aller", pt = "tenho que ir", ru = "мне нужно идти", de = "muss los", pl = "muszę iść", hu = "mennem kell", sk = "musím ísť" },
	["cya"] = { lemma = "cya", es = "nos vemos", fr = "à plus", pt = "até mais", ru = "пока", de = "bis dann", pl = "na razie", hu = "viszlát", sk = "čau" },
	["later"] = { lemma = "later", es = "luego", fr = "plus tard", pt = "mais tarde", ru = "позже", de = "später", pl = "później", hu = "később", sk = "neskôr" },
	["have a good one"] = { lemma = "have a good one", es = "que tengas un buen día", fr = "passe une bonne journée", pt = "tenha um bom dia", ru = "хорошего дня", de = "einen schönen Tag noch", pl = "miłego dnia", hu = "legyen szép napod", sk = "maj pekný deň" },
	["np ty"] = { lemma = "np ty", es = "de nada gracias", fr = "pas de problème merci", pt = "de nada obrigado", ru = "без проблем спасибо", de = "kein Problem danke", pl = "nie ma sprawy, dzięki", hu = "nincs gond, köszi", sk = "žiaden problém, ďakujem" },
	["lol out loud"] = { lemma = "lol out loud", es = "riendo a carcajadas", fr = "rire à voix haute", pt = "rindo alto", ru = "громко смеюсь", de = "laut lachen", pl = "śmiejąc się głośno", hu = "hangosan nevet", sk = "smejem sa nahlas" },
	["ROFL"] = { lemma = "ROFL", es = "ROFL", fr = "ROFL", pt = "ROFL", ru = "Ржунимагу", de = "ROFL", pl = "ROFL", hu = "ROFL", sk = "ROFL" }, -- Rolling on the floor laughing
	["BRB AFK"] = { lemma = "BRB AFK", es = "BRB AFK", fr = "BRB AFK", pt = "BRB AFK", ru = "скоро вернусь АФК", de = "bin gleich zurück AFK", pl = "zaraz wracam AFK", hu = "azonnal jövök AFK", sk = "hned som späť AFK" },
	["IRL"] = { lemma = "IRL", es = "IRL", fr = "IRL", pt = "IRL", ru = "ВЖ", de = "IRL", pl = "IRL", hu = "IRL", sk = "IRL" }, -- In Real Life
	["GG EZ"] = { lemma = "GG EZ", es = "GG EZ", fr = "GG EZ", pt = "GG EZ", ru = "ГГ ИЗИ", de = "GG EZ", pl = "GG EZ", hu = "GG EZ", sk = "GG EZ" }, -- Good game easy (often sarcastic/toxic)
	["g2g"] = { lemma = "g2g", es = "tengo que irme", fr = "faut y aller", pt = "tenho que ir", ru = "нужно идти", de = "muss gehen", pl = "trzeba iść", hu = "menni kell", sk = "musím ísť" },
	["wp"] = { lemma = "wp", es = "bien jugado", fr = "bien joué", pt = "bem jogado", ru = "хорошо сыграно", de = "gut gespielt", pl = "dobrze zagrane", hu = "jól játszott", sk = "dobre zahraté" },
	["np"] = { lemma = "np", es = "de nada", fr = "pas de problème", pt = "de nada", ru = "без проблем", de = "kein Problem", pl = "nie ma sprawy", hu = "nincs gond", sk = "žiaden problém" },
	["idk"] = { lemma = "idk", es = "no sé", fr = "je sais pas", pt = "não sei", ru = "не знаю", de = "keine Ahnung", pl = "nie wiem", hu = "nem tudom", sk = "neviem" },
	["imo"] = { lemma = "imo", es = "en mi opinión", fr = "à mon avis", pt = "na minha opinião", ru = "по моему мнению", de = "meiner Meinung nach", pl = "moim zdaniem", hu = "szerintem", sk = "podľa mňa" },
	["imho"] = { lemma = "imho", es = "en mi humilde opinión", fr = "à mon humble avis", pt = "na minha humilde opinião", ru = "по моему скромному мнению", de = "meiner bescheidenen Meinung nach", pl = "moim skromnym zdaniem", hu = "szerény véleményem szerint", sk = "podľa môjho skromného názoru" },
	["afaik"] = { lemma = "afaik", es = "hasta donde sé", fr = "autant que je sache", pt = "até onde eu sei", ru = "насколько я знаю", de = "soweit ich weiß", pl = "o ile wiem", hu = "amennyire tudom", sk = "pokiaľ viem" },
	["tldr"] = { lemma = "tldr", es = "demasiado largo no leí", fr = "trop long pas lu", pt = "muito longo não li", ru = "слишком длинно не читал", de = "zu lang nicht gelesen", pl = "za długie nie czytałem", hu = "tldr", sk = "príliš dlhé nečítal som" },
	["IRL stuff"] = { lemma = "IRL stuff", es = "cosas de la vida real", fr = "trucs IRL", pt = "coisas da vida real", ru = "дела в реале", de = "IRL-Sachen", pl = "rzeczy IRL", hu = "IRL dolgok", sk = "IRL veci" },
	-- Expanded WoW Terms and Mechanics
	["buff timer"] = { lemma = "buff timer", es = "tiempo de buff", fr = "minuteur de buff", pt = "timer de buff", ru = "таймер баффа", de = "Buff-Timer", pl = "licznik buffa", hu = "buff időzítő", sk = "buff časovač" },
	["debuff timer"] = { lemma = "debuff timer", es = "tiempo de debuff", fr = "minuteur de debuff", pt = "timer de debuff", ru = "таймер дебаффа", de = "Debuff-Timer", pl = "licznik debuffa", hu = "debuff időzítő", sk = "debuff časovač" },
	["threat management"] = { lemma = "threat management", es = "manejo de amenaza", fr = "gestion de l'aggro", pt = "gerenciamento de ameaça", ru = "управление угрозой", de = "Bedrohungsmanagement", pl = "zarządzanie zagrożeniem", hu = "fenyegetéskezelés", sk = "manažment hrozby" },
	["aggro drop"] = { lemma = "aggro drop", es = "caída de aggro", fr = "perte d'aggro", pt = "queda de aggro", ru = "сброс аггро", de = "Aggro-Drop", pl = "spadek aggro", hu = "aggro esés", sk = "aggro pokles" },
	["pull range"] = { lemma = "pull range", es = "rango de pull", fr = "portée de pull", pt = "alcance de pull", ru = "дальность пулла", de = "Pull-Reichweite", pl = "zasięg pulla", hu = "pull hatótáv", sk = "pull dosah" },
	["melee range"] = { lemma = "melee range", es = "rango de melee", fr = "portée de mêlée", pt = "alcance de melee", ru = "дальность ближнего боя", de = "Nahkampf-Reichweite", pl = "zasięg walki wręcz", hu = "közelharc hatótáv", sk = "melee dosah" },
	["ranged range"] = { lemma = "ranged range", es = "rango de ranged", fr = "portée de distance", pt = "alcance de ranged", ru = "дальность дальнего боя", de = "Fernkampf-Reichweite", pl = "zasięg dystansowy", hu = "távolsági hatótáv", sk = "range dosah" },
	["LOS me"] = { lemma = "LOS me", es = "ponme en LoS", fr = "LoS-moi", pt = "me coloque em LoS", ru = "закрой меня по ЛоС", de = "LOS mich", pl = "zakryj mnie LOSem", hu = "LOS-olj engem", sk = "LoS ma" }, -- Line of Sight me
	["line up"] = { lemma = "line up", es = "alinearse", fr = "s'aligner", pt = "alinhar-se", ru = "выстроиться", de = "aufstellen", pl = "ustawić się", hu = "sorakozó", sk = "zarovnať sa" },
	["position yourself"] = { lemma = "position yourself", es = "posicionate", fr = "positionnez-vous", pt = "posicione-se", ru = "займи позицию", de = "positioniere dich", pl = "ustaw się", hu = "helyezkedj el", sk = "umiestni sa" },
	["get behind"] = { lemma = "get behind", es = "ponte detrás", fr = "mets-toi derrière", pt = "fique atrás", ru = "стань сзади", de = "geh dahinter", pl = "stań z tyłu", hu = "állj mögé", sk = "dostaň sa za" },
	["frontals"] = { lemma = "frontals", es = "frontales", fr = "frontaux", pt = "frontais", ru = "фронталки", de = "Frontals", pl = "frontale", hu = "frontálisok", sk = "frontály" }, -- Frontal attacks/abilities
	["cones"] = { lemma = "cones", es = "conos", fr = "cônes", pt = "cones", ru = "конусы", de = "Kegel", pl = "stożki", hu = "kúpok", sk = "kužele" }, -- Cone-shaped abilities
	["circles"] = { lemma = "circles", es = "círculos", fr = "cercles", pt = "círculos", ru = "круги", de = "Kreise", pl = "okręgi", hu = "körök", sk = "kruhy" }, -- Circular AoE
	["raid leading"] = { lemma = "raid leading", es = "liderazgo de raid", fr = "gestion de raid", pt = "liderança de raide", ru = "рейд-лидерство", de = "Schlachtzugsleitung", pl = "prowadzenie rajdu", hu = "raid vezetés", sk = "raid vedenie" },
	["healing stream"] = { lemma = "healing stream", es = "corriente de sanación", fr = "courant de soins", pt = "corrente de cura", ru = "поток исцеления", de = "Heilstrom", pl = "strumień leczenia", hu = "gyógyító patak", sk = "liečivý prúd" },
	["healing rain"] = { lemma = "healing rain", es = "lluvia de sanación", fr = "pluie de soins", pt = "chuva de cura", ru = "дождь исцеления", de = "Heilende Regen", pl = "deszcz leczenia", hu = "gyógyító eső", sk = "liečivý dážď" },
	["chain heal"] = { lemma = "chain heal", es = "cadena de sanación", fr = "chaîne de soins", pt = "cura encadeada", ru = "цепное исцеление", de = "Kettenheilung", pl = "łańcuchowe leczenie", hu = "láncgyógyítás", sk = "reťazové liečenie" },
	["flash heal"] = { lemma = "flash heal", es = "sanación relámpago", fr = "soin éclair", pt = "cura relâmpago", ru = "быстрое исцеление", de = "Blitzheilung", pl = "błyskawiczne leczenie", hu = "villámgyógyítás", sk = "bleskové liečenie" },
	["greater heal"] = { lemma = "greater heal", es = "sanación superior", fr = "soin supérieur", pt = "cura maior", ru = "великое исцеление", de = "Große Heilung", pl = "większe leczenie", hu = "nagyobb gyógyítás", sk = "väčšie liečenie" },
	["renew"] = { lemma = "renew", es = "renovar", fr = "rénover", pt = "renovar", ru = "обновить", de = "erneuern", pl = "odnowić", hu = "megújít", sk = "obnoviť" },
	["power word shield"] = { lemma = "power word shield", es = "palabra de poder escudo", fr = "mot de pouvoir bouclier", pt = "palavra de poder escudo", ru = "слово силы: щит", de = "Machtwort: Schild", pl = "słowo mocy: tarcza", hu = "erőszó pajzs", sk = "slovo sily: štít" },
	["divine hymn"] = { lemma = "divine hymn", es = "himno divino", fr = "hymne divin", pt = "hino divino", ru = "божественный гимн", de = "Göttlicher Hymnus", pl = "boski hymn", hu = "isteni himnusz", sk = "božská hymna" },
	["guardian spirit"] = { lemma = "guardian spirit", es = "espíritu guardián", fr = "esprit gardien", pt = "espírito guardião", ru = "дух хранитель", de = "Schutzgeist", pl = "duch stróż", hu = "őrző szellem", sk = "strážny duch" },
	["dispellable"] = { lemma = "dispellable", es = "disipable", fr = "dissipable", pt = "dispelável", ru = "снимаемый", de = "bannbar", pl = "możliwy do rozproszenia", hu = "oszlatható", sk = "rozptýliteľný" },
	["cleanse please"] = { lemma = "cleanse please", es = "limpiar por favor", fr = "purifiez s'il vous plaît", pt = "purificar por favor", ru = "снимите пожалуйста", de = "läutern bitte", pl = "oczyść proszę", hu = "tisztíts kérlek", sk = "očisti prosím" },
	["remove curse"] = { lemma = "remove curse", es = "quitar maldición", fr = "dissiper malédiction", pt = "remover maldição", ru = "снять проклятие", de = "Fluch aufheben", pl = "usuń klątwę", hu = "átok eltávolítása", sk = "odstrániť kliatbu" },
	["remove poison"] = { lemma = "remove poison", es = "quitar veneno", fr = "dissiper poison", pt = "remover veneno", ru = "снять яд", de = "Gift aufheben", pl = "usuń truciznę", hu = "méreg eltávolítása", sk = "odstrániť jed" },
	["remove disease"] = { lemma = "remove disease", es = "quitar enfermedad", fr = "dissiper maladie", pt = "remover doença", ru = "снять болезнь", de = "Krankheit aufheben", pl = "usuń chorobę", hu = "betegség eltávolítása", sk = "odstrániť chorobu" },
	["CC chain"] = { lemma = "CC chain", es = "cadena de CC", fr = "chaîne de CC", pt = "corrente de CC", ru = "цепочка контроля", de = "CC-Kette", pl = "łańcuch CC", hu = "CC lánc", sk = "CC reťaz" },
	["break CC"] = { lemma = "break CC", es = "romper CC", fr = "casser le CC", pt = "quebrar CC", ru = "сбить контроль", de = "CC brechen", pl = "przerwij CC", hu = "törj CC-t", sk = "preruš CC" },
	["interrupt this"] = { lemma = "interrupt this", es = "interrumpe esto", fr = "interrompez ceci", pt = "interrompa isto", ru = "прерви это", de = "unterbreche dies", pl = "przerwij to", hu = "ezt szakítsd félbe", sk = "preruš toto" },
	["on target"] = { lemma = "on target", es = "en objetivo", fr = "sur la cible", pt = "no alvo", ru = "на цели", de = "auf Ziel", pl = "na celu", hu = "célponton", sk = "na cieli" },
	["range check"] = { lemma = "range check", es = "chequeo de rango", fr = "vérification de portée", pt = "verificação de alcance", ru = "проверка дальности", de = "Reichweitenprüfung", pl = "sprawdzenie zasięgu", hu = "hatótáv ellenőrzés", sk = "kontrola dosahu" },
	["los pull"] = { lemma = "los pull", es = "pull por Los", fr = "pull LoS", pt = "puxar por LoS", ru = "пулл через ЛоС", de = "LOS-Pull", pl = "pull LOSem", hu = "LOS pull", sk = "LoS pull" },
	["agro range"] = { lemma = "aggro range", es = "rango de agro", fr = "portée d'aggro", pt = "alcance de aggro", ru = "дальность аггро", de = "Aggro-Reichweite", pl = "zasięg aggro", hu = "aggro hatótáv", sk = "aggro dosah" },
	["wipe it"] = { lemma = "wipe it", es = "wipear", fr = "wipez-le", pt = "wipear", ru = "вайпать", de = "wipen", pl = "zwippuj", hu = "wipe", sk = "wipe to" },
	["last boss"] = { lemma = "last boss", es = "último jefe", fr = "dernier boss", pt = "último boss", ru = "последний босс", de = "letzter Boss", pl = "ostatni boss", hu = "utolsó boss", sk = "posledný boss" },
	["next boss"] = { lemma = "next boss", es = "siguiente jefe", fr = "prochain boss", pt = "próximo boss", ru = "следующий босс", de = "nächster Boss", pl = "ďalší boss", hu = "következő boss", sk = "ďalší boss" },
	["alt run"] = { lemma = "alt run", es = "run de alts", fr = "run d'alts", pt = "run de alts", ru = "ран альтов", de = "Twink-Run", pl = "run altów", hu = "alt futás", sk = "alt run" },
	["fresh run"] = { lemma = "fresh run", es = "run fresco", fr = "run frais", pt = "run novo", ru = "свежий ран", de = "frischer Run", pl = "świeży run", hu = "friss futás", sk = "čerstvý run" },
	["raid lockout reset"] = { lemma = "raid lockout reset", es = "reinicio de bloqueo de raid", fr = "réinitialisation du verrouillage de raid", pt = "reset de lockout de raide", ru = "сброс локов рейда", de = "Schlachtzugssperren-Reset", pl = "reset blokady rajdu", hu = "raid zár reset", sk = "raid lockout reset" },
	["farm content"] = { lemma = "farm content", es = "contenido de farmeo", fr = "contenu de farm", pt = "conteúdo de farmeo", ru = "фарм контент", de = "Farm-Inhalt", pl = "zawartość do farmienia", hu = "farm tartalom", sk = "farm obsah" },
	["push content"] = { lemma = "push content", es = "contenido de push", fr = "contenu de push", pt = "conteúdo de push", ru = "пуш контент", de = "Push-Inhalt", pl = "zawartość do pushowania", hu = "push tartalom", sk = "push obsah" },
	["progression"] = { lemma = "progression", es = "progresión", fr = "progression", pt = "progressão", ru = "прогресс", de = "Progression", pl = "progres", hu = "progresszió", sk = "progresia" },
	["progression raid"] = { lemma = "progression raid", es = "raid de progresión", fr = "raid de progression", pt = "raid de progressão", ru = "прогрессионный рейд", de = "Progressions-Raid", pl = "rajd progresowy", hu = "progress raid", sk = "progresný raid" },
	["farm raid"] = { lemma = "farm raid", es = "raid de farmeo", fr = "raid de farm", pt = "raid de farmeo", ru = "фарм рейд", de = "Farm-Raid", pl = "rajd farm", hu = "farm raid", sk = "farm raid" },
	["carry run"] = { lemma = "carry run", es = "run de carry", fr = "run de carry", pt = "run de carry", ru = "керри ран", de = "Carry-Run", pl = "run carry", hu = "carry futás", sk = "carry run" },
	["boost run"] = { lemma = "boost run", es = "run de boost", fr = "run de boost", pt = "run de boost", ru = "буст ран", de = "Boost-Run", pl = "run boost", hu = "boost futás", sk = "boost run" },
	["GDKP"] = { lemma = "GDKP", es = "GDKP", fr = "GDKP", pt = "GDKP", ru = "ГДКП", de = "GDKP", pl = "GDKP", hu = "GDKP", sk = "GDKP" }, -- Gold DKP
	["soft res"] = { lemma = "soft res", es = "soft res", fr = "soft res", pt = "soft res", ru = "софт рез", de = "Soft Res", pl = "soft res", hu = "soft res", sk = "soft res" }, -- Soft Reserve
	["MS > OS"] = { lemma = "MS > OS", es = "MS > OS", fr = "MS > OS", pt = "MS > OS", ru = "МС > ОС", de = "MS > OS", pl = "MS > OS", hu = "MS > OS", sk = "MS > OS" }, -- Main Spec > Off Spec
	["Prio"] = { lemma = "Prio", es = "prioridad", fr = "prio", pt = "prioridade", ru = "приоритет", de = "Prio", pl = "prio", hu = "prio", sk = "prio" }, -- Priority
	["Trial"] = { lemma = "Trial", es = "prueba", fr = "essai", pt = "teste", ru = "трай", de = "Trial", pl = "próba", hu = "próba", sk = "skúška" },
	["bench"] = { lemma = "bench", es = "banquillo", fr = "banc", pt = "banco", ru = "скамейка", de = "Bank", pl = "ławka", hu = "pad", sk = "lavička" }, -- Sitting out of a raid
	["raid time"] = { lemma = "raid time", es = "hora de raid", fr = "heure de raid", pt = "hora de raide", ru = "рейд тайм", de = "Schlachtzugszeit", pl = "czas rajdu", hu = "raid idő", sk = "raid čas" },
	["raid day"] = { lemma = "raid day", es = "día de raid", fr = "jour de raid", pt = "dia de raide", ru = "рейд день", de = "Raid-Tag", pl = "dzień rajdu", hu = "raid nap", sk = "raid deň" },
	["raid lead"] = { lemma = "raid lead", es = "líder de raid", fr = "chef de raid", pt = "líder de raide", ru = "рейд лид", de = "Raid-Leiter", pl = "lider rajdu", hu = "raid vezető", sk = "raid vedúci" },
	["class leader"] = { lemma = "class leader", es = "líder de clase", fr = "chef de classe", pt = "líder de classe", ru = "лидер класса", de = "Klassenleiter", pl = "lider klasy", hu = "osztály vezető", sk = "triedny vedúci" },
	["loot master"] = { lemma = "loot master", es = "maestro de botín", fr = "maître du butin", pt = "mestre de saque", ru = "лут мастер", de = "Beutemeister", pl = "mistrz łupów", hu = "zsákmány mester", sk = "majster lúpu" },
	["DKP"] = { lemma = "DKP", es = "DKP", fr = "DKP", pt = "DKP", ru = "ДКП", de = "DKP", pl = "DKP", hu = "DKP", sk = "DKP" }, -- Dragon Kill Points
	["EPGP"] = { lemma = "EPGP", es = "EPGP", fr = "EPGP", pt = "EPGP", ru = "ЕПГП", de = "EPGP", pl = "EPGP", hu = "EPGP", sk = "EPGP" },
	["loot council"] = { lemma = "loot council", es = "consejo de botín", fr = "conseil de butin", pt = "conselho de saque", ru = "лут консил", de = "Beuterat", pl = "rada łupu", hu = "zsákmány tanács", sk = "rada lúpu" },
	["whisper me"] = { lemma = "whisper me", es = "susúrrame", fr = "chuchote-moi", pt = "sussurre-me", ru = "напиши в личку", de = "flüstere mir", pl = "szepnij mi", hu = "suttogj nekem", sk = "šepkaj mi" },
	["party chat"] = { lemma = "party chat", es = "chat de grupo", fr = "chat de groupe", pt = "chat de grupo", ru = "партийный чат", de = "Gruppenchat", pl = "czat party", hu = "parti chat", sk = "skupinový čet" },
	["raid chat"] = { lemma = "raid chat", es = "chat de raid", fr = "chat de raid", pt = "chat de raide", ru = "рейдовый чат", de = "Schlachtzugs-Chat", pl = "czat rajdowy", hu = "raid chat", sk = "raid čet" },
	["guild chat"] = { lemma = "guild chat", es = "chat de hermandad", fr = "chat de guilde", pt = "chat de guilda", ru = "гильдейский чат", de = "Gildenchat", pl = "czat gildii", hu = "céh chat", sk = "guild čet" },
	["officer chat"] = { lemma = "officer chat", es = "chat de oficiales", fr = "chat des officiers", pt = "chat de oficiais", ru = "офицерский чат", de = "Offizierschat", pl = "czat oficerów", hu = "tiszt chat", sk = "dôstojnícky čet" },
	["world chat"] = { lemma = "world chat", es = "chat de mundo", fr = "chat mondial", pt = "chat do mundo", ru = "мировой чат", de = "Weltchat", pl = "czat światowy", hu = "világ chat", sk = "svetový čet" },
	["general chat"] = { lemma = "general chat", es = "chat general", fr = "canal general", pt = "chat geral", ru = "общий чат", de = "Allgemeiner Chat", pl = "ogólny czat", hu = "általános chat", sk = "všeobecný čet" },
	["trade chat"] = { lemma = "trade chat", es = "chat de comercio", fr = "canal de commerce", pt = "chat de comércio", ru = "торговый чат", de = "Handelschat", pl = "czat handlowy", hu = "kereskedelmi chat", sk = "obchodný čet" },
	["lookingforgroup"] = { lemma = "lookingforgroup", es = "buscando grupo", fr = "recherche de groupe", pt = "procurando grupo", ru = "поиск группы", de = "Suche nach Gruppe", pl = "szukanie grupy", hu = "csoportot keres", sk = "hľadám skupinu" },
	["zone chat"] = { lemma = "zone chat", es = "chat de zona", fr = "chat de zone", pt = "chat de zona", ru = "зоновый чат", de = "Zonenchat", pl = "czat strefowy", hu = "zóna chat", sk = "zónový čet" },
	["emote chat"] = { lemma = "emote chat", es = "chat de gestos", fr = "chat d'emotes", pt = "chat de emotes", ru = "эмоциональный чат", de = "Emote-Chat", pl = "czat emotikon", hu = "érzelem chat", sk = "emotikony čet" },
	["say chat"] = { lemma = "say chat", es = "chat de decir", fr = "chat dire", pt = "chat de dizer", ru = "чат сказать", de = "Sagen-Chat", pl = "czat mów", hu = "mond chat", sk = "povedz čet" },
	["yell chat"] = { lemma = "yell chat", es = "chat de gritar", fr = "chat crier", pt = "chat de gritar", ru = "чат крик", de = "Schreien-Chat", pl = "czat krzycz", hu = "kiabálás chat", sk = "kričať čet" },
	["whisper chat"] = { lemma = "whisper chat", es = "chat de susurro", fr = "chat chuchoter", pt = "chat de sussurro", ru = "шепот чат", de = "Flüster-Chat", pl = "czat szept", hu = "suttogó chat", sk = "šepot čet" },
	["report player"] = { lemma = "report player", es = "reportar jugador", fr = "signaler joueur", pt = "denunciar jogador", ru = "пожаловаться на игрока", de = "Spieler melden", pl = "zgłoś gracza", hu = "játékos jelentése", sk = "nahlásiť hráča" },
	["ticket"] = { lemma = "ticket", es = "ticket", fr = "ticket", pt = "ticket", ru = "тикет", de = "Ticket", pl = "zgłoszenie", hu = "jegy", sk = "ticket" },
	["GM"] = { lemma = "GM", es = "MJ", fr = "MJ", pt = "MJ", ru = "ГМ", de = "GM", pl = "GM", hu = "GM", sk = "GM" }, -- Game Master
	["devs"] = { lemma = "devs", es = "devs", fr = "devs", pt = "desenvolvedores", ru = "разрабы", de = "Entwickler", pl = "deweloperzy", hu = "fejlesztők", sk = "vývojári" },
	["bug report"] = { lemma = "bug report", es = "reporte de bug", fr = "rapport de bug", pt = "relatório de bug", ru = "баг-репорт", de = "Bug-Report", pl = "zgłoszenie błędu", hu = "hiba jelentés", sk = "hlásenie chyby" },
	["server restart"] = { lemma = "server restart", es = "reinicio de servidor", fr = "redémarrage du serveur", pt = "reiniciar servidor", ru = "перезагрузка сервера", de = "Server-Neustart", pl = "restart serwera", hu = "szerver újraindítás", sk = "reštart servera" },
	["weekly reset"] = { lemma = "weekly reset", es = "reinicio semanal", fr = "réinitialisation hebdomadaire", pt = "reset semanal", ru = "еженедельный сброс", de = "wöchentlicher Reset", pl = "tygodniowy reset", hu = "heti reset", sk = "týždenný reset" },
	["daily reset"] = { lemma = "daily reset", es = "reinicio diario", fr = "réinitialisation quotidienne", pt = "reset diário", ru = "ежедневный сброс", de = "täglicher Reset", pl = "dzienny reset", hu = "napi reset", sk = "denný reset" },
	["exp gain"] = { lemma = "exp gain", es = "ganancia de exp", fr = "gain d'exp", pt = "ganho de xp", ru = "прирост опыта", de = "EP-Gewinn", pl = "zysk exp", hu = "exp nyereség", sk = "xp zisk" },
	["honor gain"] = { lemma = "honor gain", es = "ganancia de honor", fr = "gain d'honneur", pt = "ganho de honra", ru = "прирост хонора", de = "Ehre-Gewinn", pl = "zysk honoru", hu = "becsület nyereség", sk = "čestný zisk" },
	["gold gain"] = { lemma = "gold gain", es = "ganancia de oro", fr = "gain d'or", pt = "ganho de ouro", ru = "прирост золота", de = "Gold-Gewinn", pl = "zysk złota", hu = "arany nyereség", sk = "zlato zisk" },
	["rep gain"] = { lemma = "rep gain", es = "ganancia de reputación", fr = "gain de réputation", pt = "ganho de reputação", ru = "прирост репутации", de = "Ruf-Gewinn", pl = "zysk rep", hu = "rep nyereség", sk = "rep zisk" },
	["alt leveling"] = { lemma = "alt leveling", es = "subir de nivel alts", fr = "monter les alts", pt = "upar alts", ru = "прокачка альтов", de = "Twink leveln", pl = "levelowanie altów", hu = "alt szintezés", sk = "alt levelovanie" },
	["transmog run"] = { lemma = "transmog run", es = "run de transmog", fr = "run transmog", pt = "run de transmog", ru = "трансмог ран", de = "Transmog-Run", pl = "transmog run", hu = "transzmog futás", sk = "transmog run" },
	["mount run"] = { lemma = "mount run", es = "run de monturas", fr = "run monture", pt = "run de montarias", ru = "ран на маунтов", de = "Reittier-Run", pl = "run na mounty", hu = "mount futás", sk = "mount run" },
	["pet battle daily"] = { lemma = "pet battle daily", es = "diaria de duelo de mascotas", fr = "quotidienne de combat de mascottes", pt = "diária de batalha de mascotes", ru = "ежедневная битва питомцев", de = "Haustierkampf-Daily", pl = "dzienna walka zwierzaków", hu = "kisállat csata napi", sk = "denná bitka maznáčikov" },
	["auction house flips"] = { lemma = "auction house flips", es = "flips de casa de subastas", fr = "flips hôtel des ventes", pt = "flips de casa de leilões", ru = "перепродажа на ауке", de = "Auktionshaus-Flips", pl = "flippy na AH", hu = "AH flip", sk = "AH flippy" },
	["crafting cooldown"] = { lemma = "crafting cooldown", es = "reutilización de crafteo", fr = "temps de recharge d'artisanat", pt = "cooldown de criação", ru = "кд крафта", de = "Handwerks-Abklingzeit", pl = "cooldown craftingu", hu = "kézműves CD", sk = "výrobný cooldown" },
	["profession cap"] = { lemma = "profession cap", es = "límite de profesión", fr = "plafond de profession", pt = "cap de profissão", ru = "кап профессии", de = "Berufs-Cap", pl = "limit profesji", hu = "szakma sapka", sk = "profesia cap" },
	["garrison missions"] = { lemma = "garrison missions", es = "misiones de ciudadela", fr = "missions de fief", pt = "missões de guarnição", ru = "миссии гарнизона", de = "Garnisonsmissionen", pl = "misje garnizonowe", hu = "helyőrség küldetések", sk = "posádkové misie" },
	["order hall missions"] = { lemma = "order hall missions", es = "misiones de sede de clase", fr = "missions de domaine de classe", pt = "missões de salão da ordem", ru = "миссии штаба класса", de = "Ordenshallen-Missionen", pl = "misje siedziby zakonu", hu = "rendi terem küldetések", sk = "misie siene rádu" },
	["covenant abilities"] = { lemma = "covenant abilities", es = "habilidades de pacto", fr = "capacités de congrégation", pt = "habilidades de pacto", ru = "способности ковенанта", de = "Paktfähigkeiten", pl = "zdolności paktu", hu = "szövetség képességek", sk = "paktové schopnosti" },
	["azerite armor"] = { lemma = "azerite armor", es = "armadura de azerita", fr = "armure d'azérite", pt = "armadura de azerita", ru = "азеритовая броня", de = "Azeritrüstung", pl = "azerytowy pancerz", hu = "azerit páncél", sk = "azeritové brnenie" },
	["corrupted gear"] = { lemma = "corrupted gear", es = "equipo corrupto", fr = "équipement corrompu", pt = "equipamento corrompido", ru = "испорченная экипировка", de = "Verderbtes Ausrüstung", pl = "skażony sprzęt", hu = "korrumpált felszerelés", sk = "skazená výstroj" },
	["essences slot"] = { lemma = "essences slot", es = "ranura de esencias", fr = "emplacement d'essences", pt = "espaço de essências", ru = "слот эссенций", de = "Essenzen-Platz", pl = "slot esencji", hu = "esszencia slot", sk = "slot esencie" },
	["conduit energy"] = { lemma = "conduit energy", es = "energía de conducto", fr = "énergie de conduit", pt = "energia de conduíte", ru = "энергия проводника", de = "Leitungsenergie", pl = "energia przewodu", hu = "vezeték energia", sk = "vodivá energia" },
	["legendary item"] = { lemma = "legendary item", es = "objeto legendario", fr = "objet légendaire", pt = "item lendário", ru = "легендарный предмет", de = "Legendärer Gegenstand", pl = "legendarny przedmiot", hu = "legendás tárgy", sk = "legendárny predmet" },
	["tier token"] = { lemma = "tier token", es = "ficha de tier", fr = "jeton de palier", pt = "ficha de tier", ru = "токен тира", de = "Tier-Token", pl = "żeton tieru", hu = "tier token", sk = "tier žetón" },
	["set bonus active"] = { lemma = "set bonus active", es = "bonificación de conjunto activa", fr = "bonus de set actif", pt = "bônus de conjunto ativo", ru = "бонус сета активен", de = "Setbonus aktiv", pl = "bonus zestawu aktywny", hu = "szett bónusz aktív", sk = "set bonus aktívny" },
	["trinket usage"] = { lemma = "trinket usage", es = "uso de abalorio", fr = "utilisation de bijou", pt = "uso de trinket", ru = "использование триньки", de = "Schmuckstück-Nutzung", pl = "użycie trinketu", hu = "trinket használat", sk = "použitie trinketu" },
	["consumables stock"] = { lemma = "consumables stock", es = "stock de consumibles", fr = "stock de consommables", pt = "estoque de consumíveis", ru = "запас расходников", de = "Verbrauchsgegenstände-Bestand", pl = "zapas consumable'i", hu = "fogyasztó készlet", sk = "zásoba spotrebných" },
	["raid strategy"] = { lemma = "raid strategy", es = "estrategia de raid", fr = "stratégie de raid", pt = "estratégia de raide", ru = "рейд стратегия", de = "Schlachtzugsstrategie", pl = "strategia rajdu", hu = "raid stratégia", sk = "raid stratégia" },
	["boss strategy"] = { lemma = "boss strategy", es = "estrategia de jefe", fr = "stratégie de boss", pt = "estratégia de boss", ru = "стратегия босса", de = "Boss-Strategie", pl = "strategia bossa", hu = "boss stratégia", sk = "boss stratégia" },
	["add control"] = { lemma = "add control", es = "control de adds", fr = "contrôle des adds", pt = "controle de adds", ru = "контроль аддов", de = "Add-Kontrolle", pl = "kontrola addów", hu = "add kontroll", sk = "kontrola addov" },
	["phase transition"] = { lemma = "phase transition", es = "transición de fase", fr = "transition de phase", pt = "transição de fase", ru = "переход фазы", de = "Phasenübergang", pl = "przejście fazy", hu = "fázis átmenet", sk = "prechod fázy" },
	["soft reset"] = { lemma = "soft reset", es = "reinicio suave", fr = "réinitialisation douce", pt = "reset suave", ru = "софт ресет", de = "Soft Reset", pl = "miękki reset", hu = "soft reset", sk = "mäkký reset" },
	["hard reset"] = { lemma = "hard reset", es = "reinicio duro", fr = "réinitialisation dure", pt = "reset forte", ru = "хард ресет", de = "Hard Reset", pl = "twardy reset", hu = "hard reset", sk = "tvrdý reset" },
	["pull timing"] = { lemma = "pull timing", es = "tiempo de pull", fr = "timing du pull", pt = "tempo de pull", ru = "время пулла", de = "Pull-Timing", pl = "czas pulla", hu = "pull időzítés", sk = "pull načasovanie" },
	["group up here"] = { lemma = "group up here", es = "agrupense aquí", fr = "groupez-vous ici", pt = "agrupe-se aqui", ru = "собирайтесь здесь", de = "hier gruppieren", pl = "zbierzcie się tutaj", hu = "itt csoportosulj", sk = "zoskupte sa tu" },
	["stay spread"] = { lemma = "stay spread", es = "manténganse dispersos", fr = "restez dispersés", pt = "fique espalhado", ru = "оставайтесь разойдясь", de = "verteilt bleiben", pl = "pozostańcie rozproszeni", hu = "maradj szétterülve", sk = "zostaňte rozostúpení" },
	["move out of void"] = { lemma = "move out of void", es = "sal del vacío", fr = "sortez du vide", pt = "saia do vazio", ru = "выйди из войда", de = "aus dem Void gehen", pl = "wyjdź z pustki", hu = "menj ki az űrből", sk = "vyhni sa prázdnote" },
	["avoid damage"] = { lemma = "avoid damage", es = "evita el daño", fr = "évitez les dégâts", pt = "evite o dano", ru = "избегай урона", de = "Schaden vermeiden", pl = "unikaj obrażeń", hu = "kerüld a sebzést", sk = "vyhni sa poškodeniu" },
	["interrupt priority"] = { lemma = "interrupt priority", es = "prioridad de interrupción", fr = "priorité d'interruption", pt = "prioridade de interrupção", ru = "приоритет прерывания", de = "Unterbrechungspriorität", pl = "priorytet interrupta", hu = "megszakítási prioritás", sk = "priorita prerušenia" },
	["off tank taunt"] = { lemma = "off tank taunt", es = "taunt del off tank", fr = "taunt du off tank", pt = "taunt do off tank", ru = "таунт офф танка", de = "Off-Tank-Hohn", pl = "taunt off tanka", hu = "off tank taunt", sk = "off tank taunt" },
	["main tank taunt"] = { lemma = "main tank taunt", es = "taunt del main tank", fr = "taunt du main tank", pt = "taunt do main tank", ru = "таунт мейн танка", de = "Main-Tank-Hohn", pl = "taunt main tanka", hu = "fő tank taunt", sk = "main tank taunt" },
	["target marker"] = { lemma = "target marker", es = "marcador de objetivo", fr = "marqueur de cible", pt = "marcador de alvo", ru = "метка цели", de = "Zielmarker", pl = "znacznik celu", hu = "céljelző", sk = "cieľový značkovač" },
	["raid warning"] = { lemma = "raid warning", es = "aviso de raid", fr = "avertissement de raid", pt = "aviso de raide", ru = "рейд предупреждение", de = "Schlachtzugswarnung", pl = "ostrzeżenie rajdowe", hu = "raid figyelmeztetés", sk = "raid upozornenie" },
	["guild bank"] = { lemma = "guild bank", es = "banco de hermandad", fr = "banque de guilde", pt = "banco de guilda", ru = "гильд банк", de = "Gildenbank", pl = "bank gildyjny", hu = "céh bank", sk = "guild banka" },
	["guild vault"] = { lemma = "guild vault", es = "cámara de hermandad", fr = "coffre de guilde", pt = "cofre de guilda", ru = "гильд хранилище", de = "Gildentruhe", pl = "skrytka gildii", hu = "céh kincstár", sk = "guild trezor" },
	["PvP talent"] = { lemma = "PvP talent", es = "talento JcJ", fr = "talent PvP", pt = "talento PvP", ru = "ПвП талант", de = "PvP-Talent", pl = "talent PvP", hu = "PvP talent", sk = "PvP talent" },
	["PvE talent"] = { lemma = "PvE talent", es = "talento JcE", fr = "talent PvE", pt = "talento PvE", ru = "ПвЕ талант", de = "PvE-Talent", pl = "talent PvE", hu = "PvE talent", sk = "PvE talent" },
	["off-hand weapon"] = { lemma = "off-hand weapon", es = "arma de mano izquierda", fr = "arme de main gauche", pt = "arma da mão esquerda", ru = "оффхенд оружие", de = "Schildhand-Waffe", pl = "broń off-hand", hu = "mellék kéz fegyver", sk = "off-hand zbraň" },
	["main-hand weapon"] = { lemma = "main-hand weapon", es = "arma de mano derecha", fr = "arme de main droite", pt = "arma da mão direita", ru = "мейнхенд оружие", de = "Haupthand-Waffe", pl = "broń main-hand", hu = "fő kéz fegyver", sk = "main-hand zbraň" },
	["two-handed weapon"] = { lemma = "two-handed weapon", es = "arma a dos manos", fr = "arme à deux mains", pt = "arma de duas mãos", ru = "двуручное оружие", de = "zweihändige Waffe", pl = "broń dwuręczna", hu = "kétkezes fegyver", sk = "dvojručná zbraň" },
	["one-handed weapon"] = { lemma = "one-handed weapon", es = "arma a una mano", fr = "arme à une mano", pt = "arma de uma mão", ru = "одноручное оружие", de = "einhändige Waffe", pl = "broń jednoręczna", hu = "egykezes fegyver", sk = "jednoručná zbraň" },
	["gear grind"] = { lemma = "gear grind", es = "grindeo de equipo", fr = "farm d'équipement", pt = "grind de equipamento", ru = "фарм шмота", de = "Gear grind", pl = "farm sprzętu", hu = "felszerelés grind", sk = "gear grind" },
	["talent build advice"] = { lemma = "talent build advice", es = "consejo de build de talentos", fr = "conseil de build de talents", pt = "conselho de build de talentos", ru = "совет по билду талантов", de = "Talent-Build-Beratung", pl = "porada co do buildu talentów", hu = "talent build tanács", sk = "talent build rada" },
	["glyph setup advice"] = { lemma = "glyph setup advice", es = "consejo de configuración de glifos", fr = "conseil de configuration de glyphes", pt = "conselho de configuração de glifos", ru = "совет по сетапу глифов", de = "Glyphen-Setup-Beratung", pl = "porada co do ustawienia glifów", hu = "glifa setup tanács", sk = "glyf setup rada" },
	["gemming strategy"] = { lemma = "gemming strategy", es = "estrategia de engemado", fr = "stratégie de gemmage", pt = "estratégia de gemagem", ru = "стратегия окамнения", de = "Sockelstrategie", pl = "strategia gemowania", hu = "gemmelési stratégia", sk = "gemovanie stratégia" },
	["enchanting materials"] = { lemma = "enchanting materials", es = "materiales de encantamiento", fr = "matériaux d'enchantement", pt = "materiais de encantamento", ru = "материалы для зачарования", de = "Verzauberungsmaterialien", pl = "materiały do zaklinania", hu = "elbűvölő anyagok", sk = "očarovacie materiály" },

	-- Additional words for ChatTranslator Addon (Continued - General Conversation)

	-- Greetings and Closings (more variations)
	["hey"] = { lemma = "hey", es = "hola", fr = "salut", pt = "oi", ru = "привет", de = "hey", pl = "hej", hu = "szia", sk = "ahoj" },
	["what's good"] = { lemma = "what's good", es = "qué hay", fr = "quoi de bon", pt = "qual é a boa", ru = "что хорошего", de = "was geht ab", pl = "co jest dobrego", hu = "mi van", sk = "čo je dobré" },
	["how's it going"] = { lemma = "how's it going", es = "cómo va todo", fr = "comment ça va", pt = "como está indo", ru = "как дела", de = "wie läuft's", pl = "jak leci", hu = "hogy megy", sk = "ako sa máš" },
	["long time no see"] = { lemma = "long time no see", es = "cuánto tiempo sin verte", fr = "ça fait longtemps", pt = "há quanto tempo", ru = "давно не виделись", de = "lange nicht gesehen", pl = "dawno się nie widzieliśmy", hu = "rég nem láttuk egymást", sk = "dlho sme sa nevideli" },
	["catch you later"] = { lemma = "catch you later", es = "te veo luego", fr = "à plus tard", pt = "te pego mais tarde", ru = "увидимся позже", de = "bis später", pl = "do zobaczenia później", hu = "később találkozunk", sk = "uvidíme sa neskôr" },
	["take care"] = { lemma = "take care", es = "cuídate", fr = "prends soin de toi", pt = "cuidado", ru = "береги себя", de = "pass auf dich auf", pl = "trzymaj się", hu = "vigyázz magadra", sk = "dávaj si pozor" },

	-- Common Expressions and Filler Words
	["like that"] = { lemma = "like that", es = "así", fr = "comme ça", pt = "assim", ru = "так", de = "so", pl = "tak", hu = "így", sk = "tak" },
	["you know"] = { lemma = "you know", es = "sabes", fr = "tu sais", pt = "você sabe", ru = "ты знаешь", de = "du weißt", pl = "wiesz", hu = "tudod", sk = "vieš" },
	["I mean"] = { lemma = "I mean", es = "quiero decir", fr = "je veux dire", pt = "quero dizer", ru = "я имею в виду", de = "ich meine", pl = "to znaczy", hu = "úgy értem", sk = "myslím" },
	["actually"] = { lemma = "actually", es = "en realidad", fr = "en fait", pt = "na verdade", ru = "на самом деле", de = "tatsächlich", pl = "właściwie", hu = "valójában", sk = "vlastne" },
	["basically"] = { lemma = "basically", es = "básicamente", fr = "en gros", pt = "basicamente", ru = "в основном", de = "im Grunde", pl = "zasadniczo", hu = "alapvetően", sk = "v podstate" },
	["definitely not"] = { lemma = "definitely not", es = "definitivamente no", fr = "certainement pas", pt = "definitivamente não", ru = "точно нет", de = "auf keinen Fall", pl = "na pewno nie", hu = "egyáltalán nem", sk = "určite nie" },
	["for sure"] = { lemma = "for sure", es = "seguro", fr = "sûr", pt = "com certeza", ru = "точно", de = "sicher", pl = "na pewno", hu = "biztosan", sk = "určite" },
	["I guess"] = { lemma = "I guess", es = "supongo", fr = "je suppose", pt = "eu acho", ru = "я полагаю", de = "ich schätze", pl = "chyba", hu = "azt hiszem", sk = "asi" },
	["right away"] = { lemma = "right away", es = "enseguida", fr = "tout de suite", pt = "imediatamente", ru = "сразу же", de = "sofort", pl = "natychmiast", hu = "azonnal", sk = "okamžite" },
	["all good"] = { lemma = "all good", es = "todo bien", fr = "tout va bien", pt = "tudo bem", ru = "всё хорошо", de = "alles gut", pl = "wszystko w porządku", hu = "minden rendben", sk = "všetko v poriadku" },
	["never mind"] = { lemma = "never mind", es = "no importa", fr = "laisse tomber", pt = "deixa pra lá", ru = "неважно", de = "egal", pl = "nie ważne", hu = "mindegy", sk = "nevadi" },
	["it depends"] = { lemma = "it depends", es = "depende", fr = "ça dépend", pt = "depende", ru = "зависит", de = "es kommt darauf an", pl = "zależy", hu = "függ", sk = "závisí" },
	["sounds good to me"] = { lemma = "sounds good to me", es = "me parece bien", fr = "ça me va", pt = "me parece bom", ru = "меня устраивает", de = "klingt gut für mich", pl = "brzmi dobrze dla mnie", hu = "nekem jó", sk = "to znie dobre" },
	["hang on"] = { lemma = "hang on", es = "espera", fr = "attends", pt = "espere", ru = "подожди", de = "warte mal", pl = "zaczekaj", hu = "várj", sk = "počkaj" },
	["no problem at all"] = { lemma = "no problem at all", es = "sin ningún problema", fr = "aucun problème du tout", pt = "nenhum problema", ru = "совсем без проблем", de = "überhaupt kein Problem", pl = "żadnego problemu", hu = "egyáltalán nem probléma", sk = "žiaden problém" },
	["you bet"] = { lemma = "you bet", es = "claro que sí", fr = "bien sûr", pt = "pode apostar", ru = "конечно", de = "darauf kannst du wetten", pl = "jasne", hu = "fogadjunk", sk = "jasné" },

	-- Questions and Clarifications
	["what else"] = { lemma = "what else", es = "qué más", fr = "quoi d'autre", pt = "o que mais", ru = "что ещё", de = "was noch", pl = "co jeszcze", hu = "mi más", sk = "čo ešte" },
	["anything new"] = { lemma = "anything new", es = "algo nuevo", fr = "du nouveau", pt = "algo novo", ru = "что-нибудь новое", de = "etwas Neues", pl = "coś nowego", hu = "valami új", sk = "niečo nové" },
	["are you sure"] = { lemma = "are you sure", es = "estás seguro", fr = "es-tu sûr", pt = "você tem certeza", ru = "ты уверен", de = "bist du sicher", pl = "jesteś pewien", hu = "biztos vagy benne", sk = "si si istý" },
	["can you hear me"] = { lemma = "can you hear me", es = "puedes oírme", fr = "tu m'entends", pt = "você pode me ouvir", ru = "ты меня слышишь", de = "hörst du mich", pl = "słyszysz mnie", hu = "hallasz", sk = "počuješ ma" },
	["is everything okay"] = { lemma = "is everything okay", es = "está todo bien", fr = "tout va bien", pt = "está tudo bem", ru = "всё в порядке", de = "ist alles in Ordnung", pl = "wszystko w porządku", hu = "minden rendben van", sk = "je všetko v poriadku" },
	["do you understand"] = { lemma = "do you understand", es = "entiendes", fr = "tu comprends", pt = "você entende", ru = "ты понимаешь", de = "verstehst du", pl = "rozumiesz", hu = "érted", sk = "rozumieš" },
	["what's your plan"] = { lemma = "what's your plan", es = "cuál es tu plan", fr = "quel est ton plan", pt = "qual é o seu plano", ru = "какой у тебя план", de = "was ist dein Plan", pl = "jaki jest twój plan", hu = "mi a terved", sk = "aký je tvoj plán" },
	["how does that work"] = { lemma = "how does that work", es = "cómo funciona eso", fr = "comment ça marche", pt = "como isso funciona", ru = "как это работает", de = "wie funktioniert das", pl = "jak to działa", hu = "hogy működik", sk = "ako to funguje" },

	-- Reactions and Affirmations
	["exactly that"] = { lemma = "exactly that", es = "exactamente eso", fr = "exactement ça", pt = "exatamente isso", ru = "именно это", de = "genau das", pl = "dokładnie to", hu = "pontosan az", sk = "presne to" },
	["totally agree"] = { lemma = "totally agree", es = "totalmente de acuerdo", fr = "tout à fait d'accord", pt = "totalmente de acordo", ru = "полностью согласен", de = "stimme vollkommen zu", pl = "całkowicie się zgadzam", hu = "teljesen egyetértek", sk = "úplne súhlasím" },
	["for sure"] = { lemma = "for sure", es = "seguro", fr = "sûr", pt = "com certeza", ru = "точно", de = "sicher", pl = "na pewno", hu = "biztosan", sk = "určite" },
	["you're right"] = { lemma = "you're right", es = "tienes razón", fr = "tu as raison", pt = "você está certo", ru = "ты прав", de = "du hast Recht", pl = "masz rację", hu = "igazad van", sk = "máš pravdu" },
	["I agree"] = { lemma = "I agree", es = "estoy de acuerdo", fr = "je suis d'accord", pt = "eu concordo", ru = "я согласен", de = "ich stimme zu", pl = "zgadzam się", hu = "egyetértek", sk = "súhlasím" },
	["gotcha"] = { lemma = "gotcha", es = "te entiendo", fr = "j'ai compris", pt = "entendi", ru = "понял", de = "verstanden", pl = "rozumiem", hu = "értem", sk = "chápem" },
	["alright then"] = { lemma = "alright then", es = "de acuerdo entonces", fr = "d'accord alors", pt = "tudo bem então", ru = "ну ладно", de = "alles klar dann", pl = "no dobrze", hu = "rendben akkor", sk = "dobre teda" },
	["sounds like a plan"] = { lemma = "sounds like a plan", es = "suena a plan", fr = "ça a l'air d'un plan", pt = "parece um plano", ru = "похоже на план", de = "klingt nach einem Plan", pl = "brzmi jak plan", hu = "tervnek tűnik", sk = "znie to ako plán" },
	["that's good"] = { lemma = "that's good", es = "eso es bueno", fr = "c'est bien", pt = "isso é bom", ru = "это хорошо", de = "das ist gut", pl = "to dobrze", hu = "ez jó", sk = "to je dobré" },
	["that's bad"] = { lemma = "that's bad", es = "eso es malo", fr = "c'est mauvais", pt = "isso é ruim", ru = "это плохо", de = "das ist schlecht", pl = "to źle", hu = "ez rossz", sk = "to je zlé" },
	["that's true"] = { lemma = "that's true", es = "eso es cierto", fr = "c'est vrai", pt = "isso é verdade", ru = "это правда", de = "das stimmt", pl = "to prawda", hu = "ez igaz", sk = "to je pravda" },
	["not really"] = { lemma = "not really", es = "no realmente", fr = "pas vraiment", pt = "não muito", ru = "не совсем", de = "nicht wirklich", pl = "nie bardzo", hu = "nem igazán", sk = "nie tak celkom" },
	["sort of"] = { lemma = "sort of", es = "más o menos", fr = "en quelque sorte", pt = "mais ou menos", ru = "вроде того", de = "irgendwie", pl = "jakoś", hu = "valahogy", sk = "nejako" },
	["kind of"] = { lemma = "kind of", es = "algo así", fr = "un peu", pt = "meio que", ru = "вроде того", de = "sozusagen", pl = "trochę", hu = "valahogy", sk = "tak trochu" },
	["I think so too"] = { lemma = "I think so too", es = "yo también lo creo", fr = "je pense aussi", pt = "eu também acho", ru = "я тоже так думаю", de = "das denke ich auch", pl = "też tak myślę", hu = "én is azt hiszem", sk = "aj ja si to myslím" },
	["fair enough"] = { lemma = "fair enough", es = "justo", fr = "assez juste", pt = "justo", ru = "справедливо", de = "fair genug", pl = "w porządku", hu = "elég igazságos", sk = "spravodlivé" },
	["makes sense to me"] = { lemma = "makes sense to me", es = "tiene sentido para mí", fr = "ça a du sens pour moi", pt = "faz sentido para mim", ru = "мне это понятно", de = "macht Sinn für mich", pl = "ma dla mnie sens", hu = "nekem van értelme", sk = "dáva mi zmysel" },

	-- Requests and Offers
	["can I help"] = { lemma = "can I help", es = "puedo ayudar", fr = "je peux aider", pt = "posso ajudar", ru = "могу помочь", de = "kann ich helfen", pl = "czy mogę pomóc", hu = "segíthetek", sk = "môžem pomôcť" },
	["do you need anything"] = { lemma = "do you need anything", es = "necesitas algo", fr = "as-tu besoin de quelque chose", pt = "você precisa de algo", ru = "тебе что-нибудь нужно", de = "brauchst du etwas", pl = "potrzebujesz czegoś", hu = "szükséged van valamire", sk = "potrebuješ niečo" },
	["let me know"] = { lemma = "let me know", es = "házmelo saber", fr = "fais-moi savoir", pt = "me avise", ru = "дай мне знать", de = "sag Bescheid", pl = "daj mi znać", hu = "tudasd velem", sk = "daj mi vedieť" },
	["I'll try"] = { lemma = "I'll try", es = "lo intentaré", fr = "j'essaierai", pt = "vou tentar", ru = "я попробую", de = "ich versuche es", pl = "spróbuję", hu = "megpróbálom", sk = "pokúsim sa" },
	["I'll do my best"] = { lemma = "I'll do my best", es = "haré lo mejor que pueda", fr = "je ferai de mon mieux", pt = "farei o meu melhor", ru = "я сделаю всё возможное", de = "ich gebe mein Bestes", pl = "zrobię co w mojej mocy", hu = "mindent megteszek", sk = "urobím čo najlepšie" },
	["can we"] = { lemma = "can we", es = "podemos", fr = "pouvons-nous", pt = "podemos", ru = "мы можем", de = "können wir", pl = "czy możemy", hu = "tudunk", sk = "môžeme" },
	["should we"] = { lemma = "should we", es = "deberíamos", fr = "devrions-nous", pt = "deveríamos", ru = "нам следует", de = "sollten wir", pl = "czy powinniśmy", hu = "kellene", sk = "mali by sme" },
	["I'm ready"] = { lemma = "I'm ready", es = "estoy listo", fr = "je suis prêt", pt = "estou pronto", ru = "я готов", de = "ich bin bereit", pl = "jestem gotowy", hu = "kész vagyok", sk = "som pripravený" },
	["I'm not ready"] = { lemma = "I'm not ready", es = "no estoy listo", fr = "je ne suis pas prêt", pt = "não estou pronto", ru = "я не готов", de = "ich bin nicht bereit", pl = "nie jestem gotowy", hu = "nem vagyok kész", sk = "nie som pripravený" },
	["give me a moment"] = { lemma = "give me a moment", es = "dame un momento", fr = "donne-moi un instant", pt = "me dê um momento", ru = "дай мне минуту", de = "gib mir einen Moment", pl = "daj mi chwilę", hu = "adj egy pillanatot", sk = "daj mi chvíľu" },
	["one sec"] = { lemma = "one sec", es = "un segundo", fr = "une seconde", pt = "um segundo", ru = "одну секунду", de = "eine Sekunde", pl = "jedną sekundę", hu = "egy pillanat", sk = "sekundu" },
	["coming soon"] = { lemma = "coming soon", es = "próximamente", fr = "bientôt", pt = "em breve", ru = "скоро", de = "bald", pl = "wkrótce", hu = "hamarosan", sk = "čoskoro" },
	["ETA"] = { lemma = "ETA", es = "ETA", fr = "ETA", pt = "ETA", ru = "ОЖВ", de = "ETA", pl = "ETA", hu = "ETA", sk = "ETA" }, -- Estimated Time of Arrival

	-- Expressing Emotion/State
	["I'm tired"] = { lemma = "I'm tired", es = "estoy cansado", fr = "je suis fatigué", pt = "estou cansado", ru = "я устал", de = "ich bin müde", pl = "jestem zmęczony", hu = "fáradt vagyok", sk = "som unavený" },
	["I'm hungry"] = { lemma = "I'm hungry", es = "tengo hambre", fr = "j'ai faim", pt = "estou com fome", ru = "я голоден", de = "ich habe Hunger", pl = "jestem głodny", hu = "éhes vagyok", sk = "som hladný" },
	["I'm thirsty"] = { lemma = "I'm thirsty", es = "tengo sed", fr = "j'ai soif", pt = "estou com sede", ru = "я хочу пить", de = "ich habe Durst", pl = "jestem spragniony", hu = "szomjas vagyok", sk = "som smädný" },
	["feeling good"] = { lemma = "feeling good", es = "me siento bien", fr = "je me sens bien", pt = "me sentindo bem", ru = "чувствую себя хорошо", de = "fühle mich gut", pl = "czuję się dobrze", hu = "jól érzem magam", sk = "cítim sa dobre" },
	["feeling bad"] = { lemma = "feeling bad", es = "me siento mal", fr = "je me sens mal", pt = "me sentindo mal", ru = "чувствую себя плохо", de = "fühle mich schlecht", pl = "czuję się źle", hu = "rosszul érzem magam", sk = "cítim sa zle" },
	["stressed"] = { lemma = "stressed", es = "estresado", fr = "stressé", pt = "estressado", ru = "в стрессе", de = "gestresst", pl = "zestresowany", hu = "stresszes", sk = "v strese" },
	["relaxed"] = { lemma = "relaxed", es = "relajado", fr = "détendu", pt = "relaxado", ru = "расслабленный", de = "entspannt", pl = "zrelaksowany", hu = "nyugodt", sk = "uvoľnený" },
	["excited"] = { lemma = "excited", es = "emocionado", fr = "excité", pt = "animado", ru = "взволнован", de = "aufgeregt", pl = "podekscytowany", hu = "izgatott", sk = "nadšený" },
	["bored"] = { lemma = "bored", es = "aburrido", fr = "ennuyé", pt = "entediado", ru = "скучно", de = "gelangweilt", pl = "znudzony", hu = "unatkozó", sk = "znudený" },
	["happy"] = { lemma = "happy", es = "feliz", fr = "heureux", pt = "feliz", ru = "счастливый", de = "glücklich", pl = "szczęśliwy", hu = "boldog", sk = "šťastný" },
	["sad"] = { lemma = "sad", es = "triste", fr = "triste", pt = "triste", ru = "грустный", de = "traurig", pl = "smutny", hu = "szomorú", sk = "smutný" },

	-- General World of Warcraft Phrases
	["leveling up"] = { lemma = "leveling up", es = "subiendo de nivel", fr = "montée de niveau", pt = "subindo de nível", ru = "качаюсь", de = "leveln", pl = "levelowanie", hu = "szintezés", sk = "levelovanie" },
	["grinding mobs"] = { lemma = "grinding mobs", es = "farmeando mobs", fr = "farm de mobs", pt = "farmando mobs", ru = "гринжу мобов", de = "Mobs grinden", pl = "farmienie mobów", hu = "mob grindolás", sk = "farmenie mobov" },
	["doing dailies"] = { lemma = "doing dailies", es = "haciendo diarias", fr = "faisant les journalières", pt = "fazendo diárias", ru = "делаю дейлики", de = "Dailys machen", pl = "robię daily", hu = "napikat csinálok", sk = "robím denné" },
	["farming mats"] = { lemma = "farming mats", es = "farmeando materiales", fr = "farm de matériaux", pt = "farmando materiais", ru = "фармлю маты", de = "Mats farmen", pl = "farmienie matów", hu = "anyagot farmolok", sk = "farmím suroviny" },
	["looking for groups"] = { lemma = "looking for groups", es = "buscando grupos", fr = "recherche de groupes", pt = "procurando grupos", ru = "ищу группы", de = "Suche Gruppen", pl = "szukam grup", hu = "csoportokat keresek", sk = "hľadám skupiny" },
	["doing quests"] = { lemma = "doing quests", es = "haciendo misiones", fr = "faisant des quêtes", pt = "fazendo missões", ru = "делаю квесты", de = "Quests machen", pl = "robię zadania", hu = "küldetéseket csinálok", sk = "robím úlohy" },
	["heading to"] = { lemma = "heading to", es = "dirigiéndome a", fr = "direction", pt = "indo para", ru = "направляюсь в", de = "gehe nach", pl = "idę do", hu = "tartok", sk = "smerujem do" },
	["on my way to"] = { lemma = "on my way to", es = "en camino a", fr = "en route pour", pt = "a caminho de", ru = "по пути в", de = "auf dem Weg zu", pl = "w drodze do", hu = "úton vagyok", sk = "na ceste do" },
	["waiting for raid"] = { lemma = "waiting for raid", es = "esperando raid", fr = "attente raid", pt = "esperando raide", ru = "жду рейда", de = "warte auf Raid", pl = "czekam na rajd", hu = "raidre várok", sk = "čakám na raid" },
	["waiting for dungeon"] = { lemma = "waiting for dungeon", es = "esperando mazmorra", fr = "attente donjon", pt = "esperando masmorra", ru = "жду данжа", de = "warte auf Dungeon", pl = "czekam na loch", hu = "kazamatára várok", sk = "čakám na žalár" },
	["need to go AFK"] = { lemma = "need to go AFK", es = "necesito ir AFK", fr = "besoin d'aller AFK", pt = "preciso ir AFK", ru = "нужно отойти", de = "muss AFK gehen", pl = "muszę iść AFK", hu = "AFK-ba kell mennem", sk = "musím ísť AFK" },
	["I'm back"] = { lemma = "I'm back", es = "ya volví", fr = "je suis de retour", pt = "voltei", ru = "я вернулся", de = "ich bin zurück", pl = "wróciłem", hu = "visszatértem", sk = "som späť" },
	["just finished"] = { lemma = "just finished", es = "acabo de terminar", fr = "je viens de finir", pt = "acabei de terminar", ru = "только что закончил", de = "gerade fertig geworden", pl = "właśnie skończyłem", hu = "épp befejeztem", sk = "práve som skončil" },
	["what's next"] = { lemma = "what's next", es = "qué sigue", fr = "quelle est la suite", pt = "o que vem a seguir", ru = "что дальше", de = "was als Nächstes", pl = "co dalej", hu = "mi a következő", sk = "čo ďalej" },
	["any tips"] = { lemma = "any tips", es = "algún consejo", fr = "des conseils", pt = "alguma dica", ru = "какие-нибудь советы", de = "irgendwelche Tipps", pl = "jakieś wskazówki", hu = "valami tipp", sk = "nejaké tipy" },
	["good luck with that"] = { lemma = "good luck with that", es = "buena suerte con eso", fr = "bonne chance avec ça", pt = "boa sorte com isso", ru = "удачи с этим", de = "viel Glück dabei", pl = "powodzenia z tym", hu = "sok szerencsét hozzá", sk = "veľa šťastia s tým" },
	["wish me luck"] = { lemma = "wish me luck", es = "deséame suerte", fr = "souhaite-moi bonne chance", pt = "me deseje sorte", ru = "пожелай мне удачи", de = "wünsch mir Glück", pl = "życz mi szczęścia", hu = "kívánj szerencsét", sk = "želaj mi šťastie" },
	["thanks for asking"] = { lemma = "thanks for asking", es = "gracias por preguntar", fr = "merci d'avoir demandé", pt = "obrigado por perguntar", ru = "спасибо, что спросил", de = "danke der Nachfrage", pl = "dzięki za pytanie", hu = "köszönöm a kérdést", sk = "ďakujem za otázku" },
	["you're welcome"] = { lemma = "you're welcome", es = "de nada", fr = "de rien", pt = "de nada", ru = "пожалуйста", de = "gern geschehen", pl = "proszę bardzo", hu = "szívesen", sk = "nemáš začo" },
	["have fun gaming"] = { lemma = "have fun gaming", es = "que te diviertas jugando", fr = "amuse-toi bien en jouant", pt = "divirta-se jogando", ru = "приятной игры", de = "viel Spaß beim Zocken", pl = "dobrej zabawy w grze", hu = "jó szórakozást játék közben", sk = "príjemnú zábavu pri hraní" },
	["nice to meet you"] = { lemma = "nice to meet you", es = "encantado de conocerte", fr = "ravi de te rencontrer", pt = "prazer em conhecê-lo", ru = "приятно познакомиться", de = "schön dich kennenzulernen", pl = "miło cię poznać", hu = "örülök, hogy megismerhettelek", sk = "rád ťa spoznávam" },
	["same here"] = { lemma = "same here", es = "a mí también", fr = "moi aussi", pt = "o mesmo aqui", ru = "мне тоже", de = "mir auch", pl = "mi też", hu = "én is", sk = "aj ja" },
	["no worries at all"] = { lemma = "no worries at all", es = "sin preocupaciones", fr = "pas de soucis du tout", pt = "nenhum problema", ru = "вообще без проблем", de = "keine Sorge überhaupt nicht", pl = "bez obaw", hu = "egyáltalán nem aggódom", sk = "žiadne starosti vôbec" },
	["any time"] = { lemma = "any time", es = "cuando quieras", fr = "n'importe quand", pt = "a qualquer hora", ru = "в любое время", de = "jederzeit", pl = "w każdej chwili", hu = "bármikor", sk = "kedykoľvek" },
	["what are you up to"] = { lemma = "what are you up to", es = "qué haces", fr = "qu'est-ce que tu fais", pt = "o que você está fazendo", ru = "что ты делаешь", de = "was machst du so", pl = "co robisz", hu = "mit csinálsz", sk = "čo robíš" },
	["how was your day"] = { lemma = "how was your day", es = "cómo estuvo tu día", fr = "comment s'est passée ta journée", pt = "como foi seu dia", ru = "как прошёл твой день", de = "wie war dein Tag", pl = "jak minął ci dzień", hu = "milyen volt a napod", sk = "ako sa mal tvoj deň" },
	["just chilling"] = { lemma = "just chilling", es = "relajándome", fr = "juste en train de me détendre", pt = "só relaxando", ru = "просто отдыхаю", de = "einfach chillen", pl = "tylko odpoczywam", hu = "csak lazulok", sk = "len tak chillujem" },
	["taking a break"] = { lemma = "taking a break", es = "tomando un descanso", fr = "faisant une pause", pt = "fazendo uma pausa", ru = "делаю перерыв", de = "eine Pause machen", pl = "robię przerwę", hu = "szünetet tartok", sk = "robím si prestávku" },
	["be right back"] = { lemma = "be right back", es = "enseguida vuelvo", fr = "je reviens tout de suite", pt = "volto já", ru = "сейчас вернусь", de = "bin gleich zurück", pl = "zaraz wracam", hu = "azonnal jövök", sk = "hned som späť" },
	["one moment please"] = { lemma = "one moment please", es = "un momento por favor", fr = "un instant s'il vous plaît", pt = "um momento por favor", ru = "одну минуту пожалуйста", de = "einen Moment bitte", pl = "jedną chwilę proszę", hu = "egy pillanatot kérek", sk = "chvíľku prosím" },
	["got some time"] = { lemma = "got some time", es = "tienes tiempo", fr = "tu as du temps", pt = "tem tempo", ru = "есть время", de = "hast du Zeit", pl = "masz czas", hu = "van időd", sk = "máš čas" },
	["what's the deal"] = { lemma = "what's the deal", es = "cuál es el trato", fr = "c'est quoi le problème", pt = "qual é o problema", ru = "в чём дело", de = "was ist los", pl = "o co chodzi", hu = "mi a helyzet", sk = "čo sa deje" },
	["hit me up"] = { lemma = "hit me up", es = "contáctame", fr = "contacte-moi", pt = "me chame", ru = "напиши мне", de = "meld dich bei mir", pl = "odezwij się", hu = "keress meg", sk = "ozvi sa mi" },
	["shoot me a message"] = { lemma = "shoot me a message", es = "mándame un mensaje", fr = "envoie-moi un message", pt = "me mande uma mensagem", ru = "напиши мне сообщение", de = "schreib mir eine Nachricht", pl = "napisz do mnie", hu = "küldj egy üzenetet", sk = "pošli mi správu" },
	["talk to you later"] = { lemma = "talk to you later", es = "hablamos luego", fr = "on se parle plus tard", pt = "falo com você depois", ru = "поговорим позже", de = "sprechen wir später", pl = "pogadam z tobą później", hu = "később beszélünk", sk = "porozprávame sa neskôr" },
	["cheers everyone"] = { lemma = "cheers everyone", es = "saludos a todos", fr = "salut tout le monde", pt = "saúde a todos", ru = "всем привет", de = "Prost zusammen", pl = "zdrowie wszystkim", hu = "egészségére mindenkinek", sk = "na zdravie všetkým" },
	["good times"] = { lemma = "good times", es = "buenos momentos", fr = "bons moments", pt = "bons momentos", ru = "хорошие времена", de = "gute Zeiten", pl = "dobre czasy", hu = "jó idők", sk = "dobré časy" },
	["fun stuff"] = { lemma = "fun stuff", es = "cosas divertidas", fr = "trucs amusants", pt = "coisas divertidas", ru = "веселье", de = "lustige Sachen", pl = "fajne rzeczy", hu = "szórakoztató dolgok", sk = "zábavné veci" },
	["keep it up"] = { lemma = "keep it up", es = "sigue así", fr = "continue comme ça", pt = "continue assim", ru = "так держать", de = "mach weiter so", pl = "tak trzymaj", hu = "így tovább", sk = "len tak ďalej" },
	["nice work"] = { lemma = "nice work", es = "buen trabajo", fr = "beau travail", pt = "bom trabalho", ru = "хорошая работа", de = "gute Arbeit", pl = "dobra robota", hu = "jó munka", sk = "dobrá práca" },
	["well done"] = { lemma = "well done", es = "bien hecho", fr = "bien joué", pt = "bem feito", ru = "молодец", de = "gut gemacht", pl = "dobrze zrobione", hu = "jól van", sk = "dobre urobené" },
	["that's awesome"] = { lemma = "that's awesome", es = "eso es genial", fr = "c'est génial", pt = "isso é incrível", ru = "это потрясающе", de = "das ist super", pl = "to świetnie", hu = "ez fantasztikus", sk = "to je úžasné" },
	["epic fail"] = { lemma = "epic fail", es = "fallo épico", fr = "échec épique", pt = "falha épica", ru = "эпический провал", de = "epischer Fehler", pl = "epicka porażka", hu = "epikus kudarc", sk = "epický prešľap" },
	["my bad on that"] = { lemma = "my bad on that", es = "mi culpa por eso", fr = "ma faute pour ça", pt = "erro meu nisso", ru = "моя вина в этом", de = "mein Fehler dabei", pl = "moja wina w tym", hu = "az én hibám volt", sk = "moja chyba v tom" },
	["can't believe it"] = { lemma = "can't believe it", es = "no puedo creerlo", fr = "je n'y crois pas", pt = "não consigo acreditar", ru = "не могу поверить", de = "ich kann es nicht glauben", pl = "nie mogę w to uwierzyć", hu = "nem hiszem el", sk = "nemôžem uveriť" },
	["seriously"] = { lemma = "seriously", es = "en serio", fr = "sérieusement", pt = "sério", ru = "серьёзно", de = "ernsthaft", pl = "poważnie", hu = "komolyan", sk = "vážne" },
	["what the heck"] = { lemma = "what the heck", es = "qué demonios", fr = "c'est quoi ce délire", pt = "que diabos", ru = "какого чёрта", de = "was zum Teufel", pl = "co do cholery", hu = "mi a fene", sk = "čo to do pekla" },
	["GGWP"] = { lemma = "GGWP", es = "GGWP", fr = "GGWP", pt = "GGWP", ru = "ГГВП", de = "GGWP", pl = "GGWP", hu = "GGWP", sk = "GGWP" }, -- Good game, well played
	["GLHF"] = { lemma = "GLHF", es = "GLHF", fr = "GLHF", pt = "GLHF", ru = "ГЛХФ", de = "GLHF", pl = "GLHF", hu = "GLHF", sk = "GLHF" }, -- Good luck, have fun
	["AFK farming"] = { lemma = "AFK farming", es = "farmeando AFK", fr = "farm AFK", pt = "farmando AFK", ru = "АФК фарм", de = "AFK farmen", pl = "farmienie AFK", hu = "AFK farmolás", sk = "AFK farmenie" },
	["downtime"] = { lemma = "downtime", es = "tiempo de inactividad", fr = "temps mort", pt = "tempo de inatividade", ru = "даунтайм", de = "Auszeit", pl = "przestój", hu = "állásidő", sk = "prestoje" },
	["burst damage"] = { lemma = "burst damage", es = "daño explosivo", fr = "dégâts en rafale", pt = "dano de explosão", ru = "бурстовый урон", de = "Burst-Schaden", pl = "obrażenia seryjne", hu = "burst sebzés", sk = "burst poškodenie" },
	["sustained damage"] = { lemma = "sustained damage", es = "daño sostenido", fr = "dégâts soutenus", pt = "dano sustentado", ru = "постоянный урон", de = "konstanter Schaden", pl = "ciągłe obrażenia", hu = "fenntartott sebzés", sk = "trvalé poškodenie" },
	["raid buffs"] = { lemma = "raid buffs", es = "buffs de raid", fr = "buffs de raid", pt = "buffs de raide", ru = "рейдовые баффы", de = "Raid-Buffs", pl = "buffy rajdowe", hu = "raid buffok", sk = "raid buffy" },
	["raid debuffs"] = { lemma = "raid debuffs", es = "debuffs de raid", fr = "debuffs de raid", pt = "debuffs de raide", ru = "рейдовые дебаффы", de = "Raid-Debuffs", pl = "debuffy rajdowe", hu = "raid debuffok", sk = "raid debuffy" },
	["healing rotation"] = { lemma = "healing rotation", es = "rotación de curación", fr = "rotation de soins", pt = "rotação de cura", ru = "ротация хила", de = "Heilrotation", pl = "rotacja leczenia", hu = "gyógyítási rotáció", sk = "rotácia liečenia" },
	["tank rotation"] = { lemma = "tank rotation", es = "rotación de tanques", fr = "rotation de tanks", pt = "rotação de tanques", ru = "ротация танков", de = "Tankrotation", pl = "rotacja tanków", hu = "tank rotáció", sk = "tank rotácia" },
	["dps"] = { lemma = "dps", en = "dps", es = "dps", fr = "dps", pt = "dps", ru = "дпс", de = "dps", pl = "dps", hu = "dps", sk = "dps" },
	["dd"] = { lemma = "dd", en = "dd", es = "dd", fr = "dd", pt = "dd", ru = "дд", de = "dd", pl = "dd", hu = "dd", sk = "dd" },
	["dps rotation"] = { lemma = "dps rotation", es = "rotación de dps", fr = "rotation de dps", pt = "rotação de dps", ru = "ротация дпс", de = "DPS-Rotation", pl = "rotacja DPS", hu = "DPS rotáció", sk = "DPS rotácia" },
	["trash pull"] = { lemma = "trash pull", es = "pull de basura", fr = "pull de trash", pt = "pull de lixo", ru = "пулл трэша", de = "Trash-Pull", pl = "pull śmieci", hu = "trash pull", sk = "trash pull" },
	["boss pull"] = { lemma = "boss pull", es = "pull de jefe", fr = "pull de boss", pt = "pull de boss", ru = "пулл босса", de = "Boss-Pull", pl = "pull bossa", hu = "boss pull", sk = "boss pull" },
	["on cooldowns"] = { lemma = "on cooldowns", es = "con reutilizaciones", fr = "avec cooldowns", pt = "com cooldowns", ru = "на кулдаунах", de = "auf Cooldowns", pl = "na cooldownach", hu = "cooldownokon", sk = "na cooldownoch" },
	["pop all CDs"] = { lemma = "pop all CDs", es = "usa todos los CDs", fr = "utilisez tous les CDs", pt = "use todos os CDs", ru = "используй все кд", de = "alle CDs zünden", pl = "użyj wszystkich CD", hu = "használd az összes CD-t", sk = "použi všetky CD" },
	["save for boss"] = { lemma = "save for boss", es = "guarda para el jefe", fr = "gardez pour le boss", pt = "salve para o boss", ru = "береги для босса", de = "für Boss aufheben", pl = "zachowaj na bossa", hu = "bossra tartogasd", sk = "šetri na bossa" },
	["raid marker"] = { lemma = "raid marker", es = "marcador de raid", fr = "marqueur de raid", pt = "marcador de raide", ru = "рейд маркер", de = "Schlachtzugsmarkierung", pl = "znacznik rajdu", hu = "raid jelző", sk = "raid značka" },
	["world marker"] = { lemma = "world marker", es = "marcador de mundo", fr = "marqueur mondial", pt = "marcador de mundo", ru = "мировой маркер", de = "Weltmarkierung", pl = "znacznik świata", hu = "világ jelző", sk = "svetová značka" },
	["skull target"] = { lemma = "skull target", es = "marcar cráneo", fr = "cible crâne", pt = "marcar alvo", ru = "метка черепа", de = "Schädel-Ziel", pl = "cel czaszka", hu = "koponya célpont", sk = "cieľ lebka" },
	["cross target"] = { lemma = "cross target", es = "marcar cruz", fr = "cible croix", pt = "marcar cruz", ru = "метка креста", de = "Kreuz-Ziel", pl = "cel krzyż", hu = "kereszt célpont", sk = "cieľ kríž" },
	["moon target"] = { lemma = "moon target", es = "marcar luna", fr = "cible lune", pt = "marcar lua", ru = "метка луны", de = "Mond-Ziel", pl = "cel księżyc", hu = "hold célpont", sk = "cieľ mesiac" },
	["star target"] = { lemma = "star target", es = "marcar estrella", fr = "cible étoile", pt = "marcar estrela", ru = "метка звезды", de = "Stern-Ziel", pl = "cel gwiazda", hu = "csillag célpont", sk = "cieľ hviezda" },
	["square target"] = { lemma = "square target", es = "marcar cuadrado", fr = "cible carré", pt = "marcar quadrado", ru = "метка квадрата", de = "Quadrat-Ziel", pl = "cel kwadrat", hu = "négyzet célpont", sk = "cieľ štvorec" },
	["triangle target"] = { lemma = "triangle target", es = "marcar triángulo", fr = "cible triangle", pt = "marcar triângulo", ru = "метка треугольника", de = "Dreieck-Ziel", pl = "cel trójkąt", hu = "háromszög célpont", sk = "cieľ trojuholník" },
	["diamond target"] = { lemma = "diamond target", es = "marcar diamante", fr = "cible losange", pt = "marcar diamante", ru = "метка ромба", de = "Raute-Ziel", pl = "cel romb", hu = "gyémánt célpont", sk = "cieľ kosoštvorec" },
	["circle target"] = { lemma = "circle target", es = "marcar círculo", fr = "cible cercle", pt = "marcar círculo", ru = "метка круга", de = "Kreis-Ziel", pl = "cel okrąg", hu = "kör célpont", sk = "cieľ kruh" },
	["incoming pull"] = { lemma = "incoming pull", es = "pull entrante", fr = "pull en approche", pt = "pull chegando", ru = "входящий пул", de = "ankommender Pull", pl = "nadchodzący pull", hu = "közelgő pull", sk = "prichádzajúci pull" },
	["clear adds"] = { lemma = "clear adds", es = "limpiar adds", fr = "nettoyer les adds", pt = "limpar adds", ru = "зачистить аддов", de = "Adds beseitigen", pl = "wyczyść addy", hu = "tisztítsd meg az addokat", sk = "vyčisti addy" },
	["run to me"] = { lemma = "run to me", es = "ven a mí", fr = "cours vers moi", pt = "corra para mim", ru = "беги ко мне", de = "lauf zu mir", pl = "biegnij do mnie", hu = "fuss hozzám", sk = "bež ku mne" },
	["stay close to healer"] = { lemma = "stay close to healer", es = "mantente cerca del sanador", fr = "restez près du soigneur", pt = "fique perto do curandeiro", ru = "держись рядом с хилом", de = "bleib nah am Heiler", pl = "zostań blisko healera", hu = "maradj közel a gyógyítóhoz", sk = "zostaň blízko liečiteľa" },
	["pop CDs"] = { lemma = "pop CDs", es = "usa CDs", fr = "utilisez les CDs", pt = "use os CDs", ru = "используй кд", de = "CDs zünden", pl = "użyj CD", hu = "használd a CD-ket", sk = "použi CD" },
	["rez range"] = { lemma = "rez range", es = "rango de rez", fr = "portée de rez", pt = "alcance de rez", ru = "радиус реса", de = "Rez-Reichweite", pl = "zasięg respa", hu = "rez hatótáv", sk = "rez dosah" },
	["drink up"] = { lemma = "drink up", es = "bebe", fr = "bois", pt = "beba", ru = "пей", de = "trinkt aus", pl = "pij", hu = "igyál", sk = "pi" },
	["eat food"] = { lemma = "eat food", es = "come comida", fr = "mange de la nourriture", pt = "coma comida", ru = "ешь еду", de = "iss Essen", pl = "jedz jedzenie", hu = "egyél", sk = "jedz jedlo" },
	["rest here"] = { lemma = "rest here", es = "descansa aquí", fr = "reposez-vous ici", pt = "descanse aqui", ru = "отдыхай здесь", de = "hier ausruhen", pl = "odpocznij tutaj", hu = "itt pihenj", sk = "odpočívaj tu" },
	["take a break"] = { lemma = "take a break", es = "toma un descanso", fr = "fais une pause", pt = "faça uma pausa", ru = "сделай перерыв", de = "mach eine Pause", pl = "zrób przerwę", hu = "tarts szünetet", sk = "daj si prestávku" },
	["wait for mana"] = { lemma = "wait for mana", es = "espera el mana", fr = "attends le mana", pt = "espere a mana", ru = "жди ману", de = "auf Mana warten", pl = "czekaj na manę", hu = "várj a manára", sk = "počkaj na manu" },
	["wait for cooldowns"] = { lemma = "wait for cooldowns", es = "espera los cds", fr = "attends les cooldowns", pt = "espere os cooldowns", ru = "жди кд", de = "auf Cooldowns warten", pl = "czekaj na cooldowny", hu = "várj a CD-kre", sk = "počkaj na cooldowny" },
	["clear trash"] = { lemma = "clear trash", es = "limpiar basura", fr = "nettoyer le trash", pt = "limpar lixo", ru = "зачистить трэш", de = "Trash clearen", pl = "wyczyść śmieci", hu = "tisztítsd meg a trash-t", sk = "vyčisti trash" },
	["skip trash"] = { lemma = "skip trash", es = "saltar basura", fr = "sauter le trash", pt = "pular lixo", ru = "пропустить трэш", de = "Trash überspringen", pl = "omiń trash", hu = "ugorj át trash-t", sk = "preskoč trash" },
	["pull big"] = { lemma = "pull big", es = "pull grande", fr = "gros pull", pt = "puxar grande", ru = "большой пул", de = "großen Pull machen", pl = "pulluj dużo", hu = "nagy pull", sk = "ťahaj veľké" },
	["pull small"] = { lemma = "pull small", es = "pull pequeño", fr = "petit pull", pt = "puxar pequeno", ru = "маленький пул", de = "kleinen Pull machen", pl = "pulluj mało", hu = "kis pull", sk = "ťahaj malé" },
	["aggro all"] = { lemma = "aggro all", es = "aggro a todos", fr = "aggro tout le monde", pt = "aggro todos", ru = "аггро всех", de = "alle aggro ziehen", pl = "aggro wszystkich", hu = "mindenkit aggro-zz", sk = "aggro všetkých" },
	["group heal"] = { lemma = "group heal", es = "sanación de grupo", fr = "soin de groupe", pt = "cura de grupo", ru = "групповой хил", de = "Gruppenheilung", pl = "leczenie grupowe", hu = "csoportos gyógyítás", sk = "skupinové liečenie" },
	["single heal"] = { lemma = "single heal", es = "sanación individual", fr = "soin individuel", pt = "cura individual", ru = "единичный хил", de = "Einzelheilung", pl = "pojedyncze leczenie", hu = "egyedi gyógyítás", sk = "jednotlivé liečenie" },
	["raid wide damage"] = { lemma = "raid wide damage", es = "daño a todo el raid", fr = "dégâts à tout le raid", pt = "dano em todo o raide", ru = "урон по рейду", de = "Raid-weiter Schaden", pl = "obrażenia na cały rajd", hu = "raid szintű sebzés", sk = "raid poškodenie" },
	["target swap"] = { lemma = "target swap", es = "cambio de objetivo", fr = "changement de cible", pt = "troca de alvo", ru = "смена цели", de = "Zielwechsel", pl = "zmiana celu", hu = "célpont csere", sk = "výmena cieľa" },
	["focus healer"] = { lemma = "focus healer", es = "enfocar sanador", fr = "focus soigneur", pt = "focar curandeiro", ru = "фокус хилера", de = "Heiler fokusieren", pl = "skup się na healerze", hu = "gyógyítóra fókuszál", sk = "sústreď sa na liečiteľa" },
	["focus DPS"] = { lemma = "focus DPS", es = "enfocar DPS", fr = "focus DPS", pt = "focar DPS", ru = "фокус ДПС", de = "DPS fokusieren", pl = "skup się na DPS", hu = "DPS-re fókuszál", sk = "sústreď sa na DPS" },
	["focus tank"] = { lemma = "focus tank", es = "enfocar tanque", fr = "focus tank", pt = "focar tanque", ru = "фокус танка", de = "Tank fokusieren", pl = "skup się na tanku", hu = "tankra fókuszál", sk = "sústreď sa na tanka" },
	["AoE stun"] = { lemma = "AoE stun", es = "aturdimiento en área", fr = "étourdissement de zone", pt = "atordoamento em área", ru = "АоЕ стан", de = "AoE-Betäubung", pl = "ogłuszenie obszarowe", hu = "AoE kábítás", sk = "plošné omráčenie" },
	["AoE silence"] = { lemma = "AoE silence", es = "silencio en área", fr = "silence de zone", pt = "silenciar em área", ru = "АоЕ сайленс", de = "AoE-Stille", pl = "uciszenie obszarowe", hu = "AoE csend", sk = "plošné umlčanie" },
	["AoE root"] = { lemma = "AoE root", es = "enraizar en área", fr = "enracinement de zone", pt = "enraizar em área", ru = "АоЕ рут", de = "AoE-Wurzeln", pl = "zakorzenienie obszarowe", hu = "AoE gyökerezés", sk = "plošné zakorenenie" },
	["fear bomb"] = { lemma = "fear bomb", es = "bomba de miedo", fr = "bombe de peur", pt = "bomba de medo", ru = "фир бомба", de = "Furcht-Bombe", pl = "bomba strachu", hu = "félelem bomba", sk = "fear bomba" },
	["mana break"] = { lemma = "mana break", es = "descanso de mana", fr = "pause mana", pt = "pausa de mana", ru = "перерыв на ману", de = "Mana-Pause", pl = "przerwa na manę", hu = "mana szünet", sk = "mana prestávka" },
	["hp pot"] = { lemma = "hp pot", es = "poción de vida", fr = "potion de vie", pt = "poção de vida", ru = "хп пот", de = "HP-Trank", pl = "mikstura HP", hu = "hp ital", sk = "hp elixír" },
	["flask"] = { lemma = "flask", es = "frasco", fr = "flacon", pt = "frasco", ru = "фласка", de = "Fläschchen", pl = "flakon", hu = "flakon", sk = "fľaška" },
	["elixir"] = { lemma = "elixir", es = "elixir", fr = "élixir", pt = "elixir", ru = "эликсир", de = "Elixier", pl = "eliksir", hu = "elixír", sk = "elixír" },
	["gear check"] = { lemma = "gear check", es = "chequeo de equipo", fr = "vérification d'équipement", pt = "verificação de equipamento", ru = "проверка гира", de = "Ausrüstungs-Check", pl = "sprawdzenie sprzętu", hu = "felszerelés ellenőrzés", sk = "kontrola výstroja" },
	["BIS list"] = { lemma = "BIS list", es = "lista BIS", fr = "liste BIS", pt = "lista BIS", ru = "БИС лист", de = "BIS-Liste", pl = "lista BIS", hu = "BIS lista", sk = "BIS zoznam" },
	["pre-potting now"] = { lemma = "pre-potting now", es = "pre-poteando ahora", fr = "pré-potion maintenant", pt = "pré-potenciando agora", ru = "сейчас пре-потим", de = "jetzt vor-potten", pl = "pre-potuję teraz", hu = "most pre-potolok", sk = "predpotujem teraz" },
	["pull in 3"] = { lemma = "pull in 3", es = "pull en 3", fr = "pull dans 3", pt = "puxar em 3", ru = "пулл через 3", de = "Pull in 3", pl = "pull za 3", hu = "pull 3", sk = "pull za 3" },
	["pull in 2"] = { lemma = "pull in 2", es = "pull en 2", fr = "pull dans 2", pt = "puxar em 2", ru = "пулл через 2", de = "Pull in 2", pl = "pull za 2", hu = "pull 2", sk = "pull za 2" },
	["pull in 1"] = { lemma = "pull in 1", es = "pull en 1", fr = "pull dans 1", pt = "puxar em 1", ru = "пулл через 1", de = "Pull in 1", pl = "pull za 1", hu = "pull 1", sk = "pull za 1" },
	["tanking now"] = { lemma = "tanking now", es = "tanqueando ahora", fr = "tanking maintenant", pt = "tankando agora", ru = "танкую сейчас", de = "tanken jetzt", pl = "tankuję teraz", hu = "most tankolok", sk = "tankujem teraz" },
	["healing now"] = { lemma = "healing now", es = "curando ahora", fr = "soignant maintenant", pt = "curando agora", ru = "хилю сейчас", de = "heilen jetzt", pl = "leczę teraz", hu = "most gyógyítok", sk = "liečim teraz" },
	["dpsing now"] = { lemma = "dpsing now", es = "haciendo dps ahora", fr = "dps maintenant", pt = "dpsando agora", ru = "дпсю сейчас", de = "dpsen jetzt", pl = "dpsuję teraz", hu = "most sebzem", sk = "dpsím teraz" },
	["on my way up"] = { lemma = "on my way up", es = "en camino hacia arriba", fr = "en chemin vers le haut", pt = "a caminho para cima", ru = "иду вверх", de = "auf dem Weg nach oben", pl = "w drodze na górę", hu = "felfelé megyek", sk = "na ceste hore" },
	["on my way down"] = { lemma = "on my way down", es = "en camino hacia abajo", fr = "en chemin vers le bas", pt = "a caminho para baixo", ru = "иду вниз", de = "auf dem Weg nach unten", pl = "w drodze na dół", hu = "lefelé megyek", sk = "na ceste dole" },
	["at the entrance"] = { lemma = "at the entrance", es = "en la entrada", fr = "à l'entrée", pt = "na entrada", ru = "у входа", de = "am Eingang", pl = "przy wejściu", hu = "a bejáratnál", sk = "pri vchode" },
	["at the exit"] = { lemma = "at the exit", es = "en la salida", fr = "à la sortie", pt = "na saída", ru = "у выхода", de = "am Ausgang", pl = "przy wyjściu", hu = "a kijáratnál", sk = "pri východe" },
	["pulling next"] = { lemma = "pulling next", es = "siguiente pull", fr = "pull suivant", pt = "próximo pull", ru = "следующий пул", de = "nächster Pull", pl = "następny pull", hu = "következő pull", sk = "ďalší pull" },
	["target the one with"] = { lemma = "target the one with", es = "apunta al que tiene", fr = "ciblez celui avec", pt = "alvo o que tem", ru = "цель того, у кого", de = "ziel den mit", pl = "celuj w tego z", hu = "célozd azt, akinél", sk = "zacieľ toho s" },
	["kill priority"] = { lemma = "kill priority", es = "prioridad de eliminación", fr = "priorité de tuer", pt = "prioridade de abate", ru = "приоритет убийства", de = "Kill-Priorität", pl = "priorytet zabijania", hu = "gyilkolási prioritás", sk = "priorita zabíjania" },
	["kite it to me"] = { lemma = "kite it to me", es = "kitealo hacia mí", fr = "kite-le vers moi", pt = "kite-o para mim", ru = "кайти его ко мне", de = "kite es zu mir", pl = "kite'uj to do mnie", hu = "kite-old hozzám", sk = "kite to ku mne" },
	["line of sight pull"] = { lemma = "line of sight pull", es = "pull por línea de visión", fr = "pull en ligne de mire", pt = "puxar por linha de visão", ru = "пулл по ЛоС", de = "Line-of-Sight Pull", pl = "pull na linii wzroku", hu = "látómező pull", sk = "LoS pull" },
	["need a rez here"] = { lemma = "need a rez here", es = "necesito un rez aquí", fr = "besoin d'un rez ici", pt = "preciso de um rez aqui", ru = "нужен рез здесь", de = "brauche hier einen Rez", pl = "potrzebuję reza tutaj", hu = "itt kell egy rez", sk = "potrebujem rez tu" },
	["rez on tank"] = { lemma = "rez on tank", es = "rez en tanque", fr = "rez sur le tank", pt = "rez no tanque", ru = "рез на танка", de = "Rez auf Tank", pl = "rez na tanku", hu = "tankra rez", sk = "rez na tanka" },
	["rez on healer"] = { lemma = "rez on healer", es = "rez en curador", fr = "rez sur le soigneur", pt = "rez no curandeiro", ru = "рез на хила", de = "Rez auf Heiler", pl = "rez na healera", hu = "gyógyítóra rez", sk = "rez na liečiteľa" },
	["regen mana"] = { lemma = "regen mana", es = "regenerar mana", fr = "régénérer mana", pt = "regenerar mana", ru = "регенить ману", de = "Mana regenerieren", pl = "regeneruj manę", hu = "mana regen", sk = "regen mana" },
	["pop bloodlust"] = { lemma = "pop bloodlust", es = "usar sed de sangre", fr = "utiliser furie sanguinaire", pt = "usar sede de sangue", ru = "использовать бл", de = "Blutdurst zünden", pl = "użyj bloodlust", hu = "használd a vérszomjat", sk = "použi krvožíznivosť" },
	["pop heroism"] = { lemma = "pop heroism", es = "usar heroísmo", fr = "utiliser héroïsme", pt = "usar heroísmo", ru = "использовать героизм", de = "Heldenmut zünden", pl = "użyj heroizmu", hu = "használd a hősiességet", sk = "použi hrdinstvo" },
	["timer for"] = { lemma = "timer for", es = "temporizador para", fr = "minuteur pour", pt = "timer para", ru = "таймер для", de = "Timer für", pl = "czasomierz na", hu = "időzítő ehhez", sk = "časovač pre" },
	["boss timer"] = { lemma = "boss timer", es = "temporizador de jefe", fr = "minuteur de boss", pt = "timer de boss", ru = "таймер босса", de = "Boss-Timer", pl = "czasomierz bossa", hu = "boss időzítő", sk = "boss časovač" },
	["addon settings"] = { lemma = "addon settings", es = "ajustes del addon", fr = "paramètres de l'addon", pt = "configurações do addon", ru = "настройки аддона", de = "Addon-Einstellungen", pl = "ustawienia addonu", hu = "kiegészítő beállítások", sk = "nastavenia doplnku" },
	["talent build help"] = { lemma = "talent build help", es = "ayuda con build de talentos", fr = "aide pour build de talents", pt = "ajuda com build de talentos", ru = "помощь по билду талантов", de = "Talent-Build-Hilfe", pl = "pomoc z buildem talentów", hu = "talent build segítség", sk = "talent build pomoc" },
	["glyph setup help"] = { lemma = "glyph setup help", es = "ayuda con configuración de glifos", fr = "aide pour configuration de glyphes", pt = "ajuda com configuração de glifos", ru = "помощь по сетапу глифов", de = "Glyphen-Setup-Hilfe", pl = "pomoc z ustawieniem glifów", hu = "glifa setup segítség", sk = "glyf setup pomoc" },
	["profession guide"] = { lemma = "profession guide", es = "guía de profesión", fr = "guide de profession", pt = "guia de profissão", ru = "гайд по профессии", de = "Berufsführer", pl = "poradnik profesji", hu = "szakma útmutató", sk = "profesijný sprievodca" },
	["have"] = { lemma = "have", es = "tener", fr = "avoir", pt = "ter", ru = "иметь", de = "haben", pl = "mieć", hu = "birtokol", sk = "mať" },
    	["I have"] = { lemma = "have", es = "tengo", fr = "j'ai", pt = "eu tenho", ru = "у меня есть", de = "ich habe", pl = "mam", hu = "nekem van", sk = "mám" },
    	["do"] = { lemma = "do", es = "hacer", fr = "faire", pt = "fazer", ru = "делать", de = "tun", pl = "robić", hu = "csinál", sk = "robiť" },
    	["I do"] = { lemma = "do", es = "hago", fr = "je fais", pt = "eu faço", ru = "я делаю", de = "ich tue", pl = "robię", hu = "csinálok", sk = "robím" },
    	["say"] = { lemma = "say", es = "decir", fr = "dire", pt = "dizer", ru = "сказать", de = "sagen", pl = "mówić", hu = "mond", sk = "hovoriť" },
    	["I say"] = { lemma = "say", es = "digo", fr = "je dis", pt = "eu digo", ru = "я говорю", de = "ich sage", pl = "mówię", hu = "mondom", sk = "hovorím" },
    	["get"] = { lemma = "get", es = "conseguir", fr = "obtenir", pt = "obter", ru = "получить", de = "bekommen", pl = "dostać", hu = "szerez", sk = "zohnať" },
    	["I get"] = { lemma = "get", es = "consigo", fr = "j'obtiens", pt = "eu consigo", ru = "я получаю", de = "ich bekomme", pl = "dostaję", hu = "szerzek", sk = "dostanem" },
    	["make"] = { lemma = "make", es = "hacer", fr = "faire", pt = "fazer", ru = "сделать", de = "machen", pl = "zrobić", hu = "készít", sk = "urobiť" },
    	["I make"] = { lemma = "make", es = "hago", fr = "je fais", pt = "eu faço", ru = "я делаю", de = "ich mache", pl = "robię", hu = "készítek", sk = "robím" },
    ["go"] = { lemma = "go", es = "ir", fr = "aller", pt = "ir", ru = "идти", de = "gehen", pl = "iść", hu = "megy", sk = "ísť" },
    ["I go"] = { lemma = "go", es = "voy", fr = "je vais", pt = "eu vou", ru = "я иду", de = "ich gehe", pl = "idę", hu = "megyek", sk = "idem" },
    ["know"] = { lemma = "know", es = "saber", fr = "savoir", pt = "saber", ru = "знать", de = "wissen", pl = "wiedzieć", hu = "tud", sk = "vedieť" },
    ["I know"] = { lemma = "know", es = "sé", fr = "je sais", pt = "eu sei", ru = "я знаю", de = "ich weiß", pl = "wiem", hu = "tudom", sk = "viem" },
    ["think"] = { lemma = "think", es = "pensar", fr = "penser", pt = "pensar", ru = "думать", de = "denken", pl = "myśleć", hu = "gondol", sk = "myslieť" },
    ["I think"] = { lemma = "think", es = "pienso", fr = "je pense", pt = "eu penso", ru = "я думаю", de = "ich denke", pl = "myślę", hu = "gondolom", sk = "myslím" },
    ["take"] = { lemma = "take", es = "tomar", fr = "prendre", pt = "tomar", ru = "взять", de = "nehmen", pl = "wziąć", hu = "vesz", sk = "vziať" },
    ["I take"] = { lemma = "take", es = "tomo", fr = "je prends", pt = "eu pego", ru = "я беру", de = "ich nehme", pl = "biorę", hu = "veszek", sk = "beriem" },
    ["see"] = { lemma = "see", es = "ver", fr = "voir", pt = "ver", ru = "видеть", de = "sehen", pl = "widzieć", hu = "lát", sk = "vidieť" },
    ["I see"] = { lemma = "see", es = "veo", fr = "je vois", pt = "eu vejo", ru = "я вижу", de = "ich sehe", pl = "widzę", hu = "látok", sk = "vidím" },
    ["come"] = { lemma = "come", es = "venir", fr = "venir", pt = "vir", ru = "прийти", de = "kommen", pl = "przyjść", hu = "jön", sk = "prísť" },
    ["I come"] = { lemma = "come", es = "vengo", fr = "je viens", pt = "eu venho", ru = "я прихожу", de = "ich komme", pl = "przychodzę", hu = "jövök", sk = "prídem" },
    ["want"] = { lemma = "want", es = "querer", fr = "vouloir", pt = "querer", ru = "хотеть", de = "wollen", pl = "chcieć", hu = "akar", sk = "chcieť" },
    ["I want"] = { lemma = "want", es = "quiero", fr = "je veux", pt = "eu quero", ru = "я хочу", de = "ich will", pl = "chcę", hu = "akarom", sk = "chcem" },
    ["look"] = { lemma = "look", es = "mirar", fr = "regarder", pt = "olhar", ru = "смотреть", de = "schauen", pl = "patrzeć", hu = "néz", sk = "pozrieť" },
    ["I look"] = { lemma = "look", es = "miro", fr = "je regarde", pt = "eu olho", ru = "я смотрю", de = "ich schaue", pl = "patrzę", hu = "nézek", sk = "pozerám" },
    ["use"] = { lemma = "use", es = "usar", fr = "utiliser", pt = "usar", ru = "использовать", de = "benutzen", pl = "używać", hu = "használ", sk = "použiť" },
    ["I use"] = { lemma = "use", es = "uso", fr = "j'utilise", pt = "eu uso", ru = "я использую", de = "ich benutze", pl = "używam", hu = "használom", sk = "používam" },
    ["find"] = { lemma = "find", es = "encontrar", fr = "trouver", pt = "encontrar", ru = "найти", de = "finden", pl = "znaleźć", hu = "talál", sk = "nájsť" },
    ["I find"] = { lemma = "find", es = "encuentro", fr = "je trouve", pt = "eu encontro", ru = "я нахожу", de = "ich finde", pl = "znajduję", hu = "találok", sk = "nájdem" },
    ["give"] = { lemma = "give", es = "dar", fr = "donner", pt = "dar", ru = "дать", de = "geben", pl = "dać", hu = "ad", sk = "dať" },
    ["I give"] = { lemma = "give", es = "doy", fr = "je donne", pt = "eu dou", ru = "я даю", de = "ich gebe", pl = "daję", hu = "adok", sk = "dám" },
    ["tell"] = { lemma = "tell", es = "decir", fr = "dire", pt = "dizer", ru = "сказать", de = "erzählen", pl = "powiedzieć", hu = "mond", sk = "povedať" },
    ["I tell"] = { lemma = "tell", es = "digo", fr = "je dis", pt = "eu digo", ru = "я рассказываю", de = "ich erzähle", pl = "mówię", hu = "mondom", sk = "poviem" },
    ["work"] = { lemma = "work", es = "trabajar", fr = "travailler", pt = "trabalhar", ru = "работать", de = "arbeiten", pl = "pracować", hu = "dolgozik", sk = "pracovať" },
    ["I work"] = { lemma = "work", es = "trabajo", fr = "je travaille", pt = "eu trabalho", ru = "я работаю", de = "ich arbeite", pl = "pracuję", hu = "dolgozom", sk = "pracujem" },
    ["call"] = { lemma = "call", es = "llamar", fr = "appeler", pt = "chamar", ru = "звонить", de = "anrufen", pl = "dzwonić", hu = "hív", sk = "volať" },
    ["I call"] = { lemma = "call", es = "llamo", fr = "j'appelle", pt = "eu chamo", ru = "я звоню", de = "ich rufe an", pl = "dzwonię", hu = "hívok", sk = "volám" },
    ["try"] = { lemma = "try", es = "intentar", fr = "essayer", pt = "tentar", ru = "пытаться", de = "versuchen", pl = "próbować", hu = "próbál", sk = "skúšať" },
    ["I try"] = { lemma = "try", es = "intento", fr = "j'essaie", pt = "eu tento", ru = "я пытаюсь", de = "ich versuche", pl = "próbuję", hu = "próbálok", sk = "skúšam" },
    ["ask"] = { lemma = "ask", es = "preguntar", fr = "demander", pt = "perguntar", ru = "спросить", de = "fragen", pl = "pytać", hu = "kérdez", sk = "pýtať" },
    ["I ask"] = { lemma = "ask", es = "pregunto", fr = "je demande", pt = "eu pergunto", ru = "я спрашиваю", de = "ich frage", pl = "pytam", hu = "kérdezek", sk = "pýtam" },
    ["need"] = { lemma = "need", es = "necesitar", fr = "besoin", pt = "precisar", ru = "нужен", de = "brauchen", pl = "potrzebować", hu = "kell", sk = "potrebovať" },
    ["I need"] = { lemma = "need", es = "necesito", fr = "j'ai besoin", pt = "eu preciso", ru = "мне нужно", de = "ich brauche", pl = "potrzebuję", hu = "szükségem van", sk = "potrebujem" },
    ["feel"] = { lemma = "feel", es = "sentir", fr = "ressentir", pt = "sentir", ru = "чувствовать", de = "fühlen", pl = "czuć", hu = "érez", sk = "cítiť" },
    ["I feel"] = { lemma = "feel", es = "siento", fr = "je ressens", pt = "eu sinto", ru = "я чувствую", de = "ich fühle", pl = "czuję", hu = "érzek", sk = "cítim" },
    ["become"] = { lemma = "become", es = "convertirse", fr = "devenir", pt = "tornar-se", ru = "становиться", de = "werden", pl = "stać się", hu = "válik", sk = "stať sa" },
    ["I become"] = { lemma = "become", es = "me convierto", fr = "je deviens", pt = "eu me torno", ru = "я становлюсь", de = "ich werde", pl = "staję się", hu = "válok", sk = "stanem sa" },
    ["leave"] = { lemma = "leave", es = "salir", fr = "partir", pt = "sair", ru = "уходить", de = "verlassen", pl = "wyjść", hu = "elmegy", sk = "odísť" },
    ["I leave"] = { lemma = "leave", es = "salgo", fr = "je pars", pt = "eu saio", ru = "я ухожу", de = "ich verlasse", pl = "wychodzę", hu = "elmegyek", sk = "odchádzam" },
    ["put"] = { lemma = "put", es = "poner", fr = "mettre", pt = "colocar", ru = "класть", de = "legen", pl = "położyć", hu = "tesz", sk = "položiť" },
    ["I put"] = { lemma = "put", es = "pongo", fr = "je mets", pt = "eu coloco", ru = "я кладу", de = "ich lege", pl = "kładę", hu = "teszek", sk = "položím" },
    ["mean"] = { lemma = "mean", es = "significar", fr = "signifier", pt = "significar", ru = "означать", de = "bedeuten", pl = "znaczyć", hu = "jelent", sk = "znamená" },
    ["I mean"] = { lemma = "mean", es = "quiero decir", fr = "je veux dire", pt = "eu quero dizer", ru = "я имею в виду", de = "ich meine", pl = "mam na myśli", hu = "úgy értem", sk = "myslím" },
    ["keep"] = { lemma = "keep", es = "mantener", fr = "garder", pt = "manter", ru = "держать", de = "behalten", pl = "trzymać", hu = "tart", sk = "držať" },
    ["I keep"] = { lemma = "keep", es = "mantengo", fr = "je garde", pt = "eu mantenho", ru = "я держу", de = "ich behalte", pl = "trzymam", hu = "tartom", sk = "držím" },
    ["let"] = { lemma = "let", es = "dejar", fr = "laisser", pt = "deixar", ru = "позволять", de = "lassen", pl = "pozwolić", hu = "enged", sk = "nechať" },
    ["I let"] = { lemma = "let", es = "dejo", fr = "je laisse", pt = "eu deixo", ru = "я позволяю", de = "ich lasse", pl = "pozwalam", hu = "engedem", sk = "nechám" },
    ["run"] = { lemma = "run", es = "correr", fr = "courir", pt = "correr", ru = "бежать", de = "laufen", pl = "biegać", hu = "fut", sk = "bežať" },
    ["I run"] = { lemma = "run", es = "corro", fr = "je cours", pt = "eu corro", ru = "я бегу", de = "ich laufe", pl = "biegnę", hu = "futok", sk = "bežím" },
    ["talk"] = { lemma = "talk", es = "hablar", fr = "parler", pt = "falar", ru = "говорить", de = "sprechen", pl = "mówić", hu = "beszél", sk = "hovoriť" },
    ["I talk"] = { lemma = "talk", es = "hablo", fr = "je parle", pt = "eu falo", ru = "я говорю", de = "ich spreche", pl = "mówię", hu = "beszélek", sk = "hovorím" },
    ["wait"] = { lemma = "wait", es = "esperar", fr = "attendre", pt = "esperar", ru = "ждать", de = "warten", pl = "czekać", hu = "vár", sk = "čakať" },
    ["I wait"] = { lemma = "wait", es = "espero", fr = "j'attends", pt = "eu espero", ru = "я жду", de = "ich warte", pl = "czekam", hu = "várok", sk = "čakám" },
    ["play"] = { lemma = "play", es = "jugar", fr = "jouer", pt = "jogar", ru = "играть", de = "spielen", pl = "grać", hu = "játszik", sk = "hrať" },
    ["I play"] = { lemma = "play", es = "juego", fr = "je joue", pt = "eu jogo", ru = "я играю", de = "ich spiele", pl = "gram", hu = "játszom", sk = "hrám" },
    ["meet"] = { lemma = "meet", es = "encontrar", fr = "rencontrer", pt = "encontrar", ru = "встречать", de = "treffen", pl = "spotkać", hu = "találkozik", sk = "stretnúť" },
    ["I meet"] = { lemma = "meet", es = "encuentro", fr = "je rencontre", pt = "eu encontro", ru = "я встречаю", de = "ich treffe", pl = "spotykam", hu = "találkozom", sk = "stretávam" },
    ["start"] = { lemma = "start", es = "empezar", fr = "commencer", pt = "começar", ru = "начать", de = "beginnen", pl = "zacząć", hu = "kezd", sk = "začať" },
    ["I start"] = { lemma = "start", es = "empiezo", fr = "je commence", pt = "eu começo", ru = "я начинаю", de = "ich fange an", pl = "zaczynam", hu = "kezdem", sk = "začínam" },
    ["stop"] = { lemma = "stop", es = "parar", fr = "arrêter", pt = "parar", ru = "остановить", de = "stoppen", pl = "zatrzymać", hu = "megáll", sk = "zastaviť" },
    ["I stop"] = { lemma = "stop", es = "paro", fr = "j'arrête", pt = "eu paro", ru = "я останавливаю", de = "ich stoppe", pl = "zatrzymuję", hu = "megállok", sk = "zastavím" },
    ["move"] = { lemma = "move", es = "mover", fr = "bouger", pt = "mover", ru = "двигаться", de = "bewegen", pl = "ruszać", hu = "mozog", sk = "pohybovať" },
    ["I move"] = { lemma = "move", es = "muevo", fr = "je bouge", pt = "eu me movo", ru = "я двигаюсь", de = "ich bewege", pl = "ruszam się", hu = "mozgok", sk = "pohybujem sa" },
    ["like"] = { lemma = "like", es = "gustar", fr = "aimer", pt = "gostar", ru = "нравиться", de = "mögen", pl = "lubić", hu = "szeret", sk = "mať rád" },
    ["I like"] = { lemma = "like", es = "me gusta", fr = "j'aime", pt = "eu gosto", ru = "мне нравится", de = "ich mag", pl = "lubię", hu = "szeretem", sk = "mám rád" },
    ["live"] = { lemma = "live", es = "vivir", fr = "vivre", pt = "viver", ru = "жить", de = "leben", pl = "żyć", hu = "él", sk = "žiť" },
    ["I live"] = { lemma = "live", es = "vivo", fr = "je vis", pt = "eu moro", ru = "я живу", de = "ich lebe", pl = "żyję", hu = "élek", sk = "žijem" },
    ["believe"] = { lemma = "believe", es = "creer", fr = "croire", pt = "acreditar", ru = "верить", de = "glauben", pl = "wierzyć", hu = "hinni", sk = "veriť" },
    ["I believe"] = { lemma = "believe", es = "creo", fr = "je crois", pt = "eu acredito", ru = "я верю", de = "ich glaube", pl = "wierzę", hu = "hiszek", sk = "verím" },
    ["bring"] = { lemma = "bring", es = "traer", fr = "apporter", pt = "trazer", ru = "принести", de = "bringen", pl = "przynieść", hu = "hoz", sk = "priniesť" },
    ["I bring"] = { lemma = "bring", es = "traigo", fr = "j'apporte", pt = "eu trago", ru = "я приношу", de = "ich bringe", pl = "przynoszę", hu = "hozok", sk = "prinesiem" },
    ["write"] = { lemma = "write", es = "escribir", fr = "écrire", pt = "escrever", ru = "писать", de = "schreiben", pl = "pisać", hu = "ír", sk = "písať" },
    ["I write"] = { lemma = "write", es = "escribo", fr = "j'écris", pt = "eu escrevo", ru = "я пишу", de = "ich schreibe", pl = "piszę", hu = "írok", sk = "píšem" },
    ["sit"] = { lemma = "sit", es = "sentarse", fr = "s'asseoir", pt = "sentar", ru = "сидеть", de = "sitzen", pl = "siedzieć", hu = "ül", sk = "sedieť" },
    ["I sit"] = { lemma = "sit", es = "me siento", fr = "je m'assois", pt = "eu sento", ru = "я сижу", de = "ich sitze", pl = "siedzę", hu = "ülök", sk = "sedím" },
    ["stand"] = { lemma = "stand", es = "estar de pie", fr = "se tenir", pt = "ficar de pé", ru = "стоять", de = "stehen", pl = "stać", hu = "áll", sk = "stáť" },
    ["I stand"] = { lemma = "stand", es = "estoy de pie", fr = "je me tiens", pt = "eu fico de pé", ru = "я стою", de = "ich stehe", pl = "stoję", hu = "állok", sk = "stojím" },
    ["lose"] = { lemma = "lose", es = "perder", fr = "perdre", pt = "perder", ru = "терять", de = "verlieren", pl = "przegrać", hu = "veszít", sk = "stratiť" },
    ["I lose"] = { lemma = "lose", es = "pierdo", fr = "je perds", pt = "eu perco", ru = "я теряю", de = "ich verliere", pl = "przegrywam", hu = "veszítek", sk = "stratím" },
    ["pay"] = { lemma = "pay", es = "pagar", fr = "payer", pt = "pagar", ru = "платить", de = "zahlen", pl = "płacić", hu = "fizet", sk = "platiť" },
    ["I pay"] = { lemma = "pay", es = "pago", fr = "je paie", pt = "eu pago", ru = "я плачу", de = "ich zahle", pl = "płacę", hu = "fizetek", sk = "platím" },
    ["buy"] = { lemma = "buy", es = "comprar", fr = "acheter", pt = "comprar", ru = "покупать", de = "kaufen", pl = "kupić", hu = "vásárol", sk = "kúpiť" },
    ["I buy"] = { lemma = "buy", es = "compro", fr = "j'achète", pt = "eu compro", ru = "я покупаю", de = "ich kaufe", pl = "kupuję", hu = "veszek", sk = "kúpim" },
    ["sell"] = { lemma = "sell", es = "vender", fr = "vendre", pt = "vender", ru = "продавать", de = "verkaufen", pl = "sprzedać", hu = "elad", sk = "predať" },
    ["I sell"] = { lemma = "sell", es = "vendo", fr = "je vends", pt = "eu vendo", ru = "я vendo", de = "ich verkaufe", pl = "sprzedaję", hu = "eladok", sk = "predávam" },
    ["walk"] = { lemma = "walk", es = "caminar", fr = "marcher", pt = "caminhar", ru = "идти", de = "gehen", pl = "chodzić", hu = "sétál", sk = "chodiť" },
    ["I walk"] = { lemma = "walk", es = "camino", fr = "je marche", pt = "eu ando", ru = "я иду", de = "ich gehe", pl = "chodzę", hu = "sétálok", sk = "chodím" },
    ["read"] = { lemma = "read", es = "leer", fr = "lire", pt = "ler", ru = "читать", de = "lesen", pl = "czytać", hu = "olvas", sk = "čítať" },
    ["I read"] = { lemma = "read", es = "leo", fr = "je lis", pt = "eu leio", ru = "я читаю", de = "ich lese", pl = "czytam", hu = "olvasok", sk = "čítam" },
    ["send"] = { lemma = "send", es = "enviar", fr = "envoyer", pt = "enviar", ru = "отправлять", de = "senden", pl = "wysłać", hu = "küld", sk = "poslať" },
    ["I send"] = { lemma = "send", es = "envío", fr = "j'envoie", pt = "eu envio", ru = "я отправляю", de = "ich sende", pl = "wysyłam", hu = "küldök", sk = "posielam" },
    ["build"] = { lemma = "build", es = "construir", fr = "construire", pt = "construir", ru = "строить", de = "bauen", pl = "budować", hu = "épít", sk = "stavať" },
    ["I build"] = { lemma = "build", es = "construyo", fr = "je construis", pt = "eu construo", ru = "я строю", de = "ich baue", pl = "buduję", hu = "építek", sk = "staviam" },
    ["stay"] = { lemma = "stay", es = "quedarse", fr = "rester", pt = "ficar", ru = "оставаться", de = "bleiben", pl = "zostać", hu = "marad", sk = "zostať" },
    ["I stay"] = { lemma = "stay", es = "me quedo", fr = "je reste", pt = "eu fico", ru = "я остаюсь", de = "ich bleibe", pl = "zostaję", hu = "maradok", sk = "ostávam" },
    ["fall"] = { lemma = "fall", es = "caer", fr = "tomber", pt = "cair", ru = "падать", de = "fallen", pl = "upaść", hu = "esik", sk = "padnúť" },
    ["I fall"] = { lemma = "fall", es = "caigo", fr = "je tombe", pt = "eu caio", ru = "я падаю", de = "ich falle", pl = "upadam", hu = "esek", sk = "padám" },
    ["change"] = { lemma = "change", es = "cambiar", fr = "changer", pt = "mudar", ru = "менять", de = "ändern", pl = "zmienić", hu = "változik", sk = "zmeniť" },
    ["I change"] = { lemma = "change", es = "cambio", fr = "je change", pt = "eu mudo", ru = "я меняю", de = "ich ändere", pl = "zmieniam", hu = "változtatok", sk = "mením" },
    ["open"] = { lemma = "open", es = "abrir", fr = "ouvrir", pt = "abrir", ru = "открывать", de = "öffnen", pl = "otworzyć", hu = "nyit", sk = "otvoriť" },
    ["I open"] = { lemma = "open", es = "abro", fr = "j'ouvre", pt = "eu abro", ru = "я открываю", de = "ich öffne", pl = "otwieram", hu = "nyitok", sk = "otváram" },
    ["close"] = { lemma = "close", es = "cerrar", fr = "fermer", pt = "fechar", ru = "закрывать", de = "schließen", pl = "zamknąć", hu = "bezár", sk = "zavrieť" },
    ["I close"] = { lemma = "close", es = "cierro", fr = "je ferme", pt = "eu fecho", ru = "я закрываю", de = "ich schließe", pl = "zamykam", hu = "bezárom", sk = "zatváram" },
    ["watch"] = { lemma = "watch", es = "mirar", fr = "regarder", pt = "assistir", ru = "смотреть", de = "schauen", pl = "oglądać", hu = "néz", sk = "pozerať" },
    ["I watch"] = { lemma = "watch", es = "miro", fr = "je regarde", pt = "eu assisto", ru = "я смотрю", de = "ich schaue", pl = "oglądam", hu = "nézek", sk = "pozerám" },
    ["follow"] = { lemma = "follow", es = "seguir", fr = "suivre", pt = "seguir", ru = "следовать", de = "folgen", pl = "podążać", hu = "követ", sk = "nasledovať" },
    ["I follow"] = { lemma = "follow", es = "sigo", fr = "je suis", pt = "eu sigo", ru = "я следую", de = "ich folge", pl = "podążam", hu = "követek", sk = "nasledujem" },
    ["begin"] = { lemma = "begin", es = "comenzar", fr = "commencer", pt = "começar", ru = "начинать", de = "anfangen", pl = "zacząć", hu = "kezd", sk = "začať" },
    ["I begin"] = { lemma = "begin", es = "comienzo", fr = "je commence", pt = "eu começo", ru = "я начинаю", de = "ich beginne", pl = "zaczynam", hu = "kezdek", sk = "začínam" },
    ["end"] = { lemma = "end", es = "terminar", fr = "terminer", pt = "terminar", ru = "заканчивать", de = "enden", pl = "zakończyć", hu = "befejez", sk = "skončiť" },
    ["I end"] = { lemma = "end", es = "termino", fr = "je termine", pt = "eu termino", ru = "я заканчиваю", de = "ich beende", pl = "kończę", hu = "befejezem", sk = "končím" },
    ["finish"] = { lemma = "finish", es = "terminar", fr = "finir", pt = "terminar", ru = "заканчивать", de = "beenden", pl = "zakończyć", hu = "befejez", sk = "dokončiť" },
    ["I finish"] = { lemma = "finish", es = "termino", fr = "je finis", pt = "eu termino", ru = "я заканчиваю", de = "ich beende", pl = "kończę", hu = "befejezem", sk = "dokončím" },
    ["join"] = { lemma = "join", es = "unirse", fr = "joindre", pt = "juntar-se", ru = "присоединяться", de = "beitreten", pl = "dołączyć", hu = "csatlakozik", sk = "pridať sa" },
    ["I join"] = { lemma = "join", es = "me uno", fr = "je rejoins", pt = "eu me junto", ru = "я присоединяюсь", de = "ich trete bei", pl = "dołączam", hu = "csatlakozom", sk = "pridávam sa" },
    ["break"] = { lemma = "break", es = "romper", fr = "casser", pt = "quebrar", ru = "ломать", de = "brechen", pl = "złamać", hu = "tör", sk = "zlomiť" },
    ["I break"] = { lemma = "break", es = "rompo", fr = "je casse", pt = "eu quebro", ru = "я ломаю", de = "ich breche", pl = "łamię", hu = "török", sk = "zlomím" },
    ["check"] = { lemma = "check", es = "verificar", fr = "vérifier", pt = "verificar", ru = "проверять", de = "prüfen", pl = "sprawdzić", hu = "ellenőriz", sk = "skontrolovať" },
    ["I check"] = { lemma = "check", es = "verifico", fr = "je vérifie", pt = "eu verifico", ru = "я проверяю", de = "ich prüfe", pl = "sprawdzam", hu = "ellenőrzöm", sk = "kontrolujem" },
    ["fight"] = { lemma = "fight", es = "luchar", fr = "se battre", pt = "lutar", ru = "сражаться", de = "kämpfen", pl = "walczyć", hu = "harcol", sk = "bojovať" },
    ["I fight"] = { lemma = "fight", es = "lucho", fr = "je me bats", pt = "eu luto", ru = "я сражаюсь", de = "ich kämpfe", pl = "walczę", hu = "harcolok", sk = "bojujem" },
    ["defend"] = { lemma = "defend", es = "defender", fr = "défendre", pt = "defender", ru = "защищать", de = "verteidigen", pl = "bronić", hu = "védeni", sk = "brániť" },
    ["I defend"] = { lemma = "defend", es = "defiendo", fr = "je défends", pt = "eu defendo", ru = "я защищаю", de = "ich verteidige", pl = "bronię", hu = "védek", sk = "bránim" },
    ["attack"] = { lemma = "attack", es = "atacar", fr = "attaquer", pt = "atacar", ru = "атаковать", de = "angreifen", pl = "atakować", hu = "támadni", sk = "útočiť" },
    ["I attack"] = { lemma = "attack", es = "ataco", fr = "j'attaque", pt = "eu ataco", ru = "я атакую", de = "ich greife an", pl = "atakuję", hu = "támadok", sk = "útočím" },
    ["cast"] = { lemma = "cast", es = "lanzar", fr = "lancer", pt = "lançar", ru = "кастовать", de = "zaubern", pl = "rzucać", hu = "varázsol", sk = "vrhať" },
    ["I cast"] = { lemma = "cast", es = "lanzo", fr = "je lance", pt = "eu lanço", ru = "я кастую", de = "ich zaubere", pl = "rzucam", hu = "varázsolok", sk = "vrhám" },
    ["summon"] = { lemma = "summon", es = "invocar", fr = "invoquer", pt = "invocar", ru = "призвать", de = "beschwören", pl = "przywołać", hu = "idézni", sk = "privolať" },
    ["I summon"] = { lemma = "summon", es = "invoco", fr = "j'invoque", pt = "eu invoco", ru = "я призываю", de = "ich beschwöre", pl = "przywołuję", hu = "idézek", sk = "privolávam" },
    ["loot"] = { lemma = "loot", es = "saquear", fr = "piller", pt = "saquear", ru = "лутать", de = "plündern", pl = "grabież", hu = "zsákmányol", sk = "vyplieniť" },
    ["I loot"] = { lemma = "loot", es = "saqueo", fr = "je pille", pt = "eu saqueio", ru = "я лутаю", de = "ich plündere", pl = "łupię", hu = "zsákmányolok", sk = "vyplienim" },
    ["equip"] = { lemma = "equip", es = "equipar", fr = "équiper", pt = "equipar", ru = "экипировать", de = "ausrüsten", pl = "wyposażyć", hu = "felszerel", sk = "vybaviť" },
    ["I equip"] = { lemma = "equip", es = "equipo", fr = "j'équipe", pt = "eu equipo", ru = "я экипируюсь", de = "ich rüste aus", pl = "wyposażam", hu = "felszerelek", sk = "vybavím" },
    ["trade"] = { lemma = "trade", es = "comerciar", fr = "échanger", pt = "trocar", ru = "торговать", de = "handeln", pl = "handlować", hu = "kereskedni", sk = "obchodovať" },
    ["I trade"] = { lemma = "trade", es = "comercio", fr = "j'échange", pt = "eu troco", ru = "я торгую", de = "ich handle", pl = "handluję", hu = "kereskedem", sk = "obchodujem" },
    ["invite"] = { lemma = "invite", es = "invitar", fr = "inviter", pt = "convidar", ru = "пригласить", de = "einladen", pl = "zaprosić", hu = "meghívni", sk = "pozvať" },
    ["I invite"] = { lemma = "invite", es = "invito", fr = "j'invite", pt = "eu convido", ru = "я приглашаю", de = "ich lade ein", pl = "zapraszam", hu = "meghívok", sk = "pozývam" },
    ["kick"] = { lemma = "kick", es = "patear", fr = "expulser", pt = "expulsar", ru = "кикнуть", de = "rausschmeißen", pl = "wyrzucić", hu = "kirúgni", sk = "vyhodiť" },
    ["I kick"] = { lemma = "kick", es = "pateo", fr = "j'expulse", pt = "eu expulso", ru = "я кикаю", de = "ich schmeiße raus", pl = "wyrzucam", hu = "kirúgok", sk = "vyhodím" },
    ["win"] = { lemma = "win", es = "ganar", fr = "gagner", pt = "ganhar", ru = "победить", de = "gewinnen", pl = "wygrać", hu = "győzni", sk = "vyhrať" },
    ["I win"] = { lemma = "win", es = "gano", fr = "je gagne", pt = "eu ganho", ru = "я выигрываю", de = "ich gewinne", pl = "wygrywam", hu = "nyerek", sk = "vyhrávam" },
    ["die"] = { lemma = "die", es = "morir", fr = "mourir", pt = "morrer", ru = "умереть", de = "sterben", pl = "umrzeć", hu = "meghalni", sk = "zomrieť" },
    ["I die"] = { lemma = "die", es = "muero", fr = "je meurs", pt = "eu morro", ru = "я умираю", de = "ich sterbe", pl = "umieram", hu = "meghalok", sk = "zomieram" },
    ["kill"] = { lemma = "kill", es = "matar", fr = "tuer", pt = "matar", ru = "убить", de = "töten", pl = "zabić", hu = "megölni", sk = "zabiť" },
    ["I kill"] = { lemma = "kill", es = "mato", fr = "je tue", pt = "eu mato", ru = "я убиваю", de = "ich töte", pl = "zabijam", hu = "megölök", sk = "zabíjam" },
    ["revive"] = { lemma = "revive", es = "revivir", fr = "ressusciter", pt = "reviver", ru = "оживить", de = "wiederbeleben", pl = "ożywić", hu = "feltámasztani", sk = "oživiť" },
    ["I revive"] = { lemma = "revive", es = "revivo", fr = "je ressuscite", pt = "eu revivo", ru = "я оживляю", de = "ich belebe wieder", pl = "ożywiam", hu = "feltámasztok", sk = "oživím" },
    ["escape"] = { lemma = "escape", es = "escapar", fr = "s'échapper", pt = "escapar", ru = "сбежать", de = "entkommen", pl = "uciec", hu = "megszökni", sk = "uniknúť" },
    ["I escape"] = { lemma = "escape", es = "escapo", fr = "je m'échappe", pt = "eu escapo", ru = "я убегаю", de = "ich entkomme", pl = "uciekam", hu = "megszökök", sk = "unikám" },
    ["hide"] = { lemma = "hide", es = "esconderse", fr = "se cacher", pt = "esconder-se", ru = "прятаться", de = "sich verstecken", pl = "ukryć się", hu = "elbújni", sk = "schovať sa" },
    ["I hide"] = { lemma = "hide", es = "me escondo", fr = "je me cache", pt = "eu me escondo", ru = "я прячусь", de = "ich verstecke mich", pl = "ukrywam się", hu = "elbújok", sk = "schovávam sa" },
    ["search"] = { lemma = "search", es = "buscar", fr = "chercher", pt = "procurar", ru = "искать", de = "suchen", pl = "szukać", hu = "keresni", sk = "hľadať" },
    ["I search"] = { lemma = "search", es = "busco", fr = "je cherche", pt = "eu procuro", ru = "я ищу", de = "ich suche", pl = "szukam", hu = "keresek", sk = "hľadám" },
    ["explore"] = { lemma = "explore", es = "explorar", fr = "explorer", pt = "explorar", ru = "исследовать", de = "erforschen", pl = "badać", hu = "felfedezni", sk = "preskúmať" },
    ["I explore"] = { lemma = "explore", es = "exploro", fr = "j'explore", pt = "eu exploro", ru = "я исследую", de = "ich erforsche", pl = "badam", hu = "felfedezek", sk = "preskúmavam" },
    ["craft"] = { lemma = "craft", es = "fabricar", fr = "fabriquer", pt = "fabricar", ru = "крафтить", de = "herstellen", pl = "wytworzyć", hu = "kézműveskedni", sk = "vyrobiť" },
    ["I craft"] = { lemma = "craft", es = "fabrico", fr = "je fabrique", pt = "eu fabrico", ru = "я крафчу", de = "ich stelle her", pl = "wytwarzam", hu = "kézműveskedek", sk = "vyrábam" },
    ["gather"] = { lemma = "gather", es = "recoger", fr = "ramasser", pt = "coletar", ru = "собирать", de = "sammeln", pl = "zbierać", hu = "gyűjteni", sk = "zbierať" },
    ["I gather"] = { lemma = "gather", es = "recojo", fr = "je ramasse", pt = "eu coleto", ru = "я собираю", de = "ich sammle", pl = "zbieram", hu = "gyűjtök", sk = "zbieram" },
    ["mine"] = { lemma = "mine", es = "minar", fr = "miner", pt = "minerar", ru = "добывать", de = "abbauen", pl = "wydobywać", hu = "bányászni", sk = "ťažiť" },
    ["I mine"] = { lemma = "mine", es = "mino", fr = "je mine", pt = "eu minero", ru = "я добываю", de = "ich baue ab", pl = "wydobywam", hu = "bányászok", sk = "ťažím" },
    ["fish"] = { lemma = "fish", es = "pescar", fr = "pêcher", pt = "pescar", ru = "ловить рыбу", de = "angeln", pl = "łowić ryby", hu = "halászni", sk = "loviť ryby" },
    ["I fish"] = { lemma = "fish", es = "pesco", fr = "je pêche", pt = "eu pesco", ru = "я ловлю рыбу", de = "ich angle", pl = "łowię ryby", hu = "halászom", sk = "lovím ryby" },
    ["cook"] = { lemma = "cook", es = "cocinar", fr = "cuisiner", pt = "cozinhar", ru = "готовить", de = "kochen", pl = "gotować", hu = "főzni", sk = "variť" },
    ["I cook"] = { lemma = "cook", es = "cocino", fr = "je cuisine", pt = "eu cozinho", ru = "я готовлю", de = "ich koche", pl = "gotuję", hu = "főzök", sk = "varím" },
    ["enchant"] = { lemma = "enchant", es = "encantar", fr = "enchanter", pt = "encantar", ru = "зачаровать", de = "verzaubern", pl = "oczarować", hu = "elbűvölni", sk = "očarovať" },
    ["I enchant"] = { lemma = "enchant", es = "encanto", fr = "j'enchante", pt = "eu encanto", ru = "я зачаровываю", de = "ich verzaubere", pl = "zaklinam", hu = "elbűvölök", sk = "očarúvam" },
    ["disenchant"] = { lemma = "disenchant", es = "desencantar", fr = "désenchanter", pt = "desencantar", ru = "распылить", de = "entzaubern", pl = "odczarować", hu = "elbűvölni", sk = "odčarovať" },
    ["I disenchant"] = { lemma = "disenchant", es = "desencanto", fr = "je désenchante", pt = "eu desencanto", ru = "я распыляю", de = "ich entzaubere", pl = "odczarowuję", hu = "elbűvölök", sk = "odčarúvam" },
    ["repair"] = { lemma = "repair", es = "reparar", fr = "réparer", pt = "reparar", ru = "починить", de = "reparieren", pl = "naprawić", hu = "javítani", sk = "opraviť" },
    ["kick this afk"] = { lemma = "kick this afk", es = "expulsar a este ausente", fr = "mettons fin à cet inactif", pt = "expulsar esse ausente", ru = "кикнуть этого афк", de = "diesen AFK kicken", pl = "wyrzucić tego AFK", hu = "kirúgni ezt az AFK-t", sk = "vykopnúť tohto AFK" },
	["I repair"] = { lemma = "repair", es = "reparo", fr = "je répare", pt = "eu reparo", ru = "я чиню", de = "ich repariere", pl = "naprawiam", hu = "javítok", sk = "opravujem" },
    ["upgrade"] = { lemma = "upgrade", es = "mejorar", fr = "améliorer", pt = "melhorar", ru = "улучшить", de = "verbessern", pl = "ulepszyć", hu = "fejleszteni", sk = "vylepšiť" },
    ["I upgrade"] = { lemma = "upgrade", es = "mejoro", fr = "j'améliore", pt = "eu melhoro", ru = "я улучшаю", de = "ich verbessere", pl = "ulepszam", hu = "fejlesztek", sk = "vylepšujem" },
    ["heal"] = { lemma = "heal", es = "sanar", fr = "soigner", pt = "curar", ru = "лечить", de = "heilen", pl = "leczyć", hu = "gyógyít", sk = "liečiť" },
    ["I heal"] = { lemma = "heal", es = "sano", fr = "je soigne", pt = "eu curo", ru = "я лечу", de = "ich heile", pl = "leczę", hu = "gyógyítok", sk = "liečim" },
    ["resurrect"] = { lemma = "resurrect", es = "resucitar", fr = "ressusciter", pt = "ressuscitar", ru = "воскрешать", de = "wiederbeleben", pl = "wskrzesić", hu = "feltámaszt", sk = "vzkriesiť" },
    ["I resurrect"] = { lemma = "resurrect", es = "resucito", fr = "je ressuscite", pt = "eu ressuscito", ru = "я воскрешаю", de = "ich belebe wieder", pl = "wskrzeszam", hu = "feltámasztok", sk = "vzkriesim" },
	["gold making guide"] = { lemma = "gold making guide", es = "guía para hacer oro", fr = "guide pour faire de l'or", pt = "guia para fazer ouro", ru = "гайд по фарму голды", de = "Gold-Guide", pl = "poradnik zarabiania złota", hu = "aranygyűjtési útmutató", sk = "sprievodca zarábaním zlata" },
	["need"] = { lemma = "need", es = "necesitar", fr = "besoin", pt = "precisar", ru = "нужно", de = "brauchen", pl = "potrzebować", hu = "kell", sk = "potrebovať" },
    	["greed"] = { lemma = "greed", es = "codicia", fr = "cupidité", pt = "ganância", ru = "жадность", de = "Gier", pl = "chciwość", hu = "kapzsiság", sk = "chamtivosť" },
	["best in slot list"] = { lemma = "best in slot list", es = "lista de BIS", fr = "liste du meilleur dans le slot", pt = "lista de melhor no slot", ru = "БИС лист", de = "Best-in-Slot-Liste", pl = "lista najlepszych w slocie", hu = "BIS lista", sk = "BIS zoznam" },
	["current gear"] = { lemma = "current gear", es = "equipo actual", fr = "équipement actuel", pt = "equipamento atual", ru = "текущая экипировка", de = "aktuelle Ausrüstung", pl = "aktualny sprzęt", hu = "jelenlegi felszerelés", sk = "aktuálna výstroj" },
	["next upgrade"] = { lemma = "next upgrade", es = "siguiente mejora", fr = "prochaine amélioration", pt = "próxima melhoria", ru = "следующий апгрейд", de = "nächstes Upgrade", pl = "następne ulepszenie", hu = "következő fejlesztés", sk = "ďalší upgrade" }
}
-- Validate translations table and remove invalid langCodes
do
    for word, data in pairs(translations) do
        if type(word) ~= "string" or type(data) ~= "table" or not data.lemma then
            translations[word] = nil
        else
            for lang, trans in pairs(data) do
                if lang ~= "lemma" and (type(trans) ~= "string" or not languageNames[lang]) then
                    data[lang] = nil
                end
            end
        end
    end
end

-- Phrase lookup table for translation
-- This table maps a translated word/phrase (e.g., "poco", "guía para hacer oro") back to its lemma (e.g., "little", "guide to make gold").
-- It's generated from the 'translations' table.
local phraseLookup = {}
for langCode, _ in pairs(languageNames) do
    phraseLookup[langCode] = {}
end
for lemma, data in pairs(translations) do -- 'lemma' here is the key of the outer table (e.g., "little", "guide to make gold")
    for langCode, translatedText in pairs(data) do -- 'translatedText' is the actual translated string (e.g., "poco", "guía para hacer oro")
        if langCode ~= "lemma" and type(translatedText) == "string" and languageNames[langCode] then
            -- Generate the lookup key by tokenizing the translatedText and joining without spaces
            -- This ensures consistency with how phrases are reconstructed for lookup in translateMessage
            -- Use the same tokenization logic for phraseLookup keys as for incoming messages
            local tokenized_translated_text_for_key = {}
            for token in string.gmatch(string.lower(translatedText), "[^%s%/%%%(%)%?%!%.,;:]+") do
                 table.insert(tokenized_translated_text_for_key, token)
            end
            local lookup_key = table.concat(tokenized_translated_text_for_key, "")
            phraseLookup[langCode][lookup_key] = lemma
        end
    end
end

-- Helper function to trim whitespace
local function trim(str)
    return str and string.gsub(str, "^%s*(.*%S?)%s*$", "%1") or ""
end

-- Helper function to split message into words based on spaces and defined punctuation
-- This replaces the original splitMessageIntoTokens and provides the core logic for word separation.
local function getWords(message)
    local words = {}
    -- Pattern: Matches sequences of characters that are NOT whitespace, '/', '(', ')', '?', '!', '.', ',', ';', or ':'
    -- This means words will be split by these characters.
    for word in string.gmatch(message, "[^%s%/%%%(%)%?%!%.,;:]+") do
        table.insert(words, word)
    end
    return words
end


-- Detect language with phrase and word weighting
local function detectLanguage(message)
    if not message or trim(message) == "" then return "en" end
    local lowerMsg = string.lower(trim(message))
    local scores = {}
    local totalUnits = 0
    for lang in pairs(languageNames) do scores[lang] = 0 end

    -- Check for full message phrase matches
    for langCode, lookup in pairs(phraseLookup) do
        if lookup[lowerMsg] then
            scores[langCode] = scores[langCode] + 5 -- Higher score for full message match
            totalUnits = totalUnits + 5
        end
    end

    -- Check for individual word matches using the new getWords function
    for _, word in ipairs(getWords(lowerMsg)) do
        totalUnits = totalUnits + 1
        local found = false
        for langCode, lookup in pairs(phraseLookup) do
            if lookup[word] then -- Checks if the word exists as a key in the phraseLookup for any language
                scores[langCode] = scores[langCode] + 1
                found = true
                break
            end
        end
        -- If a word isn't found in any language lookup, default to English score
        if not found then scores["en"] = scores["en"] + 1 end
    end

    -- Simple scoring to determine best language
    local bestLang, maxScore = "en", scores["en"] or 0
    -- If totalUnits is 0 (empty message), default to English
    if totalUnits == 0 then return "en" end

    -- If English has a high percentage, assume English to prevent misdetection of short non-English phrases
    local englishPercentage = (scores["en"] or 0) / totalUnits
    if englishPercentage >= 0.7 then return "en" end

    for lang, score in pairs(scores) do
        if score > maxScore then
            bestLang, maxScore = lang, score
        end
    end
    return bestLang
end


-- Translate message with refined word and phrase matching
local function translateMessage(message, sourceLang, targetLang)
    if sourceLang == targetLang or not message then return message or "" end
    local lowerMsg = string.lower(trim(message))
    local segments = {}
    local translated = false
    local pos = 1
    local len = string.len(lowerMsg)

    -- Define separator pattern (same as in getWords, but used for string.find)
    local separator_pattern = "[%s%/%%%(%)%?%!%.,;:]"

    while pos <= len do
        local matchedPhrase = false
        local longestMatchLen = 0
        local longestTrans = nil
        local longestLemma = nil

        -- Attempt to find the longest phrase match starting from the current position
        -- We'll try to find phrases *without* separators in the middle for lookup keys
        for phrase_key_in_lookup, lemma in pairs(phraseLookup[sourceLang] or {}) do
            local current_sub_msg = string.sub(lowerMsg, pos)
            -- Reconstruct the exact string that would be used as a key in phraseLookup
            -- by removing separators from current_sub_msg up to the length of phrase_key_in_lookup
            local potential_match = ""
            local current_sub_pos = 1
            for char_idx = 1, string.len(current_sub_msg) do
                local char = string.sub(current_sub_msg, char_idx, char_idx)
                if not string.find(char, separator_pattern) then
                    potential_match = potential_match .. char
                end
                if string.len(potential_match) == string.len(phrase_key_in_lookup) then
                    break
                end
            end


            if potential_match == phrase_key_in_lookup then
                local phraseLen = 0 -- Actual character length in the message, including separators
                local temp_phrase_str = ""
                for char_idx = pos, len do
                    local char = string.sub(lowerMsg, char_idx, char_idx)
                    phraseLen = phraseLen + 1
                    if not string.find(char, separator_pattern) then
                        temp_phrase_str = temp_phrase_str .. char
                    end
                    if string.len(temp_phrase_str) == string.len(phrase_key_in_lookup) then
                        break
                    end
                end

                if phraseLen > longestMatchLen then
                    longestMatchLen = phraseLen
                    longestLemma = lemma
                    longestTrans = translations[lemma] and translations[lemma][targetLang] or lemma
                end
            end
        end

        if longestTrans then
            table.insert(segments, longestTrans)
            pos = pos + longestMatchLen
            translated = true
            matchedPhrase = true
        end

        -- If no phrase matched, process the next individual word/punctuation
        if not matchedPhrase then
            local next_separator_pos = string.find(lowerMsg, separator_pattern, pos)
            local current_word_end = (next_separator_pos or len + 1) - 1
            local current_raw_token = string.sub(lowerMsg, pos, current_word_end)

            local token_for_lookup = current_raw_token -- Assume for now it's just the token
            -- If it's a word, clean it for lookup (remove any internal symbols not used as separators here)
            if string.find(current_raw_token, "[%a%d]") then -- Contains alphanumeric, so it's a word
                token_for_lookup = string.gsub(current_raw_token, separator_pattern, "") -- Remove separators if they are part of the raw token (e.g. from phrase edge)
            end

            local lemmaForToken = phraseLookup[sourceLang] and phraseLookup[sourceLang][token_for_lookup] or current_raw_token
            local tokenTrans = translations[lemmaForToken] and translations[lemmaForToken][targetLang] or current_raw_token

            table.insert(segments, tokenTrans)
            if translations[lemmaForToken] then translated = true end

            pos = current_word_end + 1
        end

        -- Add any trailing separators after the token/phrase
        while pos <= len and string.find(string.sub(lowerMsg, pos, pos), separator_pattern) do
            table.insert(segments, string.sub(lowerMsg, pos, pos))
            pos = pos + 1
        end
    end

    local result = trim(table.concat(segments, "")) -- Concatenate with no default separator
    return translated and result or nil
end


-- UI: Output Box
local function InitializeOutputBox()
    outputBox = CreateFrame("Frame", "ChatTranslatorOutput", UIParent)
    outputBox:SetSize(ChatTranslatorSettings.frameWidth or 350, ChatTranslatorSettings.frameHeight or 200)
    if ChatTranslatorSettings.framePoint then
        outputBox:SetPoint(unpack(ChatTranslatorSettings.framePoint))
    else
        outputBox:SetPoint("CENTER")
    end
    outputBox:SetBackdrop({
        bgFile = "Interface\\Tooltips\\UI-Tooltip-Background",
        edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
        tile = true, tileSize = 16, edgeSize = 8,
        insets = { left = 2, right = 2, top = 2, bottom = 2 }
    })
    outputBox:SetBackdropColor(0, 0, 0, ChatTranslatorSettings.opacity or 0.8)
    outputBox:SetBackdropBorderColor(1, 1, 1, ChatTranslatorSettings.opacity or 0.8)
    outputBox:SetMovable(not (ChatTranslatorSettings.isLocked or false))
    outputBox:EnableMouse(not (ChatTranslatorSettings.isLocked or false))
    outputBox:SetClampedToScreen(true)
    outputBox:SetResizable(true)
    outputBox:SetMinResize(200, 150)
    outputBox:SetMaxResize(600, 400)
    outputBox:Show()

    outputBox:RegisterForDrag("LeftButton")
    outputBox:SetScript("OnDragStart", function(self)
        if not ChatTranslatorSettings.isLocked then self:StartMoving() end
    end)
    outputBox:SetScript("OnDragStop", function(self)
        self:StopMovingOrSizing()
        local point, relativeTo, relativePoint, xOfs, yOfs = self:GetPoint()
        ChatTranslatorSettings.framePoint = { point, "UIParent", relativePoint, xOfs, yOfs }
    end)

    msgFrame = CreateFrame("ScrollingMessageFrame", "ChatTranslatorMsg", outputBox)
    msgFrame:SetPoint("TOPLEFT", 5, -5)
    msgFrame:SetPoint("BOTTOMRIGHT", -5, 5)
    msgFrame:SetFont("Fonts\\ARIALN.TTF", 12, "")
    msgFrame:SetJustifyH("LEFT")
    msgFrame:SetMaxLines(500)
    msgFrame:SetFading(false)
    msgFrame:EnableMouseWheel(true)
    msgFrame:SetScript("OnMouseWheel", function(self, delta)
        if delta > 0 then self:ScrollUp() else self:ScrollDown() end
    end)

    resizeBtn = CreateFrame("Button", nil, outputBox)
    resizeBtn:SetSize(16, 16)
    resizeBtn:SetPoint("BOTTOMRIGHT")
    resizeBtn:SetNormalTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Up")
    resizeBtn:SetHighlightTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Highlight")
    resizeBtn:SetPushedTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Down")
    resizeBtn:SetScript("OnMouseDown", function(self, button)
        if not ChatTranslatorSettings.isLocked and button == "LeftButton" then
            outputBox:StartSizing("BOTTOMRIGHT")
        end
    end)
    resizeBtn:SetScript("OnMouseUp", function(self, button)
        if button == "LeftButton" then
            outputBox:StopMovingOrSizing()
            ChatTranslatorSettings.frameWidth = outputBox:GetWidth()
            ChatTranslatorSettings.frameHeight = outputBox:GetHeight()
        end
    end)
    resizeBtn:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        GameTooltip:SetText("Drag to resize")
        GameTooltip:Show()
    end)
    resizeBtn:SetScript("OnLeave", function() GameTooltip:Hide() end)
    resizeBtn:EnableMouse(not (ChatTranslatorSettings.isLocked or false))
end

-- UI: Minimap Button
local function InitializeMinimapButton()
    minimapButton = CreateFrame("Button", "ChatTranslatorMinimap", Minimap)
    minimapButton:SetSize(32, 32)
    minimapButton:SetFrameStrata("MEDIUM")
    minimapButton:SetPoint("TOPLEFT", Minimap, "TOPLEFT")
    minimapButton:SetNormalTexture("Interface\\Icons\\INV_Misc_Note_02")
    minimapButton:SetHighlightTexture("Interface\\Minimap\\UI-Minimap-ZoomButton-Highlight")
    minimapButton:SetPushedTexture("Interface\\Minimap\\UI-Minimap-ZoomButton-Highlight")
    minimapButton:SetScript("OnClick", function(self)
        if configFrame:IsShown() then
            configFrame:Hide()
        else
            configFrame:Show()
        end
    end)
end

-- UI: Config Panel
local function InitializeConfigFrame()
    configFrame = CreateFrame("Frame", "ChatTranslatorConfig", UIParent)
    configFrame:SetSize(250, 200)
    configFrame:SetPoint("CENTER")
    configFrame:SetBackdrop({
        bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background",
        edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border",
        tile = true, tileSize = 32, edgeSize = 16,
        insets = { left = 4, right = 4, top = 4, bottom = 4 }
    })
    configFrame:Hide()

    dropdown = CreateFrame("Frame", "ChatTranslatorLangDrop", configFrame, "UIDropDownMenuTemplate")
    dropdown:SetPoint("TOP", 0, -20)
    UIDropDownMenu_SetWidth(dropdown, 120)
    UIDropDownMenu_SetText(dropdown, languageNames[ChatTranslatorSettings.targetLanguage or targetLanguage])

    UIDropDownMenu_Initialize(dropdown, function(self)
        local info = UIDropDownMenu_CreateInfo()
        for code, name in pairs(languageNames) do
            info.text = name
            info.value = code
            info.func = function(self)
                targetLanguage = self.value
                UIDropDownMenu_SetText(dropdown, languageNames[code])
                ChatTranslatorSettings.targetLanguage = targetLanguage
            end
            UIDropDownMenu_AddButton(info)
        end
    end)

    opacitySlider = CreateFrame("Slider", "ChatTranslatorOpacitySlider", configFrame, "OptionsSliderTemplate")
    opacitySlider:SetPoint("TOP", dropdown, "BOTTOM", 0, -20)
    opacitySlider:SetWidth(150)
    opacitySlider:SetMinMaxValues(0, 1)
    opacitySlider:SetValueStep(0.1)
    opacitySlider:SetValue(ChatTranslatorSettings.opacity or 0.8)

    if not opacitySlider.Text then
        opacitySlider.Text = opacitySlider:CreateFontString(nil, "OVERLAY", "GameFontNormal")
        opacitySlider.Text:SetPoint("BOTTOM", opacitySlider, "TOP", 0, 2)
    end
    opacitySlider.Text:SetText("Opacity")

    if not opacitySlider.Low then
        opacitySlider.Low = opacitySlider:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        opacitySlider.Low:SetPoint("TOPLEFT", opacitySlider, "BOTTOMLEFT", 0, -2)
    end
    opacitySlider.Low:SetText("0%")

    if not opacitySlider.High then
        opacitySlider.High = opacitySlider:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        opacitySlider.High:SetPoint("TOPRIGHT", opacitySlider, "BOTTOMRIGHT", 0, -2)
    end
    opacitySlider.High:SetText("100%")

    opacitySlider:SetScript("OnValueChanged", function(self, value)
        local alpha = value
        outputBox:SetBackdropColor(0, 0, 0, alpha)
        outputBox:SetBackdropBorderColor(1, 1, 1, alpha)
        ChatTranslatorSettings.opacity = alpha
    end)

    lockCheckBox = CreateFrame("CheckButton", "ChatTranslatorLockCheckBox", configFrame, "InterfaceOptionsCheckButtonTemplate")
    lockCheckBox:SetPoint("TOP", opacitySlider, "BOTTOM", 0, -20)
    if not lockCheckBox.Text then
        lockCheckBox.Text = lockCheckBox:CreateFontString(nil, "OVERLAY", "GameFontNormal")
        lockCheckBox.Text:SetPoint("LEFT", lockCheckBox, "RIGHT", 4, 0)
    end
    lockCheckBox.Text:SetText("Lock Frame")
    lockCheckBox:SetChecked(ChatTranslatorSettings.isLocked or false)
    lockCheckBox:SetScript("OnClick", function(self)
        local isChecked = self:GetChecked()
        ChatTranslatorSettings.isLocked = isChecked
        outputBox:SetMovable(not isChecked)
        outputBox:EnableMouse(not isChecked)
        resizeBtn:EnableMouse(not isChecked)
    end)

    local resetButton = CreateFrame("Button", nil, configFrame, "UIPanelButtonTemplate")
    resetButton:SetSize(100, 25)
    resetButton:SetPoint("BOTTOM", 0, 10)
    resetButton:SetText("Reset to Default")
    resetButton:SetScript("OnClick", function()
        ChatTranslatorSettings.opacity = 0.8
        ChatTranslatorSettings.isLocked = false
        ChatTranslatorSettings.framePoint = nil
        ChatTranslatorSettings.frameWidth = 350
        ChatTranslatorSettings.frameHeight = 200
        ChatTranslatorSettings.targetLanguage = "en"
        outputBox:SetBackdropColor(0, 0, 0, 0.8)
        outputBox:SetBackdropBorderColor(1, 1, 1, 0.8)
        outputBox:ClearAllPoints()
        outputBox:SetPoint("CENTER")
        outputBox:SetSize(350, 200)
        opacitySlider:SetValue(0.8)
        lockCheckBox:SetChecked(false)
        outputBox:SetMovable(true)
        outputBox:EnableMouse(true)
        resizeBtn:EnableMouse(true)
        targetLanguage = "en"
        UIDropDownMenu_SetText(dropdown, languageNames["en"])
    end)
end

-- Initialize UI
local function InitializeUI()
    ChatTranslatorSettings = ChatTranslatorSettings or {}
    ChatTranslatorSettings.opacity = ChatTranslatorSettings.opacity or 0.8
    ChatTranslatorSettings.isLocked = ChatTranslatorSettings.isLocked or false
    ChatTranslatorSettings.targetLanguage = ChatTranslatorSettings.targetLanguage or "en"

    InitializeOutputBox()
    InitializeConfigFrame()
    InitializeMinimapButton()

    -- Apply settings immediately after UI creation
    outputBox:SetBackdropColor(0, 0, 0, ChatTranslatorSettings.opacity)
    outputBox:SetBackdropBorderColor(1, 1, 1, ChatTranslatorSettings.opacity)
    outputBox:SetMovable(not ChatTranslatorSettings.isLocked)
    outputBox:EnableMouse(not ChatTranslatorSettings.isLocked)
    resizeBtn:EnableMouse(not ChatTranslatorSettings.isLocked)
    opacitySlider:SetValue(ChatTranslatorSettings.opacity)
    lockCheckBox:SetChecked(ChatTranslatorSettings.isLocked)
    UIDropDownMenu_SetText(dropdown, languageNames[ChatTranslatorSettings.targetLanguage] or "English")
end

-- Chat events
local chatEvents = {
    ["CHAT_MSG_SAY"] = true,
    ["CHAT_MSG_PARTY"] = true,
    ["CHAT_MSG_RAID"] = true,
    ["CHAT_MSG_YELL"] = true,
    ["CHAT_MSG_WHISPER"] = true,
    ["CHAT_MSG_CHANNEL"] = true,
    ["CHAT_MSG_GUILD"] = true,
    ["CHAT_MSG_BATTLEGROUND"] = true,
}
for event in pairs(chatEvents) do
    frame:RegisterEvent(event)
end
frame:RegisterEvent("ADDON_LOADED")
frame:RegisterEvent("PLAYER_LOGOUT")

-- Event handler
frame:SetScript("OnEvent", function(self, event, ...)
    if event == "ADDON_LOADED" then
        local name = ...
        if name == addonName then
            ChatTranslatorSettings = ChatTranslatorSettings or {}
            InitializeUI()
        end
    elseif event == "PLAYER_LOGOUT" then
        -- Save settings on logout
        ChatTranslatorSettings = ChatTranslatorSettings or {}
        ChatTranslatorSettings.targetLanguage = targetLanguage
        ChatTranslatorSettings.opacity = opacitySlider and opacitySlider:GetValue() or ChatTranslatorSettings.opacity or 0.8
        ChatTranslatorSettings.isLocked = lockCheckBox and lockCheckBox:GetChecked() or ChatTranslatorSettings.isLocked or false
        if outputBox then
            local point, relativeTo, relativePoint, xOfs, yOfs = outputBox:GetPoint()
            ChatTranslatorSettings.framePoint = { point, "UIParent", relativePoint, xOfs, yOfs }
            ChatTranslatorSettings.frameWidth = outputBox:GetWidth()
            ChatTranslatorSettings.frameHeight = outputBox:GetHeight()
        end
    elseif chatEvents[event] then
        local message, sender = ...
        if message and sender then
            local trimmedMessage = trim(message)
            if trimmedMessage ~= "" then
                local detectedLang = detectLanguage(trimmedMessage)
                if detectedLang ~= targetLanguage then
                    local translated = translateMessage(trimmedMessage, detectedLang, targetLanguage)
                    if translated then
                        local displayText = sender .. ": " .. translated .. " (translated from " .. (languageNames[detectedLang] or "Unknown") .. " to " .. (languageNames[targetLanguage] or "English") .. ")"
                        msgFrame:AddMessage(displayText)
                        outputBox:Show()
                    end
                end
            end
        end
    end
end)

-- Slash commands
SLASH_CHATTRANSLATOR1 = "/chattranslator"
SlashCmdList["CHATTRANSLATOR"] = function()
    if outputBox:IsShown() then
        outputBox:Hide()
    else
        outputBox:Show()
    end
end

-- Initialize (Ensures ChatTranslatorSettings table exists for addon loading)
ChatTranslatorSettings = ChatTranslatorSettings or {}

-- ============== BULGARIAN LANGUAGE PATCH START ==============
-- This block of code adds full Bulgarian language support to the ChatTranslator addon.
-- It is designed to be appended to the end of the original ChatTranslator.lua file.

do
    -- Step 1: Add Bulgarian to the list of supported languages.
    if languageNames and not languageNames["bg"] then
        languageNames["bg"] = "Bulgarian" -- Bulgarian 
    end

    -- Step 2: Define the complete Bulgarian translations list.
    local bulgarian_translations = {
        ["be"] = "съм",
        ["am"] = "съм",
        ["is"] = "е",
        ["portal"] = "портал",
        ["dala"] = "Даларан",
        ["community"] = "общност",
        ["most"] = "повечето",
        ["spot"] = "място",
        ["dm"] = "лично съобщение",
        ["smoke"] = "дим",
        ["event"] = "събитие",
        ["title"] = "титла",
        ["information"] = "информация",
        ["boost"] = "бууст",
        ["trinkets"] = "тринкети",
        ["trinket"] = "тринкет",
        ["items"] = "предмети",
        ["item"] = "предмет",
        ["wts"] = "продавам",
        ["weapon"] = "оръжие",
        ["weapons"] = "оръжия",
        ["bis"] = "най-добър в слота",
        ["naxx"] = "Наксрамас",
        ["icc"] = "Цитаделата на Ледената Корона",
        ["casted"] = "кастнат",
        ["fool"] = "глупак",
        ["dont"] = "недей",
        ["bubble"] = "балон",
        ["feral"] = "ферал",
        ["hello"] = "здравей",
        ["yea"] = "да",
        ["nah"] = "не",
        ["traded"] = "разменен",
        ["fought"] = "бит",
        ["thing"] = "нещо",
        ["things"] = "неща",
        ["bro"] = "брато",
        ["goodbye"] = "довиждане",
        ["please"] = "моля",
        ["thank you"] = "благодаря",
        ["yes"] = "да",
        ["no"] = "не",
        ["pull now"] = "дърпай сега",
        ["watch aggro"] = "внимавай с агрото",
        ["pop cooldowns"] = "използвай кулдауни",
        ["wipe it"] = "уайпваме",
        ["stack up"] = "съберете се",
        ["spread out"] = "разпръснете се",
        ["kick interrupt"] = "прекини",
        ["taunt now"] = "таунт сега",
        ["swap target"] = "смени целта",
        ["focus boss"] = "фокус върху боса",
        ["clear adds"] = "изчисти адовете",
        ["stay alive"] = "остани жив",
        ["big heal"] = "голям хийл",
        ["dispel now"] = "диспел сега",
        ["move out"] = "излез",
        ["watch floor"] = "гледай пода",
        ["drop portal"] = "пусни портал",
        ["lust now"] = "блъдлъст сега",
        ["save mana"] = "пази мана",
        ["full focus"] = "пълен фокус",
        ["burn phase"] = "бърн фаза",
        ["hold dps"] = "спри ДПС-а",
        ["go hard"] = "давай здраво",
        ["nice pull"] = "добър пул",
        ["huge crit"] = "огромен крит",
        ["we got this"] = "наш е",
        ["one shot"] = "уаншот",
        ["bad call"] = "лошо решение",
        ["clutch heal"] = "ключов хийл",
        ["tank down"] = "танкът падна",
        ["rez now"] = "рез сега",
        ["cc broke"] = "СС-то се счупи",
        ["gear check"] = "проверка на екипировката",
        ["chill out"] = "спокойно",
        ["tight fight"] = "оспорвана битка",
        ["sick loot"] = "яка плячка",
        ["noob move"] = "нубски ход",
        ["gank alert"] = "внимание, ганк",
        ["camped hard"] = "здрав къмпинг",
        ["pvp time"] = "време за ПвП",
        ["arena pop"] = "арената е готова",
        ["lock down"] = "заключи",
        ["peel for"] = "пази",
        ["burst him"] = "бърстни го",
        ["kite away"] = "кайтвай надалеч",
        ["call inc"] = "обади се за инк",
        ["heal me"] = "хийлни ме",
        ["watch back"] = "пази си гърба",
        ["good try"] = "добър опит",
        ["next pull"] = "следващия пул",
        ["raid up"] = "рейдът е готов",
        ["sorry"] = "съжалявам",
        ["excuse me"] = "извинете",
        ["good morning"] = "добро утро",
        ["good night"] = "лека нощ",
        ["how are you"] = "как си",
        ["my name is"] = "казвам се",
        ["friend"] = "приятел",
        ["family"] = "семейство",
        ["love"] = "любов",
        ["home"] = "дом",
        ["school"] = "училище",
        ["teacher"] = "учител",
        ["student"] = "ученик",
        ["book"] = "книга",
        ["pen"] = "химикал",
        ["paper"] = "хартия",
        ["table"] = "маса",
        ["chair"] = "стол",
        ["door"] = "врата",
        ["window"] = "прозорец",
        ["time"] = "време",
        ["day"] = "ден",
        ["night"] = "нощ",
        ["week"] = "седмица",
        ["month"] = "месец",
        ["year"] = "година",
        ["today"] = "днес",
        ["tomorrow"] = "утре",
        ["yesterday"] = "вчера",
        ["mother"] = "майка",
        ["father"] = "баща",
        ["brother"] = "брат",
        ["sister"] = "сестра",
        ["child"] = "дете",
        ["food"] = "храна",
        ["water"] = "вода",
        ["bread"] = "хляб",
        ["milk"] = "мляко",
        ["apple"] = "ябълка",
        ["house"] = "къща",
        ["car"] = "кола",
        ["dog"] = "куче",
        ["cat"] = "котка",
        ["bird"] = "птица",
        ["tree"] = "дърво",
        ["flower"] = "цвете",
        ["sun"] = "слънце",
        ["moon"] = "луна",
        ["star"] = "звезда",
        ["sky"] = "небе",
        ["cloud"] = "облак",
        ["rain"] = "дъжд",
        ["wind"] = "вятър",
        ["big"] = "голям",
        ["small"] = "малък",
        ["hot"] = "горещ",
        ["cold"] = "студен",
        ["happy"] = "щастлив",
        ["sad"] = "тъжен",
        ["good"] = "добър",
        ["bad"] = "лош",
        ["eat"] = "ям",
        ["drink"] = "пия",
        ["sleep"] = "спя",
        ["walk"] = "ходя",
        ["run"] = "тичам",
        ["read"] = "чета",
        ["write"] = "пиша",
        ["speak"] = "говоря",
        ["listen"] = "слушам",
        ["see"] = "виждам",
        ["one"] = "едно",
        ["two"] = "две",
        ["three"] = "три",
        ["four"] = "четири",
        ["five"] = "пет",
        ["red"] = "червен",
        ["blue"] = "син",
        ["green"] = "зелен",
        ["yellow"] = "жълт",
        ["black"] = "черен",
        ["white"] = "бял",
        ["man"] = "мъж",
        ["woman"] = "жена",
        ["city"] = "град",
        ["country"] = "държава",
        ["street"] = "улица",
        ["fresh"] = "свеж",
        ["mr"] = "господин",
        ["mrs"] = "госпожа",
        ["i want"] = "искам",
        ["inv"] = "покани",
        ["add"] = "добави",
        ["remove"] = "премахни",
        ["yo"] = "ей",
        ["ty"] = "благодаря",
        ["are"] = "са",
        ["was"] = "беше",
        ["have"] = "имам",
        ["had"] = "имах",
        ["lfm"] = "търся още",
        ["player"] = "играч",
        ["players"] = "играчи",
        ["skilled"] = "опитен",
        ["free"] = "свободен",
        ["here"] = "тук",
        ["equal"] = "равен",
        ["someone"] = "някой",
        ["me"] = "мен",
        ["help"] = "помощ",
        ["with"] = "с",
        ["a"] = "един",
        ["little"] = "малко",
        ["gold"] = "злато",
        ["need"] = "трябва ми",
        ["give"] = "дай",
        ["can you"] = "можеш ли",
        ["trade"] = "търгувай",
        ["more"] = "още",
        ["some"] = "няколко",
        ["now"] = "сега",
        ["info"] = "инфо",
        ["do"] = "правя",
        ["did"] = "направих",
        ["say"] = "казвам",
        ["said"] = "казах",
        ["get"] = "вземи",
        ["got"] = "взех",
        ["make"] = "правя",
        ["made"] = "направих",
        ["go"] = "върви",
        ["went"] = "отидох",
        ["know"] = "знам",
        ["knew"] = "знаех",
        ["think"] = "мисля",
        ["thought"] = "мислех",
        ["quest"] = "куест",
        ["damn"] = "по дяволите",
        ["shit"] = "лайна",
        ["fuck"] = "мамка му",
        ["asshole"] = "задник",
        ["bitch"] = "кучка",
        ["noob"] = "нуб",
        ["suck"] = "гадно е",
        ["trash talk"] = "обиди",
        ["get good"] = "стани по-добър",
        ["you suck"] = "смотан си",
        ["dungeon"] = "дънджън",
        ["take"] = "вземи",
        ["took"] = "взех",
        ["saw"] = "видях",
        ["come"] = "ела",
        ["came"] = "дойдох",
        ["want"] = "искам",
        ["wanted"] = "исках",
        ["look"] = "виж",
        ["use"] = "използвай",
        ["find"] = "намери",
        ["found"] = "намерих",
        ["gave"] = "дадох",
        ["tell"] = "кажи",
        ["told"] = "казах",
        ["work"] = "работя",
        ["call"] = "обади се",
        ["try"] = "опитай",
        ["ask"] = "питай",
        ["feel"] = "чувствам",
        ["become"] = "ставам",
        ["leave"] = "напусни",
        ["put"] = "сложи",
        ["mean"] = "означава",
        ["keep"] = "пази",
        ["let"] = "нека",
        ["running"] = "тичащ",
        ["ran"] = "тичах",
        ["talk"] = "говоря",
        ["talking"] = "говорейки",
        ["wait"] = "чакай",
        ["waiting"] = "чакащ",
        ["play"] = "играй",
        ["playing"] = "играейки",
        ["meet"] = "срещни",
        ["start"] = "започни",
        ["stop"] = "спри",
        ["move"] = "мръдни",
        ["like"] = "харесвам",
        ["live"] = "живея",
        ["believe"] = "вярвам",
        ["heals"] = "лекува",
        ["needs"] = "нуждае се",
        ["makes"] = "прави",
        ["goes"] = "отива",
        ["knows"] = "знае",
        ["thinks"] = "мисли",
        ["takes"] = "взема",
        ["sees"] = "вижда",
        ["comes"] = "идва",
        ["wants"] = "иска",
        ["looks"] = "изглежда",
        ["uses"] = "използва",
        ["finds"] = "намира",
        ["gives"] = "дава",
        ["tells"] = "казва",
        ["works"] = "работи",
        ["calls"] = "обажда се",
        ["tries"] = "опитва",
        ["asks"] = "пита",
        ["feels"] = "чувства",
        ["becomes"] = "става",
        ["leaves"] = "напуска",
        ["puts"] = "слага",
        ["means"] = "означава",
        ["keeps"] = "пази",
        ["lets"] = "позволява",
        ["runs"] = "тича",
        ["talks"] = "говори",
        ["waits"] = "чака",
        ["plays"] = "играе",
        ["meets"] = "среща",
        ["starts"] = "започва",
        ["stops"] = "спира",
        ["moves"] = "движи се",
        ["likes"] = "харесва",
        ["lives"] = "живее",
        ["believes"] = "вярва",
        ["brings"] = "носи",
        ["writes"] = "пише",
        ["sits"] = "седи",
        ["stands"] = "стои",
        ["loses"] = "губи",
        ["pays"] = "плаща",
        ["buys"] = "купува",
        ["sells"] = "продава",
        ["walks"] = "ходи",
        ["reads"] = "чете",
        ["sends"] = "изпраща",
        ["builds"] = "строи",
        ["stays"] = "остава",
        ["falls"] = "пада",
        ["changes"] = "променя",
        ["opens"] = "отваря",
        ["closes"] = "затваря",
        ["watches"] = "гледа",
        ["follows"] = "следва",
        ["begins"] = "започва",
        ["ends"] = "свършва",
        ["finishes"] = "завършва",
        ["joins"] = "присъединява се",
        ["breaks"] = "чупи",
        ["checks"] = "проверява",
        ["fights"] = "бие се",
        ["defends"] = "защитава",
        ["attacks"] = "атакува",
        ["casts"] = "каства",
        ["summons"] = "призовава",
        ["loots"] = "плячкосва",
        ["equips"] = "екипира",
        ["trades"] = "търгува",
        ["invites"] = "кани",
        ["kicks"] = "рита",
        ["wins"] = "печели",
        ["dies"] = "умира",
        ["kills"] = "убива",
        ["revives"] = "съживява",
        ["escapes"] = "избягва",
        ["hides"] = "крие се",
        ["searches"] = "търси",
        ["explores"] = "изследва",
        ["crafts"] = "изработва",
        ["gathers"] = "събира",
        ["mines"] = "копае",
        ["fishes"] = "лови риба",
        ["cooks"] = "готви",
        ["enchants"] = "омагьосва",
        ["disenchants"] = "разомагьосва",
        ["repairs"] = "поправя",
        ["upgrades"] = "подобрява",
        ["resurrects"] = "възкресява",
        ["bring"] = "донеси",
        ["happen"] = "случва се",
        ["sit"] = "седни",
        ["stand"] = "стани",
        ["lose"] = "губя",
        ["pay"] = "плащам",
        ["buy"] = "купувам",
        ["sell"] = "продавам",
        ["send"] = "изпращам",
        ["build"] = "строя",
        ["stay"] = "оставам",
        ["fall"] = "падам",
        ["change"] = "променям",
        ["open"] = "отварям",
        ["close"] = "затварям",
        ["watch"] = "гледам",
        ["follow"] = "следвам",
        ["begin"] = "започвам",
        ["end"] = "край",
        ["finish"] = "свършвам",
        ["join"] = "присъедини се",
        ["break"] = "счупи",
        ["check"] = "провери",
        ["I"] = "аз",
        ["you"] = "ти",
        ["he"] = "той",
        ["she"] = "тя",
        ["it"] = "то",
        ["we"] = "ние",
        ["they"] = "те",
        ["him"] = "него",
        ["her"] = "нея",
        ["us"] = "нас",
        ["them"] = "тях",
        ["my"] = "мой",
        ["your"] = "твой",
        ["his"] = "негов",
        ["our"] = "наш",
        ["their"] = "техен",
        ["an"] = "един",
        ["the"] = "определителен член",
        ["in"] = "в",
        ["on"] = "на",
        ["at"] = "при",
        ["to"] = "до",
        ["for"] = "за",
        ["by"] = "от",
        ["of"] = "на",
        ["from"] = "от",
        ["up"] = "нагоре",
        ["down"] = "надолу",
        ["over"] = "над",
        ["under"] = "под",
        ["between"] = "между",
        ["through"] = "през",
        ["into"] = "в",
        ["out"] = "навън",
        ["off"] = "изключено",
        ["about"] = "относно",
        ["and"] = "и",
        ["but"] = "но",
        ["or"] = "или",
        ["if"] = "ако",
        ["when"] = "когато",
        ["because"] = "защото",
        ["since"] = "откакто",
        ["while"] = "докато",
        ["although"] = "въпреки че",
        ["then"] = "тогава",
        ["there"] = "там",
        ["very"] = "много",
        ["really"] = "наистина",
        ["just"] = "просто",
        ["still"] = "все още",
        ["always"] = "винаги",
        ["never"] = "никога",
        ["new"] = "нов",
        ["old"] = "стар",
        ["fast"] = "бърз",
        ["slow"] = "бавен",
        ["easy"] = "лесен",
        ["hard"] = "труден",
        ["place"] = "място",
        ["way"] = "път",
        ["people"] = "хора",
        ["problem"] = "проблем",
        ["question"] = "въпрос",
        ["answer"] = "отговор",
        ["game"] = "игра",
        ["world"] = "свят",
        ["life"] = "живот",
        ["death"] = "смърт",
        ["area"] = "зона",
        ["room"] = "стая",
        ["money"] = "пари",
        ["enemy"] = "враг",
        ["power"] = "сила",
        ["light"] = "светлина",
        ["dark"] = "тъмен",
        ["fire"] = "огън",
        ["earth"] = "земя",
        ["air"] = "въздух",
        ["hour"] = "час",
        ["minute"] = "минута",
        ["morning"] = "сутрин",
        ["evening"] = "вечер",
        ["this"] = "този",
        ["that"] = "онзи",
        ["all"] = "всички",
        ["any"] = "някакъв",
        ["first"] = "първи",
        ["last"] = "последен",
        ["next"] = "следващ",
        ["other"] = "друг",
        ["same"] = "същият",
        ["different"] = "различен",
        ["many"] = "много",
        ["few"] = "малко",
        ["less"] = "по-малко",
        ["what"] = "какво",
        ["who"] = "кой",
        ["where"] = "къде",
        ["why"] = "защо",
        ["how"] = "как",
        ["DPS"] = "ДПС",
        ["damage dealer"] = "нанасящ щети",
        ["DD"] = "ДД",
        ["tank"] = "танк",
        ["healer"] = "лечител",
        ["main tank"] = "главен танк",
        ["off tank"] = "втори танк",
        ["aggro"] = "агро",
        ["threat"] = "заплаха",
        ["taunt"] = "провокация",
        ["pull"] = "дърпане",
        ["wipe"] = "уайп",
        ["cooldown"] = "кулдаун",
        ["CC"] = "СС",
        ["crowd control"] = "контрол на тълпата",
        ["interrupt"] = "прекъсване",
        ["dispel"] = "диспел",
        ["kiting"] = "кайтене",
        ["stack"] = "събиране",
        ["move out of fire"] = "излез от огъня",
        ["focus"] = "фокус",
        ["focus target"] = "фокус цел",
        ["buff"] = "бъф",
        ["debuff"] = "дебъф",
        ["mana"] = "мана",
        ["rage"] = "ярост",
        ["runic power"] = "руническа сила",
        ["critic"] = "критичен удар",
        ["haste"] = "бързина",
        ["melee"] = "близък бой",
        ["ranged"] = "далечен бой",
        ["damage"] = "щета",
        ["stun"] = "зашеметяване",
        ["silence"] = "заглушаване",
        ["root"] = "вкореняване",
        ["fear"] = "страх",
        ["revive me"] = "съживи ме",
        ["resurrection"] = "възкресение",
        ["need heal"] = "трябва ми хийл",
        ["need tank"] = "трябва ми танк",
        ["healing"] = "лекуване",
        ["out of mana"] = "без мана",
        ["low mana"] = "малко мана",
        ["rez"] = "рез",
        ["battle rez"] = "боен рез",
        ["mass resurrection"] = "масово възкресение",
        ["need rez"] = "трябва ми рез",
        ["direct heal"] = "директен хийл",
        ["quick heal"] = "бърз хийл",
        ["heal tank"] = "хийл на танка",
        ["full health"] = "пълно здраве",
        ["low health"] = "малко здраве",
        ["mana regen"] = "регенерация на мана",
        ["need mana"] = "трябва ми мана",
        ["mana pot"] = "мана поушън",
        ["innervate"] = "инървейт",
        ["mana tide"] = "мана тайд",
        ["evocation"] = "евокейшън",
        ["health"] = "здраве",
        ["potion"] = "отвара",
        ["stunned"] = "зашеметен",
        ["fight"] = "битка",
        ["defend"] = "защитавай",
        ["cast"] = "каствай",
        ["summon"] = "призови",
        ["loot"] = "плячка",
        ["equip"] = "екипирай",
        ["invite"] = "покани",
        ["kick"] = "ритни",
        ["win"] = "победа",
        ["die"] = "умри",
        ["kill"] = "убий",
        ["revive"] = "съживи",
        ["escape"] = "избягай",
        ["hide"] = "скрий се",
        ["search"] = "търси",
        ["explore"] = "изследвай",
        ["craft"] = "изработвай",
        ["gather"] = "събирай",
        ["mine"] = "копай",
        ["fish"] = "лови риба",
        ["cook"] = "готви",
        ["enchant"] = "омагьосай",
        ["disenchant"] = "разомагьосай",
        ["repair"] = "поправи",
        ["upgrade"] = "подобри",
        ["strong"] = "силен",
        ["weak"] = "слаб",
        ["powerful"] = "мощен",
        ["magical"] = "магически",
        ["legendary"] = "легендарен",
        ["rare"] = "рядък",
        ["common"] = "обикновен",
        ["epic"] = "епичен",
        ["unique"] = "уникален",
        ["cursed"] = "прокълнат",
        ["blessed"] = "благословен",
        ["enchanted"] = "омагьосан",
        ["broken"] = "счупен",
        ["damaged"] = "повреден",
        ["repaired"] = "поправен",
        ["upgraded"] = "подобрен",
        ["shiny"] = "лъскав",
        ["dull"] = "матов",
        ["bright"] = "светъл",
        ["heavy"] = "тежък",
        ["quick"] = "бърз",
        ["agile"] = "пъргав",
        ["clumsy"] = "непохватен",
        ["smart"] = "умен",
        ["wise"] = "мъдър",
        ["level"] = "ниво",
        ["experience"] = "опит",
        ["guild"] = "гилдия",
        ["raid"] = "рейд",
        ["boss"] = "бос",
        ["minion"] = "миньон",
        ["ally"] = "съюзник",
        ["opponent"] = "опонент",
        ["victory"] = "победа",
        ["defeat"] = "загуба",
        ["strategy"] = "стратегия",
        ["tactic"] = "тактика",
        ["skill"] = "умение",
        ["ability"] = "способност",
        ["talent"] = "талант",
        ["profession"] = "професия",
        ["crafting"] = "изработване",
        ["gathering"] = "събиране",
        ["auction"] = "търг",
        ["bank"] = "банка",
        ["mailbox"] = "пощенска кутия",
        ["vendor"] = "търговец",
        ["trainer"] = "треньор",
        ["inn"] = "кръчма",
        ["arena"] = "арена",
        ["battleground"] = "бойно поле",
        ["Azeroth"] = "Азерот",
        ["Horde"] = "Орда",
        ["Alliance"] = "Алианс",
        ["warrior"] = "воин",
        ["paladin"] = "паладин",
        ["hunter"] = "ловец",
        ["rogue"] = "разбойник",
        ["priest"] = "жрец",
        ["shaman"] = "шаман",
        ["mage"] = "маг",
        ["warlock"] = "уорлок",
        ["druid"] = "друид",
        ["hi"] = "здрасти",
        ["group"] = "група",
        ["sword"] = "меч",
        ["axe"] = "брадва",
        ["mace"] = "боздуган",
        ["dagger"] = "кама",
        ["staff"] = "жезъл",
        ["bow"] = "лък",
        ["crossbow"] = "арбалет",
        ["gun"] = "пушка",
        ["polearm"] = "копие",
        ["fist weapon"] = "оръжие за юмрук",
        ["thrown weapon"] = "метателно оръжие",
        ["shield"] = "щит",
        ["cloth"] = "плат",
        ["leather"] = "кожа",
        ["mail"] = "плетена ризница",
        ["plate"] = "плочеста броня",
        ["helm"] = "шлем",
        ["shoulders"] = "рамене",
        ["chest"] = "гърди",
        ["bracers"] = "накитници",
        ["gloves"] = "ръкавици",
        ["belt"] = "колан",
        ["legs"] = "крака",
        ["boots"] = "ботуши",
        ["ring"] = "пръстен",
        ["cloak"] = "плащ",
        ["back"] = "гръб",
        ["wrist"] = "китка",
        ["questing"] = "куестване",
        ["grinding"] = "гриндене",
        ["raid leader"] = "рейд лидер",
        ["dungeon finder"] = "търсач на дънджъни",
        ["party sync"] = "синхронизация на групата",
        ["transmog"] = "трансмог",
        ["addon"] = "аддон",
        ["macro"] = "макрос",
        ["talent tree"] = "дърво на талантите",
        ["spell"] = "заклинание",
        ["quest giver"] = "даващ куест",
        ["mob"] = "моб",
        ["NPC"] = "НПЦ",
        ["emote"] = "емоция",
        ["whisper"] = "шепот",
        ["channel"] = "канал",
        ["trade chat"] = "търговски чат",
        ["general chat"] = "общ чат",
        ["looking for group"] = "търся група",
        ["LFG"] = "ТГ",
        ["WTS"] = "Продава",
        ["WTB"] = "Купува",
        ["WTT"] = "Разменя",
        ["AFK"] = "АФК",
        ["BRB"] = "Веднага се връщам",
        ["GG"] = "Добра игра",
        ["GL"] = "Късмет",
        ["HF"] = "Забавлявай се",
        ["PvP"] = "ПвП",
        ["PvE"] = "ПвЕ",
        ["gank"] = "ганк",
        ["dot"] = "дот",
        ["HoT"] = "хот",
        ["AoE"] = "АоЕ",
        ["respawn"] = "респуаун",
        ["loot spec"] = "специализация на плячката",
        ["dungeon group"] = "група за дънджън",
        ["raid group"] = "рейд група",
        ["pvp group"] = "пвп група",
        ["battleground group"] = "група за бойно поле",
        ["arena team"] = "отбор за арена",
        ["gear"] = "екипировка",
        ["item level"] = "ниво на предмета",
        ["talent point"] = "точка за талант",
        ["glyph"] = "глиф",
        ["mount"] = "маунт",
        ["pet"] = "любимец",
        ["companion"] = "спътник",
        ["profession skill"] = "умение на професията",
        ["gathering node"] = "събирателен възел",
        ["resource"] = "ресурс",
        ["vendor trash"] = "боклук за продавач",
        ["awesome"] = "страхотно",
        ["cool"] = "яко",
        ["no worries"] = "няма грижи",
        ["glad to help"] = "радвам се да помогна",
        ["my pleasure"] = "удоволствието е мое",
        ["cheers mate"] = "наздраве, приятел",
        ["what's happening"] = "какво става",
        ["gotta go"] = "трябва да тръгвам",
        ["cya"] = "чао",
        ["later"] = "по-късно",
        ["have a good one"] = "приятен ден",
        ["np ty"] = "нп, благодаря",
        ["lol out loud"] = "хаха на глас",
        ["ROFL"] = "търкалям се по пода от смях",
        ["BRB AFK"] = "Веднага се връщам, АФК",
        ["IRL"] = "в реалния живот",
        ["GG EZ"] = "Добра игра, лесно",
        ["g2g"] = "трябва да тръгвам",
        ["wp"] = "добра игра",
        ["np"] = "няма проблем",
        ["idk"] = "не знам",
        ["imo"] = "по мое мнение",
        ["imho"] = "по мое скромно мнение",
        ["afaik"] = "доколкото знам",
        ["tldr"] = "твърде дълго, не го прочетох",
        ["IRL stuff"] = "неща от реалния живот",
        ["buff timer"] = "таймер на бъфа",
        ["debuff timer"] = "таймер на дебъфа",
        ["threat management"] = "управление на заплахата",
        ["aggro drop"] = "спадане на агрото",
        ["pull range"] = "обхват на дърпане",
        ["melee range"] = "обхват за близък бой",
        ["ranged range"] = "обхват за далечен бой",
        ["LOS me"] = "скрий ме от погледа",
        ["line up"] = "нареди се",
        ["position yourself"] = "позиционирай се",
        ["get behind"] = "мини отзад",
        ["frontals"] = "фронтални атаки",
        ["cones"] = "конусовидни атаки",
        ["circles"] = "кръгови атаки",
        ["raid leading"] = "рейд лидерство",
        ["healing stream"] = "поток на лечение",
        ["healing rain"] = "дъжд на лечение",
        ["chain heal"] = "верижен хийл",
        ["flash heal"] = "бърз хийл",
        ["greater heal"] = "по-голям хийл",
        ["renew"] = "обновяване",
        ["power word shield"] = "щит на силата",
        ["divine hymn"] = "божествен химн",
        ["guardian spirit"] = "пазител дух",
        ["dispellable"] = "може да се диспелне",
        ["cleanse please"] = "изчисти, моля",
        ["remove curse"] = "премахни проклятие",
        ["remove poison"] = "премахни отрова",
        ["remove disease"] = "премахни болест",
        ["CC chain"] = "верига от СС",
        ["break CC"] = "счупи СС",
        ["interrupt this"] = "прекини това",
        ["on target"] = "на целта",
        ["range check"] = "проверка на обхвата",
        ["los pull"] = "пул зад стена",
        ["agro range"] = "обхват на агрото",
        ["last boss"] = "последен бос",
        ["next boss"] = "следващ бос",
        ["alt run"] = "рън с алт",
        ["fresh run"] = "свеж рън",
        ["raid lockout reset"] = "ресет на лока на рейда",
        ["farm content"] = "фарм съдържание",
        ["push content"] = "пуш съдържание",
        ["progression"] = "прогрес",
        ["progression raid"] = "прогрес рейд",
        ["farm raid"] = "фарм рейд",
        ["carry run"] = "кери рън",
        ["boost run"] = "бууст рън",
        ["GDKP"] = "ГДКП",
        ["soft res"] = "софт резервация",
        ["MS > OS"] = "МС > ОС",
        ["Prio"] = "Приоритет",
        ["Trial"] = "Проба",
        ["bench"] = "пейка",
        ["raid time"] = "време за рейд",
        ["raid day"] = "ден за рейд",
        ["raid lead"] = "рейд лидер",
        ["class leader"] = "класов лидер",
        ["loot master"] = "плячкомайстор",
        ["DKP"] = "ДКП",
        ["EPGP"] = "ЕПГП",
        ["loot council"] = "съвет за плячката",
        ["whisper me"] = "пиши ми на лично",
        ["party chat"] = "парти чат",
        ["raid chat"] = "рейд чат",
        ["guild chat"] = "гилдиен чат",
        ["officer chat"] = "офицерски чат",
        ["world chat"] = "световен чат",
        ["lookingforgroup"] = "търсягрупа",
        ["zone chat"] = "зонов чат",
        ["emote chat"] = "емоционален чат",
        ["say chat"] = "чат за казване",
        ["yell chat"] = "чат за викане",
        ["whisper chat"] = "чат за шепот",
        ["report player"] = "докладвай играч",
        ["ticket"] = "тикет",
        ["GM"] = "ГМ",
        ["devs"] = "разработчици",
        ["bug report"] = "доклад за бъг",
        ["server restart"] = "рестарт на сървъра",
        ["weekly reset"] = "седмичен ресет",
        ["daily reset"] = "дневен ресет",
        ["exp gain"] = "получаване на опит",
        ["honor gain"] = "получаване на чест",
        ["gold gain"] = "получаване на злато",
        ["rep gain"] = "получаване на репутация",
        ["alt leveling"] = "левълинг на алт",
        ["transmog run"] = "трансмог рън",
        ["mount run"] = "маунт рън",
        ["pet battle daily"] = "дневна битка с любимци",
        ["auction house flips"] = "обръщане в аукциона",
        ["crafting cooldown"] = "кулдаун на изработването",
        ["profession cap"] = "капачка на професията",
        ["garrison missions"] = "мисии в гарнизона",
        ["order hall missions"] = "мисии в залата на ордена",
        ["covenant abilities"] = "способности на ковенанта",
        ["azerite armor"] = "азеритова броня",
        ["corrupted gear"] = "корумпирана екипировка",
        ["essences slot"] = "слот за есенции",
        ["conduit energy"] = "енергия на проводника",
        ["legendary item"] = "легендарен предмет",
        ["tier token"] = "тиер токен",
        ["set bonus active"] = "активен сет бонус",
        ["trinket usage"] = "използване на тринкет",
        ["consumables stock"] = "запас от консумативи",
        ["raid strategy"] = "рейд стратегия",
        ["boss strategy"] = "бос стратегия",
        ["add control"] = "контрол на адовете",
        ["phase transition"] = "преход на фаза",
        ["soft reset"] = "мек ресет",
        ["hard reset"] = "твърд ресет",
        ["pull timing"] = "време за пул",
        ["group up here"] = "съберете се тук",
        ["stay spread"] = "стойте разпръснати",
        ["move out of void"] = "излез от празнотата",
        ["avoid damage"] = "избягвай щети",
        ["interrupt priority"] = "приоритет на прекъсването",
        ["off tank taunt"] = "таунт на втори танк",
        ["main tank taunt"] = "таунт на главен танк",
        ["target marker"] = "маркер на целта",
        ["raid warning"] = "рейд предупреждение",
        ["guild bank"] = "гилдийна банка",
        ["guild vault"] = "гилдийн трезор",
        ["PvP talent"] = "ПвП талант",
        ["PvE talent"] = "ПвЕ талант",
        ["off-hand weapon"] = "оръжие за лява ръка",
        ["main-hand weapon"] = "оръжие за дясна ръка",
        ["two-handed weapon"] = "двуръчно оръжие",
        ["one-handed weapon"] = "едноръчно оръжие",
        ["gear grind"] = "гринд за екипировка",
        ["talent build advice"] = "съвет за билд на таланти",
        ["glyph setup advice"] = "съвет за настройка на глифове",
        ["gemming strategy"] = "стратегия за гемове",
        ["enchanting materials"] = "материали за омагьосване",
        ["I have"] = "имам",
        ["I do"] = "правя",
        ["I say"] = "казвам",
        ["I get"] = "получавам",
        ["I make"] = "правя",
        ["I go"] = "отивам",
        ["I know"] = "знам",
        ["I think"] = "мисля",
        ["I take"] = "вземам",
        ["I see"] = "виждам",
        ["I come"] = "идвам",
        ["I want"] = "искам",
        ["I look"] = "гледам",
        ["I use"] = "използвам",
        ["I find"] = "намирам",
        ["I give"] = "давам",
        ["I tell"] = "казвам",
        ["I work"] = "работя",
        ["I call"] = "обаждам се",
        ["I try"] = "опитвам",
        ["I ask"] = "питам",
        ["I need"] = "трябва ми",
        ["I feel"] = "чувствам",
        ["I become"] = "ставам",
        ["I leave"] = "напускам",
        ["I put"] = "слагам",
        ["I mean"] = "имам предвид",
        ["I keep"] = "пазя",
        ["I let"] = "позволявам",
        ["I run"] = "тичам",
        ["I talk"] = "говоря",
        ["I wait"] = "чакам",
        ["I play"] = "играя",
        ["I meet"] = "срещам",
        ["I start"] = "започвам",
        ["I stop"] = "спирам",
        ["I move"] = "движа се",
        ["I like"] = "харесвам",
        ["I live"] = "живея",
        ["I believe"] = "вярвам",
        ["I bring"] = "нося",
        ["I write"] = "пиша",
        ["I sit"] = "седя",
        ["I stand"] = "стоя",
        ["I lose"] = "губя",
        ["I pay"] = "плащам",
        ["I buy"] = "купувам",
        ["I sell"] = "продавам",
        ["I walk"] = "ходя",
        ["I read"] = "чета",
        ["I send"] = "изпращам",
        ["I build"] = "строя",
        ["I stay"] = "оставам",
        ["I fall"] = "падам",
        ["I change"] = "променям",
        ["I open"] = "отварям",
        ["I close"] = "затварям",
        ["I watch"] = "гледам",
        ["I follow"] = "следвам",
        ["I begin"] = "започвам",
        ["I end"] = "свършвам",
        ["I finish"] = "завършвам",
        ["I join"] = "присъединявам се",
        ["I break"] = "чупя",
        ["I check"] = "проверявам",
        ["I fight"] = "бия се",
        ["I defend"] = "защитавам",
        ["I attack"] = "атакувам",
        ["I cast"] = "каствам",
        ["I summon"] = "призовавам",
        ["I loot"] = "плячкосвам",
        ["I equip"] = "екипирам",
        ["I trade"] = "търгувам",
        ["I invite"] = "каня",
        ["I kick"] = "ритам",
        ["I win"] = "печеля",
        ["I die"] = "умирам",
        ["I kill"] = "убивам",
        ["I revive"] = "съживявам",
        ["I escape"] = "избягвам",
        ["I hide"] = "крия се",
        ["I search"] = "търся",
        ["I explore"] = "изследвам",
        ["I craft"] = "изработвам",
        ["I gather"] = "събирам",
        ["I mine"] = "копая",
        ["I fish"] = "ловя риба",
        ["I cook"] = "готвя",
        ["I enchant"] = "омагьосвам",
        ["I disenchant"] = "разомагьосвам",
        ["I repair"] = "поправям",
        ["kick this afk"] = "кикни този афк",
        ["I upgrade"] = "подобрявам",
        ["I heal"] = "лекувам",
        ["I resurrect"] = "възкресявам",
        ["gold making guide"] = "ръководство за правене на злато",
        ["greed"] = "алчност",
        ["best in slot list"] = "списък с най-добрите предмети",
        ["current gear"] = "текуща екипировка",
        ["next upgrade"] = "следващо подобрение"
    }

    -- Step 3: Merge the Bulgarian translations into the main 'translations' table.
    -- This logic reads your list above and adds the ".bg" entry to the addon's main list.
    if translations and bulgarian_translations then
        for lemma, bg_translation in pairs(bulgarian_translations) do
            local entry = translations[lemma]
            if entry and type(entry) == "table" then
                entry.bg = bg_translation
            end
        end
    end

    -- Step 4: Rebuild the Bulgarian part of the phraseLookup table.
    -- This is crucial for detecting incoming messages written in Bulgarian.
    if phraseLookup and translations then
        -- Ensure the Bulgarian lookup table exists and clear it.
        phraseLookup["bg"] = {}
        
        -- Populate with the new translations from your list.
        for lemma, data in pairs(translations) do
            if data and data.bg and type(data.bg) == "string" then
                local tokenized_translated_text_for_key = {}
                for token in string.gmatch(string.lower(data.bg), "[^%s%/%%%(%)%?%!%.,;:]+") do
                     table.insert(tokenized_translated_text_for_key, token)
                end
                local lookup_key = table.concat(tokenized_translated_text_for_key, "")
                if lookup_key ~= "" then
                    phraseLookup["bg"][lookup_key] = lemma
                end
            end
        end
    end
    
    -- Step 5: Update the dropdown menu in the config panel if it's already loaded.
    -- This makes the language available without a /reload after the patch is applied.
    if ChatTranslatorConfig and ChatTranslatorLangDrop then
        UIDropDownMenu_Initialize(ChatTranslatorLangDrop, function(self)
            local info = UIDropDownMenu_CreateInfo()
            local sortedLanguageCodes = {}
            for code in pairs(languageNames) do table.insert(sortedLanguageCodes, code) end
            table.sort(sortedLanguageCodes)

            for _, code in ipairs(sortedLanguageCodes) do
                local name = languageNames[code]
                info.text = name
                info.value = code
                info.func = function(dropdown_self)
                    targetLanguage = dropdown_self.value
                    UIDropDownMenu_SetText(ChatTranslatorLangDrop, languageNames[code])
                    ChatTranslatorSettings.targetLanguage = targetLanguage
                end
                UIDropDownMenu_AddButton(info)
            end
        end)
    end

end
-- ============== BULGARIAN LANGUAGE PATCH END ==============