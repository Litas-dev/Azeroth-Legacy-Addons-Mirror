Redeemer
by Ryplinn-Kargath(US)

Welcome to Redeemer! This mod makes you say humorous messages whenever you cast a resurrection spell and serves purely to entertain you and annoy others.

Enjoy!

To select which channels to send Redeemer quotes to, use the /redeemer command.

If you'd like to add in your own messages, feel free to edit the RedeemerQuotes.lua file. Make sure to strictly follow the guidelines at the beginning of the RedeemerQuotes.lua file.

Quotes? Questions? Bug reports? Send them to me at ryplinn@gmail.com. Be sure to include the word "Redeemer" in your subject line.

Changelog

v0.6.2-4/19/2010
-Changed Warlock quote to reflect cooldown changes
-Updated .toc for version 3.3

v0.6.1-8/6/2009
-Fixed Ghoul quotes issue
-Updated for 3.2

v0.6.0-11/12/2008
-Added option for whispering quotes to the target of the rez
-Added Death Knight quotes

v0.5.0-10/26/2008
-Added Revive support
-Added Warlock and self-rez quotes

v0.4.0-6/25/2008
-Added options for saying quotes in party and raid chat through slash commands

v0.3.3-6/1/2008
-Fixed an issue with no-target quotes

v0.3.2-5/31/2008
-Fixed Hunter pet quotes

v0.3.1-3/25/2008
-updated for patch 2.4

v0.3.0a-3/5/2008
-added Hunter messages

v0.2.0a-2/24/2008
-added Engineering messages

v0.1.1a-2/20/2008
-removed debugging messages (oops)

v0.1.0a-2/20/2008
-first version uploaded