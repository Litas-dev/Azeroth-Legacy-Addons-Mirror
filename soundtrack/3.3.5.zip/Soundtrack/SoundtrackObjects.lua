Soundtrack = 
{
    Library = {};    
    Events = {};
    BattleEvents = {};
    ZoneEvents = {};
    DanceEvents = {};
    MountEvents = {};
    Util = {};
    Settings = {};
    Timers = {};
};