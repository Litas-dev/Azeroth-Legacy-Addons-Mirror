--[[
    Soundtrack addon for World of Warcraft

    Soundtrack Profile functions.
]]



function SoundtrackProfile_CreateProfile()

end

function SoundtrackProfile_DeleteProfile()

end

function SoundtrackProfile_CopyProfile()

end