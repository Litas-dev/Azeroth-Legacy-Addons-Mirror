Windows XP:
To enable the option to create links, put junction.exe from the following link into the junction folder.
http://technet.microsoft.com/en-us/sysinternals/bb896768.aspx