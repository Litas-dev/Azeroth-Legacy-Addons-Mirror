Windows XP:
To enable the option to create links, put junction.exe from the following link into this folder.
http://technet.microsoft.com/en-us/sysinternals/bb896768.aspx