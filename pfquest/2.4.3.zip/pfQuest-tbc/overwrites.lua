-- This file can be used to manually overwrite or add contents to the db
-- which weren't detect by the extractor. Make sure to write proper comments
-- and include as much information as possible, as this should be only the
-- intermediate solution and fixing the extractor instead is the desired goal.


-- [[ Quest: Great Bear Spirit ]]
-- Unit: Great Bear Spirit (11956)
-- Type: Talk/Gossip Menu Requirement
pfDB["quests"]["data"][5929]["obj"] = { ["U"] = { 11956 } }
pfDB["quests"]["data"][5930]["obj"] = { ["U"] = { 11956 } }

