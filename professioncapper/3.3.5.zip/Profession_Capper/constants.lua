local addonName, addonTable = ...;

addonTable.chat_frame_default_color = "6BFF75"; ------ pastel green
addonTable.chat_frame_player_name_color = "6BC6FF" --- pastel blue
