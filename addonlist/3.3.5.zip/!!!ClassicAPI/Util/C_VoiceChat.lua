local C_VoiceChat = C_VoiceChat or {}

function C_VoiceChat.GetTtsVoices()
	return {}
end

-- Global
_G.C_VoiceChat = C_VoiceChat