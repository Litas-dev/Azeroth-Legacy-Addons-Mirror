local SOUNDKIT = SOUNDKIT or {}

-- https://github.com/liquidbase/wowui-source/blob/master/SoundKitConstants.lua

SOUNDKIT.IG_MAINMENU_OPTION = "igMainMenuOption"
SOUNDKIT.IG_MAINMENU_OPTION_CHECKBOX_ON = "igMainMenuOptionCheckBoxOn"
SOUNDKIT.IG_MAINMENU_OPTION_CHECKBOX_OFF = "igMainMenuOptionCheckBoxOff"
SOUNDKIT.IG_SPELLBOOK_OPEN = "igSpellBookOpen"
SOUNDKIT.IG_SPELLBOOK_CLOSE = "igSpellBookClose"
SOUNDKIT.GS_LOGIN_CHANGE_REALM_OK = "uChatScrollButton"
SOUNDKIT.GS_LOGIN_CHANGE_REALM_CANCEL = "uChatScrollButton"

-- Global
_G.SOUNDKIT = SOUNDKIT