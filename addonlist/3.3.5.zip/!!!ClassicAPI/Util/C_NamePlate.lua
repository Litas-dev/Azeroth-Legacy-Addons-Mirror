if ( C_NamePlate ) then return end -- (https://github.com/FrostAtom/awesome_wotlk)

--local C_NamePlate = C_NamePlate or {}

-- Global
--_G.C_NamePlate = C_NamePlate