/an ingame to adjust size/positions

![image](https://github.com/Poli93/ArenaNumbers/assets/965110/a33400b6-ad13-4678-a350-27206dffba78)
