local L = LibStub("AceLocale-3.0"):NewLocale("DalaranAH", "enUS", true)
if not L then
  return
end

L["Like Clockwork"] = "Like Clockwork"
L["Brassbolt Mechawrench"] = "Brassbolt Mechawrench"
L["Reginald Arcfire"] = "Reginald Arcfire"
L["Left-click to target"] = "Left-click to target"
L["Press "] = "Press "
L[" to interact with Target"] = " to interact with Target"
L[" or "] = " or "
L[" to interact with Mouseover"] = " to interact with Mouseover"
L["Bind 'Interact with Target' to interact with the Target"] = "Bind 'Interact with Target' to interact with the Target"
L["Bind 'Interact with Mouseover' to interact with the Mouseover"] =
  "Bind 'Interact with Mouseover' to interact with the Mouseover"
L["Reset"] = "Reset"
L["Reset to Defaults"] = "Reset to Defaults"
L["Reset all settings to default?"] = "Reset all settings to default?"
L["General"] = "General"
L["Button Size"] = "Button Size"
L["Additional Functions"] = "Additional Functions"
L["Set Mark on the Auctioneer"] = "Set Mark on the Auctioneer"
L["On-Click sets Mark on the Auctioneer"] = "On-Click sets Mark on the Auctioneer"
L["Select the Mark"] = "Select the Mark"
L["Set Auctioneer as Focus"] = "Set Auctioneer as Focus"
L["On-Click sets Auctioneer as Focus"] = "On-Click sets Auctioneer as Focus"
L["Keybinds"] = "Keybinds"
L["Set Keybind to Interact with Mouseover"] = "Set Keybind to Interact with Mouseover"
L["Set Keybind to Interact with Target"] = "Set Keybind to Interact with Target"
