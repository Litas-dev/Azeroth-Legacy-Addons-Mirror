local L = LibStub("AceLocale-3.0"):NewLocale("DalaranAH", "frFR")
if not L then
  return
end

L["Like Clockwork"] = "Comme une horloge"
L["Brassbolt Mechawrench"] = "Zéboulon Mécaclef"
L["Reginald Arcfire"] = "Reginald Arkenfeu"
L["Left-click to target"] = "Clic gauche pour cibler"
L["Press "] = "Appuyez sur "
L[" to interact with Target"] = " pour interagir avec la cible"
L[" or "] = " ou "
L[" to interact with Mouseover"] = " pour interagir avec le survol"
L["Bind 'Interact with Target' to interact with the Target"] = "Assignez « Interagir avec la cible » pour interagir"
L["Bind 'Interact with Mouseover' to interact with the Mouseover"] =
  "Assignez « Interagir avec le survol » pour interagir"
L["Reset"] = "Réinitialiser"
L["Reset to Defaults"] = "Réinitialiser par défaut"
L["Reset all settings to default?"] = "Réinitialiser tous les paramètres par défaut ?"
L["General"] = "Général"
L["Button Size"] = "Taille du bouton"
L["Additional Functions"] = "Fonctions supplémentaires"
L["Set Mark on the Auctioneer"] = "Marquer le commissaire-priseur"
L["On-Click sets Mark on the Auctioneer"] = "Un clic marque le commissaire-priseur"
L["Select the Mark"] = "Sélectionner la marque"
L["Set Auctioneer as Focus"] = "Définir le commissaire-priseur comme focus"
L["On-Click sets Auctioneer as Focus"] = "Un clic définit le commissaire-priseur comme focus"
L["Keybinds"] = "Raccourcis clavier"
L["Set Keybind to Interact with Mouseover"] = "Définir la touche pour interagir avec le survol"
L["Set Keybind to Interact with Target"] = "Définir la touche pour interagir avec la cible"
