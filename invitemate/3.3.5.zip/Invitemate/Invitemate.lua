
local f = CreateFrame("Frame")
f:RegisterEvent("CHAT_MSG_WHISPER")
f:SetScript("OnEvent", function()
	if arg1:lower() == "!invite" then
		DEFAULT_CHAT_FRAME:AddMessage("[Invitemate] Autoinviting " .. arg2);
		InviteUnit(arg2);
		return;
	end
end)
