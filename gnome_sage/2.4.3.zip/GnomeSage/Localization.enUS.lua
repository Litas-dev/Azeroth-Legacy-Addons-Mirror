﻿-- Author      : Svartalve
-- Create Date : 8/2/2008 2:04:29 AM

GnomeSageLocalization = {
	QUESTION = UnitName("player").." asks: \"",
	ERROR =  UnitName("player")..", please ask me a question by typing in the box below.",
	YES_1 = UnitName("player")..", according to my Mechaveritosphere, your plan will be a resounding success.",
	YES_2 = "If you go public on GobDAQ, I would buy 1,000 "..UnitName("player").." shares. You have nowhere to go but up!",
	YES_3 = "Leper Gnome Tests confirm that your decision will NOT result in Male-pattern Baldness, Explosive Discombobulation, or Gender-switching Anomalies.",
	YES_4 = "Accurate, precise, and exact measurement of my radioThaumaturgical Goblinoid Calipers point to an affirmative response.",
	YES_5 = "Careful analysis of your question's eigenstats, keyflavors, and uniqlues correspond to a 'Yes' answer.",
	MAYBE_1 = "Lupine aggressor data processed by Oviniform Calcumatrix indicates this is the right choice; however if these are Ovine observer values for the Folli-xtractor this is the wrong option.",
	MAYBE_2 = "I am having difficulty traversing the uncertainty matrix for your dilemma. Please supply the problem set at another chronological junction and attempt resolution again.",
	MAYBE_3 = "Gnomish Tinkerological Indeces are unable to predict success or failure based on your query, "..UnitName("player")..". Ask me again at a later interval to allow excitable variables to calm down.",
	MAYBE_4 = "My post-Gnomeregan Diaspora mecha-Brain expresses ambivalence regarding positive and negative responses. Both are equally likely to apply.",
	MAYBE_5 = "Even after Telegyro-consultation with my colleagues at Toshley's Station, I'm not sure whether or not everything will go as you planned, "..UnitName("player")..".",
	NO_1 = "Observation of Atroform Cloud Chamber indicates that you will fail if you pursue this course of action, "..UnitName("player")..".",
	NO_2 = UnitName("player")..", avoid Mohawked-Night Elves bearing gifts and scrap your current plans, my Air-cooled Certainty Probabilizing Upper-head senses disaster ahead.",
	NO_3 = "Chronatom analysis shows that your future self will receive a negative response to your question. In order to avoid conflict with the Infinite Dragonflight, I must concur.",
	NO_4 = "After utilizing the newly activated LHC (Leper gnome Hand Collator) machine in an undisclosed Gnomish Research Facility, I can confirm that the correct response is 'No'.",
	NO_5 = "After a first-approximation computation of your question, I conclude that you must not continue on this path.",
}