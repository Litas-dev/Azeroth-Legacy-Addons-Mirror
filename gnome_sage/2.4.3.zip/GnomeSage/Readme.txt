==============
Gnome Sage 1.0
==============

Author: Svartalve of Bronzebeard

A fun, little gadget that gives you your very own Pocket Gnome to help you make decisions as only a crafty, humorous companion can.

========
Commands
========

*Show "Gnome Sage" window
	/gnomesage
	
===============
Version History
===============

1.0 August 2, 2008
	First Release