-- Author      : Svartalve
-- Create Date : 4/7/2010 1:25:29 AM

	local name = UnitName("player")
GnomeSageLocalization = {
	QUESTION = name.." asks: \"",
	ERROR =  name..", please ask me a question by typing in the box below.",
	YES_1 = name..", as I percieve it, affirmatron.",
	YES_2 = "It is indubitable, "..name..".",
	YES_3 = "It is positively so.",
	YES_4 = "Most assumably.",
	YES_5 = "Forecast most agreeable.",
	YES_6 = name..", Veritometer indicates you are go.",
	YES_7 = "Incertitude at zero.",
	YES_8 = "Affirmatron.",
	YES_9 = "Affirmatron - indubitably.",
	YES_10 = "You may depend on it.",
	MAYBE_1 = "Feedback uncertain. Retry.",
	MAYBE_2 = "Inquire again postliminary.",
	MAYBE_3 = "Preferable to delay answer, "..name..".",
	MAYBE_4 = "Unable to forecast at this time.",
	MAYBE_5 = "Focus and inquire again, "..name..".",
	NO_1 = "Don't wager on it, "..name..".",
	NO_2 = name..", my findings indicate negatory.",
	NO_3 = "Telemetry advise negatron.",
	NO_4 = "Forecast least desirable",
	NO_5 = "Most dubitable.",
}