===============
Gnome Sage 1.13
===============

Author: Svartalve of Bronzebeard

A fun, little addon that gives you your very own Pocket Gnome to help you make decisions as only a crafty, humorous companion can.

Note:

For the adventurous types, you can customize Gnome Sages YES/MAYBE/NO responses easily by editing Localization.enUS.lua in your preferred text editor.
========
Commands
========

*Show "Gnome Sage" window
/gnomesage

===============
Version History
===============

1.13 July 22, 2010
Improved localization implemented (hat tip to Seerah!)

1.12 June 30, 2010
Minor graphics update

1.11 April 7, 2010
Minor updates to Localization.enUS.lua, GnomeSage.toc, & Readme.txt

1.1 January 24, 2010
Increased possible answers to 20
Previous answers made more concise

1.0 August 2, 2008
First Release