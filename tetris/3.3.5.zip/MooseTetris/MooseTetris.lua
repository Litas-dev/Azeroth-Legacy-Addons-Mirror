--[[ NOTES

to do:
		score keeping and history, possibly share high score with guild
		score screen
			level select
		game menu
		possibly music
		sounds
		TETRIS animation
		make clearer based on time and not graphic
		when game not in progress or paused, use normal keybinds

]]
--[[ CHANGE LOG 		version =		(patch.patch).revision#


	V 5.1.3
	1/19/2013
		Minor UI tweaks
		Added a fading animation to line clearing
		Fixed Options and Pause button text mix-up
	1/13/2013
		Code changes to prepare for line clear animation
	10/31/2012
		Started guild score tracking
	
	V 5.0.2
	10/28/2012
		Added options UI
		Added keybinding capability
		Added close button
	10/19/2012
		Code clean-up.
		Added support for debug messages through MOOSETETRIS_OPTIONS.isDebugging and Moose_DebugMsg() in library.
		NYF - Added command '/tetris level X' where X is 0-9
	
		
	V 5.0.1
	10/15/2012
		Updated .toc for MoP.  Everything still works.

]]

--**************************************************
-- addon globals

local gsub, strfind, strlower, tonumber, tostring, random, floor, ceil, strsub, sqrt, abs = gsub, strfind, strlower, tonumber, tostring, random, floor, ceil, strsub, sqrt, abs
local CURRENT_VERS = 513
--reset options/scores if saved var vers is below these numbers
local LAST_VERS_TO_RESET_OPTIONS = 0
local LAST_VERS_TO_RESET_SCORES = 513
local addonTag = "\124cffffcc00[Tetris]:\124r"
local ONUPDATE_SPEED = 1
local PLAYER = UnitName("player")
local pieceTypes = {"O","I","S","Z","L","J","T"}
local HORIZONTAL_SPEED = 1/6		--onupdate speed for piece drifting script
local TetrominoQueue = {}		--string table
local MAX_LEVEL = 9
local scores_per_lines_cleared = {
	[1] = 40,
	[2] = 100,
	[3] = 300,
	[4] = 1200,
}
local MOOSETETRIS_OPTIONS_DEFAULTS = {
	["isDebugging"] = false,
	["keybinds"] = {
		["close"] = "ENTER",
		["left"] = "LEFT",
		["right"] = "RIGHT",
		["down"] = "DOWN",
		["rotateClock"] = "X",
		["rotateCounter"] = "Z",},
}
local Gameboard = {
	["CELLS"] = {},
	["entryCell"] = 14,
	["cellSize"] = 20,		--length of a single cell
	["cellsPerRow"] = 10,
	["level"] = 0,
	["linesCleared"] = 0,
	["linesUntilNextLevel"] = 10,
	["score"] = 0,
	["cursor"] = 0,
	["activePieces"] = {},	--table of frame objects that make up the tetromino currently being controlled
	["activePiecePositions"] = {},	--table holding the current piece's blocks' cell numbers	--!DEP
	["activePieceStatus"] = "",
	["blocks"] = {},			--table of frame objects (blocks) which have been placed
	["recyclables"] = {},	--table of frame objects (blocks) which are no longer visible on the gameboard, and can be recycled for new tetrominos
	["previewBlocks"] = {},
	["isGameOver"] = true,
	["isPaused"] = false,
	["isClearingLines"] = false,
}
local blockTex = {
	[0] = {
		["T"] = "Interface\\AddOns\\MooseTetris\\blocktex\\tetristxtr_blue_0",
		["J"] = "Interface\\AddOns\\MooseTetris\\blocktex\\tetristxtr_blue_1",
		["Z"] = "Interface\\AddOns\\MooseTetris\\blocktex\\tetristxtr_lightblue_1",
		["O"] = "Interface\\AddOns\\MooseTetris\\blocktex\\tetristxtr_blue_0",
		["S"] = "Interface\\AddOns\\MooseTetris\\blocktex\\tetristxtr_blue_1",
		["L"] = "Interface\\AddOns\\MooseTetris\\blocktex\\tetristxtr_lightblue_1",
		["I"] = "Interface\\AddOns\\MooseTetris\\blocktex\\tetristxtr_blue_0",
	},
	[1] = {
		["T"] = "Interface\\AddOns\\MooseTetris\\blocktex\\tetristxtr_darkgreen_0",
		["J"] = "Interface\\AddOns\\MooseTetris\\blocktex\\tetristxtr_darkgreen_1",
		["Z"] = "Interface\\AddOns\\MooseTetris\\blocktex\\tetristxtr_lime_1",
		["O"] = "Interface\\AddOns\\MooseTetris\\blocktex\\tetristxtr_darkgreen_0",
		["S"] = "Interface\\AddOns\\MooseTetris\\blocktex\\tetristxtr_darkgreen_1",
		["L"] = "Interface\\AddOns\\MooseTetris\\blocktex\\tetristxtr_lime_1",
		["I"] = "Interface\\AddOns\\MooseTetris\\blocktex\\tetristxtr_darkgreen_0",
	},
	[2] = {
		["T"] = "Interface\\AddOns\\MooseTetris\\blocktex\\tetristxtr_magenta_0",
		["J"] = "Interface\\AddOns\\MooseTetris\\blocktex\\tetristxtr_magenta_1",
		["Z"] = "Interface\\AddOns\\MooseTetris\\blocktex\\tetristxtr_pink_1",
		["O"] = "Interface\\AddOns\\MooseTetris\\blocktex\\tetristxtr_magenta_0",
		["S"] = "Interface\\AddOns\\MooseTetris\\blocktex\\tetristxtr_magenta_1",
		["L"] = "Interface\\AddOns\\MooseTetris\\blocktex\\tetristxtr_pink_1",
		["I"] = "Interface\\AddOns\\MooseTetris\\blocktex\\tetristxtr_magenta_0",
	},
	[3] = {
		["T"] = "Interface\\AddOns\\MooseTetris\\blocktex\\tetristxtr_blue_0",
		["J"] = "Interface\\AddOns\\MooseTetris\\blocktex\\tetristxtr_blue_1",
		["Z"] = "Interface\\AddOns\\MooseTetris\\blocktex\\tetristxtr_green_1",
		["O"] = "Interface\\AddOns\\MooseTetris\\blocktex\\tetristxtr_blue_0",
		["S"] = "Interface\\AddOns\\MooseTetris\\blocktex\\tetristxtr_blue_1",
		["L"] = "Interface\\AddOns\\MooseTetris\\blocktex\\tetristxtr_green_1",
		["I"] = "Interface\\AddOns\\MooseTetris\\blocktex\\tetristxtr_blue_0",
	},
	[4] = {
		["T"] = "Interface\\AddOns\\MooseTetris\\blocktex\\tetristxtr_red_0",
		["J"] = "Interface\\AddOns\\MooseTetris\\blocktex\\tetristxtr_red_1",
		["Z"] = "Interface\\AddOns\\MooseTetris\\blocktex\\tetristxtr_lightgreen_1",
		["O"] = "Interface\\AddOns\\MooseTetris\\blocktex\\tetristxtr_red_0",
		["S"] = "Interface\\AddOns\\MooseTetris\\blocktex\\tetristxtr_red_1",
		["L"] = "Interface\\AddOns\\MooseTetris\\blocktex\\tetristxtr_lightgreen_1",
		["I"] = "Interface\\AddOns\\MooseTetris\\blocktex\\tetristxtr_red_0",
	},
	[5] = {
		["T"] = "Interface\\AddOns\\MooseTetris\\blocktex\\tetristxtr_lightgreen_0",
		["J"] = "Interface\\AddOns\\MooseTetris\\blocktex\\tetristxtr_lightgreen_1",
		["Z"] = "Interface\\AddOns\\MooseTetris\\blocktex\\tetristxtr_dullblue_1",
		["O"] = "Interface\\AddOns\\MooseTetris\\blocktex\\tetristxtr_lightgreen_0",
		["S"] = "Interface\\AddOns\\MooseTetris\\blocktex\\tetristxtr_lightgreen_1",
		["L"] = "Interface\\AddOns\\MooseTetris\\blocktex\\tetristxtr_dullblue_1",
		["I"] = "Interface\\AddOns\\MooseTetris\\blocktex\\tetristxtr_lightgreen_0",
	},
	[6] = {
		["T"] = "Interface\\AddOns\\MooseTetris\\blocktex\\tetristxtr_redorange_0",
		["J"] = "Interface\\AddOns\\MooseTetris\\blocktex\\tetristxtr_redorange_1",
		["Z"] = "Interface\\AddOns\\MooseTetris\\blocktex\\tetristxtr_grey_1",
		["O"] = "Interface\\AddOns\\MooseTetris\\blocktex\\tetristxtr_redorange_0",
		["S"] = "Interface\\AddOns\\MooseTetris\\blocktex\\tetristxtr_redorange_1",
		["L"] = "Interface\\AddOns\\MooseTetris\\blocktex\\tetristxtr_grey_1",
		["I"] = "Interface\\AddOns\\MooseTetris\\blocktex\\tetristxtr_redorange_0",
	},
	[7] = {
		["T"] = "Interface\\AddOns\\MooseTetris\\blocktex\\tetristxtr_indigo_0",
		["J"] = "Interface\\AddOns\\MooseTetris\\blocktex\\tetristxtr_indigo_1",
		["Z"] = "Interface\\AddOns\\MooseTetris\\blocktex\\tetristxtr_darkred_1",
		["O"] = "Interface\\AddOns\\MooseTetris\\blocktex\\tetristxtr_indigo_0",
		["S"] = "Interface\\AddOns\\MooseTetris\\blocktex\\tetristxtr_indigo_1",
		["L"] = "Interface\\AddOns\\MooseTetris\\blocktex\\tetristxtr_darkred_1",
		["I"] = "Interface\\AddOns\\MooseTetris\\blocktex\\tetristxtr_indigo_0",
	},
	[8] = {
		["T"] = "Interface\\AddOns\\MooseTetris\\blocktex\\tetristxtr_blue_0",
		["J"] = "Interface\\AddOns\\MooseTetris\\blocktex\\tetristxtr_blue_1",
		["Z"] = "Interface\\AddOns\\MooseTetris\\blocktex\\tetristxtr_redorange_1",
		["O"] = "Interface\\AddOns\\MooseTetris\\blocktex\\tetristxtr_blue_0",
		["S"] = "Interface\\AddOns\\MooseTetris\\blocktex\\tetristxtr_blue_1",
		["L"] = "Interface\\AddOns\\MooseTetris\\blocktex\\tetristxtr_redorange_1",
		["I"] = "Interface\\AddOns\\MooseTetris\\blocktex\\tetristxtr_blue_0",
	},
	[9] = {
		["T"] = "Interface\\AddOns\\MooseTetris\\blocktex\\tetristxtr_redorange_0",
		["J"] = "Interface\\AddOns\\MooseTetris\\blocktex\\tetristxtr_redorange_1",
		["Z"] = "Interface\\AddOns\\MooseTetris\\blocktex\\tetristxtr_orange_1",
		["O"] = "Interface\\AddOns\\MooseTetris\\blocktex\\tetristxtr_redorange_0",
		["S"] = "Interface\\AddOns\\MooseTetris\\blocktex\\tetristxtr_redorange_1",
		["L"] = "Interface\\AddOns\\MooseTetris\\blocktex\\tetristxtr_orange_1",
		["I"] = "Interface\\AddOns\\MooseTetris\\blocktex\\tetristxtr_redorange_0",
	},


}
local Tetrominoes = {	--tetrominoes and their positions relative to the pivotal piece in order that they rotate counter-clockwise
	["O"] = {
		[1] = {-1,0,(Gameboard.cellsPerRow - 1),Gameboard.cellsPerRow},
	},
	["I"] = {
		[1] = {0,-1,-2,1},		--horizontal
		[2] = {0,-Gameboard.cellsPerRow,Gameboard.cellsPerRow,(Gameboard.cellsPerRow * 2)},		--vertical
	},
	["S"] = {
		[1] = {0,1,(Gameboard.cellsPerRow - 1),Gameboard.cellsPerRow},
		[2] = {0,-Gameboard.cellsPerRow,1,(Gameboard.cellsPerRow + 1)},
	},
	["Z"] = {
		[1] = {0,-1,Gameboard.cellsPerRow,(Gameboard.cellsPerRow + 1)},
		[2] = {0,1,Gameboard.cellsPerRow,-(Gameboard.cellsPerRow - 1)},
	},
	["L"] = {
		[1] = {-1,0,1,(Gameboard.cellsPerRow - 1)},
		[2] = {-Gameboard.cellsPerRow,0,Gameboard.cellsPerRow,(Gameboard.cellsPerRow + 1)},
		[3] = {-1,0,1,-(Gameboard.cellsPerRow - 1)},
		[4] = {-(Gameboard.cellsPerRow + 1),-Gameboard.cellsPerRow,0,Gameboard.cellsPerRow},
	},
	["J"] = {
		[1] = {-1,0,1,(Gameboard.cellsPerRow + 1)},
		[2] = {-Gameboard.cellsPerRow,-(Gameboard.cellsPerRow - 1),0,Gameboard.cellsPerRow},
		[3] = {-(Gameboard.cellsPerRow + 1),-1,0,1},
		[4] = {-Gameboard.cellsPerRow,0,(Gameboard.cellsPerRow - 1),Gameboard.cellsPerRow},
	},
	["T"] = {
		[1] = {-1,0,1,Gameboard.cellsPerRow},
		[2] = {-Gameboard.cellsPerRow,0,1,Gameboard.cellsPerRow},
		[3] = {-Gameboard.cellsPerRow,-1,0,1},
		[4] = {-Gameboard.cellsPerRow,-1,0,Gameboard.cellsPerRow},
	},
}
local Tetris_SlashCmds = {		--must be placed after globals
	[0] = function()		--vanilla command
		if TetrisGameBoard:IsVisible() then
			TetrisGameBoard:Hide()
		else
			TetrisGameBoard:Show()
		end
	end,
	[1] = function(msg)	-- unrecognized command
		print(addonTag,"Command \""..msg.."\" not recognized.")
	end,
	["debug"] = function(msg)
		if not msg then msg = "" end
		if msg == "on" then
			MOOSETETRIS_OPTIONS.isDebugging = true
			print(addonTag,"\124cff00ff00Debugging messages enabled.")
		elseif msg == "off" then
			MOOSETETRIS_OPTIONS.isDebugging  = false
			print(addonTag,"\124cffff0000Debugging messages Disabled.")
		else
			MOOSETETRIS_OPTIONS.isDebugging  = not MOOSETETRIS_OPTIONS.isDebugging 
			if MOOSETETRIS_OPTIONS.isDebugging  then print(addonTag,"\124cffff0000Debugging messages disabled.") else print(addonTag,"\124cff00ff00Debugging messages enabled.") end
		end
	end,
	["level"] = function(msg)	--  EVENTUALLY REPLACED BY TXT WIDGET NEXT TO START GAME BUTTON
		if not msg then
			print(addonTag,"NOPE. You need to specify the level when using \124aaaaaa\"/tetris level \124cffff0000X\124r\", where \124cffff0000X\124r is 0 through 9.")
			return
		end
		for x = 0,MAX_LEVEL do
			if msg == tostring(x) then
				if Gameboard.isGameOver then
					ChangeLevel(tonumber(msg))		--DOES NOT WORK.  :NEWGAME() IS CALLED, CHANGES LEVEL BACK THROUGH  :CLEARBOARD()
					print(addonTag,"Level changed to "..msg..".")
				else
					print(addonTag,"Cannot change level with a game in progress.")
				end
				return
			end
		end
		print(addonTag,"NOPE. You need to specify the level when using \124aaaaaa\"/tetris level \124cffff0000X\124r\", where \124cffff0000X\124r is 0 through 9.")
		return
	end,
}
--NYI Tetris_KeyFunctions
local Tetris_KeyFunctions = {		--must be placed after globals
	
	["close"] = function(self,key)
		print(addonTag,"Pausing game.")
		self:Hide()
	end,
	["left"] = function(self,key)
		--if the active piece is not already against the left side, move it over to the left a cell
		if #Gameboard.activePieces == 0 then return end
		spinner.TimeSinceLastUpdate = 1/8
		spinner.dir = "left"
		spinner:Show()
	end,
	["right"] = function(self,key)
		if #Gameboard.activePieces == 0 then return end
		spinner.TimeSinceLastUpdate = 1/8
		spinner.dir = "right"
		spinner:Show()
	end,
	["down"] = function(self,key)
		ONUPDATE_SPEED = (MAX_LEVEL + 1 - 9)/(MAX_LEVEL+1)
		if self.TimeSinceLastUpdate > ONUPDATE_SPEED then self.TimeSinceLastUpdate = ONUPDATE_SPEED end
	end,
	["rotateClock"] = function(self,key)		--X
		if Gameboard.activePieceStatus == "dead" then return end
		local blockType,rotation,newRotationSet = Gameboard.activePieces[1].blockType, Gameboard.activePieces[1].rotation, Gameboard.activePieces[1].rotation - 1
		if newRotationSet <= 0 then newRotationSet = #Tetrominoes[blockType] end
		local tempCursor = Gameboard.cursor
		local canRotate = false
		for a=0,2 do
			if Gameboard.cursor % 10 <= 4 then tempCursor = Gameboard.cursor + a else tempCursor = Gameboard.cursor - a end				
			for b=1,4 do
				if abs(((tempCursor + Tetrominoes[blockType][rotation][b]) % 10) - ((tempCursor + Tetrominoes[blockType][newRotationSet][b]) % 10)) > 5 then
					--can't rotate here, try to shift
					break
				end
				if b == 4 then	--rotating piece will not go through an edge
					for c=1,4 do
						--check if there's a block in any of the spaces we're trying to rotate	
						if IsBlockInCell(tempCursor+ Tetrominoes[blockType][newRotationSet][c]) == true then break end
						if c==4 then canRotate = true end		--all the checks went through. flag as ready to rotate
					end
					if canRotate == true then ShiftPiece(tempCursor - Gameboard.cursor);RotatePiece(-1) return end
				end
			end
		end
	end,
	["rotateCounter"] = function(self,key)	--Z
		--check if 90 deg rotation is legal
		if Gameboard.activePieceStatus == "dead" then return end
		local blockType,rotation,newRotationSet = Gameboard.activePieces[1].blockType, Gameboard.activePieces[1].rotation, Gameboard.activePieces[1].rotation + 1
		if newRotationSet > #Tetrominoes[blockType] then newRotationSet = 1 end

		local tempCursor = Gameboard.cursor
		local canRotate = false
		for a=0,2 do
			if Gameboard.cursor % 10 <= 4 then tempCursor = Gameboard.cursor + a else tempCursor = Gameboard.cursor - a end				
			for b=1,4 do
				if abs(((tempCursor + Tetrominoes[blockType][rotation][b]) % 10) - ((tempCursor + Tetrominoes[blockType][newRotationSet][b]) % 10)) > 5 then
					--can't rotate here, try to shift
					break
				end
				if b == 4 then	--rotating piece will not go through an edge
					for c=1,4 do
						--check if there's a block in any of the spaces we're trying to rotate
						if IsBlockInCell(tempCursor + Tetrominoes[blockType][newRotationSet][c]) == true then break end
						if c==4 then canRotate = true end		--all the checks went through. flag as ready to rotate
					end
					if canRotate == true then ShiftPiece(tempCursor - Gameboard.cursor);RotatePiece(1) return end
				end
			end
		end
	end,
}
function TetrisGameBoardStatus()
	if Gameboard.isGameOver then return "gameover" end
	if Gameboard.isPaused then return "paused" end
	return "in progress"
end

--================================================

function Tetris_ResetKeybinds()
	print(addonTag,"Reset keybinds to default.")
	if not MOOSETETRIS_OPTIONS then MOOSETETRIS_OPTIONS = MOOSETETRIS_OPTIONS_DEFAULTS end
	if not MOOSETETRIS_OPTIONS.keybinds then MOOSETETRIS_OPTIONS.keybinds = MOOSETETRIS_OPTIONS_DEFAULTS.keybinds end
	for k,v in pairs(MOOSETETRIS_OPTIONS_DEFAULTS.keybinds) do
		MOOSETETRIS_OPTIONS.keybinds[k] = v
	end
	Tetris_CloseAllKeybindButtons()
end

function Tetris_CloseAllKeybindButtons()
	MooseTetrisOptionsFrame_KeybindsFrame_CloseGameWindowFrame_KeybindButton:SetScript("OnKeyDown",nil)
	MooseTetrisOptionsFrame_KeybindsFrame_CloseGameWindowFrame_KeybindButton:SetText(MOOSETETRIS_OPTIONS.keybinds.close)
	MooseTetrisOptionsFrame_KeybindsFrame_LeftBindFrame_KeybindButton:SetScript("OnKeyDown",nil)
	MooseTetrisOptionsFrame_KeybindsFrame_LeftBindFrame_KeybindButton:SetText(MOOSETETRIS_OPTIONS.keybinds.left)
	MooseTetrisOptionsFrame_KeybindsFrame_RightBindFrame_KeybindButton:SetScript("OnKeyDown",nil)
	MooseTetrisOptionsFrame_KeybindsFrame_RightBindFrame_KeybindButton:SetText(MOOSETETRIS_OPTIONS.keybinds.right)
	MooseTetrisOptionsFrame_KeybindsFrame_DownBindFrame_KeybindButton:SetScript("OnKeyDown",nil)
	MooseTetrisOptionsFrame_KeybindsFrame_DownBindFrame_KeybindButton:SetText(MOOSETETRIS_OPTIONS.keybinds.down)
	MooseTetrisOptionsFrame_KeybindsFrame_RotateCounterBindFrame_KeybindButton:SetScript("OnKeyDown",nil)
	MooseTetrisOptionsFrame_KeybindsFrame_RotateCounterBindFrame_KeybindButton:SetText(MOOSETETRIS_OPTIONS.keybinds.rotateCounter)
	MooseTetrisOptionsFrame_KeybindsFrame_RotateClockBindFrame_KeybindButton:SetScript("OnKeyDown",nil)
	MooseTetrisOptionsFrame_KeybindsFrame_RotateClockBindFrame_KeybindButton:SetText(MOOSETETRIS_OPTIONS.keybinds.rotateClock)
	MooseTetrisOptionsFrame_KeybindsFrame_SetDefaultBindFrame_KeybindButton:SetScript("OnKeyDown",nil)
	MooseTetrisOptionsFrame_KeybindsFrame_SetDefaultBindFrame_KeybindButton:SetText("Reset to Defaults")
end

TetrisGameBoard:RegisterEvent("ADDON_LOADED")
TetrisGameBoard:SetScript("OnEvent", function(self,event,...)
	if event == "ADDON_LOADED" then
		self:UnregisterEvent("ADDON_LOADED")
		SLASH_TETRIS1 = '/tetris'
		
		--initialize saved vars
		if not MOOSETETRIS_OPTIONS then MOOSETETRIS_OPTIONS = MOOSETETRIS_OPTIONS_DEFAULTS end
		for k,v in pairs(MOOSETETRIS_OPTIONS_DEFAULTS) do
			if not MOOSETETRIS_OPTIONS[k] then MOOSETETRIS_OPTIONS[k] = v end
		end
		if not MOOSETETRIS_SCORES then MOOSETETRIS_SCORES = {} end
		if not MOOSETETRIS_SCORES.player then MOOSETETRIS_SCORES.player = {} end
		if not MOOSETETRIS_SCORES.guild then MOOSETETRIS_SCORES.guild = {} end
		
		--version check
		if not MOOSETETRIS_VERS then MOOSETETRIS_VERS = CURRENT_VERS end		--first time loading
		--if version doesn't match, we may need to clear options and scores if changes to the table layout were made
		if MOOSETETRIS_VERS ~= CURRENT_VERS then
		--WOULD LIKE TO KEEP AS MUCH INFO AS POSSIBLE
		--WOULD LIKE TO KEEP AS MUCH INFO AS POSSIBLE
		--WOULD LIKE TO KEEP AS MUCH INFO AS POSSIBLE
		--WOULD LIKE TO KEEP AS MUCH INFO AS POSSIBLE
			if MOOSETETRIS_VERS < LAST_VERS_TO_RESET_OPTIONS then
				MOOSETETRIS_OPTIONS = MOOSETETRIS_OPTIONS_DEFAULTS
				print(addonTag,"\124cffff0000New version required options and keybindings reset to defaults.\124r")
			end
			if MOOSETETRIS_VERS < LAST_VERS_TO_RESET_SCORES then
				MOOSETETRIS_SCORES = {}
				MOOSETETRIS_SCORES.player = {}
				MOOSETETRIS_SCORES.guild = {}
				print(addonTag,"\124cffff0000New version required scores to be reset.\124r")
			end
			
			MOOSETETRIS_VERS = CURRENT_VERS
		end
		
		--RegisterAddonMessagePrefix("$tet")
		--self:RegisterEvent("CHAT_MSG_ADDON")
		
		self:SetUp()
		--self:SetScript("OnEvent", MooseTetris_ProcessAddonMsg)
		return
	end
end)

function MooseTetris_ProcessAddonMsg(self, event, ...)
	if event ~= "CHAT_MSG_ADDON" then return end
	local prefix, msg, _, sender = select(1, ...)
	if prefix ~= "$tet" then return end
	
	print(sender,msg)
	
	local msgType = strsub(msg,1,1)
	if msgType == "*" then		-- someone sent us a score
		local score = tonumber(strsub(msg,2,strlen(msg)))
		if #MOOSETETRIS_SCORES.guild < 5 then
			local senderClass
			local total,online = GetNumGuildMembers()
			for x=1,total do
				local n, r, ri, level, L_class, _, _, _, o, _, class, _, _, _, _, _ = GetGuildRosterInfo(x)
				if n == sender then senderClass = class break end
			end
			tinsert(MOOSETETRIS_SCORES.guild,{["name"]=sender,["class"]=senderClass,["date"]=tostring(date()),["score"]=score,})	--FIX DATE
			print(addonTag,GetClassColor(senderClass)..sender.."\124r has achieved a guild high score of \124cffffcc00"..tostring(score).."\124r.")
			return
		else
		
			table.sort(MOOSETETRIS_SCORES.guild, function(a,b) return a<b end)
			for x=1,#MOOSETETRIS_SCORES.guild do
			
				if score > MOOSETETRIS_SCORES.guild[x].score then
					local senderClass
					local total,online = GetNumGuildMembers()
					for x=1,total do
						local n, r, ri, level, L_class, _, _, _, o, _, class, _, _, _, _, _ = GetGuildRosterInfo(x)
						if n == sender then senderClass = class break end
					end
					MOOSETETRIS_SCORES.guild[x].name = sender
					MOOSETETRIS_SCORES.guild[x].class = senderClass
					MOOSETETRIS_SCORES.guild[x]["date"] = tostring(date())
					MOOSETETRIS_SCORES.guild[x].score = score
					print(addonTag,GetClassColor(senderClass)..sender.."\124r has beaten a guild high score with \124cffffcc00"..tostring(score).."\124r.")
					return
				end
			end
		end
		return
	end
	
	if msgType == "@" then		--recieved a query for guild scores
		
		--respond by sending 
		
	end
	
end

function MooseTetris_GetScores()
	--send addon msg to guild asking for scores from other peoples tetris addons
end

-- used for shading blocks after game over, but is versatile
local timer = CreateFrame("frame",nil,TetrisGameBoard)
timer:Hide()
timer.TimeSinceLastUpdate, timer.interval, timer.doFunction = 0, 10, nil
timer:SetScript("OnUpdate",function(self,elapsed)
	self.TimeSinceLastUpdate = self.TimeSinceLastUpdate + elapsed
	if self.TimeSinceLastUpdate >= self.interval then
		if self.doFunction() then end
		self.TimeSinceLastUpdate = self.TimeSinceLastUpdate - self.interval
	end
end)

--onUpdate script required to continue shifting the active piece over when right or left is held
local spinner = CreateFrame("frame",nil,TetrisGameBoard)
spinner:Hide()
spinner.TimeSinceLastUpdate, spinner.dir = 0, "right"
spinner:SetScript("OnUpdate",function(self,elapsed)
	self.TimeSinceLastUpdate = self.TimeSinceLastUpdate + elapsed
	while self.TimeSinceLastUpdate >= HORIZONTAL_SPEED do
		if spinner.dir == "left" then
			if IsBlockUnderPiece(-1) == false and IsPieceLeftmost() == false then ShiftPiece(-1) end
		elseif spinner.dir == "right" then
			if IsBlockUnderPiece(1) == false and IsPieceRightmost() == false then ShiftPiece(1) end
		end
		self.TimeSinceLastUpdate = self.TimeSinceLastUpdate - HORIZONTAL_SPEED
	end
end)

function SlashCmdList.TETRIS(msg)	--slash command handler
	local orig_msg = msg		--preserve the original message for Tetris_SlashCmds[1]
	msg = strlower(strtrim(msg))
	if msg == "" then msg = 0 end
	
	local command,_,value = nil,nil,nil
	if not strfind(msg," ") then
		command = msg
	else
		command,_,value = string.match(msg,"(%w+)(%s+)(.*)")
	end
	
	if Tetris_SlashCmds[command] ~= nil then
		pcall(Tetris_SlashCmds[command],value)
	else
		pcall(Tetris_SlashCmds[1],orig_msg)
	end
end

function TetrisGameBoard:SetUp()

	self.isKeybindingMode = false
	Gameboard.entryCell = Gameboard.cellsPerRow + (floor(Gameboard.cellsPerRow / 2) - 1)	--middle of second row
	
	--set up widgets
	self:SetWidth(Gameboard.cellsPerRow * Gameboard.cellSize)
	self:SetHeight(20 * Gameboard.cellSize)		--the gameboard will always be 20 cells high
	
	TetrisGameBoard_Border:Lower()
	TetrisGameBoard_Border:SetWidth(Gameboard.cellsPerRow * Gameboard.cellSize + 6)
	TetrisGameBoard_Border:SetHeight(20 * Gameboard.cellSize + 6)
	
	TetrisGameBoard_RightSideBar:SetWidth(5 * Gameboard.cellSize)
	TetrisGameBoard_RightSideBar:SetHeight(20 * Gameboard.cellSize)
		TetrisGameBoard_RightSideBar_linesTextFrame:SetWidth(5 * Gameboard.cellSize)
		TetrisGameBoard_RightSideBar_linesTextFrame:SetHeight(32)
		TetrisGameBoard_RightSideBar_scoreTextFrame:SetWidth(5 * Gameboard.cellSize)
		TetrisGameBoard_RightSideBar_scoreTextFrame:SetHeight(32)
		TetrisGameBoard_RightSideBar_levelTextFrame:SetWidth(5 * Gameboard.cellSize)
		TetrisGameBoard_RightSideBar_levelTextFrame:SetHeight(32)
		TetrisGameBoard_RightSideBar_nextPieceFrame:SetWidth(4/5 * Gameboard.cellSize * 6)
		TetrisGameBoard_RightSideBar_nextPieceFrame:SetHeight(4/5 * Gameboard.cellSize * 6)
		TetrisGameBoard_RightSideBar_nextPieceFrame_Border:Lower()
		TetrisGameBoard_RightSideBar_nextPieceFrame_Border:SetWidth(4/5 * Gameboard.cellSize * 6 + 6)
		TetrisGameBoard_RightSideBar_nextPieceFrame_Border:SetHeight(4/5 * Gameboard.cellSize * 6 + 6)

	for previewBlock = 1,4 do
		local previewFrame = CreateFrame("Frame","TetrisPreviewBlock_"..tostring(previewBlock),TetrisGameBoard_RightSideBar_nextPieceFrame,"TetrisCellTemplate")
		previewFrame.texture = _G[previewFrame:GetName().."_BGTexture"]
		previewFrame:SetWidth(4/5 * Gameboard.cellSize)
		previewFrame:SetHeight(4/5 * Gameboard.cellSize)
		tinsert(Gameboard.previewBlocks, previewFrame)
	end

	--onupdate script (timer for gameloop)
	self.TimeSinceLastUpdate = 0
	--self:SetScript("OnUpdate",TetrisGameBoard_OnUpdate)
	
	--keyboard handles
	self:SetScript("OnKeyDown", function(self, key)
		--print(key)
		if self.isKeybindingMode then return end
		if TetrisGameBoardStatus() ~= "in progress" or Gameboard.isClearingLines == true then return end
		
		if key == MOOSETETRIS_OPTIONS.keybinds.close then
			self:Pause(true,true,true)
			self:Hide()
			return
		end
		if key == MOOSETETRIS_OPTIONS.keybinds.left then	--start shifting left
			--if the active piece is not already against the left side, move it over to the left a cell
			if #Gameboard.activePieces == 0 then return end
			spinner.TimeSinceLastUpdate = 1/8
			spinner.dir = "left"
			spinner:Show()
		end
		if key == MOOSETETRIS_OPTIONS.keybinds.right then	--shift right
			if #Gameboard.activePieces == 0 then return end
			spinner.TimeSinceLastUpdate = 1/8
			spinner.dir = "right"
			spinner:Show()
		end
		if key == MOOSETETRIS_OPTIONS.keybinds.down then	--shift down
			if #Gameboard.activePieces == 0 then return end
			ONUPDATE_SPEED = (MAX_LEVEL + 1 - 9)/(MAX_LEVEL+1)
			if self.TimeSinceLastUpdate > ONUPDATE_SPEED then self.TimeSinceLastUpdate = ONUPDATE_SPEED end
		end
		if key == MOOSETETRIS_OPTIONS.keybinds.rotateCounter then	--rotate 90 deg
			--check if 90 deg rotation is legal
			if #Gameboard.activePieces == 0 then return end
			if Gameboard.activePieceStatus == "dead" then return end
			local blockType,rotation,newRotationSet = Gameboard.activePieces[1].blockType, Gameboard.activePieces[1].rotation, Gameboard.activePieces[1].rotation + 1
			if newRotationSet > #Tetrominoes[blockType] then newRotationSet = 1 end

			local tempCursor = Gameboard.cursor
			local canRotate = false
			for a=0,2 do
				if Gameboard.cursor % Gameboard.cellsPerRow <= 4 then tempCursor = Gameboard.cursor + a else tempCursor = Gameboard.cursor - a end				
				for b=1,4 do
					if abs(((tempCursor + Tetrominoes[blockType][rotation][b]) % Gameboard.cellsPerRow) - ((tempCursor + Tetrominoes[blockType][newRotationSet][b]) % Gameboard.cellsPerRow)) > 5 then
						--can't rotate here, try to shift
						break
					end
					if b == 4 then	--rotating piece will not go through an edge
						for c=1,4 do
							--check if there's a block in any of the spaces we're trying to rotate
							if IsBlockInCell(tempCursor + Tetrominoes[blockType][newRotationSet][c]) == true then break end
							if c==4 then canRotate = true end		--all the checks went through. flag as ready to rotate
						end
						if canRotate == true then ShiftPiece(tempCursor - Gameboard.cursor);RotatePiece(1) return end
					end
				end
			end

		end
		if key == MOOSETETRIS_OPTIONS.keybinds.rotateClock then	--rotate -90 deg
			if #Gameboard.activePieces == 0 then return end
			if Gameboard.activePieceStatus == "dead" then return end
			local blockType,rotation,newRotationSet = Gameboard.activePieces[1].blockType, Gameboard.activePieces[1].rotation, Gameboard.activePieces[1].rotation - 1
			if newRotationSet <= 0 then newRotationSet = #Tetrominoes[blockType] end
			local tempCursor = Gameboard.cursor
			local canRotate = false
			for a=0,2 do
				if Gameboard.cursor % Gameboard.cellsPerRow <= 4 then tempCursor = Gameboard.cursor + a else tempCursor = Gameboard.cursor - a end				
				for b=1,4 do
					if abs(((tempCursor + Tetrominoes[blockType][rotation][b]) % Gameboard.cellsPerRow) - ((tempCursor + Tetrominoes[blockType][newRotationSet][b]) % Gameboard.cellsPerRow)) > 5 then
						--can't rotate here, try to shift
						break
					end
					if b == 4 then	--rotating piece will not go through an edge
						for c=1,4 do
							--check if there's a block in any of the spaces we're trying to rotate	
							if IsBlockInCell(tempCursor+ Tetrominoes[blockType][newRotationSet][c]) == true then break end
							if c==4 then canRotate = true end		--all the checks went through. flag as ready to rotate
						end
						if canRotate == true then ShiftPiece(tempCursor - Gameboard.cursor);RotatePiece(-1) return end
					end
				end
			end
		end
	end)
	self:SetScript("OnKeyUp", function(self, key)
		if key == MOOSETETRIS_OPTIONS.keybinds.down then ONUPDATE_SPEED = (MAX_LEVEL + 1 - Gameboard.level)/(MAX_LEVEL+1) end
		if key == MOOSETETRIS_OPTIONS.keybinds.left or key == MOOSETETRIS_OPTIONS.keybinds.right then spinner:Hide() end
	end)
	
	--create the invisible array of cells
	for x=0,((20 * Gameboard.cellsPerRow) - 1) do
		local f
		f = CreateFrame("Frame","TetrisCell_"..tostring(x),self,"TetrisCellTemplate")
		f:SetWidth(Gameboard.cellSize)
		f:SetHeight(Gameboard.cellSize)
		f:SetPoint("TOPLEFT",self,"TOPLEFT",
			(x % Gameboard.cellsPerRow) * Gameboard.cellSize,
			floor(x / Gameboard.cellsPerRow) * -Gameboard.cellSize)
		Gameboard.CELLS[x] = f
	end
	
	UpdateScoreText()
end

function TetrisGameBoard:CreateTetromino(shape)
	--print(shape,"created")	--DEBUG
	Gameboard.activePieceStatus = "active"
	for x=1,4 do
		if not Gameboard.activePieces[x] then
			local f = CreateFrame("Frame","TetrisPiece_"..tostring(#Gameboard.activePieces + x),self,"TetrisCellTemplate")
			f:SetWidth(Gameboard.cellSize)
			f:SetHeight(Gameboard.cellSize)
			f.texture = _G[f:GetName().."_BGTexture"]
			Gameboard.activePieces[x] = f
		end
		Gameboard.activePieces[x]:Show()
		Gameboard.activePieces[x].texture:SetTexture(blockTex[Gameboard.level][shape])	--color according to the level color sets
		Gameboard.activePieces[x]:SetPoint("BOTTOM",Gameboard.CELLS[Gameboard.entryCell + Tetrominoes[shape][1][x]],"BOTTOM")
		Gameboard.activePieces[x].position = Gameboard.entryCell + Tetrominoes[shape][1][x]
		Gameboard.activePieces[x].blockType = shape
		Gameboard.activePieces[x].rotation = 1
	end
	Gameboard.cursor = Gameboard.entryCell
end

function TetrisGameBoard:CreateTetrominoFromQueue()
	if #TetrominoQueue < 3 then for a=1,5 do tinsert(TetrominoQueue,pieceTypes[random(1,#pieceTypes)]) end end
	self:CreateTetromino(TetrominoQueue[1])
	tremove(TetrominoQueue, 1)
	ChangePreviewPiece()
end

function TetrisGameBoard_OnUpdate(self,elapsed)
	self.TimeSinceLastUpdate = self.TimeSinceLastUpdate + elapsed
	while self.TimeSinceLastUpdate >= ONUPDATE_SPEED do
		self:GameLoop()
		self.TimeSinceLastUpdate = self.TimeSinceLastUpdate - ONUPDATE_SPEED
	end
end

function TetrisGameBoard:GameLoop()
	
	if Gameboard.isClearingLines then self:SetScript("OnUpdate",nil) return end
	if Gameboard.isGameOver then self:SetScript("OnUpdate",nil) end
	
	--[[	CLEAR LINE CHECK	]]
	if Gameboard.activePieceStatus == "dead" or #Gameboard.activePieces == 0 then	--the piece has dropped and been replaced by stationary blocks
		--check if there are lines to clear
		ClearAnyLines()
		self:CreateTetrominoFromQueue()
		return
	end
	
	--[[	LOSE CONDITION CHECK	]]
	--if a block is occupying the entry cell, the game is over.  note that the active piece is not part of the blocks table until it's placed.
	if IsBlockInCell(Gameboard.entryCell) == true then self:uLose() end
	
	--[[	GRAVITY		]]
	if IsPieceAtBottom() == false and IsBlockUnderPiece(Gameboard.cellsPerRow) == false then	--AND THERE'S NO BLOCK BENEATH THE PIECE
		ShiftPiece(Gameboard.cellsPerRow)
	else	-- current piece can't move down anymore
		for c=1,#Gameboard.activePieces do		-- should always be 1,4
			local f
			if #Gameboard.recyclables == 0 then	
				--create new frame
				f = CreateFrame("Frame","TetrisBlock_"..tostring(#Gameboard.blocks + #Gameboard.recyclables + 1),self,"TetrisCellTemplate")
				f:SetWidth(Gameboard.cellSize)
				f:SetHeight(Gameboard.cellSize)
				f.texture = _G[f:GetName().."_BGTexture"]
			else
				--take one from the recyclables
				f = Gameboard.recyclables[1]
				tremove(Gameboard.recyclables, 1)
			end
			f.blockType = Gameboard.activePieces[c].blockType
			f.texture:SetTexture(blockTex[Gameboard.level][Gameboard.activePieces[c].blockType])
			tinsert(Gameboard.blocks,f)
			f.position = Gameboard.activePieces[c].position
			f:SetPoint("BOTTOM",Gameboard.CELLS[f.position],"BOTTOM")
			f:Show()
			Gameboard.activePieceStatus = "dead"
		end
		tinsert(TetrominoQueue,pieceTypes[random(1,#pieceTypes)])
		return
	end

end

function TetrisGameBoard:NewGame()
	if Gameboard.isPaused == true then self:UnPause(false) end
	print(addonTag,"New game starting in 5 seconds. Get ready!")
	timer:Hide()
	self:ClearBoard()
	self.TimeSinceLastUpdate = -5
	Gameboard.isGameOver = false
	self:SetScript("OnUpdate",TetrisGameBoard_OnUpdate)
	for a = 1,#Gameboard.blocks do Gameboard.blocks[a]:Show() end
	--for b = 1,#Gameboard.activePieces do Gameboard.activePieces[b]:Show() end
	for c = 1,#Gameboard.previewBlocks do Gameboard.previewBlocks[c]:Show() end
end

function TetrisGameBoard:Pause(printMsg,hideBlocks,changeButtonText)
	if Gameboard.isClearingLines then return end
	if Gameboard.isGameOver == true or Gameboard.isPaused == true then return end
	if printMsg == true then print(addonTag,"Game paused...") end
	if changeButtonText then TetrisGameBoard_RightSideBar_PauseButton:SetText("UNPAUSE") end 
	Gameboard.isPaused = true
	self:SetScript("OnUpdate",nil)
	if hideBlocks then
		for a = 1,#Gameboard.blocks do Gameboard.blocks[a]:Hide() end
		for b = 1,#Gameboard.activePieces do Gameboard.activePieces[b]:Hide() end
		for c = 1,#Gameboard.previewBlocks do Gameboard.previewBlocks[c]:Hide() end
	end
	TetrisGameBoard_RightSideBar_PauseButton.checked = true
end

function TetrisGameBoard:UnPause(printMsg)
	if Gameboard.isGameOver == true or Gameboard.isPaused == false then return end
	TetrisGameBoard:GameLoop()
	if printMsg == true then print(addonTag,"Game resuming...") end
	TetrisGameBoard_RightSideBar_PauseButton:SetText("Pause")
	Gameboard.isPaused = false
	self:SetScript("OnUpdate",TetrisGameBoard_OnUpdate)
	for a = 1,#Gameboard.blocks do Gameboard.blocks[a]:Show() end
	for b = 1,#Gameboard.activePieces do Gameboard.activePieces[b]:Show() end
	for c = 1,#Gameboard.previewBlocks do Gameboard.previewBlocks[c]:Show() end
	TetrisGameBoard_RightSideBar_PauseButton.checked = false
end

function TetrisGameBoard:ClearBoard()
	for a = 1,#Gameboard.blocks do
		Gameboard.blocks[a].texture:SetVertexColor(1,1,1,1)
		Gameboard.blocks[a]:Hide()
		tinsert(Gameboard.recyclables, Gameboard.blocks[a])
	end
	for rec = 1,#Gameboard.recyclables do
		Gameboard.recyclables[rec].texture:SetVertexColor(1,1,1,1)
		for bl = 1,#Gameboard.blocks do
			if Gameboard.blocks[bl] == Gameboard.recyclables[rec] then tremove(Gameboard.blocks,bl) end
		end
	end
	for p = 1,4 do
		if Gameboard.activePieces[p] then Gameboard.activePieces[p]:Hide() end
	end
	--wipe(Gameboard.activePieces)
	ChangeLevel(0)
	Gameboard.linesUntilNextLevel = 10
	Gameboard.score = 0
	Gameboard.linesCleared = 0
	UpdateScoreText()
	Gameboard.activePieceStatus = "dead"
	wipe(TetrominoQueue)
end

function TetrisGameBoard:uLose()
	self:SetScript("OnUpdate",nil)
	print(addonTag,"Oh Noes! ULOSEBRO. Play Again!")
	for b = 1,#Gameboard.activePieces do Gameboard.activePieces[b]:Hide() end
	Gameboard.isGameOver = true
	timer.interval = .1
	timer.doFunction = ShadeBlocksRandomColors
	timer:Show()
	SendAddonMessage("$tet","*"..tostring(Gameboard.score),"GUILD")
end

function ShadeBlocksRandomColors()
	for x= 1,10 do
		if #Gameboard.blocks == 0 then break end
		local index = random(1,#Gameboard.blocks)
		if not Gameboard.blocks[index] then break end
		local block = Gameboard.blocks[index]
		local v = {block.texture:GetVertexColor()}
		local r = random(1,#v)
		if v[r] >= .1 then v[r] = v[r] - .1 end
		block.texture:SetVertexColor(v[1],v[2],v[3],v[4])
		local R,G,B,A = block.texture:GetVertexColor()
		if R <= .1 and G <= .1 and B <= .1 and A <= .1 then
			tinsert(Gameboard.recyclables, block)
			tremove(Gameboard.blocks, index)
			block:Hide()
			--print("removed \""..block:GetName().."\" from table. "..#Gameboard.blocks.." remaining...")	--DEBUG
		end
		
	end
	for y = 1,#Gameboard.blocks do
		local r,g,b,a = Gameboard.blocks[y].texture:GetVertexColor()
		if r >= .1 or g >= .1 or b >= .1 or a >= .1 then return true end
	end
	--print("animation done.")
	timer:Hide()
	return true
end

function UpdateScoreText()
	TetrisGameBoard_RightSideBar_linesTextFrame_Text:SetText("Lines Cleared:\n    "..tonumber(Gameboard.linesCleared))
	TetrisGameBoard_RightSideBar_scoreTextFrame_Text:SetText("Score:\n    "..tonumber(Gameboard.score))
	TetrisGameBoard_RightSideBar_levelTextFrame_Text:SetText("\124cffcccc00Level\124r "..tonumber(Gameboard.level))
end

function ChangePreviewPiece()
	
	--get queue[1] piece and display it in the preview box
	--set texture according to piece type and level colors
	if not TetrominoQueue[1] then for a=1,5 do tinsert(TetrominoQueue,pieceTypes[random(1,#pieceTypes)]) end sort(TetrominoQueue) end
	local shape = TetrominoQueue[1]
	local pieceAnchors = {
		["O"] = {{2,-2},{3,-2},{2,-3},{3,-3}},
		["I"] = {{1,-2.5},{2,-2.5},{3,-2.5},{4,-2.5}},
		["S"] = {{2.5,-2},{3.5,-2},{2.5,-3},{1.5,-3}},
		["Z"] = {{2.5,-2},{1.5,-2},{2.5,-3},{3.5,-3}},
		["L"] = {{1.5,-3.5},{1.5,-2.5},{2.5,-2.5},{3.5,-2.5}},
		["J"] = {{3.5,-3.5},{1.5,-2.5},{2.5,-2.5},{3.5,-2.5}},
		["T"] = {{1.5,-2},{2.5,-2},{3.5,-2},{2.5,-3}},
	}
	
	for x = 1,#Gameboard.previewBlocks do
		
		Gameboard.previewBlocks[x].texture:SetTexture(blockTex[Gameboard.level][shape])
		Gameboard.previewBlocks[x]:SetPoint(
			"TOPLEFT",
			TetrisGameBoard_RightSideBar_nextPieceFrame,
			"TOPLEFT",
			(4/5 * Gameboard.cellSize) * pieceAnchors[shape][x][1],
			(4/5 * Gameboard.cellSize) * pieceAnchors[shape][x][2])
	end

end

function ChangeLevel(newLevel)
	--set a cap
	if newLevel > MAX_LEVEL then newLevel = MAX_LEVEL end
	
	--update the level counter
	Gameboard.level = newLevel
	
	--change ONUPDATE_SPEED
	ONUPDATE_SPEED = (MAX_LEVEL + 1 - Gameboard.level)/(MAX_LEVEL+1)
	
	--change colors of all current blocks
	for a = 1,#Gameboard.blocks do
		Gameboard.blocks[a].texture:SetTexture(blockTex[Gameboard.level][Gameboard.blocks[a].blockType])
	end
	for b = 1,4 do
		if Gameboard.activePieces[b] then
			Gameboard.activePieces[b].texture:SetTexture(blockTex[Gameboard.level][Gameboard.activePieces[b].blockType])
		end
	end
	
end

local clearer = CreateFrame("frame",nil,TetrisGameBoard)
clearer:Hide()
clearer.TimeSinceLastUpdate, clearer.interval, clearer.rows, clearer.depletedRows, clearer.firstCellTopRow, clearer.numRowsToClear, clearer.blocksPerRow, clearer.timer = 0, .01, nil, nil, 0, 0, nil, 0
clearer:SetScript("OnUpdate",function(self,elapsed)
	self.TimeSinceLastUpdate = self.TimeSinceLastUpdate + elapsed
	if self.TimeSinceLastUpdate >= self.interval then
		if type(clearer.rows) ~= "table" then self:SetScript("OnUpdate",nil) return end

		if #clearer.rows <= 0 then 	--finished line-lowering animation
			
			--turn off this update script
			self:Hide()
			
			--[[hide rows
			reset each blocks' height value [and color if going to change colors]
			insert row blocks to recyclables table
			remove rows from Gameboard.blocks table]]
			--print("BEFORE recyclables:",#Gameboard.recyclables)
			--print("BEFORE blocks:",#Gameboard.blocks)
			for k,v in pairs(clearer.blocksPerRow) do
				--v is a table of blocks in each row
				for a,block in pairs(v) do
					block:Hide()
					block:SetHeight(Gameboard.cellSize)
					block.texture:SetVertexColor(1,1,1,1)
					tinsert(Gameboard.recyclables, block)
					--print("\124cff00ff00inserting block at pos",block.position,"-> recyclables\124r")
					for x,GAMEBOARDBLOCKS in pairs(Gameboard.blocks) do
						if GAMEBOARDBLOCKS == block then
							tremove(Gameboard.blocks, x)
							--print("\124cffff0000removing block at pos",block.position,"from Gameboard.blocks\124r")
						end
					end
				end
			end
			
			--print("AFTER recyclables:",#Gameboard.recyclables)
			--print("AFTER blocks:",#Gameboard.blocks)
			--bring down all blocks above by X rows
			table.sort(clearer.depletedRows, function(a,b) return a<b end)
			for x,row in pairs(clearer.depletedRows) do
				for y,block in pairs(Gameboard.blocks) do
					if block.position < (row * Gameboard.cellsPerRow) then
						block:SetPoint("BOTTOM",Gameboard.CELLS[block.position + Gameboard.cellsPerRow],"BOTTOM")
						block.position = block.position + Gameboard.cellsPerRow
					end	
				end
			end
			--update stats
			Gameboard.linesCleared = Gameboard.linesCleared + clearer.numRowsToClear
			Gameboard.score = Gameboard.score + (scores_per_lines_cleared[clearer.numRowsToClear] * (Gameboard.level + 1))
			Gameboard.linesUntilNextLevel = Gameboard.linesUntilNextLevel - clearer.numRowsToClear
			if Gameboard.linesUntilNextLevel <= 0 then	--NEXT LEVEL
				Gameboard.linesUntilNextLevel = 10 + (4 * Gameboard.level + 1) - Gameboard.linesUntilNextLevel
				ChangeLevel(Gameboard.level + 1)
			end
			UpdateScoreText()
			
			--may need to reset TetrisGameBoard.TimeSinceLastUpdate = -1 or something
			TetrisGameBoard.TimeSinceLastUpdate = 0
			TetrisGameBoard:SetScript("OnUpdate",TetrisGameBoard_OnUpdate)
			
			--Gameboard.isClearingLines = false
			Gameboard.isClearingLines = false

			return
		end
		
		
		--if clearer.blocksPerRow[clearer.rows[1]][1]:GetHeight() > 0 then
			--reduce height of all blocks in this row by 1/20th of the Gameboard.cellSize value
		
		
		
		
		if select(4,clearer.blocksPerRow[clearer.rows[1]][1].texture:GetVertexColor()) > 0 then
		
			for row,block in pairs(clearer.blocksPerRow[clearer.rows[1]]) do
				--block:SetHeight(block:GetHeight() - (Gameboard.cellSize / 20))
				
				local R,G,B,A = block.texture:GetVertexColor()
				block.texture:SetVertexColor(R,G,B,(A - (1/20)))
				
				if select(4,clearer.blocksPerRow[clearer.rows[1]][1].texture:GetVertexColor()) <= 0 then
					block:Hide()
				end
			end
			--if clearer.blocksPerRow[clearer.rows[1]][1]:GetHeight() <= 0 then
			if select(4,clearer.blocksPerRow[clearer.rows[1]][1].texture:GetVertexColor()) <= 0 then
				tinsert(clearer.depletedRows,clearer.rows[1])
				tremove(clearer.rows,1)
			end
		else
			tinsert(clearer.depletedRows,clearer.rows[1])
			tremove(clearer.rows,1)
		end
		
		self.TimeSinceLastUpdate = self.TimeSinceLastUpdate - self.interval
	end
end)

function ClearAnyLines()
	
	--this is also initialization of clearer table values
	clearer.TimeSinceLastUpdate = 0
	clearer.timer = 0
	clearer.rows = {}
	clearer.depletedRows = {}
	clearer.firstCellTopRow = 0
	clearer.numRowsToClear	= 0
	clearer.blocksPerRow = {}
	
	-- if each cell in row "x" has a block in it, add row "x" to table "clearer.rows"

	for row = 0,19 do
		for block = 0,Gameboard.cellsPerRow - 1 do
			if IsBlockInCell((row * Gameboard.cellsPerRow) + block) == false then break end
			if block == Gameboard.cellsPerRow - 1 then
				tinsert(clearer.rows, row)
			end
		end
	end
	
	if #clearer.rows <= 0 then return end
	
	Gameboard.isClearingLines = true
	
	table.sort(clearer.rows, function(a,b) return a<b end)
	clearer.firstCellTopRow = clearer.rows[1] * Gameboard.cellsPerRow
	clearer.numRowsToClear = #clearer.rows
	for k,row in pairs(clearer.rows) do
		clearer.blocksPerRow[row] = GetBlocksInRow(row)
	end

	--[[debug
	print("clearer.rows :")
	for k,v in pairs(clearer.rows) do print(k,v) end
	print("---------------")
	print("clearer.numRowsToClear",clearer.numRowsToClear)
	print("clearer.firstCellTopRow",clearer.firstCellTopRow)
	print("clearer.blocksPerRow:")
	for k,v in pairs(clearer.blocksPerRow) do
		for a,b in pairs(v) do
			print("["..k.."]","["..a.."] =",b.position)
		end
	end
	print("---------------")]]
	
	
	
	clearer:Show()

--[[
	if #linesToClear > 0 then
		
		table.sort(linesToClear, function(a,b) return a<b end)
		--print("clearing "..#linesToClear.." lines... "..linesToClear[1],linesToClear[2],linesToClear[3],linesToClear[4])
		local tetris = false
		if #linesToClear == 4 then tetris = true end
		for ROW = 1,#linesToClear do
			for BLOCK = 0,Gameboard.cellsPerRow - 1 do
				for GBB=1,#Gameboard.blocks do
					if Gameboard.blocks[GBB].position == (linesToClear[ROW] * Gameboard.cellsPerRow) + BLOCK then
						
						
						--CLEAR LINE ANIMATION GOES HERE
						
						
						Gameboard.blocks[GBB]:Hide()		--COMMENT OUT WHEN ANIMATION IS IMPLEMENTED
						tinsert(Gameboard.recyclables, Gameboard.blocks[GBB])		--COMMENT OUT WHEN ANIMATION IS IMPLEMENTED
					end
				end
			end
		end
		
		for shitlord = 1,#Gameboard.recyclables do
			local numBlocks = #Gameboard.blocks
			for piece = 0,numBlocks do
				if Gameboard.blocks[numBlocks - piece] then
					if Gameboard.blocks[numBlocks - piece] == Gameboard.recyclables[shitlord] then
						--print("removed block at",Gameboard.blocks[numBlocks - piece].position)
						tremove(Gameboard.blocks,numBlocks - piece)
					end
				end
			end
		end
		
		-- move blocks above cleared rows down
		for L = 1,#linesToClear do
			for z=1,#Gameboard.blocks do
				if Gameboard.blocks[z].position < linesToClear[L] * Gameboard.cellsPerRow then
					Gameboard.blocks[z]:SetPoint("CENTER",Gameboard.CELLS[Gameboard.blocks[z].position + Gameboard.cellsPerRow],"CENTER")
					Gameboard.blocks[z].position = Gameboard.blocks[z].position + Gameboard.cellsPerRow
				end
			end
		end

		--update stats
		Gameboard.linesCleared = Gameboard.linesCleared + #linesToClear
		Gameboard.score = Gameboard.score + (scores_per_lines_cleared[#linesToClear] * (Gameboard.level + 1))
		Gameboard.linesUntilNextLevel = Gameboard.linesUntilNextLevel - #linesToClear
		if Gameboard.linesUntilNextLevel <= 0 then	--NEXT LEVEL
			Gameboard.linesUntilNextLevel = 10 + (4 * Gameboard.level + 1) - Gameboard.linesUntilNextLevel
			ChangeLevel(Gameboard.level + 1)
		end
		
		
		UpdateScoreText()
		
		--TetrisGameBoard:SetScript("OnUpdate",nil)	--PAUSE FOR DEBU
		return true

	end
	return false]]
end

function GetBlocksInRow(row)	--returns table of all blocks in row
	local Blocks = {}
	for k,block in pairs(Gameboard.blocks) do
		if block.position >= (row * Gameboard.cellsPerRow) and block.position <= (((row + 1) * Gameboard.cellsPerRow) - 1) then
			tinsert(Blocks,block)
		end
	end
	return Blocks
end

function RotatePiece(d)	--where d == 1 or -1 (i.e. rotates 90 deg or -90 deg)
	--print("rotating piece...")
	if Gameboard.activePieceStatus == "dead" then return end
	local blockType,rotation,newRotationSet = Gameboard.activePieces[1].blockType, Gameboard.activePieces[1].rotation, Gameboard.activePieces[1].rotation + d
	if rotation + d > #Tetrominoes[blockType] then
		newRotationSet = 1
	elseif rotation + d <= 0 then
		newRotationSet = #Tetrominoes[blockType]
	end
	
	for x=1,#Gameboard.activePieces do
		Gameboard.activePieces[x]:SetPoint("BOTTOM",Gameboard.CELLS[Gameboard.cursor + Tetrominoes[blockType][newRotationSet][x]],"BOTTOM")
		--Gameboard.activePieces[x]:SetPoint("BOTTOM",Gameboard.CELLS[Gameboard.activePieces[x].position + n],"BOTTOM")
		Gameboard.activePieces[x].position = Gameboard.cursor + Tetrominoes[blockType][newRotationSet][x]
		Gameboard.activePieces[1].rotation = newRotationSet
	end
end

function ShiftPiece(n)
	if Gameboard.activePieceStatus == "dead" then return end
	for x=1,#Gameboard.activePieces do
		Gameboard.activePieces[x]:SetPoint("BOTTOM",Gameboard.CELLS[Gameboard.activePieces[x].position + n],"BOTTOM")
		Gameboard.activePieces[x].position = Gameboard.activePieces[x].position + n
	end
	Gameboard.cursor = Gameboard.cursor + n
end

function IsPieceAtBottom() -- returns bool (whether the current piece is in the bottom cells)
	for x=1,#Gameboard.activePieces do
		if Gameboard.activePieces[x].position >= ((20 - 1) * Gameboard.cellsPerRow) then return true end
	end
	return false
end

function IsPieceLeftmost()
	for x=1,#Gameboard.activePieces do
		if Gameboard.activePieces[x].position % Gameboard.cellsPerRow == 0 then return true end
	end
	return false
end

function IsPieceRightmost()
	for x=1,#Gameboard.activePieces do
		if Gameboard.activePieces[x].position % Gameboard.cellsPerRow == Gameboard.cellsPerRow - 1 then return true end
	end
	return false
end

function IsBlockInCell(cell)	--returns bool: whether there is a block occupying "cell"
	if cell < 0 or cell > ((20 * Gameboard.cellsPerRow) - 1) then return true end
	for y=1,#Gameboard.blocks do
		if Gameboard.blocks[y].position == cell then return true end
	end
	return false
end

function IsBlockUnderPiece(rel)	--returns bool (whether there is a block under the position relative to the active piece)
	for x=1,#Gameboard.activePieces do
		for y=1,#Gameboard.blocks do
			if Gameboard.activePieces[x].position + rel == Gameboard.blocks[y].position then return true end
		end
	end
	return false
end
