--[[ NOTES

]]

--**************************************************
-- addon globals

local floor, ceil, pairs, tinsert, print = floor, ceil, pairs, tinsert, print
local ClassColors = {
	["priest"] = "\124cffffffff",
	["mage"] = "\124cff69CCF0",
	["warlock"] = "\124cff9482C9",
	["druid"] = "\124cffFF7D0A",
	["rogue"] = "\124cffFFF569",
	["shaman"] = "\124cff0070DE",
	["hunter"] = "\124cffABD473",
	["warrior"] = "\124cffC79C6E",
	["death knight"] = "\124cffC41F3B",
	["paladin"] = "\124cffF58CBA",
	["monk"] = "\124cff00FF96",
}

--**************************************************
function RoundRealToInt(n)
	if (n - floor(n)) >= .5 then return ceil(n) else return floor(n) end
end

function tblContains(tbl,item)	--replacement for blizzard's fail tContains()
	for k,v in pairs(tbl) do
		if tbl[k] == item then return true end
	end
	return false
end

function tinsertAll(tbl,items)
	for k,v in pairs(items) do
		tinsert(tbl,v)
	end
end

function Moose_DebugMsg(msg)
	if not msg then return end	--nothing to print
	if not MOOSETETRIS_OPTIONS then MOOSETETRIS_SetDefaultOptions() end
	if type(MOOSETETRIS_OPTIONS.isDebugging) ~= "boolean" then MOOSETETRIS_OPTIONS.isDebugging = false end
	if MOOSETETRIS_OPTIONS.isDebugging == true then
		print("debug:",msg)
	end
end

function GetClassColor(class) --returns string containing color code for a class.  returns black if class is invalid.
	if class == nil or type(class) ~= "string" then return "\124cff000000" end
	for k,v in pairs(ClassColors) do
		if k == strlower(class) then return v end
	end
	return  "\124cff000000"
end









