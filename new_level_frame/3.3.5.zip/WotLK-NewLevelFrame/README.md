
# New Level Frame

### _Backported to 3.3.5a version from [Vanilla_NewLevelFrame](https://github.com/alchem1ster/Vanilla-NewLevelFrame) by [alchem1ster](https://github.com/alchem1ster)_

Just New Level Frame that will be shown when PLAYER_LEVEL_UP event is triggered



https://github.com/user-attachments/assets/c84f4997-e770-4bf2-8f36-6b72ed40e876



## How to install
- Download [THIS](https://github.com/mrrosh/WotLK-NewLevelFrame/archive/refs/heads/main.zip) archive;  
- Extract `WotLK-NewLevelFrame-main` folder to your `Interface/AddOns` folder and rename it to `WotLK-NewLevelFrame`;  
- Enjoy!  
