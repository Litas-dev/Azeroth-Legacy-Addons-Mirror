# Spy-Bronzebeard
### v1.0.1
Added "Disable alerts for non-hostile players" - to no longer be alerted by players you can't actually attack. (NOTE: while this is active, the scanning is based on nameplates (the only way to determine unitID and PvP flag) so make sure to crank that nameplate distance to the max).
## Spy Addon fixed to work in bronzebeard server.

- For the addon to work remember to change the name from "Spy-Bronzebeard-main" to "Spy".
- Since bronzebeard haven't launched yet i haven't been able to test if the player detection works correctly, but every other addon functionality works.
- If you detect any error or malfunction of the addon let me know with as much detail as you can and i will try to fix it.

---

For more info about the addon use /spy in the chat or check the orignial addon post description here: https://www.curseforge.com/wow/addons/spy

---

<img src="https://github.com/user-attachments/assets/54e47532-3d24-43e9-8238-8acdcbf62c8c" alt="ss4" width="200" style="vertical-align:top;"/>
<img src="https://github.com/user-attachments/assets/e157b3c1-7ef9-4f1e-8a56-74d8b42f53fe" alt="stealth" width="200" style="vertical-align:top;"/>
<img src="https://github.com/user-attachments/assets/364b73f5-5b3b-4a35-a1de-38e440e025ad" alt="ss7" width="200" style="vertical-align:top;"/>



