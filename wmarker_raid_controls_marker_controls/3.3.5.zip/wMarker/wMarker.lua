wMV = "wMarker v1.3"

wMarkerDB = {
	isLocked = false,
	isClamped = false,
	isHidden = false,
	isFlipped = false,
	partyShow = false,
	scale = 1,
	alpha = 1,
	scalePcnt = 100,
	alphaPcnt = 100,
	bgIsHidden = false,
}

local wMarker_defaultVars = {
	isLocked = false,
	isClamped = false,
	isHidden = false,
	isFlipped = false,
	partyShow = false,
	scale = 1,
	alpha = 1,
	scalePcnt = 100,
	alphaPcnt = 100,
	bgIsHidden = false,
}

local sVars = CreateFrame("FRAME")
sVars:RegisterEvent("ADDON_LOADED")
sVars:SetScript("OnEvent", function(self, event, addon)
	if addon == "wMarker" then
		if  wMarkerDB.isLocked == nil then
			wMarkerDB.isLocked = wMarker_defaultVars.isLocked
		elseif wMarkerDB.isClamped == nil then
			wMarkerDB.isClamped = wMarker_defaultVars.isClamped
		elseif wMarkerDB.isHidden == nil then
			wMarkerDB.isHidden = wMarker_defaultVars.isHidden
		elseif wMarkerDB.isFlipped == nil then
			wMarkerDB.isFlipped = wMarker_defaultVars.isFlipped	
		elseif wMarkerDB.partyShow == nil then
			wMarkerDB.partyShow = wMarker_defaultVars.partyShow
		elseif wMarkerDB.scale == nil then
			wMarkerDB.scale = wMarker_defaultVars.scale
		elseif wMarkerDB.alpha == nil then
			wMarkerDB.alpha = wMarker_defaultVars.alpha
		elseif wMarkerDB.scalePcnt == nil then
			wMarkerDB.scalePcnt = wMarker_defaultVars.scalePcnt
		elseif wMarkerDB.alphaPcnt == nil then
			wMarkerDB.alphaPcnt = wMarker_defaultVars.alphaPcnt
		elseif wMarkerDB.bgIsHidden == nil then
			wMarkerDB.bgIsHidden = wMarker_defaultVars.bgIsHidden
		end
					
		if wMarkerDB.isClamped == true then
			wMarker_MainFrame:SetClampedToScreen( true )
		else 
			wMarker_MainFrame:SetClampedToScreen( false )
		end
		if wMarkerDB.isHidden == true then
			wMarker_MainFrame:Hide()
		else
			wMarker_MainFrame:Show()
		end
		if wMarkerDB.partyShow == true then
				local pMems = GetNumPartyMembers()
				if pMems > 0 then
					wMarker_MainFrame:Show()
				elseif pMems == 0 then
					wMarker_MainFrame:Hide()
				end
		end
		if wMarkerDB.isLocked == true then
			wMarker_moveTab:SetAlpha(0)
			wMarker_moveTab2:SetAlpha(0)
			wMarker_moveTab:SetSize(1, 1)
			wMarker_moveTab2:SetSize(1, 1)	
		else
			wMarker_moveTab:SetAlpha(1)
			wMarker_moveTab2:SetAlpha(1)
			wMarker_moveTab:SetSize(20, 40)
			wMarker_moveTab2:SetSize(20, 40)
		end
		if wMarkerDB.isFlipped == true then
			wMarker_backwardIcons()
		else
			wMarker_forwardIcons()
		end
		if wMarkerDB.bgIsHidden == true then
			wMarker_IconFrame:SetBackdropColor(0.1, 0.1, 0.1, 0)
			wMarker_ControlFrame:SetBackdropColor(0.1, 0.1, 0.1, 0)
			wMarker_IconFrame:SetBackdropBorderColor(1, 1, 1, 0)
			wMarker_ControlFrame:SetBackdropBorderColor(1, 1, 1, 0)
		else 
			wMarker_IconFrame:SetBackdropColor(0.1, 0.1, 0.1, 0.7)
			wMarker_ControlFrame:SetBackdropColor(0.1, 0.1, 0.1, 0.7)
			wMarker_IconFrame:SetBackdropBorderColor(1, 1, 1, 1)
			wMarker_ControlFrame:SetBackdropBorderColor(1, 1, 1, 1)
		end
			wMarker_MainFrame:SetScale(wMarkerDB.scale)
			wMarker_MainFrame:SetAlpha(wMarkerDB.alpha)
			getglobal(wMarker_OptionsFrame_sliderScale:GetName().."Text"):SetText("wMarker Scale: "..wMarkerDB.scalePcnt.."%")
			getglobal(wMarker_OptionsFrame_sliderAlpha:GetName().."Text"):SetText("wMarker Alpha: "..wMarkerDB.alphaPcnt.."%")
	end
end)

local partyShowEvent = CreateFrame("FRAME")
partyShowEvent:RegisterEvent("PARTY_MEMBERS_CHANGED")
partyShowEvent:SetScript("OnEvent", function(self, event)
	if wMarkerDB.isHidden == false then
		if wMarkerDB.partyShow == true then
			local pMems = GetNumPartyMembers()
			if pMems > 0 then
				wMarker_MainFrame:Show()
			elseif pMems == 0 then
				wMarker_MainFrame:Hide()
			end
		end
	end
end)

SLASH_WMARKER1 = '/wmarker'
SLASH_WMARKER2 = '/wm'
function SlashCmdList.WMARKER(msg, editbox)
	if msg == 'lock' then
		if wMarkerDB.isLocked == true then
			wMarker_unlock()		
		elseif wMarkerDB.isLocked == false then
			wMarker_lock()				
		end
	end
	if msg == "hide" then
		wMarker_hide()
	end
	if msg == "show" then
		wMarker_show()
	end
	if msg == "clamp" then
		if wMarkerDB.isClamped == true then
			wMarker_unclamp() 
		elseif wMarkerDB.isClamped == false then
			wMarker_clamp()
		end
	end
	if msg == "reset" then
		wMarker_reset()
	end
	if msg == "options" then
		wMarker_OptionsFrame:Show()
		wMarker_OptionsFrame_headerText:SetText(wMV)
		getglobal(wMarker_OptionsFrame_sliderScale:GetName().."Text"):SetText("wMarker Scale: "..wMarkerDB.scalePcnt.."%")
		getglobal(wMarker_OptionsFrame_sliderAlpha:GetName().."Text"):SetText("wMarker Alpha: "..wMarkerDB.alphaPcnt.."%")
		wMarker_OptionsFrame_sliderScale:SetValue(wMarkerDB.scalePcnt)
		wMarker_OptionsFrame_sliderAlpha:SetValue(wMarkerDB.alphaPcnt)
		if wMarkerDB.isLocked == true then
			wMarker_OptionsFrame_buttonLock:SetChecked(true)
		else
			wMarker_OptionsFrame_buttonLock:SetChecked(false)
		end
		if wMarkerDB.isClamped == true then
			wMarker_OptionsFrame_buttonClamp:SetChecked(true)
		else
			wMarker_OptionsFrame_buttonClamp:SetChecked(false)
		end
		if wMarkerDB.isHidden == true then
			wMarker_OptionsFrame_buttonHide:SetChecked(false)
		else
			wMarker_OptionsFrame_buttonHide:SetChecked(true)
		end
		if wMarkerDB.isFlipped == true then
			wMarker_OptionsFrame_buttonFlip:SetChecked(true)
		else
			wMarker_OptionsFrame_buttonFlip:SetChecked(false)
		end
		if wMarkerDB.partyShow == true then
			wMarker_OptionsFrame_buttonPartyShow:SetChecked(true)
		else
			wMarker_OptionsFrame_buttonPartyShow:SetChecked(false)
		end
		if wMarkerDB.bgIsHidden == true then
			wMarker_OptionsFrame_buttonBgHide:SetChecked(true)
		else
			wMarker_OptionsFrame_buttonBgHide:SetChecked(false)
		end
	end
end
SLASH_RC1 = '/rc'
function SlashCmdList.RC(msg, editbox)
	DoReadyCheck();
end

function wMarker_reset()
	wMarkerDB.isLocked = wMarker_defaultVars.isLocked
	wMarkerDB.isClamped = wMarker_defaultVars.isClamped
	wMarkerDB.isHidden = wMarker_defaultVars.isHidden
	wMarkerDB.isFlipped = wMarker_defaultVars.isFlipped
	wMarkerDB.partyShow = wMarker_defaultVars.partyShow
	wMarkerDB.scale= wMarker_defaultVars.scale
	wMarkerDB.alpha = wMarker_defaultVars.alpha
	wMarkerDB.scalePcnt = wMarker_defaultVars.scalePcnt
	wMarkerDB.alphaPcnt = wMarker_defaultVars.scalePcnt
	wMarkerDB.bgIsHidden = wMarker_defaultVars.bgIsHidden
	wMarker_MainFrame:Show()
	wMarker_MainFrame:SetClampedToScreen( false )
	wMarker_MainFrame:ClearAllPoints()
	wMarker_MainFrame:SetPoint('CENTER', UIParent, 'CENTER', -30, 0)
	wMarker_moveTab:SetAlpha(1)
	wMarker_moveTab2:SetAlpha(1)
	wMarker_moveTab:SetSize(20, 40)
	wMarker_moveTab2:SetSize(20, 40)
	wMarker_OptionsFrame_buttonLock:SetChecked(false)
	wMarker_OptionsFrame_buttonClamp:SetChecked(false)
	wMarker_OptionsFrame_buttonHide:SetChecked(true)
	wMarker_OptionsFrame_buttonPartyShow:SetChecked(false)
	wMarker_OptionsFrame_buttonBgHide:SetChecked(false)
	wMarker_MainFrame:SetScale(1)
	wMarker_MainFrame:SetAlpha(1)
	wMarker_OptionsFrame_sliderScale:SetValue(100)
	wMarker_OptionsFrame_sliderAlpha:SetValue(100)
	getglobal(wMarker_OptionsFrame_sliderScale:GetName().."Text"):SetText("wMarker Scale: "..wMarkerDB.scalePcnt.."%")
	getglobal(wMarker_OptionsFrame_sliderAlpha:GetName().."Text"):SetText("wMarker Alpha: "..wMarkerDB.alphaPcnt.."%")
	wMarker_IconFrame:SetBackdropColor(0.1, 0.1, 0.1, 0.7)
	wMarker_ControlFrame:SetBackdropColor(0.1, 0.1, 0.1, 0.7)
	wMarker_IconFrame:SetBackdropBorderColor(1, 1, 1, 1)
	wMarker_ControlFrame:SetBackdropBorderColor(1, 1, 1, 1)
	wMarker_IconFrame_skull:SetPoint("LEFT", 5, 0)
    wMarker_IconFrame_cross:SetPoint("LEFT", "$parent_skull", "RIGHT", 0, 0)
    wMarker_IconFrame_square:SetPoint("LEFT", "$parent_cross", "RIGHT", 0, 0)
    wMarker_IconFrame_moon:SetPoint("LEFT", "$parent_square", "RIGHT", 0, 0)
    wMarker_IconFrame_triangle:SetPoint("LEFT", "$parent_moon", "RIGHT", 0, 0)
    wMarker_IconFrame_diamond:SetPoint("LEFT", "$parent_triangle", "RIGHT", 0, 0)
    wMarker_IconFrame_circle:SetPoint("LEFT", "$parent_diamond", "RIGHT", 0, 0)
    wMarker_IconFrame_star:SetPoint("LEFT", "$parent_circle", "RIGHT", 0, 0)
	print(wMV.." has been reset.")
end

function wMarker_lock()
	wMarkerDB.isLocked = true 
	wMarker_moveTab:SetAlpha(0)
	wMarker_moveTab2:SetAlpha(0)
	wMarker_moveTab:SetSize(1, 1)
	wMarker_moveTab2:SetSize(1, 1)	
end

function wMarker_unlock()
	wMarkerDB.isLocked = false
	wMarker_moveTab:SetAlpha(1)
	wMarker_moveTab2:SetAlpha(1)
	wMarker_moveTab:SetSize(20, 40)
	wMarker_moveTab2:SetSize(20, 40)
end

function wMarker_clamp()
	wMarkerDB.isClamped = true
	wMarker_MainFrame:SetClampedToScreen( true )
end

function wMarker_unclamp()
	wMarkerDB.isClamped = false
	wMarker_MainFrame:SetClampedToScreen( false )
end

function wMarker_show()
	wMarkerDB.isHidden = false
	wMarker_MainFrame:Show()
end

function wMarker_hide()
	wMarkerDB.isHidden = true
	wMarker_MainFrame:Hide()
end

function wMarker_scale(self)
	if self == nil then return end
	wMarkerDB.scalePcnt = math.floor(self:GetValue())
	getglobal(self:GetName().."Text"):SetText("wMarker Scale: "..wMarkerDB.scalePcnt.."%")
	wMarkerDB.scale = (self:GetValue()) / 100;
	wMarker_MainFrame:SetScale(wMarkerDB.scale);
end

function wMarker_alpha(self)
	wMarkerDB.alphaPcnt = math.floor(self:GetValue())
	getglobal(self:GetName().."Text"):SetText("wMarker Alpha: "..wMarkerDB.alphaPcnt.."%")
	wMarkerDB.alpha = (self:GetValue()) / 100;
	wMarker_MainFrame:SetAlpha(wMarkerDB.alpha)
end

function wMarker_BgHide()
	wMarker_IconFrame:SetBackdropColor(0.1, 0.1, 0.1, 0)
	wMarker_ControlFrame:SetBackdropColor(0.1, 0.1, 0.1, 0)
	wMarker_IconFrame:SetBackdropBorderColor(1, 1, 1, 0)
	wMarker_ControlFrame:SetBackdropBorderColor(1, 1, 1, 0)
end

function wMarker_BgShow()
	wMarker_IconFrame:SetBackdropColor(0.1, 0.1, 0.1, 0.7)
	wMarker_ControlFrame:SetBackdropColor(0.1, 0.1, 0.1, 0.7)
	wMarker_IconFrame:SetBackdropBorderColor(1, 1, 1, 1)
	wMarker_ControlFrame:SetBackdropBorderColor(1, 1, 1, 1)
end

function wMarker_forwardIcons()
   wMarker_IconFrame_skull:SetPoint("LEFT", 5, 0)
   wMarker_IconFrame_cross:SetPoint("LEFT", "$parent_skull", "RIGHT", 0, 0)
   wMarker_IconFrame_square:SetPoint("LEFT", "$parent_cross", "RIGHT", 0, 0)
   wMarker_IconFrame_moon:SetPoint("LEFT", "$parent_square", "RIGHT", 0, 0)
   wMarker_IconFrame_triangle:SetPoint("LEFT", "$parent_moon", "RIGHT", 0, 0)
   wMarker_IconFrame_diamond:SetPoint("LEFT", "$parent_triangle", "RIGHT", 0, 0)
   wMarker_IconFrame_circle:SetPoint("LEFT", "$parent_diamond", "RIGHT", 0, 0)
   wMarker_IconFrame_star:SetPoint("LEFT", "$parent_circle", "RIGHT", 0, 0)
   wMarkerDB.isFlipped = false
end

function wMarker_backwardIcons()
   wMarker_IconFrame_star:SetPoint("LEFT", 5, 0)
   wMarker_IconFrame_circle:SetPoint("LEFT", "$parent_star", "RIGHT", 0, 0)
   wMarker_IconFrame_diamond:SetPoint("LEFT", "$parent_circle", "RIGHT", 0, 0)
   wMarker_IconFrame_triangle:SetPoint("LEFT", "$parent_diamond", "RIGHT", 0, 0)
   wMarker_IconFrame_moon:SetPoint("LEFT", "$parent_triangle", "RIGHT", 0, 0)
   wMarker_IconFrame_square:SetPoint("LEFT", "$parent_moon", "RIGHT", 0, 0)
   wMarker_IconFrame_cross:SetPoint("LEFT", "$parent_square", "RIGHT", 0, 0)
   wMarker_IconFrame_skull:SetPoint("LEFT", "$parent_cross", "RIGHT", 0, 0)
   wMarkerDB.isFlipped = true
end
	
function wMarker_OnMouseDown()
	if wMarkerDB.isLocked == false then
		wMarker_MainFrame:StartMoving();
	elseif wMarkerDB.isLocked == true then
		return
	end
end

function wMarker_OnMouseUp()
	wMarker_MainFrame:StopMovingOrSizing();
end

function wMarkerOptions_OnMouseDown()
	wMarker_OptionsFrame:StartMoving();
end

function wMarkerOptions_OnMouseUp()
	wMarker_OptionsFrame:StopMovingOrSizing();
end