VenderChatarra_Locals = {}
local L = VenderChatarra_Locals
local Language = GetLocale()

-- Versión principal en Castellano --
if Language == 'esES' or Language == 'esMX' then
	L["Add"] = "Añadir a la Lista de Chatarra"
	L["Added"] = "Añadido a la Lista de Chatarra: %s"
	L["Remove"] = "Eliminar de la Lista de Chatarra"
	L["Removed"] = "Eliminado de la Lista de Chatarra: %s"
	L["SellJunk"] = "Vender Chatarra"
	L["SoldJunk"] = "Has vendido tu chatarra por %s"

-- Fallback/Default para cualquier otro idioma (también en castellano) --
else
	L["Add"] = "Añadir a la Lista de Chatarra"
	L["Added"] = "Añadido a la Lista de Chatarra: %s"
	L["Remove"] = "Eliminar de la Lista de Chatarra"
	L["Removed"] = "Eliminado de la Lista de Chatarra: %s"
	L["SellJunk"] = "Vender Chatarra"
	L["SoldJunk"] = "Has vendido tu chatarra por %s"
end