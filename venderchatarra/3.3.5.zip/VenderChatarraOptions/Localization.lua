local L = VenderChatarra_Locals
local Language = GetLocale()

-- Spanish (Castellano) - Versión principal
if Language == 'esES' or Language == 'esMX' then
	L["AutoSell"] = "Auto Vender"
	L["AutoSellDesc"] = "Si está habilitado, VenderChatarra venderá automáticamente toda tu chatarra cuando visites a un mercader."
	L["ShowTutorials"] = "Mostrar Tutoriales"
	L["Tutorial"] = "Estás usando VenderChatarra, un addon que te permite vender la chatarra que no necesitas con un simple click cada vez que visitas a un mercader.|n|n|cffffd200Click Izquierdo|r en el Botón VenderChatarra venderá toda tu chatarra. |cffffd200Click Derecho|r en el botón mostrará opciones extra."
	L["Tutorial2"] = "Puedes especificar que objetos quieres vender o no: para añadir o eliminar un objeto de tu |cffffd200Lista de Chatarra|r, arrástralo desde tus bolsas al Botón VenderChatarra."

-- Fallback/Default para cualquier otro idioma (también en castellano)
else
	L["AutoSell"] = "Auto Vender"
	L["AutoSellDesc"] = "Si está habilitado, VenderChatarra venderá automáticamente toda tu chatarra cuando visites a un mercader."
	L["ShowTutorials"] = "Mostrar Tutoriales"
	L["Tutorial"] = "Estás usando VenderChatarra, un addon que te permite vender la chatarra que no necesitas con un simple click cada vez que visitas a un mercader.|n|n|cffffd200Click Izquierdo|r en el Botón VenderChatarra venderá toda tu chatarra. |cffffd200Click Derecho|r en el botón mostrará opciones extra."
	L["Tutorial2"] = "Puedes especificar que objetos quieres vender o no: para añadir o eliminar un objeto de tu |cffffd200Lista de Chatarra|r, arrástralo desde tus bolsas al Botón VenderChatarra."
end