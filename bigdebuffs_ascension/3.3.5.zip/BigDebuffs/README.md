# BigDebuffs
WotLK displays information about controls on frames as icons. ENG and RUS locale.
![WoWScrnShot_041322_211414](https://user-images.githubusercontent.com/78731609/163246431-77171137-6e40-4311-b9f8-411cc8db52b1.jpg)
![WoWScrnShot_041322_211417](https://user-images.githubusercontent.com/78731609/163246441-057821d8-5f20-4795-bc68-8d5fe9a746a1.jpg)
![WoWScrnShot_041322_211426](https://user-images.githubusercontent.com/78731609/163246444-d44e7327-ab0b-4384-8e36-c06c96f54519.jpg)
