local GSE = GSE

GSE.UnsavedOptions["GUI"] = true
