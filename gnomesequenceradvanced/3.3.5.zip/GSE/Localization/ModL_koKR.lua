
if not(GetLocale() == "koKR") then
    return;
end

local L = LibStub("AceLocale-3.0"):NewLocale("GSE", "koKR")

-- Options translation
--@localization(locale="koKR", format="lua_additive_table")@


--@do-not-package@
--@end-do-not-package@
