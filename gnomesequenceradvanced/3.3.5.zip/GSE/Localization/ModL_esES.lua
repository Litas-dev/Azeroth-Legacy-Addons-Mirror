
if not(GetLocale() == "esES") then
    return;
end

local L = LibStub("AceLocale-3.0"):NewLocale("GSE", "esES")

-- Options translation
--@localization(locale="esES", format="lua_additive_table")@


--@do-not-package@
--@end-do-not-package@
