
if not(GetLocale() == "zhTW") then
    return;
end

local L = LibStub("AceLocale-3.0"):NewLocale("GSE", "zhTW")

-- Options translation
--@localization(locale="zhTW", format="lua_additive_table")@


--@do-not-package@
--@end-do-not-package@
