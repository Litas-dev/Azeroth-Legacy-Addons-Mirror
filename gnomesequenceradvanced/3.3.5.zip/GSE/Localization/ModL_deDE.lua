
if not(GetLocale() == "deDE") then
    return;
end

local L = LibStub("AceLocale-3.0"):NewLocale("GSE", "deDE", false)

-- Options translation
--@localization(locale="deDE", format="lua_additive_table")@


--@do-not-package@
--@end-do-not-package@
