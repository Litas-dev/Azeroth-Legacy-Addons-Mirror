
if not(GetLocale() == "ruRU") then
    return;
end

local L = LibStub("AceLocale-3.0"):NewLocale("GSE", "ruRU")

-- Options translation
--@localization(locale="ruRU", format="lua_additive_table")@


--@do-not-package@
--@end-do-not-package@
