
if not(GetLocale() == "zhCN") then
    return;
end

local L = LibStub("AceLocale-3.0"):NewLocale("GSE", "zhCN")

-- Options translation
--@localization(locale="zhCN", format="lua_additive_table")@


--@do-not-package@
--@end-do-not-package@
