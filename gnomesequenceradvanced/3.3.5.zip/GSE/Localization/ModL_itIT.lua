
if not(GetLocale() == "itIT") then
    return;
end

local L = LibStub("AceLocale-3.0"):NewLocale("GSE", "itIT")

-- Options translation
--@localization(locale="itIT", format="lua_additive_table")@


--@do-not-package@
--@end-do-not-package@
