
if not(GetLocale() == "frFR") then
    return;
end

local L = LibStub("AceLocale-3.0"):NewLocale("GSE", "frFR")

-- Options translation
--@localization(locale="frFR", format="lua_additive_table")@


--@do-not-package@
--@end-do-not-package@
