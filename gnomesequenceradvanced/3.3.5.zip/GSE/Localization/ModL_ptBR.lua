
if not(GetLocale() == "ptBR") then
    return;
end

local L = LibStub("AceLocale-3.0"):NewLocale("GSE", "ptBR")

-- Options translation
--@localization(locale="ptBR", format="lua_additive_table")@


--@do-not-package@
--@end-do-not-package@
