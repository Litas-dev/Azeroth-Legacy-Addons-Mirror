
if not(GetLocale() == "esMX") then
    return;
end

local L = LibStub("AceLocale-3.0"):NewLocale("GSE", "esMX")

-- Options translation
--@localization(locale="esMX", format="lua_additive_table")@


--@do-not-package@
--@end-do-not-package@
