SoulSpeak is a small Ace3/LibDataBroker based info/management addon.
For time being warlocks only!

Current features;

Does a random quote on Ritual of Souls and Ritual of Summoning.
Does a random emote/quote incl. whisper to target for Soulstone Resurrection.
Does a random quote when summoning Felguard, Felhunter, Imp, Succubus or Voidwalker.
Events is split in party/raid/solo with lots of editable messages.
Support <player>,<pet>,<target>,<targetclass>,<he/she>,<him/her>,<his/her>,<his/hers> tags.
Gender tags is NOT case sensitive, see what you type:)

Does a defined or random emote when using the infamous Hearthstone:P
The events is split in morning, afternoon, evening and night.

And since we all are polite warlocks:P
Does a defined or random emote to the person rez'ing you:)

How frequent the various events trigger can be set in options menu.

Colorized view of Soul Shard amount & delete (disabled by default) if > defined value.

It does not provide it's own display, you'll need a LDB-based display addon.
Use hotkeys on LDB-panel or type /ss for options menu.

Builtin support for multiple localizations, need translators!

This is my first addon and previously I had no experience with LUA-scripting.
SoulSpeak came to life by using countless hours learning how others did it.
Thanks to all of you and thanks to the community!:)

Lilih @ The Venture Co. (EU)

Changelog;
Version 3.1
- Fixed bug if change of target while casting Soulstone Resurrection
Version 3.09
- Increased Imp quotes from 16 to 18
- Increased default demon quotes frequency from 10% to 20%
- Fixed default Felguard quotes from 5 to 6
- Updated Ace3 libraries
Version 3.05
- Soulstone events frequency can now be set independently
- Fixed typos in Soulstone emote #8, #9 and #15
- Increased Felguard quotes from 5 to 6
- Minor changes in LDB-panel
- Code optimization
Version 3.01
- Fixed bug interfering with Tongues and public announcements
Version 3.0
- Support for <pet> tags, see defaults for examples
- Does a random quote when summoning Felguard or Felhunter
- Increased Soulstone emotes from 14 to 16
- Increased Soulstone quotes from 20 to 22
- Increased Ritual of Summoning quotes from 22 to 32
- Increased Imp quotes from 14 to 16
- Increased Voidwalker quotes from 9 to 10
- Several demon quotes was reset due to use of <pet> tag
- Enhanced Options/LDB-panel incl. dynamic demon icons
- Version number is now located under Options/About
Version 2.61
- Fixed bug with libraries loading routine
Version 2.6
- Does a random quote when summoning Succubus
- Increased Imp quotes from 10 to 14
- Increased Voidwalker quotes from 7 to 9
- Minor changes in LDB-panel
- Removed LDB options menu
- Libraries loading routine moved from XML to TOC
- Various code layout optimization
Version 2.5
- Does a random quote when summoning Imp or Voidwalker
- How frequent all events trigger can now be set
- Hearthstone and Resurrected emotes can now be set to random
- 'Helpme' emote for the rituals can now be turned off independently
- Updated 3 Soulstone events to reflect new cooldown timer (15min)
- Removed changelog from advanced options menu
- Removed version number from LDB-panel
- Various code optimization tweaks (some variables had to reset)
- Minor GUI and sound effect changes
- Memory usage reduced 50kb
- Updated AceConfig-3.0 & AceGUI-3.0 libraries
Version 2.41
- Fixed bug in parser function for targets from other realms
Version 2.4
- Updated TOC for patch 3.3
- Updated TOC addon loading routine
- Updated Ace3/LibDataBroker libraries
- Reduced fixed width size in advanced options menu
- Minor changes in description fields
Version 2.35
- Updated TOC for patch 3.2
- Enhancements incl. sound effects in advanced options menu
- Advanced options can now be opened from Blizzard addons menu
Version 2.34
- Fixed bug with auto delete of excess Soul Shards
- Fixed bug not making the GUI options screen as intended
- Reduced Soulstone emotes from 18 to 14
- Reduced Soulstone quotes from 22 to 20
- Reduced Soulstone whispers from 21 to 18
Version 2.31
- Hearthstone emote should now trigger at all times
Version 2.3
- Resurrected emotes can now be changed
- Increased Resurrected emotes from 1 to 12
- Increased Ritual of Souls quotes from 17 to 20
- Rearranged Soulstone quotes/whispers
- Localization is now variables in core
- Minor code optimization
Version 2.21
- Fixed typos in description fields
Version 2.2
- Gender tags is no longer case sensitive, see what you type
- Support <his/hers> and <targetclass> tags
- Increased Soulstone emotes from 17 to 18
- Increased Soulstone quotes from 20 to 22
- Increased Soulstone whispers from 18 to 20
- Increased Ritual of Souls quotes from 16 to 17
- Increased Ritual of Summoning quotes from 20 to 22
- Increased Soul Shard view from 3 to 6 colors incl. new scales
- Fixed bug where changing profiles would force player to reload
- Fixed bug in tags function when using one of the ritual spells
- Fixed bug in tags parser function
- Minor changes in default emotes/quotes/whispers
- GUI enhancements in advanced options menu
Version 2.15
- Fixed random function causing neverending loop
- Fixed minor bug in Hearthstone timeframe
- Fixed typos in default emotes/quotes/whispers
- Enabled messages set to 1 no longer is 2 on reload
- Gender tags should now trigger correctly on all events
- Support <He/She> tags
- Increased Soulstone emotes from 10 to 17
- Increased Soulstone quotes from 18 to 20
- Increased Soulstone whispers from 12 to 18
- Increased Ritual of Souls quotes from 13 to 16
- Increased Ritual of Summoning quotes from 19 to 20
Version 2.1
- Support <he/she>,<him/her>,<his/her> tags, see defaults for examples
- Random emote/quote/whisper is now never the same twice in a row if > 1
- Increased Soulstone quotes from 10 to 18
- Increased Soulstone whispers from 10 to 12
- Increased Ritual of Souls quotes from 10 to 13
- Increased Ritual of Summoning quotes from 12 to 19
- Increased all emote/quote/whisper message fields to 20
- Soul Shard colorized view now scale 33% <> 66% previous 25% <> 75%
- Soul Shard amount on panel now updates correctly on profile reset
- GUI enhancements incl. new button to delete Soul Shards > defined value
- Reorganized config menu in LDB-panel
- Fixed bug interfering with BabelFu on french clients
Version 2.02
- Spell events now use spellID instead of spellName
Version 2.01
- Fixed emotes and spells localization
Version 2.0
- Support for Soulstone Resurrection incl. whisper to target
- Support <player> and <target> tags
- 'Helpme' emote for the rituals can now be turned off
- Max number of messages to use can now be set independently on all events
- Resurrected emote can now be enabled for party, raid and solo
- Increased Ritual of Summoning quotes from 10 to 12
- Title, status and options on tooltip can now be turned off
- Enhancements in advanced options menu
- Minor code optimization
Version 1.4
- Quotes management in advanced options has been reorganized
- Quotes can now be enabled for chat, party and raid independently
- Quote channels can now be changed (raid > party > say > yell)
- Increased all default quotes from 8 to 10
- Removed color codes from localization file
Version 1.32
- Fixed toggle of Hearthstone emotes more logical
- Fixed minor typo in morning, afternoon, evening and night descriptions
Version 1.3
- Fixed colors in panel/tooltip based on Soul Shard amount
- The 'Bye/Farewell' emote should now trigger correctly
- Quotes in chat frame if not in group can now be turned off
- Soul Shard amount on panel/tooltip can now be turned off
- Increased Hearthstone emotes from 6 to 14
- Increased Ritual of Souls quotes from 6 to 8
Version 1.2
- First public release
Version x.x
- Internal development releases