do
	
	local function GetTotalCount(itemId)
		return ICGetItemCountTotal(itemId) or -1;
	end
	
	local function GetCharacterCount(itemId)
		return ICGetItemCountCharacter(itemId) or -1;
	end
	
	local function IsEnabled()
		return (ICGetItemCountTotal and ICGetItemCountCharacter);
	end
	
	IMRegisterItemCountAddon("ItemCount", GetTotalCount, GetCharacterCount, IsEnabled);
	
end
