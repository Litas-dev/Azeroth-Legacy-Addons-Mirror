do
	
	local function GetTotalCount(itemId)
		return Altoholic:GetItemCount(itemId) or -1;
	end
	
	local function IsEnabled()
		return (Altoholic and Altoholic.GetItemCount);
	end
	
	IMRegisterItemCountAddon("Altoholic", GetTotalCount, nil, IsEnabled);
	
end
