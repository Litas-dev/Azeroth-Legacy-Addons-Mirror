do
	
	local function Queue(tradeSkillIndex, amount)
		local link = GetTradeSkillRecipeLink(tradeSkillIndex);
		local recipeId = tonumber(link:match("|Henchant:([-0-9]+)|h"));
		
		GnomeWorks:ShowQueueList();
		return GnomeWorks:AddToQueue(GnomeWorks.player, tradeSkillIndex, recipeId, amount);
	end
	
	local function IsEnabled()
		return (GnomeWorks and GnomeWorks.AddToQueue);
	end
	
	IMRegisterCraftingAddon("GnomeWorks", Queue, IsEnabled);
	
end
