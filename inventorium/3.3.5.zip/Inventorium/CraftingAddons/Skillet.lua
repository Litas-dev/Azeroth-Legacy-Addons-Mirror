do
	
	local function Queue(tradeSkillIndex, amount)
		local link = GetTradeSkillRecipeLink(tradeSkillIndex);
		local recipeId = tonumber(link:match("|Henchant:([-0-9]+)|h"));
		
		local newCommand = Skillet:QueueCommandIterate(recipeId, amount);
		return Skillet:AddToQueue(newCommand);
	end
	
	local function IsEnabled()
		return (Skillet and Skillet.QueueCommandIterate and Skillet.AddToQueue);
	end
	
	IMRegisterCraftingAddon("Skillet", Queue, IsEnabled);
	
end
