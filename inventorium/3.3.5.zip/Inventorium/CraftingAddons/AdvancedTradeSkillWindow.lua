do
	
	local function Queue(tradeSkillIndex, amount)
		local link = GetTradeSkillItemLink(tradeSkillIndex);
		local itemName = link:match("%[([^%[%]]*)%]");
		
		return ATSW_AddJob(itemName, amount);
	end
	
	local function IsEnabled()
		return (ATSW_AddJob);
	end
	
	IMRegisterCraftingAddon("AdvancedTradeSkillWindow", Queue, IsEnabled);
	
end
