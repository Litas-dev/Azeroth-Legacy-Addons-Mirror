do
	
	local function GetValue(link)
		local _, _, _, lowerBuyout, _, _, numAuctions, _ = AucMasGetCurrentAuctionInfo(link, false, true);
		--local avgBid, avgBuyout, lowerBid, lowerBuyout, upperBid, upperBuyout, numAuctions, numBuyouts
		
		return (numAuctions > 0 and lowerBuyout) or -1;
	end
	
	local function IsEnabled()
		return (AucMasGetCurrentAuctionInfo);
	end
	
	IMRegisterPricingAddon("AuctionMaster", GetValue, IsEnabled);
	
end
