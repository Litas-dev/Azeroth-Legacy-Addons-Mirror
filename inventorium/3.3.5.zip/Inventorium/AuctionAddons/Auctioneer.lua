do
	
	local function GetValue(link)
		local imgSeen, _, _, _, _, lowBuy, _, _ = AucAdvanced.Modules.Util.SimpleAuction.Private.GetItems(link);
		--local imgseen, image, matchBid, matchBuy, lowBid, lowBuy, aveBuy, aSeen 
		
		if imgSeen <= 0 then
			-- No auctions up at this time
			return -1;
		end
		
		return lowBuy;
	end
	
	local function IsEnabled()
		return (AucAdvanced ~= nil and AucAdvanced.Modules.Util.SimpleAuction ~= nil and AucAdvanced.Modules.Util.SimpleAuction.Private.GetItems ~= nil);
	end
	
	IMRegisterPricingAddon("Auctioneer", GetValue, IsEnabled);
	
end
