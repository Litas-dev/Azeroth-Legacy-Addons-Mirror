do
	
	local function GetValue(link)
		return GetAuctionBuyout(link) or -1;
	end
	
	local function IsEnabled()
		return (GetAuctionBuyout);
	end
	
	IMRegisterPricingAddon("Others", GetValue, IsEnabled);
	
end
