do
	
	local function GetValue(link)
		local history = AuctionLite:GetHistoricalPriceById(itemID);
		
		return (history and hist.items > 0 and math.floor(hist.price)) or -1;
	end
	
	local function IsEnabled()
		return (AuctionLite and AuctionLite.GetHistoricalPriceById);
	end
	
	IMRegisterPricingAddon("AuctionLite", GetValue, IsEnabled);
	
end
