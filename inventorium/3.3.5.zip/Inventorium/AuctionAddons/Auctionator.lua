do
	
	local function GetValue(link)
		return Atr_GetAuctionBuyout(link) or -1;
	end
	
	local function IsEnabled()
		return (Atr_GetAuctionBuyout);
	end
	
	IMRegisterPricingAddon("Auctionator", GetValue, IsEnabled);
	
end
