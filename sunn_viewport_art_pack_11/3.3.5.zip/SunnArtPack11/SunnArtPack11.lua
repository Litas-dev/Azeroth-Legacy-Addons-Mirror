if not SunnArtPack then SunnArtPack = {theme = {}, overlap = {}, panels = {}, length = {}} end
SunnArtPack.theme["SunnArtPack11\\catabottom"] = "Cataclysm (Bottom)"
SunnArtPack.overlap["SunnArtPack11\\catabottom"] = 31.8
SunnArtPack.panels["SunnArtPack11\\catabottom"] = 2

SunnArtPack.theme["SunnArtPack11\\cataside"] = "Cataclysm (Sides)"
SunnArtPack.overlap["SunnArtPack11\\cataside"] = 0
SunnArtPack.panels["SunnArtPack11\\cataside"] = 1

SunnArtPack.theme["SunnArtPack11\\cata2-"] = "Cataclysm 2"
SunnArtPack.overlap["SunnArtPack11\\cata2-"] = 0
SunnArtPack.panels["SunnArtPack11\\cata2-"] = 4

SunnArtPack.theme["SunnArtPack11\\deathwing"] = "Deathwing"
SunnArtPack.overlap["SunnArtPack11\\deathwing"] = 0
SunnArtPack.panels["SunnArtPack11\\deathwing"] = 4

SunnArtPack.theme["SunnArtPack11\\worgen"] = "Worgen"
SunnArtPack.overlap["SunnArtPack11\\worgen"] = 0
SunnArtPack.panels["SunnArtPack11\\worgen"] = 4

SunnArtPack.theme["SunnArtPack11\\worgen2"] = "Worgen 2"
SunnArtPack.overlap["SunnArtPack11\\worgen2"] = 0
SunnArtPack.panels["SunnArtPack11\\worgen2"] = 4

SunnArtPack.theme["SunnArtPack11\\goblin"] = "Goblin"
SunnArtPack.overlap["SunnArtPack11\\goblin"] = 0
SunnArtPack.panels["SunnArtPack11\\goblin"] = 4

DEFAULT_CHAT_FRAME:AddMessage("|cFF0000FFSunnArtPack11|r: Loaded")
