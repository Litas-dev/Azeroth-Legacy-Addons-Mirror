local startcash = GetMoney() or 0
local count = 0
local SILVER_PER_GOLD, COPPER_PER_SILVER = SILVER_PER_GOLD, COPPER_PER_SILVER
local f

function Junkster_OnEvent()

	if(event=="MERCHANT_SHOW") then
		count = 0
		startcash = GetMoney()
		for bag=0,4 do
			for slot=0,GetContainerNumSlots(bag) do
				local link = GetContainerItemLink(bag, slot)
				if link and select(3, GetItemInfo(link)) == 0 then
					ShowMerchantSellCursor(1)
					UseContainerItem(bag, slot)
					count = count + 1
				end
			end
		end

	f:RegisterEvent("MERCHANT_CLOSED")
	
	elseif(event=="MERCHANT_CLOSED") then

		local endcash = GetMoney()
		local gain = endcash - startcash
		local gold = floor(gain / (COPPER_PER_SILVER * SILVER_PER_GOLD))
		local silver = floor((gain - (gold * COPPER_PER_SILVER * SILVER_PER_GOLD)) / COPPER_PER_SILVER)
		local copper = mod(gain, COPPER_PER_SILVER)

		
		if gain == 0 then
			return
		end
		
		if gain < 0 then
			
			gain = startcash - endcash

		gold = floor(gain / (COPPER_PER_SILVER * SILVER_PER_GOLD))
		silver = floor((gain - (gold * COPPER_PER_SILVER * SILVER_PER_GOLD)) / COPPER_PER_SILVER)
		copper = mod(gain, COPPER_PER_SILVER)


				DEFAULT_CHAT_FRAME:AddMessage(string.format("Junkster: Sold %d trash items and |cffff0000lost|r "..gold.."|cffffd700g|r "..silver.."|cffc7c7cfs|r "..copper.."|cffeda55fc|r.", count))

		else
				DEFAULT_CHAT_FRAME:AddMessage(string.format("Junkster: Sold %d trash items and |cff00ff00gained|r "..gold.."|cffffd700g|r "..silver.."|cffc7c7cfs|r "..copper.."|cffeda55fc|r.", count))
		end
	f:UnregisterEvent("MERCHANT_CLOSED")
	end	

end

f = CreateFrame("Frame")

	f:SetScript("OnEvent", Junkster_OnEvent)
	f:RegisterEvent("MERCHANT_SHOW")