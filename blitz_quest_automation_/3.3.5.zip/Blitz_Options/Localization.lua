local L = Blitz_Locals

L.Automate = "Automate Gossip"
L.AutomateDesc = "Sets automating as the default action for enabled quests."
L.AutomateKey = "Automating Key"
L.AutomateKeyDesc = "Holding the selected key while talking to a quest giver will start Blitz's automating process."
L.Description = "Automatically accepts and delivers daily and repeatable quests."
L.DisableKey = "Disable Key"
L.DisableKeyDesc = "Holding the selected key while talking to a quest giver will stop Blitz's automating process."
L.EnableQuests = "Enable Quests"
L.EnableQuestsDesc = "Enables new quests for the automating process by default."