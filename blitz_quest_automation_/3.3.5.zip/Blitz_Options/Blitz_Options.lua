--[[
Copyright 2009, 2010 João Cardoso
Blitz is distributed under the terms of the GNU General Public License (or the Lesser GPL).
This file is part of Blitz.

Blitz is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

Blitz is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with Blitz. If not, see <http://www.gnu.org/licenses/>.
--]]

local Options = LibStub('Sushi-2.0'):CreateWidget('Container')
local L, Sets = Blitz_Locals, Blitz_Settings


--[[ Options ]]--

function Options:Startup()
	self:SetParent(BlitzOptions)
	self:SetPoint('BOTTOMRIGHT', -4, 5)
	self:SetPoint('TOPLEFT', 4, -4)
	self:SetHeight(0)
	self:SetWidth(0)

	self:SetLayout('List')
	self:SetChildren('Initialize')
	self.Startup = nil
end

function Options:Initialize()
	self:Create('Heading', 'Blitz')
	self:Create('Description', 'Description', true)
	self:Create('CheckButton', 'EnableQuests')
	self:Create('CheckButton', 'Automate')
	
	local Dropdown = self:Create('Dropdown', 'AutomateKey')
	Dropdown:AddLine('Alt', ALT_KEY)
	Dropdown:AddLine('Control', CTRL_KEY)
	Dropdown:AddLine('Shift', SHIFT_KEY)
	Dropdown:AddLine('None', NONE_KEY)
	Dropdown:SetWidth(135)
	
	if Sets.Automate then
		Dropdown:SetDescription(L.DisableKeyDesc)
		Dropdown:SetLabel(L.DisableKey)
	end
end

function Options:Create(type, arg, small)
	local widget = self:CreateChild(type)
	widget:SetLabel(L[arg] or arg)
	widget:SetSmall(small)
	
	if widget.SetValue then
		widget:SetDescription(L[arg .. 'Desc'])
		widget:SetValue(Sets[arg])
		
		widget:RegisterCallback('OnValueChanged', function(v)
			Sets[arg] = v
		end)
	end
	
	return widget
end

Options:Startup()