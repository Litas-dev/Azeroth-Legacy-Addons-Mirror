--[[
Copyright 2008, 2009, 2010 João Cardoso
Sushi is distributed under the terms of the GNU General Public License (or the Lesser GPL).
This file is part of Sushi.

Sushi is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

Sushi is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with Sushi. If not, see <http://www.gnu.org/licenses/>.
--]]

local Sushi = LibStub('Sushi-2.0')
local Description = Sushi:NewWidgetClass('Description', {
	frameType = 'Frame',
	insets = {top = 5, bottom = 20, left = 12, right = 12},
	version = 1,
})

if not Description then
	return
end


--[[ Events ]]--

function Description:OnCreate()
	local Text = self:CreateFontString(self:GetName() .. 'Text')
	Text:SetPoint('TOPLEFT')
	Text:SetJustifyH('LEFT')
	
	self.SetRealWidth = getmetatable(self).__index.SetWidth
	self.SetLabel = self.SetText
	self.GetLabel = self.GetText
	self.Text = Text
end

function Description:OnAcquire()
	self:SetWidth(true)
	self:UpdateFont()
end

function Description:OnRelease()
	self.disabled, self.small = nil, nil
	self.Text:SetText(nil)
end


--[[ Text ]]--

function Description:SetText(text)
	self.Text:SetText(text)
	self:UpdateHeight()
end

function Description:GetText(text)
	return self.Text:GetText()
end


--[[ Width & Height ]]--

function Description:SetWidth(width)
	if width == true then
		local parent = self:GetParent()
		width = parent and parent:GetWidth() - 12
	end
	
	width = width or 0
	self.Text:SetWidth(width)
	self:SetRealWidth(width)
	self:UpdateHeight()
end

function Description:UpdateHeight()
	self:SetHeight(self.Text:GetHeight())
end


--[[ Font ]]--

function Description:SetDisabled(disabled)
	self.disabled = disabled
	self:UpdateFont()
end

function Description:IsDisabled()
	return self.disabled
end

function Description:SetSmall(small)
	self.small = small
	self:UpdateFont()
end

function Description:IsSmall()
	return self.small
end

function Description:UpdateFont()
	local font
	if not self:IsDisabled() then
		font = 'Highlight'
	else
		font = 'Disable'
	end
	if self:IsSmall() then
		font = font ..'Small'
	end
	
	self.Text:SetFontObject('GameFont' .. font)
	self:UpdateHeight()
end


--[[ Embedding ]]--

Description:UpdateEmbeds()