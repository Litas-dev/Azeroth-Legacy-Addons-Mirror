--[[
Copyright 2009, 2010 João Cardoso
Blitz Display is distributed under the terms of the GNU General Public License (or the Lesser GPL).
This file is part of Blitz Display.

Blitz Display is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

Blitz Display is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with Blitz Display. If not, see <http://www.gnu.org/licenses/>.
--]]

AchievementShield_OnLoad = AchievementShield_OnLoad or function() end --it's to only way to use this template
local Display = CreateFrame('Button', 'BlitzDisplay', UIParent, 'AchievementAlertFrameTemplate')
local QuestMessageFormat = ERR_QUEST_COMPLETE_S:gsub('%%s', '([%%s%%a%%p]+)')


--[[ Frame ]]--

function Display:Startup()
	hooksecurefunc('AlertFrame_FixAnchors', function() self:UpdatePosition() end)
	self:SetScript('OnEvent', function(self, event, ...) self[event](self, ...) end)
	self:RegisterEvent('CHAT_MSG_SYSTEM')
	self:RegisterForClicks(nil)
	
	-- Regions
	local name = self:GetName()
	_G[name..'Glow']:Hide()
	_G[name..'Shine']:Hide()
	_G[name..'Shield']:Hide()
	_G[name..'Name']:Hide()
	
	-- Background
	local BackPatch = self:CreateTexture(name..'BackgroundPatch', 'BORDER')
	BackPatch:SetTexture('Interface\\Addons\\Blitz_Display\\Textures\\Background Patch') 
	BackPatch:SetPoint('CENTER', _G[name..'Background'], 104, -20)
	
	-- Required Items
	local ItemCount = _G[name .. 'Icon']:CreateFontString(name ..'ItemCount', 'OVERLAY', 'NumberFontNormal')
	ItemCount:SetPoint('BOTTOMRIGHT', _G[name .. 'IconTexture'], -4, 4)
	
	self.ItemIcon = _G[name .. 'IconTexture']
	self.ItemCount = ItemCount
	
	-- NPC Portrait
	local PortraitBorder = self:CreateTexture(name..'PortraitBorder', 'OVERLAY')
	PortraitBorder:SetTexture('Interface/AchievementFrame/UI-Achievement-IconFrame')
	PortraitBorder:SetHeight(73) PortraitBorder:SetWidth(73)
	PortraitBorder:SetTexCoord(0.5625, 0, 0, 0.5625)
	PortraitBorder:SetPoint('TOPRIGHT', 0, -7)
	
	local Portrait = self:CreateTexture(name..'Portrait', 'ARTWORK')
	Portrait:SetHeight(55) Portrait:SetWidth(55)
	Portrait:SetPoint('CENTER', PortraitBorder)
	self.Portrait = Portrait
	
	-- Quest Title
	local QuestTitle = _G[name .. 'Unlocked']
	QuestTitle:SetTextColor(.8, .8, .8)
	QuestTitle:SetDrawLayer('OVERLAY')
	QuestTitle:SetPoint('TOP', 1, -24)
	QuestTitle:SetWidth(110)
	self.QuestTitle = QuestTitle
	
	local TitleBack = self:CreateTexture(name..'TitleBackground', 'ARTWORK')
	TitleBack:SetTexture('Interface/AchievementFrame/UI-Achievement-Reward-Background')
	TitleBack:SetWidth(250) TitleBack:SetHeight(21)
	TitleBack:SetVertexColor(.5, .5, .5)
	TitleBack:SetPoint('TOP', 40, -15)
	TitleBack:SetTexCoord(0, 1, 1, 0)
	
	-- Progress Arrow
	local Arrow = self:CreateTexture(name..'Arrow', 'ARTWORK')
	Arrow:SetTexture('Interface\\Addons\\Blitz_Display\\Textures\\Arrow')
	Arrow:SetHeight(50) Arrow:SetWidth(190)
	Arrow:SetPoint('CENTER', 1, -2)
	
	local ArrowGlow = self:CreateTexture(name..'ArrowGlow', 'OVERLAY')
	ArrowGlow:SetTexture('Interface\\Addons\\Blitz_Display\\Textures\\Arrow Glow')
	ArrowGlow:SetPoint('LEFT', Arrow) ArrowGlow:SetHeight(50)
	self.ArrowGlow = ArrowGlow
	
	local ArrowSpark = self:CreateTexture(name..'ArrowSpark', 'OVERLAY')
	ArrowSpark:SetTexture('Interface/CastingBar/UI-CastingBar-Spark')
	ArrowSpark:SetWidth(14) ArrowSpark:SetHeight(14)
	ArrowSpark:SetBlendMode('ADD')
	self.ArrowSpark = ArrowSpark
	
	-- Animations
	local FadeOut = self:CreateAnimationGroup():CreateAnimation()
	FadeOut:SetScript('OnUpdate', function() self:SetAlpha(1 - FadeOut:GetProgress()) end)
	FadeOut:SetScript('OnFinished', function() self:Hide() AlertFrame_FixAnchors() end)
	FadeOut:SetStartDelay(3)
	FadeOut:SetDuration(1.5)
	self.FadeOut = FadeOut
	
	local FadeIn = self:CreateAnimationGroup():CreateAnimation()
	FadeIn:SetScript('OnUpdate', function() self:SetAlpha(FadeIn:GetProgress()) end)
	FadeIn:SetScript('OnFinished', function() FadeOut:Play() end)
	FadeIn:SetDuration(0.2)
	self.FadeIn = FadeIn
	
	local ArrowAnimation = self:CreateAnimationGroup():CreateAnimation()
	ArrowAnimation:SetEndDelay(5)
	ArrowAnimation:SetDuration(1)
	
	ArrowAnimation:SetScript('OnUpdate', function()
		local progress = ArrowAnimation:GetProgress() * self.increment + self.start
		ArrowSpark:SetPoint('LEFT', ArrowGlow, 190 * progress - 5, 0)
		ArrowGlow:SetTexCoord(0, progress, 0, 1)
		ArrowGlow:SetWidth(190 * progress)
		
		if progress >= 0.93 then
			ArrowSpark:Hide()
		end
	end)
	
	self.ArrowAnimation = ArrowAnimation
	self.Startup = nil
end

function Display:ShowQuest(name, info)
	local hidden, new = not self:IsShown(), self.name ~= name
	if new then
		SetPortraitTexture(self.Portrait, 'NPC')
		self.QuestTitle:SetText(name)
	end
	
	if hidden or new then
		local numStacks, requiredStack, item
		for item, required in gmatch(info, '(%d+):(%d+)') do
			local stacks = floor(GetItemCount(item) / required)
			if not numStacks or stacks < numStacks then
				requiredStack = required
				requiredItem = item
				numStacks = stacks
			end
		end

		self.numStacks, self.stack, self.item, self.name = numStacks, requiredStack, requiredItem, name
		self.ItemIcon:SetTexture(GetItemIcon(requiredItem))
		self.ArrowGlow:SetTexCoord(0, 0.045, 0, 1)
		self.ArrowGlow:SetWidth(1)
		self.ArrowSpark:Show()
	end
	
	if hidden then
		self:UpdatePosition()
		self.FadeIn:Play()
		self:Show()
	else
		self.FadeOut:Stop()
		self.FadeOut:Play()
	end
	
	self:BAG_UPDATE()
	self:RegisterEvent('BAG_UPDATE')
end

function Display:UpdatePosition()
	if self:IsShown() then
		DungeonCompletionAlertFrame1:SetPoint('BOTTOM', self, 'TOP', 0, 10)

		for i= 2, 1, -1 do
			local frame = _G['AchievementAlertFrame'..i]
			if frame and frame:IsShown() then
				return self:SetPoint('BOTTOM', frame, 'TOP', 0, -10)
			end
		end
			
		for i = NUM_GROUP_LOOT_FRAMES, 1, -1 do
			local frame = _G['GroupLootFrame'..i]
			if frame and frame:IsShown() then
				return self:SetPoint('BOTTOM', frame, 'TOP', 0, 10)
			end
		end
		
		self:SetPoint('BOTTOM', UIParent, 'BOTTOM', 0, 128)
	end
end


--[[ Events ]]--

function Display:CHAT_MSG_SYSTEM(text)
	local name = strmatch(text, QuestMessageFormat)
	if not name or name == '' then
		return
	end
	
	local info = Blitz_RepeatableQuests[name]
	if info and Blitz:CanSkipQuest(name) then
		self:ShowQuest(name, info)
	end
end

function Display:BAG_UPDATE()
	if Blitz:CanSkipQuest(self.name) then
		self.ItemIcon:SetVertexColor(1, 1, 1)
	else
		self.ItemIcon:SetVertexColor(0.4, 0.4, 0.4)
	end
	
	local numItems = GetItemCount(self.item)
	self.start = select(5, self.ArrowGlow:GetTexCoord())
	self.increment = ((self.numStacks - floor(numItems / self.stack)) / self.numStacks - self.start) * 0.93
	
	self.ItemCount:SetText(format('%d/%d', numItems, self.stack))
	self:UnregisterEvent('BAG_UPDATE')
	self.ArrowAnimation:Stop()
	self.ArrowAnimation:Play()
end

Display:Startup()