--[[
Copyright 2009, 2010 João Cardoso
Blitz is distributed under the terms of the GNU General Public License (or the Lesser GPL).
This file is part of Blitz.

Blitz is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

Blitz is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with Blitz. If not, see <http://www.gnu.org/licenses/>.
--]]

local Blitz = CreateFrame('CheckButton', 'Blitz', QuestFrame, 'OptionsSmallCheckButtonTemplate')
local ActiveQuests, RepeatableQuests, DailyQuests
local L, Sets = Blitz_Locals


--[[ Startup ]]--

function Blitz:Startup()
	self:SetScript('OnEvent', function(self, event, ...) self[event](self, ...) end)
	self:RegisterEvent('VARIABLES_LOADED')
	self:RegisterEvent('QUEST_GREETING')
	self:RegisterEvent('QUEST_COMPLETE')
	self:RegisterEvent('QUEST_PROGRESS')
	self:RegisterEvent('QUEST_ACCEPTED')
	self:RegisterEvent('QUEST_DETAIL')
	self:RegisterEvent('GOSSIP_SHOW')
	
	self:StartupOptions()
	self:SetScript('OnClick', self.ToggleQuest)
	self:SetPoint('TOPLEFT', 74, -50)
	self.StartupOptions = nil
	self.Startup = nil
	
	hooksecurefunc('QuestInfoItem_OnClick', function() self:SetQuestReward() end)
	BlitzText:SetText(L.AutomateQuest)
end

function Blitz:StartupOptions()
	local frame = CreateFrame('Frame', 'BlitzOptions')
	frame.name = 'Blitz'
	
	frame:SetScript('OnShow', function()
		local loaded, reason = LoadAddOn('Blitz_Options')
		if not loaded then
			local string = frame:CreateFontString()
			string:SetFontObject('GameFontHighlight')
			string:SetHeight(30)
			
			string:SetPoint('LEFT', 40, 0)
			string:SetPoint('RIGHT', -40, 0)
			string:SetText(format(L.MissingOptions, strlower(_G['ADDON_'..reason])))
		end
	end)
	
	InterfaceOptions_AddCategory(frame)
end

function Blitz:VARIABLES_LOADED()
	Sets = Blitz_Settings or {AutomateKey = 'Shift'}
	Blitz_Settings = Sets
	
	ActiveQuests = Blitz_ActiveQuests or {}
	RepeatableQuests = Blitz_RepeatableQuests or {}
	DailyQuests = Blitz_DailyQuests or {}
	
	Blitz_ActiveQuests = ActiveQuests
	Blitz_RepeatableQuests = RepeatableQuests
	Blitz_DailyQuests = DailyQuests
	
	self.VARIABLES_LOADED = nil
	self:CheckForDailies()
end


--[[ Events ]]--

function Blitz:GOSSIP_SHOW()
	if self:IsKeyDown() then
		if not self:SelectGossipOption('Active', GetGossipActiveQuests()) then
			self:SelectGossipOption('Available', GetGossipAvailableQuests())
		end
	end
end

function Blitz:QUEST_GREETING()
	if self:IsKeyDown() then
		for i = 1, GetNumActiveQuests() do
			if self:CanSkipQuest(GetActiveTitle(i)) then
				return SelectGossipActiveQuest(i)
			end
		end
		
		for i = 1, GetNumAvailableQuests() do
			if self:CanSkipQuest(GetAvailableTitle(i)) then
				return SelectGossipAvailableQuest(i)
			end
		end
	end
	
	self:Hide()
end

function Blitz:QUEST_DETAIL()
	if self:IsKeyDown() and ActiveQuests[GetTitleText()] then
		AcceptQuest()
	end
	
	self:UpdateGossipButton()
end

function Blitz:QUEST_ACCEPTED()
	self:CheckForDailies()
end

function Blitz:QUEST_PROGRESS()
	local name = GetTitleText()
	local info = self:GetQuestLogInfo(name)
	
	if self:CanSkipQuest(name) then
		CompleteQuest()
	elseif not info then
		self:RegisterRepeatableQuest(name)
	end
	
	self:UpdateGossipButton()
end

function Blitz:QUEST_ITEM_UPDATE()
	self:RegisterRepeatableQuest(GetTitleText())
	self:UnregisterEvent('QUEST_ITEM_UPDATE')
end

function Blitz:QUEST_COMPLETE()
	local name = GetTitleText()
	local item = ActiveQuests[name]
	
	self:UpdateGossipButton() -- Placed here for now to prevent bugs from previous version!
	if self:CanSkipQuest(name) then
		if GetNumQuestChoices() > 0 and item == 0 then
			QuestChooseRewardError()
		else
			GetQuestReward(item)
		end
	end
	
	if item and item ~= 0 then
		local icon = _G['QuestRewardItem' .. item]
		if icon then
			icon:GetScript('OnClick')(icon)
		end
	end
end


--[[ Enable/Disable ]]--

function Blitz:UpdateGossipButton()
	local name = GetTitleText()
	if DailyQuests[name] or RepeatableQuests[name] then
		if ActiveQuests[name] == nil or ActiveQuests[name] == true then -- The 'true' is just a bug fix from previous version. Remove in the future!
			ActiveQuests[name] = Sets.EnableQuests and self:GetSelectedReward() or false
		end
		
		self:SetChecked(ActiveQuests[name] and true)
		self:Show()
	else
		self:Hide()
	end
end

function Blitz:ToggleQuest()
	local name = GetTitleText()
	if not ActiveQuests[name] then
		ActiveQuests[name] = self:GetSelectedReward()
	else
		ActiveQuests[name] = nil
	end
end

function Blitz:SetQuestReward()
	local name = GetTitleText()
	if ActiveQuests[name] then
		ActiveQuests[name] = self:GetSelectedReward()
	end
end

function Blitz:GetSelectedReward()
	return QuestInfoFrame.itemChoice or 0
end


--[[ Skipping ]]--

function Blitz:SelectGossipOption(type, ...)
	for i = 1, select('#', ...), 5 do
		if self:CanSkipQuest(select(i, ...)) then
			return _G['SelectGossip'..type..'Quest']((i - 1) / 5 + 1)
		end
	end
end

function Blitz:CanSkipQuest(name)
	if self:IsKeyDown() and ActiveQuests[name] then
		local info = RepeatableQuests[name]
		if info then
			return self:HasQuestRequirements(info)
		else
			return self:CanAdvanceQuest(name)
		end
	end
end

function Blitz:IsKeyDown()
	local key, default = Sets.AutomateKey, Sets.Automate
	local down = key ~= 'None' and _G['Is' .. key .. 'KeyDown']()
	return (not default and down) or (default and not down)
end


--[[ Dailies ]]--

function Blitz:CheckForDailies()
	for i = 1, MAX_QUESTLOG_QUESTS * 2 do
		local title, _, _, _, _, _, _, isDaily = GetQuestLogTitle(i)
		if title then
			DailyQuests[title] = isDaily and true or nil
		end
	end
end

function Blitz:CanAdvanceQuest(name)
	local hasQuest, _,_,_,_, isComplete = self:GetQuestLogInfo(name)
	return not hasQuest or isComplete
end

function Blitz:GetQuestLogInfo(name)
	for i = 1, MAX_QUESTLOG_QUESTS * 2 do
		local title = GetQuestLogTitle(i)
		if title == name then
			return select(2, GetQuestLogTitle(i))
		end
	end
end


--[[ Repeatables ]]--

function Blitz:RegisterRepeatableQuest(name)
	local info

	for i = 1, GetNumQuestItems() do
		local id = strmatch(GetQuestItemLink('required', i) or '', 'item:(%d+)')
		if id then
			local item = id .. ':' .. select(3, GetQuestItemInfo('required', i))
			
			if i > 1 then
				info = info .. ':' .. item
			else
				info = item
			end
		else
			self:RegisterEvent('QUEST_ITEM_UPDATE')
			return
		end
	end
		
	local money = GetQuestMoneyToGet()
	if money > 0 then
		info = info .. '|' .. money
	end
		
	RepeatableQuests[name] = info
end

function Blitz:HasQuestRequirements(info)
	for item, required in gmatch(info, '(%d+):(%d+)') do
		if GetItemCount(item) < tonumber(required) then
			return false
		end
	end
	
	local money = strmatch(info, '|(%d+)')
	if not money or GetMoney() > money then
		return true
	end
end

Blitz:Startup()