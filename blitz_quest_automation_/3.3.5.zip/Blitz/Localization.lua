Blitz_Locals = {}
local L = Blitz_Locals

L.AutomateQuest = 'Automate Quest'
L.MissingOptions = '"Blitz Options" could not be loaded because the addon is %s.'