﻿--[[ $Id: Locale.en.lua 14691 2006-10-21 20:09:52Z damjau $ ]]--

local L = AceLibrary("AceLocale-2.2"):new("CooldownCount")

L:RegisterTranslations("deDE", function()
	return {
		["shine"] = "Aufleuchten",
		["Toggle icon shine display after finish cooldown."] = "Aktiviert ein Aufleuchten des Symbols wenn die Abklingzeit abgelaufen ist.",
		["shinescale"] = "Aufleuchten Größe",
		["Adjust icon shine scale."] = "Justiere die Größe des aufzuleuchtenden Symbols.",
		["font"] = "Schriftart",
		["Set cooldown value display font."] = "Wähle die Schriftart in der die Abklingzeit angezeigt werden soll.",

		["font size"] = "Schriftgröße",
		["Setup cooldown value display font size."] = "Wähle die Größe der Schriftart welche die Abklingzeit anzeigt.",
		["small size"] = "Kleine Schriftgröße",
		["Small font size for cooldown is longer than 10 minutes."] = "Anzeigen der Abklingzeit in einer kleinen Schriftgröße wenn die Abklingzeit länger als 10 Minuten ist.",
		["medium size"] = "Normale Schriftgröße",
		["Medium font size for cooldown is longer than 1 minute and less than 10 minutes."] = "Anzeigen der Abklingzeit in normaler Schriftgröße wenn die Abklingzeit länger als 1 Minuten ist.",
		["large size"] = "Große Schriftgröße",
		["Large font size for cooldown is longer than 10 seconds and less than 1 minutes."] = "Anzeigen der Abklingzeit in großer Schriftgröße wenn die Abklingzeit länger als 10 Sekunden und weniger als 1 Minute ist.",
		["warning size"] = "Warnung Schriftgröße",
		["Warning font size for cooldown is less than 10 seconds."] = "Warnung Schriftgröße (groß/blinkend) wenn die Abklingzeit weniger als 10 Sekunden ist.",

		["common color"] = "Allgemeine Farbe",
		["Setup the common color for value display."] = "Justiere die  Allgemeine Farbe der Schriftart.",
		["warning color"] = "Warnungsfarbe",
		["Setup the warning color for value display."] = "Justiere die  Warnungsfarbe der Schriftart.",

		["d"] = "T",
		["h"] = "S",
		["m"] = "M",

		["minimum duration"] = "Minimum Dauer",
		["Minimum duration for display cooldown count."] = "Minimum Dauer einer Abklingzeit damit diese anzeigt wird.",
		["hide animation"] = "Verstecke Animation",
		["Hide Bliz origin cooldown animation."] = "Verstecke die Orginale Blizzard Abklingzeit Animation.",
	}
end)
