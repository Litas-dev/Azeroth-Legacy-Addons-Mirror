﻿local L = AceLibrary("AceLocale-2.2"):new("CooldownCount")

L:RegisterTranslations("zhTW", function()
	return {
		["shine"] = "閃爍",
		["Toggle icon shine display after finish cooldown."] = "設定冷卻完畢後閃爍提示",
		["shinescale"] = "閃爍大小",
		["Adjust icon shine scale."] = "設定圖示閃爍大小",
		["font"] = "字型",
		["Set cooldown value display font."] = "設定冷卻數字字體",

		["font size"] = "字體大小",
		["Setup cooldown value display font size."] = "設定冷卻顯示字體大小",
		["small size"] = "小尺寸",
		["Small font size for cooldown is longer than 10 minutes."] = "設定大於10分鐘的冷卻字體大小",
		["medium size"] = "中尺寸",
		["Medium font size for cooldown is longer than 1 minute and less than 10 minutes."] = "設定1-10分鐘的冷卻字體大小",
		["large size"] = "大尺寸",
		["Large font size for cooldown is longer than 10 seconds and less than 1 minutes."] = "設定10秒-1分鐘的冷卻字體大小",
		["warning size"] = "警告尺寸",
		["Warning font size for cooldown is less than 10 seconds."] = "設定小於10秒鐘的冷卻字體大小",

		["common color"] = "一般顏色",
		["Setup the common color for value display."] = "設定冷卻顯示字體的一般顏色",
		["warning color"] = "警告顏色",
		["Setup the warning color for value display."] = "設定冷卻顯示字體的警告顏色",
		
		["d"] = "天",
		["h"] = "時",
		["m"] = "分",

		["minimum duration"] = "最小時間",
		["Minimum duration for display cooldown count."] = "設定顯示倒數計時的最小冷卻時間",
		["hide animation"] = "隱藏動畫",
		["Hide Bliz origin cooldown animation."] = "隱藏暴風雪原有的冷卻動畫",

	}
end)