﻿--[[ $Id: Locale.lua 14439 2006-10-19 22:52:04Z hshh $ ]]--

local L = AceLibrary("AceLocale-2.2"):new("CooldownCount")

L:RegisterTranslations("frFR", function()
	return {
		["shine"] = "surbrillance",
		["Toggle icon shine display after finish cooldown."] = "Basculer la surbrillance de l'icône après la fin du cooldown.",
		["shinescale"] = "échelle de la surbrillance",
		["Adjust icon shine scale."] = "Ajuste l'échelle de la surbrillance de l'icône.",
		--["font"] = true,
		["Set cooldown value display font."] = "Définir la police d'affichage de la valeur.",

		["font size"] = "taille de la police",
		["Setup cooldown value display font size."] = "Définir la taille de la police d'affichage de la valeur.",
		["small size"] = "petite taille",
		["Small font size for cooldown is longer than 10 minutes."] = "Petite taille pour des valeurs supérieures à 10 minutes.",
		["medium size"] = "taille moyenne",
		["Medium font size for cooldown is longer than 1 minute and less than 10 minutes."] = "Taille moyenne pour des valeurs supérieures à 1 minute et inférieur à 10.",
		["large size"] = "grande taille",
		["Large font size for cooldown is longer than 10 seconds and less than 1 minutes."] = "Grande Taille pour des valeurs supérieures à 10 secondes et inférieures à 1 minute.",
		["warning size"] = "taille d'alerte",
		["Warning font size for cooldown is less than 10 seconds."] = "Taille d'alerte pour des valeurs inférieures à 10 secondes.",

		["common color"] = "couleur commune",
		["Setup the common color for value display."] = "Définir la couleur commune d'affichage de la valeur.",
		["warning color"] = "couleur d'alerte",
		["Setup the warning color for value display."] = "Définir la couleur d'alerte d'affichage de la valeur.",

		["d"] = "j",
		["h"] = "h",
		["m"] = "m",

		["minimum duration"] = "durée minimum",
		["Minimum duration for display cooldown count."] = "Durée minimum pour afficher le compteur",
		["hide animation"] = "masquer l'animation",
		["Hide Bliz origin cooldown animation."] = "Masquer l'animation de cooldown de l'interface d'origine"
	}
end)
