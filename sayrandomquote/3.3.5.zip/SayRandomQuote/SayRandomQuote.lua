srq_quotes = {}

srq_quotes["rezfunny"] = {
"Hey the fire DOES buff you %t!",
"Red rover, red rover, send %t right over!",
"I rezzed your mom last night %t!",
"It's ok %t, just blame your death on lag. That's why you didn't get healed...",
"Aw, how cute, %t's dead AGAIN.",
"%t fails at life. Literally.",
"Your subscription to life has expired %t, would you like to renew?",
"There are worse things then death, %t. Have you ever grouped with Nampy?",
"Well %t, you tried your best, but apparently your best is pretty terrible.",
"You don't deserve a cute rez macro, %t. You deserve to die. Oh you did! Karma works.",
"I'll rez you my pretty, and your little %t too!!!!!", 
"Sorry you died %t, your healer was too busy looking at po...I mean I had baby aggro. Yeah. Baby aggro.",
"Quick %t, accept this rez before the necrophiliacs get here!",
"GAME OVER. Restart %t?",
"Rise and kick moar azz %t.",
}

srq_quotes["rez"] = {
">>> Rezzing %t <<<",
"<<< Rezzing %t >>>",
">>> Rezzing %t <<<",
"<<< Rezzing %t >>>",
">>> Rezzing %t <<<",
"<<< Rezzing %t >>>",
">>> Rezzing %t <<<",
"<<< Rezzing %t >>>",
">>> Rezzing %t <<<",
"<<< Rezzing %t >>>",
"Incoming rez for %t",
"Rez: %t",
"Incoming rez for %t",
"Rez: %t",
"Incoming rez for %t",
"Rez: %t",
"Incoming rez for %t",
"Rez: %t",
"Hey the fire DOES buff you %t!",
"Red rover, red rover, send %t right over!",
"I rezzed your mom last night %t!",
"It's ok %t, just blame your death on lag. That's why you didn't get healed...",
"Aw, how cute, %t's dead AGAIN.",
"%t fails at life. Literally!",
"Your subscription to life has expired %t, would you like to renew?",
"There are worse things then death, %t. Have you ever grouped with Nampy?",
"Well %t, you tried your best, but apparently your best is pretty terrible.",
"You don't deserve a cute rez macro, %t. You deserve to die. Oh you did! Karma works.",
"I'll rez you my pretty, and your little %t too!!!!!", 
"Sorry you died %t, your healer was too busy looking at po...I mean I had baby aggro. Yeah. Baby aggro.",
"Quick %t, accept this rez before the necrophiliacs get here!",
"GAME OVER. Restart %t?",
"Rise and kick moar azz %t.",
}

srq_quotes["g2g"] = {
"cat got out",
"g2g my hamster's on fire",
"g2g ",
"afk ",
"afk ",
"afk ",
"afk ",
"afk ",
"afk ",
"afk ",
}

srq_quotes["mount"] = {
"",
"",
"",
"",
"",
"",
"",
"Regulators...mount up.",
"I'll get you my pretty, and your little dog too!!!!!",
"Why walk when you can ride?",
"You like it?  Thank the boys at 'Pimp my Mount.'",
"Don't you wish your mount was hot like mine?",
"I'm out of here.",
}

srq_quotes["ty"] = {
"ty",
"ty ty",
"thanks",
"thanks you",
"tanks yew",
"danka",
" /ty",
}

srq_quotes["farewell"] = {
"later",
"l8",
"peace",
"farewell",
" /bye",
" /goodbye",
" /late",
" /later",
"see ya",
"cya",
"bye",
"goodbye",
"Farewell, metaphors be with you.",
}

srq_quotes["summoning"] = {
"Summoning %t, please click.",
"What, your hearthstone on cooldown %t?",
"Scotty, beam %t up! Didn't work? Guess you can't summon stupid.",
"Sorry, Scotty's on break %t. Try again later.",
"Summoning retards hasn't been tested before.  Are you volunteering %t?",
"Click the portal for your free %t!",
"By accepting this summon %t, you agree to pay my repair bill. How nice!",
"%t, come on down! You're the next contestant on 'Lazy Ass WoW Players!'",
"Summoning %t.  Declining this summon will result in death.  Survival not guaranteed if accepted.",
"Summoning %t, click if you're horny.",
"Summoning %t.  Please beat them like they owe you money.",
"Summoning %t, click the effing portal!",
"Red rover, red rover, send %t right over!",
"Summoning %t.  Thousands served.",
"Summoning %t.  Clicky clicky por favor.",
"God %t, can't you WALK?",
}

srq_quotes["summonppl"] = {
"Just because this lasts two minutes doesn't mean I want to stand here that long. Please click.",
"Summoning %t, please click.  Wait, is this a Summoning Portal or a Doomguard Portal?  I always get those two mixed up...",
"The two things I hate most are summoning people and not getting a 'thank you.'  Both are about to happen.",
"Accepting this summon will result in the 'Recently Summoned' debuff, which decreases %t's chace at epic lewts by 100% for the next four hours.",
"I actually hate you %t, I'm just doing this to help the group.",
"Summoning %t.  Next person to pass the portal and not click goes on THE LIST.",
"So, %t, care to explain why you weren't here on time? Don't worry, you can explain it to our fearless leader face-to-face. Enjoy.",
"Why is %t so special? I mean, the rest of you managed to get here without help.",
"Azeroth Yellow Cab!  Summoning %t, please click.",
"Who wants to lend me their soul for the next shard?",
"First one to click the portal gets 1g! (Not really.)",
"If you don't want me to run up there, aggro all those mobs, sacrifice my Voidwalker and run like hell, I suggest you click this portal.",
"Summoning Services!  Transporting slackers like %t since 2007! Please click.",
"You know %t, you can get a mount at level 20 now.  Oh, no reason.  Just conversation.",
"Hey %t, shards don't grow on trees you know!",
"Do we HAVE to summon %t?  I'm sure I have a demon that could do their job.",
"Every time I summon a player, I have to kill something.  You're damning my eternal WoW soul to Hell!  I hope you're happy %t.",
"Every time you click this portal, Blizzard kills a noob.",
"Whoa whoa whoa whoa whoa whoa whoa whoa. Whoa... whoa... whoa. Lois, this is not my Batman Glass.",
}

srq_quotes["shortgratz"] = {
"gratz!",
"gratz",
"congratulations",
"GRATZ!",
"grats",
"grats!",
"grats dude",
"gratz dude",
"way to go",
" /congratulations",
" /grats",
" /congrats",
" /gratz",
"congrats",
"wtg",
"here's a cookie",
"its ggggggggggggggggratz!",
"starg",
"congratu-freaking-lations",
"OMG GRATZ! ;)",
"if i seem impressed, i'm not. jk! grats. =)",
"well done",	
"felicidades (congratulations in Spanish)",
"urime (congratulations in Albanian)",
"felicitaties (congratulations in Dutch)",
"onnitlused (congratulations in Estonian)",
"felicitations (congratulations in French)",
"parabens (congratulations in Galician, no its not an alien language)",
"gluckwunsche (congratulations in German)",
"comhghairdeas (congratulations in Irish)",
"congratulazioni (congratulations in Italian)",
"hongera (congratulations in Swahili)",
"There is only one measurement for success in WoW: BOSS is DEAD = WIN!",
"o / \\ o High five!",
" /highfive",
"\\m/ >.< \\m/ ROCK ON!",
"garzibalizik (congratulations that I made up just for Furry)",
"\\o/ yay!",
"gratz!",
"jesus how many times do i have to say this in one day? gratz! =)",
"you want a cookie or something? jk gratz!",
"here's a cookie: O",
"here's a cookie: {circle}",
"V(-.-)V grats",
"V(-.o)V grats",
"woot!",
"w00t",
"w00+",
"\\/\\/ O 0 +",
" /hi5",
" /high5",
" /hiphive",
" /highphive",
" /highfuckingfive",
" /hifuqing5",
}

srq_quotes["gratz"] = {
"you want a cookie or something? jk gratz",
"congratulations are the civility of envy...so congrats lol",
"jesus how many times do i have to say this in one day? gratz!",
"the virtue of deeds lies in completing them...congratulations",
"Gratz, but remember: 'There are basically two types of people. People who accomplish things, and people who claim to have accomplished things. The first group is less crowded.' - Mark Twain",
"'Don't measure yourself by what you have accomplished, but what you should have accomplished with your ability.' - John Wooden",
"grats. 'There is no happiness except in the realization that we have accomplished something.' - Henry Ford",
"It is not the mountain we conquer but ourselves. - Edmund Hillary",
"it's always the adventurous that accomplish great things",
}

srq_quotes["random"] = {
"Roses are red, violets are blue, all of my base are belong to you.",
"Every fight is a food fight when you're a cannibal.",
"Friendship is like peeing on yourself: everyone can see it, but only you get the warm feeling that it brings.",
"There are no stupid questions, just stupid people.",
"It takes 46 muscles to frown but only 4 to flip 'em the bird.",
"A hippie is someone who looks like Tarzan, walks like Jane and smells like Cheetah.",
"Outside of a dog, a book is man's best friend. Inside of a dog, it's too dark to read.",
"Drawing upon my fine command of language, I say nothing. ",
"I know that you believe you understand what you think I said, but I'm not sure you realize that what you heard is not what I meant.",
"I'm so clever that sometimes I don't understand a single word of what I'm saying.",
"Everyone has a photographic memory, some just don't have film.",
"Friends are like bras, close to your heart and there for support.",
"Just because no one complains doesn't mean all parachutes are perfect.",
"I used to think I was indecisive but now I'm not so sure.",
"Since light travels faster than sound, some people appear bright until they speak.",
"On the other hand, you have different fingers.",
"You're only young once, but you can be immature forever.",
"I started out with nothing and I still have most of it.",
"A thunderstorm is God's way of saying you spend too much time playing WoW.",
"I've never had a problem with drugs, I've only had problems with the police.",
"The problem with political jokes is that they always get elected.",
"Fighting for peace is like screwing for virginity.",
"Your girlfriend ain't mad at you, she's just jealous of your epics.",
}

srq_quotes["facepalm"] = {
"You're turning me emo.",
"Oh how the not so mighty have slipped further.",
"One day, I will be able to point at you and you will die. That's not a threat, it's religious prophecy.",
}

srq_quotes["bye"] = {
"Farewell, metaphors be with you.",
"See ya later.",
"All good things must come to an end, but all bad things can continue forever.",
"Bye %t.",
}

srq_quotes["drain"] = {
"Don't cross the streams!!",
"I suck....your soul!",
"Get over here!",
"It is better for civilization to be going down the drain than to be coming up it.",
"I put my heart and my soul into my work, and have lost my mind in the process.",
"Your own soul is nourished when you are kind; it is destroyed when you are cruel.",
"Whatever satisfies the soul is truth.",
"A soul you say? Give my pocketwatch to a savage and he'll think it has a soul!",
"The finest souls are those that have the most variety and suppleness.",
"There's nothing that cleanses your soul like getting the hell kicked out of you.",
"Defeat may serve as well as victory to shake the soul and let the glory out.",
"If you're losing your soul and you know it, then you've still got a soul left to lose.",
"To be somebody you must last.",
"To possess taste, one must have some soul. Let me have yours.",
"There's nothing that cleanses your soul like getting the hell kicked out of you.",
"Your soul will be dead even before your body; fear nothing further.",
"I put my heart and my soul into my work, and have lost my mind in the process.",
}

function srq_OnLoad()

  SlashCmdList["SRQ"] = srq_SlashCommand;
  SLASH_SRQ1="/srq";
  SLASH_SRQ2="/sayrandomquote";

end

function srq_SlashCommand(var1)

  -- Declare what we'll be using as local, so it doesn't mess
  -- with another addon's global variables

  local q, command, parameter, index

  if var1=="" then var1="random" 
  end

  -- Find the position of the parameters, if they exist. For
  -- a chat command, you will have this typical setup:
  --
  -- /trigger command parameter
  --
  -- But when the slash handler gets this information, the
  -- string passed is "command parameter" which is why
  -- we need to split it up. For this code, command
  -- will represent the quote group to use, and parameter
  -- will be the chat type to use.

  index = string.find(var1, " ");

  -- If there were parameters found, separate them from the command

  if ( index ) then

    command = string.sub(var1, 1, index-1);
    parameter = string.sub(var1, index+1);
  
  -- Otherwise, we just have a command, so set our parameter to the
  -- default chat type of "say"

  else

    command = var1;
    parameter = "SAY";

  end

  q=srq_quotes[command];

  -- When sending the chat message, make sure the parameter is uppercase

  if(q~=nil) then
    SendChatMessage(q[math.random(#q)], string.upper(parameter));
  else
    DEFAULT_CHAT_FRAME:AddMessage("That quote set doesn't exist! ("..command..")");
  end

end