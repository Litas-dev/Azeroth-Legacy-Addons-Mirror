SindyLocsDB = {}
SindyLocsDB.x, SindyLocsDB.y = UIParent:GetCenter()

local f = CreateFrame("Frame", nil, UIParent)

local function initFrame()
	f:SetWidth(256)
	f:SetHeight(128)
	f:SetBackdrop({
		bgFile = "Interface\\Buttons\\WHITE8X8",
		edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
		tile = true, tileSize = 8, edgeSize = 14,
		insets = { left = 2, right = 2, top = 2, bottom = 2 }
	})
	f:SetBackdropColor(0, 0, 0, 0)
	
	local bg = f:CreateTexture(nil, "BACKGROUND")
	bg:SetAllPoints(f)
	bg:SetTexture("Interface\\AddOns\\\PWASindyLocs\\floor")
	f.background = bg
	
	--1 star 2 circle 3 diamond 4 triangle 5 moon 6 square 7 cross 8 skull
	local raidTargets = CreateFrame("Frame", nil, f)
	raidTargets:SetWidth(180)
	raidTargets:SetHeight(85)
	--raidTargets:SetAlpha(0.7)
	raidTargets:ClearAllPoints()
	raidTargets:SetPoint("BOTTOMLEFT", f, "BOTTOMLEFT", 50, 23)
	for i=8,3,-1 do
		local rt = raidTargets:CreateTexture(nil, "OVERLAY")
		rt:SetTexture("Interface\\TargetingFrame\\UI-RaidTargetingIcon_"..i)
		rt:SetWidth(32)
		rt:SetHeight(32)
		rt:ClearAllPoints()
		if i == 8 then
			rt:SetPoint("BOTTOMLEFT", raidTargets, "BOTTOMLEFT")
		elseif i == 5 then
			rt:SetPoint("TOPLEFT", raidTargets, "TOPLEFT", 32, 0)
		else
			rt:SetPoint("LEFT", raidTargets["rt"..(i+1)], "RIGHT", 30, 0)
		end
		rt:Show()
		raidTargets["rt"..i] = rt
	end
	f.raidTargets = raidTargets
	
	local targetCircle = CreateFrame("Frame", nil, f)
	targetCircle:SetWidth(45)
	targetCircle:SetHeight(45)
	targetCircle:ClearAllPoints()
	targetCircle:SetPoint("CENTER", raidTargets.rt8, "CENTER")
	
	local tc = targetCircle:CreateTexture(nil, "OVERLAY")
	tc:SetAllPoints(targetCircle)
	tc:SetBlendMode("ADD")
	tc:SetTexture("Interface\\Minimap\\Ping\\ping4")
	
	targetCircle:Hide()
	f.targetCircle = targetCircle
	
	
	f:EnableMouse(true)
	f:SetMovable(true)
	f:SetClampedToScreen(true)
	f:RegisterForDrag("LeftButton")
	f:SetScript("OnDragStart", f.StartMoving)
	f:SetScript("OnDragStop", function(self)
		self:StopMovingOrSizing()
		SindyLocsDB.x = self:GetLeft()
		SindyLocsDB.y = self:GetTop()
	end)
	
	f:SetScript("OnHide", function()
		f.targetCircle:Hide()
	end)
	
	f:ClearAllPoints()
	f:SetPoint("TOPLEFT", UIParent, "BOTTOMLEFT", SindyLocsDB.x, SindyLocsDB.y)
	
	f:Hide()
end

local function target(index)
	if index and index > 2 then
		f.targetCircle:SetPoint("CENTER", f.raidTargets["rt"..index], "CENTER")
		f.targetCircle:Show()
	else
		f.targetCircle:Hide()
	end
end

local frostBeacon = GetSpellInfo(70126)
f:SetScript("OnEvent", function(self, event, arg1, ...)
	if event == "COMBAT_LOG_EVENT_UNFILTERED" then
	
		local d = GetInstanceDifficulty()
		if d == 1 or d == 3 then return end
		
		local eventType, _, sName, _, _, dName, _, _, spellName = ...
		if spellName == frostBeacon and eventType == "SPELL_AURA_APPLIED" and UnitIsUnit(dName, "player") then
			self:Show()
		elseif spellName == frostBeacon and eventType == "SPELL_AURA_REMOVED" and UnitIsUnit(dName, "player") then
			self:Hide()
		end
		
	elseif event == "RAID_TARGET_UPDATE" and self:IsShown() then
	
		target(GetRaidTargetIndex("player"))
	
	elseif event == "ADDON_LOADED" and arg1 == "PWASindyLocs" then
	
		self:UnregisterEvent("ADDON_LOADED")
		initFrame()
		self:RegisterEvent("COMBAT_LOG_EVENT_UNFILTERED")
		self:RegisterEvent("RAID_TARGET_UPDATE")
	
	end
end)
f:RegisterEvent("ADDON_LOADED")


SLASH_SINDYLOCS1 = "/sindylocs"
SlashCmdList["SINDYLOCS"] = function(msg)
	if f:IsShown() then
		f:Hide()
	else
		f:Show()
	end
end