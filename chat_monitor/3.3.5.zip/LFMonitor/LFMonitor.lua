﻿-- ************************
-- * Variable Declaration *
-- ************************

local alertframe, cfflag, ddmenu, clmenu, pname, pflag, itemlink = nil, nil, nil, nil, nil, nil
local mouse, buttons = false, false
local inactive, combat = false, false
local tradechannel = -1
local _G = _G
local eventframe = nil
local events = {}

-- ***********************
-- * Debug Functions *
-- ***********************

local function debug(msg)

    DEFAULT_CHAT_FRAME:AddMessage(msg, 1, 0, 0)

end

-- ***************************
-- * Miscellaneous functions *
-- ***************************
local function sendWhisper(priority, prefix, msg, type, lang, dest)

	local ch, msgchunk, segment, m
	local space = 0
	local msgs = {}

	msgchunk = msg

	if (string.len(msg) > 255) then

		while (string.len(msgchunk) > 255) do

			segment = string.sub(msgchunk, 1, 255)

			for ch = 255, 1, -1 do

				if (string.sub(segment, ch, ch) == " ") then

					space = ch
					break

				end

			end

			if (space == 0) then

				space = 255

			end

			table.insert(msgs, string.sub(segment, 1, space - 1))
			msgchunk = string.sub(msgchunk, space + 1)

		end

	end

	table.insert(msgs, msgchunk)

	for _, m in ipairs(msgs) do

		ChatThrottleLib:SendChatMessage(priority, prefix, m, type, lang, dest)

	end

end

local function resetEvent()

	if (LFMMAIN:GetScript("OnUpdate") == nil) then

		LFMMAIN:SetScript("OnUpdate", function(self, elapsed) LFMonitor:AlertOnUpdate(self, elapsed) end)

	end

end

function LFMonitor:PlayAlert(id)

	local sound = LFMonitor.sounds[id]

	if (LFMonitorDB.options.soundon == 1) then

		if (sound.type == "game") then

			PlaySound(sound.file)

		else

			PlaySoundFile("Interface\\AddOns\\LFMonitor\\Sounds\\" .. sound.file)

		end
		
	end

end

local function GetAutoReply()

	local reply, cl = nil, nil
	local flag = string.lower(pflag)

	reply = LFMonitorDB.responses[flag]

	cl = LFMonitorDB.craftlist[flag]
	
	if (LFMonitorDB.options.scl == 1) then

		--add crafting list
		if (not(cl == nil or "")) then

			reply = cl .. " " .. reply

		end
		
	end

	return reply

end

function LFMonitor:ChatCommand(input)

	local command = string.lower(input or "")

	if (command == "show") then

		LFMonitorDB.options.disabled = 0
		SetDisable(false)

	elseif (command == "hide") then

		LFMonitorDB.options.disabled = 1
		SetDisable(true)

	else

		InterfaceOptionsFrame_OpenToCategory(_G.LFMonitorOptionsMain)

	end

end

local function GetLocalTime()

	local format = LFMonitor.timestamps[LFMonitorDB.options.timestamp].format
	local localtime = date(format)

	return localtime

end

local function IsInstance()

	local inInstance, instanceType = IsInInstance()
	local ininstance = false

	if (inInstance ~= nil) then

		if (instanceType ~= "none") then

  			ininstance = true

		end

	end

  	return ininstance

end

local function alertHide()

	alertframe:Hide()

end

local function respond(self, event, ...)

	if (events[event]) then

		events[event](event, ...)

	end

end

function LFMonitor:lfmframeOnUpdate(self, elapsed)

	local flash = LFMEndFlash
	local flashtimer = LFMonitor.frame.flashtimer + elapsed

	if (alertframe:AtBottom()) then

		if (flash:IsShown()) then

			flash:Hide()

		end

		LFMonitor.frame:SetScript("OnUpdate", nil)

	elseif (flashtimer < CHAT_BUTTON_FLASH_TIME ) then

		LFMonitor.frame.flashtimer = flashtimer

	else

		LFMonitor.frame.flashtimer = 0

		if (flash:IsShown()) then

			flash:Hide()

		else

			flash:Show()

		end

	end

end

function LFMonitor:GetChannelNumber(channel)

	local channels = {GetChannelList()}
	local channelnumber = -1
	
	for num = 1, #channels, 2 do

		if (channels[num + 1] == channel) then

			channelnumber = num

		end

	end

	return channelnumber

end

local function eventframeInit(init)

	if (LFMonitor.testmode == true) then

		eventframe:RegisterEvent("CHAT_MSG_WHISPER_INFORM")
		
	else

		eventframe:RegisterEvent("CHAT_MSG_CHANNEL")
		eventframe:RegisterEvent("CHAT_MSG_SAY")
		eventframe:RegisterEvent("CHAT_MSG_YELL")

	end

	if (not inactive) then

		eventframe:RegisterEvent("PLAYER_UPDATE_RESTING")
		eventframe:RegisterEvent("PLAYER_ENTERING_WORLD")
		eventframe:RegisterEvent("PLAYER_REGEN_DISABLED")
		eventframe:RegisterEvent("PLAYER_REGEN_ENABLED")
		eventframe:RegisterEvent("ZONE_CHANGED_NEW_AREA")
		eventframe:RegisterEvent("ZONE_CHANGED")
		eventframe:RegisterEvent("CHAT_MSG_CHANNEL_NOTICE")
		eventframe:RegisterEvent("TRADE_SKILL_SHOW")

	end

	inactive = false
	eventframe:SetScript("OnEvent", respond)

	if (init) then

		tradechannel = LFMonitor:GetChannelNumber("Trade")
		LFMonitor:DisableCheck()

	end

	alertframe:Clear()

end

local function SetDisable(disable)

	if (disable == true) then

		if (alertframe:IsVisible()) then

			LFMonitor:OnDisable()
			inactive = true

		end

	else

		if (not alertframe:IsVisible()) then

			UIFrameFadeIn(alertframe, 1)
			resetEvent()
			eventframeInit()
			inactive = false

		end

	end

end

function LFMonitor:DisableCheck()

	local disable = false

	tradechannel = LFMonitor:GetChannelNumber("Trade")

	if (LFMonitorDB.options.hinst == 1) then

		if (IsInstance() == 1) then

			disable = true

		end

	end

	if (LFMonitorDB.options.rested == 1) then

		if (not IsResting()) then

			disable = true

		end

	end

	if (LFMonitorDB.options.trade == 1) then

		if (tradechannel == -1) then

			disable = true

		end

	end

	SetDisable(disable)

end

function LFMonitor:IsInBounds()

	local scale = UIParent:GetEffectiveScale()
	local x, y = GetCursorPosition()
	local xmin = LFMonitorDB.alert.position.x
	local xmax = xmin + LFMonitorDB.alert.position.width
	local ymax = LFMonitorDB.alert.position.y
	local ymin = ymax - LFMonitorDB.alert.position.height
	local inbounds = nil
	
	x = x / scale
	y = y / scale
	
	if ((x >= xmin) and (x <= xmax) and (y >= ymin) and (y <= ymax)) then

		inbounds = true

	end

	return inbounds

end

-- *************************
-- * Alert Frame Functions *
-- *************************

function LFMonitor:AlertShowButtons()

	UIFrameFadeIn(ScrollAlertFrameUpBtn, 0.5, 0, 1)
	UIFrameFadeIn(ScrollAlertFrameDownBtn, 0.5, 0, 1)
	UIFrameFadeIn(ScrollAlertFrameEndBtn, 0.5, 0, 1)

end

function LFMonitor:AlertHideButtons()
	
	ScrollAlertFrameUpBtn:Hide()
	ScrollAlertFrameDownBtn:Hide()
	ScrollAlertFrameEndBtn:Hide()
	
end

local function checkHistory(msg, sender)

--ignore duplicate messages sent within 20 seconds of each other
--to try and cut down on channel spam

	local i, v
	local valid = 1

	if (#LFMonitor.history > 0) then

		for i,v in pairs(LFMonitor.history) do

			if ((v.msender == sender) and (v.mmsg == msg)) then

				if (GetTime() - v.mtime < 20) then

					valid = nil

				end

			end

		end

	end

	if (valid) then

		if (LFMonitor.hindex == 10) then

			LFMonitor.hindex = 1

		end

		table.insert(LFMonitor.history, LFMonitor.hindex, {msender = sender, mmsg = msg, mtime = GetTime()})
		LFMonitor.hindex = LFMonitor.hindex + 1

	end

	return valid

end

local function addAlert(msg, sender, guid)

	local hlink
	local plink = "[" .. sender .. "]:|h|r "
	local tlink = "|c" .. LFMonitorDB.alert.font.timestamp .. GetLocalTime() .. "|r "
	local mcol = "|c" .. LFMonitorDB.alert.font.text
	local pcol

	if guid == -99999 then
	
		return
		
	end
	
	if (LFMonitorDB.options.useclasscolours == 1) then

		pcol = LFMonitor:GetClassColour(guid)

	else

		pcol = LFMonitorDB.alert.font.player

	end

	hlink = "|c" .. pcol .. "|Hplayer:" .. sender .. ":LFMONITOR:" .. cfflag .. "|h"	
	
	if (checkHistory(msg, sender)) then

		LFMonitor:PlayAlert(LFMonitorDB.options.sound)

		if (alertframe:GetAlpha() ~= 1) then

			LFMonitor:AlertFadeIn(0.1)

		end

		alertframe.TimeSinceLastUpdate = 0
		alertframe:AddMessage(tlink .. hlink .. plink .. mcol .. msg .. "|r", 1, 1, 1, 1, 60.0)

	end

end

function LFMonitor:SetLocked(locked)

	alertframe.isLocked = locked
	LFMonitorDB.options.locked = locked

end

function LFMonitor:AlertFadeIn(ftime)

	if (not mouse) then

		if (alertframe:GetAlpha() ~= 1) then

			UIFrameFadeIn(alertframe, ftime, 0.3, 1)
			resetEvent()

		end

	end

end

function LFMonitor:AlertFadeOut(ftime)

	if (alertframe:GetAlpha() == 1) then

		UIFrameFadeOut(alertframe, ftime, 1, 0.3)

	end

end

function LFMonitor:SetMouse(bValue)

	mouse = bValue

end

function LFMonitor:SetAlertFont()

	local r, g, b, a = LFMonitor:HexToRGB(LFMonitorDB.alert.font.text)
	local fontfile = LFMonitor.fonts[LFMonitorDB.alert.font.index].file

	alertframe:SetFont(fontfile, LFMonitorDB.alert.font.height)	

end

function LFMonitor:SetAlertBackdropColour()

	local r, g, b, a = LFMonitor:HexToRGB(LFMonitorDB.alert.backdrop.background)

	alertframe:SetBackdropColor(r, g, b, a)

end

function LFMonitor:SetAlertBorderColour()

	local r, g, b, a = LFMonitor:HexToRGB(LFMonitorDB.alert.backdrop.border)

	alertframe:SetBackdropBorderColor(r, g, b, a)

end

-- *****************
-- * Filter Engine *
-- *****************

local function doSearch(profTxt, msgTxt, typeTxt, sender, guid)

	local lmsg = string.lower(msgTxt)
	local pattern, message, pattern2 = nil, nil, nil
	local matched = false
	local match2

	pattern = ".*(www%.).*"
	message = string.match(lmsg, pattern)

	if (message ~= nil) then

		--found probable spam, so ignore
		return false

	end

	for _, stxt in ipairs(profTxt) do

		for _, ttxt in ipairs(typeTxt) do

			pattern = "^" .. ttxt .. "(%s+.*" ..  stxt .. "%p*%s*.*)"
			pattern2 = ".*%s+" .. ttxt .. "(%s+.*" .. stxt .. "%p*%s*.*)"

			if ((typeTxt[1] == LFMonitor.lfwtxt[1]) or (cfflag == "CUSTOM")) then

				pattern2 = ttxt

			end

			message = string.match(lmsg, pattern)

			if (message == nil) then

				message = string.match(lmsg, pattern2)

			end

			--make sure we've not matched only part of a word
			if (message ~= nil) then

				if (stxt == "") then

					stxt = ".*"

				end

				pattern = "^.*%s+" .. stxt .. "%p*%s.*"
				pattern2 = "^.*%s+" .. stxt .. "%p*$"

				if ((typeTxt[1] == LFMonitor.lfwtxt[1]) or (cfflag == "CUSTOM")) then

					pattern = ttxt

				end

				match2 = string.match(message, pattern)

				if (match2 == nil) then

					match2 =string.match(message, pattern2)

				end

				if (match2 ~= nil) then

					addAlert(msgTxt, sender, guid)
					matched = true
					break

				end

			end

		end

		if (matched) then

			break

		end

	end

	return matched

end

-- *******************
-- * Event Functions *
-- *******************

function LFMonitor:OnInitialise()

	local x, y
	local slashcmd, slashidx = "LFMONITOR_CMD", 1

	SLASH_LFMONITOR_CMD1 = "/" .. LFMonitor.CHAT_COMMANDS[1]
	SLASH_LFMONITOR_CMD2 = "/" .. LFMonitor.CHAT_COMMANDS[2]
	SlashCmdList["LFMONITOR_CMD"] = function(input) LFMonitor:ChatCommand(input) end

	LFMDBSVARS = LFMonitorDB

	if (IsAddOnLoaded("TradeForwarder")) then

		LFMonitor.tfw = true

	else

		LFMonitor.tfw = nil

	end

end

function LFMonitor:OnDisable()

	local r, g, b, a = LFMMAIN:GetBackdropColor()

	if (LFMonitor.testmode == true) then

		eventframe:UnregisterEvent("CHAT_MSG_WHISPER_INFORM")
		
	else

		eventframe:UnregisterEvent("CHAT_MSG_CHANNEL")
		eventframe:UnregisterEvent("CHAT_MSG_SAY")
		eventframe:UnregisterEvent("CHAT_MSG_YELL")

	end

	LFMonitor.frame:SetScript("OnUpdate", nil)
	LFMMAIN:SetScript("OnUpdate", nil)

	UIFrameFadeOut(alertframe, 1, a, 0)
	alertframe.fadeInfo.finishedFunc = alertHide
	inactive = true

end

function events.PLAYER_REGEN_DISABLED()

	--player entering combat
	if (LFMonitorDB.options.combat == 1) then

		if (alertframe:IsVisible()) then

			dis = true
			combat = true
			UIFrameFadeOut(alertframe, 1)
			alertframe.fadeInfo.finishedFunc = alertHide

		end

	end

end

function events.PLAYER_REGEN_ENABLED()

	--player leaving combat
	if (combat) then

		UIFrameFadeIn(alertframe, 1)
		resetEvent()
		combat = false

	end

end

function events.PLAYER_UPDATE_RESTING(event, ...)

	tradechannel = LFMonitor:GetChannelNumber("Trade")
	LFMonitor:DisableCheck()

end

function events.ZONE_CHANGED_NEW_AREA(event, ...)

	tradechannel = LFMonitor:GetChannelNumber("Trade")
	LFMonitor:DisableCheck()

end

function events.ZONE_CHANGED(event, ...)

	tradechannel = LFMonitor:GetChannelNumber("Trade")
	LFMonitor:DisableCheck()

end

function events.PLAYER_ENTERING_WORLD(event, ...)

	tradechannel = LFMonitor:GetChannelNumber("Trade")
	LFMonitor:DisableCheck()

end

function LFMonitor:AlertOnUpdate(self, elapsed)

	self.TimeSinceLastUpdate = self.TimeSinceLastUpdate + elapsed

	if (self.TimeSinceLastUpdate < LFMonitor.LFM_Update_Int) then

		return

	end

	if (alertframe:IsVisible()) then

		if (alertframe:GetAlpha() == 1) then 

			if (mouse == false) then

				self.TimeSinceLastUpdate = 0
				LFMonitor:AlertHideButtons()
		    		LFMonitor:AlertFadeOut(2)
				LFMMAIN:SetScript("OnUpdate", nil)
				mouse = false

		  	end

		end

	end

end

function LFMonitor:OnHyperlinkShow(self, link, text, button)

	SetItemRef(link, text, button)

end

local function ChatParser(event, chatmessage, sender, language, channelstring, target, flags, zoneid, channelnumber, channelname, _, counter, guid, ...)

	local message = nil
	local pattern, lmsg = nil, nil
	local omsg, classtxt = nil, nil
	local lfmclasses = {"dk", "dr", "hu", "ma", "pa", "pr", "ro", "sh", "wa", "wr"}
	local profs = {"jc", "enc", "lw", "ins", "tlr", "bs", "alc", "eng", "misc"}
	local misc = {"lfg", "wtb", "lf", "wts", "lfw"}
	local matched, lfmgen = false, true
	local channelmatch = false
	local tmp = {}
	local i, channels = {}
	local tfwidx, tfwname, tfwmsg, tfwcolour
	local lfmsender

	lfmsender = sender

	if (LFMonitorDB.channels.general == 1) then

		if ((zoneid == 1) or (event == "CHAT_MSG_SAY") or (event == "CHAT_MSG_YELL")) then

			channelmatch = true
	
		end
	
	end

	if (LFMonitorDB.channels.trade == 1) then

		if (zoneid == 2) then

			channelmatch = true

		end
		
	end

	if (LFMonitorDB.channels.guild == 1) then

		if (event == "CHAT_MSG_GUILD") then

			channelmatch = true
		
		end

	end

	if (LFMonitorDB.channels.lfg == 1) then

		if (zoneid == 26) then

			channelmatch = true

		end

	end

	if (channelmatch == false) then

		channels = {GetChannelList()}

		for i = 1, #channels, 2 do

			if (channels[i] > 4) then

				if (LFMonitorDB.channels["cc" .. channels[i + 1]] == 1) then

					if (channelnumber == channels[i]) then

						channelmatch = true

					end

				end
			end

		end

	end

	if (LFMMAIN:IsVisible()) then

		if ((channelmatch == true) or (LFMonitor.testmode == true)) then

			omsg = chatmessage
			
			if (LFMonitor.tfw) then

				tfwidx, tfwname, tfwmsg, tfwcolor = strmatch(chatmessage, LFMonitor.TFW_PATTERN)

				if (tfwmsg) then

					omsg = tfwmsg
					lfmsender = tfwname

				end

			end

			if (table.getn(LFMonitor.proflist) ~= 0) then

				cfflag = "PROF"
				matched = doSearch(LFMonitor.proflist, omsg, LFMonitor.lftxt, lfmsender, guid)

			end

			if (not matched) then

				if (LFMonitorDB.monitoring.lfm == 1) then

					cfflag = "LFM"

					if (table.getn(LFMonitor.raidlist) ~=0) then
					
						matched = doSearch(LFMonitor.raidlist, omsg, LFMonitor.lfmtxt, lfmsender, -99999)
						
					end
					
					if (table.getn(LFMonitor.classlist) ~=0) then

						if ((not matched) and (table.getn(LFMonitor.raidlist) ~=0)) then
						
							if (LFMonitorDB.options.overrideraid == 1) then
							
								matched = doSearch(LFMonitor.classlist, omsg, LFMonitor.lfmtxt, lfmsender, guid)
								
							end
							
						else
	
							matched = doSearch(LFMonitor.classlist, omsg, LFMonitor.lfmtxt, lfmsender, guid)
	
						end

					else
					
						if matched then
						
							addAlert(omsg, lfmsender, guid)
							
						end
						
					end

					if ((not matched) and (table.getn(LFMonitor.classlist) == 0)) then

						if (lfmgen) then

							matched = doSearch(LFMonitor.nop, omsg, LFMonitor.lfmtxt, lfmsender, guid)
							
						end

					end

				end

	        	end

			if (not matched) then

				for j, other in ipairs(misc) do

					if (LFMonitorDB.monitoring[other] == 1) then

						cfflag = string.upper(other)

						if (not matched) then

							matched = doSearch(LFMonitor.nop, omsg, LFMonitor[other .. "txt"], lfmsender, guid)

						end

					end

				end

			end

			if (not matched) then

				if ((LFMonitorDB.options.basic or "") ~= "") then

					cfflag = "CUSTOM"
					tmp = {}
					
					if (string.find(LFMonitorDB.options.basicesc, " ")) then
					
						tmp = {strsplit(" ", string.lower(LFMonitorDB.options.basicesc))}
						
					else
					
						table.insert(tmp, string.lower(LFMonitorDB.options.basicesc))
						
					end
					
					matched = doSearch(LFMonitor.nop, omsg, tmp, lfmsender, guid)

				end

			end

			if (not matched) then

				if ((LFMonitorDB.options.adv or "") ~= "") then

					cfflag = "CUSTOM"
					tmp = {}
					table.insert(tmp, LFMonitorDB.options.adv)
					matched = doSearch(LFMonitor.nop, omsg, tmp, lfmsender, guid)

				end

			end

		end

	end

end

function events.CHAT_MSG_CHANNEL(event, chatmessage, sender, language, channelstring, target, flags, zoneid, channelnumber, channelname, counter, ...)

	ChatParser(event, chatmessage, sender, language, channelstring, target, flags, zoneid, channelnumber, channelname, counter, ...)

end

function events.CHAT_MSG_WHISPER_INFORM(event, chatmessage, sender, language, channelstring, target, flags, zoneid, channelnumber, channelname, counter, ...)

	ChatParser(event, chatmessage, sender, language, channelstring, target, flags, zoneid, channelnumber, channelname, counter, ...)

end

function events.CHAT_MSG_YELL(event, chatmessage, sender, language, channelstring, target, flags, zoneid, channelnumber, channelname, counter, ...)

	ChatParser(event, chatmessage, sender, language, channelstring, target, flags, zoneid, channelnumber, channelname, counter, ...)

end

function events.CHAT_MSG_SAY(event, chatmessage, sender, language, channelstring, target, flags, zoneid, channelnumber, channelname, counter, ...)

	ChatParser(event, chatmessage, sender, language, channelstring, target, flags, zoneid, channelnumber, channelname, counter, ...)

end

function events.CHAT_MSG_CHANNEL_NOTICE(event, chatmessage, sender, language, channelstring, target, flags, zoneid, channelnumber, channelname, counter, ...)

	tradechannel = LFMonitor:GetChannelNumber("Trade")
	LFMonitor:DisableCheck()

end


function events.TRADE_SKILL_SHOW()

	local frameTitle = TradeSkillFrameTitleText:GetText()
	local skilllist = GetTradeSkillListLink()
	local skills = {
		{skill = LFMonitor.ALCHEMY, db = "alc"},
		{skill = LFMonitor.BLACKSMITHING, db = "bs"},
		{skill = LFMonitor.ENCHANTING, db = "enc"},
		{skill = LFMonitor.ENGINEERING, db = "eng"},
		{skill = LFMonitor.INSCRIPTION, db = "ins"},
		{skill = LFMonitor.JEWELCRAFTING, db = "jc"},
		{skill = LFMonitor.LEATHERWORKING, db = "lw"},
		{skill = LFMonitor.TAILORING, db = "tlr"}}
	
	for id, tradeskill in ipairs(skills) do

		if strfind(frameTitle, tradeskill.skill) then

			LFMonitorDB.craftlist[tradeskill.db] = skilllist

		end

	end	

end

function LFMonitor:OnEnable()

	LFMonitor:CreateOptions()

	if (LFMonitorDB.alert.position.x == -1) then

		x = (UIParent:GetWidth() - LFMonitorDB.alert.position.width) / 2
		y = (UIParent:GetHeight() - LFMonitorDB.alert.position.height) / 2
		LFMonitorDB.alert.position.x = x
		LFMonitorDB.alert.position.y = y

	end

	alertframe = LFMonitor:CreateAlertFrame()

	eventframe = CreateFrame("Frame", "LFMonitorEventFrame")
	eventframeInit(true)
	LFMonitor:BuildTables()
	tradechannel = LFMonitor:GetChannelNumber("Trade")
	LFMonitor:DisableCheck()

	if (IsAddOnLoaded("TradeForwarder")) then

		LFMonitor.tfw = 1

	else

		LFMonitor.tfw = nil

	end

end

-- ******************
-- * Dropdown Menus *
-- ******************

local function LFMonitor_DDMenuItem_OnClick(self, button, down)

	local opt = self.value
	local reply, rtmp = nil, nil
	local cl = nil

	PlaySound("igMainMenuOption")

	if (opt == 1) then

		--autoreply
		reply = GetAutoReply()

		if (reply == nil or reply == "") then

			--nothing to autoreply with
			StaticPopup_Show("LFMONITOR_NOAUTOREPLY")

		else

			rtmp = string.sub(reply, 1, 255)

			sendWhisper("NORMAL", "LFMONITOR", reply, "WHISPER", nil, pname)

		end

	elseif(opt == 2) then

		--whisper
		ChatFrameEditBox:SetText(LFMonitor.WHISPER_COMMAND .. " " .. pname .. " ")

	elseif(opt == 3) then

		--ignore
		AddIgnore(pname)

	elseif(opt == 4) then

		--cancel
		--do nothing

	end

end

local function LFMonitor_DD_Initialise()

	local info

	info = {}
	info.text = pname
	info.value = 0
	info.owner = ddmenu
	info.isTitle = true
	info.func = nil
	UIDropDownMenu_AddButton(info)

	info = {}
	info.text = LFMonitor.AUTOREPLY
	info.value = 1
	info.owner = ddmenu
	info.isTitle = nil

	if (pflag == "LFG" or pflag == "WTB") then

		info.disabled = true

	else

		info.disabled = nil

	end

	info.tooltipTitle = LFMonitor.AUTOREPLY
	info.tooltipText = string.format(LFMonitor.SEND_AUTO, pname)
	info.func = LFMonitor_DDMenuItem_OnClick
	UIDropDownMenu_AddButton(info, 1)

	info = {}
	info.text = _G.WHISPER
	info.value = 2
	info.owner = ddmenu
	info.isTitle = nil
	info.disabled = nil
	info.tooltipTitle = _G.WHISPER
	info.tooltipText = string.format(LFMonitor.WHISPER, pname)
	info.func = LFMonitor_DDMenuItem_OnClick
	UIDropDownMenu_AddButton(info, 1)

	info = {}
	info.text = _G.IGNORE
	info.value = 3
	info.owner = ddmenu
	info.isTitle = nil
	info.disabled = nil
	info.tooltipTitle = _G.IGNORE
	info.tooltipText = string.format(LFMonitor.IGNORE_LIST, pname)
	info.func = LFMonitor_DDMenuItem_OnClick
	UIDropDownMenu_AddButton(info, 1)

	info = {}
	info.text = _G.CANCEL
	info.value = 4
	info.owner = ddmenu
	info.isTitle = nil
	info.disabled = nil
	info.tooltipTitle = _G.CANCEL
	info.tooltipText = LFMonitor.CLOSE_MENU
	info.func = LFMonitor_DDMenuItem_OnClick
	UIDropDownMenu_AddButton(info, 1)

end

local function LFMonitor_ShowDDMenu(link)

	local htype, hname, hmod, flag = strsplit(":", link)

	pname = hname
	pflag = flag

	ddmenu = _G.LFMonitorDDMenu
	ddmenu.initialize = LFMonitor_DD_Initialise
	ddmenu.displayMode = "MENU"
	ddmenu.name = "LFMonitor"
	PlaySound("igMainMenuOpen")
	ToggleDropDownMenu(1, nil, ddmenu, "cursor")

end

-- *********
-- * Hooks *
-- *********

--Hook SetItemRef so LFMonitor can handle its own custom links
local ORIG_SetItemRef = _G.SetItemRef

local function LFMonitor_SetItemRef (link, text, button, ...)

	local htype, hname, hmod, flag = strsplit(":", link)
	local runorig = nil

	if (IsModifiedClick("CHATLINK")) then

		runorig = true

	elseif (button == "RightButton") then

		if (hmod == "LFMONITOR") then

			LFMonitor_ShowDDMenu(link)

		else

			runorig = true

		end

	else

		runorig = true

	end

	if (runorig) then

		ORIG_SetItemRef(link, text, button, ...)

	end

end

_G.SetItemRef = LFMonitor_SetItemRef

--[[local editbox = ChatFrameEditBox

--if not editbox then

    -- Support for 3.3.5 and newer
    --editbox = ChatEdit_GetActiveWindow()
	--editbox = ChatFrame1EditBox
	
--end 

--if editbox then

	hooksecurefunc(ChatFrame1EditBox, "Insert", 
		function(self, text)	
	
			if(LFMonitor.LFGEditFocus == true) then

				LFMonitor.lfgedit:Insert(text)

			end

		end)

	ChatFrame1EditBox.LFMonitorIsVisible = ChatFrame1EditBox.IsVisible

	ChatFrame1EditBox.IsVisible = function(self)

		if(LFMonitor.LFGEditFocus == true) then

			return true

		else

			return ChatFrame1EditBox:LFMonitorIsVisible()

		end

	end

	ChatFrame1EditBox.LFMonitorIsShown = ChatFrame1EditBox.IsShown

	ChatFrame1EditBox.IsShown = function(self)

		if(LFMonitor.LFGEditFocus == true) then

			return true

		else

			return ChatFrame1EditBox:LFMonitorIsShown()

		end

	end
	
--end
]]