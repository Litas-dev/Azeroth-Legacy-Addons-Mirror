﻿--Create the LFMonitor package and event handler
LFMonitor = {}

local function LFMonEvent(self, event, arg1)

	if ((event == "ADDON_LOADED") and arg1 == "LFMonitor") then

		LFMonitor:OnInitialise()

	elseif (event == "PLAYER_LOGIN") then

		LFMonitor:OnEnable()

	end

end

LFMonitor.frame = CreateFrame("Frame")
LFMonitor.frame:RegisterEvent("ADDON_LOADED")
LFMonitor.frame:RegisterEvent("PLAYER_LOGIN")
LFMonitor.frame:SetScript("OnEvent", LFMonEvent)
LFMonitor.frame.flashtimer = 0
LFMonitor.TimeSinceLastUpdate = 0