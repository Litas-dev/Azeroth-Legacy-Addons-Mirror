﻿-- *****************
-- * Options Panel *
-- *****************
local _G = _G

local function OptionColour(frame, entity)

	local r, g, b = ColorPickerFrame:GetColorRGB()	
	local ir, ig, ib, ia

	if ((entity == "timestamp") or (entity == "player") or (entity == "text")) then
	
		ir, ig, ib, ia = LFMonitor:HexToRGB(LFMonitorDB.alert.font[entity])
		LFMonitorDB.alert.font[entity] = LFMonitor:RGBToHex(r, g, b, ia)

	else

		ir, ig, ib, ia = LFMonitor:HexToRGB(LFMonitorDB.alert.backdrop[entity])
		LFMonitorDB.alert.backdrop[entity] = LFMonitor:RGBToHex(r, g, b, ia)

		if (entity == "background") then

			LFMonitor:SetAlertBackdropColour()

		else

			LFMonitor:SetAlertBorderColour()

		end

	end

	frame:SetTexture(r, g, b, 1)

end

local function OptionOpacity(frame, entity)

	local a = 1 - OpacitySliderFrame:GetValue()	
	local ir, ig, ib, ia

	if ((entity == "timestamp") or (entity == "player") or (entity == "text")) then

		ir, ig, ib, ia = LFMonitor:HexToRGB(LFMonitorDB.alert.font[entity])
		LFMonitorDB.alert.font[entity] = LFMonitor:RGBToHex(ir, ig, ib, a)

	else

		ir, ig, ib, ia = LFMonitor:HexToRGB(LFMonitorDB.alert.backdrop[entity])
		LFMonitorDB.alert.backdrop[entity] = LFMonitor:RGBToHex(ir, ig, ib, a)

		if (entity == "background") then

			LFMonitor:SetAlertBackdropColour()

		else

			LFMonitor:SetAlertBorderColour()

		end

	end

end

local function OptionCancel(frame, entity)

	local r, g, b, a = unpack(ColorPickerFrame.previousValues)	

	if ((entity == "timestamp") or (entity == "player") or (entity == "text")) then

		LFMonitorDB.alert.font[entity] = LFMonitor:RGBToHex(r, g, b, a)

	else
		
		LFMonitorDB.alert.backdrop[entity] = LFMonitor:RGBToHex(r, g, b, a)

		if (entity == "background") then

			LFMonitor:SetAlertBackdropColour()

		else

			LFMonitor:SetAlertBorderColour()

		end

	end

	frame:SetTexture(r, g, b, 1)

end

function LFMonitor:ResponseOptionsOkay()

	if(_G.LFMonitorOptionsRespond:IsVisible())then

		LFMonitorDB.responses.alc = _G.LFMonitorAlcEdit:GetText()
		LFMonitorDB.responses.bs = _G.LFMonitorBsEdit:GetText()
		LFMonitorDB.responses.enc = _G.LFMonitorEncEdit:GetText()
		LFMonitorDB.responses.eng = _G.LFMonitorEngEdit:GetText()
		LFMonitorDB.responses.ins = _G.LFMonitorInsEdit:GetText()
		LFMonitorDB.responses.jc = _G.LFMonitorJcEdit:GetText()
		LFMonitorDB.responses.lw = _G.LFMonitorLwEdit:GetText()
		LFMonitorDB.responses.tlr = _G.LFMonitorTlrEdit:GetText()
		LFMonitorDB.responses.lfm = _G.LFMonitorLFGEdit:GetText()

	end

	LFMonitor:BuildTables()

end

function LFMonitor:ResponseOptionsDefault()

	_G.ScrollAlertFrame:Clear()
	LFMonitorDB = LFMonitor:deepcopy(LFMonitor.defaults)
	LFMonitor:ChatCommand(nil)
	LFMonitor:SetAlertFont()
	LFMonitor:SetAlertBackdropColour()
	LFMonitor:SetAlertBorderColour()
	LFMonitor:BuildTables()

end

function LFMonitor:CustomOptionsOkay()

	local bas = _G.LFMonitorBasicEdit:GetText() or ""
	local adv = _G.LFMonitorAdvEdit:GetText() or ""

	if(_G.LFMonitorOptionsCustom:IsVisible())then

		LFMonitorDB.options.basic = bas

		if (bas ~= "") then

			-- make sure magic characters are escaped to preserve literal values
			-- ^$().[]*+-?%
			bas = string.gsub(bas, "[%^%$%(%)%.%[%]%*%+%-%?%%]", "%%%1")

			--strip multiple spaces
			bas = string.gsub(bas, "%s+", " ")
			
		end

		LFMonitorDB.options.basicesc = bas
		LFMonitorDB.options.adv = adv

	end

end

local function SetSelectColour(frame, entity)

	local r, g, b, a

	if ((entity == "background") or (entity == "border")) then

		r, g, b, a = LFMonitor:HexToRGB(LFMonitorDB.alert.backdrop[entity])

	else

		r, g, b, a =  LFMonitor:HexToRGB(LFMonitorDB.alert.font[entity])

	end

	frame:SetTexture(r, g, b, 1)

end

function LFMonitor:FontSliderOnValueChanged(self)

	local slider = self:GetName()

	LFMonitorDB.alert.font.height = self:GetValue()
	LFMonitor:SetAlertFont()
	getglobal(slider .. "Text"):SetText(LFMonitorDB.alert.font.height)

end

local function OptAppClick(frame, entity)

	local r, g, b, a, o
	local ir, ig, ib, ia

	if ((entity == "background") or (entity == "border")) then

		r, g, b, a = LFMonitor:HexToRGB(LFMonitorDB.alert.backdrop[entity])
		o = true
		
	else

		r, g, b, a =  LFMonitor:HexToRGB(LFMonitorDB.alert.font[entity])
		o = false
		
	end

	ColorPickerFrame.func = function() OptionColour(frame, entity) end
	ColorPickerFrame.opacityFunc = function() OptionOpacity(frame, entity) end
	ColorPickerFrame.cancelFunc = function() OptionCancel(frame, entity) end
	ColorPickerFrame:SetColorRGB(r, g, b)
	ColorPickerFrame.hasOpacity = o
	ColorPickerFrame.opacity = 1 - a
	ColorPickerFrame.previousValues = {r, g, b, a}	
	ShowUIPanel(ColorPickerFrame)

end

local function LFMonitor_Sound_DD_OnClick(self, button, down)

	local opt = self.value

	LFMonitor:PlayAlert(opt)
	LFMonitorDB.options.sound = opt
	LFMonitorSoundSelectText:SetText(LFMonitor.sounds[opt].name)

end

local function LFMonitor_Sound_DD_Initialise()

	local info

	for sound = 1, #LFMonitor.sounds do
		
		info = {}
		info.text = LFMonitor.sounds[sound].name
		info.value = sound
		info.func = LFMonitor_Sound_DD_OnClick
		UIDropDownMenu_AddButton(info)

	end

end

local function LFMonitor_Font_DD_OnClick(self, button, down)

	local opt = self.value
	
	LFMonitorDB.alert.font.index = opt	
	LFMonitor:SetAlertFont()
	LFMonitorFontSelectText:SetText(LFMonitor.fonts[opt].name)

end

local function LFMonitor_Font_DD_Initialise()

	local info

	for font = 1, #LFMonitor.fonts do
		
		info = {}
		info.text = LFMonitor.fonts[font].name
		info.value = font
		info.func = LFMonitor_Font_DD_OnClick
		UIDropDownMenu_AddButton(info)

	end

end

local function LFMonitor_TS_DD_OnClick(self, button, down)

	local opt = self.value
	
	LFMonitorDB.options.timestamp = opt	
	LFMonitorTSSelectText:SetText(LFMonitor.timestamps[opt].name)

end

local function LFMonitor_TS_DD_Initialise()

	local info

	for timestamp = 1, #LFMonitor.timestamps do
		
		info = {}
		info.text = LFMonitor.timestamps[timestamp].name
		info.value = timestamp
		info.func = LFMonitor_TS_DD_OnClick
		UIDropDownMenu_AddButton(info)

	end

end

local function CreateMainPanel()

	local frame = CreateFrame("Frame", "LFMonitorOptionsMain")
	local title = frame:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge")
	local version = frame:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge")
	local author = frame:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge")

	title:SetText("LFMonitor")
	title:SetPoint("CENTER", frame, "CENTER", 0, 170)	

	version:SetText(_G.GAME_VERSION_LABEL .. " " .. GetAddOnMetadata("LFMonitor", "Version"))
	version:SetPoint("CENTER", frame, "CENTER", 0, 140)

	author:SetText("Author: Deepac")
	author:SetPoint("CENTER", frame, "CENTER", 0, 110)

	return frame

end

local function CreateProfessionPanel()

	local frame = CreateFrame("Frame", "LFMonitorOptionsProfession")
	local alccheck = CreateFrame("CheckButton", nil, frame, "OptionsCheckButtonTemplate")
	local bscheck = CreateFrame("CheckButton", nil, frame, "OptionsCheckButtonTemplate")
	local enccheck = CreateFrame("CheckButton", nil, frame, "OptionsCheckButtonTemplate")
	local engcheck = CreateFrame("CheckButton", nil, frame, "OptionsCheckButtonTemplate")
	local inscheck = CreateFrame("CheckButton", nil, frame, "OptionsCheckButtonTemplate")
	local jccheck = CreateFrame("CheckButton", nil, frame, "OptionsCheckButtonTemplate")
	local lwcheck = CreateFrame("CheckButton", nil, frame, "OptionsCheckButtonTemplate")
	local tlrcheck = CreateFrame("CheckButton", nil, frame, "OptionsCheckButtonTemplate")
	local misccheck = CreateFrame("CheckButton", nil, frame, "OptionsCheckButtonTemplate")
	local lfcheck = CreateFrame("CheckButton", nil, frame, "OptionsCheckButtonTemplate")
	local wtbcheck = CreateFrame("CheckButton", nil, frame, "OptionsCheckButtonTemplate")
	local title = frame:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge")
	local alctext = alccheck:CreateFontString(nil, "ARTWORK", "GameFontNormal")
	local bstext = bscheck:CreateFontString(nil, "ARTWORK", "GameFontNormal")
	local enctext = enccheck:CreateFontString(nil, "ARTWORK", "GameFontNormal")
	local engtext = engcheck:CreateFontString(nil, "ARTWORK", "GameFontNormal")
	local instext = inscheck:CreateFontString(nil, "ARTWORK", "GameFontNormal")
	local jctext = jccheck:CreateFontString(nil, "ARTWORK", "GameFontNormal")
	local lwtext = lwcheck:CreateFontString(nil, "ARTWORK", "GameFontNormal")
	local tlrtext = tlrcheck:CreateFontString(nil, "ARTWORK", "GameFontNormal")
	local misctext = misccheck:CreateFontString(nil, "ARTWORK", "GameFontNormal")
	local lftext = lfcheck:CreateFontString(nil, "ARTWORK", "GameFontNormal")
	local wtbtext = wtbcheck:CreateFontString(nil, "ARTWORK", "GameFontNormal")
	local wtscheck = CreateFrame("CheckButton", nil, frame, "OptionsCheckButtonTemplate")
	local wtstext = wtscheck:CreateFontString(nil, "ARTWORK", "GameFontNormal")
	local lfwcheck = CreateFrame("CheckButton", nil, frame, "OptionsCheckButtonTemplate")
	local lfwtext = wtscheck:CreateFontString(nil, "ARTWORK", "GameFontNormal")

	local function ProfessionOnShow()

		alccheck:SetChecked(LFMonitorDB.professions.alc)
		bscheck:SetChecked(LFMonitorDB.professions.bs)
		enccheck:SetChecked(LFMonitorDB.professions.enc)
		engcheck:SetChecked(LFMonitorDB.professions.eng)
		inscheck:SetChecked(LFMonitorDB.professions.ins)
		jccheck:SetChecked(LFMonitorDB.professions.jc)
		lwcheck:SetChecked(LFMonitorDB.professions.lw)
		tlrcheck:SetChecked(LFMonitorDB.professions.tlr)
		misccheck:SetChecked(LFMonitorDB.monitoring.misc)
		lfcheck:SetChecked(LFMonitorDB.monitoring.lf)
		wtbcheck:SetChecked(LFMonitorDB.monitoring.wtb)
		wtscheck:SetChecked(LFMonitorDB.monitoring.wts)
		lfwcheck:SetChecked(LFMonitorDB.monitoring.lfw)

	end

	frame:SetScript("OnShow", ProfessionOnShow)

	title:SetWidth(400)
	title:SetJustifyH("CENTER")
	title:SetText(LFMonitor.SET_LOOKING_FOR)
	title:SetPoint("TOPLEFT", frame, "TOPLEFT", 5, -20)

	alccheck:SetPoint("LEFT", title, "TOPLEFT", 15, -40)
	alccheck:SetScript("OnClick", function() LFMonitorDB.professions.alc = alccheck:GetChecked() end)
	alctext:SetText(LFMonitor.ALCHEMY)
	alctext:SetPoint("LEFT", alccheck, "RIGHT")
	alctext:SetTextColor(1, 1, 1, 1)

	bscheck:SetPoint("LEFT", alccheck, "TOPLEFT", 0, -40)
	bscheck:SetScript("OnClick", function() LFMonitorDB.professions.bs = bscheck:GetChecked() end)
	bstext:SetText(LFMonitor.BLACKSMITHING)
	bstext:SetPoint("LEFT", bscheck, "RIGHT")
	bstext:SetTextColor(1, 1, 1, 1)

	enccheck:SetPoint("LEFT", bscheck, "TOPLEFT", 0, -40)
	enccheck:SetScript("OnClick", function() LFMonitorDB.professions.enc = enccheck:GetChecked() end)
	enctext:SetText(LFMonitor.ENCHANTING)
	enctext:SetPoint("LEFT", enccheck, "RIGHT")
	enctext:SetTextColor(1, 1, 1, 1)

	engcheck:SetPoint("LEFT", enccheck, "TOPLEFT", 0, -40)
	engcheck:SetScript("OnClick", function() LFMonitorDB.professions.eng = engcheck:GetChecked() end)
	engtext:SetText(LFMonitor.ENGINEERING)
	engtext:SetPoint("LEFT", engcheck, "RIGHT")
	engtext:SetTextColor(1, 1, 1, 1)

	inscheck:SetPoint("LEFT", engcheck, "TOPLEFT", 0, -40)
	inscheck:SetScript("OnClick", function() LFMonitorDB.professions.ins = inscheck:GetChecked() end)
	instext:SetText(LFMonitor.INSCRIPTION)
	instext:SetPoint("LEFT", inscheck, "RIGHT")
	instext:SetTextColor(1, 1, 1, 1)
	
	jccheck:SetPoint("LEFT", inscheck, "TOPLEFT", 0, -40)
	jccheck:SetScript("OnClick", function() LFMonitorDB.professions.jc = jccheck:GetChecked() end)
	jctext:SetText(LFMonitor.JEWELCRAFTING)
	jctext:SetPoint("LEFT", jccheck, "RIGHT")
	jctext:SetTextColor(1, 1, 1, 1)
	
	lwcheck:SetPoint("LEFT", jccheck, "TOPLEFT", 0, -40)
	lwcheck:SetScript("OnClick", function() LFMonitorDB.professions.lw = lwcheck:GetChecked() end)
	lwtext:SetText(LFMonitor.LEATHERWORKING)
	lwtext:SetPoint("LEFT", lwcheck, "RIGHT")
	lwtext:SetTextColor(1, 1, 1, 1)
	
	tlrcheck:SetPoint("LEFT", lwcheck, "TOPLEFT", 0, -40)
	tlrcheck:SetScript("OnClick", function() LFMonitorDB.professions.tlr = tlrcheck:GetChecked() end)
	tlrtext:SetText(LFMonitor.TAILORING)
	tlrtext:SetPoint("LEFT", tlrcheck, "RIGHT")
	tlrtext:SetTextColor(1, 1, 1, 1)
	
	misccheck:SetPoint("LEFT", tlrcheck, "TOPLEFT", 0, -40)
	misccheck:SetScript("OnClick", function() LFMonitorDB.monitoring.misc = misccheck:GetChecked() end)
	misctext:SetText(LFMonitor.ALL_LF_CRAFTER_REQUESTS)
	misctext:SetPoint("LEFT", misccheck, "RIGHT")
	misctext:SetTextColor(1, 1, 1, 1)
	
	lfcheck:SetPoint("LEFT", misccheck, "TOPLEFT", 0, -40)
	lfcheck:SetScript("OnClick", function() LFMonitorDB.monitoring.lf = lfcheck:GetChecked() end)
	lftext:SetText(LFMonitor.GENERAL_LF_REQUESTS)
	lftext:SetPoint("LEFT", lfcheck, "RIGHT")
	lftext:SetTextColor(1, 1, 1, 1)
	
	wtbcheck:SetPoint("LEFT", lfcheck, "TOPLEFT", 0, -40)
	wtbcheck:SetScript("OnClick", function() LFMonitorDB.monitoring.wtb = wtbcheck:GetChecked() end)
	wtbtext:SetText(LFMonitor.ALL_WTB_REQUESTS)
	wtbtext:SetPoint("LEFT", wtbcheck, "RIGHT")
	wtbtext:SetTextColor(1, 1, 1, 1)

	wtscheck:SetPoint("LEFT", wtbcheck, "TOPLEFT", 0, -40)
	wtscheck:SetScript("OnClick", function() LFMonitorDB.monitoring.wts = wtscheck:GetChecked() end)
	wtstext:SetText(LFMonitor.ALL_WTS_REQUESTS)
	wtstext:SetPoint("LEFT", wtscheck, "RIGHT")
	wtstext:SetTextColor(1, 1, 1 ,1)

	lfwcheck:SetPoint("LEFT", wtscheck, "TOPLEFT", 0, -40)
	lfwcheck:SetScript("OnClick", function() LFMonitorDB.monitoring.lfw = lfwcheck:GetChecked() end)
	lfwtext:SetText(LFMonitor.ALL_LFW_REQUESTS)
	lfwtext:SetPoint("LEFT", lfwcheck, "RIGHT")
	lfwtext:SetTextColor(1, 1, 1 ,1)

	return frame

end

local function CreateAppearancePanel()

	local frame = CreateFrame("Frame", "LFMonitorOptionsAppearance")
	local slider = CreateFrame("Slider", "LFMonitorFontSlider", frame, "OptionsSliderTemplate")
	local tscolour, tsback = LFMonitor:CreateColourBox(frame)
	local pncolour, pnback = LFMonitor:CreateColourBox(frame)
	local mtcolour, mtback = LFMonitor:CreateColourBox(frame)
	local wincolour, winback = LFMonitor:CreateColourBox(frame)
	local borcolour, borback = LFMonitor:CreateColourBox(frame)
	local title = frame:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge")
	local texttitle = frame:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge")
	local wintitle = frame:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge")
	local fonttitle = frame:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge")
	local tstitle = frame:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge")
	local tstext = tscolour:CreateFontString(nil, "ARTWORK", "GameFontNormal")
	local pntext = pncolour:CreateFontString(nil, "ARTWORK", "GameFontNormal")
	local mttext = mtcolour:CreateFontString(nil, "ARTWORK", "GameFontNormal")
	local wintext = wincolour:CreateFontString(nil, "ARTWORK", "GameFontNormal")
	local bortext = borcolour:CreateFontString(nil, "ARTWORK", "GameFontNormal")
	local fontselect, fontselected = LFMonitor:CreateComboBox(frame, "LFMonitorFontSelect")
	local tsselect, tsselected = LFMonitor:CreateComboBox(frame, "LFMonitorTSSelect")
	local classcheck = CreateFrame("CheckButton", nil, frame, "OptionsCheckButtonTemplate")
	local classtext = classcheck:CreateFontString(nil, "ARTWORK", "GameFontNormal")

	local function frameOnShow()

		classcheck:SetChecked(LFMonitorDB.options.useclasscolours)

	end

	frame:SetScript("OnShow", frameOnShow)

	title:SetWidth(400)
	title:SetText(LFMonitor.APPEARANCE_OPTIONS)
	title:SetJustifyH("CENTER")
	title:SetPoint("TOPLEFT", frame, "TOPLEFT", 5, -20)

	texttitle:SetWidth(400)
	texttitle:SetText(LFMonitor.TEXT)
	texttitle:SetJustifyH("LEFT")
	texttitle:SetPoint("LEFT", title, "TOPLEFT", 42, -40)

	wintitle:SetWidth(400)
	wintitle:SetText(LFMonitor.WINDOW)
	wintitle:SetJustifyH("LEFT")
	wintitle:SetPoint("LEFT", texttitle, "TOPLEFT", 0, -150)

	fonttitle:SetText(LFMonitor.FONT)
	fonttitle:SetJustifyH("LEFT")
	fonttitle:SetPoint("TOPLEFT", texttitle, "TOPLEFT", 200, 0)

	tstitle:SetWidth(400)
	tstitle:SetText(LFMonitor.TIMESTAMP_FORMAT)
	tstitle:SetJustifyH("CENTER")
	tstitle:SetPoint("TOPLEFT", frame, 5, -270)

	tscolour:SetPoint("LEFT", texttitle, "TOPLEFT", -27, -35)
	tscolour:SetScript("OnShow", function() SetSelectColour(tsback, "timestamp") end)
	tscolour:SetScript("OnMouseDown", function() if (arg1 == "LeftButton") then OptAppClick(tsback, "timestamp") end end)

	tstext:SetPoint("LEFT", tscolour, "RIGHT", 10, 0)
	tstext:SetTextColor(1, 1, 1, 1)
	tstext:SetText(LFMonitor.TIMESTAMP)

	pncolour:SetPoint("LEFT", tscolour, "TOPLEFT", 0, -30)
	pncolour:SetScript("OnShow", function() SetSelectColour(pnback, "player") end)
	pncolour:SetScript("OnMouseDown", function() if (arg1 == "LeftButton") then OptAppClick(pnback, "player") end end)

	pntext:SetPoint("LEFT", pncolour, "RIGHT", 10, 0)
	pntext:SetTextColor(1, 1, 1, 1)
	pntext:SetText(_G.CALENDAR_PLAYER_NAME)

	mtcolour:SetPoint("LEFT", pncolour, "TOPLEFT", 0, -30)
	mtcolour:SetScript("OnShow", function() SetSelectColour(mtback, "text") end)
	mtcolour:SetScript("OnMouseDown", function() if (arg1 == "LeftButton") then OptAppClick(mtback, "text") end end)

	mttext:SetPoint("LEFT", mtcolour, "RIGHT", 10, 0)
	mttext:SetTextColor(1, 1, 1, 1)
	mttext:SetText(LFMonitor.MESSAGE_TEXT)

	classcheck:SetPoint("LEFT", mtcolour, "TOPLEFT", -4, -45)
	classcheck:SetScript("OnClick", function() LFMonitorDB.options.useclasscolours = classcheck:GetChecked() or 0 end)
	classtext:SetPoint("LEFT", classcheck, "RIGHT", 4, 0)
	classtext:SetTextColor(1, 1, 1, 1)
	classtext:SetText(LFMonitor.CLASS_COLOUR_TEXT)

	wincolour:SetPoint("LEFT", wintitle, "TOPLEFT", -27, -35)
	wincolour:SetScript("OnShow", function() SetSelectColour(winback, "background") end)
	wincolour:SetScript("OnMouseDown", function() if (arg1 == "LeftButton") then OptAppClick(mtback, "background") end end)

	wintext:SetPoint("LEFT", wincolour, "RIGHT", 10, 0)
	wintext:SetTextColor(1, 1, 1, 1)
	wintext:SetText(LFMonitor.WINDOW)

	borcolour:SetPoint("LEFT", wincolour, "TOPLEFT", 0, -30)
	borcolour:SetScript("OnShow", function() SetSelectColour(borback, "border") end)
	borcolour:SetScript("OnMouseDown", function() if (arg1 == "LeftButton") then OptAppClick(borback, "border") end end)

	bortext:SetPoint("LEFT", borcolour, "RIGHT", 10, 0)
	bortext:SetTextColor(1, 1, 1, 1)
	bortext:SetText(_G.EMBLEM_BORDER)

	local function fontOnShow()

		fontselected:SetText(LFMonitor.fonts[LFMonitorDB.alert.font.index].name)
		UIDropDownMenu_Initialize(fontselect, LFMonitor_Font_DD_Initialise)

	end
	
	fontselect:SetPoint("CENTER", fonttitle, "CENTER", 0, -30)
	fontselect:SetScript("OnShow", fontOnShow)

	slider:SetPoint("CENTER", fontselect, "CENTER", 0, -40)
	slider:SetMinMaxValues(6, 18)
	slider:SetValueStep(1)

	local function sliderOnShow()

		slider:SetValue(LFMonitorDB.alert.font.height)
		LFMonitorFontSliderLow:SetText(6)
		LFMonitorFontSliderHigh:SetText(18)
		LFMonitorFontSliderText:SetText(LFMonitorDB.alert.font.height)

	end

	slider:SetScript("OnShow", sliderOnShow)

	local function sliderOnValueChanged()

		LFMonitorDB.alert.font.height = slider:GetValue()
		LFMonitor:SetAlertFont()
		LFMonitorFontSliderText:SetText(LFMonitorDB.alert.font.height)

	end

	slider:SetScript("OnValueChanged", sliderOnValueChanged)

	local function tsOnShow()

		tsselected:SetText(LFMonitor.timestamps[LFMonitorDB.options.timestamp].name)
		UIDropDownMenu_Initialize(tsselect, LFMonitor_TS_DD_Initialise)

	end
	
	tsselect:SetPoint("CENTER", tstitle, "CENTER", 0, -35)
	tsselect:SetScript("OnShow", tsOnShow)                    

	return frame

end

local function CreateGeneralPanel()

	local frame = CreateFrame("Frame", "LFMonitorOptionsAppearance")
	local discheck = CreateFrame("CheckButton", nil, frame, "OptionsCheckButtonTemplate")
	local lockcheck = CreateFrame("CheckButton", nil, frame, "OptionsCheckButtonTemplate")
	local showframe = CreateFrame("Frame", nil, frame)
	local restcheck = CreateFrame("CheckButton", nil, frame, "OptionsCheckButtonTemplate")
	local tradecheck = CreateFrame("CheckButton", nil, frame, "OptionsCheckButtonTemplate")
	local combcheck = CreateFrame("CheckButton", nil, frame, "OptionsCheckButtonTemplate")
	local instcheck = CreateFrame("CheckButton", nil, frame, "OptionsCheckButtonTemplate")
	local craftcheck = CreateFrame("CheckButton", nil, frame, "OptionsCheckButtonTemplate")
	local soundcheck = CreateFrame("CheckButton", nil, frame, "OptionsCheckButtonTemplate")
	local generalcheck = CreateFrame("CheckButton", nil, frame, "OptionsCheckButtonTemplate")
	local tradechancheck = CreateFrame("CheckButton", nil, frame, "OptionsCheckButtonTemplate")
	local guildcheck = CreateFrame("CheckButton", nil, frame, "OptionsCheckButtonTemplate")
	local lfgcheck = CreateFrame("CheckButton", nil, frame, "OptionsCheckButtonTemplate")
	local showtex = showframe:CreateTexture()
	local title = frame:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge")
	local channels = frame:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge")
	local distext = discheck:CreateFontString(nil, "ARTWORK", "GameFontNormal")
	local cltext = frame:CreateFontString(nil, "ARTWORK", "GameFontNormal")
	local locktext = lockcheck:CreateFontString(nil, "ARTWORK", "GameFontNormal")
	local resttext = restcheck:CreateFontString(nil, "ARTWORK", "GameFontNormal")
	local tradetext = restcheck:CreateFontString(nil, "ARTWORK", "GameFontNormal")
	local combtext = combcheck:CreateFontString(nil, "ARTWORK", "GameFontNormal")
	local insttext = instcheck:CreateFontString(nil, "ARTWORK", "GameFontNormal")
	local crafttext = craftcheck:CreateFontString(nil, "ARTWORK", "GameFontNormal")
	local soundtext = soundcheck:CreateFontString(nil, "ARTWORK", "GameFontNormal")
	local generaltext = generalcheck:CreateFontString(nil, "ARTWORK", "GameFontNormal")
	local tradechantext = tradecheck:CreateFontString(nil, "ARTWORK", "GameFontNormal")
	local guildtext = guildcheck:CreateFontString(nil, "ARTWORK", "GameFontNormal")
	local lfgtext = guildcheck:CreateFontString(nil, "ARTWORK", "GameFontNormal")
	local soundselect, soundselected = LFMonitor:CreateComboBox(frame, "LFMonitorSoundSelect")

	local function GeneralOnShow()

		discheck:SetChecked(LFMonitorDB.options.disabled)
		lockcheck:SetChecked(LFMonitorDB.options.locked)
		craftcheck:SetChecked(LFMonitorDB.options.scl)            
		instcheck:SetChecked(LFMonitorDB.options.hinst)
		restcheck:SetChecked(LFMonitorDB.options.rested)
		tradecheck:SetChecked(LFMonitorDB.options.trade)
		combcheck:SetChecked(LFMonitorDB.options.combat)
		soundcheck:SetChecked(LFMonitorDB.options.soundon)
		generalcheck:SetChecked(LFMonitorDB.channels.general)
		tradechancheck:SetChecked(LFMonitorDB.channels.trade)
		guildcheck:SetChecked(LFMonitorDB.channels.guild)
		lfgcheck:SetChecked(LFMonitorDB.channels.lfg)

		if (soundcheck:GetChecked()) then

			soundselect:Show()

		else

			soundselect:Hide()

		end

	end

	frame:SetScript("OnShow", GeneralOnShow)

	title:SetPoint("TOPLEFT", frame, "TOPLEFT", 5, -20)
	title:SetJustifyH("CENTER")
	title:SetWidth(400)
	title:SetText(LFMonitor.GENERAL_OPTIONS)

	cltext:SetPoint("TOPLEFT", title, "TOPLEFT", 42, -220)
	cltext:SetJustifyH("LEFT")
	cltext:SetWidth(355)
	cltext:SetText(LFMonitor.CRAFTING_LIST)

	channels:SetPoint("TOPLEFT", cltext, "BOTTOMLEFT", -37, -50)
	channels:SetWidth(400)
	channels:SetJustifyH("CENTER")
	channels:SetText(LFMonitor.CHANNELS)

	showframe:SetPoint("TOPLEFT", title, "TOPLEFT", 6, -22)
	showframe:SetHeight(62)
	showframe:SetWidth(390)
	showframe:SetBackdrop({edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border", edgeSize = 16})
	showframe:SetBackdropBorderColor(0.6, 0.6, 0.6, 0.6)
	showtex:SetAllPoints(showframe)

	
	local function radioOnClick(chk1, chk2)

		if ((chk1:GetChecked()) and (chk2:GetChecked())) then

			chk2:SetChecked(0)

		end

		LFMonitorDB.options.rested = restcheck:GetChecked()
		LFMonitorDB.options.trade = tradecheck:GetChecked()
		LFMonitor:DisableCheck()

	end
		
	restcheck:SetPoint("LEFT", title, "TOPLEFT", 15, -40)
	restcheck:SetScript("OnClick", function() radioOnClick(restcheck, tradecheck) end)

	resttext:SetPoint("LEFT", restcheck, "RIGHT")
	resttext:SetTextColor(1, 1, 1, 1)
	resttext:SetText(LFMonitor.SHOW_IN_CITIES)

	tradecheck:SetPoint("LEFT", restcheck, "TOPLEFT", 0, -40)
	tradecheck:SetScript("OnClick", function() radioOnClick(tradecheck, restcheck) end)

	tradetext:SetPoint("LEFT", tradecheck, "RIGHT")
	tradetext:SetTextColor(1, 1, 1, 1)
	tradetext:SetText(LFMonitor.TRADE_CHANNEL)

	discheck:SetPoint("LEFT", tradecheck, "TOPLEFT", 0, -45)
	discheck:SetScript("OnClick", function() LFMonitorDB.options.disabled = discheck:GetChecked(); LFMonitor:DisableCheck(discheck:GetChecked()) end)

	distext:SetPoint("LEFT", discheck, "RIGHT")
	distext:SetTextColor(1, 1, 1, 1)
	distext:SetText(_G.ADDON_DISABLED)

	lockcheck:SetPoint("LEFT", discheck, "TOPLEFT", 0, -40)
	lockcheck:SetScript("OnClick", function() LFMonitor:SetLocked(lockcheck:GetChecked()) end)

	locktext:SetPoint("LEFT", lockcheck, "RIGHT")
	locktext:SetTextColor(1, 1, 1, 1)
	locktext:SetText(LFMonitor.LOCK)

	combcheck:SetPoint("LEFT", lockcheck, "TOPLEFT", 0, -40)
	combcheck:SetScript("OnClick", function() LFMonitorDB.options.combat = combcheck:GetChecked() end)

	combtext:SetPoint("LEFT", combcheck, "RIGHT")
	combtext:SetTextColor(1, 1, 1, 1)
	combtext:SetText(LFMonitor.HIDE_IN_COMBAT)

	instcheck:SetPoint("LEFT", combcheck, "TOPLEFT", 0, -40)
	instcheck:SetScript("OnClick", function() LFMonitorDB.options.hinst = instcheck:GetChecked(); LFMonitor:DisableCheck(); end)

	insttext:SetPoint("LEFT", instcheck, "RIGHT")
	insttext:SetTextColor(1, 1, 1, 1)
	insttext:SetText(LFMonitor.HIDE_IN_INSTANCES)

	craftcheck:SetPoint("LEFT", instcheck, "TOPLEFT", 0, -40)
	craftcheck:SetScript("OnClick", function() LFMonitorDB.options.scl = craftcheck:GetChecked() end)

	crafttext:SetPoint("LEFT", craftcheck, "RIGHT")
	crafttext:SetTextColor(1, 1, 1, 1)
	crafttext:SetText(LFMonitor.SEND_CRAFTING_LIST)

	soundcheck:SetPoint("LEFT", cltext, "BOTTOMLEFT", -27, -25)
	soundcheck:SetScript("OnClick", function() LFMonitorDB.options.soundon = soundcheck:GetChecked(); if (soundcheck:GetChecked()) then soundselect:Show() else soundselect:Hide() end end)

	soundtext:SetPoint("LEFT", soundcheck, "RIGHT")
	soundtext:SetTextColor(1, 1, 1, 1)
	soundtext:SetText(LFMonitor.SOUND_ON)

	local function soundOnShow()

		soundselected:SetText(LFMonitor.sounds[LFMonitorDB.options.sound].name)
		UIDropDownMenu_Initialize(soundselect, LFMonitor_Sound_DD_Initialise)

	end
	
	soundselect:SetPoint("LEFT", soundcheck, "RIGHT", 100, -2)
	soundselect:SetScript("OnShow", soundOnShow)

	generalcheck:SetPoint("LEFT", soundcheck, "TOPLEFT", 0, -65)
	generalcheck:SetScript("OnClick", function() LFMonitorDB.channels.general = generalcheck:GetChecked() end)
	
	generaltext:SetPoint("LEFT", generalcheck, "RIGHT")
	generaltext:SetTextColor(1, 1, 1, 1)
	generaltext:SetText(_G.GENERAL)

	tradechancheck:SetPoint("LEFT", generalcheck, "TOPLEFT", 0, -40)
	tradechancheck:SetScript("OnClick", function() LFMonitorDB.channels.trade = tradechancheck:GetChecked() end)
	
	tradechantext:SetPoint("LEFT", tradechancheck, "RIGHT")
	tradechantext:SetTextColor(1, 1, 1, 1)
	tradechantext:SetText(_G.TRADE)
	
	guildcheck:SetPoint("LEFT", tradechancheck, "TOPLEFT", 0, -40)
	guildcheck:SetScript("OnClick", function() LFMonitorDB.channels.guild = guildcheck:GetChecked() end)
	
	guildtext:SetPoint("LEFT", guildcheck, "RIGHT")
	guildtext:SetTextColor(1, 1, 1, 1)
	guildtext:SetText(_G.GUILD)

	lfgcheck:SetPoint("TOPLEFT", generalcheck, "TOPLEFT", 180, 0)
	lfgcheck:SetScript("OnClick", function() LFMonitorDB.channels.lfg = lfgcheck:GetChecked() end)

	lfgtext:SetPoint("LEFT", lfgcheck, "RIGHT")
	lfgtext:SetTextColor(1, 1, 1, 1)
	lfgtext:SetText(_G.LFG_TITLE)

	return frame

end

local function CreateClassPanel()

	local frame = CreateFrame("Frame", "LFMonitorOptionsAppearance")
	local lfmcheck = CreateFrame("CheckButton", nil, frame, "OptionsCheckButtonTemplate")
	local lfgcheck = CreateFrame("CheckButton", nil, frame, "OptionsCheckButtonTemplate")
	local dkcheck = CreateFrame("CheckButton", nil, frame, "OptionsCheckButtonTemplate")
	local drcheck = CreateFrame("CheckButton", nil, frame, "OptionsCheckButtonTemplate")
	local hucheck = CreateFrame("CheckButton", nil, frame, "OptionsCheckButtonTemplate")
	local macheck = CreateFrame("CheckButton", nil, frame, "OptionsCheckButtonTemplate")
	local pacheck = CreateFrame("CheckButton", nil, frame, "OptionsCheckButtonTemplate")
	local prcheck = CreateFrame("CheckButton", nil, frame, "OptionsCheckButtonTemplate")
	local rocheck = CreateFrame("CheckButton", nil, frame, "OptionsCheckButtonTemplate")
	local shcheck = CreateFrame("CheckButton", nil, frame, "OptionsCheckButtonTemplate")
	local wacheck = CreateFrame("CheckButton", nil, frame, "OptionsCheckButtonTemplate")
	local wrcheck = CreateFrame("CheckButton", nil, frame, "OptionsCheckButtonTemplate")
	local override = CreateFrame("CheckButton", nil, frame, "OptionsCheckButtonTemplate")
	local title = frame:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge")
	local limit = frame:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge")
	local lfmtext = frame:CreateFontString(nil, "ARTWORK", "GameFontNormal")
	local lfgtext = frame:CreateFontString(nil, "ARTWORK", "GameFontNormal")
	local dktext = dkcheck:CreateFontString(nil, "ARTWORK", "GameFontNormal")
	local drtext = drcheck:CreateFontString(nil, "ARTWORK", "GameFontNormal")
	local hutext = hucheck:CreateFontString(nil, "ARTWORK", "GameFontNormal")
	local matext = macheck:CreateFontString(nil, "ARTWORK", "GameFontNormal")
	local patext = pacheck:CreateFontString(nil, "ARTWORK", "GameFontNormal")
	local prtext = prcheck:CreateFontString(nil, "ARTWORK", "GameFontNormal")
	local rotext = rocheck:CreateFontString(nil, "ARTWORK", "GameFontNormal")
	local shtext = shcheck:CreateFontString(nil, "ARTWORK", "GameFontNormal")
	local watext = wacheck:CreateFontString(nil, "ARTWORK", "GameFontNormal")
	local wrtext = wrcheck:CreateFontString(nil, "ARTWORK", "GameFontNormal")
	local overridetext = override:CreateFontString(nil, "ARTWORK", "GameFontNormal")
	local txt, num

	title:SetPoint("TOPLEFT", frame, "TOPLEFT", 5, -20)
	title:SetJustifyH("CENTER")
	title:SetWidth(400)
	title:SetText(LFMonitor.LFM_OPTIONS)

	limit:SetPoint("LEFT", title, "TOPLEFT", 15, -100)
	limit:SetJustifyH("LEFT")
	limit:SetWidth(400)
	limit:SetText(LFMonitor.LFM_LIMIT)

	local function SetLFMOptions(show)

		local checks = {dkcheck, drcheck, hucheck, macheck, pacheck, prcheck, rocheck, shcheck, wacheck, wrcheck, limit}

		if (show == 1) then

			for _, check in ipairs(checks) do

				check:Show()

			end

		else

			for _, check in ipairs(checks) do

				check:Hide()

			end

		end

	end

	lfmcheck:SetPoint("LEFT", title, "TOPLEFT", 15, -40)
	lfmcheck:SetScript("OnClick", function() LFMonitorDB.monitoring.lfm = lfmcheck:GetChecked(); SetLFMOptions(lfmcheck:GetChecked()) end)
	
	lfmtext:SetPoint("LEFT", lfmcheck, "RIGHT")
	lfmtext:SetTextColor(1, 1, 1, 1)
	lfmtext:SetText(LFMonitor.ALL_LFM_REQUESTS)

	lfgcheck:SetPoint("LEFT", lfmcheck, "TOPLEFT", 0, -40)
	lfgcheck:SetScript("OnClick", function() LFMonitorDB.monitoring.lfg = lfgcheck:GetChecked() end)
	
	lfgtext:SetPoint("LEFT", lfgcheck, "RIGHT")
	lfgtext:SetTextColor(1, 1, 1, 1)
	lfgtext:SetText(LFMonitor.ALL_LFG_REQUESTS)

	dkcheck:SetPoint("LEFT", limit, "TOPLEFT", 0, -40)
	dkcheck:SetScript("OnClick", function() LFMonitorDB.classes.dk = dkcheck:GetChecked() end)
	
	dktext:SetPoint("LEFT", dkcheck, "RIGHT")
	dktext:SetTextColor(1, 1, 1, 1)
	txt, num = string.gsub(LFMonitor.DK_TXT[1],"(%a)", string.upper, 1)
	dktext:SetText(txt)

	drcheck:SetPoint("LEFT", dkcheck, "TOPLEFT", 0, -35)
	drcheck:SetScript("OnClick", function() LFMonitorDB.classes.dr = drcheck:GetChecked() end)
	
	drtext:SetPoint("LEFT", drcheck, "RIGHT")
	drtext:SetTextColor(1, 1, 1, 1)
	txt, num = string.gsub(LFMonitor.DR_TXT[1],"(%a)", string.upper, 1)
	drtext:SetText(txt)

	hucheck:SetPoint("LEFT", drcheck, "TOPLEFT", 0, -35)
	hucheck:SetScript("OnClick", function() LFMonitorDB.classes.hu = hucheck:GetChecked() end)
	
	hutext:SetPoint("LEFT", hucheck, "RIGHT")
	hutext:SetTextColor(1, 1, 1, 1)
	txt, num = string.gsub(LFMonitor.HU_TXT[1],"(%a)", string.upper, 1)
	hutext:SetText(txt)

	macheck:SetPoint("LEFT", hucheck, "TOPLEFT", 0, -35)
	macheck:SetScript("OnClick", function() LFMonitorDB.classes.ma = macheck:GetChecked() end)
	
	matext:SetPoint("LEFT", macheck, "RIGHT")
	matext:SetTextColor(1, 1, 1, 1)
	txt, num = string.gsub(LFMonitor.MA_TXT[1],"(%a)", string.upper, 1)
	matext:SetText(txt)

	pacheck:SetPoint("LEFT", macheck, "TOPLEFT", 0, -35)
	pacheck:SetScript("OnClick", function() LFMonitorDB.classes.pa = pacheck:GetChecked() end)
	
	patext:SetPoint("LEFT", pacheck, "RIGHT")
	patext:SetTextColor(1, 1, 1, 1)
	txt, num = string.gsub(LFMonitor.PA_TXT[1],"(%a)", string.upper, 1)
	patext:SetText(txt)

	prcheck:SetPoint("LEFT", pacheck, "TOPLEFT", 0, -35)
	prcheck:SetScript("OnClick", function() LFMonitorDB.classes.pr = prcheck:GetChecked() end)
	
	prtext:SetPoint("LEFT", prcheck, "RIGHT")
	prtext:SetTextColor(1, 1, 1, 1)
	txt, num = string.gsub(LFMonitor.PR_TXT[1],"(%a)", string.upper, 1)
	prtext:SetText(txt)

	rocheck:SetPoint("LEFT", prcheck, "TOPLEFT", 0, -35)
	rocheck:SetScript("OnClick", function() LFMonitorDB.classes.ro = rocheck:GetChecked() end)
	
	rotext:SetPoint("LEFT", rocheck, "RIGHT")
	rotext:SetTextColor(1, 1, 1, 1)
	txt, num = string.gsub(LFMonitor.RO_TXT[1],"(%a)", string.upper, 1)
	rotext:SetText(txt)

	shcheck:SetPoint("LEFT", rocheck, "TOPLEFT", 0, -35)
	shcheck:SetScript("OnClick", function() LFMonitorDB.classes.sh = shcheck:GetChecked() end)
	
	shtext:SetPoint("LEFT", shcheck, "RIGHT")
	shtext:SetTextColor(1, 1, 1, 1)
	txt, num = string.gsub(LFMonitor.SH_TXT[1],"(%a)", string.upper, 1)
	shtext:SetText(txt)

	wacheck:SetPoint("LEFT", shcheck, "TOPLEFT", 0, -35)
	wacheck:SetScript("OnClick", function() LFMonitorDB.classes.wa = wacheck:GetChecked() end)
	
	watext:SetPoint("LEFT", wacheck, "RIGHT")
	watext:SetTextColor(1, 1, 1, 1)
	txt, num = string.gsub(LFMonitor.WA_TXT[1],"(%a)", string.upper, 1)
	watext:SetText(txt)

	wrcheck:SetPoint("LEFT", wacheck, "TOPLEFT", 0, -35)
	wrcheck:SetScript("OnClick", function() LFMonitorDB.classes.wr = wrcheck:GetChecked() end)
	
	wrtext:SetPoint("LEFT", wrcheck, "RIGHT")
	wrtext:SetTextColor(1, 1, 1, 1)
	txt, num = string.gsub(LFMonitor.WR_TXT[1],"(%a)", string.upper, 1)
	wrtext:SetText(txt)

	override:SetPoint("LEFT", wrcheck, "TOPLEFT", 0, -70)
	override:SetScript("OnClick", function() LFMonitorDB.options.overrideraid = override:GetChecked() end)
	
	overridetext:SetPoint("LEFT", override, "RIGHT")
	overridetext:SetTextColor(1, 1, 1, 1)
	overridetext:SetText(LFMonitor.IGNORE_RAID)
	
	local function ClassOnShow()

		lfmcheck:SetChecked(LFMonitorDB.monitoring.lfm)
		lfgcheck:SetChecked(LFMonitorDB.monitoring.lfg)
		dkcheck:SetChecked(LFMonitorDB.classes.dk)
		drcheck:SetChecked(LFMonitorDB.classes.dr)
		hucheck:SetChecked(LFMonitorDB.classes.hu)
		macheck:SetChecked(LFMonitorDB.classes.ma)
		pacheck:SetChecked(LFMonitorDB.classes.pa)
		prcheck:SetChecked(LFMonitorDB.classes.pr)
		rocheck:SetChecked(LFMonitorDB.classes.ro)
		shcheck:SetChecked(LFMonitorDB.classes.sh)
		wacheck:SetChecked(LFMonitorDB.classes.wa)
		wrcheck:SetChecked(LFMonitorDB.classes.wr)
		override:SetChecked(LFMonitorDB.options.overrideraid)
		SetLFMOptions(lfmcheck:GetChecked())

	end

	frame:SetScript("OnShow", ClassOnShow)

	return frame

end

local function CreateResponsePanel()

	local frame = CreateFrame("Frame", "LFMonitorOptionsRespond")
	local alcedit = CreateFrame("EditBox", "LFMonitorAlcEdit", frame, "InputBoxTemplate")
	local bsedit = CreateFrame("EditBox", "LFMonitorBsEdit", frame, "InputBoxTemplate")
	local encedit = CreateFrame("EditBox", "LFMonitorEncEdit", frame, "InputBoxTemplate")
	local engedit = CreateFrame("EditBox", "LFMonitorEngEdit", frame, "InputBoxTemplate")
	local insedit = CreateFrame("EditBox", "LFMonitorInsEdit", frame, "InputBoxTemplate")
	local jcedit = CreateFrame("EditBox", "LFMonitorJcEdit", frame, "InputBoxTemplate")
	local lwedit = CreateFrame("EditBox", "LFMonitorLwEdit", frame, "InputBoxTemplate")
	local tlredit = CreateFrame("EditBox", "LFMonitorTlrEdit", frame, "InputBoxTemplate")
	LFMonitor.lfgedit = CreateFrame("EditBox", "LFMonitorLFGEdit", frame, "InputBoxTemplate")
	local title = frame:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge")
	local alctext = alcedit:CreateFontString(nil, "ARTWORK", "GameFontNormal")
	local bstext = bsedit:CreateFontString(nil, "ARTWORK", "GameFontNormal")
	local enctext = encedit:CreateFontString(nil, "ARTWORK", "GameFontNormal")
	local engtext = engedit:CreateFontString(nil, "ARTWORK", "GameFontNormal")
	local instext = insedit:CreateFontString(nil, "ARTWORK", "GameFontNormal")
	local jctext = jcedit:CreateFontString(nil, "ARTWORK", "GameFontNormal")
	local lwtext = lwedit:CreateFontString(nil, "ARTWORK", "GameFontNormal")
	local tlrtext = tlredit:CreateFontString(nil, "ARTWORK", "GameFontNormal")
	local lfgtext = LFMonitor.lfgedit:CreateFontString(nil, "ARTWORK", "GameFontNormal")
	local edits = {
		{box = alcedit, text = alctext, db = "alc", title = LFMonitor.ALCHEMY},
		{box = bsedit, text = bstext, db = "bs", title = LFMonitor.BLACKSMITHING},
		{box = encedit, text = enctext, db = "enc", title = LFMonitor.ENCHANTING},
		{box = engedit, text = engtext, db = "eng", title = LFMonitor.ENGINEERING},
		{box = insedit, text = instext, db = "ins", title = LFMonitor.INSCRIPTION},
		{box = jcedit, text = jctext, db = "jc", title = LFMonitor.JEWELCRAFTING},
		{box = lwedit, text = lwtext, db = "lw", title = LFMonitor.LEATHERWORKING},
		{box = tlredit, text = tlrtext, db = "tlr", title = LFMonitor.TAILORING},
		}
	local first, anchor = true, title
	local offsety, offsetx = -55, 10

	frame:Hide()

	title:SetPoint("TOPLEFT", frame, "TOPLEFT", 5, -20)
	title:SetWidth(400)
	title:SetText(LFMonitor.RESPONSES_TO_REQUESTS)

	local function responseOnShow()

		for _, edit in ipairs(edits) do

			if ((first) and (LFMonitorDB.professions[edit.db] == 1)) then

				anchor = title
				first = nil
				offsetx = 10

			else

				offsetx = 0

			end

			if (LFMonitorDB.professions[edit.db] == 1) then

				edit.box:SetPoint("LEFT", anchor, "TOPLEFT", offsetx, offsety)
				edit.box:SetWidth(385)
				edit.box:SetHeight(32)
				edit.box:SetMaxLetters(90)
				edit.box:SetAutoFocus(false)
				edit.box:SetText(LFMonitorDB.responses[edit.db])
				edit.text:SetPoint("LEFT", edit.box, "TOPLEFT", 0, 5)
				edit.text:SetText(edit.title)
				edit.box:Show()
				anchor = edit.box

			else

				edit.box:Hide()

			end

		end

		if (LFMonitorDB.monitoring.lfm == 1) then

			local function lfgMouse(self, button)

				local cursor = self:GetCursorPosition()
				local text = self:GetText()
				local segment = string.sub(text, 1, cursor)
				local link, txt, sp
				local ls, le = string.find(segment, "|c.-|h|r")

				if ((cursor == nil) or (cursor >= string.len(text))) then

					return

				end

				--remove any leading links and find the one we want

				sp = ls or 1

				while (le) do

					segment = string.sub(segment, le +1)
					sp = sp + le
					ls, le = string.find(segment, "|c.-|h|r")

				end

				ls, le = string.find(segment, "|c")

				if (ls) then

					txt = string.match(text, "|c.-|h|r", sp)
					link = string.match(text, "|H(.-)|h", sp)
					SetItemRef(link, txt, button)

				end

			end

			LFMonitor.lfgedit:SetPoint("LEFT", anchor, "TOPLEFT", offsetx, offsety)
			LFMonitor.lfgedit:SetWidth(385)
			LFMonitor.lfgedit:SetHeight(32)
			LFMonitor.lfgedit:SetMaxLetters(90)
			LFMonitor.lfgedit:SetAutoFocus(false)
			LFMonitor.lfgedit:SetScript("OnEditFocusGained", function() LFMonitor.LFGEditFocus = true end)
			LFMonitor.lfgedit:SetScript("OnEditFocusLost", function() LFMonitor.LFGEditFocus = false end)
			LFMonitor.lfgedit:SetScript("OnMouseUp", lfgMouse)

			if (LFMonitorDB.responses.lfm == nil) then

				LFMonitorDB.responses.lfm = LFMonitor.LFG_RESPONSE

			end

			LFMonitor.lfgedit:SetText(LFMonitorDB.responses.lfm)
			lfgtext:SetPoint("LEFT", LFMonitor.lfgedit, "TOPLEFT", 0, 5)
			lfgtext:SetText(_G.LFG_TITLE)
			LFMonitor.lfgedit:Show()

		else

			LFMonitor.lfgedit:Hide()

		end

		first = true

	end

	local function responseOnHide()

		for _, edit in ipairs(edits) do

			edit.box:ClearAllPoints()
			edit.text:ClearAllPoints()

		end

	end

	frame:SetScript("OnShow", responseOnShow)
	frame:SetScript("OnHide", responseOnHide)

	return frame

end

local function CreateCustomPanel()

	local frame = CreateFrame("Frame", "LFMonitorOptionsCustom")
	local basicedit = CreateFrame("EditBox", "LFMonitorBasicEdit", frame, "InputBoxTemplate")
	local advedit = CreateFrame("EditBox", "LFMonitorAdvEdit", frame, "InputBoxTemplate")
	local title = frame:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge")
	local basictext = basicedit:CreateFontString(nil, "ARTWORK", "GameFontNormal")
	local advtext = advedit:CreateFontString(nil, "ARTWORK", "GameFontNormal")
	local inst = frame:CreateFontString(nil, "ARTWORK", "GameFontNormal")
	local warn = frame:CreateFontString(nil, "ARTWORK", "GameFontNormal")
	LFMonitor.cchantext = frame:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge")
	LFMonitor.cc1 = CreateFrame("CheckButton", nil, frame, "OptionsCheckButtonTemplate")
	LFMonitor.cc1text = LFMonitor.cc1:CreateFontString(nil, "ARTWORK", "GameFontNormal")
	LFMonitor.cc2 = CreateFrame("CheckButton", nil, frame, "OptionsCheckButtonTemplate")
	LFMonitor.cc2text = LFMonitor.cc2:CreateFontString(nil, "ARTWORK", "GameFontNormal")
	LFMonitor.cc3 = CreateFrame("CheckButton", nil, frame, "OptionsCheckButtonTemplate")
	LFMonitor.cc3text = LFMonitor.cc3:CreateFontString(nil, "ARTWORK", "GameFontNormal")
	LFMonitor.cc4 = CreateFrame("CheckButton", nil, frame, "OptionsCheckButtonTemplate")
	LFMonitor.cc4text = LFMonitor.cc4:CreateFontString(nil, "ARTWORK", "GameFontNormal")
	LFMonitor.cc5 = CreateFrame("CheckButton", nil, frame, "OptionsCheckButtonTemplate")
	LFMonitor.cc5text = LFMonitor.cc5:CreateFontString(nil, "ARTWORK", "GameFontNormal")
	LFMonitor.cc6 = CreateFrame("CheckButton", nil, frame, "OptionsCheckButtonTemplate")
	LFMonitor.cc6text = LFMonitor.cc6:CreateFontString(nil, "ARTWORK", "GameFontNormal")
	LFMonitor.cc7 = CreateFrame("CheckButton", nil, frame, "OptionsCheckButtonTemplate")
	LFMonitor.cc7text = LFMonitor.cc7:CreateFontString(nil, "ARTWORK", "GameFontNormal")
	local ctl

	local function customOnShow()

		local i, v
		local channels = {GetChannelList()}

		v = 1

		for i = 1, 7 do

			LFMonitor["cc" .. i]:Hide()

		end

		for i = 1, #channels, 2 do

			if (channels[i] > 4) then

				LFMonitor["cc" .. v .. "text"]:SetText(channels[i + 1])
				LFMonitor["cc" .. v]:SetChecked(LFMonitorDB.channels["cc" .. channels[i + 1]])
				LFMonitor["cc" .. v]:Show()
				v = v + 1

			end

		end

		if (v == 1) then

			LFMonitor.cchantext:Hide()

		else

			LFMonitor.cchantext:Show()

		end

	end

	frame:Hide()
	frame:SetScript("OnShow", customOnShow)

	title:SetPoint("TOPLEFT", frame, "TOPLEFT", 5, -20)
	title:SetWidth(400)
	title:SetText(LFMonitor.CUSTOM_OPTIONS)

	inst:SetPoint("TOPLEFT", title, "TOPLEFT", 0, -20)
	inst:SetWidth(400)
	inst:SetText(LFMonitor.CUSTOM_INST)

	basictext:SetPoint("LEFT", inst, "TOPLEFT", 5, -30)
	basictext:SetText(LFMonitor.CUSTOM_BASIC)

	basicedit:SetPoint("LEFT", basictext, "TOPLEFT", 5, -25)
	basicedit:SetWidth(385)
	basicedit:SetHeight(32)
	basicedit:SetMaxLetters(90)
	basicedit:SetAutoFocus(false)
	basicedit:SetText(LFMonitorDB.options.basic or "")
	
	warn:SetPoint("TOPLEFT", basicedit, "TOPLEFT", -5, -45)
	warn:SetTextColor(1, 1, 1, 1)
	warn:SetWidth(390)
	warn:SetJustifyH("LEFT")
	warn:SetText(LFMonitor.CUSTOM_WARNING)

	advtext:SetPoint("LEFT", warn, "BOTTOMLEFT", 0, -20)
	advtext:SetText(LFMonitor.CUSTOM_ADV)

	advedit:SetPoint("LEFT", advtext, "TOPLEFT", 5, -25)
	advedit:SetWidth(385)
	advedit:SetHeight(32)
	advedit:SetMaxLetters(90)
	advedit:SetAutoFocus(false)
	advedit:SetText(LFMonitorDB.options.adv or "")

	LFMonitor.cchantext:SetPoint("TOPLEFT", advedit, "TOPLEFT", 0, -35)
	LFMonitor.cchantext:SetWidth(400)
	LFMonitor.cchantext:SetText(LFMonitor.CUSTOM_CHANNELS)

	local function ctlOnClick(idx)

		LFMonitorDB.channels["cc" .. LFMonitor["cc" .. idx .. "text"]:GetText()] = LFMonitor["cc" .. idx]:GetChecked()

	end

	for ctl = 1,7 do

		if (ctl == 1) then

			LFMonitor["cc1"]:SetPoint("TOPLEFT", LFMonitor.cchantext, "BOTTOMLEFT", 5, -5)

		else

			LFMonitor["cc" .. ctl]:SetPoint("TOPLEFT", LFMonitor["cc" .. (ctl - 1)], "BOTTOMLEFT", 0, 0)

		end

		LFMonitor["cc" .. ctl .. "text"]:SetPoint("TOPLEFT", LFMonitor["cc" .. ctl], "TOPRIGHT", 5, -5)
		LFMonitor["cc" .. ctl]:SetScript("OnClick", function() ctlOnClick(ctl) end)

	end

	return frame

end

local function CreateRaidsPanel()

	local frame = CreateFrame("Frame", "LFMonitorOptionsProfession")
	local eoecheck = CreateFrame("CheckButton", nil, frame, "OptionsCheckButtonTemplate")
	local icccheck = CreateFrame("CheckButton", nil, frame, "OptionsCheckButtonTemplate")
	local naxxcheck = CreateFrame("CheckButton", nil, frame, "OptionsCheckButtonTemplate")
	local onycheck = CreateFrame("CheckButton", nil, frame, "OptionsCheckButtonTemplate")
	local oscheck = CreateFrame("CheckButton", nil, frame, "OptionsCheckButtonTemplate")
	local toccheck = CreateFrame("CheckButton", nil, frame, "OptionsCheckButtonTemplate")
	local rscheck = CreateFrame("CheckButton", nil, frame, "OptionsCheckButtonTemplate")
	local ulrcheck = CreateFrame("CheckButton", nil, frame, "OptionsCheckButtonTemplate")
	local voacheck = CreateFrame("CheckButton", nil, frame, "OptionsCheckButtonTemplate")
	local bmjcheck = CreateFrame("CheckButton", nil, frame, "OptionsCheckButtonTemplate")
	local btcheck = CreateFrame("CheckButton", nil, frame, "OptionsCheckButtonTemplate")
	local glcheck = CreateFrame("CheckButton", nil, frame, "OptionsCheckButtonTemplate")
	local kzcheck = CreateFrame("CheckButton", nil, frame, "OptionsCheckButtonTemplate")
	local mlcheck = CreateFrame("CheckButton", nil, frame, "OptionsCheckButtonTemplate")
	local ssccheck = CreateFrame("CheckButton", nil, frame, "OptionsCheckButtonTemplate")
	local spcheck = CreateFrame("CheckButton", nil, frame, "OptionsCheckButtonTemplate")
	local tkcheck = CreateFrame("CheckButton", nil, frame, "OptionsCheckButtonTemplate")
	local zacheck = CreateFrame("CheckButton", nil, frame, "OptionsCheckButtonTemplate")
	local bwlcheck = CreateFrame("CheckButton", nil, frame, "OptionsCheckButtonTemplate")
	local mccheck = CreateFrame("CheckButton", nil, frame, "OptionsCheckButtonTemplate")
	local rqcheck = CreateFrame("CheckButton", nil, frame, "OptionsCheckButtonTemplate")
	local aqcheck = CreateFrame("CheckButton", nil, frame, "OptionsCheckButtonTemplate")
	local ubrscheck = CreateFrame("CheckButton", nil, frame, "OptionsCheckButtonTemplate")
	local zgcheck = CreateFrame("CheckButton", nil, frame, "OptionsCheckButtonTemplate")
	local eoetext = eoecheck:CreateFontString(nil, "ARTWORK", "GameFontNormal")
	local icctext = icccheck:CreateFontString(nil, "ARTWORK", "GameFontNormal")
	local naxxtext = naxxcheck:CreateFontString(nil, "ARTWORK", "GameFontNormal")
	local onytext = onycheck:CreateFontString(nil, "ARTWORK", "GameFontNormal")
	local ostext = oscheck:CreateFontString(nil, "ARTWORK", "GameFontNormal")
	local toctext = toccheck:CreateFontString(nil, "ARTWORK", "GameFontNormal")
	local rstext = rscheck:CreateFontString(nil, "ARTWORK", "GameFontNormal")
	local ulrtext = ulrcheck:CreateFontString(nil, "ARTWORK", "GameFontNormal")
	local voatext = voacheck:CreateFontString(nil, "ARTWORK", "GameFontNormal")
	local bmjtext = bmjcheck:CreateFontString(nil, "ARTWORK", "GameFontNormal")
	local bttext = btcheck:CreateFontString(nil, "ARTWORK", "GameFontNormal")
	local gltext = glcheck:CreateFontString(nil, "ARTWORK", "GameFontNormal")
	local kztext = kzcheck:CreateFontString(nil, "ARTWORK", "GameFontNormal")
	local mltext = mlcheck:CreateFontString(nil, "ARTWORK", "GameFontNormal")
	local ssctext = ssccheck:CreateFontString(nil, "ARTWORK", "GameFontNormal")
	local sptext = spcheck:CreateFontString(nil, "ARTWORK", "GameFontNormal")
	local tktext = tkcheck:CreateFontString(nil, "ARTWORK", "GameFontNormal")
	local zatext = zacheck:CreateFontString(nil, "ARTWORK", "GameFontNormal")
	local bwltext = bwlcheck:CreateFontString(nil, "ARTWORK", "GameFontNormal")
	local mctext = mccheck:CreateFontString(nil, "ARTWORK", "GameFontNormal")
	local rqtext = rqcheck:CreateFontString(nil, "ARTWORK", "GameFontNormal")
	local aqtext = aqcheck:CreateFontString(nil, "ARTWORK", "GameFontNormal")
	local ubrstext = ubrscheck:CreateFontString(nil, "ARTWORK", "GameFontNormal")
	local zgtext = zgcheck:CreateFontString(nil, "ARTWORK", "GameFontNormal")
	
	if (LFMonitorDB.raids == nil) then
	
		LFMonitorDB.raids = {eoe = 0, icc = 0, naxx = 0, ony = 0, os = 0, toc = 0, rs = 0, ulr = 0, voa = 0, bmj = 0, bt = 0, gl = 0,
			kz = 0, ml = 0, ssc = 0, sp = 0, tk = 0, za = 0, bwl = 0, mc = 0, rq = 0, aq = 0, ubrs = 0, zg = 0}
			
	end
	
	local function ProfessionOnShow()

		eoecheck:SetChecked(LFMonitorDB.raids.eoe)
		icccheck:SetChecked(LFMonitorDB.raids.icc)
		naxxcheck:SetChecked(LFMonitorDB.raids.naxx)
		onycheck:SetChecked(LFMonitorDB.raids.ony)
		oscheck:SetChecked(LFMonitorDB.raids.os)
		toccheck:SetChecked(LFMonitorDB.raids.toc)
		rscheck:SetChecked(LFMonitorDB.raids.rs)
		ulrcheck:SetChecked(LFMonitorDB.raids.ulr)
		voacheck:SetChecked(LFMonitorDB.raids.voa)
		bmjcheck:SetChecked(LFMonitorDB.raids.bmj)
		btcheck:SetChecked(LFMonitorDB.raids.bt)
		glcheck:SetChecked(LFMonitorDB.raids.gl)
		kzcheck:SetChecked(LFMonitorDB.raids.kz)

	end

	frame:SetScript("OnShow", ProfessionOnShow)

	eoecheck:SetPoint("TOPLEFT", frame, "TOPLEFT", 5, -5)
	eoecheck:SetScript("OnClick", function() LFMonitorDB.raids.eoe = eoecheck:GetChecked() end)
	eoetext:SetText(LFMonitor.EOE_NAME)
	eoetext:SetPoint("LEFT", eoecheck, "RIGHT")
	eoetext:SetTextColor(1, 1, 1, 1)

	icccheck:SetPoint("LEFT", eoecheck, "TOPLEFT", 0, -30)
	icccheck:SetScript("OnClick", function() LFMonitorDB.raids.icc = icccheck:GetChecked() end)
	icctext:SetText(LFMonitor.ICC_NAME)
	icctext:SetPoint("LEFT", icccheck, "RIGHT")
	icctext:SetTextColor(1, 1, 1, 1)

	naxxcheck:SetPoint("LEFT", icccheck, "TOPLEFT", 0, -30)
	naxxcheck:SetScript("OnClick", function() LFMonitorDB.raids.naxx = naxxcheck:GetChecked() end)
	naxxtext:SetText(LFMonitor.NAXX_NAME)
	naxxtext:SetPoint("LEFT", naxxcheck, "RIGHT")
	naxxtext:SetTextColor(1, 1, 1, 1)

	onycheck:SetPoint("LEFT", naxxcheck, "TOPLEFT", 0, -30)
	onycheck:SetScript("OnClick", function() LFMonitorDB.raids.ony = onycheck:GetChecked() end)
	onytext:SetText(LFMonitor.ONY_NAME)
	onytext:SetPoint("LEFT", onycheck, "RIGHT")
	onytext:SetTextColor(1, 1, 1, 1)

	oscheck:SetPoint("LEFT", onycheck, "TOPLEFT", 0, -30)
	oscheck:SetScript("OnClick", function() LFMonitorDB.raids.os = oscheck:GetChecked() end)
	ostext:SetText(LFMonitor.OS_NAME)
	ostext:SetPoint("LEFT", oscheck, "RIGHT")
	ostext:SetTextColor(1, 1, 1, 1)
	
	toccheck:SetPoint("LEFT", oscheck, "TOPLEFT", 0, -30)
	toccheck:SetScript("OnClick", function() LFMonitorDB.raids.toc = toccheck:GetChecked() end)
	toctext:SetText(LFMonitor.TOC_NAME)
	toctext:SetPoint("LEFT", toccheck, "RIGHT")
	toctext:SetTextColor(1, 1, 1, 1)
	
	rscheck:SetPoint("LEFT", toccheck, "TOPLEFT", 0, -30)
	rscheck:SetScript("OnClick", function() LFMonitorDB.raids.rs = rscheck:GetChecked() end)
	rstext:SetText(LFMonitor.RS_NAME)
	rstext:SetPoint("LEFT", rscheck, "RIGHT")
	rstext:SetTextColor(1, 1, 1, 1)
	
	ulrcheck:SetPoint("LEFT", rscheck, "TOPLEFT", 0, -30)
	ulrcheck:SetScript("OnClick", function() LFMonitorDB.raids.ulr = ulrcheck:GetChecked() end)
	ulrtext:SetText(LFMonitor.ULR_NAME)
	ulrtext:SetPoint("LEFT", ulrcheck, "RIGHT")
	ulrtext:SetTextColor(1, 1, 1, 1)
	
	voacheck:SetPoint("LEFT", ulrcheck, "TOPLEFT", 0, -30)
	voacheck:SetScript("OnClick", function() LFMonitorDB.raids.voa = voacheck:GetChecked() end)
	voatext:SetText(LFMonitor.VOA_NAME)
	voatext:SetPoint("LEFT", voacheck, "RIGHT")
	voatext:SetTextColor(1, 1, 1, 1)
	
	bmjcheck:SetPoint("LEFT", voacheck, "TOPLEFT", 0, -30)
	bmjcheck:SetScript("OnClick", function() LFMonitorDB.raids.bmj = bmjcheck:GetChecked() end)
	bmjtext:SetText(LFMonitor.BMJ_NAME)
	bmjtext:SetPoint("LEFT", bmjcheck, "RIGHT")
	bmjtext:SetTextColor(0, 1, 1, 1)
	
	btcheck:SetPoint("LEFT", bmjcheck, "TOPLEFT", 0, -30)
	btcheck:SetScript("OnClick", function() LFMonitorDB.raids.bt = btcheck:GetChecked() end)
	bttext:SetText(LFMonitor.BT_NAME)
	bttext:SetPoint("LEFT", btcheck, "RIGHT")
	bttext:SetTextColor(0, 1, 1, 1)

	glcheck:SetPoint("LEFT", btcheck, "TOPLEFT", 0, -30)
	glcheck:SetScript("OnClick", function() LFMonitorDB.raids.gl = glcheck:GetChecked() end)
	gltext:SetText(LFMonitor.GL_NAME)
	gltext:SetPoint("LEFT", glcheck, "RIGHT")
	gltext:SetTextColor(0, 1, 1 ,1)

	kzcheck:SetPoint("LEFT", glcheck, "TOPLEFT", 0, -30)
	kzcheck:SetScript("OnClick", function() LFMonitorDB.raids.kz = kzcheck:GetChecked() end)
	kztext:SetText(LFMonitor.KZ_NAME)
	kztext:SetPoint("LEFT", kzcheck, "RIGHT")
	kztext:SetTextColor(0, 1, 1 ,1)
	
	mlcheck:SetPoint("LEFT", kzcheck, "TOPLEFT", 0, -30)
	mlcheck:SetScript("OnClick", function() LFMonitorDB.raids.ml = mlcheck:GetChecked() end)
	mltext:SetText(LFMonitor.ML_NAME)
	mltext:SetPoint("LEFT", mlcheck, "RIGHT")
	mltext:SetTextColor(0, 1, 1 ,1)
	
	ssccheck:SetPoint("LEFT", mlcheck, "TOPLEFT", 0, -30)
	ssccheck:SetScript("OnClick", function() LFMonitorDB.raids.ssc = ssccheck:GetChecked() end)
	ssctext:SetText(LFMonitor.SSC_NAME)
	ssctext:SetPoint("LEFT", ssccheck, "RIGHT")
	ssctext:SetTextColor(0, 1, 1 ,1)
	
	spcheck:SetPoint("LEFT", ssccheck, "TOPLEFT", 0, -30)
	spcheck:SetScript("OnClick", function() LFMonitorDB.raids.sp = spcheck:GetChecked() end)
	sptext:SetText(LFMonitor.SP_NAME)
	sptext:SetPoint("LEFT", spcheck, "RIGHT")
	sptext:SetTextColor(0, 1, 1 ,1)
	
	tkcheck:SetPoint("LEFT", spcheck, "TOPLEFT", 0, -30)
	tkcheck:SetScript("OnClick", function() LFMonitorDB.raids.tk = tkcheck:GetChecked() end)
	tktext:SetText(LFMonitor.TK_NAME)
	tktext:SetPoint("LEFT", tkcheck, "RIGHT")
	tktext:SetTextColor(0, 1, 1 ,1)
	
	zacheck:SetPoint("LEFT", tkcheck, "TOPLEFT", 0, -30)
	zacheck:SetScript("OnClick", function() LFMonitorDB.raids.za = zacheck:GetChecked() end)
	zatext:SetText(LFMonitor.ZA_NAME)
	zatext:SetPoint("LEFT", zacheck, "RIGHT")
	zatext:SetTextColor(0, 1, 1 ,1)
	
	bwlcheck:SetPoint("LEFT", zacheck, "TOPLEFT", 0, -30)
	bwlcheck:SetScript("OnClick", function() LFMonitorDB.raids.bwl = bwlcheck:GetChecked() end)
	bwltext:SetText(LFMonitor.BWL_NAME)
	bwltext:SetPoint("LEFT", bwlcheck, "RIGHT")
	bwltext:SetTextColor(0, 0.5, 1 ,1)
	
	mccheck:SetPoint("LEFT", bwlcheck, "TOPLEFT", 0, -30)
	mccheck:SetScript("OnClick", function() LFMonitorDB.raids.mc = mccheck:GetChecked() end)
	mctext:SetText(LFMonitor.MC_NAME)
	mctext:SetPoint("LEFT", mccheck, "RIGHT")
	mctext:SetTextColor(0, 0.5, 1 ,1)
	
	rqcheck:SetPoint("LEFT", mccheck, "TOPLEFT", 0, -30)
	rqcheck:SetScript("OnClick", function() LFMonitorDB.raids.rq = rqcheck:GetChecked() end)
	rqtext:SetText(LFMonitor.RQ_NAME)
	rqtext:SetPoint("LEFT", rqcheck, "RIGHT")
	rqtext:SetTextColor(0, 0.5, 1 ,1)
	
	aqcheck:SetPoint("LEFT", rqcheck, "TOPLEFT", 0, -30)
	aqcheck:SetScript("OnClick", function() LFMonitorDB.raids.aq = aqcheck:GetChecked() end)
	aqtext:SetText(LFMonitor.AQ_NAME)
	aqtext:SetPoint("LEFT", aqcheck, "RIGHT")
	aqtext:SetTextColor(0, 0.5, 1 ,1)
	
	ubrscheck:SetPoint("LEFT", aqcheck, "TOPLEFT", 0, -30)
	ubrscheck:SetScript("OnClick", function() LFMonitorDB.raids.ubrs = ubrscheck:GetChecked() end)
	ubrstext:SetText(LFMonitor.UBRS_NAME)
	ubrstext:SetPoint("LEFT", ubrscheck, "RIGHT")
	ubrstext:SetTextColor(0, 0.5, 1 ,1)
	
	zgcheck:SetPoint("LEFT", ubrscheck, "TOPLEFT", 0, -30)
	zgcheck:SetScript("OnClick", function() LFMonitorDB.raids.zg = zgcheck:GetChecked() end)
	zgtext:SetText(LFMonitor.ZG_NAME)
	zgtext:SetPoint("LEFT", zgcheck, "RIGHT")
	zgtext:SetTextColor(0, 0.5, 1 ,1)
	
	return frame

end

function LFMonitor:CreateOptions()

	local mainPanel = CreateMainPanel()
	local professionPanel = CreateProfessionPanel()
	local responsePanel = CreateResponsePanel()
	local generalPanel = CreateGeneralPanel()
	local appearancePanel = CreateAppearancePanel()
	local classPanel = CreateClassPanel()
	local customPanel = CreateCustomPanel()
	local raidsPanel = CreateRaidsPanel()
	
	mainPanel.name = "LFMonitor"
	mainPanel.default = function() StaticPopup_Show("LFMONITOR_DEFAULTS") end
	InterfaceOptions_AddCategory(mainPanel)

	appearancePanel.name = _G.APPEARANCE_LABEL
	appearancePanel.parent = "LFMonitor"
	appearancePanel.default = function() StaticPopup_Show("LFMONITOR_DEFAULTS") end
	InterfaceOptions_AddCategory(appearancePanel)

	professionPanel.name = LFMonitor.PROF
	professionPanel.parent = "LFMonitor"
	professionPanel.default = function() StaticPopup_Show("LFMONITOR_DEFAULTS") end
	InterfaceOptions_AddCategory(professionPanel)
	
	classPanel.name = _G.LFM_TITLE
	classPanel.parent = "LFMonitor"
	classPanel.default = function() StaticPopup_Show("LFMONITOR_DEFAULTS") end
	InterfaceOptions_AddCategory(classPanel)

	raidsPanel.name = _G.LFG_TYPE_RAID
	raidsPanel.parent = "LFMonitor"
	raidsPanel.default = function() StaticPopup_Show("LFMONITOR_DEFAULTS") end
	InterfaceOptions_AddCategory(raidsPanel)
	
	responsePanel.name = LFMonitor.RESPONSES
	responsePanel.parent = "LFMonitor"
	responsePanel.okay = function() LFMonitor:ResponseOptionsOkay() end
	responsePanel.cancel = function() LFMonitor:BuildTables() end
	responsePanel.default = function() StaticPopup_Show("LFMONITOR_DEFAULTS") end
	InterfaceOptions_AddCategory(responsePanel)	

	generalPanel.name = _G.GENERAL
	generalPanel.parent = "LFMonitor"
	generalPanel.default = function() StaticPopup_Show("LFMONITOR_DEFAULTS") end
	InterfaceOptions_AddCategory(generalPanel)

	customPanel.name = LFMonitor.CUSTOM_OPTIONS
	customPanel.parent = "LFMonitor"
	customPanel.default = function() StaticPopup_Show("LFMONITOR_DEFAULTS") end
	customPanel.okay = function() LFMonitor:CustomOptionsOkay() end

	InterfaceOptions_AddCategory(customPanel)

end