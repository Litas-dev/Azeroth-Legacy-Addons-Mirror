﻿-- *********************************
-- * Variable/Constant Declaration *
-- *********************************

LFMonitor.LFM_Update_Int = 20.0
LFMonitor.CL_Update_Int = 0.5
LFMonitor.testmode = false
LFMonitor.history = {}
LFMonitor.hindex = 1
LFMonitor.TFW_PATTERN = "^_$(%d+)(.+)_$(.+)_$(.+)%$$"

-- function to deepcopy a table, from http://lua-users.org/wiki/CopyTable
function LFMonitor:deepcopy(object)

    local lookup_table = {}
    local function _copy(object)

        if type(object) ~= "table" then

            return object

        elseif lookup_table[object] then

            return lookup_table[object]

        end

        local new_table = {}
        lookup_table[object] = new_table

        for index, value in pairs(object) do

            new_table[_copy(index)] = _copy(value)

        end

        return setmetatable(new_table, getmetatable(object))

    end

    return _copy(object)

end

--concatenate two tables to produce one table
local function concatenate(t1, t2)

	local ctable = LFMonitor:deepcopy(t1)

	for _, txt in ipairs(t2) do

		table.insert(ctable, txt)

	end

	return ctable

end

--build search tables
function LFMonitor:BuildTables()

	local profs = {"jc", "enc", "lw", "ins", "tlr", "bs", "alc", "eng", "misc"}
	local raids = {"eoe", "icc", "naxx", "ony", "os", "toc", "rs", "ulr", "voa", "bmj", "bt", "gl", "kz", "ml", "ssc", "sp", "tk", "za", "bwl", "mc", "rq", "aq", "ubrs", "zg"}
	local prof, proflist, raidlist = nil, {}, {}
	local dps, tank, healer, cc = 0, 0, 0, 0
	local classlist = {}

	for _, prof in ipairs(profs) do

		if (LFMonitorDB.professions[prof] == 1) then

			proflist = concatenate(proflist, LFMonitor[prof .. "txt"])

		end

	end

	LFMonitor.proflist = proflist

	for _, prof in ipairs(raids) do
	
		if (LFMonitorDB.raids[prof] == 1) then
		
			raidlist = concatenate(raidlist, LFMonitor[string.upper(prof)])
			
		end
		
	end
	
	if (LFMonitorDB.classes["dk"] == 1) then

		classlist = concatenate(concatenate(LFMonitor.DK_TXT, LFMonitor.DPS_TXT), LFMonitor.TANK_TXT)
		dps = 1
		tank = 1

	end

	if (LFMonitorDB.classes["dr"] == 1) then

		classlist = concatenate(classlist, LFMonitor.DR_TXT)

		if (dps == 0) then

			classlist = concatenate(classlist, LFMonitor.DPS_TXT)
			dps = 1

		end

		if (tank == 0) then

			classlist = concatenate(classlist, LFMonitor.TANK_TXT)
			tank = 1

		end

		classlist = concatenate(classlist, LFMonitor.HEALER_TXT)
		healer = 1

		classlist = concatenate(classlist, LFMonitor.CC_TXT)
		cc = 1

	end

	if (LFMonitorDB.classes["hu"] == 1) then

		classlist = concatenate(classlist, LFMonitor.HU_TXT)

		if (dps == 0) then

			classlist = concatenate(classlist, LFMonitor.DPS_TXT)
			dps = 1

		end

		if (cc == 0) then

			classlist = concatenate(classlist, LFMonitor.CC_TXT)
			cc = 1

		end

	end

	if (LFMonitorDB.classes["ma"] == 1) then

		classlist = concatenate(classlist, LFMonitor.MA_TXT)

		if (dps == 0) then

			classlist = concatenate(classlist, LFMonitor.DPS_TXT)
			dps = 1

		end

		if (cc == 0) then

			classlist = concatenate(classlist, LFMonitor.CC_TXT)
			cc = 1

		end

	end

	if (LFMonitorDB.classes["pa"] == 1) then

		classlist = concatenate(classlist, LFMonitor.PA_TXT)

		if (dps == 0) then

			classlist = concatenate(classlist, LFMonitor.DPS_TXT)
			dps = 1

		end

		if (tank == 0) then

			classlist = concatenate(classlist, LFMonitor.TANK_TXT)
			tank = 1

		end

		if (healer == 0) then

			classlist = concatenate(classlist, LFMonitor.HEALER_TXT)
			healer = 1

		end

		if (cc == 0) then

			classlist = concatenate(classlist, LFMonitor.CC_TXT)
			cc = 1

		end

	end

	if (LFMonitorDB.classes["pr"] == 1) then

		classlist = concatenate(classlist, LFMonitor.PR_TXT)

		if (dps == 0) then

			classlist = concatenate(classlist, LFMonitor.DPS_TXT)
			dps = 1

		end

		if (healer == 0) then

			classlist = concatenate(classlist, LFMonitor.HEALER_TXT)
			healer = 1

		end

		if (cc == 0) then

			classlist = concatenate(classlist, LFMonitor.CC_TXT)
			cc = 1

		end

	end

	if (LFMonitorDB.classes["ro"] == 1) then

		classlist = concatenate(classlist, LFMonitor.RO_TXT)

		if (dps == 0) then

			classlist = concatenate(classlist, LFMonitor.DPS_TXT)
			dps = 1

		end

	end

	if (LFMonitorDB.classes["sh"] == 1) then

		classlist = concatenate(classlist, LFMonitor.SH_TXT)

		if (dps == 0) then

			classlist = concatenate(classlist, LFMonitor.DPS_TXT)
			dps = 1

		end

		if (healer == 0) then

			classlist = concatenate(classlist, LFMonitor.HEALER_TXT)
			healer = 1

		end

	end

	if (LFMonitorDB.classes["wa"] == 1) then

		classlist = concatenate(classlist, LFMonitor.WA_TXT)

		if (dps == 0) then

			classlist = concatenate(classlist, LFMonitor.DPS_TXT)
			dps = 1

		end

	end

	if (LFMonitorDB.classes["wr"] == 1) then

		classlist = concatenate(classlist, LFMonitor.WR_TXT)

		if (dps == 0) then

			classlist = concatenate(classlist, LFMonitor.DPS_TXT)

		end

		if (tank == 0) then

			classlist = concatenate(classlist, LFMonitor.TANK_TXT)

		end

		if (cc == 0) then

			classlist = concatenate(classlist, LFMonitor.CC_TXT)

		end

	end

	LFMonitor.raidlist = raidlist
	LFMonitor.classlist = classlist

end

LFMonitor.sounds = {
	[1] = {
		file = "LOOTWINDOWCOINSOUND",
		name = LFMonitor.COINS,
		type = "game"
	},
	[2] = {
		file = "INTERFACESOUND_CHARWINDOWTAB",
		name = LFMonitor.WINDOW_TAB,
		type = "game"
	},
	[3] = {
		file = "INTERFACESOUND_GAMEMENUOPEN",
		name = LFMonitor.MENU_OPENING,
		type = "game"
	},
	[4] = {
		file = "igMiniMapOpen",
		name = LFMonitor.MINIMAP_OPENING,
		type = "game"
	},
	[5] = {
		file = "igSpellBookOpen",
		name = LFMonitor.SPELLBOOK_OPENING,
		type = "game"
	},
	[6] = {
		file = "igSpellBookClose",
		name = LFMonitor.SPELLBOOK_CLOSING,
		type = "game"
	},
	[7] = {
		file = "TalentScreenOpen",
		name = LFMonitor.TALENTS_OPENING,
		type = "game"
	},
	[8] = {
		file = "igQuestLogOpen",
		name = LFMonitor.QUEST_LOG_OPENING,
		type = "game"
	},
	[9] = {
		file = "Fishing Reel in",
		name = LFMonitor.FISHING,
		type = "game"
	},
	[10]= {
		file = "HumanExploration",
		name = LFMonitor.DISCOVERY,
		type = "game"
	},
	[11]= {
		file = "applause.wav",
		name = LFMonitor.APPLAUSE,
		type = "addon"
	},
	[12]= {
		file = "BEEPMULT.WAV",
		name = LFMonitor.BEEP,
		type = "addon"
	},
	[13]= {
		file = "CLICK10B.WAV",
		name = LFMonitor.CLICK,
		type = "addon"
	},
	[14]= {
		file = "dogbrk.wav",
		name = LFMonitor.DOG_BARKING,
		type = "addon"
	},
	[15]= {
		file = "pcmouseclick1.wav",
		name = LFMonitor.MOUSE_CLICK,
		type = "addon"
	},
	[16]= {
		file = "stapler2.wav",
		name = LFMonitor.STAPLER,
		type = "addon"
	}
}

LFMonitor.fonts = {
	[1] = {
		file = "Fonts\\FRIZQT__.TTF",
		name = LFMonitor.FONT_FRIZ
	},
	[2] = {
		file = "Fonts\\ARIALN.TTF",
		name = LFMonitor.FONT_ARIALN
	},
	[3] = {
		file = "Fonts\\skurri.ttf",
		name = LFMonitor.FONT_SKURRI
	},
	[4] = {
		file = "Fonts\\MORPHEUS.ttf",
		name = LFMonitor.FONT_MORPHEUS
	}
}

LFMonitor.timestamps = {
	[1] = {
		name = LFMonitor.TS_12HR1,
		format = "%I:%M"
	},
	[2] = {
		name = LFMonitor.TS_12HR2,
		format = "%I:%M:%S"
	},
	[3] = {
		name = LFMonitor.TS_12HR3,
		format = "%I:%M %p"
	},
	[4] = {
		name = LFMonitor.TS_12HR4,
		format = "%I:%M:%S %p"
	},
	[5] = {
		name = LFMonitor.TS_24HR1,
		format = "%H:%M"
	},
	[6] = {
		name = LFMonitor.TS_24HR2,
		format = "%H:%M:%S"
	}
}

LFMonitor.defaults = {
    professions = {
		jc = 0,
		enc = 0,
		lw = 0,
		ins = 0,
		tlr = 0,
		bs = 0,
		alc = 0,
		eng = 0
	},
	monitoring = {
		lf = 0,
		wtb = 0,
		lfm = 0,
		lfg = 0,
		misc = 0,
		lfw = 0,
		wts = 0
	},
	responses = {
		jc = LFMonitor.WHISPER_ME,
		enc = LFMonitor.WHISPER_ME,
		lw = LFMonitor.WHISPER_ME,
		ins = LFMonitor.WHISPER_ME,
		tlr = LFMonitor.WHISPER_ME,
		bs = LFMonitor.WHISPER_ME,
		alc = LFMonitor.WHISPER_ME,
		eng = LFMonitor.WHISPER_ME,
		lfg = LFMonitor.LFG_RESPONSE
	},
	options = {
		scl = 1,
		hinst = 1,
		rested = 0,
		combat = 0,
		soundon = 1,
		sound = 15,
		locked = 0,
		disabled = 0,
		trade = 1,
		timestamp = 5,
		basic = "",
		adv = "",
		basicesc = "",
		useclasscolours = 0,
		overrideraid = 0
	},
	craftlist = {
		jc = nil,
		enc = nil,
		lw = nil,
		ins = nil,
		tlr = nil,
		bs = nil,
		alc = nil
	},
	classes = {
		dk = 0,
		dr = 0,
		hu = 0,
		ma = 0,
		pa = 0,
		pr = 0,
		ro = 0,
		sh = 0,
		wa = 0,
		wr = 0
	},
	channels = {
		general = 1,
		trade = 1,
		guild = 0
	},
	alert = {
		font = {				
			index = 1,
			height = 14,
			timestamp = "ffffd200",
			player = "ff22ee55",
			text = "ffffffff"
		},
		backdrop = {
			background = "80000000",
			border = "ff87bdff"				
		},
		position = {
			x = -1,
			y = -1,
			width = 575,
			height = 100
		}
	},
	raids = {
		eoe = 0,
		icc = 0,
		naxx = 0,
		ony = 0,
		os = 0,
		toc = 0,
		rs = 0,
		ulr = 0,
		voa = 0,
		bmj = 0,
		bt = 0,
		gl = 0,
		kz = 0,
		ml = 0,
		ssc = 0,
		sp = 0,
		tk = 0,
		za = 0,
		bwl = 0,
		mc = 0,
		rq = 0,
		aq = 0,
		ubrs = 0,
		zg = 0
	}
}

LFMonitorDB = LFMonitor:deepcopy(LFMonitor.defaults)

-- Popup dialogues
StaticPopupDialogs["LFMONITOR_NOAUTOREPLY"] = {
	text = LFMonitor.CANNOT_SEND,
	button1 = _G.OKAY,
	timeout = 0,
	whileDead = 1,
	hideOnEscape = 1
}

StaticPopupDialogs["LFMONITOR_DEFAULTS"] = {
	text = LFMonitor.RESET_CONFIRM,
	button1 = _G.YES,
	button2 = _G.NO,
	OnAccept = function() LFMonitor:ResponseOptionsDefault() end,
	timeout = 0,
	whileDead = 1,
	hideOnEscape = 1
}

--no operation used for certain request types
LFMonitor.nop = {""}