﻿function LFMonitor:trim(s)

      return (string.gsub(s, "^%s*(.-)%s*$", "%1"))
	  
end

function LFMonitor:IsEdge(edge)

	local scale = UIParent:GetEffectiveScale()
	local x, y = GetCursorPosition()
	local xmin, xmax, ymin, ymax = 0, 0, 0, 0
	local isedge = nil
	
	if (edge == "LEFT") then

		xmin = LFMonitorDB.alert.position.x
		xmax = xmin + 10
		ymax = LFMonitorDB.alert.position.y
		ymin = ymax - LFMonitorDB.alert.position.height

	elseif (edge == "RIGHT") then

		xmax = LFMonitorDB.alert.position.x + LFMonitorDB.alert.position.width
		xmin = xmax - 10
		ymax = LFMonitorDB.alert.position.y
		ymin = ymax - LFMonitorDB.alert.position.height

	elseif (edge == "TOP") then

		xmin = LFMonitorDB.alert.position.x
		xmax = xmin + LFMonitorDB.alert.position.width
		ymax = LFMonitorDB.alert.position.y
		ymin = ymax - 10

	elseif (edge == "BOTTOM") then

		xmin = LFMonitorDB.alert.position.x
		xmax = xmin + LFMonitorDB.alert.position.width
		ymin = LFMonitorDB.alert.position.y - LFMonitorDB.alert.position.height
		ymax = ymin + 10

	end

	x = x / scale
	y = y / scale
	
	if	(((x >= xmin) and (x <= xmax)) and ((y >= ymin) and (y <= ymax))) then

		isedge = true

	end

	return isedge

end

function LFMonitor:BoolToString(value)

	local retval = value

	if type(value) == "boolean" then

		if value then

			retval = "True"

		else

			retval = "False"

		end

	end

	return retval

end

-- converts e.g. ff00ff00 to r=0, g=1, b=1, a=1
function LFMonitor:HexToRGB(hex)
	
    local ahex, rhex, ghex, bhex = string.sub(hex, 1, 2), string.sub(hex, 3, 4), string.sub(hex, 5, 6), string.sub(hex, 7, 8)
	return tonumber(rhex, 16)/255, tonumber(ghex, 16)/255, tonumber(bhex, 16)/255, tonumber(ahex, 16)/255

end

-- converts e.g. r=0, g=1, b=0, a=1 to ff00ff00
function LFMonitor:RGBToHex(r, g, b, a)

	r = r <= 1 and r >= 0 and r or 0
	g = g <= 1 and g >= 0 and g or 0
	b = b <= 1 and b >= 0 and b or 0
	a = a <= 1 and a >= 0 and a or 0
	
	return string.format("%02x%02x%02x%02x", a*255, r*255, g*255, b*255)

end

-- returns the player's class colour based on GUID

function LFMonitor:GetClassColour(guid)

	local _, class, _, _, _ = GetPlayerInfoByGUID(guid)
	local colour = LFMonitorDB.alert.font.player
	local cc = {}

	if (class) then

		cc = RAID_CLASS_COLORS[class]

		if (cc) then

			colour = LFMonitor:RGBToHex(cc.r, cc.g, cc.b, 1)

		end

	end

	return colour

end