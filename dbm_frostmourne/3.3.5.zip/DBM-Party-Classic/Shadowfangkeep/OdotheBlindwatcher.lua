local mod	= DBM:NewMod("OdotheBlindwatcher", "DBM-Party-Classic", 14)
local L		= mod:GetLocalizedStrings()

mod:SetRevision("20250929220131")
mod:SetCreatureID(4279)
mod:SetEncounterID(468)

mod:RegisterCombat("combat")
