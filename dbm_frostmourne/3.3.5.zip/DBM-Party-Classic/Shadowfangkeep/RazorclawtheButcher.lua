local mod	= DBM:NewMod("RazorclawtheButcher", "DBM-Party-Classic", 14)
local L		= mod:GetLocalizedStrings()

mod:SetRevision("20250929220131")
mod:SetCreatureID(3886)
mod:SetEncounterID(465)

mod:RegisterCombat("combat")
