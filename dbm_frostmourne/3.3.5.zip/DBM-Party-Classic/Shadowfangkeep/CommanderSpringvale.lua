local mod	= DBM:NewMod("CommanderSpringvale", "DBM-Party-Classic", 14)
local L		= mod:GetLocalizedStrings()

mod:SetRevision("20250929220131")
mod:SetCreatureID(4278)
mod:SetEncounterID(467)

mod:RegisterCombat("combat")
