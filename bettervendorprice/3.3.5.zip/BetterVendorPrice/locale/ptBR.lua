-- Generated file, do not edit.
local addon, _ns = ...

if (GetLocale() ~= 'ptBR') then return end

local L = _G[addon].L

