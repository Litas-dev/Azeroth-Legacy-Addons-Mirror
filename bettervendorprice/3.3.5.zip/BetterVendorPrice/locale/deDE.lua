-- Generated file, do not edit.
local addon, _ns = ...

if (GetLocale() ~= 'deDE') then return end

local L = _G[addon].L
L[" (% |4seller:sellers;), "] = "(% |4seller:Verkäufer;),"
L[" (%+ sellers), "] = "(%+ Verkäufer),"
L[" (curr. full stack of %d)"] = "(Akt. voller Stapel von %d)"
L[" (current stack of %d)"] = "(Aktueller Stapel von %d)"
L[" (full stack of %d)"] = "(Voller Stapel von %d)"
L[" (item doesn't stack)"] = "(Item stapelt sich nicht)"
L[" (per item)"] = "(pro Stück)"
L[" (per; stacks to %d)"] = "(pro; stapelt bis %d)"
L["% |4item:total items;"] = "% |4item:Insgesamt; "
L["AHDB buyout"] = "AHDB Sofortkauf"
L["AHDB last scan: % |4auction:auctions;"] = "AHDB Letzter Scan: % |4auction:Auktionen;"
L["AHDB minbid"] = "AHDB Mindestgebot"
L["Better Vendor Price"] = "BetterVendorPrice"
L["Better Vendor Price bug report open: "] = "BetterVendorPrice Fehlerbericht offen:"
L["Better Vendor Price options"] = "BetterVendorPrice Optionen"
L["Bug report from slash command"] = "Fehlerbericht vom Slash Befehl"
L["Debug level"] = "Fehlersuchlevel"
L["Development, troubleshooting and advanced options:"] = "Entwicklung, Problemlösung und erweiterte Optionen:"
L["Get Auction House DataBase (|cFF99E5FFAHDB|r) v0.12 or newer to see auction information on the toolip!"] = "Lade Dir Auction House DataBase (|cFF99E5FFAHDB|r) v0.12 oder neuer herunter um Auktionsinformationen im Tooltip angezeigt zu bekommen."
L["Get Information to submit a bug."] = "Erhalte Informationen um einen Fehler einzureichen."
L["Please submit on discord or on https://|cFF99E5FFbit.ly/vendorbug|r  or email"] = "Bitte im Discord, auf https://|cFF99E5FFbit.ly/vendorbug|r oder per E-Mail einreichen."
L["Sets the debug level"] = "Ändert das Fehlersuchlevel"
L["These options let you control the behavior of BetterVendorPrice"] = "Mit diesen Optionen kannst du das Verhalten von BetterVendorPrice kontrollieren."
L["Vendors for:"] = "Verkauft für:"

