-- Generated file, do not edit.
local addon, _ns = ...

if (GetLocale() ~= 'itIT') then return end

local L = _G[addon].L
L[" (% |4seller:sellers;), "] = "(% |4mercante:mercanti;), "
L[" (%+ sellers), "] = "(%+ mercanti), "
L[" (curr. full stack of %d)"] = "(att. cumulo pieno di %d)"
L[" (curr. stack of %d/%d)"] = "(att. cumulo di %d/%d)"
L[" (current stack of %d)"] = "(attuale cumulo di %d)"
L[" (full stack of %d)"] = "(cumulo pieno di %d)"
L[" (item doesn't stack)"] = "(l'oggetto non è cumulabile)"
L[" (per item)"] = "(per oggetto)"
L[" (per; stacks to %d)"] = "(per; cumulo di %d)"
L["% |4item:total items;"] = "% |4oggetto:totale oggetti;"
L["AHDB buyout"] = "AHDB compra"
L["AHDB last scan: % |4auction:auctions;"] = "AHDB ultima scansione: % |4asta:aste;"
L["AHDB minbid"] = "AHDB offerta minima"
L["Better Vendor Price"] = "Miglior prezzo del Venditore"
L["Better Vendor Price bug report open: "] = "Miglior prezzo del Venditore comunica un bug:"
L["Better Vendor Price options"] = "Miglior prezzo del Venditore opzioni"
L["Bug Report"] = "Segnala un Bug"
L["Bug report from slash command"] = "Segnala un Bug per un comando slash"
L["Debug level"] = "livello Debug"
L["Development, troubleshooting and advanced options:"] = "Sviluppo, risoluzione dei problemi e opzioni avanzate:"
L["Get Information to submit a bug."] = "Ottieni Informazioni per segnalare un bug"
L["Vendors for:"] = "Mercanti per:"

