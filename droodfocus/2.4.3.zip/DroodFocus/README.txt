To open configuration :		"/droodfocus config"
To reset configuration :	"/droodfocus reset"
To change the skin, just overwrite file "DroodFocusSkin.lua" with one come from the skins directory.

Description of skin datas (with the default skin "WoW" here)

---------------------
-- SKIN DATA 2.6.5 --
---------------------
-- main frame
SKIN_uiWidth = 256;   -- The width and height of the texture
SKIN_uiHeight = 128;  -- (remember all texture size must be a multiple of 16)
SKIN_uiTexture = "Interface\\AddOns\\DroodFocus\\arts\\UIborder"; -- file of the texture to use, blank == no texture
SKIN_uiTextureMode = "BLEND"; -- alphablending mode for the texture

-- Energy bar
SKIN_uiDroodFocusEnergyWidth = 119; -- width and height of the statubar
SKIN_uiDroodFocusEnergyHeight = 18; -- (no restriction for sizes)
SKIN_uiDroodFocusEnergyX = 98;      -- position of the statusbar, relative to the top left corner of main texture
SKIN_uiDroodFocusEnergyY = -43;
SKIN_uiDroodFocusEnergyTexture = "Interface\\TargetingFrame\\UI-StatusBar" -- file of the texture (i use texture from the game here)
SKIN_uiDroodFocusEnergyColor = {r=1,g=1,b=0,a=1};       -- color of the statusbar
SKIN_uiDroodFocusEnergyBackColor = {r=0,g=0,b=0,a=0.5}; -- color of the background
SKIN_uiDroodFocusEnergyTextColor = {r=1,g=1,b=1,a=1};   -- color of the text
SKIN_uiDroodFocusEnergyTextSize = 13;                   -- font size
SKIN_uiDroodFocusEnergyTextVisible = true;              -- visibility (true or false)
SKIN_uiDroodFocusEnergyTextAlign = "CENTER";		-- anchor point relative to statutbar (CENTER,TOP,BOTTOM,LEFT,RIGTH and TOPLEFT,TOPRIGHT,...)
SKIN_uiDroodFocusEnergyTextX = 0;			-- offset x
SKIN_uiDroodFocusEnergyTextY = 0;			-- offset y
SKIN_uiDroodFocusEnergyOrientation = "HORIZONTAL";      -- orientation for filling bar
SKIN_uiDroodFocusRageColor = {r=1,g=0,b=0,a=1};         -- Color of statusbar in bear
SKIN_uiDroodFocusRageBackColor = {r=0,g=0,b=0,a=0.5};   -- Color of background statusbar in bear
SKIN_uiDroodFocusRageTextColor = {r=1,g=1,b=1,a=1};     -- color of text in bear
SKIN_uiDroodFocusEnergyBorder = true, -- true or false - add border to the statusbar

-- tick bar (same as energy bar)
SKIN_uiDroodFocusTickWidth = 119;
SKIN_uiDroodFocusTickHeight = 10;
SKIN_uiDroodFocusTickX = 98;
SKIN_uiDroodFocusTickY = -62;
SKIN_uiDroodFocusTickTexture = "Interface\\TargetingFrame\\UI-StatusBar"
SKIN_uiDroodFocusTickColor = {r=0,g=1,b=0,a=1};
SKIN_uiDroodFocusTickBackColor = {r=0,g=0,b=0,a=0.5};
SKIN_uiDroodFocusTickTextColor = {r=1,g=1,b=1,a=1};
SKIN_uiDroodFocusTickTextSize = 9;
SKIN_uiDroodFocusTickTextVisible = true;
SKIN_uiDroodFocusTickTextAlign = "CENTER";		-- anchor point relative to statutbar (CENTER,TOP,BOTTOM,LEFT,RIGTH and TOPLEFT,TOPRIGHT,...)
SKIN_uiDroodFocusTickTextX = 0;			-- offset x
SKIN_uiDroodFocusTickTextY = 0;			-- offset y
SKIN_uiDroodFocusTickOrientation = "HORIZONTAL";
SKIN_uiDroodFocusTickBorder = true, -- true or false - add border to the statusbar

-- Mana bar (same as energy bar)
SKIN_uiDroodFocusManaWidth = 119;
SKIN_uiDroodFocusManaHeight = 10;
SKIN_uiDroodFocusManaX = 98;
SKIN_uiDroodFocusManaY = -73;
SKIN_uiDroodFocusManaTexture = "Interface\\TargetingFrame\\UI-StatusBar"
SKIN_uiDroodFocusManaColor = {r=0,g=0,b=1,a=1};
SKIN_uiDroodFocusManaBackColor = {r=0,g=0,b=0,a=0.5};
SKIN_uiDroodFocusManaTextColor = {r=1,g=1,b=1,a=1};
SKIN_uiDroodFocusManaTextSize = 9;
SKIN_uiDroodFocusManaTextVisible = true;
SKIN_uiDroodFocusManaTextAlign = "CENTER";		-- anchor point relative to statutbar (CENTER,TOP,BOTTOM,LEFT,RIGTH and TOPLEFT,TOPRIGHT,...)
SKIN_uiDroodFocusManaTextX = 0;			-- offset x
SKIN_uiDroodFocusManaTextY = 0;			-- offset y
SKIN_uiDroodFocusManaOrientation = "HORIZONTAL";
SKIN_uiDroodFocusManaBorder = true, -- true or false - add border to the statusbar

-- combo bar background (texture use for combo point background)
SKIN_comboBarWidth = 128; -- witdh / eight of texture
SKIN_comboBarHeight = 32;
SKIN_comboBarTexture = "Interface\\AddOns\\DroodFocus\\arts\\combobar"; -- file
SKIN_comboBarTextureMode = "BLEND"; -- alphablending mode
SKIN_comboBarX = 81; -- position relative to the top left corner of main texture
SKIN_comboBarY = -14;
SKIN_comboBarLevel = 2; -- FrameLevel of frame, lowers levels always shows under highers levels
SKIN_comboBarVisible = true; -- visibility

-- combo point
SKIN_comboPtWidth = 26; -- width / eigth of combo point
SKIN_comboPtHeight = 26;
SKIN_comboPtTexture = "Interface\\AddOns\\DroodFocus\\arts\\combo"; -- texture
SKIN_comboPtTextureMode = "BLEND";
SKIN_comboPtX = 83; -- position relative to the top left corner of main texture
SKIN_comboPtY = -16;
SKIN_comboPtOffsetX = 23.5; -- offset of each combo point, the fifth combo point will be placed a 23.5*5 pixel from the first
SKIN_comboPtOffsetY = 0;    -- same as offset X
SKIN_comboPtLevel = 3;
SKIN_comboPtVisible = true;

-- clear cast light
SKIN_clearCastWidth = 128; -- width / eight
SKIN_clearCastheight = 128;
SKIN_clearCastX = 67; -- position relative to the top left corner of main texture
SKIN_clearCastY = -64;
SKIN_clearCastTexture = "Interface\\AddOns\\DroodFocus\\arts\\img_clearcast";
SKIN_clearCastTextureMode = "ADD";
SKIN_clearCastAlpha = 0.95; -- transparency of the light (0 to 1, 0 = invisible)
SKIN_clearCastSize = 1; -- size multiplier
SKIN_clearCastLevel = 1; -- frame level

-- portrait frame (cat,bear, rogue image)
SKIN_portraitWidth = 128; -- width/eight
SKIN_portraitHeight = 128;
SKIN_portraitX = 67; -- position relative to the top left corner of main texture
SKIN_portraitY = -64;
SKIN_portraitTextureMode = "BLEND";
SKIN_portraitTextureCat = "Interface\\AddOns\\DroodFocus\\arts\\img_catform";     -- texture for cat
SKIN_portraitTexturebear = "Interface\\AddOns\\DroodFocus\\arts\\img_bearform";   -- texture for bear
SKIN_portraitTextureRogue = "Interface\\AddOns\\DroodFocus\\arts\\img_rogueform"; -- texture for rogue
SKIN_portraitLevel = 2; -- frame level
SKIN_portraitVisible = true; -- visibility

SKIN_Border = true ; -- true or false, for black border on statusbars

