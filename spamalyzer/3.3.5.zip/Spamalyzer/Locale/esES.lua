﻿local ADDON_NAME = ...

local L = LibStub("AceLocale-3.0"):NewLocale(ADDON_NAME, "esES", false)

if not L then return end

L["Bytes"] = true -- Needs review
L["ChatFrame1"] = true -- Needs review
L["ChatFrame2"] = true -- Needs review
L["ChatFrame3"] = true -- Needs review
L["ChatFrame4"] = true -- Needs review
L["ChatFrame5"] = true -- Needs review
L["ChatFrame6"] = true -- Needs review
L["ChatFrame7"] = true -- Needs review
L["Display Known"] = "Mostrar conocidos" -- Needs review
L["Display Unknown"] = "Mostrar Desconocido" -- Needs review
L["Display messages from known AddOns in the ChatFrame."] = "Mensajes de la pantalla de AddOns conocido en el ChatFrame." -- Needs review
L["Display messages from unknown AddOns in the ChatFrame."] = "Mensajes de la pantalla de AddOns desconocido en el ChatFrame." -- Needs review
L["Draws the icon on the minimap."] = "Señala el icono en el minimapa." -- Needs review
L["Hide Hint Text"] = "Ocultar texto de sugerencia"
L["Hides the hint text at the bottom of the tooltip."] = "Oculta el texto de pista en la parte inferior de la descripción." -- Needs review
L["Input"] = "Entrada" -- Needs review
L["Left-click to change datafeed type."] = "Click izquierdo para cambiar el tipo de datafeed."
L["Messages"] = "Mensajes" -- Needs review
L["Middle-click to change tooltip mode."] = "Click central para cambiar el modo de tooltip."
L["Minimap Icon"] = "Icono de minimapa"
L["Move the slider to adjust the scale of the tooltip."] = "Mueva el control deslizante para ajustar la escala de la descripción."
L["Move the slider to adjust the tooltip fade time."] = "Mueva el control deslizante para ajustar el desvanecimiento de la descripción."
L["Output"] = "Salida" -- Needs review
L["Received"] = "Recibido" -- Needs review
L["Right-click for options."] = "Click derecho para ver las opciones."
L["Scale"] = "Escala" -- Needs review
L["Secondary location to display AddOn messages."] = "Ubicación secundaria para mostrar mensajes de addon."
L["Sent"] = "Enviado" -- Needs review
L["Shift+Left-click to clear data."] = "Shift + click izquierdo para borrar datos."
L["Show traffic statistics at the bottom of the tooltip."] = "Mostrar las estadísticas de tráfico en la parte inferior de la descripción." -- Needs review
L["Timer"] = "Temporizador" -- Needs review
L["Toggle recording of %s AddOn messages."] = "Activar la grabación de%s mensajes de addon."
L["Tooltip"] = true -- Needs review
L["Tracking"] = "Rastreo" -- Needs review
