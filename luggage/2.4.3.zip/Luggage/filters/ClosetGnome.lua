if not ClosetGnome then return end

local L = LibStub("AceLocale-3.0"):GetLocale("Luggage")
local ClosetGnomeSets = {}

Luggage:RegisterFilter("ClosetGnome", {
   name = "ClosetGnome",
   tooltipText = L["Filter by ClosetGnome Set"],
   values = function()
      local sets = ClosetGnome.db.char.set
      for setName, set in pairs(sets) do
         ClosetGnomeSets[setName] = {name = setName}
      end
      return ClosetGnomeSets
   end,
   func = function(bag, itemTable, setName)
      local set = ClosetGnome.db.char.set[setName]
      for _, itemLink in pairs(set) do
         if itemLink == itemTable.link then
            return true
         end
      end
   end,
})