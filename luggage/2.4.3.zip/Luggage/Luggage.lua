Luggage = LibStub("AceAddon-3.0"):NewAddon("Luggage", "AceEvent-3.0", "AceHook-3.0")
--Luggage.db = LibStub:GetLibrary("AceDB-3.0"):New("LuggageDB")
local libBaggage = LibStub:GetLibrary("LibBaggage-1.0")


local L = LibStub("AceLocale-3.0"):GetLocale("Luggage")

Luggage.bags = {}
Luggage.filters = {}

local function CreateDummyBagFrames()
   local dummyBagFrames = {}
   local frame
   for i=0,NUM_BAG_SLOTS+NUM_BANKBAGSLOTS do
      frame = CreateFrame("Frame", "Luggage_DummyBag_"..i, UIParent)
      frame:SetID(i)
      dummyBagFrames[i] = frame
   end
   frame = CreateFrame("Frame", "Luggage_DummyBag_Bank", UIParent)
   frame:SetID(-1)
   dummyBagFrames[-1] = frame
   Luggage.dummyBagFrames = dummyBagFrames
end

function Luggage:OnInitialize() 
   Luggage.db = LibStub:GetLibrary("AceDB-3.0"):New("LuggageDB")
   Luggage.db:RegisterDefaults(Luggage.defaultOptions)
   CreateDummyBagFrames()
	LibStub("AceConfigRegistry-3.0"):RegisterOptionsTable("Luggage", Luggage.GetOptionsTable)
	LibStub("AceConfigDialog-3.0"):AddToBlizOptions("Luggage", "Luggage", nil)   
end

function Luggage:OnEnable()
   libBaggage.RegisterCallback(Luggage, "LibBaggage_ItemAdded")
   libBaggage.RegisterCallback(Luggage, "LibBaggage_ItemRemoved")
   libBaggage.RegisterCallback(Luggage, "LibBaggage_FullRescanDone")
   libBaggage.RegisterCallback(Luggage, "LibBaggage_ItemLockChanged")
   self:RegisterEvent("BANKFRAME_OPENED")
   self:RegisterEvent("BANKFRAME_CLOSED")
   self:RegisterEvent("GUILDBANKFRAME_OPENED")
   self:RegisterEvent("GUILDBANKFRAME_CLOSED")
   self:RegisterEvent("MAIL_SHOW")
   self:RegisterEvent("MAIL_CLOSED")
   self:RegisterEvent("AUCTION_HOUSE_SHOW")
   self:RegisterEvent("AUCTION_HOUSE_CLOSED")
   self:RegisterEvent("MERCHANT_SHOW")
   self:RegisterEvent("MERCHANT_CLOSED")
   self:SetBlizzardBankEnabled(Luggage.db.profile.blizzardBankEnabled)
   self:SetBlizzardBagsEnabled(Luggage.db.profile.blizzardBagsEnabled)
   self:BuildBagBars()
   self:LocalizeBindings()
end

function Luggage:OnDisable()
   libBaggage.UnregisterCallback(Luggage, "LibBaggage_ItemAdded")
   libBaggage.UnregisterCallback(Luggage, "LibBaggage_ItemRemoved")
   libBaggage.UnregisterCallback(Luggage, "LibBaggage_FullRescanDone")
end

function Luggage:LocalizeBindings()
   BINDING_HEADER_Luggage = "Luggage"
   BINDING_NAME_LUGGAGE_TOGGLE_ALL_BAGS = L["Toggle all bags"]
   for i=1,5 do
      _G[("BINDING_NAME_LUGGAGE_TOGGLE_SET_%d"):format(i)] = L["Toggle bag set %s"]:format(i)
   end
end

function Luggage:BANKFRAME_OPENED()
   for index, bagbar in pairs(self.bagbars) do
      if bagbar.savedVars.showAtBank then
         bagbar:Show()
      end
   end
   self:ToggleBags("showAtBank", true)
end

function Luggage:BANKFRAME_CLOSED()
   for index, bagbar in pairs(self.bagbars) do
      if bagbar.savedVars.showAtBank then
         bagbar:Hide()
      end
   end
   self:ToggleBags("showAtBank", false)
end

function Luggage:GUILDBANKFRAME_OPENED()
   for index, bagbar in pairs(self.bagbars) do
      if bagbar.savedVars.showAtGuildBank then
         bagbar:Show()
      end
   end
   self:ToggleBags("showAtGuildbank", true)
end

function Luggage:GUILDBANKFRAME_CLOSED()
   for index, bagbar in pairs(self.bagbars) do
      if bagbar.savedVars.showAtGuildbank then
         bagbar:Hide()
      end
   end
   self:ToggleBags("showAtGuildbank", false)
end

function Luggage:MAIL_SHOW()
   self:ToggleBags("showAtMailbox", true)
end

function Luggage:MAIL_CLOSED()
   self:ToggleBags("showAtMailbox", false)
end

function Luggage:AUCTION_HOUSE_SHOW()
   self:ToggleBags("showAtAuctionHouse", true)
end

function Luggage:AUCTION_HOUSE_CLOSED()
   self:ToggleBags("showAtAuctionHouse", false)
end

function Luggage:MERCHANT_SHOW()
   self:ToggleBags("showAtVendor", true)
end

function Luggage:MERCHANT_CLOSED()
   self:ToggleBags("showAtVendor", false)
end

function Luggage:ToggleBags(key, open)
   for index, bag in pairs(self.bags) do
      if bag.savedVars[key] then
         if open then
            bag:Show()
         else
            bag:Hide()
         end
      end
   end
end

local openSets = {}
function Luggage:ToggleAllBags()
   local key = "showOnToggleAll"
   local show = not openSets[key]
   Luggage:ToggleBags(key, show)
   openSets[key] = (not openSets[key]) or nil
end

function Luggage:ToggleBagSet(setNumber)
   local key = ("showOnToggleSet%d"):format(setNumber)
   local show = not openSets[key]
   Luggage:ToggleBags(key, show)
   openSets[key] = (not openSets[key]) or nil
end

function Luggage:LibBaggage_ItemLockChanged(event, bagID, slotID)
   for i, bag in ipairs(self.bags) do
      bag:UpdateItemLock(bagID, slotID)
   end
end


function Luggage:NewBagBar()
   StaticPopupDialogs["Luggage_NewBagBar"] = {
      text = L["Please enter a name for the new bag bar:"],
      button1 = L["Accept"],
      button2 = L["Cancel"],
      OnShow = function()
         getglobal(this:GetName().."EditBox"):SetText("")
      end,
      OnAccept = function()
         local name = getglobal(this:GetParent():GetName().."EditBox"):GetText()
         if name ~= "" then
         end
      end,
      hasEditBox = 1,
      timeout = 0,
      whileDead = 1,
      hideOnEscape = 1
   }
   StaticPopup_Show ("Luggage_NewBagBar")
end

function Luggage:BuildBagBars()
   local bagbars = self.db.profile.bagbars
   if self.bagbars then
      self:UpdateBagBars()
      return
   end
   self.bagbars = {}
   for index, bagBarSV in pairs(bagbars) do
      if index ~= "**" then
         table.insert(self.bagbars, Luggage.BagBar:New(index, bagBarSV))
      end
   end
end

function Luggage:UpdateBagBars()
end

function Luggage:RegisterBagForEvents(bag)
   table.insert(self.bags, bag)
   for item in libBaggage:AllItems() do
      if bag:ContainsItem(item) then
         bag:AddItem(item)
      end
   end
end

function Luggage:UnregisterBagForEvents(bag)
   for i, myBag in ipairs(self.bags) do
      if myBag == bag then
         table.remove(self.bags, i)
         break
      end
   end
end

Luggage.emptySlot = {}
function Luggage:GetEmptySlotTable(bag)
   local empty = self.emptySlot
   empty.bagID, empty.slotID = libBaggage:GetFreeSlot(bank)
   local locationFilter = bag.savedVars.filters.Location
   if locationFilter[2] == false and locationFilter[1] ~= false then
      empty.stackCount = libBaggage:GetTotalFreeBankSpace()
   elseif locationFilter[2] ~= false and locationFilter[1] == false then
      empty.stackCount = libBaggage:GetTotalFreeMainBagSpace()
   end
   if empty.stackCount == 0 then
      return nil
   else
      return empty
   end
end

function Luggage:RegisterFilter(id, filterTable, override)
   local filters = self.filters
   if filters[id] and not override then
      return false
   end
   assert(type(filterTable) == "table")
   filters[id] = filterTable
end


function Luggage:OnIconChosen(icon, name)
   if icon then
      self.iconCallback(icon, name)
   end
   self.iconCallback = nil
   self.iconCallBackArgs = nil
end

function Luggage:AskUserForIconAndName(callback)
   self.iconCallback = callback
   local dialog = self.dialog
   if not dialog then
      self:CreateDialog()
      dialog = self.dialog
   end
   dialog:Show()
end

-- Source: http://lua-users.org/wiki/StringRecipes
-- Compatibility: Lua-5.0
local function Split(str, delim, maxNb)
    -- Eliminate bad cases...
    if string.find(str, delim) == nil then
        return { str }
    end
    if maxNb == nil or maxNb < 1 then
        maxNb = 0    -- No limit
    end
    local result = {}
    local pat = "(.-)" .. delim .. "()"
    local nb = 0
    local lastPos
    for part, pos in string.gmatch(str, pat) do
        nb = nb + 1
        result[nb] = part
        lastPos = pos
        if nb == maxNb then break end
    end
    -- Handle the last field
    if nb ~= maxNb then
        result[nb + 1] = string.sub(str, lastPos)
    end
    return result
end

-- A layout that allocates 10% of the height for the first object and
-- 90% for the second
LibStub("AceGUI-3.0"):RegisterLayout("10-90-Height",
   function(content, children)
      local child1 = children[1]
      local child2 = children[2]
      if child1 and child2 then
         child1:SetWidth(content:GetWidth() or 0)
         child1:SetHeight(0.1*content:GetHeight() or 0)
         child1.frame:ClearAllPoints()
         child1.frame:SetPoint("TOPLEFT", content, "TOPLEFT")
         child1.frame:SetPoint("TOPRIGHT", content, "TOPRIGHT")
         child1.frame:Show()

         child2:SetWidth(content:GetWidth() or 0)
         -- Only 88%, otherwise it causes overlap in the outer frame
         child2:SetHeight(0.88*content:GetHeight() or 0)
         child2.frame:ClearAllPoints()
         child2.frame:SetPoint("TOPLEFT", child1.frame, "BOTTOMLEFT")
         child2.frame:SetPoint("TOPRIGHT", child1.frame, "BOTTOMRIGHT")
         child2.frame:Show()
		end      
   end
)

function Luggage:CreateDialog()
   local iconTree = self.IconTree
   self.IconTree:Create()
   local acegui = LibStub("AceGUI-3.0")
   local dialog = acegui:Create("Frame")
   local tree = acegui:Create("TreeGroup")
   local scroll = acegui:Create("ScrollFrame")
   local matrix = acegui:Create("ButtonMatrix")
   local nameBox =acegui:Create("EditBox")
   local searchBox =acegui:Create("EditBox")
   local treeTable = iconTree:GetTableForTreeView()
   dialog:SetLayout("10-90-Height")
   tree:SetLayout("10-90-Height")
   scroll:SetLayout("Fill")
   tree:SetTree(treeTable)
   nameBox:SetLabel(L["Enter Name:"])
   searchBox:SetLabel(L["Search Icon List:"])
   matrix.userdata.tree = tree
   tree:SetCallback("OnGroupSelected", 
      function(self, event, value) 
         local buttonTable = iconTree:GetButtonTableForPath(Split(self.localstatus.selected, "\001"))
         matrix:SetButtonTable(buttonTable)
      end
   )
   dialog:SetCallback("OnClose", 
      function()
         Luggage:OnIconChosen(matrix.status.selectedButtonValue, nameBox.lasttext)
         nameBox:SetText("")
      end
   )
   searchBox:SetCallback("OnEnterPressed",
      function(editBox, event, searchText)
         if string.len(searchText) == 0 then return end
         local buttonTable = iconTree:SearchAndConvertToButtonTable(searchText)
         matrix:SetButtonTable(buttonTable)
      end
   )
   scroll:AddChild(matrix)
   tree:AddChild(searchBox)
   tree:AddChild(scroll)
   dialog:AddChild(nameBox)
   dialog:AddChild(tree)
   self.dialog = dialog
end

function Luggage:SetBlizzardBankEnabled(value)
   Luggage.db.profile.blizzardBankEnabled = value
   if value then
      self:EnableBlizzardBank()
   else
      self:DisableBlizzardBank()
   end
end

function Luggage:EnableBlizzardBank()
   UIPanelWindows["BankFrame"] = { area = "left", pushable = 6, width = 425 };
   BankFrame:ClearAllPoints()
   BankFrame:Hide()
end

function Luggage:DisableBlizzardBank()
   UIPanelWindows["BankFrame"] =	nil
   BankFrame:ClearAllPoints()
   BankFrame:SetPoint("BOTTOMRIGHT", UIParent, "TOPLEFT", -100, 100)
end

function Luggage:SetBlizzardBagsEnabled(value)
   Luggage.db.profile.blizzardBagsEnabled = value
   if value then
      self:EnableBlizzardBags()
   else
      self:DisableBlizzardBags()
   end
end

function Luggage:EnableBlizzardBags()
   self:Unhook("OpenBackpack")
   self:Unhook("ToggleBackpack")
   self:Unhook("OpenBag")
   self:Unhook("ToggleBag")
   self:Unhook("OpenAllBags")
end

function Luggage:DisableBlizzardBags()
   self:RawHook("OpenBackpack", "DevNull", true )
   self:RawHook("ToggleBackpack", "DevNull", true )
   self:RawHook("OpenBag", "DevNull", true )
   self:RawHook("ToggleBag", "DevNull", true )
   self:RawHook("OpenAllBags", "DevNull", true )
   for i=1, NUM_CONTAINER_FRAMES, 1 do
      local frame = getglobal("ContainerFrame"..i);
      frame:Hide()
   end
end

function Luggage:DevNull()
end

function Luggage:FullUpdate()
   for i, bag in ipairs(self.bags) do
      bag:Clear()
   end
   for item in libBaggage:AllItems() do
      self:SortItem(item)
   end
   for i, bag in ipairs(self.bags) do
      bag:UpdateItemButtons()
   end
end

local bagsInNeedOfUpdate = {}
function Luggage:SortItem(item)
   for i, bag in ipairs(self.bags) do
      if bag:ContainsItem(item) then
         bag:AddItem(item)
         bagsInNeedOfUpdate[bag] = true
      end
      if bag.savedVars.showEmptySlot then
         bagsInNeedOfUpdate[bag] = true
      end
      bag:UpdateBagSpace()
   end
   for bag in pairs(bagsInNeedOfUpdate) do
      bag:UpdateItemButtons()
      bagsInNeedOfUpdate[bag] = nil
   end
end

function Luggage:UnsortItem(item)
   for i, bag in ipairs(self.bags) do
      bag:RemoveItem(item)
      bag:UpdateBagSpace()
   end
end

function Luggage:LibBaggage_ItemAdded(event, bagID, slotID)
   local item = libBaggage:GetItem(bagID, slotID)
   if type(slotID) ~= "number" then return end
   self:SortItem(item)
end

function Luggage:LibBaggage_ItemRemoved(event, item)
   if type(item.slotID) ~= "number" then return end
   self:UnsortItem(item)
end

function Luggage:LibBaggage_FullRescanDone(event)
   self:FullUpdate()
end
