local Bar = {}
local L = LibStub("AceLocale-3.0"):GetLocale("Luggage")

function Bar:New(name, savedVars)
   local newBagBar = {
      savedVars = savedVars,
      name = name,
      bags = {},
   }
   setmetatable(newBagBar, {__index = self})
   newBagBar:Create()
   return newBagBar
end

function Bar:Create()
   self.tabbedFrame = Luggage.TabbedFrame:New("Luggage_"..self.name)
   local tabbedFrame = self.tabbedFrame
   tabbedFrame:SetPoint(self.savedVars.point, UIParent, self.savedVars.point, self.savedVars.x, self.savedVars.y)
   tabbedFrame.FrameMovedCallback = function() self:SavePosition() end
   tabbedFrame:AdjustSize()
   tabbedFrame.GetDropdownTable = function(tabbedFrame, tabButton)
      local menu = {
         {
            text = L["Add Tab"],
            func = function()
               local callback = function(icon, tabName)
                  local tabSVs = self.savedVars.tabs
                  local newTabSV = tabSVs[#tabSVs+1]
                  newTabSV.icon = icon
                  newTabSV.name = tabName
                  tabbedFrame:AddTab(icon, tabName)
                  self:AddBag(#tabSVs, newTabSV.bags[1])
               end
               Luggage:AskUserForIconAndName(callback)
            end,
            tooltipTitle = L["Add Tab"],
            tooltipText = L["Add one tab to this bag bar"],
         },
         {
            text = L["Edit Tab"],
            tooltipTitle = L["Edit Tab"],
            tooltipText = L["Change icon and name"],
            func = function()
               local callback = function(icon, name)
                  tabbedFrame:SetIcon(tabButton:GetID(), icon)
                  tabbedFrame:SetName(tabButton:GetID(), name)
                  self.savedVars.tabs[tabButton:GetID()].icon = icon
                  self.savedVars.tabs[tabButton:GetID()].name = name
               end
               Luggage:AskUserForIconAndName(callback)
            end
         },
         {
            text = L["Remove Tab"],
            func = function()
               if #self.savedVars.tabs == 1 then
                  DEFAULT_CHAT_FRAME:AddMessage(L["Can't remove the last tab. Edit this one or add a new tab before deleting it."])
                  return
               end
               StaticPopupDialogs["Luggage_DeleteTab"] = {
                  text = L["Warning: This will delete this tab and all bags belonging to it! Are you sure?"],
                  button1 = L["Remove Tab"],
                  button2 = L["Cancel"],
                  OnAccept = function()
                     table.remove(self.savedVars.tabs, tabButton:GetID())
                     tabbedFrame:RemoveTab(tabButton:GetID())
                  end,
                  timeout = 0,
                  whileDead = 1,
                  hideOnEscape = 1
               }
               StaticPopup_Show ("Luggage_DeleteTab")
            end,
            tooltipTitle = L["Remove Tab"],
            tooltipText = L["Removes this tab and all bags belonging to it"],
         },
         {
            text = L["Add Bag"],
            func = function()
               self:NewBagDialog(tabButton)
            end,
            tooltipTitle = L["Add Bag"],
            tooltipText = L["Add a bag to this tab"],
         },
      }
      return menu
   end

   local holdLayout = true
   for i, tab in ipairs(self.savedVars.tabs) do
      tabbedFrame:AddTab(tab.icon,tab.name)
      for id, bagSavedVars in pairs(tab.bags) do
         self:AddBag(i, bagSavedVars, holdLayout)
      end
   end
   tabbedFrame:LayoutContent(self.savedVars.bagInset, self.savedVars.bagPadding)
   
   if self.savedVars.showAlways then
      tabbedFrame:Show()
   else
      tabbedFrame:Hide()
   end
end

function Bar:SavePosition()
   local sv = self.savedVars
   local frame = self.tabbedFrame.frame
   local point, relativeTo, relativePoint, xOffs, yOffs = frame:GetPoint(1)
   sv.point = point or "BOTTOMLEFT"
   sv.x = xOffs or frame:GetLeft()
   sv.y = yOffs or frame:GetBottom()
end

function Bar:NewBagDialog(tabButton)
   local tabbedFrame = self.tabbedFrame
   local callback = function(icon, bagName)
      local bagList = self.savedVars.tabs[tabButton:GetID()].bags
      local bagOptions = bagList[#bagList+1]
      bagOptions.icon = icon
      bagOptions.name = bagName
      self:AddBag(tabButton:GetID(), bagOptions)
   end
   Luggage:AskUserForIconAndName(callback)
end

function Bar:AddBag(tabNumber, bagSavedVars, holdLayout)
   local bagNumber = #self.bags
   local bag = Luggage.Bag:New(string.format("%s_Bag%i", self.name, bagNumber), bagSavedVars)
   table.insert(self.bags, bag)
   bag:SetBagButtonSize(self.savedVars.bagButtonSize)
   bag.bagbar = self
   Luggage:RegisterBagForEvents(bag)
   local tabbedFrame = self.tabbedFrame
   tabbedFrame:AddContent(bag.bagButton, tabNumber)
   if not holdLayout then
      tabbedFrame:LayoutContent(self.savedVars.bagInset, self.savedVars.bagPadding)
   end
end

function Bar:RemoveBag(bag)
   Luggage:UnregisterBagForEvents(bag)
   self.tabbedFrame:RemoveContent(bag.bagButton)
   self.tabbedFrame:LayoutContent(self.savedVars.bagInset, self.savedVars.bagPadding)
   for i, tab in pairs(self.savedVars.tabs) do
      for j, bagSV in ipairs(tab.bags) do
         if bagSV == bag.savedVars then
            table.remove(tab.bags, j)
            break
         end
      end
   end
end

function Bar:Show()
   self.tabbedFrame:Show()
end

function Bar:Hide()
   self.tabbedFrame:Hide()
   for i, bag in ipairs(self.bags) do
      bag:Hide()
   end
end

function Bar:UpdateOptionsTable(options)
end

function Bar:SetBagInset(inset)
   if inset ~= self.savedVars.bagInset then
      self.savedVars.bagInset = inset
      self.tabbedFrame:LayoutContent(inset, self.savedVars.bagPadding)
   end
end

function Bar:SetBagPadding(padding)
   if padding ~= self.savedVars.bagPadding then
      self.savedVars.bagPadding = padding
      self.tabbedFrame:LayoutContent(self.savedVars.bagInset, padding)
   end
end

function Bar:SetBagButtonSize(size)
   if size ~= self.savedVars.bagButtonSize then
      self.savedVars.bagButtonSize = size
      for i, bag in ipairs(self.bags) do
         bag:SetBagButtonSize(size)
      end
      self.tabbedFrame:LayoutContent(self.savedVars.bagInset, self.savedVars.bagPadding)
   end
end


function Bar:ResetPosition()
   self.savedVars.x = 500
   self.savedVars.y = 500
   self.savedVars.point = "BOTTOMLEFT"
   self.tabbedFrame:SetPoint("BOTTOMLEFT", UIParent, "BOTTOMLEFT", self.savedVars.x, self.savedVars.y)
end

function Bar:Delete()
   for i, bag in ipairs(self.bags) do
      self:RemoveBag(bag)
      bag.bagButton:ClearAllPoints()
      bag.bagButton:Hide()
      bag:Clear()
      bag:Hide()
   end
   for i, bagbar in ipairs(Luggage.bagbars) do
      if bagbar == self then
         table.remove(Luggage.bagbars, i)
         break
      end
   end
   for index, sv in pairs(Luggage.db.profile.bagbars) do
      if sv == self.savedVars then
         Luggage.db.profile.bagbars[index] = nil
      end
   end
   self:Hide()
   Luggage:UpdateOptions()
end

function Bar:SetShowAt(key, value)
   local sv = self.savedVars
   sv[key] = value
   if sv.showAlways then
      self:Show()
      return
   end
   if sv.showAtBank and getglobal("BankFrame"):IsVisible() then
      self:Show()
      return
   end
   self:Hide()
end

Luggage.BagBar = Bar