local L = LibStub("AceLocale-3.0"):GetLocale("Luggage")

local newBarName = ""
Luggage.GetOptionsTable = function()
   local self = Luggage
   local options = self.options
   if not options then
      options = {
         type = "group",
         childGroups = "tree",
         args = {
            options = {
               name = L["Options"],
               desc = L["General settings"],
               type = "group",
               args = {
                  placement = {
                     type = "execute",
                     name = L["Show Bag Placement Frame"],
                     desc = L["Shows a frame where you can make various settings for automatic bag placement."],
                     func = function() Luggage:ShowPlacementFrame() end,
                  },
                  blizzardBank = {
                     type = "toggle",
                     name = L["Show Default Blizzard Bank"],
                     desc = L["If checked, the default bank frame will still be displayed alongside Luggage bag bars. Useful if you want to swap out bags."],
                     get = function() return Luggage.db.profile.blizzardBankEnabled end,
                     set = function(info, value) Luggage:SetBlizzardBankEnabled(value) end,
                  },
                  blizzardBags = {
                     type = "toggle",
                     name = L["Show Default Blizzard Bags"],
                     desc = L["If checked, the default bag frames will still be displayed alongside Luggage bags."],
                     get = function() return Luggage.db.profile.blizzardBagsEnabled end,
                     set = function(info, value) Luggage:SetBlizzardBagsEnabled(value) end,
                  },
               },
            },
            bars = {
               type = "group",
               name = L["Bagbars"],
               desc = "",
               childGroups = "tree",
               args = {
                  barName = {
                     type = "input",
                     name = L["New Bar Name"],
                     desc = L["The name of the new bar"],
                     get = function() return newBarName end,
                     set = function(info, value) newBarName = value end
                  },
                  newBar = {
                     name = L["New Bag Bar"],
                     desc = L["Create a new bag bar"],
                     type = "execute",
                     func = function() 
                        local bagbarSV = self.db.profile.bagbars[newBarName]
                        table.insert(self.bagbars, Luggage.BagBar:New(newBarName, bagbarSV))
                     end,
                  },
               },
            },
         },
      }
      self.options = options
   end
   local bagbarOptions = options.args.bars.args
   for index, bagbar in pairs(self.bagbars) do
      local barName = bagbar.name
--~       DEFAULT_CHAT_FRAME:AddMessage("Bar name: "..barName)
      if not bagbarOptions[barName] then
         bagbarOptions[barName] = {
            type = "group",
            name = barName,
            childGroups = "tree",
            args = {
               delete = {
                  type = "execute",
                  name = L["Delete"],
                  desc = L["Delete Bag Bar"],
                  confirm = true,
                  confirmText = L["This will delete the bag bar and all its bags. Are you sure?"],
                  func = function() 
                     bagbar:Delete()
                     table.remove(bagbarOptions, index)
                  end,
               },
               inset = {
                  type = "range",
                  name = L["Bag Button Inset"],
                  desc = L["The distance between the bag buttons and the edge of the bag bar frame."],
                  min = 0,
                  max = 20,
                  step = 1,
                  get = function() return bagbar.savedVars.bagInset end,
                  set = function(info, value) bagbar:SetBagInset(value) end,
               },
               padding = {
                  type = "range",
                  name = L["Bag Button Padding"],
                  desc = L["The distance between two bag buttons in this bar."],
                  min = 0,
                  max = 20,
                  step = 1,
                  get = function() return bagbar.savedVars.bagPadding end,
                  set = function(info, value) bagbar:SetBagPadding(value) end,
               },
               size = {
                  type = "range",
                  name = L["Bag Button Size"],
                  desc = L["The size of this bar's bag buttons."],
                  min = 10,
                  max = 50,
                  step = 1,
                  get = function() return bagbar.savedVars.bagButtonSize end,
                  set = function(info, value) bagbar:SetBagButtonSize(value) end,
               },
               resetPos = {
                  type = "execute",
                  name = L["Reset Position"],
                  desc = L["Reset the bar's position to (roughly) the center of the screen."],
                  func = function() bagbar:ResetPosition() end,
               },
               showAt = {
                  type = "multiselect",
                  name = L["Show at:"],
                  desc = L["Set when this bag bar should be displayed."],
                  values = {
                     showAlways = L["Always"],
                     showAtBank = L["At Bank"],
                  },
                  get = function(info, key) return bagbar.savedVars[key] end,
                  set = function(info, key, value) bagbar:SetShowAt(key, value) end,
               },
               bags = {
                  type = "group",
                  name = L["Bags"],
                  desc = L["Bag specific settings"],
                  args = {
                  },
               },
            },
         }
      end
      bagbar:UpdateOptionsTable(bagbarOptions[index])
   end
   for i, bag in ipairs(Luggage.bags) do
      local bagOptions = bagbarOptions[bag.bagbar.name].args.bags.args
      if not bagOptions[""..i] then
         bagOptions[""..i] = {
            type = "group",
            name = bag.savedVars.name,
            args = {
               itemSize = {
                  type = "range",
                  name = L["Item Button Size"],
                  desc = L["Size of the items inside the bag"],
                  min = 20,
                  max = 50,
                  step = 1,
                  set = function(info, value) bag:SetItemButtonSize(value) end,
                  get = function() return bag.savedVars.itemSize end,
               },
               inset = {
                  type = "range",
                  name = L["Item Button Inset"],
                  desc = L["The distance between the item buttons and the edge of the bag frame."],
                  min = 0,
                  max = 20,
                  step = 1,
                  get = function() return bag.savedVars.inset end,
                  set = function(info, value) bag:SetInset(value) end,
               },
               padding = {
                  type = "range",
                  name = L["Item Button Padding"],
                  desc = L["The distance between two item buttons in this bag."],
                  min = 0,
                  max = 20,
                  step = 1,
                  get = function() return bag.savedVars.padding end,
                  set = function(info, value) bag:SetPadding(value) end,
               },
               columns = {
                  type = "range",
                  name = L["Number of columns"],
                  desc = L["The maximum number of item buttons in one row."],
                  min = 1,
                  max = 20,
                  step = 1,
                  get = function() return bag.savedVars.columns end,
                  set = function(info, value) bag:SetColumns(value) end,
               },
               growUpwards = {
                  type = "toggle",
                  name = L["Expand upwards"],
                  desc = L["Begin placing item buttons to the bottom, then stack them up as more items are added."],
                  get = function() return bag.savedVars.growUpwards end,
                  set = function(info, value) bag:SetGrowUpwards(value) end,
               },
               growLeft = {
                  type = "toggle",
                  name = L["Expand to the left"],
                  desc = L["Begin placing item buttons to the right, then expand to the left as more items are added."],
                  get = function() return bag.savedVars.growLeft end,
                  set = function(info, value) bag:SetGrowLeft(value) end,
               },
               showAt = {
                  type = "multiselect",
                  name = L["Open:"],
                  desc = L["Set when this bag should be automatically opened."],
                  values = {
                     showAtBank = L["At Bank"],
                     showAtMailbox = L["At Mailbox"],
                     showAtVendor = L["At Vendor"],
                     showAtAuctionHouse = L["At Auction House"],
                     showAtGuildbank = L["At Guildbank"],
                     showOnToggleAll = L["On Toggle All Bags"],
                     showOnToggleSet1 = L["On Toggle Bag Set %d"]:format(1),
                     showOnToggleSet2 = L["On Toggle Bag Set %d"]:format(2),
                     showOnToggleSet3 = L["On Toggle Bag Set %d"]:format(3),
                     showOnToggleSet4 = L["On Toggle Bag Set %d"]:format(4),
                     showOnToggleSet5 = L["On Toggle Bag Set %d"]:format(5),
                  },
                  get = function(info, key) return bag.savedVars[key] end,
                  set = function(info, key, value) bag:SetShowAt(key, value) end,
               },
            },
         }
      end
   end
   return options
end


function Luggage:UpdateOptions()
   self.options = nil
   self:GetOptionsTable()
   LibStub("AceConfigRegistry-3.0"):NotifyChange("Luggage")
end
