local Bag = {}
local libBaggage = LibStub:GetLibrary("LibBaggage-1.0")
local L = LibStub("AceLocale-3.0"):GetLocale("Luggage")

function Bag:New(id, savedVars)
   local newBag = {
     id = id,
     itemStacks = {},
     buttons = {},
     containedItems = {},
     filters = savedVars.filters,
     savedVars = savedVars,
   }
   setmetatable(newBag, {__index = self})
   newBag:CreateBagButton()
   newBag:CreateBagFrame()
   newBag:CreateTitleFrame()
   return newBag
end

local bagButtonScripts = {
   "OnClick",
   "OnEnter",
   "OnLeave",
}

function Bag:CreateBagButton()
   local bagButton = CreateFrame("CheckButton", "Luggage_"..self.id.."_BagButton", UIParent, "Luggage_BagSlotButtonTemplate")
   bagButton.bag = self
   self.bagButton = bagButton
   bagButton.countText = getglobal(bagButton:GetName().."Count")
   bagButton.stockText = getglobal(bagButton:GetName().."Stock")
   bagButton.iconTexture = getglobal(bagButton:GetName().."IconTexture")
   bagButton.iconTexture:SetTexture(self.savedVars.icon)
   for i, scriptName in ipairs(bagButtonScripts) do
      bagButton:SetScript(scriptName, Luggage.Bag[scriptName])
   end
   bagButton:RegisterForClicks("LeftButtonUp", "RightButtonUp")
   bagButton:ClearAllPoints()
end

local normalTextureScale = 64/37
function Bag:SetBagButtonSize(size)
   local bagButton = self.bagButton
   local normalTexture = getglobal(bagButton:GetName().."NormalTexture")
   bagButton:SetHeight(size)
   bagButton:SetWidth(size)
   normalTexture:SetHeight(size * normalTextureScale)
   normalTexture:SetWidth(size * normalTextureScale)
end

function Bag:CreateBagFrame()
   local frame = CreateFrame("Frame", "Luggage_"..self.id.."_Frame", UIParent)--, "Luggage_BagFrameTemplate")
   table.insert(UISpecialFrames,frame:GetName())
   frame:SetBackdrop({
      bgFile   = "Interface/Tooltips/UI-Tooltip-Background", 
      edgeFile = "Interface/Tooltips/UI-Tooltip-Border",
      tile     = true, 
      tileSize = 16, 
      edgeSize = 16, 
      insets   = { left = 4, right = 4, top = 4, bottom = 4 }
   })
   frame:SetBackdropColor(0,0,0,0.9)
   frame:EnableMouse(true)
   frame:SetMovable(true)
   frame:SetScript("OnShow",
      function(this)
         self:Show()
      end
   )
   frame:SetScript( "OnMouseUp",
      function(this, mouseButton)
         self:SavePosition(this)
      end
   )
   frame:SetScript( "OnMouseDown",
      function(this, mouseButton)
         if mouseButton == "LeftButton" and not this.isMoving and self:IsUserPlaced() then
            this:StartMoving()
            this.isMoving = true
         end
      end
   )
   frame:SetScript( "OnHide",
      function(this)
         self:SavePosition(this)
         self:Hide()
      end
   )
   self.frame = frame
end

function Bag:SavePosition(this)
   if this.isMoving then
      this:StopMovingOrSizing()
      this.isMoving = false
      local sv = self.savedVars
      local point, relativeTo, relativePoint, xOffs, yOffs = self.frame:GetPoint(1)
      sv.point = point or "BOTTOMLEFT"
      sv.x = xOffs or frame:GetLeft()
      sv.y = yOffs or frame:GetBottom()
   end
end

local BAG_TITLE_HEIGHT = 30
function Bag:CreateTitleFrame()
   local frame = self.frame
   local titleFrame = CreateFrame("Frame", frame:GetName().."_Title", frame)
--~    titleFrame:SetBackdrop({
--~       bgFile   = "Interface/Tooltips/UI-Tooltip-Background", 
--~       edgeFile = "Interface/Tooltips/UI-Tooltip-Border",
--~       tile     = true, 
--~       tileSize = 16, 
--~       edgeSize = 16, 
--~       insets   = { left = 4, right = 4, top = 4, bottom = 4 }
--~    })
--~    titleFrame:SetBackdropColor(0,0,0,0.9)
   titleFrame:SetPoint("TOPLEFT", frame, "TOPLEFT", 0, 0)
   titleFrame:SetPoint("TOPRIGHT", frame, "TOPRIGHT", 0, 0)
   titleFrame:SetHeight(BAG_TITLE_HEIGHT)
   titleFrame:Show()
   local closeButton = CreateFrame("Button", titleFrame:GetName().."CloseButton", titleFrame, "UIPanelCloseButton")
   closeButton:SetPoint("RIGHT", titleFrame, "RIGHT")
   closeButton:SetScript("OnClick", function() self:Hide() end)
   self.closeButton = closeButton
   local fontString = titleFrame:CreateFontString(titleFrame:GetName().."Text", nil, "GameFontNormal")
   self.titleText = fontString
   fontString:SetText(self.savedVars.name)
   fontString:SetPoint("LEFT", titleFrame, "LEFT", 7, 0)
   fontString:SetPoint("RIGHT", titleFrame, "RIGHT", - closeButton:GetWidth(), 0)
   fontString:SetJustifyH("LEFT")
   titleFrame:EnableMouse(true)
   titleFrame:SetScript( "OnMouseUp",
      function(this, mouseButton)
         if mouseButton == "LeftButton" then
            self:SavePosition(this)
         elseif mouseButton == "RightButton" then
            self:ShowTitleDropdown()
         end
      end
   )
   titleFrame:SetScript( "OnMouseDown",
      function(this, mouseButton)
         if mouseButton == "LeftButton" and not frame.isMoving and self:IsUserPlaced() then
            frame:StartMoving()
            frame.isMoving = true
         end
      end
   )
   titleFrame:SetScript( "OnHide",
      function(this)
         self:SavePosition(this)
      end
   )
   
   self.titleFrame = titleFrame
end

function Bag.OnClick(frame, mouseButton)
   local self = frame.bag
   if mouseButton == "LeftButton" then
      if IsModifierKeyDown("shift") then
         local infoType, itemID = GetCursorInfo()
         if infoType == "item" then
            local nextState = Luggage:GetNextState(self.savedVars.itemIDs[itemID])
            local str
            if nextState == true then
               str = "true"
            elseif nextState == false then
               str = "false"
            elseif nextState == nil then
               str = "nil"
            end
            self:SetFilterForItem(itemID, nextState)
            Bag.OnEnter(frame)
         end
      else
         if self:IsShown() then
            self:Hide()
         else
            self:Show()
         end
      end
   elseif mouseButton == "RightButton" then
      self.bagButton:SetChecked(not self.bagButton:GetChecked()) -- Looks weird, but leads to not changing the checked status
      self:ShowDropdown()
   end
end

function Bag.OnEnter(frame)
   local self = frame.bag
   GameTooltip:SetOwner(frame, "ANCHOR_LEFT");
   if CursorHasItem() then
      local infoType, itemID = GetCursorInfo()
      local r,g,b = Luggage:GetFilterColor(self.savedVars.itemIDs[itemID])
      GameTooltip_AddNewbieTip(self.savedVars.name, r,g,b, L["Shift-Click to cycle through the filter modes for this particular item"], false)
   else
      GameTooltip:SetText(self.savedVars.name)
   end
   GameTooltip:Show()
end

function Bag.OnLeave(frame)
   local self = frame.bag
   GameTooltip:Hide()
   ResetCursor()
end

function Bag:ShowDropdown()
   Luggage:ShowBagDropdown(self)
end

function Bag:ShowTitleDropdown()
   if not self.titleDropdownMenu then
      self.titleDropdownMenu = {
         {
            text = L["Place Manually"],
            func = function(value)
               self.savedVars.isUserPlaced = not self.savedVars.isUserPlaced
               self:UpdatePosition()
               Luggage:ArrangeBags()
            end,
            checked = function() return self:IsUserPlaced() end,
            keepShownOnClick = true,
         }
      }
      self.titleDropdownFrame = CreateFrame("Frame", self.savedVars.name.."TitleDropdownFrame", UIParent, "UIDropDownMenuTemplate")
   end
   EasyMenu(self.titleDropdownMenu, self.titleDropdownFrame, self.titleFrame, nil, nil, "MENU")
end

function Bag:ToggleCombineStacks()
   local combineStacks = self.savedVars.combineStacks
   self:SetCombineStacks(not combineStacks)
end

function Bag:ToggleEmptySlot()
   local showEmptySlot = self.savedVars.showEmptySlot
   self:SetShowEmptySlot(not showEmptySlot)
end

function Bag:ToggleShowNumberOfContainedItems()
   self.savedVars.showNumberOfContainedItems = not self.savedVars.showNumberOfContainedItems
   self:UpdateBagSpace()
end

function Bag:ToggleShowFreeSpace(bagType)
   self.savedVars.showFreeSpace = bit.bxor(self.savedVars.showFreeSpace or 0, bagType)
   self:UpdateBagSpace()
end

function Bag:SetShowEmptySlot(showEmptySlot)
   local svShowEmptySlot = self.savedVars.showEmptySlot
   if (not showEmptySlot and not svShowEmptySlot) or (showEmptySlot and svShowEmptySlot) then
      return
   end
   self:Clear()
   self.savedVars.showEmptySlot = showEmptySlot
   self:Update()
end

function Bag:SetCombineStacks(combineStacks)
   local savedCombineStacks = self.savedVars.combineStacks
   if (not savedCombineStacks and not combineStacks) or (savedCombineStacks and combineStacks) then
      return
   end
   self:Clear()
   self.savedVars.combineStacks = combineStacks
   self:Update()
end

function Bag:SetIcon(icon)
   self.savedVars.icon = icon
   self.bagButton.iconTexture:SetTexture(icon)
   self.bagButton:Show()
end

function Bag:SetName(name)
   self.savedVars.name = name
   self.titleText:SetText(name)
end

function Bag:SetFilterForItem(itemID, value)
   self.savedVars.itemIDs[itemID] = value
   Luggage:FullUpdate()
end

function Bag:SetShowAt(key, value)
   self.savedVars[key] = value
end

function Bag:Update()
   for item in libBaggage:AllItems() do
      if self:ContainsItem(item) then
         self:AddItem(item)
      end
   end
   self:UpdateItemButtons()
end

function Bag:SortItems()
   local buttons
   if self.savedVars.combineStacks then
      buttons = self.itemStacks
   else
      buttons = self.itemButtons
   end
end

function Bag:GetItemList()
   local list = self.itemList
   if list then
      for i, item in pairs(list) do
         list[i] = nil
      end
   else
      self.itemList = {}
      list = self.itemList
   end
   local n = 1
   if self.savedVars.combineStacks then
      for itemID, stack in pairs(self.itemStacks) do
         list[n] = stack:GetItemTable()
         n = n + 1
      end
   else
      for item in pairs(self.containedItems) do
         list[n] = item
         n = n + 1
      end
   end
   if self.savedVars.showEmptySlot then
      list[n] = Luggage:GetEmptySlotTable(self)
      n = n + 1
   end
   list = self:SortItemList(list)
   return list
end

local function sortByName(item1, item2)
   local name1 = item1.name
   local name2 = item2.name
   if not name1 then 
      return false
   end
   if not name2 then
      return true
   end
   return name1 < name2
end

function Bag:SortItemList(list)
   table.sort(list, sortByName)
   return list
end

function Bag:TrimItemButtons(count)
   local buttons = self.buttons
   while count < #buttons do
      Luggage:DepositItemButton(table.remove(buttons))
   end
   while count > #buttons do
      table.insert(buttons, Luggage:GetItemButton())
   end
end

function Bag:UpdateItemButtons()
   if not self:IsShown() then return end
   local itemList = self:GetItemList()
   self:TrimItemButtons(#itemList)
   for i, button in ipairs(self.buttons) do
      button:SetItem(itemList[i])
   end
   self:UpdatePosition() 
end

function Bag:UpdateItemLock(bagID, slotID)
   if not self:IsShown() then return end
   local item = libBaggage:GetItem(bagID, slotID)
   if self.savedVars.combineStacks then
      local stack = self.itemStacks[item.itemID]
      if not stack then return end
      local new_item = stack:GetItemTable()
      for i, button in ipairs(self.buttons) do
         if button.itemID == item.itemID then
            button:SetItem(new_item)
            break
         end
      end
   else
      for i, button in ipairs(self.buttons) do
         if button.bagID == bagID and button.slotID == slotID then
            button:SetItem(item)
         end
      end
   end
   
end

local MIN_HEIGHT = 50
local MIN_WIDTH = 50
function Bag:UpdatePosition()
   local frame = self.frame
   frame:ClearAllPoints()
   frame:SetPoint(self.savedVars.point, UIParent, self.savedVars.point, self.savedVars.x, self.savedVars.y)
   local columns = math.min(self:GetNumberOfColumns(), #self.buttons)
   if columns == 0 then columns = 1 end
   local itemSize = self.savedVars.itemSize
   local inset = self.savedVars.inset
   local padding = self.savedVars.padding
   local width = math.max(inset + columns*(itemSize + padding) - padding + inset, self.titleText:GetStringWidth() + self.closeButton:GetWidth() + 10)
   local rows = math.ceil(#self.buttons / columns)
   local height = math.max(inset + rows*(itemSize + padding) - padding + inset + BAG_TITLE_HEIGHT, MIN_HEIGHT)
   frame:SetHeight(height)
   frame:SetWidth(width)   
   for i, button in ipairs(self.buttons) do
      button.frame:ClearAllPoints()
      local column = (i-1) % columns
      local row = math.floor((i-1)/columns)
      local x,y = self:GetButtonOffset(row, column, width, height)
      button.frame:SetPoint("TOPLEFT", frame, "TOPLEFT", x, y)
      i = i + 1
      button:SetSize(itemSize)
   end
   if not self:IsUserPlaced() then
      Luggage:ArrangeBags()
   end
end

function Bag:Locations()
   local locationFilter = self.savedVars.filters.Location
   local bankFilter
   local mainBagFilter
   if locationFilter then
      bankFilter = locationFilter[1]
      mainBagFilter = locationFilter[2]
   end
   local isBank = bankFilter or bankFilter == nil
   local isMainBags = mainBagFilter or mainBagFilter == nil
   return isMainBags, isBank
end

function Bag:UpdateBagSpace()
   local freeSpace
   local isMainBags, isBank = self:Locations()
   local bagType = self.savedVars.showFreeSpace
   local count = getglobal(self.bagButton:GetName().."Count")
   if bagType ~= 0 then
      if isBank then
         freeSpace = (freeSpace or 0) + libBaggage:GetTotalFreeBankSpace(bagType, true)
      end
      if isMainBags then
         freeSpace = (freeSpace or 0) + libBaggage:GetTotalFreeMainBagSpace(bagType, true)
      end
      count:SetText(freeSpace)
      count:Show()
   else
      count:Hide()
   end
   local stock = getglobal(self.bagButton:GetName().."Stock")
   if self.savedVars.showNumberOfContainedItems then
      local nItems = 0
      for item in pairs(self.containedItems) do
         nItems = nItems + 1
      end
      stock:SetText(nItems)
      stock:Show()
   else
      stock:Hide()
   end
end

function Bag:GetNumberOfColumns()
   return self.savedVars.columns
end

function Bag:GetButtonOffset(row, column, width, height)
   local itemSize = self.savedVars.itemSize
   local padding = self.savedVars.padding
   local inset = self.savedVars.inset
   local x,y
   if self.savedVars.growUpwards then
      y = row*(itemSize + padding) - height + itemSize + inset - BAG_TITLE_HEIGHT
   else
      y = -( row*(itemSize + padding)) - BAG_TITLE_HEIGHT
   end
   if self.savedVars.growLeft then
      x = -inset - column*(itemSize+padding) + width - itemSize
   else
      x = inset + column*(itemSize+padding)
   end
   return x,y
end

function Bag:ContainsItem(itemTable, excludeFilters)
   local sv = self.savedVars
   local byItemID = sv.itemIDs[itemTable.itemID]
   if byItemID ~= nil then
      return byItemID 
   end
   local contains = false
   local filters = sv.filters
   for id, values in pairs(filters) do
      if Luggage.filters[id] and (not excludeFilters or not excludeFilters[id]) then
         local filterFunc = Luggage.filters[id].func
         if type(values) == "boolean" then
            if values then
               contains = contains or filterFunc(self, itemTable)
            else
               if filterFunc(self, itemTable) then
                  return false
               end
            end
         elseif type(values) == "table" then
            for value, isContained in pairs(values) do
               if isContained == true then
                  contains = contains or filterFunc(self, itemTable, value)
               elseif isContained == false then
                  if filterFunc(self, itemTable, value) then
                     return false
                  end
               end            
            end
         end
      end
   end
   return contains
end

function Bag:AddItem(itemTable)
   self.containedItems[itemTable] = true
   if self.savedVars.combineStacks then
      local itemID = itemTable.itemID
      local stack = self.itemStacks[itemID] 
      if not stack then 
         self.itemStacks[itemID] = Luggage:GetStack(itemTable)
      else
         stack:AddItemStack(itemTable)
      end
   end
   self:PlayAnim(itemTable.icon)
end

function Bag:PlayAnim(icon)
   local anim = getglobal(self.bagButton:GetName().."ItemAnim")
   if not icon then
      anim:Hide()
      return
   end
   anim:ReplaceIconTexture(icon);
   anim:SetSequence(0);
   anim:SetSequenceTime(0, 0);
   anim:Show();
end


function Bag:RemoveItem(itemTable)
   local containedItems = self.containedItems
   if not containedItems[itemTable] then return end
   containedItems[itemTable] = nil
   if self.savedVars.combineStacks then
      local itemID = itemTable.itemID
      local stack = self.itemStacks[itemID]
      if not stack then return end
      local stackShouldRemain = stack:RemoveItemStack(itemTable)
      if stackShouldRemain then
         self:UpdateSingleItemButton(itemTable.bagID, itemTable.slotID, stack:GetItemTable())
      else
         Luggage:DepositStack(stack)
         self.itemStacks[itemID] = nil
         self:HideItemButton(itemTable.bagID, itemTable.slotID)
      end
   else
      self:HideItemButton(itemTable.bagID, itemTable.slotID)
   end
end

function Bag:Clear()
   local containedItems = self.containedItems
   for item in pairs(containedItems) do
      containedItems[item] = nil
   end
   local itemStacks = self.itemStacks
   for itemID, stack in pairs(self.itemStacks) do
      Luggage:DepositStack(table.remove(itemStacks, itemID))
      self.itemStacks[itemID] = nil
   end
   local itemList = self.itemList
   if itemList then
      for i, item in ipairs(itemList) do
         itemList[i] = nil
      end
   end
end

function Bag:HideItemButton(bagID, slotID)
   for i, button in ipairs(self.buttons) do
      if button.bagID == bagID and button.slotID == slotID then
         button:SetItem(nil)
         return
      end
   end
end

function Bag:UpdateSingleItemButton(oldBagID, oldSlotID, new_item)
   if not self:IsShown() then return end
   local combineStacks = self.savedVars.combineStacks
   for i, button in ipairs(self.buttons) do
      if combineStacks then
         if button.itemID == new_item.itemID then
            button:SetItem(new_item)
         end
      else
         if button.bagID == oldBagID and button.slotID == oldSlotID then
            button:SetItem(new_item)
            return
         end
      end
   end
end

function Bag:Show()
   self.show = true
   self.frame:Show()
   self.bagButton:SetChecked(1)
   self:UpdateItemButtons()
end

function Bag:Hide()
   self.show = nil
   self.frame:Hide()
   self.bagButton:SetChecked(0)
   for i, button in ipairs(self.buttons) do
      button.frame:Hide()
   end
   if not self:IsUserPlaced() then
      Luggage:ArrangeBags()
   end
--   self:TrimItemButtons(0) -- I think this line is doing more harm than good
end

function Bag:IsShown()
   return self.show
end

function Bag:SetItemButtonSize(size)
   self.savedVars.itemSize = size
   self:UpdatePosition()
end

function Bag:SetInset(inset)
   self.savedVars.inset = inset
   self:UpdatePosition()
end

function Bag:SetPadding(padding)
   self.savedVars.padding = padding
   self:UpdatePosition()
end

function Bag:SetColumns(nr)
   self.savedVars.columns = nr
   self:UpdatePosition()
end

function Bag:SetGrowUpwards(growUpwards)
   self.savedVars.growUpwards = growUpwards
   self:UpdatePosition()
end

function Bag:SetGrowLeft(growLeft)
   self.savedVars.growLeft = growLeft
   self:UpdatePosition()
end

function Bag:IsUserPlaced()
   return self.savedVars.isUserPlaced
end

function Bag:GetHeight()
   return self.frame:GetHeight() / self.frame:GetEffectiveScale()
end

function Bag:GetWidth()
   return self.frame:GetWidth() / self.frame:GetEffectiveScale()
end

function Bag:SetPoint(point, frame, relativePoint, xOffs, yOffs)
   if string.sub(point, 1, 3) == "TOP" then
      yOffs = yOffs - self.titleFrame:GetHeight()
   end
   self.frame:SetPoint(point, frame, relativePoint, xOffs, yOffs)
end

function Bag:ClearAllPoints()
   self.frame:ClearAllPoints()
end

Luggage.Bag = Bag
