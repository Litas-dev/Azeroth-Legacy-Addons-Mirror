--[[
   Compost heaps of Luggage
]]--

-- Itembutton Frames --
local itemButtonNumber = 0
local itemButtonFrameCache = {} -- frames cannot be gc'd, so no need for __mode = 'k'
function Luggage:GetItemButtonFrame()
   local frame = next(itemButtonFrameCache) 
   if not frame then
      frame = CreateFrame("Button", "Luggage_ItemButton_"..itemButtonNumber, nil, "ContainerFrameItemButtonTemplate")
      itemButtonNumber = itemButtonNumber + 1
   end
   itemButtonFrameCache[frame] = nil
   return frame
end

function Luggage:DepositItemButtonFrame(frame)
   frame:SetParent(UIParent)
   frame:ClearAllPoints()
   frame:Hide()
   itemButtonFrameCache[frame] = true
end

-- Itembutton Objects --
local itemButtonCache = setmetatable({}, {__mode='k'})
function Luggage:GetItemButton()
   local itemButton = next(itemButtonCache)
   if not itemButton then
      itemButton = Luggage.ItemButton:New()
   else
      local frame = self:GetItemButtonFrame()
      itemButton:SetFrame(frame)
   end
   itemButtonCache[itemButton] = nil
   return itemButton
end

function Luggage:DepositItemButton(itemButton)
   self:DepositItemButtonFrame(itemButton.frame)
   itemButton:SetItem(nil)
   itemButton.frame = nil
   itemButtonCache[itemButton] = true
end

-- Stack Objects --
local stackCache = setmetatable({}, {__mode='k'})
function Luggage:GetStack(itemTable)
   local stack = next(stackCache)
   if not stack then
      stack = Luggage.Stack:New(itemTable)
   else
      stack:SetItem(itemTable)
   end
   stackCache[stack] = nil
   return stack
end

function Luggage:DepositStack(stack)
   if not stack then return end
   stack:SetItem(nil)
   stackCache[stack] = true
end
