--[[ 
 
title: RaidMobMarkerHUD 2.6c
author: humfras - credits/thanks to Baudzilla -
quick-description: help to set raidtargets


==Current Features==
circular marking HUD

==Help==
"/rmmhud show" -> show/hide HUD
"/rmmhud help" -> shows help
"/rmmhud macro" -> advanced macro description

== HISTORY ==

version 2.4
- Initial release (/bow Baudzilla)
version 2.5
- advanced HUD options and help
- some visual fixes
version 2.5b
- patch 3.3 toc update
version 2.6
- Party / Raid Lead fix
version 2.6b
- some minor fixes
version 2.6c
- some minor fixes
verion 2.7
- some minor code enhancements
verion 2.8
- only a toc update
verion 2.8
- some minor code enhancements
version 3.0
- Cataclysm preparation

== TODO ==
- none -
 
]] 
 
RaidMobMarkerHUD = {};
RaidMobMarkerHUD.title       = "RaidMobMarkerHUD";
RaidMobMarkerHUD.version     = "|cff8080ff3.0|r";
RaidMobMarkerHUD.author      = "humfras - credits/thanks to Baudzilla -";
RaidMobMarkerHUD.CMD_PREFIX = "RAIDMOBMARKERHUD";

local KeyHeld;

function RaidMobMarkerHUD_OnLoad(self)
  self:RegisterEvent("PLAYER_TARGET_CHANGED");
  
  -- register slash commands
  SLASH_RAIDMOBMARKERHUD1 = "/rmmhud";
  SLASH_RAIDMOBMARKERHUD2 = "/raidmobmarkerhud";
  SlashCmdList["RAIDMOBMARKERHUD"] = function(msg) 
	RaidMobMarkerHUD.Command(msg);
  end

  -- Key Bindings
  BINDING_HEADER_RaidMobMarkerHUD = "RaidMobMarkerHUD";
  BINDING_NAME_RaidMobMarkerHUD = RaidMobMarkerHUD_Display;
  
  local Button, Angle;
  for Index = 1, 8 do
    Button = CreateFrame("Button", "RaidMobMarkerHUDIconButton"..Index, self);
    Button:SetWidth(30);
    Button:SetHeight(30);
    Button:SetID(Index);
    Button.Texture = Button:CreateTexture(Button:GetName().."NormalTexture", "ARTWORK");
    Button.Texture:SetTexture("Interface\\TargetingFrame\\UI-RaidTargetingIcons");
    Button.Texture:SetAllPoints();
    SetRaidTargetIconTexture(Button.Texture, Index);
    Button:RegisterForClicks("LeftButtonUp","RightButtonUp");
    Button:SetScript("OnClick", RaidMobMarkerHUD_Button_OnClick);
    Button:SetScript("OnEnter", RaidMobMarkerHUD_Button_OnEnter);
    Button:SetScript("OnLeave", RaidMobMarkerHUD_Button_OnLeave);
    if(Index==8)then
      Button:SetPoint("CENTER");
    else
      Angle = 360 / 7 * Index;
      Button:SetPoint("CENTER", sin(Angle) * 50, cos(Angle) * 50);
    end
  end

  RaidMobMarkerHUD.Print(""..RaidMobMarkerHUD.version.." by "..RaidMobMarkerHUD.author.." loaded.");
end

function RaidMobMarkerHUD_CanMark()
	if(GetNumRaidMembers() > 0 and not (IsRaidLeader() or IsRaidOfficer())) then 
		UIErrorsFrame:AddMessage(RaidMobMarkerHUD_NoPermission, 1.0, 0.1, 0.1, 1.0, UIERRORS_HOLD_TIME);
		return false; 
	else
		return true; 
	end
end


function RaidMobMarkerHUD_HotkeyPressed(keystate)
  KeyHeld = (keystate=="down") and RaidMobMarkerHUD_CanMark();
  if KeyHeld then
	RaidMobMarkerHUD_ShowIcons();
  else
    RaidMobMarkerHUD_Frame:Hide();
  end
end


function RaidMobMarkerHUD_OnEvent(self, event)
  if(event=="PLAYER_TARGET_CHANGED")then
    if KeyHeld then
      RaidMobMarkerHUD_ShowIcons();
    end
  end
end


function RaidMobMarkerHUD_ShowIcons()
  if not UnitExists("target") or UnitIsDead("target") then
    return;
  end
  local X, Y = GetCursorPosition();
  local Scale = UIParent:GetEffectiveScale();
  RaidMobMarkerHUD_Frame:SetPoint("CENTER", UIParent, "BOTTOMLEFT", X / Scale, Y / Scale);
  RaidMobMarkerHUD_Frame:Show();
end


function RaidMobMarkerHUD_ShowIconsMacro()
  if (RaidMobMarkerHUD_Frame:IsVisible()) then
	RaidMobMarkerHUD_Frame:Hide();
  end
  if not UnitExists("target") or UnitIsDead("target") then
    return;
  end
  if RaidMobMarkerHUD_CanMark() then
  local X, Y = GetCursorPosition();
  local Scale = UIParent:GetEffectiveScale();
  RaidMobMarkerHUD_Frame:SetPoint("CENTER", UIParent, "BOTTOMLEFT", X / Scale, Y / Scale);
  RaidMobMarkerHUD_Toggle();
  end
end


function RaidMobMarkerHUD_Toggle()
   local frame = RaidMobMarkerHUD_Frame;
   if (frame) then
	if(frame:IsVisible()) then
		frame:Hide();
	else
		frame:Show();
	end
   end
end


function RaidMobMarkerHUD_Button_OnEnter(self)
  self.Texture:ClearAllPoints();
  self.Texture:SetPoint("TOPLEFT", -5, 5);
  self.Texture:SetPoint("BOTTOMRIGHT", 5, -5);
end


function RaidMobMarkerHUD_Button_OnLeave(self)
  self.Texture:SetAllPoints();
end


function RaidMobMarkerHUD_Button_OnClick(self)
	PlaySound("UChatScrollButton");
  SetRaidTarget("target", (arg1~="RightButton")and self:GetID()or 0);
  RaidMobMarkerHUD_Frame:Hide();
  -- ClearTarget();
end



--[[

further functions

]]

-- print function
function RaidMobMarkerHUD.Print (msg)
	DEFAULT_CHAT_FRAME:AddMessage(COLOR_ORANGE..RaidMobMarkerHUD.title.."> "..COLOR_END..msg);
end


-- slash function handle
function RaidMobMarkerHUD.Command(msg)
	local cmd, param1, param2 = RaidMobMarkerHUD.ParamParser(msg);
	if ( cmd == "" ) then
		RaidMobMarkerHUD.ShowHelp();
	-- hud display command
	elseif(cmd=="show") then
		RaidMobMarkerHUD_ShowIconsMacro();
	elseif(cmd=="help") then
		RaidMobMarkerHUD.ShowHelp2();
	elseif(cmd=="macro") then
		RaidMobMarkerHUD.ShowHelpMacro();
	else
		RaidMobMarkerHUD.ShowHelp();
	end
end


-- Parse data after /slash command
function RaidMobMarkerHUD.ParamParser(msg)
 	if msg then
 		local a,b,c=strfind(msg, "(%S+)"); --contiguous string of non-space characters
 		if a then
 			return c, strsub(msg, b+2);
 		else	
 			return "";
 		end
 	end
end


-- prints command line help
function RaidMobMarkerHUD.ShowHelp()
	RaidMobMarkerHUD.Print(COLOR_GOLD..RaidMobMarkerHUD.title..COLOR_END.." "..RaidMobMarkerHUD.version )
	RaidMobMarkerHUD.Print(COLOR_GOLD.."/rmmhud show "..COLOR_END..COLOR_WHITE..RaidMobMarkerHUD_HELP1_1..COLOR_END);
	RaidMobMarkerHUD.Print(COLOR_GOLD.."/rmmhud help "..COLOR_END..COLOR_WHITE..RaidMobMarkerHUD_HELP1_2..COLOR_END);
	RaidMobMarkerHUD.Print(COLOR_GOLD.."/rmmhud macro "..COLOR_END..COLOR_WHITE..RaidMobMarkerHUD_HELP1_3..COLOR_END);
end

-- prints additional command line help
function RaidMobMarkerHUD.ShowHelp2()
	RaidMobMarkerHUD.Print(COLOR_GOLD..RaidMobMarkerHUD.title..COLOR_END.." "..RaidMobMarkerHUD.version.." "..COLOR_GOLD.."HELP"..COLOR_END )
	RaidMobMarkerHUD.Print(COLOR_WHITE..RaidMobMarkerHUD_HELP2_1..COLOR_END);
	RaidMobMarkerHUD.Print(COLOR_WHITE..RaidMobMarkerHUD_HELP2_2..COLOR_END);
	RaidMobMarkerHUD.Print(COLOR_WHITE..RaidMobMarkerHUD_HELP2_3..COLOR_END);
	RaidMobMarkerHUD.Print(COLOR_WHITE..RaidMobMarkerHUD_HELP2_4..COLOR_END);
	RaidMobMarkerHUD.Print(COLOR_WHITE..RaidMobMarkerHUD_HELP2_5..COLOR_END);
end


-- prints macro help
function RaidMobMarkerHUD.ShowHelpMacro()
	RaidMobMarkerHUD.Print(COLOR_GOLD..RaidMobMarkerHUD_HELP4..COLOR_END);
	RaidMobMarkerHUD.Print(COLOR_WHITE..RaidMobMarkerHUD_HELP4_1..COLOR_END);
	RaidMobMarkerHUD.Print(COLOR_WHITE..RaidMobMarkerHUD_HELP4_2..COLOR_END);
end
