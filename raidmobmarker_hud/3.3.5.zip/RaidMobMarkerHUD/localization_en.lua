-- Colours
COLOR_RED = "|cffff0000";
COLOR_GREEN = "|cff00ff00";
COLOR_BLUE = "|cff0000ff";
COLOR_PURPLE = "|cff700090";
COLOR_YELLOW = "|cffffff00";
COLOR_ORANGE = "|cffff6d00";
COLOR_GREY = "|cff808080";
COLOR_GOLD = "|cffcfb52b";
COLOR_WHITE = "|cffffffff";
COLOR_NEON_BLUE = "|cff4d4dff";
COLOR_END = "|r";


-- HUD
RaidMobMarkerHUD_Display = "Mark Targets(Hold)";
RaidMobMarkerHUD_NoPermission = "You don't have permission to mark targets.";
RaidMobMarkerHUD_NoGroup = "You must be in a party or raid to mark targets.";


-- help
RaidMobMarkerHUD_HELP1_1 = "show/hide HUD";
RaidMobMarkerHUD_HELP1_2 = "shows help";
RaidMobMarkerHUD_HELP1_3 = "advanced macro description";
-- help 'help'
RaidMobMarkerHUD_HELP2_1 = "In the ingame keybinding menu you will find an entry called RaidMobMarker HUD, where you have to assign a button to it.";
RaidMobMarkerHUD_HELP2_2 = "To mark a target with a raid symbol, target the unit and hold down the assigned button. (Requires party or raid)";
RaidMobMarkerHUD_HELP2_3 = "LEFT-click a symbol and your current target will be marked with it.";
RaidMobMarkerHUD_HELP2_4 = "RIGHT-click a symbol to unmark the current target.";
RaidMobMarkerHUD_HELP2_5 = "While holding down the button, the HUD will re-show when you change your target.";
-- help 'macro'
RaidMobMarkerHUD_HELP4 = "You can use the following macro to mark mouseover targets";
RaidMobMarkerHUD_HELP4_1 = "/target mouseover";
RaidMobMarkerHUD_HELP4_2 = "/rmmhud";
