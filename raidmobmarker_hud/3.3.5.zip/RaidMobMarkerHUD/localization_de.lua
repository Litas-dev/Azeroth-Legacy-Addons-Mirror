﻿if ( GetLocale() == "deDE" ) then

-- HUD
RaidMobMarkerHUD_Display = "Zielmarkierung(Halten)";
RaidMobMarkerHUD_NoPermission = "Du hast keine Erlaubnis zum Markieren.";
RaidMobMarkerHUD_NoGroup = "Du musst in einer Gruppe oder Raid sein, um markieren zu können.";


-- help
RaidMobMarkerHUD_HELP1_1 = "zeigen/verbergen des HUD";
RaidMobMarkerHUD_HELP1_2 = "Zeigt erweiterte Hilfe an";
RaidMobMarkerHUD_HELP1_3 = "Erweiterte Info zur Makro-Nutzung";
-- help 'help'
RaidMobMarkerHUD_HELP2_1 = "In der Tastatur-Belegung findet ihr einen Eintrag 'RaidMobMarker HUD', unter dem ihr eine Taste zuweisen könnt.";
RaidMobMarkerHUD_HELP2_2 = "Um einem Ziel ein Raid-Symbol zuweisen zu können, Ziel anvisieren und die Taste gedrückt halten. (Benötigt Gruppe oder Raid)";
RaidMobMarkerHUD_HELP2_3 = "LINKS-Klick auf ein Symbol weißt dieses dem aktuellen Ziel zu.";
RaidMobMarkerHUD_HELP2_4 = "RECHTS-Klick auf ein Symbol entfernt die Markierung vom aktuellen Ziel.";
RaidMobMarkerHUD_HELP2_5 = "Wenn ihr die Taste gedrückt haltet und ein neues Ziel anvisiert, erscheint das HUD erneut, um dieses Ziel markieren zu können.";
-- help 'macro'
RaidMobMarkerHUD_HELP4 = "Mit dem folgenden Makro kannst du mouseover-Ziele markieren.";
RaidMobMarkerHUD_HELP4_1 = "/target mouseover";
RaidMobMarkerHUD_HELP4_2 = "/rmmhud";


end
