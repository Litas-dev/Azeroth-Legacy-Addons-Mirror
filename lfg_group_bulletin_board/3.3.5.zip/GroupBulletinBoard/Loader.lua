local TOCNAME = "GroupBulletinBoard"

GroupBulletinBoard_Addon = {}
--GB = GroupBulletinBoard_Addon

GroupBulletinBoard_Loader = {
  Main = function() return TOCNAME, GroupBulletinBoard_Addon end
}

