# TrufiGCD
Backport of TrufiGCD for 3.3.5

Features settings:
1. Move and resize icons
2. Change direction of fade icons
3. Add and remove ability from blacklist
4. Restore default settings. Save settings from character and load its an another.
5. Masque's icon customization
