local ShowMyDPS = LibStub("AceAddon-3.0"):NewAddon("ShowMyDPS", "AceConsole-3.0", "AceEvent-3.0")

DBDefault = {
	char = {
		handleDPS = true,
		isLock = false,
		isShown = true,
		oocHide = false,
	}
}

function ShowMyDPS:OnInitialize()
	self.db = LibStub("AceDB-3.0"):New("SMDdb", DBDefault)
	self:RegisterChatCommand("smd","SlashHandler")
end

function ShowMyDPS:OnEnable()
	self:CreateFrame()
	self:RegisterEvent("PLAYER_REGEN_ENABLED","LeaveCombat")
	self:RegisterEvent("PLAYER_REGEN_DISABLED","EnterCombat")
	self:RegisterEvent("COMBAT_LOG_EVENT_UNFILTERED","AddAmount")
end

function ShowMyDPS:CreateFrame()

	smdFrame = CreateFrame("Frame", "ShowMyDPSFrame", UIParent, "GameTooltipTemplate")
	smdFrame:SetPoint("CENTER", UIParent, self.db.char.x and "BOTTOMLEFT" or "CENTER", self.db.char.x or 0, self.db.char.y or 0)
	smdFrame:EnableMouse(true)
	smdFrame:SetToplevel(true)
	smdFrame:SetMovable(true)
	smdFrame:SetFrameStrata("LOW")
	smdFrame:SetWidth(220)
	smdFrame:SetHeight(25)
	if self.db.char.isShown and not self.db.char.oocHide then
		smdFrame:Show()
	end

	local backdrop_header = {bgFile = "Interface\\Tooltips\\UI-Tooltip-Background",
			edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border", tile=1, tileSize=16, edgeSize = 16,
			insets = {left = 5, right = 5, top = 5, bottom = 5}}

	smdFrame:SetBackdrop(backdrop_header);
	smdFrame:SetBackdropBorderColor(TOOLTIP_DEFAULT_COLOR.r, TOOLTIP_DEFAULT_COLOR.g, TOOLTIP_DEFAULT_COLOR.b)
	smdFrame:SetBackdropColor(TOOLTIP_DEFAULT_BACKGROUND_COLOR.r, TOOLTIP_DEFAULT_BACKGROUND_COLOR.g, TOOLTIP_DEFAULT_BACKGROUND_COLOR.b)

	smdFrame.text = smdFrame:CreateFontString("$parentText", "ARTWORK", "GameFontNormalSmall")
	smdFrame.text:SetPoint("CENTER", smdFrame, "CENTER", 0, 0)
	smdFrame.text:Show()

	smdFrame:SetScript("OnMouseDown", function(frame, button) 
		if not self.db.char.isLock and button ~= "RightButton" then
			frame.isMoving = true
			frame:StartMoving()	
		end
	end)

	smdFrame:SetScript("OnMouseUp", function(frame, button) 
		if not self.db.char.isLock and button ~= "RightButton" then
			if( frame.isMoving ) then
				frame.isMoving = nil
				frame:StopMovingOrSizing()
				self.db.char.x, self.db.char.y = frame:GetCenter()
			end
		else
			self.db.char.handleDPS = not self.db.char.handleDPS
			self:AddAmount()
		end
	end)
	self:AddAmount()
	ShowMyDPS.Frame = smdFrame
end

function ShowMyDPS:SlashHandler(msg)
	if msg == "lock" then
		self.db.char.isLock = not self.db.char.isLock
	elseif msg == "show" then
		if ShowMyDPS.Frame:IsShown() then ShowMyDPS.Frame:Hide() self.db.char.isShown = false else ShowMyDPS.Frame:Show() self.db.char.isShown = true end
	elseif msg == "oochide" then
		self.db.char.oocHide = not self.db.char.oocHide
		if not InCombatLockdown() then 
			if self.db.char.oocHide then smdFrame:Hide() elseif self.db.char.isShown then smdFrame:Show() end
		end
	elseif msg == "resetpos" then
		self.db.char.x = nil
		self.db.char.y = nil
		self:Printf("You should now reload your ui")
	else
		self:Printf("/smd lock : toggle lock/unlock")
		self:Printf("/smd show : toggle show/hide")
		self:Printf("/smd oochide : toggle hide when out of combat")
		self:Printf("/smd resetpos : resets frame position")
	end
end

local cbtDuration, cbtStart = nil, nil
local cbtDPS, cbtDmgAmount = nil, 0
local cbtHPS, cbtHealAmount= nil, 0

function ShowMyDPS:EnterCombat()
	if self.db.char.isShown and self.db.char.oocHide then smdFrame:Show() end
	cbtDmgAmount = 0
	cbtHealAmount = 0
	cbtStart = GetTime() - 3.5
end

function ShowMyDPS:AddAmount(...)
	if not arg5 or bit.band(arg5, 0x1111) == 0x1111 or bit.band(arg5, 0x511) == 0x511 then -- Checking source
	
		-- DPS crap
		if (arg2 and string.find(arg2, "_DAMAGE")) then
			if not arg12 then -- Checking dps type
				cbtDmgAmount = cbtDmgAmount + arg9 -- Melee swing
			else
				cbtDmgAmount = cbtDmgAmount + arg12 -- Anything else
			end
		end
		
		-- Heal crap
		if (arg2 and string.find(arg2, "_HEAL")) then
			cbtHealAmount = cbtHealAmount + ( arg12 - arg13 ) -- Only effective healing
		end
	
		-- Get recount-like feature
		cbtStart = cbtStart or GetTime() - 3.5

		-- Calculation
		cbtDuration = GetTime() - cbtStart
		if cbtDmgAmount then cbtDPS = (floor((cbtDmgAmount/cbtDuration * 100) + 0.5))/100 end
		if cbtHealAmount then cbtHPS = (floor((cbtHealAmount/cbtDuration * 100) + 0.5))/100 end
		
		
		-- Adapt
		if cbtDmgAmount and cbtDmgAmount > 1000000 then cbtDmgAmount = floor(cbtDmgAmount/1000).."k" end
		if cbtHealAmount and cbtHealAmount > 1000000 then cbtHealAmount = floor(cbtHealAmount/1000).."k" end
		
		-- Show
		if not arg5 or InCombatLockdown() then
			if self.db.char.handleDPS then
				if cbtDmgAmount and cbtDmgAmount > 0 then
					ShowMyDPSFrameText:SetText(format("Dmg : %s | %s | %s dps",cbtDmgAmount,SecondsToTime(cbtDuration),cbtDPS))
				else
					ShowMyDPSFrameText:SetText("Damage")
				end
			else
				if cbtHealAmount and cbtHealAmount > 0 then
					ShowMyDPSFrameText:SetText(format("Heal : %s | %s | %s hps",cbtHealAmount,SecondsToTime(cbtDuration),cbtHPS))
				else
					ShowMyDPSFrameText:SetText("Heal")
				end
			end
		end
	end
end

function ShowMyDPS:LeaveCombat()
	if self.db.char.oocHide then smdFrame:Hide() end
	cbtDmgAmount = 0
	cbtHealAmount = 0
	cbtStart = nil
end