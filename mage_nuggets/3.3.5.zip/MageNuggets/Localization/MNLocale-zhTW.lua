﻿local L = LibStub('AceLocale-3.0'):NewLocale('MageNuggets', 'zhTW')
if not L then return end


L["magenuggets"] = true
L["Slowfall Cast On You"] = true 
L["Focus Magic Cast On You"] = true
L["Thanks For Focus Magic"] = true
L["Thanks For The Innervate"] = true 
L["Mage"] = true
L["Nuggets"] = true
L["loaded! (Use: /magenuggets options)"] = true
L["/magenuggets"] = true
L["loaded! Some Options Disabled (Class:"] = true
L["options (Shows options)"] = true
L["Ice Barrier Absorbing"] = true
L["Damage"] = true
L["Mana Shield Absorbing"] = true
L["Polymorph(Pig) Broken On"] = true
L["Polymorph(Sheep) Broken On"] = true
L["Polymorph(Turtle) Broken On"] = true
L["Polymorph(Rabbit) Broken On"] = true
L["Polymorph(Black Cat) Broken On"] = true
L["Frost"] = true
L["Fire"] = true
L["Frost Ward Absorbing"] = true
L["Fire Ward Absorbing"] = true
L["Clearcast"] = true
L["Praxis"] = true
L["+350 Spellpower"] = true
L["HOT STREAK!"] = true
L["BRAIN FREEZE!"] = true
L["MISSILE BARRAGE!"] = true
L["Fingers Of Frost"] = true
L["Evocating For"] = true
L["Mana"] = true
L["STORM POWER"] = true
L["(+135% Crit Damage)"] = true
L["TOASTY FIRE!"] = true
L["Fungal Creep!"] = true
L["(+50% Crit Rating)"] = true
L["Aura of Celerity!"] = true
L["(+20% Haste)"] = true
L["Star Light!"] = true
L["(50% Haste)"] = true
L["Innervated By"] = true
L["INNERVATED YOU!"] = true
L["Focused Magic By"] = true
L["Focused Magic you"] = true
L["Blood Lust used by"] = true
L["BLOOD LUSTED!"] = true
L["Stole"] = true
L["Spell Stolen"] = true
L["Power Infusion"] = true






----------------Options----------------

L["To disable a message leave all of its boxes blank."] = true
L["Messages are picked at random."] = true
L["You can disable or resize this"] = true
L["monitor in options."] = true
L["Disable SP and Crit% Monitor"] = true
L["Disable Spellsteal Monitor"] = true
L["Disable Mage Proc Combat Text"] = true
L["Disable Maximum Camera Zoom Out"] = true
L["Disable Precise Shield Absorb Notify"] = true
L["Disable Mirror Image Timer"] = true
L["Disable Water Elemental Timer"] = true
L["Disable Evocation Notify"] = true
L["Disable Living Bomb Counter"] = true
L["SP and Crit % Monitor Size"] = true
L["Spellsteal Monitor Size"] = true
L["Living Bomb Counter Size"] = true
L["Slowfall Notify Messages"] = true
L["Focus Magic Notify Messages"] = true
L["Focus Magic Thank You Messages"] = true
L["Innervate Thank You Messages"] = true
L["Preview Frames"] = true
L["Disable Mage Proc Monitor"] = true
L["Mage Proc Monitor Size"] = true
L["Lock Frames"] = true
L["Disable Console Text"] = true
L["Checking this will disable all notifications sent to"] = true
L["the chat console. This includes shield absorb, polymorph, evocation,"] = true
L["spellsteal notifications and all other chat console notifications."] = true
L["The in game combat text must be turned on"] = true
L["for mage proc combat text to function."] = true

