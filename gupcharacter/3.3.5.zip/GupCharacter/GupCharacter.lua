﻿GupCharacter_Options = {
	"PLAYERSTAT_BASE_STATS", 
	"PLAYERSTAT_MELEE_COMBAT", 
	"PLAYERSTAT_DEFENSES", 
}
 
----------------------------------------------------------------------------------------------------------------
--[[	GupCharacter_OnLoad				 																	]]--
----------------------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------------------
function GupCharacter_OnLoad(self)
	self:RegisterEvent("VARIABLES_LOADED");
	self:RegisterEvent("PLAYER_ENTERING_WORLD");
end

----------------------------------------------------------------------------------------------------------------
--[[	GupCharacter_OnEvent			 																	]]--
----------------------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------------------
function GupCharacter_OnEvent(self, event) --self, event, ...

	if event == "PLAYER_ENTERING_WORLD"  then
		self:UnregisterEvent("PLAYER_ENTERING_WORLD");
		
		PaperDollFrame:DisableDrawLayer("BACKGROUND"); 

		CharacterFrame:SetWidth(512);
		
		---------------------------------
		-- Character
		---------------------------------
		CharacterModelFrame:ClearAllPoints();
		CharacterModelFrame:SetPoint("TOPLEFT", GupCharacter_PaperDollFrame, "TOPLEFT", 129, -78)
		
--		CharacterModelFrame:SetPoint("TOPLEFT", GupCharacter_PaperDollFrame, "TOPLEFT", 129-35, -78)
--		CharacterModelFrame:SetWidth(300); --232
--		CharacterModelFrame:SetModelScale(1) ;
--		CharacterModelFrame:SetModelScale(0.45) ;
--		CharacterModelFrame:SetPosition(0,0,0);
--		CharacterModelFrame:SetPosition(0,0,00.25);
		CharacterModelFrameRotateLeftButton:SetPoint( "TOPLEFT" , -64 , 0);
		 
		CharacterAttributesFrame:ClearAllPoints();
		
		CharacterResistanceFrame:ClearAllPoints();
		CharacterResistanceFrame:SetPoint("TOPRIGHT", GupCharacter_PaperDollFrame, "TOPLEFT", 425, -77) --297+128
		
		CharacterHeadSlot:ClearAllPoints();
		CharacterHeadSlot:SetPoint("TOPLEFT", GupCharacter_PaperDollFrame, "TOPLEFT", 21, -74)
		
		CharacterHandsSlot:ClearAllPoints();
		CharacterHandsSlot:SetPoint("TOPLEFT", GupCharacter_PaperDollFrame, "TOPLEFT", 433, -74) --305+128
		
		CharacterMainHandSlot:ClearAllPoints();
		CharacterMainHandSlot:SetPoint("TOPLEFT", GupCharacter_PaperDollFrame, "BOTTOMLEFT", 187, 127) --122+65
		
		PaperDollFrameItemFlyout:ClearAllPoints();
		PaperDollFrameItemFlyout:SetPoint("TOPRIGHT", GupCharacter_PaperDollFrame, "TOPRIGHT", 0, 0)
		
		GearManagerDialog:ClearAllPoints();
		GearManagerDialog:SetPoint("TOPLEFT", GupCharacter_PaperDollFrame, "TOPRIGHT", -38, -10)
		
		-----
		
		CharacterModelFrame:SetScript("OnUpdate", GupCharacter_Model_OnUpdate ) ;
		
		function PaperDollFrame_OnHide (self)
			GearManagerDialog:Hide();
			GupCharacter_AnimateDialog:Hide();
		end

		
		GearManagerToggleButton:SetScript("OnClick", function() 
														if ( GearManagerDialog:IsShown() ) then	
															GearManagerDialog:Hide();			
														else							
															GearManagerDialog:Show();						
														end  
														GupCharacter_AnimateDialog:Hide();
													end ) ;
		
		---------------------------------
		-- Pets
		---------------------------------		
		GupCharacter_Hide(PetPaperDollFrame);
		GupCharacter_Hide(PetPaperDollFrameCompanionFrame );
		
		PetPaperDollFrame:UnregisterEvent("PET_UI_UPDATE");
		PetPaperDollFrame:UnregisterEvent("PET_BAR_UPDATE");
		PetPaperDollFrame:UnregisterEvent("PET_UI_CLOSE");
		PetPaperDollFrame:UnregisterEvent("UNIT_NAME_UPDATE");
		PetPaperDollFrame:UnregisterEvent("UNIT_PET");
		PetPaperDollFrame:UnregisterEvent("UNIT_PET_EXPERIENCE");
		PetPaperDollFrame:UnregisterEvent("UNIT_MODEL_CHANGED");
		PetPaperDollFrame:UnregisterEvent("UNIT_LEVEL");
		PetPaperDollFrame:UnregisterEvent("UNIT_RESISTANCES");
		PetPaperDollFrame:UnregisterEvent("UNIT_STATS");
		PetPaperDollFrame:UnregisterEvent("UNIT_DAMAGE");
		PetPaperDollFrame:UnregisterEvent("UNIT_RANGEDDAMAGE");
		PetPaperDollFrame:UnregisterEvent("UNIT_ATTACK_SPEED");
		PetPaperDollFrame:UnregisterEvent("UNIT_ATTACK_POWER");
		PetPaperDollFrame:UnregisterEvent("UNIT_RANGED_ATTACK_POWER");
		PetPaperDollFrame:UnregisterEvent("UNIT_DEFENSE");
		PetPaperDollFrame:UnregisterEvent("UNIT_ATTACK");
		PetPaperDollFrame:UnregisterEvent("PLAYER_ENTERING_WORLD");
		PetPaperDollFrame:UnregisterEvent("COMPANION_LEARNED");
		PetPaperDollFrame:UnregisterEvent("COMPANION_UPDATE");
		PetPaperDollFrame:UnregisterEvent("SPELL_UPDATE_COOLDOWN");
		PetPaperDollFrame:UnregisterEvent("UNIT_ENTERED_VEHICLE");
		PetPaperDollFrame:UnregisterEvent("UNIT_EXITED_VEHICLE");

		PetPaperDollCloseButton:Hide(); --Close Button

		PetPaperDollFramePetFrame:ClearAllPoints();
		PetPaperDollFramePetFrame:SetPoint( "TOPLEFT", GupCharacter_PetPaperDollFramePetFrame, "TOPLEFT", 0, 0); 
		PetPaperDollFramePetFrame:SetPoint( "BOTTOMRIGHT", GupCharacter_PetPaperDollFramePetFrame, "BOTTOMRIGHT", 0, 0); 
		
		-------- Pets
		PetModelFrame:ClearAllPoints();
		PetModelFrame:SetPoint( "TOPLEFT", PetPaperDollFramePetFrame, "TOPLEFT", 89, -78); --25+64
		
		PetPaperDollFrameExpBar:ClearAllPoints();
		PetPaperDollFrameExpBar:SetPoint( "BOTTOMLEFT", PetPaperDollFramePetFrame, "BOTTOMLEFT", 87, 83); --23+64
		
		PetAttributesFrame:ClearAllPoints();
		PetAttributesFrame:SetPoint( "TOPLEFT", PetPaperDollFramePetFrame, "TOPLEFT", 131, -320); --67+64
		
		PetResistanceFrame:ClearAllPoints();
		PetResistanceFrame:SetPoint( "TOPLEFT", PetPaperDollFramePetFrame, "TOPLEFT", 434, -76); --338+96
		
		-------- Companions / Mounts
		
		PetPaperDollFrameCompanionFrame:ClearAllPoints();
		
		CompanionModelFrameRotateLeftButton:ClearAllPoints();
		CompanionModelFrameRotateLeftButton:SetPoint( "TOPLEFT", GupCharacter_PetPaperDollFrameCompanionFrame, "TOPLEFT", 23, -76);
	
		CompanionModelFrame:ClearAllPoints();
		CompanionModelFrame:SetPoint( "TOPLEFT" , GupCharacter_PetPaperDollFrameCompanionFrame, "TOPLEFT" , 103 , -80); --39+64

		CompanionPrevPageButton:ClearAllPoints();
		CompanionButton1:ClearAllPoints();
		CompanionSelectedName:ClearAllPoints();
		CompanionPageNumber:ClearAllPoints();
		
		CompanionSummonButton:ClearAllPoints();
		CompanionSummonButton:SetPoint( "CENTER" , GupCharacter_PetPaperDollFrameCompanionFrame,  "CENTER" ,-13 , -5);
		
		NUM_COMPANIONS_PER_PAGE = 0 ;

		PetPaperDollFrameTab2:ClearAllPoints();
		PetPaperDollFrameTab3:ClearAllPoints();
		PetPaperDollFrameTab1:ClearAllPoints();
				
		---------------------------------
		-- Reputation
		---------------------------------				
		GupCharacter_Hide(ReputationFrame);
				
		ReputationFrameStandingLabel:ClearAllPoints();
		ReputationFrameStandingLabel:SetPoint( "TOPLEFT", ReputationFrame, "TOPLEFT", 359, -59); --215+128+16
				
		hooksecurefunc("ReputationFrame_SetRowType", function(factionRow, rowType, hasRep)
 
			local factionRowName = factionRow:GetName()
			local factionBar = getglobal(factionRowName.."ReputationBar");
 
		end)
		
		
		---------------------------------
		-- Skills
		---------------------------------	
		GupCharacter_Hide(SkillFrame);
		SkillFrameCancelButton:Hide();  --Close Button
			
		SKILLS_TO_DISPLAY = 14 ;
		
		for i=1, SKILLS_TO_DISPLAY do
			getglobal("SkillRankFrame"..i):SetWidth(399);
			getglobal("SkillRankFrame"..i.."Border"):SetWidth(409);
		end
		
		SkillListScrollFrame:SetWidth(427);
		SkillListScrollFrame:SetHeight(255);
		
		SkillDetailScrollFrame:SetWidth(427);
		SkillDetailScrollFrame:SetHeight(99);
		
		SkillDetailScrollChildFrame:SetWidth(448);
		SkillDetailCostText:SetWidth(328);
		SkillDetailDescriptionText:SetWidth(328);
		
		GupCharacter_Hide(SkillListScrollFrame);
		GupCharacter_Hide(SkillDetailScrollFrame);
		
		---------------------------------
		-- currency
		---------------------------------	
		GupCharacter_Hide(TokenFrame);
		TokenFrameCancelButton:Hide(); --Close Button
		TokenFrameContainer:SetWidth(427); --299+128
		TokenFrameContainer:SetHeight(350); --330+20
		
		TokenFrameMoneyFrame:ClearAllPoints();
		TokenFrameMoneyFrame:SetPoint( "TOPRIGHT", TokenFrame, "TOPRIGHT", -32, -59); 
		
		TokenFrameContainerScrollBar.Show = 
		function (self)
			TokenFrameContainer:SetWidth(427); --299+128
			for _, button in next, getglobal("TokenFrameContainer").buttons do
				button:SetWidth(423); --295+128
				getglobal(button:GetName().."Name"):SetWidth(343);
			end
			getmetatable(self).__index.Show(self);
		end
		
		TokenFrameContainerScrollBar.Hide = 
			function (self)
				TokenFrameContainer:SetWidth(441); --313+128
				for _, button in next, TokenFrameContainer.buttons do
					button:SetWidth(441); --313+128
				end
				getmetatable(self).__index.Hide(self);
			end		
	elseif event == "VARIABLES_LOADED" then
	end
 
end

----------------------------------------------------------------------------------------------------------------
--[[	GupCharacter_PaperDollFrame_SetLevel																]]--
----------------------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------------------
function GupCharacter_PaperDollFrame_SetLevel()
	GupCharacter_CharacterLevelText:SetFormattedText(PLAYER_LEVEL, UnitLevel("player"), UnitRace("player"), UnitClass("player"));
end

----------------------------------------------------------------------------------------------------------------
--[[	GupCharacter_PlayerStatFrameDropDown_OnLoad															]]--
----------------------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------------------
function GupCharacter_PlayerStatFrameDropDown_OnLoad (self )
	RaiseFrameLevel(self);
	UIDropDownMenu_Initialize(self, GupCharacter_PlayerStatFrameDropDown_Initialize);
	UIDropDownMenu_SetSelectedValue(self, GupCharacter_Options[self.nr]);
	UIDropDownMenu_SetWidth(self, 99);
	UIDropDownMenu_JustifyText(self, "LEFT");
end

----------------------------------------------------------------------------------------------------------------
--[[	GupCharacter_PlayerStatFrameDropDown_OnShow															]]--
----------------------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------------------
function GupCharacter_PlayerStatFrameDropDown_OnShow (self)
	UIDropDownMenu_Initialize(self, GupCharacter_PlayerStatFrameDropDown_Initialize);
	UIDropDownMenu_SetSelectedValue(self,  GupCharacter_Options[ self.nr  ]);
end

----------------------------------------------------------------------------------------------------------------
--[[	GupCharacter_PlayerStatFrameDropDown_Initialize														]]--
----------------------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------------------
function GupCharacter_PlayerStatFrameDropDown_Initialize (self)
	-- Setup buttons
	local info = UIDropDownMenu_CreateInfo();
	local checked;
	for i=1, getn(PLAYERSTAT_DROPDOWN_OPTIONS) do
		if ( PLAYERSTAT_DROPDOWN_OPTIONS[i] == GupCharacter_Options[ self.nr ] ) then
			checked = 1;
		else
			checked = nil;
		end
		info.text = getglobal(PLAYERSTAT_DROPDOWN_OPTIONS[i]);
		info.func = GupCharacter_PlayerStatFrameDropDown_OnClick ;
		info.value = PLAYERSTAT_DROPDOWN_OPTIONS[i];
		info.checked = checked;
		info.owner = UIDROPDOWNMENU_OPEN_MENU;
		info.nr = self.nr ;
		UIDropDownMenu_AddButton(info);
	end
end

----------------------------------------------------------------------------------------------------------------
--[[	GupCharacter_PlayerStatFrameDropDown_OnClick														]]--
----------------------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------------------
function GupCharacter_PlayerStatFrameDropDown_OnClick(self)
	UIDropDownMenu_SetSelectedValue(self.owner, self.value);
	GupCharacter_Options[ self.owner.nr ] =  self.value ;
	UpdatePaperdollStats("GupCharacter_PlayerStatFrame"..self.owner.nr , self.value);
end

----------------------------------------------------------------------------------------------------------------
--[[	hooksecurefunc																						]]--
----------------------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------------------
hooksecurefunc("PaperDollFrame_SetLevel", GupCharacter_PaperDollFrame_SetLevel )
 
hooksecurefunc("PaperDollFrame_UpdateStats", function()
	UpdatePaperdollStats("GupCharacter_PlayerStatFrame1", GupCharacter_Options[1])
	UpdatePaperdollStats("GupCharacter_PlayerStatFrame2", GupCharacter_Options[2])
	UpdatePaperdollStats("GupCharacter_PlayerStatFrame3", GupCharacter_Options[3])	
end)

----------------------------------------------------------------------------------------------------------------
--[[	GupCharacter_Hide																					]]--
----------------------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------------------
function GupCharacter_Hide(frame)

	if not frame then return end

	for i = 1, frame:GetNumRegions() do
		local reg = select(i, frame:GetRegions())
		
		if not reg:IsObjectType("FontString")  then
			if not hide then reg:SetAlpha(0) else reg:Hide() end
		end
	end

	for i = 1, frame:GetNumChildren() do
		local reg = select(i, frame:GetChildren())
		
		 reg:SetFrameLevel ( reg:GetFrameLevel()+1 )  ;
	end 
end

----------------------------------------------------------------------------------------------------------------
--[[	GupCharacter_ToggleCharacter																		]]--
----------------------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------------------
hooksecurefunc("ToggleCharacter", function(tab) GupCharacter_ToggleCharacter(tab) end);

function  GupCharacter_ToggleCharacter (tab)
 
	GupCharacter_PetPaperDollFrame:Hide();
	GupCharacter_ReputationFrame:Hide();
	GupCharacter_SkillFrame:Hide();
	GupCharacter_TokenFrame:Hide();

	if ( tab == "PaperDollFrame" ) then
	elseif ( tab == "PetPaperDollFrame" ) then
		GupCharacter_PetPaperDollFrame:Show();
	elseif ( tab == "ReputationFrame" ) then
		GupCharacter_ReputationFrame:Show();
	elseif ( tab == "SkillFrame" ) then
		GupCharacter_SkillFrame:Show();
	elseif ( tab == "TokenFrame" ) then
		GupCharacter_TokenFrame:Show();
	end
	
end


GupCharacter_AnimateSeqtime = 0 ;
GupCharacter_AnimateSeqNumber = 3 ;
GupCharacter_AnimateSpeed = 1000 ;

function GupCharacter_Model_OnUpdate(self, elapsedTime )
		
		GupCharacter_AnimateSeqtime = GupCharacter_AnimateSeqtime + (elapsedTime * GupCharacter_AnimateSpeed); 
		CharacterModelFrame:SetSequenceTime(GupCharacter_AnimateSeqNumber, GupCharacter_AnimateSeqtime); 
		Model_OnUpdate(self, elapsedTime);
end


GupCharacter_ModelSequenceData = 
{
	[1] = {0, "Drop Dead"} ,
	[2] = {0, ""} ,
	[3] = {0, "Standstill"} ,
	[4] = {0, "Walk"} ,
	[5] = {0, "Run"} ,
	[6] = {0, "Dead"} ,
	[7] = {0, ""} ,
	[8] = {0, ""} ,
	[9] = {0, ""} ,
	[10] = {0, ""} ,
	[11] = {0, ""} ,
	[12] = {0, ""} ,
	[13] = {0, "Walk backwords"} ,
	[14] = {0, "Dazed"} ,
	[15] = {0, ""} ,
	[16] = {0, ""} ,
	[17] = {0, ""} ,
	[18] = {0, ""} ,
	[19] = {0, ""} ,
	[20] = {0, ""} ,
	[21] = {0, ""} ,
	[22] = {0, ""} ,
	[23] = {0, ""} ,
	[24] = {0, ""} ,
	[25] = {0, ""} ,
	[26] = {0, ""} ,
	[27] = {0, ""} ,
	[28] = {0, ""} ,
	[29] = {0, ""} ,
	[30] = {0, ""} ,
	[31] = {0, ""} ,
	[32] = {0, ""} ,
	[33] = {0, ""} ,
	[34] = {0, ""} ,
	[35] = {0, ""} ,
	[36] = {0, ""} ,
	[37] = {0, ""} ,
	[38] = {0, ""} ,
	[39] = {0, ""} ,
	[40] = {0, ""} ,
	[41] = {0, "Swimming"} ,
	[42] = {0, "Swim forward"} ,
	[43] = {0, "Swim left"} ,
	[44] = {0, "Swim right"} ,
	[45] = {0, "Swim backward"} ,
	[46] = {0, ""} ,
	[47] = {0, ""} ,
	[48] = {0, ""} ,
	[49] = {0, ""} ,
	[50] = {0, ""} ,
	[51] = {0, ""} ,
	[52] = {0, ""} ,
	[53] = {0, ""} ,
	[54] = {0, ""} ,
	[55] = {0, ""} ,
	[56] = {0, ""} ,
	[57] = {0, ""} ,
	[58] = {0, ""} ,
	[59] = {0, ""} ,
	[60] = {0, "Talk"} ,
	[61] = {0, "Drink"} ,
	[62] = {0, "Mining"} ,
	[63] = {0, ""} ,
	[64] = {0, "Talk"} ,
	[65] = {0, "Talk"} ,
	[66] = {0, "Bow"} ,
	[67] = {0, "Wave"} ,
	[68] = {0, "Cheer"} ,
	[69] = {0, "Dance"} ,
	[70] = {0, "Laugh"} ,
	[71] = {0, "Sleep"} ,
	[72] = {0, ""} ,
	[73] = {0, "Rude"} ,
	[74] = {0, "Roar"} ,
	[75] = {0, "Kneel"} ,
	[76] = {0, "Kiss"} ,
	[77] = {0, "Cry"} ,
	[78] = {0, "Chicken"} ,
	[79] = {0, "Beg"} ,
	[80] = {0, "Applaud"} ,
	[81] = {0, "Yell"} ,
	[82] = {0, "Flex"} ,
	[83] = {0, "Shy"} ,
	[84] = {0, "Point"} ,
	[85] = {0, "Stab"} ,
	[86] = {0, ""} ,
	[87] = {0, ""} ,
	[88] = {0, ""} ,
	[89] = {0, ""} ,
	[90] = {0, ""} ,
	[91] = {0, ""} ,
	[92] = {0, ""} ,
	[93] = {0, ""} ,
	[94] = {0, ""} ,
	[95] = {0, "Kick"} ,
	[96] = {0, "Stand to Sit"} ,
	[97] = {0, "Sitting"} ,
	[98] = {0, "Sit to Stand"} ,
	[99] = {0, "Stand to Sleep"} ,
	[100] = {0, "Sleeping"} ,
	[101] = {0, "Sleep to Stand"} ,
	[102] = {0, "Sit"} ,
	[103] = {0, "Sit"} ,
	[104] = {0, "Sit"} ,
	[105] = {0, ""} ,
	[106] = {0, ""} ,
	[107] = {0, "Trow"} ,
	[108] = {0, ""} ,
	[109] = {0, ""} ,	
	[110] = {0, ""} ,
	[111] = {0, ""} ,
	[112] = {0, ""} ,
	[113] = {0, ""} ,
	[114] = {0, "Stand to Kneel"} ,
	[115] = {0, "Kneeled"} ,
	[116] = {0, "Kneeled to Stand"} ,
	[117] = {0, ""} ,
	[118] = {0, ""} ,
	[119] = {0, ""} ,
	[120] = {0, ""} ,
	[121] = {0, "Knockback"} ,
	[122] = {0, ""} ,
	[123] = {0, ""} ,
	[124] = {0, ""} ,
	[125] = {0, ""} ,
	[126] = {0, "BladeStorm"} ,
	[127] = {0, ""} ,
	[128] = {0, ""} ,
	[129] = {0, ""} ,
	[130] = {0, ""} ,
	[131] = {0, "Drop Dead in Water"} ,
	[132] = {0, "Dead in Water"} ,
	[133] = {0, "Trow Lure"} ,
	[134] = {0, "Fishing"} ,
	[135] = {0, "Swim"} ,
	[136] = {0, ""} ,
	[137] = {0, "Dazed"} ,
	[138] = {0, ""} ,
	[139] = {0, "Stand to Sleep"} ,
	[140] = {0, "Stand to Kneel"} ,
	[141] = {0, "Kneeled"} ,
	[142] = {0, "Kneeled to Stand"} ,
	[143] = {0, "Sprint"} 
}

GupCharacter_AnimateDialogData = {} 

function GupCharacter_AnimateDialog_OnLoad(self)

	self.title:SetText("Animations");
	getglobal( "GupCharacter_AnimateDialogContainer"):SetScrollChild( getglobal( "GupCharacter_AnimateDialogDataFrame") )	;
	
	GupCharacter_AnimateDialog_ScrollFrame_Update( getglobal("GupCharacter_AnimateDialogContainer") , 143 ,38 ,10 , 165);
	
	local z = 1 ;
	
	for i = 1 , #GupCharacter_ModelSequenceData do

		if GupCharacter_ModelSequenceData[i][1] >= 0 then
	
			GupCharacter_AnimateDialogData[z] = CreateFrame("Button", "GupCharacter_AnimateDialogDataQ"..z, GupCharacter_AnimateDialogDataFrame , "GupCharacter_AnimateButtonTemplate");
			GupCharacter_AnimateDialogData[z]:SetScript("OnClick", function ()  GupCharacter_AnimateSeqtime = 0 ; GupCharacter_AnimateSeqNumber = i ; end) ;

			GupCharacter_AnimateDialogData[z]:SetPoint('TOPLEFT', 10, 10-(z*10) );
			
			if GupCharacter_ModelSequenceData[i][2] == "" then
				GupCharacter_AnimateDialogData[z]:SetText( i.. " Unkown" );
			else
				GupCharacter_AnimateDialogData[z]:SetText( i.. " "..GupCharacter_ModelSequenceData[i][2] );
			end
			
			z = z +1  ;

		end
		
	end
	
end


----------------------------------------------------------------------------------------------------------------
--[[	GupPet_Interface_ScrollFrame_Update																	]]--
----------------------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------------------
function GupCharacter_AnimateDialog_ScrollFrame_Update(frame, numItems, numToDisplay, valueStep , FrameWidth  )

	local frameName = frame:GetName();
	local scrollBar = getglobal( frameName.."ScrollBar" );
	local scrollChildFrame = getglobal( frameName.."ScrollChildFrame" );
	local scrollUpButton = getglobal( frameName.."ScrollBarScrollUpButton" );
	local scrollDownButton = getglobal( frameName.."ScrollBarScrollDownButton" );
	local scrollFrameHeight = 0;
	local scrollChildHeight = 0;

	if ( numItems > 0 ) then
		scrollFrameHeight = (numItems - numToDisplay) * valueStep;
		scrollChildHeight = numItems * valueStep;
		if ( scrollFrameHeight < 0 ) then
			scrollFrameHeight = 0;
		end
		scrollChildFrame:Show();
	else
		scrollChildFrame:Hide();
	end

	scrollBar:SetMinMaxValues(0, scrollFrameHeight); 
	scrollBar:SetValueStep(valueStep);
	scrollChildFrame:SetHeight(scrollChildHeight);
	
	if ( numItems > numToDisplay ) then
		scrollBar:Show();
		frame:SetWidth(FrameWidth-22) ;
	else
		frame:SetWidth(FrameWidth);
		scrollBar:Hide();
	end

	-- Arrow button handling
	if ( scrollBar:GetValue() == 0 ) then
		scrollUpButton:Disable();
	else
		scrollUpButton:Enable();
	end
		
	if ((scrollBar:GetValue() - scrollFrameHeight) == 0) then
		scrollDownButton:Disable();
	else
		scrollDownButton:Enable();
	end

end


