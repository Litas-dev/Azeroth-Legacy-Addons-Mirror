GC_PetPaperDollFrame = { Init = 0 , Data = { Tempi = 0 , Tempii = 0}   } ;

local tabPoints={
	[1]={ point="TOPLEFT", relativeTo="GupCharacter_PetPaperDollFrameCompanionFrame", relativePoint="TOPLEFT", xoffset=70, yoffset=-39},
	[2]={ point="LEFT", relativePoint="RIGHT", xoffset=0, yoffset=0},
	[3]={ point="LEFT", relativePoint="RIGHT", xoffset=0, yoffset=0},
}

----------------------------------------------------------------------------------------------------------------
--[[	 GupCharacter_PetPaperDollFrame_Boot																]]--
----------------------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------------------
function GupCharacter_PetPaperDollFrame_Boot()

	if GC_PetPaperDollFrame.Init == 0 then
		GC_PetPaperDollFrame.Data.Frame = CreateFrame("FRAME", "GC_PetPaperDollFrameData", GupCharacter_PetPaperDollFrameCompanionFrame , "GupCharacter_PetPaperDollFrame_DataFieldTemplate");
		GC_PetPaperDollFrame.Data.Frame:SetWidth(450);
		GC_PetPaperDollFrame.Data.Frame:SetHeight(150);	
		GC_PetPaperDollFrame.Data.Frame:SetPoint("TOPLEFT", 20 , -280);
	
		getglobal("GC_PetPaperDollFrameData" .. "Container"):SetWidth(418);
		getglobal("GC_PetPaperDollFrameData" .. "Container"):SetHeight(140);
 
		GC_PetPaperDollFrame.Init = 1 ;
	end

	GupCharacter_PetPaperDollFrame__UpdateLocalDuelFrame( GC_PetPaperDollFrame.Data ,  PetPaperDollFrameCompanionFrame.mode )
	GupCharacter_PetPaperDollFrame_ScrollFrame_Update( getglobal("GC_PetPaperDollFrameData" .. "Container") , math.ceil( GC_PetPaperDollFrame.Data.Show ) ,7 ,20 , 440);
	GupCharacter_PetPaperDollFrame_UpdateCompanions();
	
	GC_PetPaperDollFrame.Init = 2 ;
end

----------------------------------------------------------------------------------------------------------------
--[[	 GupCharacter_PetPaperDollFrame__UpdateLocalDuelFrame												]]--
----------------------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------------------
function GupCharacter_PetPaperDollFrame__UpdateLocalDuelFrame( Data ,  Type )
	
	local t_i = 0 ;
	
	for i = 1, math.ceil(GetNumCompanions(Type)/2) do
		local creatureID, creatureName, creatureSpellID , creatureIcon = GetCompanionInfo(Type, i) ;
		
		if ( Data.Tempii < i ) then

			Data[i] = CreateFrame("CheckButton", "GC_PetPaperDollFrameData"..i , getglobal( "GC_PetPaperDollFrameData" .. "Data") , "GupCharacter_PetPaperDollFrame_IconTemplate");
			
		end

		getglobal("GC_PetPaperDollFrameData"..i ).creatureID = creatureID ;
		getglobal("GC_PetPaperDollFrameData"..i ).spellID = creatureSpellID ;
		getglobal("GC_PetPaperDollFrameData"..i ).index = i ;
		
		getglobal("GC_PetPaperDollFrameData"..i ):SetPoint('TOPLEFT', 10, 20-(i*20));
		getglobal("GC_PetPaperDollFrameData"..i .. "Text"):SetText( creatureName  ) ;
		getglobal("GC_PetPaperDollFrameData"..i .. "Icon"):SetTexture( creatureIcon );
		 
		getglobal("GC_PetPaperDollFrameData"..i ):Show();

		
		t_i = i ;
	end

	local t_ii = t_i ;
  
	for i = 1, GetNumCompanions(Type)-math.ceil(GetNumCompanions(Type)/2) do
		
		local ii = i + t_i ;
		local creatureID, creatureName, creatureSpellID , creatureIcon = GetCompanionInfo(Type, ii) ;
		
		if ( Data.Tempii  < ii ) then

			Data[ii] = CreateFrame("CheckButton", "GC_PetPaperDollFrameData"..ii , getglobal( "GC_PetPaperDollFrameData" .. "Data") , "GupCharacter_PetPaperDollFrame_IconTemplate");
		end

		getglobal("GC_PetPaperDollFrameData"..ii ):SetPoint('TOPLEFT', 236, 20-(i*20));
		getglobal("GC_PetPaperDollFrameData"..ii .. "Text"):SetText(creatureName  ) ;
		getglobal("GC_PetPaperDollFrameData"..ii .. "Icon"):SetTexture( creatureIcon );
				
		getglobal("GC_PetPaperDollFrameData"..ii ).creatureID = creatureID ;
		getglobal("GC_PetPaperDollFrameData"..ii ).spellID = creatureSpellID ;		
		getglobal("GC_PetPaperDollFrameData"..ii ).index = ii
				
		getglobal("GC_PetPaperDollFrameData"..ii ):Show();
		
		t_ii = ii ;
	end	
		
	-- Hide unneedid buttons
	for q = 1 ,Data.Tempii-t_ii do
		z = q + t_ii ;
		getglobal("GC_PetPaperDollFrameData"..z):Hide() ;
	end
		
	if Data.Tempii < t_ii then
		Data.Tempii =  t_ii ;
	end

	Data.Show =  t_i ;
		
	return Data
end

----------------------------------------------------------------------------------------------------------------
--[[	 GupCharacter_CompanionButton_OnClick																]]--
----------------------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------------------
function GupCharacter_CompanionButton_OnClick(self, button)

	if  button ~= "LeftButton"  then

		if ( self.active ) then
			DismissCompanion(PetPaperDollFrameCompanionFrame.mode);
		else
			CallCompanion(PetPaperDollFrameCompanionFrame.mode, self.index);
		end
	else
		if ( PetPaperDollFrameCompanionFrame.mode == "CRITTER" ) then
			PetPaperDollFrameCompanionFrame.idCritter = self.creatureID;
			PetPaperDollFrame_UpdateCompanionPreview();
		elseif ( PetPaperDollFrameCompanionFrame.mode == "MOUNT" ) then
			PetPaperDollFrameCompanionFrame.idMount = self.creatureID;
			PetPaperDollFrame_UpdateCompanionPreview();
		end
	end
	
	GupCharacter_PetPaperDollFrame_UpdateCompanions();
end

----------------------------------------------------------------------------------------------------------------
--[[	 GupCharacter_CompanionButton_OnDrag																]]--
----------------------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------------------
function GupCharacter_CompanionButton_OnDrag(self)
 
	PickupCompanion( PetPaperDollFrameCompanionFrame.mode, self.index );
end

----------------------------------------------------------------------------------------------------------------
--[[	 GupCharacter_PetPaperDollFrame_UpdateCompanions													]]--
----------------------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------------------
function GupCharacter_PetPaperDollFrame_UpdateCompanions()
	local button;
	local creatureID, creatureName, spellID, icon, active;
	
	if ( PetPaperDollFrameCompanionFrame.mode == "CRITTER" ) then
		selected = PetPaperDollFrame_FindCompanionIndex(PetPaperDollFrameCompanionFrame.idCritter);
	elseif ( PetPaperDollFrameCompanionFrame.mode == "MOUNT" ) then
		 
		selected = PetPaperDollFrame_FindCompanionIndex(PetPaperDollFrameCompanionFrame.idMount);
	end
	
	for i = 1, GetNumCompanions(PetPaperDollFrameCompanionFrame.mode) do
	
		button = _G["GC_PetPaperDollFrameData"..i];
 
		if ( button ) then
 
			creatureID, creatureName, spellID, icon, active = GetCompanionInfo(PetPaperDollFrameCompanionFrame.mode, i);
			button.active = active;
			
			if  i == selected and active then
				button:SetChecked(true);
				_G["GC_PetPaperDollFrameData"..i.."ActiveTexture"]:Show();
				_G["GC_PetPaperDollFrameData"..i .."Text"]:SetVertexColor( 0.5 , 1 , 0.5 );
			elseif i == selected  then
				button:SetChecked(true);
				_G["GC_PetPaperDollFrameData"..i.."ActiveTexture"]:Hide();
				_G["GC_PetPaperDollFrameData"..i .."Text"]:SetVertexColor( 0 , 1 , 1 );
			elseif( active ) then
				button:SetChecked(false);
				_G["GC_PetPaperDollFrameData"..i.."ActiveTexture"]:Show();
				_G["GC_PetPaperDollFrameData"..i .."Text"]:SetVertexColor( 1 , 1 , 0.5 );
			else
				button:SetChecked(false);
				_G["GC_PetPaperDollFrameData"..i.."ActiveTexture"]:Hide();
				_G["GC_PetPaperDollFrameData"..i.."Text"]:SetVertexColor( 1 , 1 , 1   );
			end
		end
	end
		
	if ( selected > 0 ) then
		creatureID, creatureName, spellID, icon, active = GetCompanionInfo(PetPaperDollFrameCompanionFrame.mode, selected);
		if ( active and creatureID ) then
			CompanionSummonButton:SetText(PetPaperDollFrameCompanionFrame.mode == "MOUNT" and BINDING_NAME_DISMOUNT or PET_DISMISS);
		else
			CompanionSummonButton:SetText(PetPaperDollFrameCompanionFrame.mode == "MOUNT" and MOUNT or SUMMON);
		end	
	end	
		
end

----------------------------------------------------------------------------------------------------------------
--[[	 GupCharacter_PetPaperDollFrame_UpdateCompanionCooldowns											]]--
----------------------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------------------
function GupCharacter_PetPaperDollFrame_UpdateCompanionCooldowns()
 
	if GC_PetPaperDollFrame.Init == 2 then
		for i = 1, GetNumCompanions(PetPaperDollFrameCompanionFrame.mode) do
			local button = _G["GC_PetPaperDollFrameData"..i];
			if button then
				local cooldown = _G[button:GetName().."Cooldown"];
				if ( button.creatureID ) then
					local start, duration, enable = GetCompanionCooldown(PetPaperDollFrameCompanionFrame.mode, i );
					if ( start and duration and enable ) then
						CooldownFrame_SetTimer(cooldown, start, duration, enable);
					end
				else
					cooldown:Hide();
				end
			end
		end
	end
end

----------------------------------------------------------------------------------------------------------------
--[[	 GupCharacter_CompanionButton_OnModifiedClick														]]--
----------------------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------------------
function GupCharacter_CompanionButton_OnModifiedClick(self)
	local id = self.spellID;
	if ( IsModifiedClick("CHATLINK") ) then
		if ( MacroFrame and MacroFrame:IsShown() ) then
			local spellName = GetSpellInfo(id);
			ChatEdit_InsertLink(spellName);
		else
			local spellLink = GetSpellLink(id)
			ChatEdit_InsertLink(spellLink);
		end
	elseif ( IsModifiedClick("PICKUPACTION") ) then
		GupCharacter_CompanionButton_OnDrag(self);
	end
	GupCharacter_PetPaperDollFrame_UpdateCompanions();	--Set up the highlights again
end

----------------------------------------------------------------------------------------------------------------
--[[	 GupCharacter_PetPaperDollFrame_OnEvent																]]--
----------------------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------------------
function GupCharacter_PetPaperDollFrame_OnEvent (self, event, ...)
	local arg1 = ...;

	if ( event == "PET_UI_UPDATE" or event == "PET_UI_CLOSE" or event == "PET_BAR_UPDATE" or (event == "UNIT_PET" and arg1 == "player") or
		(event == "UNIT_NAME_UPDATE" and arg1 == "pet") ) then
		GupCharacter_PetPaperDollFrame_UpdateTabs();
		PetPaperDollFrame_Update();
	elseif ( event == "COMPANION_LEARNED" ) then
		if ( not CharacterFrame:IsVisible() ) then
			SetButtonPulse(CharacterMicroButton, 60, 1);
		end
		if ( not PetPaperDollFrame:IsVisible() ) then
			SetButtonPulse(CharacterFrameTab2, 60, 1);
		end
		GupCharacter_PetPaperDollFrame_Boot();
		GupCharacter_PetPaperDollFrame_UpdateTabs();
	elseif ( event == "COMPANION_UPDATE" ) then
		GupCharacter_PetPaperDollFrame_UpdateCompanions();
	elseif ( event == "SPELL_UPDATE_COOLDOWN" ) then
		if ( self:IsVisible() ) then
			GupCharacter_PetPaperDollFrame_UpdateCompanionCooldowns();
		end
	elseif ( event == "UNIT_PET_EXPERIENCE" ) then
		PetExpBar_Update();
	elseif ( (event == "UNIT_ENTERED_VEHICLE" or event == "UNIT_EXITED_VEHICLE") and (arg1 == "player")) then
		GupCharacter_PetPaperDollFrame_UpdateCompanions();
	elseif ( arg1 == "pet" ) then
		PetPaperDollFrame_Update();
	end
		
end

----------------------------------------------------------------------------------------------------------------
--[[	GupCharacter_PetPaperDollFrame_OnLoad																]]--
----------------------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------------------
function GupCharacter_PetPaperDollFrame_OnLoad (self)

	GupCharacter_PetPaperDollFrame_Boot();
	GupCharacter_PetPaperDollFrame_UpdateTabs();
	
	self:RegisterEvent("PET_UI_UPDATE");
	self:RegisterEvent("PET_BAR_UPDATE");
	self:RegisterEvent("PET_UI_CLOSE");
	self:RegisterEvent("UNIT_NAME_UPDATE");
	self:RegisterEvent("UNIT_PET");
	self:RegisterEvent("UNIT_PET_EXPERIENCE");
	self:RegisterEvent("UNIT_MODEL_CHANGED");
	self:RegisterEvent("UNIT_LEVEL");
	self:RegisterEvent("UNIT_RESISTANCES");
	self:RegisterEvent("UNIT_STATS");
	self:RegisterEvent("UNIT_DAMAGE");
	self:RegisterEvent("UNIT_RANGEDDAMAGE");
	self:RegisterEvent("UNIT_ATTACK_SPEED");
	self:RegisterEvent("UNIT_ATTACK_POWER");
	self:RegisterEvent("UNIT_RANGED_ATTACK_POWER");
	self:RegisterEvent("UNIT_DEFENSE");
	self:RegisterEvent("UNIT_ATTACK");
	self:RegisterEvent("PLAYER_ENTERING_WORLD");
	self:RegisterEvent("COMPANION_LEARNED");
	self:RegisterEvent("COMPANION_UPDATE");
	self:RegisterEvent("SPELL_UPDATE_COOLDOWN");
	self:RegisterEvent("UNIT_ENTERED_VEHICLE");
	self:RegisterEvent("UNIT_EXITED_VEHICLE");
end

----------------------------------------------------------------------------------------------------------------
--[[	GupPet_Interface_ScrollFrame_Update																	]]--
----------------------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------------------
function GupCharacter_PetPaperDollFrame_ScrollFrame_Update(frame, numItems, numToDisplay, valueStep , FrameWidth  )

	local frameName = frame:GetName();
	local scrollBar = getglobal( frameName.."ScrollBar" );
	local scrollChildFrame = getglobal( frameName.."ScrollChildFrame" );
	local scrollUpButton = getglobal( frameName.."ScrollBarScrollUpButton" );
	local scrollDownButton = getglobal( frameName.."ScrollBarScrollDownButton" );
	local scrollFrameHeight = 0;
	local scrollChildHeight = 0;

	if ( numItems > 0 ) then
		scrollFrameHeight = (numItems - numToDisplay) * valueStep;
		scrollChildHeight = numItems * valueStep;
		if ( scrollFrameHeight < 0 ) then
			scrollFrameHeight = 0;
		end
		scrollChildFrame:Show();
	else
		scrollChildFrame:Hide();
	end

	scrollBar:SetMinMaxValues(0, scrollFrameHeight); 
	scrollBar:SetValueStep(valueStep);
	scrollChildFrame:SetHeight(scrollChildHeight);
	
	if ( numItems > numToDisplay ) then
		scrollBar:Show();
		frame:SetWidth(FrameWidth-22) ;
	else
		frame:SetWidth(FrameWidth);
		scrollBar:Hide();
	end

	-- Arrow button handling
	if ( scrollBar:GetValue() == 0 ) then
		scrollUpButton:Disable();
	else
		scrollUpButton:Enable();
	end
		
	if ((scrollBar:GetValue() - scrollFrameHeight) == 0) then
		scrollDownButton:Disable();
	else
		scrollDownButton:Enable();
	end

end

----------------------------------------------------------------------------------------------------------------
--[[	PetPaperDollFrame_SetTab																			]]--
----------------------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------------------
function GupCharacter_PetPaperDollFrame_SetTab(id)
	if ( (id == 1) and HasPetUI() ) then	--Pet Tab
		PetPaperDollFrame.GC_selectedTab=1;
		
		PetPaperDollFramePetFrame:Show();
		GupCharacter_PetPaperDollFramePetFrame:Show();
		PetPaperDollFrameCompanionFrame:Hide();
		GupCharacter_PetPaperDollFrameCompanionFrame:Hide();
		
		PetNameText:SetText(UnitName("pet"));
		
	elseif ( (id == 2) and (GetNumCompanions("CRITTER") > 0) ) then	--Critter Tab
		PetPaperDollFrame.GC_selectedTab=2;
		PetPaperDollFrameCompanionFrame.mode="CRITTER";
		PetPaperDollFramePetFrame:Hide();
		GupCharacter_PetPaperDollFramePetFrame:Hide();
		PetPaperDollFrameCompanionFrame:Show();
		GupCharacter_PetPaperDollFrameCompanionFrame:Show();
		PetPaperDollFrame_UpdateCompanionPreview();
		PetNameText:SetText(PETS);
		GupCharacter_PetPaperDollFrame_Boot();
		
	elseif ( (id == 3) and (GetNumCompanions("MOUNT") > 0) ) then	--Mount Tab
		PetPaperDollFrame.GC_selectedTab=3;
		PetPaperDollFrameCompanionFrame.mode="MOUNT";
		PetPaperDollFramePetFrame:Hide();
		GupCharacter_PetPaperDollFramePetFrame:Hide();
		PetPaperDollFrameCompanionFrame:Show();
		GupCharacter_PetPaperDollFrameCompanionFrame:Show();
		PetPaperDollFrame_UpdateCompanionPreview();
		PetNameText:SetText(PETS);
		GupCharacter_PetPaperDollFrame_Boot();
	end
	
	for i=1,3 do
		if ( i == id ) then
			PanelTemplates_SelectTab(getglobal("GupCharacter_PetPaperDollFrameTab"..i));
		else
			PanelTemplates_DeselectTab(getglobal("GupCharacter_PetPaperDollFrameTab"..i));
		end
	end
end

----------------------------------------------------------------------------------------------------------------
--[[	GupCharacter_PetPaperDollFrame_OnShow																]]--
----------------------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------------------
function GupCharacter_PetPaperDollFrame_OnShow(self)
	if ( self:IsVisible() ) then
		PetPaperDollFrame_BeenViewed = true;
	end
	SetButtonPulse(CharacterFrameTab2, 0, 1);	--Stop the button pulse
	CharacterNameText:Hide();
	PetNameText:Show();
	PetPaperDollFrame_Update();
	GupCharacter_PetPaperDollFrame_UpdateTabs();
end

----------------------------------------------------------------------------------------------------------------
--[[	GupCharacter_PetPaperDollFrame_UpdateTabs															]]--
----------------------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------------------
function GupCharacter_PetPaperDollFrame_UpdateTabs()
	
	GupCharacter_PetPaperDollFrame_UpdateIsAvailable();
	
	if ( not GupCharacter_PetPaperDollFrame:IsVisible() ) then
		return;
	end
		
	local currVal = 1;
	local currRef = tabPoints[1] ;

	GupCharacter_PetPaperDollFrameTab2:ClearAllPoints()
	GupCharacter_PetPaperDollFrameTab3:ClearAllPoints()
	
	if ( HasPetUI() ) then
		GupCharacter_PetPaperDollFrameTab1:Show();
		GupCharacter_PetPaperDollFrameTab1:SetPoint(currRef.point, currRef.relativeTo, currRef.relativePoint, currRef.xoffset, currRef.yoffset)
		currVal = currVal + 1;
		currRef = tabPoints[currVal];
		currRef.relativeTo = GupCharacter_PetPaperDollFrameTab1;
	else
		GupCharacter_PetPaperDollFrameTab1:Hide();
	end
	
	if ( GetNumCompanions("CRITTER") > 0 ) then
		GupCharacter_PetPaperDollFrameTab2:Show();
		GupCharacter_PetPaperDollFrameTab2:SetPoint(currRef.point, currRef.relativeTo, currRef.relativePoint, currRef.xoffset, currRef.yoffset);
		currVal = currVal + 1;
		currRef = tabPoints[currVal];
		currRef.relativeTo = GupCharacter_PetPaperDollFrameTab2;
		
		GupCharacter_PetPaperDollFrameTab2:SetText(COMPANIONS .. "  (" .. GetNumCompanions("CRITTER")  ..")");
		PanelTemplates_TabResize(GupCharacter_PetPaperDollFrameTab2, 0);
	else
		GupCharacter_PetPaperDollFrameTab2:Hide();
	end
	
	if ( GetNumCompanions("MOUNT") > 0 ) then
		GupCharacter_PetPaperDollFrameTab3:Show();
		GupCharacter_PetPaperDollFrameTab3:SetPoint(currRef.point, currRef.relativeTo, currRef.relativePoint, currRef.xoffset, currRef.yoffset);
		currVal = currVal + 1;
		
		GupCharacter_PetPaperDollFrameTab3:SetText(MOUNTS .. "  (" .. GetNumCompanions("MOUNT")  ..")");
		PanelTemplates_TabResize(GupCharacter_PetPaperDollFrameTab3, 0);
	else
		GupCharacter_PetPaperDollFrameTab3:Hide();
	end
	
	if ( (PanelTemplates_GetSelectedTab(PetPaperDollFrame) == 1) and (not HasPetUI()) ) then
		if ( GupCharacter_PetPaperDollFrameTab2:IsShown() ) then
			GupCharacter_PetPaperDollFrame_SetTab(2);
		elseif ( GupCharacter_PetPaperDollFrameTab3:IsShown() ) then
			GupCharacter_PetPaperDollFrame_SetTab(3);
		else
			if ( PetPaperDollFrame:IsVisible() ) then
				ToggleCharacter("PetPaperDollFrame");
			end
		end
	elseif ( (not PetPaperDollFrame.GC_selectedTab) or (not PetPaperDollFrame_BeenViewed) ) then
		if ( GupCharacter_PetPaperDollFrameTab1:IsShown() ) then
			GupCharacter_PetPaperDollFrame_SetTab(1);
		elseif ( GupCharacter_PetPaperDollFrameTab2:IsShown() ) then
			GupCharacter_PetPaperDollFrame_SetTab(2);
		elseif ( GupCharacter_PetPaperDollFrameTab3:IsShown() ) then
			GupCharacter_PetPaperDollFrame_SetTab(3);
		end
	end
	
	if ( currVal == 2 ) then --Only 1 tab shown, so no reason to make it visible.
		GupCharacter_PetPaperDollFrameTab1:Hide();
		GupCharacter_PetPaperDollFrameTab2:Hide();
		GupCharacter_PetPaperDollFrameTab3:Hide();
	end
end

----------------------------------------------------------------------------------------------------------------
--[[	GupCharacter_PetPaperDollFrame_UpdateIsAvailable													]]--
----------------------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------------------
function GupCharacter_PetPaperDollFrame_UpdateIsAvailable()
	if ( (not HasPetUI()) and (GetNumCompanions("CRITTER") == 0) and (GetNumCompanions("MOUNT") == 0) ) then
		PetPaperDollFrame.hidden = true;
		CharacterFrameTab2:Hide();
		CharacterFrameTab3:SetPoint("LEFT", "CharacterFrameTab2", "LEFT", 0, 0);
	else
		PetPaperDollFrame.hidden = false;
		CharacterFrameTab2:Show();
		CharacterFrameTab3:SetPoint("LEFT", "CharacterFrameTab2", "RIGHT", -16, 0);
	end
end
