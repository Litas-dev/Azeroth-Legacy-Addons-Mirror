-- This file is automagically generated.
-- Please visit http://www.wowace.com/projects/bazooka/localization/
-- if you wish to help with the translation.

local L = LibStub("AceLocale-3.0"):NewLocale("Bazooka", "esES")
if not L then return end

L["Bar"] = "Barra"
L["Bar#%d"] = "Barra#%d"
L["bottom"] = "Abajo"
L["center"] = "Centro"
L["|cffeda55fDrag|r to move the frame"] = " |cffeda55fArrastra|r para mover el marco"
L["|cffeda55fLeft Click|r to lock/unlock frames"] = "|cffeda55fClick Izquierdo|r para bloquear/desbloquear los marcos"
L["|cffeda55fRight Click|r to open the configuration window"] = "|cffeda55fClick Derecho|r para abrir la ventana de configuración"
L["cleft"] = "Centro-Izquierda"
L["cright"] = "Centro-Derecha"
L["Disable %s plugin?"] = "¿Desactivar el plugin %s?"
L["left"] = "Izquierda"
L["none"] = "Nada"
L["right"] = "Derecha"
L["top"] = "Arriba"

