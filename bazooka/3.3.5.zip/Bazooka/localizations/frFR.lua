-- This file is automagically generated.
-- Please visit http://www.wowace.com/projects/bazooka/localization/
-- if you wish to help with the translation.

local L = LibStub("AceLocale-3.0"):NewLocale("Bazooka", "frFR")
if not L then return end

L["Bar"] = "Barre"
L["Bar#%d"] = "Barre#%d"
L["bottom"] = "Bas"
L["center"] = "Centre"
L["|cffeda55fDrag|r to move the frame"] = "|cffeda55fSaisir|r pour déplacer le cadre."
L["|cffeda55fLeft Click|r to lock/unlock frames"] = "|cffeda55fClic gauche|r pour (dé)verouiller les cadres."
L["|cffeda55fRight Click|r to open the configuration window"] = "|cffeda55fClic droit|r pour ouvrir la fenêtre de configuration."
L["cleft"] = "Centre-gauche"
L["cright"] = "Centre-droite"
L["Disable %s plugin?"] = "Désactiver le plugin %s ?"
L["left"] = "Gauche"
L["none"] = "Aucun"
L["right"] = "Droite"
L["top"] = "Haut"

