-- This file is automagically generated.
-- Please visit http://www.wowace.com/projects/bazooka/localization/
-- if you wish to help with the translation.

local L = LibStub("AceLocale-3.0"):NewLocale("Bazooka", "koKR")
if not L then return end

L["Bar"] = "바"
L["Bar#%d"] = "바#%d"
L["bottom"] = "아래"
L["center"] = "가운데"
L["|cffeda55fDrag|r to move the frame"] = "|cffeda55f드레그|r 프레임 이동"
L["|cffeda55fLeft Click|r to lock/unlock frames"] = "| cffeda55fLeft 클릭 | r에 잠금 / 잠금 해제 프레임"
L["|cffeda55fRight Click|r to open the configuration window"] = "| cffeda55fRight 클릭 | r에 구성 창을 엽니다"
L["cleft"] = "중좌"
L["cright"] = "중우"
L["Disable %s plugin?"] = "%s 플러그인 해제?"
L["left"] = "좌"
L["none"] = "없음"
L["right"] = "우"
L["top"] = "위"

