-- This file is automagically generated.
-- Please visit http://www.wowace.com/projects/bazooka/localization/
-- if you wish to help with the translation.

local L = LibStub("AceLocale-3.0"):NewLocale("Bazooka", "zhCN")
if not L then return end

L["Bar"] = "栏"
L["Bar#%d"] = "栏#%d"
L["bottom"] = "底部"
L["center"] = "居中"
L["|cffeda55fDrag|r to move the frame"] = "|cffeda55f拖拽|r移动该框"
L["|cffeda55fLeft Click|r to lock/unlock frames"] = "|cffeda55f点击|r锁定/解锁该框"
L["|cffeda55fRight Click|r to open the configuration window"] = "|cffeda55f右键|r打开设置窗口"
L["cleft"] = "中偏左"
L["cright"] = "中偏右"
L["Disable %s plugin?"] = "关闭组件 %s ？"
L["left"] = "居左"
L["none"] = "无"
L["right"] = "居右"
L["top"] = "顶部"

