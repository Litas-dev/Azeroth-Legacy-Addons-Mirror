-- This file is automagically generated.
-- Please visit http://www.wowace.com/projects/bazooka/localization/
-- if you wish to help with the translation.

local L = LibStub("AceLocale-3.0"):NewLocale("Bazooka", "deDE")
if not L then return end

L["Bar"] = "Leiste"
L["Bar#%d"] = "Leiste#%d"
L["bottom"] = "Unten"
L["center"] = "Mitte"
L["|cffeda55fDrag|r to move the frame"] = "|cffeda55fZiehen|r um das Fenster zu verschieben"
L["|cffeda55fLeft Click|r to lock/unlock frames"] = "|cffeda55fLinksklick|r um die Fenster zu sperren/entsperren"
L["|cffeda55fRight Click|r to open the configuration window"] = "|cffeda55fRechtsklick|r um das Konfigurationsmenü zu öffnen"
L["cleft"] = "Mitte links"
L["cright"] = "Mitte rechts"
L["Disable %s plugin?"] = "%s-Plugin deaktivieren?"
L["left"] = "Links"
L["none"] = "kein"
L["right"] = "Rechts"
L["top"] = "Oben"

