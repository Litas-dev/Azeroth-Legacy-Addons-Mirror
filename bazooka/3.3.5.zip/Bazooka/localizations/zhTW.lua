-- This file is automagically generated.
-- Please visit http://www.wowace.com/projects/bazooka/localization/
-- if you wish to help with the translation.

local L = LibStub("AceLocale-3.0"):NewLocale("Bazooka", "zhTW")
if not L then return end

L["Bar"] = "條列"
L["Bar#%d"] = "條列#%d"
L["bottom"] = "底部"
L["center"] = "中心"
L["|cffeda55fDrag|r to move the frame"] = "|cffeda55f拖曳|r移動框架"
L["|cffeda55fLeft Click|r to lock/unlock frames"] = "|cffeda55f左鍵點擊|r鎖定/解鎖框架"
L["|cffeda55fRight Click|r to open the configuration window"] = "|cffeda55f右鍵點擊|r開啟配置視窗"
L["cleft"] = "中左"
L["cright"] = "中右"
L["Disable %s plugin?"] = "停用 %s 插件?"
L["left"] = "左"
L["none"] = "無"
L["right"] = "右"
L["top"] = "頂部"

