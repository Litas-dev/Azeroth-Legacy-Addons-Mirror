# CircadianRhythm

Addon that shows a GUI window with the Day/Night cycle information. This is mainly for people who use addons like Elvui which completely remove that feature from the minimap.

You can also hover over the image and it will give you a tooltip with a more detailed time of day: Morning, Noon, Afternoon, Evening, Night, Midnight, Late Night.

![image](https://github.com/Bennylavaa/CircadianRhythm/assets/165105701/2704aa24-d4b7-4aea-b6e9-042aae5328b0)
![image](https://github.com/Bennylavaa/CircadianRhythm/assets/165105701/c9af541d-7ac9-4e28-88d9-7e7029fcf6f3)
