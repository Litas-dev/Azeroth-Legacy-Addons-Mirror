function GHI_LocalizeEN()






-- Bag buttons
GHI_NEW = "New Item";
GHI_NEW_1LETTER = "N";
GHI_EDIT = "Edit Item";
GHI_EDIT_1LETTER = "E";
GHI_COPY = "Copy Item";
GHI_COPY_1LETTER = "C";
GHI_HELP = "GHI Info and Options.";
GHI_PRE = "Previous backpack.";
GHI_NE = "Next backpack.";

GHI_BAG_BNT = "GHI Backpack";
GHI_BAG_DRAG = "Shift click to drag.";

-- Tooltip
GHI_MADE_BY = "Made by";
GHI_CD_LEFT = "Cooldown remaining:";
GHI_DURATION = "Duration:";
GHI_NOT_TRANSFERED = "Not yet transfered";
GHI_TRANSFER_TIME = "Transfer time less than %s minutes.";
GHI_CUSTOM_MADE = "Custom made item";
GHI_OFFICIAL_MADE = "Official GH item";
GHI_REQUIRES = "Requires";
GHI_REMAINING = "remaining";

--	book
GHI_EDIT_TEXT = "Edit Text";
GHI_MARK_TEXT = "Mark Text";
GHI_VIEW_TEXT = "View Text";
GHI_UNDO_CHANGES = "Undo Changes";
GHI_EDIT_TITLE = "Edit Title";
GHI_DELETE_PAGE = "Delete Page";
GHI_INSERT_BEFORE = "Before This";
GHI_INSERT_AFTER = "After This";
GHI_INSERT_PAGE = "Insert Page:";
GHI_MATERIAL = "Material:";
GHI_PARCHMENT = "Parchment";
GHI_STONE = "Stone";
GHI_BRONZE = "Bronze";
GHI_MARBLE = "Marble";
GHI_SILVER = "Silver";
GHI_VALENTINE = "Valentine";
GHI_HEADLINE_1 = "Headline 1";
GHI_HEADLINE_2 = "Headline 2";
GHI_FRONT = "Font:";
GHI_H1 = "H1:";
GHI_H2 = "H2:";
GHI_NORMAL = "Normal:";
GHI_FONT_SIZE = "Font Size:";
GHI_INSERT_LINK = "Insert Link";
GHI_INSERT_LOGO = "Insert Logo";
GHI_LOGO = "Logo:";
GHI_ALLIGNMENT = "Alignment:";
GHI_LEFT = "Left";
GHI_INSERT = "Insert";
GHI_CLOSE = "Close";
GHI_TRANSCRIBE = "Transcribe to GHI";
GHI_NEW_TITLE = "New title";

GHI_TRANSCRIBED = "Transcribed";
GHI_LETTER = "Letter";
GHI_READ_LETTER = "Read the letter";
GHI_INSCRIPTION = "Inscription";
GHI_READ_INCRIPTION = "Read the inscription";
GHI_FROM = "From";

-- Binding Variables
BINDING_HEADER_GHI = "GHI";
BINDING_NAME_GHI_TOGGLE = "Toggle GHI bag";

-- Book
GHI_LOADED = "Gryphonheart Items loaded.";
GHI_MANUAL_CREATED = "GHI Manual created.";
GHI_IN_COMBAT_ERROR = "You can not do that while in combat.";
GHI_CONFIRM_DELETE_PAGE = "Delete this page?";
GHI_ENTER_PAGE_NUMBER = "Enter pagenumber to link to";
GHI_ENTER_LINK_TEXT = "Enter link text";

GHI_DISABLE_BUFF_QUESTION = "Exiting a vehicle while being in combat will result in lockdown of the UI. \nIt is recommanded to disable GHI buffs when using vehicles. Buffs can be enabled in the GHI options menu (press '?'). \nDo you want to disable buffs now (requires reload of UI)?";
GHI_DISABLE_BUFF_RELOAD = "Disabling buffs will first happend after you have reloaded the UI. Reload UI now?";
GHI_SEC = "Second";
GHI_SEC_S = "Sec";
GHI_SECS = "Seconds";
GHI_SECS_S = "Secs";
GHI_MIN = "Minute";
GHI_MIN_S = "Min";
GHI_MINS = "Minutes";
GHI_MINS_S = "Mins";
GHI_HOUR = "Hour";
GHI_HOUR_S = "Hour";
GHI_HOURS = "Hours";
GHI_HOURS_S = "Hours";
GHI_DAY = "Day";
GHI_DAY_S = "Day";
GHI_DAYS = "Days";
GHI_DAYS_S = "Days";

GHI_SPAM_LIMIT_REACHED = "GHI spam limit reached. Say and emote messages done with GHI will be blocked in up to one minute.";

--	Help Menu
GHI_HELP_TITLE = "GHI Info and Options";
GHI_HELP_ADD_INFO = "Information, tips, updates, ideas and feedback \ncan be found and given on the forum: \nhttp://www.pilus.info/forum";
GHI_HELP_BACKPACK_ICON = "GHI Backpack Icon";
GHI_SCALE = "Scale:";
GHI_CENTER_ICON = "Center Icon";
GHI_DISABLE_BUFFS = "Disable Buffs";
GHI_SHOW_WARNING = "Show Warning When Entering a Vehicle";
GHI_BLOCK_STD_EMOTE = "Hide next std emote after emote with \"   \"";

-- Create item menu
GHI_CREATE_TITLE = "Create new GHI item";
GHI_GENERAL_ITEM_INFO = "General Item Info";
GHI_NAME = "Name:";
GHI_QUALITY = "Quality:";
GHI_ICON = "Icon:";
GHI_WHITE_TEXT_1 = "White text 1:";
GHI_WHITE_TEXT_2 = "White text 2:";
GHI_YELLOW_QUOTE = "Yellow quoted text:";
GHI_AMOUNT = "Amount:";
GHI_STACK_SIZE = "Stack Size:";
GHI_COPYABLE = "Copyable by others";
GHI_ITEM_DURATION = "Item duration:";
GHI_DURATION_WHEN_TRADED = "Start duration when traded";
GHI_USE_REAL_TIME = "Use real time, instead of played time for duration.";

GHI_RIGHT_CLICK = "Rightclick Actions";
GHI_DETAILS = "Details";
GHI_RUN_REQ = "Run When Req.";
GHI_RUN_ALWAYS = "Run Always";
GHI_IS_FORFILLED = "is forfilled";
GHI_BEFORE_REQ = "Before Req."
GHI_IS_NOT_FORFILLED = "is not forfilled"
GHI_NEW_RIGHT_CLICK = "New rightclick action:";
GHI_ADD_NEW = "Add New";
GHI_DELETE = "Delete";
GHI_EDIT = "Edit";
GHI_RIGHT_CLICK_HELP = "Choose the desired type of rigth click action and press add new, to add a new right click action. \nUse the \"run when requirement\" buttons to run an action when the requirement is forfilled, is not forfilled or to run it always.";
GHI_USE = "Use:";
GHI_ITEM_CD = "Item cooldown:";
GHI_CONSUMED = "Consumed";


GHI_ONE_TYPE_WARNING = "Each item can only have one of the right click action:"
GHI_GHR_WARNING = "You must have GHR and be a faction officer or higher rank to make an item that rewards reputation.";



-- right click actions
GHI_TYPE = "Type:";
GHI_TYPE_U = "Type";
GHI_DELAY = "Delay:";
GHI_TEXT = "Text:";

GHI_SAY = "Say";
GHI_EMOTE = "Emote";

GHI_EXPRESSION_TEXT = "Please enter the expression type, its text and eventual delay (in sec). \nWrite %L to insert a link of the item.";
GHI_EXPRESSION = "Expression";
GHI_EXPRESSIONS = "Expressions";
GHI_RANDOM_EXPRESSION = "Random Expression";
GHI_RANDOM_EXPRESSION_TEXT = "Please choose the expression types and enter their text. Each will be randomly chosen and run. Empty fields will be ignored.";
GHI_RANDOM_EXPRESSION_ALLOW_SAME = "Allow the same outcome twice in a row.";

GHI_SCRIPT = "Script";
GHI_SCRIPT_TEXT = "Scripts may consist of any lua code, except restricted functions. / commands is not allowed.";

-- 
GHI_BOOK = "Book";
GHI_TITLE = "Title:";
GHI_TITLE_TEXT = "Please enter enter a title above. Title and many more book related information can be changed later in the book edit menu.";

GHI_BUFF = "Buff";
GHI_BUFF_NAME = "Buff name:";
GHI_BUFF_DETAILS = "Buff details:";
GHI_BUFF_DURATION = "Buff duration:";
GHI_BUFF_UNTIL_CANCELED = "Last untill canceled";
GHI_BUFF_ON_SELF = "Always cast on self";
GHI_STACKABLE = "Stackable";
GHI_BUFF_DEBUFF = "Buff / Debuff:";
GHI_BUFF_TYPE = "Buff Type:";

GHI_SOUND = "Sound";
GHI_SOUNDFILEPATH = "Soundfile path:";
GHI_SOUND_EX = "Enter a sound filepath and a delay. \nE.g.   Sound\\Creature\\Murloc\\mMurlocAggroOld.wav ";

GHI_EQUIP_ITEM = "Equip Item";
GHI_ITEM_NAME = "Item Name:";

GHI_BAG = "Bag";
GHI_SLOTS = "Slots:";
GHI_TEXTURE = "Texture:";
GHI_NORMAL = "Normal";
GHI_BANK = "Bank";
GHI_KEYRING = "Keyring";

GHI_GHR = "GHR Reputation";
GHI_REP_WITH = "rep. with";
GHI_FACTION = "Faction:";

GHI_REQUIREMENT = "Requirement";
GHI_REQ_TYPE = "Requirement Type:";
GHI_REQ_FILTER = "Requirement filter:";
GHI_REQ_TOOLTIP = "Tooltip text (optional):";
GHI_REQ_TEXT1 = "In the Requirement filter you can enter either a single value/name, or multible values/names seperated by a comma. \nYou can also write intervals of numbers with a \"-\" and use \"+\" as an open interval.";
GHI_REQ_TEXT2 = "Example: Having \"Level\" as type and \"10-20,25,40-42,68+\" makes the requirement be forfilled if the players level is between 10 and 20, is 25, is between 40 and 42 or is above 68.";
GHI_REQ_TEXT3 = "Some types of requirement need to have multible things as information, those are seperated with a space.";
GHI_REQ_TEXT4 = "Example: Having \"Skill\" as type and \"Blacksmithing 120+\" will let the itep require above 120 in blackssmithing.";
GHI_REQ_TEXT5 = "If tooltip text is not left blank, it will be displayed as tooltip requirement instead of the standard, but if it is set to the text \"nil\", it will not display anything.";
GHI_REQ = {
["Name"] = "Name",
["Level"] = "Level",
["Zone"] = "Zone",
["SubZone"] = "SubZone",
["Guild"] = "Guild",
["Class"] = "Class",
["Race"] = "Race",
["Gender"] = "Gender",
["Normal Item"] = "Normal Item",
["Base Stats"] = "Base Stats",
["Skill"] = "Skill",
["Reputation"] = "Reputation",
["Honor Kills"] = "Honor Kills",
["Normal Buff"] = "Normal Buff",
["GHI Buff"] = "GHI Buff",
["LUA Statement"] = "LUA Statement"
};

GHI_TIME = "Time";
GHI_OUTPUT_TYPE = "Output type:";
GHI_TIME_FORMAT = "Time format:";
GHI_TIME_TEXT = "Please enter the output type, time format, its text and eventual delay (in sec). \nWrite TIME to in the text where the time should be inserted.";
GHI_GREEN_TEXT = "Green Text";
GHI_BLUE_TEXT = "Blue Text"

-- produce item
GHI_PRODUCE_ITEM = "Produce Item";
GHI_OF = "of";
GHI_CHOOSE_ITEM = "Choose Item";
GHI_MESSAGE_TEXT = "Message:";
GHI_PRODUCE_TEXT = "Please enter the amount and text for reciving item. Select the item by pressing the \"Choose Item.\" button and select the decired item in your GHI bag.";
GHI_NOT_BY_YOU = " is not made by you.";
GHI_LOOT = "Loot";
GHI_GET_LOOT = "You recieve loot:";
GHI_CREATE = "Create";
GHI_GET_CREATE = "You create:";
GHI_CRAFT = "Craft";
GHI_GET_CRAFT = "You craft:";
GHI_RECIEVE = "Recieve";
GHI_GET_RECIEVE = "You recieve:";
GHI_PRODUCE = "Produce";
GHI_GET_PRODUCE = "You produce:";

-- consume item
GHI_CONSUME = "Consume Item";
GHI_NOT_SOURCE_ID = "Could not identify source ID.";
GHI_NO_ITEM_SELECTED = "No item selected";
GHI_CONSUME_TEXT = "Please enter the consumed amount of the items. Select the item by pressing the \"Choose Item.\" button and select the decired item in your GHI bag.";

-- message
GHI_MESSAGE_TEXT_U = "Message"
GHI_CHAT_FRAME = "Chat Frame";
GHI_ERROR_MSG = "Error Message";
GHI_MSG_TEXT = "Please enter the output type, time format, its text and eventual delay (in sec). \nWrite TIME to in the text where the time should be inserted.";
GHI_COLOR = "Color:";
GHI_COLOR_NAMES = {};
GHI_COLOR_NAMES["red"] = "Red";
GHI_COLOR_NAMES["yellow"] = "Yellow";
GHI_COLOR_NAMES["gold"] = "Gold";
GHI_COLOR_NAMES["green"] = "Green";
GHI_COLOR_NAMES["green2"] = "Dark Green";
GHI_COLOR_NAMES["blue"] = "Blue";
GHI_COLOR_NAMES["blue2"] = "Dark Blue";
GHI_COLOR_NAMES["purple"] = "Violet";
GHI_COLOR_NAMES["teal"] = "Teal";
GHI_COLOR_NAMES["orange"] = "Orange";
GHI_COLOR_NAMES["Lgreen"] = "Light Green";
GHI_COLOR_NAMES["Lblue"] = "Light Blue";
GHI_COLOR_NAMES["Dgreen"] = "Ocean Green";
GHI_COLOR_NAMES["Pink"] = "Pink";
GHI_COLOR_NAMES["Dblue"] = "Purple";
GHI_COLOR_NAMES["brown"] = "Brown";
GHI_COLOR_NAMES["gray"] = "Gray";
GHI_COLOR_NAMES["white"] = "White";

-- Remove buff
GHI_REMOVE_BUFF = "Remove Buff";
GHI_REMOVE_BUFF_TEXT = "Please enter the name, amount and type of the buff or debuff to remove.";
GHI_HELPFUL = "Helpful";
GHI_HARMFUL = "Harmful";

-- Export
GHI_CAN_NOT_EXPORT = "You do not have premission or acess to export this item.";
GHI_EXPORT = "Export Item"
GHI_EXPORT_TEXT = "You can copy the code by marking it all (alt+a) and then press alt+c to copy it.\nYou can then paste it where you want to distribute it: On forums, over instant messengers to friends or on another character.";

GHI_CAN_NOT_PRODUCE_OFFICIAL = "You can not produce an official GHI item.";
GHI_CAN_NOT_PRODUCE_ITEM = "You can not produce the item.";
GHI_CAN_NOT_FIND_ITEM = "The item could not be found. ID: %s.";

GHI_CAN_NOT_IMPORT = "Can not import item.";
GHI_EXPORT_1LETTER = "Ex";
GHI_IMPORT_1LETTER = "Im";

GHI_TOTAL_PR_CHAR = "Total pr. char.";
GHI_NONE = "None";
GHI_CHARS = "Character(s)";
GHI_GUILDS = "Guild(s)";
GHI_ACCOUNTS = "Account(s)";
GHI_REALMS = "Realm(s)";
GHI_LIMITED_TO = "Limited to:";
GHI_NAMES = "Name(s):";
GHI_CHANGE_ID = "Give the item a new ID";
GHI_CHANGE_USER = "Change creator to be the importing user";
GHI_EXPORT_LIMITATION_TEXT = "Several names of limitations can be entered by seperating them by a comma.";

GHI_IMPORT = "Import Item";
GHI_IMPORT_INSTRUCTION = "Please paste the item code into the field and press import to import the item.";
GHI_IMPORT_REPORT = "Imported: %sx%s.";

-- v.0.99 / v.1.0 texts
GHI_EDISPLAY_1LETTER = "Eq";
GHI_EDISPLAY = "Equipment Display";
GHI_SLOT_NAME = "Slot Name:"
GHI_SCALE = "Scale:";
GHI_NEW_CUSTOM_SLOT = "New Custom Slot";
GHI_NEW_CUSTOM_SLOT_SHORT = "NCS";
GHI_SELECT_DISPLAYED_SLOTS = "Select Displayed Slots";
GHI_SELECT_DISPLAYED_SLOTS_SHORT = "SDS";
GHI_BACKGROUND = "Figure Background";
GHI_BACKGROUND_SHORT = "Bg";
GHI_TOGGLE_TARGET_EQD = "Toggle Equipment Display for target player.";
GHI_HIDE_EMPTY_SLOTS = "Hide empty slots in Equipment Display"

GHI_SLOT_NAMES = {
	belt = "Belt",
	neck = "Neck",
	left_foot="Left Foot",
	right_foot="Right Foot",
	left_ring="Left Finger",
	right_ring="Right Finger",
	chest="Chest",
	face="Face",
	head="Head",
	back="Back",
	leg_left_side="Left Leg",
	leg_right_side="Right Leg",
}
GHI_CUSTOM = "Custom";
GHI_STANDARD = "Standard";

GHI_INSPECT = "Inspect Item";
GHI_INSPECT_1LETTER = "In";
GHI_INSPECT_TT = "Item Inspection:";
GHI_RC_NUM = "%s right click actions";

GHI_BLOCK_AREA_SOUND = "Block all area sounds";
GHI_RANGE = "Range";
GHI_HELP_CREDITS = "By The Gryphonhear Team.\nhttp://www.pilus.info";

GHI_EDITABLE = "Editable by others";
GHI_CENTER_BUFFS = "Center Buffs";
GHI_BLOCK_AREA_BUFFS = "Block all area buffs";
GHI_REMOVE_BUFFS = "Clear Buffs";

GHI_EQD_SCRIPT = "The script can be used to control when the equipment display should be showed. If the script changes the value of SHOW to true, it is showed.";

end



function GHI_Localize()
	
	GHI_LocalizeEN();
	
	local locale = GetLocale();
	if ( locale == "deDE" ) then
		GHI_LocalizeDE();
	elseif (locale == "frFR") then
		GHI_LocalizeFR();
	end
end

GHI_Localize(); ---  this file must be run as last localization file