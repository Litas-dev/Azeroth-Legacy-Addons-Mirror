
GHI_RawOfficialItemData = {
	[1] = {
		["stackSize"] = 1,
		["white2"] = "",
		["rightClicktext"] = "Read text.",
		["rightClick"] = {
			{
				["text8"] = "",
				["text2"] = "us<BR/><BR/>www.pilus.info</H2><P></P></BODY></HTML>",
				["text6"] = "",
				["text4"] = "",
				["text5"] = "",
				["text3"] = "",
				["text1"] = "<HTML><BODY><P><BR/><BR/></P><H1 align=\"center\">GHI Beta Test Notes</H1><P><BR/><BR/></P><H2>Gryphonheart Items<BR/><BR/>By Pil",
				["text7"] = "",
			}, -- [1]
			{
				["text8"] = "",
				["text2"] = "</A><BR/><A href=\"5\">3. Features in GHI</A><BR/><A href=\"7\">4. The Backpack</A><BR/><A href=\"9\">5. Trading items and linking</A>",
				["text6"] = "",
				["text4"] = "<A href=\"14\">9. Reputation items - GHR</A><BR/><A href=\"15\">10. Scripts</A><BR/><A href=\"16\">11. Examples and Inspiration</A></P",
				["text5"] = "></BODY></HTML>",
				["text3"] = "<BR/><A href=\"10\">6. Right click buffs</A><BR/><A href=\"11\">7. Letters and books</A><BR/><A href=\"13\">8. Secondary bags</A><BR/>",
				["text1"] = "<HTML><BODY><P></P><H2>Table of Contenst</H2><P><BR/><A href=\"3\">1. Introduction</A><BR/><A href=\"4\">2. Bug report and feedback",
				["text7"] = "",
			}, -- [2]
			{
				["text8"] = "",
				["text2"] = "es included in GHI so far. It will also include some instructions regarding testing and feedback.<BR/><BR/>GHI gives the possibi",
				["text6"] = "",
				["text4"] = "tems got no effect on game mechanicals, but exist in the GHI backpack and can be used in links etc as detailed RP props. In that",
				["text5"] = " way it can enchant the RP experience with more immersion and creative options.<BR/></P></BODY></HTML>",
				["text3"] = "lity to create items for roleplaying. It can be everything from simple props to items with advanced right click functions. The i",
				["text1"] = "<HTML><BODY><P></P><H2>1. Introduction</H2><P>Welcome beta tester of GHI. This book will give you an introduction to the featur",
				["text7"] = "",
			}, -- [3]
			{
				["text8"] = "",
				["text2"] = "on. http://www.pilus.info/forum <BR/><BR/>As beta tester you will be needed to register in order to post on the GHI closed beta ",
				["text6"] = "",
				["text4"] = " to report it. <BR/></P></BODY></HTML>",
				["text5"] = "",
				["text3"] = "feedback forum. At that forum there is a list of known bugs. Whenever you find a bug not described in that list, do not hesitate",
				["text1"] = "<HTML><BODY><P></P><H2>2. Bug report and feedback</H2><P>All feedback and bug report should take place at the forum for the add",
				["text7"] = "",
			}, -- [4]
			{
				["text8"] = "",
				["text2"] = "st of them.<BR/>- Management of items in a backpack environment similar to the original backpacks.<BR/>- Copy items and edit ite",
				["text6"] = "",
				["text4"] = "ough the original trade frame.<BR/>- Place items in the original action bars (excluding the main action bar).<BR/>- Create items",
				["text5"] = " with right click effects.<BR/><BR/></P></BODY></HTML>",
				["text3"] = "ms made by yourself.<BR/>- Possibility to link items in all kind of chats.<BR/>- Trade items to other players with the addon, tr",
				["text1"] = "<HTML><BODY><P></P><H2>3. Features in GHI</H2><P>Currently GHI include the following features. As beta tester you should try mo",
				["text7"] = "",
			}, -- [5]
			{
				["text8"] = "",
				["text2"] = "person got the addon).<BR/>- Create a letter or book.<BR/>- Create additional secondary bags.<BR/>- Create an item that gives re",
				["text6"] = "",
				["text4"] = "",
				["text5"] = "",
				["text3"] = "putation (with GHR)<BR/>- Execute a script.<BR/></P></BODY></HTML>",
				["text1"] = "<HTML><BODY><P>The right click effects are currently the following:<BR/>- Cast a non combat buff on you or your target (if the ",
				["text7"] = "",
			}, -- [6]
			{
				["text8"] = "TML>",
				["text2"] = "in the middle of your screen, but you can move it by holding down shift and drag it. The main bag got 24 slots, but when it is m",
				["text6"] = "ome fields blank, if they should not be in the item. Mouse over the \"?\" next to the right click action drop down menu for detail",
				["text4"] = "pace is practically unlimited.<BR/><BR/>To create an item, press the \"N\" button in the main backpack. This will open up the crea",
				["text5"] = "te item menu. You should be able to create the item simply by filling in the information the item shall contain. You can leave s",
				["text3"] = "ore than half full, another page of the bag will be available. You can change page with the arrow buttons. In that way the bag s",
				["text1"] = "<HTML><BODY><P></P><H2>4. The Backpack</H2><P>To open the backpack, press the blue backpack icon. By default it will be placed ",
				["text7"] = "ed information of the current chosen right click action. Details about those can also be seen in this manual.<BR/></P></BODY></H",
			}, -- [7]
			{
				["text8"] = "",
				["text2"] = "dit. You can only edit items made by yourself. You can choose either to edit the current stack or all copies of the item. Note t",
				["text6"] = "",
				["text4"] = "press the \"C\" button at the backpack and then click on the item you want to copy. Choose the amount of copies you want, press co",
				["text5"] = "py and then place them where you want to.<BR/></P></BODY></HTML>",
				["text3"] = "hat copies of the items that you have traded to other players may not be changed right away as well. <BR/><BR/>To copy an item, ",
				["text1"] = "<HTML><BODY><P>If you want to edit one of your own items, then press the \"E\" button. Afterwards click on the item you want to e",
				["text7"] = "",
			}, -- [8]
			{
				["text8"] = "",
				["text2"] = "in the precise same was as original items.  Linking items does as well work in the exact same way as the original links. Shift c",
				["text6"] = "",
				["text4"] = "n, so others will instead see [item name].<BR/><BR/></P></BODY></HTML>",
				["text5"] = "",
				["text3"] = "lick an items while having the chat bar open will give you a link of the item. This link can of cause only be seen with the addo",
				["text1"] = "<HTML><BODY><P></P><H2>5. Trading items and linking items</H2><P>It is possible to trade items trough the original trade frame ",
				["text7"] = "",
			}, -- [9]
			{
				["text8"] = "",
				["text2"] = "he addon. The buff will look like a normal buff with name, description and duration. It will of cause not have any effect on gam",
				["text6"] = "",
				["text4"] = " effect on them IC. E.g. a [Bottle of Fresh Water] could give a refreshment buff that last five minutes. <BR/><BR/></P></BODY></",
				["text5"] = "HTML>",
				["text3"] = "e mechanicals. The buffs can be either helpful (buff) or harmful (debuff).  These give option to inform a player of some sort of",
				["text1"] = "<HTML><BODY><P></P><H2>6. Right click buffs</H2><P>The buff right click effect can be cast on yourself or another player with t",
				["text7"] = "",
			}, -- [10]
			{
				["text8"] = "",
				["text2"] = "g on the item to read it and then pressing the \"Edit\" button. This will bring up the edit book menu. It is possible to edit the ",
				["text6"] = "adline 2 button.  Using the headline tags is not necessary for making books, but it gives more options.</P></BODY></HTML>",
				["text4"] = "und and the font can also be changed here.<BR/><BR/>The text is build over html like tags, very similar to those used on forums.",
				["text5"] = " To create a headline use the h1 tags. This can be inserted automatically by marking the headline and press the Headline 1 or He",
				["text3"] = "title, insert and delete pages. It is also possible to undo changes in the text on the current page. The material of the backgro",
				["text1"] = "<HTML><BODY><P></P><H2>7. Letters and books</H2><P>When created the text in the letter or book can be inserted by right clickin",
				["text7"] = "",
			}, -- [11]
			{
				["text8"] = "",
				["text2"] = "\"insert link\" button. It is necessary to fill in the page number linked to and the text the link shall consist off. When the rea",
				["text6"] = "",
				["text4"] = "e book. This is done by pressing the insert icon button. You will then have to choose what icon to insert and its alignment (lef",
				["text5"] = "t, right or center). It is possible to insert a maximum of 5 icons on each page.<BR/></P></BODY></HTML>",
				["text3"] = "der clicks that text, they will jump to the defined page in the book. <BR/><BR/>It is also possible to insert a guild icon in th",
				["text1"] = "<HTML><BODY><P>Readers of the book are able to change between pages fast by using links. These can be inserted by pressing the ",
				["text7"] = "",
			}, -- [12]
			{
				["text8"] = "",
				["text2"] = "e other items in it, except for other bags. These gives options for making different kind of IC containers and does as well give",
				["text6"] = "",
				["text4"] = "",
				["text5"] = "",
				["text3"] = " possibility to organize the items better. E.g. Engineers could make a toolbox for IC tools.<BR/></P></BODY></HTML>",
				["text1"] = "<HTML><BODY><P></P><H2>8. Secondary bags</H2><P>A secondary bag can be opened by right clicking it. It is then possible to plac",
				["text7"] = "",
			}, -- [13]
			{
				["text8"] = "",
				["text2"] = "e to make reputation items. These can give a player reputation to a faction when right clicked. This can e.g. be used as honor t",
				["text6"] = "",
				["text4"] = "",
				["text5"] = "",
				["text3"] = "oken in the exact same way as the honor token from the original Agent Dawn faction. <BR/></P></BODY></HTML>",
				["text1"] = "<HTML><BODY><P></P><H2>9. Reputation items - GHR</H2><P>Players who got GHR and are faction officers or higher rank will be abl",
				["text7"] = "",
			}, -- [14]
			{
				["text8"] = "",
				["text2"] = "sibilities for creating item effects. With the limit of 2048 characters, there is rich amount of possibilities to write either s",
				["text6"] = "acter will do a  /wave  and so on. <BR/><BR/></P></BODY></HTML>",
				["text4"] = "ple commandes such as   say(\"Hello\")   or   emote (\"waves slowly\")   . Both say and emote can be latency so e.g.   say(\"Hi\",5)  ",
				["text5"] = " will make the character say \"Hi\" five seconds after the item is clicked. By writing short emotes like emote(\"wave\")    the char",
				["text3"] = "imple or advanced codes. <BR/><BR/>For those without knowledge of lua scripting, then there is also possibility to use a few sim",
				["text1"] = "<HTML><BODY><P></P><H2>10. Scripts</H2><P>By executing a script of lua code, this right click action gives almost unlimited pos",
				["text7"] = "",
			}, -- [15]
			{
				["text8"] = "",
				["text2"] = "nd a script right click action. The script could be:<BR/><BR/>emote(\"lifts his mug and drinks a bit of it.\")<BR/>say(\"Ahh.\",4)<B",
				["text6"] = "",
				["text4"] = "ght ale is drink.<BR/><BR/><BR/><BR/></P></BODY></HTML>",
				["text5"] = "",
				["text3"] = "R/>emote(\"starts to look a bit tipsy.\",20)<BR/><BR/>The say and the last emote will first be executed a few seconds after the li",
				["text1"] = "<HTML><BODY><P></P><H2>11. Examples and Inspiration</H2><P>[Light Ale]<BR/>Creating a item named [Light Ale], with a mug icon a",
				["text7"] = "",
			}, -- [16]
			{
				["text8"] = "",
				["text2"] = " something by a simple click on the item. The following script makes a related emote randomly. <BR/><BR/>local i = random(1,5);<",
				["text6"] = " the paper.\")<BR/>end</P></BODY></HTML>",
				["text4"] = " feather in the inkstand.\")<BR/>elseif i == 3 then<BR/>emote(\"continues to write.\")<BR/>elseif i == 4 then<BR/>emote(\"looks at t",
				["text5"] = "he feather while thinking deeply.\")<BR/>say(\"hmm.\",5)<BR/>else<BR/>emote(\"stops writing for a moment, making a small ink spot on",
				["text3"] = "BR/>if i == 1 then<BR/>emote(\"writes on the paper with his writing feather.\")<BR/>elseif i == 2 then<BR/>emote(\"dips his writing",
				["text1"] = "<HTML><BODY><P>[Writing Feather]<BR/>Being my personal favorite of use, a [Writing Feather] can indicate your character writing",
				["text7"] = "",
			}, -- [17]
			["Type"] = "book",
			["CD"] = 0,
			["h2"] = 19,
			["h1"] = 30,
			["font"] = "Fonts\\FRIZQT__.TTF",
			["title"] = "GHI Betatest Note",
			["material"] = "Parchment",
			["pages"] = 17,
			["n"] = 15,
		},
		["version"] = 16,
		["white1"] = "Book",
		["name"] = "GHI Beta Test Note",
		["creater"] = "Pilus",
		["locked"] = 0,
		["comment"] = "Introduction for GHI Beta Testers",
		["icon"] = "Interface\\Icons\\INV_Misc_Note_01",
		["quality"] = 2,
	},
	["version"] = 3,
}



