SpellSpy - A Spell Brower Addon
-------------------------------
With this addon you can lookup and browse all spells in World of Warcraft.
Slash command is "/ss". To set a spell filter use "/ss <filter>". Clear filter with "/ss --clear". Show spell by spell id "/ss --<id>"