-- Daily Items
-- Localisation
-- Last Update | 17/06/2010

if ( GetLocale() == "deDE" ) then -- [German, by Drathal]

-- Zones

	HBF = "Vorgebirge des H�gellands";
	SOS = "S�derstade";
	ICE = "Eiskrone";
	HFJ = "Der heulende Fjord";
	TSH = "Zwillingsk�ste";
	WBL = "Winterhauchsee";
	SHB = "Sholazarbecken";
	RVH = "Flussnabel";
	MDG = "Mord'rethar: Das Tor des Todes";
	TBF = "Die Zerbrochene Front";
	ADG = "Aldur'thar: Das Tor der Verw�stung";
	VFH = "Das Tal der Gefallenen Helden";
	IQD = "Insel von Quel'Danas";
	SRH = "Hafen der Sonnenweiten";
	SRA = "Waffenkammer der Sonnenweiten";
	TBO = "Die Blutschwur";
	TSL = "Die Sin'loren";
	TDC = "Die Morgensturm";
	TDS = "Platz der Morgenr�te";
	GGC = "K�ste der Gr�nkiemen";
	DSV = "Morgenstern";
	DES = "Die Todesschneise";
	TKF = "W�lder von Terokkar";
	RTR = "Messerdornh�he";
	TSP = "Die Sturmgipfel";
	FJA = "Fjorns Amboss";
	THF = "Donnerfall";
	VAW = "Das uralte Wintertal";
	TFM = "Die verlassene Mine";
	DRB = "Drachen�de";
	DML = "See von Drak'Mar";
	COS = "Das Ausmerzen von Stratholme";
	SOI = "Der Funke der Imagination";
	GZH = "Grizzlyh�gel";
	AWL = "Eschenholzsee";
	BNT = "Boreanische Tundra";
	NEX = "Der Nexus";
	GMB = "Garms Bann";
	TPF = "The Pit of the Fang";		-- To Be Translated
	ICC = "Icecrown Citadel";			-- To Be Translated
	NJV = "Njorndar Village";			-- To Be Translated

	SOA = "Strand der Uralten";
	WTG = "Tausendwintersee";
	IOC = "Insel der Eroberung";

-- Targets

	DSJ = "Dunkler Unterwerfer";
	ESM = "Versklavter Lakai";
	SRF = "Kampfaufkl�rer der Himmelsbrecher";
	EOH = "Abgesandter des Hasses";
	ERS = "Herumirrender Wachposten";
	WWM = "Wildwyrm";
	CFW = "Leiche des gefallenen Worgs";
	RJM = "Streunender Jormungar";
	EVK = "Ersch�pfter Vrykul";
	NDH = "Nexusdrachenjunges";
	SBF = "Schneeblinder Anh�nger";

--[[
elseif ( GetLocale() == "frFR" ) then
	DAL = "Dalaran";
elseif ( GetLocale() == "esES" ) then
	DAL = "Dalaran";
elseif ( GetLocale() == "zhTW" ) then 
	DAL = "Dalaran";
--]]

else -- [English, Original]

-- Zones

	HBF = "Hillsbrad Foothills";
	SOS = "Southshore";
	ICE = "Icecrown";
	HFJ = "Howling Fjord";
	TSH = "Twin Shores";
	WBL = "Winter's Breath Lake";
	SHB = "Sholazar Basin";
	RVH = "River's Heart";
	MDG = "Mord'rethar: The Death Gate";
	TBF = "The Broken Front";
	ADG = "Aldur'thar: The Desolation Gate";
	VFH = "The Valley of Fallen Heroes";
	IQD = "Isle of Quel'Danas";
	SRH = "Sun's Reach Harbor";
	SRA = "Sun's Reach Armory";
	TBO = "The Bloodoath";
	TSL = "The Sin'loren";
	TDC = "The Dawnchaser";
	TDS = "The Dawning Square";
	GGC = "Greengill Coast";
	DSV = "Dawnstar Village";
	DES = "The Dead Scar";
	TKF = "Terokkar Forest";
	RTR = "Razorthorn Rise";
	TSP = "The Storm Peaks";
	FJA = "Fjorn's Anvil";
	THF = "Thunderfall";
	VAW = "Valley of Ancient Winters";
	TFM = "The Forlorn Mine";
	DRB = "Dragonblight";
	DML = "Drak'Mar Lake";
	COS = "The Culling of Stratholme";
	SOI = "Spark of Imagination";
	GZH = "Grizzly Hills";
	AWL = "Ashwood Lake";
	BNT = "Borean Tundra";
	NEX = "The Nexus";
	GMB = "Garm's Bane";
	TPF = "The Pit of the Fang";
	ICC = "Icecrown Citadel";
	NJV = "Njorndar Village";

	SOA = "Strand of the Ancients";
	WTG = "Wintergrasp";
	IOC = "Isle of Conquest";

-- Targets

	DSJ = "Dark Subjugator";
	ESM = "Enslaved Minion";
	SRF = "Skybreaker Recon Fighter";
	EOH = "Emissary of Hate";
	ERS = "Erratic Sentry";
	WWM = "Wild Wyrm";
	CFW = "Corpse of the Fallen Worg";
	RJM = "Roaming Jormungar";
	EVK = "Exhausted Vrykul";
	NDH = "Nexus Drake Hatchling";
	SBF = "Snowblind Follower";

end

-- Not localised as such, due to them being hte same in any language (as far as I know)

DAL = "Dalaran";
ZLD = "Zul'Drak";
DRS = "Drak'Sotra";
KOL = "Kolramas";
NAG = "Nagrand";
HAL = "Halaa";
DUR = "Durotar";
ULD = "Ulduar";
COL = "Coldarra";

ANY = nul;