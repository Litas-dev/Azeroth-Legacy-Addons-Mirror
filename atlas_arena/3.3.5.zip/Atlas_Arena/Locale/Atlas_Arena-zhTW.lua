﻿--[[

	Atlas Arena, a World of Warcraft instance map browser
	Copyright 2010 Arith Hsu

	This file is a plugin of Atlas.

	Atlas Arena is free software; you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation; either version 2 of the License, or
	(at your option) any later version.

	Atlas is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with Atlas; if not, write to the Free Software
	Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

--]]
if ( GetLocale() ==	"zhTW" ) then

AtlasArenaLocale = {

	--Common
	["Arena Maps"] = "競技場地圖";
	["Short John Mithril"] = "小個子約翰·米斯瑞爾";

	-- Circle of Blood Arena
	["Frixee Brasstumbler <Arena Vendor>"] = "佛利基·銅杯 <競技場商人>";
	["Meminnie <Arena Vendor>"] = "蜜米妮 <競技場商人>";
	
	-- The Ring of Trials
	["Kelara <Keeper of Sha'tari Heirlooms>"] = "奇拉娜 <薩塔家傳物品保管人>";
	["Grikkin Copperspring <Arena Vendor>"] = "格利金·銅簧 <競技場商人>";
	
	-- The Rumble Cage
	["Max Luna <Arena Battlemaster>"] = "麥斯·路娜 <競技場戰場軍官>";
	["Vixton Pinchwhistle <Brutal Arena Vendor>"] = "維斯頓·急嘯 <野蠻競技場商人>";
	["Ecton Brasstumbler <Apprentice Arena Vendor>"] = "艾克頓·銅杯 <見習競技場商人>";
	["Evee Copperspring <Arena Vendor>"] = "伊薇·銅簧 <競技場商人>";
	["Argex Irongut <Veteran Arena Vendor>"] = "亞傑斯·鐵膽 <老練競技場商人>";
	["Blazzek the Biter <Exceptional Arena Weaponry>"] = "『詐欺者』布雷茲札克 <卓越競技場武器商>";
	["Bip Nigstrom <Arena Organizer>"] = "畢普·尼格斯卓 <競技場編制者>";

	-- Dalaran Sewers
	["Xazi Smolderpipe <Arena Vendor>"] = "札奇·燻管 <競技場商人>";
	["Zom Bocom <Apprentice Arena Vendor>"] = "扎姆·巴康 <見習競技場商人>";
	["Nargle Lashcord <Veteran Arena Vendor>"] = "納高·鞭索 <老練競技場商人>";
	["Trapjaw Rix <Exceptional Arena Weaponry>"] = "陷阱鉗瑞克斯 <卓越競技場武器商>";
};
end