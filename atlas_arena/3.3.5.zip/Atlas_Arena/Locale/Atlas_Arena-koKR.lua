﻿--[[

	Atlas Arena, a World of Warcraft instance map browser
	Copyright 2010 Arith Hsu

	This file is a plugin of Atlas.

	Atlas Arena is free software; you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation; either version 2 of the License, or
	(at your option) any later version.

	Atlas is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with Atlas; if not, write to the Free Software
	Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

--]]
if ( GetLocale() ==	"koKR" ) then

AtlasArenaLocale = {

	--Common
	["Arena Maps"] = "Arena Maps";
	["Short John Mithril"] = "땅딸보 존 미스릴";

	-- Circle of Blood Arena
	["Frixee Brasstumbler <Arena Vendor>"] = "프릭시 브래스텀블러 <투기장 상인>";
	["Meminnie <Arena Vendor>"] = "메미니 <투기장 상인>";
	
	-- The Ring of Trials
	["Kelara <Keeper of Sha'tari Heirlooms>"] = "켈라라 <샤타리 가보의 수호자>";
	["Grikkin Copperspring <Arena Vendor>"] = "그리킨 코퍼스프링 <투기장 상인>";
	
	-- The Rumble Cage
	["Max Luna <Arena Battlemaster>"] = "맥 루나 <투기장 사무관>";
	["Vixton Pinchwhistle <Brutal Arena Vendor>"] = "빅스톤 핀치휘슬 <냉혹한 투기장 상인>";
	["Ecton Brasstumbler <Apprentice Arena Vendor>"] = "엑튼 브래스텀블러 <투기장 상인>";
	["Evee Copperspring <Arena Vendor>"] = "에비 코퍼스프링 <투기장 상인>";
	["Argex Irongut <Veteran Arena Vendor>"] = "아르겍스 아이언구트 <老練競技場商人>";
	["Blazzek the Biter <Exceptional Arena Weaponry>"] = "Blazzek the Biter <Exceptional Arena Weaponry>"; -- To be translated
	["Bip Nigstrom <Arena Organizer>"] = "비프 닉스트롬 <투기장 조직위원>";

	-- Dalaran Sewers
	["Xazi Smolderpipe <Arena Vendor>"] = "자즈 스몰더파이프 <투기장 상인>";
	["Zom Bocom <Apprentice Arena Vendor>"] = "좀 보콤 <투기장 상인>";
	["Nargle Lashcord <Veteran Arena Vendor>"] = "나르글 래쉬코드 <전문 투기장 상인>";
	["Trapjaw Rix <Exceptional Arena Weaponry>"] = "트랩조 릭스 <특급 투기장 무기 상인>";
};
end