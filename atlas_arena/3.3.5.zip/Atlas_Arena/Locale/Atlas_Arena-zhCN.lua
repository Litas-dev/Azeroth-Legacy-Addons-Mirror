﻿--[[

	Atlas Arena, a World of Warcraft instance map browser
	Copyright 2010 Arith Hsu

	This file is a plugin of Atlas.

	Atlas Arena is free software; you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation; either version 2 of the License, or
	(at your option) any later version.

	Atlas is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with Atlas; if not, write to the Free Software
	Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

--]]
if ( GetLocale() ==	"zhCN" ) then

AtlasArenaLocale = {

	--Common
	["Arena Maps"] = "竞技场地图";

	-- Gurubashi Arena
	["Short John Mithril"] = "小个子约翰·米斯瑞尔";

	-- Circle of Blood Arena
	["Frixee Brasstumbler <Arena Vendor>"] = "弗里克希·布拉斯塔 <竞技场商人>";
	["Meminnie <Arena Vendor>"] = "蜜米妮 <竞技场商人>"; -- to be reviewed
	
	-- The Ring of Trials
	["Kelara <Keeper of Sha'tari Heirlooms>"] = "克尔拉兰 <沙塔尔宝物管理者>";
	["Grikkin Copperspring <Arena Vendor>"] = "格里金·考伯斯宾 <竞技场商人>";
	
	-- The Rumble Cage
	["Max Luna <Arena Battlemaster>"] = "麦克斯·卢纳 <竞技场管理员>";
	["Vixton Pinchwhistle <Brutal Arena Vendor>"] = "维克斯顿 <竞技场商人>";
	["Ecton Brasstumbler <Apprentice Arena Vendor>"] = "埃克顿·布拉斯塔 <竞技场商人>";
	["Evee Copperspring <Arena Vendor>"] = "伊维·考伯斯宾 <竞技场商人>";
	["Argex Irongut <Veteran Arena Vendor>"] = "亚杰斯•铁胆 <Veteran Arena Vendor>"; -- to be reviewed
	["Blazzek the Biter <Exceptional Arena Weaponry>"] = "『诈欺者』布雷兹札克 <Exceptional Arena Weaponry>";-- to be reviewed
	["Bip Nigstrom <Arena Organizer>"] = "比普·尼葛斯托 <竞技场组织者>";
	
	-- Dalaran Sewers
	["Xazi Smolderpipe <Arena Vendor>"] = "札奇•熏管 <竞技场商人>";-- to be reviewed
	["Zom Bocom <Apprentice Arena Vendor>"] = "扎姆•巴康 <见习竞技场商人>";-- to be reviewed
	["Nargle Lashcord <Veteran Arena Vendor>"] = "纳高•鞭索 <老练竞技场商人>";-- to be reviewed
	["Trapjaw Rix <Exceptional Arena Weaponry>"] = "陷阱钳瑞克斯 <卓越竞技场武器商>";-- to be reviewed


};
end
