﻿--[[

	Atlas Arena, a World of Warcraft instance map browser
	Copyright 2010 Arith Hsu

	This file is a plugin of Atlas.

	Atlas Arena is free software; you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation; either version 2 of the License, or
	(at your option) any later version.

	Atlas is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with Atlas; if not, write to the Free Software
	Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

--]]
if ( GetLocale() ==	"deDE" ) then

AtlasArenaLocale = {

	--Common
	["Arena Maps"] = "Arena Maps";

	-- Gurubashi Arena
	["Short John Mithril"] = "Störtebrecher";

	-- Circle of Blood Arena
	["Frixee Brasstumbler <Arena Vendor>"] = "Frixee Messingkipper <Arenaverkäufer>";
	["Meminnie <Arena Vendor>"] = "Meminnie <Arenaverkäufer>";
	
	-- The Ring of Trials
	["Kelara <Keeper of Sha'tari Heirlooms>"] = "Kelara <Bewahrerin des Erbes der Sha'tari>";
	["Grikkin Copperspring <Arena Vendor>"] = "Grikkin Kupferspule <Arenaverkäufer>";
	
	-- The Rumble Cage
	["Max Luna <Arena Battlemaster>"] = "Max Luna <Arenakampfmeister>";
	["Vixton Pinchwhistle <Brutal Arena Vendor>"] = "Vixton Quetschpfeife <Brutaler Arenaverkäufer>";
	["Ecton Brasstumbler <Apprentice Arena Vendor>"] = "Ecton Messingkipper <Arenaverkäufer>";
	["Evee Copperspring <Arena Vendor>"] = "Ivi Kupferspule <Arenaverkäufer>";
	["Argex Irongut <Veteran Arena Vendor>"] = "Argex Eisenmagen <Arenaverkäuferveteran>";
	["Blazzek the Biter <Exceptional Arena Weaponry>"] = "Blazzek der Beißer <Außergewöhnliche Arenawaffen>";
	["Bip Nigstrom <Arena Organizer>"] = "Bip Nigstrom <Arenaveranstalter>";
	
	-- Dalaran Sewers
	["Xazi Smolderpipe <Arena Vendor>"] = "Xazi Rauchpfeife <Arenaverkäuferin>";
	["Zom Bocom <Apprentice Arena Vendor>"] = "Zom Bocom <Arenaverkäuferlehrling>";
	["Nargle Lashcord <Veteran Arena Vendor>"] = "Nargel Peitschleine <Arenaverkäuferveteran>";
	["Trapjaw Rix <Exceptional Arena Weaponry>"] = "Eisenfang Rix <Außergewöhnliche Arenawaffen>";

};
end
