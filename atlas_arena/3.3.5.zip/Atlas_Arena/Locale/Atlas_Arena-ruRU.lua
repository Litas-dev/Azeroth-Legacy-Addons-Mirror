﻿--[[

	Atlas Arena, a World of Warcraft instance map browser
	Copyright 2010 Arith Hsu

	This file is a plugin of Atlas.

	Atlas Arena is free software; you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation; either version 2 of the License, or
	(at your option) any later version.

	Atlas is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with Atlas; if not, write to the Free Software
	Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

--]]
if ( GetLocale() ==	"ruRU" ) then

AtlasArenaLocale = {

	--Common
	["Arena Maps"] = "Arena Maps";

	-- Gurubashi Arena
	["Short John Mithril"] = "Коротышка Джон Мифрил";

	-- Circle of Blood Arena
	["Frixee Brasstumbler <Arena Vendor>"] = "Frixee Brasstumbler <Arena Vendor>"; -- To be translated
	["Meminnie <Arena Vendor>"] = "Мимыни <Продавец экипировки арены>";
	
	-- The Ring of Trials
	["Kelara <Keeper of Sha'tari Heirlooms>"] = "Келара <Хранитель наследия Ша'тар>";
	["Grikkin Copperspring <Arena Vendor>"] = "Grikkin Copperspring <Arena Vendor>"; -- To be translated
	
	-- The Rumble Cage
	["Max Luna <Arena Battlemaster>"] = "Макс Луна <Распорядитель арены>";
	["Vixton Pinchwhistle <Brutal Arena Vendor>"] = "Викстон Паросвист <Жестокий продавец экипировки арены>";
	["Ecton Brasstumbler <Apprentice Arena Vendor>"] = "Эктон Меднотумблер <Продавец экипировки арены>";
	["Evee Copperspring <Arena Vendor>"] = "Evee Copperspring <Arena Vendor>"; -- To be translated
	["Argex Irongut <Veteran Arena Vendor>"] = "Арджекс Сталечрев <Опытный продавец экипировки арены>";
	["Blazzek the Biter <Exceptional Arena Weaponry>"] = "Блаззек Кусака <Исключительное оружие для арены>";
	["Bip Nigstrom <Arena Organizer>"] = "Бип Выгоднус <Организатор боев на арене>";
	
	-- Dalaran Sewers
	["Xazi Smolderpipe <Arena Vendor>"] = "Ксази Смолилка <Продавец экипировки арены>";
	["Zom Bocom <Apprentice Arena Vendor>"] = "Зом Боком <Младший продавец экипировки арены>";
	["Nargle Lashcord <Veteran Arena Vendor>"] = "Наргл Гибкошнур <Опытный продавец экипировки арены>";
	["Trapjaw Rix <Exceptional Arena Weaponry>"] = "Чуднокусь Рикс <Исключительное оружие для арены>";

};
end
