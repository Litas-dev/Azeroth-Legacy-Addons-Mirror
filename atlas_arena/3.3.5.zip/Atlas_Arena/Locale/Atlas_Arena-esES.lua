﻿--[[

	Atlas Arena, a World of Warcraft instance map browser
	Copyright 2010 Arith Hsu

	This file is a plugin of Atlas.

	Atlas Arena is free software; you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation; either version 2 of the License, or
	(at your option) any later version.

	Atlas is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with Atlas; if not, write to the Free Software
	Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

--]]
if ( GetLocale() ==	"esES" ) then

AtlasArenaLocale = {

	--Common
	["Arena Maps"] = "Arena Maps";

	-- Gurubashi Arena
	["Short John Mithril"] = "Corto John Mitril";

	-- Circle of Blood Arena
	["Frixee Brasstumbler <Arena Vendor>"] = "Frixee Cabriolatón <Vendedora de arena>";
	["Meminnie <Arena Vendor>"] = "Meminnie <Vendedora de arena>";
	
	-- The Ring of Trials
	["Kelara <Keeper of Sha'tari Heirlooms>"] = "Kelara <Vigilante de reliquias Sha'tari>";
	["Grikkin Copperspring <Arena Vendor>"] = "Grikkin Pococobre <Vendedor de arena>";
	
	-- The Rumble Cage
	["Max Luna <Arena Battlemaster>"] = "Max Luna <Maestro de batalla de arena>";
	["Vixton Pinchwhistle <Brutal Arena Vendor>"] = "Vixton Silbapellizco <Vendedor de arena brutal>";
	["Ecton Brasstumbler <Apprentice Arena Vendor>"] = "Ecton Brasstumbler Ecton Cabriolatón <Vendedor de arena>";
	["Evee Copperspring <Arena Vendor>"] = "Evee Pococobre <Vendedora de arena>";
	["Argex Irongut <Veteran Arena Vendor>"] = "Argex Intestihierro <Vendedor de arena experto>";
	["Blazzek the Biter <Exceptional Arena Weaponry>"] = "Blazzek el Dentellada <Armas de combates de arena excepcionales>";
	["Bip Nigstrom <Arena Organizer>"] = "Bip Nigstrom <Organizador de arena>";
	
	-- Dalaran Sewers
	["Xazi Smolderpipe <Arena Vendor>"] = "Xazi Pipa Humillo <Vendedor de arena>";
	["Zom Bocom <Apprentice Arena Vendor>"] = "Zom Bocom <Aprendiz de vendedor de arena>";
	["Nargle Lashcord <Veteran Arena Vendor>"] = "Nargle Trallacable <Vendedor de arena experto>";
	["Trapjaw Rix <Exceptional Arena Weaponry>"] = "Rix Quijatrampa <Armas de combates de arena excepcionales>";

};
end
