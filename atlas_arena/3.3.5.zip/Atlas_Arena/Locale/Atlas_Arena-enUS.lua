﻿--[[

	Atlas Arena, a World of Warcraft instance map browser
	Copyright 2010 Arith Hsu

	This file is a plugin of Atlas.

	Atlas Arena is free software; you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation; either version 2 of the License, or
	(at your option) any later version.

	Atlas is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with Atlas; if not, write to the Free Software
	Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

--]]
--if ( GetLocale() ==	"enUS" ) then

AtlasArenaLocale = {

	--Common
	["Arena Maps"] = "Arena Maps";
	
	-- Gurubashi Arena
	["Short John Mithril"] = "Short John Mithril";

	-- Circle of Blood Arena
	["Frixee Brasstumbler <Arena Vendor>"] = "Frixee Brasstumbler <Arena Vendor>";
	["Meminnie <Arena Vendor>"] = "Meminnie <Arena Vendor>";
	
	-- The Ring of Trials
	["Kelara <Keeper of Sha'tari Heirlooms>"] = "Kelara <Keeper of Sha'tari Heirlooms>";
	["Grikkin Copperspring <Arena Vendor>"] = "Grikkin Copperspring <Arena Vendor>";
	
	-- The Rumble Cage
	["Max Luna <Arena Battlemaster>"] = "Max Luna <Arena Battlemaster>";
	["Vixton Pinchwhistle <Brutal Arena Vendor>"] = "Vixton Pinchwhistle <Brutal Arena Vendor>";
	["Ecton Brasstumbler <Apprentice Arena Vendor>"] = "Ecton Brasstumbler <Apprentice Arena Vendor>";
	["Evee Copperspring <Arena Vendor>"] = "Evee Copperspring <Arena Vendor>";
	["Argex Irongut <Veteran Arena Vendor>"] = "Argex Irongut <Veteran Arena Vendor>";
	["Blazzek the Biter <Exceptional Arena Weaponry>"] = "Blazzek the Biter <Exceptional Arena Weaponry>";
	["Bip Nigstrom <Arena Organizer>"] = "Bip Nigstrom <Arena Organizer>";
	
	-- Dalaran Sewers
	["Xazi Smolderpipe <Arena Vendor>"] = "Xazi Smolderpipe <Arena Vendor>";
	["Zom Bocom <Apprentice Arena Vendor>"] = "Zom Bocom <Apprentice Arena Vendor>";
	["Nargle Lashcord <Veteran Arena Vendor>"] = "Nargle Lashcord <Veteran Arena Vendor>";
	["Trapjaw Rix <Exceptional Arena Weaponry>"] = "Trapjaw Rix <Exceptional Arena Weaponry>";

};
--end
