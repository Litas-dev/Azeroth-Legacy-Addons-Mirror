﻿--[[

	Atlas Arena, a World of Warcraft instance map browser
	Copyright 2010 Arith Hsu

	This file is a plugin of Atlas.

	Atlas Arena is free software; you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation; either version 2 of the License, or
	(at your option) any later version.

	Atlas is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with Atlas; if not, write to the Free Software
	Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

--]]
if ( GetLocale() ==	"frFR" ) then

AtlasArenaLocale = {

	--Common
	["Arena Maps"] = "Arena Maps";

	-- Gurubashi Arena
	["Short John Mithril"] = "Court John Mithril";

	-- Circle of Blood Arena
	["Frixee Brasstumbler <Arena Vendor>"] = "Frixee Briquedouille <Vendeuse de l'arène>";
	["Meminnie <Arena Vendor>"] = "Miminie <Vendeur de l'arène>";
	
	-- The Ring of Trials
	["Kelara <Keeper of Sha'tari Heirlooms>"] = "Kelara <Gardienne des héritages sha'tari>";
	["Grikkin Copperspring <Arena Vendor>"] = "Grikkin Cuivressort <Vendeur de l'arène>";
	
	-- The Rumble Cage
	["Max Luna <Arena Battlemaster>"] = "Max Luna <Maître de guerre de l'arène>";
	["Vixton Pinchwhistle <Brutal Arena Vendor>"] = "Vixton Sifflepince <Vendeur de l'arène brutale>";
	["Ecton Brasstumbler <Apprentice Arena Vendor>"] = "Ecton Briquedouille <Vendeur de l'arène>";
	["Evee Copperspring <Arena Vendor>"] = "Evee Cuivressort <Vendeuse de l'arène>";
	["Argex Irongut <Veteran Arena Vendor>"] = "Argex Tripenfer <Vendeur de l'arène vétéran>";
	["Blazzek the Biter <Exceptional Arena Weaponry>"] = "Blazzek le Mordant <Armes d'arène exceptionnelles>";
	["Bip Nigstrom <Arena Organizer>"] = "Bip Nigstrom <Organisateur de combats>";
	
	-- Dalaran Sewers
	["Xazi Smolderpipe <Arena Vendor>"] = "Xazi Fumetuyère <Vendeuse de l'arène>";
	["Zom Bocom <Apprentice Arena Vendor>"] = "Zom Bocom <Apprenti vendeur de l'arène>";
	["Nargle Lashcord <Veteran Arena Vendor>"] = "Nargle Cinglecorde <Vendeur de l'arène vétéran>";
	["Trapjaw Rix <Exceptional Arena Weaponry>"] = "Dentos Rix <Armes d'arène exceptionnelles>";

};
end
