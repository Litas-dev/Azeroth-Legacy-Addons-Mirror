--[[
worldbosses.en.lua
This file defines the loot buttons in the Atlas interface for the WorldBosses maps.
]]

AtlasLootWBBossButtons = {

    Corruptedancient = {
        "Corruptedancient";
        };

    Gonzor = {
        "Gonzor";
        };

    Kinggnok = {
        "Kinggnok";
        };

    Silithidlurker = {
        "Silithidlurker";
        };

    Volchan = {
        "Volchan";
        };

    Azuregos = {
        "Azuregos";
        };

    };