local config = EventHorizon.config


local usemouseover = true	-- Make this false or nil (or just delete the line altogether) to make your healing bars not change when you mouse over something.


function EventHorizon:InitializeClass()
	self.config.gcdSpellID = 1082
	
	-- Feral bars (most require token points in Feral just to make sure they're appropriate to show).
	
	-- Savage Roar (Cat)
	self:NewSpell({
		spellID = 52610,
		playerbuff = true,
		stance = 3,
		requiredTalent = {2,1},
	})
	
	-- Mangle (Bear)
	self:NewSpell({
		spellID = 33876,
		debuff = {33876, 33878, 46855}, -- Mangle - Cat, Mangle - Bear, Trauma
		unique = true,
		stance = 3,
		cooldown = true,
		requiredTalent = {2,26},
	})
	
	-- Mangle (Bear)
	self:NewSpell({
		spellID = 33878,
		debuff = {33878, 33876, 46855}, -- Mangle - Bear, Mangle - Cat, Trauma
		cooldown = true,
		unique = true,
		stance = 1,
		requiredTalent = {2,26},
	})
	
	-- Lacerate (Bear)
	self:NewSpell({
		spellID = 33745,
		debuff = true,
		stance = 1,
		requiredTalent = {2,1},
	})
	
	-- Demo Roar/AP Debuffs (Bear)
	self:NewSpell({
		spellID = 99,
		debuff = {1160,99,50511,26017}, --Demo Shout, Demo Roar (Druid), CoW (Warlock), Vindication (Paladin)
		unique = true,
		stance = 1,
		requiredTalent = {2,1},
	})
	
	-- Rip (Cat)
	self:NewSpell({
		spellID = 1079,
		debuff = true,
		refreshable = true,
		dot = 2,
		glyphrefresh = {3,54815,"Shred"},
		stance = 3,
		requiredTalent = {2,1},
	})
	
	-- Rake (Cat)
	self:NewSpell({
		spellID = 1822,
		debuff = true,
		dot = 3,
		stance = 3,
		requiredTalent = {2,1},
	})
	
	-- Enrage (Bear)
	self:NewSpell({
		spellID = 5229,
		playerbuff = true,
		cooldown = true,
		stance = 1,
		requiredTalent = {2,1},
	})
	
	-- Barkskin (Bear)
	self:NewSpell({
		spellID = 22812,
		playerbuff = true,
		cooldown = true,
		stance = 1,
		requiredTalent = {2,1},
	})
	
	-- Tiger's Fury (Cat, if specced)
	self:NewSpell({
		spellID = 5217,
		playerbuff = true,
		cooldown = true,
		stance = 3,
		requiredTalent = {2,25},
	})
	
	-- Berserk 
	self:NewSpell({
		spellID = 50334,
		playerbuff = true,
		cooldown = true,
		requiredTalent = {2,30},
	})

	-- Balance bars (most require Moonkin form).

	-- Wrath
	self:NewSpell({
		spellID = 5176,
		uniqueID = 48518,
		playerbuff = 48518,
		internalcooldown = 30,
		cast = true,
		requiredTalent = {1,18},
	})
	
	-- Starfire
	self:NewSpell({
		spellID = 2912,
		uniqueID = 48517,
		playerbuff = 48517,
		internalcooldown = 30,
		cast = true,
		requiredTalent = {1,18},
	})
	
	-- Moonfire
	self:NewSpell({
		spellID = 8921,
		debuff = true,
		dot = 3,
		refreshable = true,	-- Glyphed refreshes
		requiredTalent = {1,18},
		glyphrefresh = {3,54845,"Starfire"},
		cleu = "SPELL_CAST_SUCCESS",
	})
	
	-- Insect Swarm
	self:NewSpell({
		spellID = 24974,
		debuff = true,
		dot = 2,
		requiredTalent = {1,18},
	})
	
	-- Starfall
	self:NewSpell({
		spellID = 53199,
		playerbuff = true,
		cooldown = true,
		requiredTalent = {1,28},
	})
	
	-- Typhoon
	self:NewSpell({
		spellID = 53223,
		cooldown = true,
		playerbuff = {67360,71177,60569,60568}, -- Idol procs.
		requiredTalent = {1,24},
	})
	
	-- Resto bars (most require Swiftmend).
	
	-- Lifebloom
	self:NewSpell({
		spellID = 33763,
		playerbuff = true,
		auraunit = usemouseover and 'mouseover' or 'target',
		refreshable = true,		-- Whaddya know. It refreshes...
		dot = 1,
		requiredTalent = {3,18},
	})
	
	-- Rejuvenation
	self:NewSpell({
		spellID = 774,
		playerbuff = true,
		auraunit = usemouseover and 'mouseover' or 'target',
		dot = 3,
		requiredTalent = {3,18},
		hasted = 71013,			-- Glyph of Rejuvenation
		expectedTicks = 6,
	})
	
	-- Regrowth
	self:NewSpell({
		spellID = 8936,
		cast = true,
		playerbuff = true,
		auraunit = usemouseover and 'mouseover' or 'target',
		dot = 3,
		requiredTalent = {3,18},
	})
	
	-- Swiftmend
	self:NewSpell({
		spellID = 18562,
		auraunit = usemouseover and 'mouseover' or 'target',
		cooldown = true,
		requiredTalent = {3,18},
	})
	
	-- Wild Growth
	self:NewSpell({
		spellID = 53249,
		playerbuff = true,
		auraunit = usemouseover and 'mouseover' or 'target',
		cooldown = true,
		dot = 1,
		requiredTalent = {3,27},
	})
	
	-- Nourish (including Nature's Grace)
	self:NewSpell({
		spellID = 50464,
		playerbuff = 16886,
		auraunit = usemouseover and 'mouseover' or 'target',
		cast = true,
		requiredTalent = {3,18},
	})
	
	-- Omen of Clarity (all specs)
	self:NewSpell({
		spellID = 16870,
		playerbuff = true,
		refreshable = true,
		requiredTalent = {3,8},
	})
	
	return true
end
