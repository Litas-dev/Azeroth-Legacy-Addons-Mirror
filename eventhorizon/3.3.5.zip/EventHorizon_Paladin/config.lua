local config = EventHorizon.config


local usemouseover = true	-- Make this false or nil (or just delete the line altogether) to make your healing bars not change when you mouse over something.


function EventHorizon:InitializeClass()
	self.config.gcdSpellID = 19740 -- Blessing of Might

	--Spell ordering, while seemingly random, is based on prioritization for each spec.
		
	-- Holy Shield
	self:NewSpell({
		spellID = 48952,
		cooldown = true,
		requiredTalent = {2,17},
	})
	
	-- Shield of Righteousness
	self:NewSpell({
		spellID = 61411,
		cooldown = true,
		requiredTalent = {2,17},
	})
		
	-- Judgement of Wisdom (including Judgements of the Pure, Holy only)
	self:NewSpell({
		spellID = 53408,
		playerbuff = 54153,
		cooldown = true,
		requiredTalent = {1,23},
	})
	
	-- Judgements
	self:NewSpell({
		spellID = 20271,
		debuff = {20271,20184,20184},
		cooldown = true,
		requiredTalent = {1,23,0},
	})
	
	-- Divine Storm
	self:NewSpell({
		spellID = 53385,
		cooldown = true,
		requiredTalent = {3,26},
	})
	
	-- Crusader Strike
	self:NewSpell({
		spellID = 35395,
		cooldown = true,
		requiredTalent = {3,23},
	})

	-- Hammer of the Righteous
	self:NewSpell({
		spellID = 53595,
		cooldown = true,
		requiredTalent = {2,26},
	})
	
	-- Consecration
	self:NewSpell({
		spellID = 48819,
		cooldown = true,
		requiredTalent = {2,2},
	})
	
	-- Avenger's Shield
	self:NewSpell({
		spellID = 48827,
		cooldown = true,
		requiredTalent = {2,22},
	})
	
	-- Exorcism
	self:NewSpell({
		spellID = 48801,
		playerbuff = 59578,
		cast = true,
		cooldown = true,
		requiredTalent = {2,2},
	})
	
	--[[ Holy Wrath
	self:NewSpell({
		spellID = 48817,
		cooldown = true,
	}) --]]
	
	-- Hammer of Wrath
	self:NewSpell({
		spellID = 48806,
		cooldown = true,
		requiredTalent = {2,2},
	})
	
	-- Beacon of Light (on focus)
	self:NewSpell({
		spellID = 53563,
		playerbuff = true,
		auraunit = 'focus',
		requiredTalent = {1,26},
	})
	
	-- Sacred Shield (30 second effect)
	self:NewSpell({
		spellID = 53601,
		uniqueID = 53601,
		playerbuff = true,
		auraunit == usemouseover and 'mouseover' or 'target',
		requiredTalent = {1,7},
	})
	
	-- Holy Shock (including Infusion of Light)
	self:NewSpell({
		spellID = 48821,
		playerbuff = 53576,
		cooldown = true,
		requiredTalent = {1,18},
	})
	
	-- Holy Light (including Light's Grace)
	self:NewSpell({
		spellID = 25292,
		playerbuff = 31834,
		cast = true,
		requiredTalent = {1,7},
	})
	
	-- Flash of Light (including Sacred Shield heal effect)
	self:NewSpell({
		spellID = 48785,
		playerbuff = 66922,
		dot = 1,
		auraunit = usemouseover and 'mouseover' or 'target',
		cast = true,
		requiredTalent = {1,7},
	})
	
	return true
end
