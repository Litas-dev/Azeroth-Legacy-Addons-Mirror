local config = EventHorizon.config

function EventHorizon:InitializeClass()
self.config.gcdSpellID = 772

	--Rend
	self:NewSpell({
		spellID = 772,
		debuff = true,
		dot = 3,
		notstance = 3,
		requiredTalent = {1,12}, -- Taste for Blood
	})

	--Mortal Strike
	self:NewSpell({
		spellID = 21551,
		debuff = true,
		cooldown = true,
		requiredTalent = {1,25},
	})

	--Sudden Death
	self:NewSpell({
		spellID = 52437,
		playerbuff = true,
		requiredTalent = {1,27},
	})
	
	--Taste for Blood
	self:NewSpell({
		spellID = 60503,
		playerbuff = 60503,
		stance = 1,
		internalcooldown = 6,
		requiredTalent = {1,12},
	})
	
	--Bloodthirst
	self:NewSpell({
		spellID = 23881,
		cooldown = true,
		requiredTalent = {2,19},
	})
	
	--Shield Slam
	self:NewSpell({
		spellID = 23922,
		playerbuff = 58374,
		cooldown = true,
		requiredTalent = {3,8},
		keepIcon = true,
	})
	
	--Whirlwind
	self:NewSpell({
		spellID = 1680,
		cooldown = true,
		stance = 3,
	})
	
	--Bloodsurge (Slam!)
	self:NewSpell({
		spellID = 46916,
		playerbuff = true,
		requiredTalent = {2,20},
	})
	
	--Revenge
	self:NewSpell({
		spellID = 6572,
		cooldown = true,
		playerbuff = 50227, -- SNB
		stance = 2,
		requiredTalent = {1,26,0}, --Do not show if Unrelenting Assault is talented (no cooldown)
		keepIcon = true,
	})
	
	--Shield Block
	self:NewSpell({
		spellID = 2565,
		cooldown = true,
		playerbuff = true,
		stance = 2,
		requiredTalent = {3,8},
	})

	-- Shockwave
	self:NewSpell({
		spellID = 46968,
		debuff = true,
		cooldown = true,
		requiredTalent = {3,27},
	})
	
	--Thunder Clap
	self:NewSpell({
		spellID = 6343,
		debuff = {6343,58181,49231}, -- TC, Infected Wounds, Earth Shock
		unique = true,
		cooldown = true,
		notstance = 3,
		requiredTalent = {3,3}, -- Improved Thunder Clap
	})
	
	--Demo Shout
	self:NewSpell({
		spellID = 1160,
		debuff = {1160,99,50511,26017}, --Demo Shout, Demo Roar (Druid), CoW (Warlock), Vindication (Paladin)
		unique = true,
		stance = 2,
	})
	
	--Bladestorm
	self:NewSpell({
		spellID = 46924,
		playerbuff = true,
		cooldown = true,
		requiredTalent = {1,31},
	})
	return true
end
