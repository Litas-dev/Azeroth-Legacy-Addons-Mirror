local config = EventHorizon.config

function EventHorizon:InitializeClass()
	self.config.gcdSpellID = 686

	-- Glyph of Life Tap
	self:NewSpell({
		spellID = 63321,
		playerbuff = true, 
		requiredGlyph = 63320,
	})
	
	-- Haunt
	self:NewSpell({
		spellID = 48181,
		debuff = true,
		cooldown = true,
		cast = true,
		requiredTalent = {1,28},
	})
	
	-- Unstable Affliction 
	self:NewSpell({
		spellID = 30108,
		debuff = true, 
		dot = 3, 
		cast = true, 
		requiredTalent = {1,25},
	}) 
	
	-- Curses - The bar icon will change according to whichever was cast last, no need for duplicate entries.
	self:NewSpell({
		spellID = 980,
		debuff = {603, 1490, 1714, 702, 980},
		cooldown = 603,
		dot = 2,	-- This only affects CoA.
	}) 
	
	-- Corruption 
	self:NewSpell({
		spellID = 172,
		debuff = true, 
		dot = 3, 
		refreshable = true, 
		hasted = 70947,		-- Glyph of Quick Decay
		expectedTicks = 6,	-- Rank 1 and 2 WILL be inaccurate with this.
		requiredTalent = {3,26,0},
	}) 
	
	-- Chaos Bolt
	self:NewSpell({
		spellID = 50796,
		cast = true,
		cooldown = true,
		requiredTalent = {3,26},
	})
	
	-- Immolate 
	self:NewSpell({
		spellID = 348,
		debuff = true,
		dot = 3,
		cast = true,
		requiredTalent = {1,25,0},-- Show only if Unstable Affliction is *not* talented.
	})
	
	-- Conflagrate
	self:NewSpell({
		spellID = 17962,
		playerbuff = 54277,	-- Backdraft
		cooldown = true,
		requiredTalent = {3,17},
	})
	
	-- Incinerate
	self:NewSpell({
		spellID = 29722,
		cast = true,
		requiredTalent = {3,16}, -- Emberstorm
	})

	-- Shadow Bolt + Shadow Embrace
	self:NewSpell({            
		spellID = 686,
		debuff = 32394,
		refreshable = true,
		cast = true, 
		requiredTalent = {{1,14},{3,16,0}}, -- SE, no Emberstorm
	})
	
	-- Shadow Bolt + Shadow Mastery
	self:NewSpell({            
		spellID = 686,
		debuff = {17800,22959,12579}, -- SM, Scorch, Winter's Chill
		refreshable = true,
		unique = true,
		cast = true,
		requiredTalent = {{1,14,0},{3,16,0}}, -- No SE or Emberstorm
	})
	
	-- Drain Soul
	self:NewSpell({
		spellID = 27217,
		channeled = true,
		numhits = 5,
		requiredTalent = {1,24},
	})
	
	-- Metamorphosis
	self:NewSpell({
		spellID = 59672,
		playerbuff = true, 
		cooldown = true, 
		requiredTalent = {2,27},
	})
	
	return true
end
