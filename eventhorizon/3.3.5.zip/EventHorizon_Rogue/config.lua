local config = EventHorizon.config

function EventHorizon:InitializeClass()
	self.config.gcdSpellID = 1752
	-- Cripple+Waylay
	self:NewSpell({
		spellID = 3408,
		debuff = {3408,58181,51693}, -- Infected Wounds for 2v2
		unique = true,
		refreshable = true,
		requiredTalent = {3,23},
	})
	-- Hunger for Blood
	self:NewSpell({
		spellID = 51662,
		playerbuff = true,
		requiredTalent = {1,27},
	})
	-- Slice and Dice
	self:NewSpell({
		spellID = 5171,
		playerbuff = true,
	})
	-- Rupture
	self:NewSpell({
		spellID = 1943,
		debuff = true,
		refreshable = true,
		dot = 2,
		glyphrefresh = {3,56800,"Backstab"},
	})
	-- Ghostly Strike (pvp)
	self:NewSpell({
		spellID = 14278,
		playerbuff = true,
		cooldown = true,
		requiredTalent = {3,8},
	})
	-- Envenom
	self:NewSpell({
		spellID = 57993,
		playerbuff = true,
		requiredTalent = {1,27},
	})
	-- Deadly Poison
	self:NewSpell({
		spellID = 57970,
		debuff = {2818, 2819, 11353, 11354, 25349, 26968, 27187, 57969, 57970}, --Experimental.
		dot = 3,
		refreshable = true,
		requiredTalent = {3,25,0},
	})
	-- Tricks of the Trade
	self:NewSpell({
		spellID = 57934,
		playerbuff = true,
		cooldown = true,
	})
	-- Shadowstep
	self:NewSpell({
		spellID = 44373,
		playerbuff = 36563,	-- Watch 10sec ShS buff, not the 3sec speed boost.
		cooldown = true,
		requiredTalent = {3,25},
	})
	-- Cheat Death
	self:NewSpell({
		spellID = 45182,
		playerbuff = true,
		internalcooldown = 60,
		requiredTalent = {3,21},
	})
		-- Overkill
	self:NewSpell({
		spellID = 58427,
		playerbuff = true,
		requiredTalent = {1,19},
	})

	--[[ -- Expose Armor
	self:NewSpell({
		spellID = 8647,
		debuff = {7386,8647}, -- Sunder Armor, Expose Armor
		unique = true,
	})
	--]]
	return true
end
