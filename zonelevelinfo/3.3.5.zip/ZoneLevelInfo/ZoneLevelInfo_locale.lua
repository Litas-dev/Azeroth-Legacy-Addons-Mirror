﻿L = {

	 ["enUS"] = {

		 ["unknown zone"] = "unknown zone"
		,["Capital City"] = "Capital City"
		,["Sanctuary"]    = "Sanctuary"
		,["Horde"]        = "Horde"
		,["Alliance"]     = "Alliance"

	}
	,["deDE"] = {

		 ["unknown zone"] = "unbekannte Zone"
		,["Capital City"] = "Hauptstadt"
		,["Sanctuary"]    = "Sicheres Gebiet"
		,["Horde"]        = "Horde"
		,["Alliance"]     = "Allianz"

	}
	,["esES"] = {

		 ["unknown zone"] = "zona desconocida"
		,["Capital City"] = "Ciudad Capital"
		,["Sanctuary"]    = "Santuario"
		,["Horde"]        = "Horda"
		,["Alliance"]     = "Alianza"

	}
	,["frFR"] = {

		 ["unknown zone"] = "zone inconnue"
		,["Capital City"] = "Capitale"
		,["Sanctuary"]    = "Sanctuaire"
		,["Horde"]        = "Horde"
		,["Alliance"]     = "Alliance"

	}
	,["ruRU"] = {

		 ["unknown zone"] = "неизвестные зоны"
		,["Capital City"] = "Столица"
		,["Sanctuary"]    = "Святилище"
		,["Horde"]        = "Орда"
		,["Alliance"]     = "Альянс"

	}

	,



};

L = L[currentLocale];
