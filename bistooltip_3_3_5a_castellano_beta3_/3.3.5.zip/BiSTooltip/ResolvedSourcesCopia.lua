ResolvedSources = ResolvedSources or {}
ResolvedSources[30063] = {{ instance="Caverna Santuario Serpiente", boss="El Rondador de abajo (15.15%)" }}
ResolvedSources[30872] = {{ instance="La Cima Hyjal", boss="Ira Frioinvierno (16.20%)" }}
ResolvedSources[32235] = {{ instance="Templo Oscuro", boss="Illidan Tempestira (15.70%)" }}
ResolvedSources[32239] = {{ instance="Templo Oscuro", boss="Gran senor de la guerra Naj'entus (14.95%)" }}
ResolvedSources[32330] = {{ instance="Templo Oscuro", boss="Teron Sanguino (12.74%)" }}
ResolvedSources[32345] = {{ instance="Templo Oscuro", boss="Esencia de ira (15.63%)" }}
ResolvedSources[32373] = {{ instance="Templo Oscuro", boss="Sumo abisalico Zerevor (15.06%)" }}
ResolvedSources[32483] = {{ instance="Templo Oscuro", boss="Illidan Tempestira (14.10%)" }}
ResolvedSources[32496] = {{ instance="Templo Oscuro", boss="Illidan Tempestira (15.08%)" }}
ResolvedSources[32837] = {{ instance="Templo Oscuro", boss="Illidan Tempestira (4.61%)" }}
ResolvedSources[32838] = {{ instance="Templo Oscuro", boss="Illidan Tempestira (5.03%)" }}
ResolvedSources[33281] = {{ instance="Zul'Aman", boss="Akil'zon (12.55%)" }}
ResolvedSources[33829] = {{ instance="Zul'Aman", boss="Senor aojador Malacrass (12.70%)" }}
ResolvedSources[33831] = {{ instance="Zul'Aman", boss="Zul'jin (14.95%)" }}
ResolvedSources[34177] = {{ instance="Meseta de La Fuente del Sol", boss="Brutallus (13.58%)" }}
ResolvedSources[34179] = {{ instance="Meseta de La Fuente del Sol", boss="Brutallus (13.00%)" }}
ResolvedSources[34180] = {{ instance="Meseta de La Fuente del Sol", boss="Brutallus (14.53%)" }}
ResolvedSources[34181] = {{ instance="Meseta de La Fuente del Sol", boss="Brutallus (12.24%)" }}
ResolvedSources[34182] = {{ instance="Meseta de La Fuente del Sol", boss="Brumavil (13.99%)" }}
ResolvedSources[34185] = {{ instance="Meseta de La Fuente del Sol", boss="Brumavil (14.11%)" }}
ResolvedSources[34186] = {{ instance="Meseta de La Fuente del Sol", boss="Brumavil (16.51%)" }}
ResolvedSources[34188] = {{ instance="Meseta de La Fuente del Sol", boss="Brumavil (15.13%)" }}
ResolvedSources[34192] = {{ instance="Meseta de La Fuente del Sol", boss="Bruja suprema Alythess (18.64%)" }}
ResolvedSources[34194] = {{ instance="Meseta de La Fuente del Sol", boss="Bruja suprema Alythess (17.19%)" }}
ResolvedSources[34195] = {{ instance="Meseta de La Fuente del Sol", boss="Bruja suprema Alythess (17.19%)" }}
ResolvedSources[34198] = {{ instance="Meseta de La Fuente del Sol", boss="Bruja suprema Alythess (18.64%)" }}
ResolvedSources[34202] = {{ instance="Meseta de La Fuente del Sol", boss="Bruja suprema Alythess (18.30%)" }}
ResolvedSources[34204] = {{ instance="Meseta de La Fuente del Sol", boss="Bruja suprema Alythess (16.03%)" }}
ResolvedSources[34206] = {{ instance="Meseta de La Fuente del Sol", boss="Bruja suprema Alythess (18.55%)" }}
ResolvedSources[34209] = {{ instance="Meseta de La Fuente del Sol", boss="Bruja suprema Alythess (18.73%)" }}
ResolvedSources[34210] = {{ instance="Meseta de La Fuente del Sol", boss="Bruja suprema Alythess (19.07%)" }}
ResolvedSources[34211] = {{ instance="Meseta de La Fuente del Sol", boss="Entropius (13.04%)" }}
ResolvedSources[34213] = {{ instance="Meseta de La Fuente del Sol", boss="Entropius (14.90%)" }}
ResolvedSources[34215] = {{ instance="Meseta de La Fuente del Sol", boss="Entropius (13.41%)" }}
ResolvedSources[34230] = {{ instance="Meseta de La Fuente del Sol", boss="Entropius (14.24%)" }}
ResolvedSources[34231] = {{ instance="Meseta de La Fuente del Sol", boss="Entropius (14.11%)" }}
ResolvedSources[34232] = {{ instance="Meseta de La Fuente del Sol", boss="Entropius (14.61%)" }}
ResolvedSources[34233] = {{ instance="Meseta de La Fuente del Sol", boss="Entropius (12.58%)" }}
ResolvedSources[34234] = {{ instance="Meseta de La Fuente del Sol", boss="Entropius (14.78%)" }}
ResolvedSources[34240] = {{ instance="Meseta de La Fuente del Sol", boss="Entropius (14.45%)" }}
ResolvedSources[34241] = {{ instance="Meseta de La Fuente del Sol", boss="Kil'jaeden (13.30%)" }}
ResolvedSources[34242] = {{ instance="Meseta de La Fuente del Sol", boss="Kil'jaeden (13.30%)" }}
ResolvedSources[34243] = {{ instance="Meseta de La Fuente del Sol", boss="Kil'jaeden (11.44%)" }}
ResolvedSources[34244] = {{ instance="Meseta de La Fuente del Sol", boss="Kil'jaeden (17.02%)" }}
ResolvedSources[34331] = {{ instance="Meseta de La Fuente del Sol", boss="Kil'jaeden (14.89%)" }}
ResolvedSources[34332] = {{ instance="Meseta de La Fuente del Sol", boss="Kil'jaeden (12.63%)" }}
ResolvedSources[34333] = {{ instance="Meseta de La Fuente del Sol", boss="Kil'jaeden (14.49%)" }}
ResolvedSources[34334] = {{ instance="Meseta de La Fuente del Sol", boss="Kil'jaeden (5.59%)" }}
ResolvedSources[34335] = {{ instance="Meseta de La Fuente del Sol", boss="Kil'jaeden (12.90%)" }}
ResolvedSources[34336] = {{ instance="Meseta de La Fuente del Sol", boss="Kil'jaeden (11.44%)" }}
ResolvedSources[34337] = {{ instance="Meseta de La Fuente del Sol", boss="Kil'jaeden (16.22%)" }}
ResolvedSources[34339] = {{ instance="Meseta de La Fuente del Sol", boss="Kil'jaeden (16.09%)" }}
ResolvedSources[34340] = {{ instance="Meseta de La Fuente del Sol", boss="Kil'jaeden (17.95%)" }}
ResolvedSources[34341] = {{ instance="Meseta de La Fuente del Sol", boss="Kil'jaeden (11.04%)" }}
ResolvedSources[34342] = {{ instance="Meseta de La Fuente del Sol", boss="Kil'jaeden (15.29%)" }}
ResolvedSources[34343] = {{ instance="Meseta de La Fuente del Sol", boss="Kil'jaeden (14.36%)" }}
ResolvedSources[34344] = {{ instance="Meseta de La Fuente del Sol", boss="Kil'jaeden (16.89%)" }}
ResolvedSources[34345] = {{ instance="Meseta de La Fuente del Sol", boss="Kil'jaeden (13.43%)" }}
ResolvedSources[34352] = {{ instance="Meseta de La Fuente del Sol", boss="Brumavil (14.23%)" }}
ResolvedSources[34427] = {{ instance="Meseta de La Fuente del Sol", boss="Entropius (12.67%)" }}
ResolvedSources[34429] = {{ instance="Meseta de La Fuente del Sol", boss="Entropius (16.56%)" }}
ResolvedSources[34472] = {{ instance="Bancal del Magister", boss="Sacerdotisa Delrissa (18.40%)" }}
ResolvedSources[34473] = {{ instance="Bancal del Magister", boss="Sacerdotisa Delrissa (17.59%)" }}
ResolvedSources[35591] = {{ instance="Gundrak", boss="Elemental Drakkari (9.96%)" }}
ResolvedSources[35617] = {{ instance="El Nexo (Normal)", boss="Gran maga Telestra (16.51%)" }}
ResolvedSources[35636] = {{ instance="Fortaleza de Drak'Tharon (Normal)", boss="El profeta Tharon'ja (8.09%)" }}
ResolvedSources[35642] = {{ instance="El Bastion Violeta (Normal)", boss="Xevozz (6.48%)" }}
ResolvedSources[35651] = {{ instance="El Bastion Violeta (Normal)", boss="Cianigosa (3.96%)" }}
ResolvedSources[35680] = {{ instance="Camaras de Piedra (Normal)", boss="Sjonnir el Afilador (2.49%)" }}
ResolvedSources[36944] = {{ instance="El Oculus (Normal)", boss="Drakos el Interrogador (1.24%)" }}
ResolvedSources[36945] = {{ instance="El Oculus (Normal)", boss="Drakos el Interrogador (1.08%)" }}
ResolvedSources[36947] = {{ instance="El Oculus (Normal)", boss="Varos Zancanubes (1.29%)" }}
ResolvedSources[36950] = {{ instance="El Oculus (Normal)", boss="Varos Zancanubes (1.28%)" }}
ResolvedSources[36951] = {{ instance="El Oculus (Normal)", boss="Senor de la Magia Urom (1.26%)" }}
ResolvedSources[36952] = {{ instance="El Oculus (Normal)", boss="Senor de la Magia Urom (1.16%)" }}
ResolvedSources[36954] = {{ instance="El Oculus (Normal)", boss="Senor de la Magia Urom (1.36%)" }}
ResolvedSources[36979] = {{ instance="Camara de los Relampagos (Normal)", boss="General Bjarngrim (6.93%)" }}
ResolvedSources[36982] = {{ instance="Camara de los Relampagos (Normal)", boss="General Bjarngrim (8.35%)" }}
ResolvedSources[36983] = {{ instance="Camara de los Relampagos (Normal)", boss="Volkhan (7.60%)" }}
ResolvedSources[36984] = {{ instance="Camara de los Relampagos (Normal)", boss="Volkhan (7.70%)" }}
ResolvedSources[36988] = {{ instance="Camara de los Relampagos (Normal)", boss="Loken (6.61%)" }}
ResolvedSources[36989] = {{ instance="Camara de los Relampagos (Normal)", boss="Loken (6.00%)" }}
ResolvedSources[36993] = {{ instance="Camara de los Relampagos (Normal)", boss="Loken (6.50%)" }}
ResolvedSources[37037] = {{ instance="Pinaculo de Utgarde (Normal)", boss="Svala Tumbapena (2.58%)" }}
ResolvedSources[37038] = {{ instance="Pinaculo de Utgarde (Normal)", boss="Svala Tumbapena (2.25%)" }}
ResolvedSources[37040] = {{ instance="Pinaculo de Utgarde (Normal)", boss="Svala Tumbapena (2.46%)" }}
ResolvedSources[37043] = {{ instance="Pinaculo de Utgarde (Normal)", boss="Svala Tumbapena (1.92%)" }}
ResolvedSources[37048] = {{ instance="Pinaculo de Utgarde (Normal)", boss="Gortok Pezuna Palida (2.08%)" }}
ResolvedSources[37051] = {{ instance="Pinaculo de Utgarde (Normal)", boss="Gortok Pezuna Palida (2.37%)" }}
ResolvedSources[37052] = {{ instance="Pinaculo de Utgarde (Normal)", boss="Gortok Pezuna Palida (2.15%)" }}
ResolvedSources[37053] = {{ instance="Pinaculo de Utgarde (Normal)", boss="Skadi el Despiadado (2.09%)" }}
ResolvedSources[37055] = {{ instance="Pinaculo de Utgarde (Normal)", boss="Skadi el Despiadado (2.23%)" }}
ResolvedSources[37057] = {{ instance="Pinaculo de Utgarde (Normal)", boss="Skadi el Despiadado (2.22%)" }}
ResolvedSources[37060] = {{ instance="Pinaculo de Utgarde (Normal)", boss="Rey Ymiron (1.53%)" }}
ResolvedSources[37061] = {{ instance="Pinaculo de Utgarde (Normal)", boss="Rey Ymiron (1.68%)" }}
ResolvedSources[37079] = {{ instance="La Matanza de Stratholme (Normal)", boss="Gancho (3.70%)" }}
ResolvedSources[37081] = {{ instance="La Matanza de Stratholme (Normal)", boss="Gancho (3.89%)" }}
ResolvedSources[37082] = {{ instance="La Matanza de Stratholme (Normal)", boss="Gancho (3.56%)" }}
ResolvedSources[37084] = {{ instance="La Matanza de Stratholme (Normal)", boss="Salramm el Modelador de carne (3.59%)" }}
ResolvedSources[37086] = {{ instance="La Matanza de Stratholme (Normal)", boss="Salramm el Modelador de carne (3.80%)" }}
ResolvedSources[37088] = {{ instance="La Matanza de Stratholme (Normal)", boss="Salramm el Modelador de carne (3.80%)" }}
ResolvedSources[37096] = {{ instance="La Matanza de Stratholme (Normal)", boss="Cronolord Epoca (3.50%)" }}
ResolvedSources[37099] = {{ instance="La Matanza de Stratholme (Normal)", boss="Cronolord Epoca (3.62%)" }}
ResolvedSources[37134] = {{ instance="El Nexo (Heroico)", boss="Gran maga Telestra (9.34%)" }}
ResolvedSources[37135] = {{ instance="El Nexo (Heroico)", boss="Gran maga Telestra (8.92%)" }}
ResolvedSources[37139] = {{ instance="El Nexo (Heroico)", boss="Gran maga Telestra (9.04%)" }}
ResolvedSources[37141] = {{ instance="El Nexo (Heroico)", boss="Anomalus (8.82%)" }}
ResolvedSources[37149] = {{ instance="El Nexo (Heroico)", boss="Anomalus (9.26%)" }}
ResolvedSources[37150] = {{ instance="El Nexo (Heroico)", boss="Anomalus (8.65%)" }}
ResolvedSources[37151] = {{ instance="El Nexo (Heroico)", boss="Ormorok el Talador (9.11%)" }}
ResolvedSources[37153] = {{ instance="El Nexo (Heroico)", boss="Ormorok el Talador (9.34%)" }}
ResolvedSources[37162] = {{ instance="El Nexo (Heroico)", boss="Keristrasza (7.85%)" }}
ResolvedSources[37170] = {{ instance="El Nexo (Heroico)", boss="Keristrasza (7.66%)" }}
ResolvedSources[37171] = {{ instance="El Nexo (Heroico)", boss="Keristrasza (7.52%)" }}
ResolvedSources[37172] = {{ instance="El Nexo (Heroico)", boss="Keristrasza (7.72%)" }}
ResolvedSources[37179] = {{ instance="Fortaleza de Utgarde (Heroico)", boss="Principe Keleseth (11.99%)" }}
ResolvedSources[37180] = {{ instance="Fortaleza de Utgarde (Heroico)", boss="Principe Keleseth (11.88%)" }}
ResolvedSources[37181] = {{ instance="Fortaleza de Utgarde (Heroico)", boss="Skarvald el Constructor (12.57%)" }}
ResolvedSources[37182] = {{ instance="Fortaleza de Utgarde (Heroico)", boss="Skarvald el Constructor (11.91%)" }}
ResolvedSources[37183] = {{ instance="Fortaleza de Utgarde (Heroico)", boss="Skarvald el Constructor (11.95%)" }}
ResolvedSources[37186] = {{ instance="Fortaleza de Utgarde (Heroico)", boss="Ingvar el Desvalijador (11.38%)" }}
ResolvedSources[37192] = {{ instance="Fortaleza de Utgarde (Heroico)", boss="Ingvar el Desvalijador (10.72%)" }}
ResolvedSources[37193] = {{ instance="Fortaleza de Utgarde (Heroico)", boss="Ingvar el Desvalijador (10.76%)" }}
ResolvedSources[37194] = {{ instance="Fortaleza de Utgarde (Heroico)", boss="Ingvar el Desvalijador (11.39%)" }}
ResolvedSources[37195] = {{ instance="El Oculus (Heroico)", boss="Senor de la Magia Urom (18.82%)" }}
ResolvedSources[37216] = {{ instance="Azjol-Nerub", boss="Krik'thir el Vigia de las puertas (14.86%)" }}
ResolvedSources[37217] = {{ instance="Azjol-Nerub", boss="Krik'thir el Vigia de las puertas (14.79%)" }}
ResolvedSources[37218] = {{ instance="Azjol-Nerub", boss="Krik'thir el Vigia de las puertas (14.79%)" }}
ResolvedSources[37219] = {{ instance="Azjol-Nerub", boss="Krik'thir el Vigia de las puertas (14.77%)" }}
ResolvedSources[37220] = {{ instance="Azjol-Nerub", boss="Hadronox (13.99%)" }}
ResolvedSources[37221] = {{ instance="Azjol-Nerub", boss="Hadronox (15.02%)" }}
ResolvedSources[37222] = {{ instance="Azjol-Nerub", boss="Hadronox (15.39%)" }}
ResolvedSources[37232] = {{ instance="Azjol-Nerub", boss="Anub'arak (12.69%)" }}
ResolvedSources[37235] = {{ instance="Azjol-Nerub", boss="Anub'arak (12.76%)" }}
ResolvedSources[37236] = {{ instance="Azjol-Nerub", boss="Anub'arak (12.47%)" }}
ResolvedSources[37237] = {{ instance="Azjol-Nerub", boss="Anub'arak (13.20%)" }}
ResolvedSources[37238] = {{ instance="Azjol-Nerub", boss="Anub'arak (13.05%)" }}
ResolvedSources[37240] = {{ instance="Azjol-Nerub", boss="Anub'arak (12.17%)" }}
ResolvedSources[37241] = {{ instance="Azjol-Nerub", boss="Anub'arak (13.23%)" }}
ResolvedSources[37242] = {{ instance="Azjol-Nerub", boss="Anub'arak (12.58%)" }}
ResolvedSources[37255] = {{ instance="El Oculus (Heroico)", boss="Drakos el Interrogador (17.51%)" }}
ResolvedSources[37256] = {{ instance="El Oculus (Heroico)", boss="Drakos el Interrogador (17.73%)" }}
ResolvedSources[37257] = {{ instance="El Oculus (Heroico)", boss="Drakos el Interrogador (17.77%)" }}
ResolvedSources[37258] = {{ instance="El Oculus (Heroico)", boss="Drakos el Interrogador (16.93%)" }}
ResolvedSources[37260] = {{ instance="El Oculus (Heroico)", boss="Varos Zancanubes (17.20%)" }}
ResolvedSources[37261] = {{ instance="El Oculus (Heroico)", boss="Varos Zancanubes (18.14%)" }}
ResolvedSources[37262] = {{ instance="El Oculus (Heroico)", boss="Varos Zancanubes (17.13%)" }}
ResolvedSources[37263] = {{ instance="El Oculus (Heroico)", boss="Varos Zancanubes (17.61%)" }}
ResolvedSources[37264] = {{ instance="El Oculus (Heroico)", boss="Senor de la Magia Urom (17.76%)" }}
ResolvedSources[37289] = {{ instance="El Oculus (Heroico)", boss="Senor de la Magia Urom (17.23%)" }}
ResolvedSources[37366] = { { instance="El Oculus (Heroico) (Heroico) (Heroico) (Heroico)", boss="Varios Jefes" } }
ResolvedSources[37367] = {{ instance="Pinaculo de Utgarde (Heroico)", boss="Svala Tumbapena (18.36%)" }}
ResolvedSources[37368] = {{ instance="Pinaculo de Utgarde (Heroico)", boss="Svala Tumbapena (19.04%)" }}
ResolvedSources[37369] = {{ instance="Pinaculo de Utgarde (Heroico)", boss="Svala Tumbapena (19.30%)" }}
ResolvedSources[37370] = {{ instance="Pinaculo de Utgarde (Heroico)", boss="Svala Tumbapena (18.92%)" }}
ResolvedSources[37371] = {{ instance="Pinaculo de Utgarde (Heroico)", boss="Gortok Pezuna Palida (19.03%)" }}
ResolvedSources[37373] = {{ instance="Pinaculo de Utgarde (Heroico)", boss="Gortok Pezuna Palida (17.93%)" }}
ResolvedSources[37374] = {{ instance="Pinaculo de Utgarde (Heroico)", boss="Gortok Pezuna Palida (19.55%)" }}
ResolvedSources[37376] = {{ instance="Pinaculo de Utgarde (Heroico)", boss="Gortok Pezuna Palida (19.43%)" }}
ResolvedSources[37377] = {{ instance="Pinaculo de Utgarde (Heroico)", boss="Skadi el Despiadado (18.25%)" }}
ResolvedSources[37379] = {{ instance="Pinaculo de Utgarde (Heroico)", boss="Skadi el Despiadado (18.36%)" }}
ResolvedSources[37384] = {{ instance="Pinaculo de Utgarde (Heroico)", boss="Skadi el Despiadado (17.02%)" }}
ResolvedSources[37389] = {{ instance="Pinaculo de Utgarde (Heroico)", boss="Skadi el Despiadado (18.88%)" }}
ResolvedSources[37390] = {{ instance="Pinaculo de Utgarde (Heroico)", boss="Rey Ymiron (16.88%)" }}
ResolvedSources[37397] = {{ instance="Pinaculo de Utgarde (Heroico)", boss="Rey Ymiron (15.58%)" }}
ResolvedSources[37398] = {{ instance="Pinaculo de Utgarde (Heroico)", boss="Rey Ymiron (16.08%)" }}
ResolvedSources[37401] = {{ instance="Pinaculo de Utgarde (Heroico)", boss="Rey Ymiron (16.61%)" }}
ResolvedSources[37407] = {{ instance="Pinaculo de Utgarde (Heroico)", boss="Rey Ymiron (15.17%)" }}
ResolvedSources[37408] = {{ instance="Pinaculo de Utgarde (Heroico)", boss="Rey Ymiron (16.57%)" }}
ResolvedSources[37409] = {{ instance="Pinaculo de Utgarde (Heroico)", boss="Rey Ymiron (16.74%)" }}
ResolvedSources[37591] = {{ instance="Ahn'kahet: El Antiguo Reino (Heroico)", boss="Ancestro Nadox (9.85%)" }}
ResolvedSources[37592] = {{ instance="Ahn'kahet: El Antiguo Reino (Heroico)", boss="Ancestro Nadox (8.82%)" }}
ResolvedSources[37593] = {{ instance="Ahn'kahet: El Antiguo Reino (Heroico)", boss="Ancestro Nadox (10.22%)" }}
ResolvedSources[37612] = {{ instance="Ahn'kahet: El Antiguo Reino (Heroico)", boss="Principe Taldaram (8.97%)" }}
ResolvedSources[37613] = {{ instance="Ahn'kahet: El Antiguo Reino (Heroico)", boss="Principe Taldaram (8.99%)" }}
ResolvedSources[37614] = {{ instance="Ahn'kahet: El Antiguo Reino (Heroico)", boss="Principe Taldaram (9.10%)" }}
ResolvedSources[37615] = {{ instance="Ahn'kahet: El Antiguo Reino (Heroico)", boss="Heraldo Volazj (8.90%)" }}
ResolvedSources[37622] = {{ instance="Ahn'kahet: El Antiguo Reino (Heroico)", boss="Heraldo Volazj (8.73%)" }}
ResolvedSources[37623] = {{ instance="Ahn'kahet: El Antiguo Reino (Heroico)", boss="Heraldo Volazj (8.44%)" }}
ResolvedSources[37626] = {{ instance="Gundrak", boss="Slad'ran (11.72%)" }}
ResolvedSources[37627] = {{ instance="Gundrak", boss="Slad'ran (12.60%)" }}
ResolvedSources[37629] = {{ instance="Gundrak", boss="Slad'ran (13.57%)" }}
ResolvedSources[37630] = {{ instance="Gundrak", boss="Moorabi (12.72%)" }}
ResolvedSources[37631] = {{ instance="Gundrak", boss="Moorabi (13.00%)" }}
ResolvedSources[37633] = {{ instance="Gundrak", boss="Moorabi (13.55%)" }}
ResolvedSources[37634] = {{ instance="Gundrak", boss="Elemental Drakkari (11.60%)" }}
ResolvedSources[37635] = {{ instance="Gundrak", boss="Elemental Drakkari (11.30%)" }}
ResolvedSources[37636] = {{ instance="Gundrak", boss="Elemental Drakkari (11.72%)" }}
ResolvedSources[37637] = {{ instance="Gundrak", boss="Elemental Drakkari (11.64%)" }}
ResolvedSources[37638] = {{ instance="Gundrak", boss="Gal'darah (11.90%)" }}
ResolvedSources[37639] = {{ instance="Gundrak", boss="Gal'darah (12.65%)" }}
ResolvedSources[37640] = {{ instance="Gundrak", boss="Gal'darah (11.39%)" }}
ResolvedSources[37641] = {{ instance="Gundrak", boss="Gal'darah (11.33%)" }}
ResolvedSources[37642] = {{ instance="Gundrak", boss="Gal'darah (12.17%)" }}
ResolvedSources[37643] = {{ instance="Gundrak", boss="Gal'darah (11.78%)" }}
ResolvedSources[37644] = {{ instance="Gundrak", boss="Gal'darah (11.54%)" }}
ResolvedSources[37651] = {{ instance="Camaras de Piedra (Heroico)", boss="Krystallus (18.60%)" }}
ResolvedSources[37652] = {{ instance="Camaras de Piedra (Heroico)", boss="Krystallus (17.86%)" }}
ResolvedSources[37657] = {{ instance="Camaras de Piedra (Heroico)", boss="Sjonnir el Afilador (13.43%)" }}
ResolvedSources[37658] = {{ instance="Camaras de Piedra (Heroico)", boss="Sjonnir el Afilador (12.66%)" }}
ResolvedSources[37660] = {{ instance="Camaras de Piedra (Heroico)", boss="Sjonnir el Afilador (13.52%)" }}
ResolvedSources[37666] = {{ instance="Camaras de Piedra (Heroico)", boss="Sjonnir el Afilador (12.69%)" }}
ResolvedSources[37667] = {{ instance="Camaras de Piedra (Heroico)", boss="Sjonnir el Afilador (12.84%)" }}
ResolvedSources[37668] = {{ instance="Camaras de Piedra (Heroico)", boss="Sjonnir el Afilador (12.70%)" }}
ResolvedSources[37669] = {{ instance="Camaras de Piedra (Heroico)", boss="Sjonnir el Afilador (12.61%)" }}
ResolvedSources[37675] = {{ instance="La Matanza de Stratholme (Heroico)", boss="Gancho (17.01%)" }}
ResolvedSources[37678] = {{ instance="La Matanza de Stratholme (Heroico)", boss="Gancho (16.70%)" }}
ResolvedSources[37679] = {{ instance="La Matanza de Stratholme (Heroico)", boss="Gancho (16.23%)" }}
ResolvedSources[37680] = {{ instance="La Matanza de Stratholme (Heroico)", boss="Gancho (16.39%)" }}
ResolvedSources[37681] = {{ instance="La Matanza de Stratholme (Heroico)", boss="Salramm el Modelador de carne (15.97%)" }}
ResolvedSources[37682] = {{ instance="La Matanza de Stratholme (Heroico)", boss="Salramm el Modelador de carne (17.00%)" }}
ResolvedSources[37683] = {{ instance="La Matanza de Stratholme (Heroico)", boss="Salramm el Modelador de carne (15.71%)" }}
ResolvedSources[37684] = {{ instance="La Matanza de Stratholme (Heroico)", boss="Salramm el Modelador de carne (16.60%)" }}
ResolvedSources[37685] = {{ instance="La Matanza de Stratholme (Heroico)", boss="Cronolord Epoca (16.67%)" }}
ResolvedSources[37687] = {{ instance="La Matanza de Stratholme (Heroico)", boss="Cronolord Epoca (15.57%)" }}
ResolvedSources[37712] = {{ instance="Fortaleza de Drak'Tharon (Heroico)", boss="Cuernotrol (14.11%)" }}
ResolvedSources[37714] = {{ instance="Fortaleza de Drak'Tharon (Heroico)", boss="Cuernotrol (14.77%)" }}
ResolvedSources[37715] = {{ instance="Fortaleza de Drak'Tharon (Heroico)", boss="Cuernotrol (14.51%)" }}
ResolvedSources[37718] = {{ instance="Fortaleza de Drak'Tharon (Heroico)", boss="Novos el Invocador (14.26%)" }}
ResolvedSources[37721] = {{ instance="Fortaleza de Drak'Tharon (Heroico)", boss="Novos el Invocador (15.11%)" }}
ResolvedSources[37722] = {{ instance="Fortaleza de Drak'Tharon (Heroico)", boss="Novos el Invocador (15.17%)" }}
ResolvedSources[37723] = {{ instance="Fortaleza de Drak'Tharon (Heroico)", boss="Rey Dred (13.76%)" }}
ResolvedSources[37724] = {{ instance="Fortaleza de Drak'Tharon (Heroico)", boss="Rey Dred (13.31%)" }}
ResolvedSources[37725] = {{ instance="Fortaleza de Drak'Tharon (Heroico)", boss="Rey Dred (13.13%)" }}
ResolvedSources[37726] = {{ instance="Fortaleza de Drak'Tharon (Heroico)", boss="Rey Dred (13.15%)" }}
ResolvedSources[37732] = {{ instance="Fortaleza de Drak'Tharon (Heroico)", boss="El profeta Tharon'ja (13.00%)" }}
ResolvedSources[37733] = {{ instance="Fortaleza de Drak'Tharon (Heroico)", boss="El profeta Tharon'ja (13.14%)" }}
ResolvedSources[37735] = {{ instance="Fortaleza de Drak'Tharon (Heroico)", boss="El profeta Tharon'ja (13.49%)" }}
ResolvedSources[37784] = {{ instance="Fortaleza de Drak'Tharon (Heroico)", boss="El profeta Tharon'ja (13.68%)" }}
ResolvedSources[37788] = {{ instance="Fortaleza de Drak'Tharon (Heroico)", boss="El profeta Tharon'ja (13.39%)" }}
ResolvedSources[37791] = {{ instance="Fortaleza de Drak'Tharon (Heroico)", boss="El profeta Tharon'ja (13.29%)" }}
ResolvedSources[37798] = {{ instance="Fortaleza de Drak'Tharon (Heroico)", boss="El profeta Tharon'ja (12.60%)" }}
ResolvedSources[37825] = {{ instance="Camara de los Relampagos (Heroico)", boss="General Bjarngrim (13.68%)" }}
ResolvedSources[37826] = {{ instance="Camara de los Relampagos (Heroico)", boss="General Bjarngrim (12.95%)" }}
ResolvedSources[37840] = {{ instance="Camara de los Relampagos (Heroico)", boss="Volkhan (13.31%)" }}
ResolvedSources[37841] = {{ instance="Camara de los Relampagos (Heroico)", boss="Volkhan (13.36%)" }}
ResolvedSources[37842] = {{ instance="Camara de los Relampagos (Heroico)", boss="Volkhan (13.02%)" }}
ResolvedSources[37843] = {{ instance="Camara de los Relampagos (Heroico)", boss="Volkhan (13.32%)" }}
ResolvedSources[37844] = {{ instance="Camara de los Relampagos (Heroico)", boss="Ionar (13.03%)" }}
ResolvedSources[37845] = {{ instance="Camara de los Relampagos (Heroico)", boss="Ionar (12.96%)" }}
ResolvedSources[37846] = {{ instance="Camara de los Relampagos (Heroico)", boss="Ionar (13.05%)" }}
ResolvedSources[37848] = {{ instance="Camara de los Relampagos (Heroico)", boss="Loken (11.31%)" }}
ResolvedSources[37849] = {{ instance="Camara de los Relampagos (Heroico)", boss="Loken (11.93%)" }}
ResolvedSources[37850] = {{ instance="Camara de los Relampagos (Heroico)", boss="Loken (11.81%)" }}
ResolvedSources[37851] = {{ instance="Camara de los Relampagos (Heroico)", boss="Loken (12.26%)" }}
ResolvedSources[37852] = {{ instance="Camara de los Relampagos (Heroico)", boss="Loken (11.96%)" }}
ResolvedSources[37853] = {{ instance="Camara de los Relampagos (Heroico)", boss="Loken (12.26%)" }}
ResolvedSources[37854] = {{ instance="Camara de los Relampagos (Heroico)", boss="Loken (11.40%)" }}
ResolvedSources[37861] = {{ instance="El Bastion Violeta (Heroico)", boss="Xevozz (21.41%)" }}
ResolvedSources[37862] = {{ instance="El Bastion Violeta (Heroico)", boss="Icoron (21.17%)" }}
ResolvedSources[37867] = {{ instance="El Bastion Violeta (Heroico)", boss="Xevozz (22.32%)" }}
ResolvedSources[37868] = {{ instance="El Bastion Violeta (Heroico)", boss="Xevozz (22.52%)" }}
ResolvedSources[37869] = {{ instance="El Bastion Violeta (Heroico)", boss="Icoron (20.63%)" }}
ResolvedSources[37870] = {{ instance="El Bastion Violeta (Heroico)", boss="Lavanthor (21.23%)" }}
ResolvedSources[37871] = {{ instance="El Bastion Violeta (Heroico)", boss="Lavanthor (21.55%)" }}
ResolvedSources[37872] = {{ instance="El Bastion Violeta (Heroico)", boss="Lavanthor (22.53%)" }}
ResolvedSources[37873] = {{ instance="El Bastion Violeta (Heroico)", boss="Cianigosa (15.40%)" }}
ResolvedSources[37874] = {{ instance="El Bastion Violeta (Heroico)", boss="Cianigosa (15.71%)" }}
ResolvedSources[37875] = {{ instance="El Bastion Violeta (Heroico)", boss="Cianigosa (15.91%)" }}
ResolvedSources[37876] = {{ instance="El Bastion Violeta (Heroico)", boss="Cianigosa (15.31%)" }}
ResolvedSources[37883] = {{ instance="El Bastion Violeta (Heroico)", boss="Cianigosa (15.35%)" }}
ResolvedSources[37884] = {{ instance="El Bastion Violeta (Heroico)", boss="Cianigosa (15.19%)" }}
ResolvedSources[37886] = {{ instance="El Bastion Violeta (Heroico)", boss="Cianigosa (15.63%)" }}
ResolvedSources[38614] = {{ instance="Camaras de Piedra (Normal) (Normal) (Normal) (Normal)", boss="Doncella de Pena (4.88%)" }}
ResolvedSources[38617] = {{ instance="Camaras de Piedra (Heroico) (Heroico) (Heroico) (Heroico)", boss="Doncella de Pena (14.91%)" }}
ResolvedSources[39193] = {{ instance="Naxxramas", boss="Anub'Rekhan (2.46%)" }}
ResolvedSources[39197] = {{ instance="Naxxramas", boss="Gran Viuda Faerlina (2.63%)" }}
ResolvedSources[39200] = {{ instance="Naxxramas", boss="Gran Viuda Faerlina (2.60%)" }}
ResolvedSources[39248] = {{ instance="Naxxramas", boss="Heigan el Impuro (2.75%)" }}
ResolvedSources[39254] = {{ instance="Naxxramas", boss="Heigan el Impuro (3.08%)" }}
ResolvedSources[39393] = {{ instance="El Nexo (Heroico)", boss="Gran maga Telestra (7.40%)" }}
ResolvedSources[39395] = {{ instance="El Nexo (Heroico)", boss="Ormorok el Talador (7.09%)" }}
ResolvedSources[39396] = {{ instance="El Nexo (Heroico)", boss="Anomalus (7.04%)" }}
ResolvedSources[39534] = {{ instance="Camara de los Relampagos (Normal)", boss="Ionar (6.58%)" }}
ResolvedSources[40266] = { { instance="Naxxramas", boss="Remendejo" }, { instance="Naxxramas", boss="Gluth" } }
ResolvedSources[40286] = { { instance="Naxxramas", boss="Gluth (0.57%)" } }
ResolvedSources[40343] = { { instance="Naxxramas", boss="Gluth (0.40%)" } }
ResolvedSources[40344] = { { instance="Naxxramas", boss="Gluth (0.43%)" } }
ResolvedSources[40345] = { { instance="Naxxramas", boss="Gluth (0.58%)" } }
ResolvedSources[40346] = { { instance="Naxxramas", boss="Gluth (0.44%)" } }
ResolvedSources[40347] = { { instance="Naxxramas", boss="Gluth (0.58%)" } }
ResolvedSources[40348] = { { instance="Naxxramas", boss="Gluth (0.54%)" } }
ResolvedSources[40349] = { { instance="Naxxramas", boss="Gluth (0.69%)" } }
ResolvedSources[40350] = { { instance="Naxxramas", boss="Gluth (0.47%)" } }
ResolvedSources[40352] = { { instance="Naxxramas", boss="Gluth (0.60%)" } }
ResolvedSources[40362] = { { instance="Naxxramas", boss="Safiron (12.84%)" } }
ResolvedSources[40363] = { { instance="Naxxramas", boss="Safiron (10.96%)" } }
ResolvedSources[40365] = { { instance="Naxxramas", boss="Safiron (10.38%)" } }
ResolvedSources[40366] = { { instance="Naxxramas", boss="Safiron (10.55%)" } }
ResolvedSources[40367] = { { instance="Naxxramas", boss="Safiron (10.75%)" } }
ResolvedSources[40368] = { { instance="Naxxramas", boss="Safiron (12.43%)" } }
ResolvedSources[40369] = { { instance="Naxxramas", boss="Safiron (11.94%)" } }
ResolvedSources[40370] = { { instance="Naxxramas", boss="Safiron (10.09%)" } }
ResolvedSources[40371] = { { instance="Naxxramas", boss="Safiron (11.41%)" } }
ResolvedSources[40372] = { { instance="Naxxramas", boss="Safiron (10.22%)" } }
ResolvedSources[40373] = { { instance="Naxxramas", boss="Safiron (10.92%)" } }
ResolvedSources[40374] = { { instance="Naxxramas", boss="Safiron (9.48%)" } }
ResolvedSources[40375] = { { instance="Naxxramas", boss="Safiron (12.06%)" } }
ResolvedSources[40376] = { { instance="Naxxramas", boss="Safiron (11.94%)" } }
ResolvedSources[40377] = { { instance="Naxxramas", boss="Safiron (12.15%)" } }
ResolvedSources[40378] = { { instance="Naxxramas", boss="Safiron (11.41%)" } }
ResolvedSources[40379] = { { instance="Naxxramas", boss="Safiron (10.55%)" } }
ResolvedSources[40380] = { { instance="Naxxramas", boss="Safiron (10.71%)" } }
ResolvedSources[40381] = { { instance="Naxxramas", boss="Safiron (11.69%)" } }
ResolvedSources[40382] = { { instance="Naxxramas", boss="Safiron (13.25%)" } }
ResolvedSources[40383] = { { instance="Naxxramas", boss="Kel'Thuzad (11.49%)" } }
ResolvedSources[40384] = { { instance="Naxxramas", boss="Kel'Thuzad (11.89%)" } }
ResolvedSources[40385] = { { instance="Naxxramas", boss="Kel'Thuzad (11.43%)" } }
ResolvedSources[40386] = { { instance="Naxxramas", boss="Kel'Thuzad (11.64%)" } }
ResolvedSources[40387] = { { instance="Naxxramas", boss="Kel'Thuzad (11.96%)" } }
ResolvedSources[40388] = { { instance="Naxxramas", boss="Kel'Thuzad (11.36%)" } }
ResolvedSources[40395] = { { instance="Naxxramas", boss="Kel'Thuzad (8.42%)" } }
ResolvedSources[40396] = { { instance="Naxxramas", boss="Kel'Thuzad (11.85%)" } }
ResolvedSources[40398] = { { instance="Naxxramas", boss="Kel'Thuzad (12.63%)" } }
ResolvedSources[40399] = { { instance="Naxxramas", boss="Kel'Thuzad (7.93%)" } }
ResolvedSources[40400] = { { instance="Naxxramas", boss="Kel'Thuzad (11.98%)" } }
ResolvedSources[40401] = { { instance="Naxxramas", boss="Kel'Thuzad (11.23%)" } }
ResolvedSources[40402] = { { instance="Naxxramas", boss="Kel'Thuzad (11.89%)" } }
ResolvedSources[40403] = { { instance="Naxxramas", boss="Kel'Thuzad (12.06%)" } }
ResolvedSources[40405] = { { instance="Naxxramas", boss="Kel'Thuzad (8.42%)" } }
ResolvedSources[40431] = { { instance="Sagrario Obsidiana", boss="Sartharion (12.62%)" } }
ResolvedSources[40432] = { { instance="Sagrario Obsidiana", boss="Sartharion (14.17%)" } }
ResolvedSources[40433] = { { instance="Sagrario Obsidiana", boss="Sartharion (13.70%)" } }
ResolvedSources[40437] = { { instance="Sagrario Obsidiana", boss="Sartharion (14.67%)" } }
ResolvedSources[40438] = { { instance="Sagrario Obsidiana", boss="Sartharion (14.25%)" } }
ResolvedSources[40439] = { { instance="Sagrario Obsidiana", boss="Sartharion (13.48%)" } }
ResolvedSources[40446] = { { instance="Sagrario Obsidiana", boss="Sartharion (13.26%)" } }
ResolvedSources[40451] = { { instance="Sagrario Obsidiana", boss="Sartharion (15.28%)" } }
ResolvedSources[40453] = { { instance="Sagrario Obsidiana", boss="Sartharion (14.39%)" } }
ResolvedSources[40455] = { { instance="Sagrario Obsidiana", boss="Sartharion (14.49%)" } }
ResolvedSources[40474] = { { instance="Fortaleza de Utgarde (Heroico)", boss="Ingvar el Desvalijador (10.21%)" } }
ResolvedSources[40486] = { { instance="Ahn'kahet: El Antiguo Reino (Heroico)", boss="Heraldo Volazj (9.78%)" } }
ResolvedSources[40488] = { { instance="Camara de los Relampagos (Heroico)", boss="Loken (10.98%)" } }
ResolvedSources[40489] = { { instance="Camaras de Piedra (Heroico)", boss="Sjonnir el Afilador (14.63%)" } }
ResolvedSources[40490] = { { instance="Fortaleza de Drak'Tharon (Heroico)", boss="Novos el Invocador (14.10%)" } }
ResolvedSources[40491] = { { instance="Gundrak", boss="Gal'darah (12.70%)" } }
ResolvedSources[40519] = { { instance="Fortaleza de Utgarde (Heroico)", boss="Ingvar el Desvalijador (10.92%)" } }
ResolvedSources[40526] = { { instance="Camara de los Relampagos (Heroico)", boss="Loken (11.12%)" } }
ResolvedSources[41660] = { { instance="Guarida de Archavon", boss="Archavon el Vigia de Piedra (0.97%)" } }
ResolvedSources[41665] = { { instance="Guarida de Archavon", boss="Archavon el Vigia de Piedra (0.33%)" } }
ResolvedSources[42001] = { { instance="Guarida de Archavon", boss="Archavon el Vigia de Piedra (1.29%)" } }
ResolvedSources[42003] = { { instance="Guarida de Archavon", boss="Archavon el Vigia de Piedra (1.29%)" } }
ResolvedSources[42028] = { { instance="Guarida de Archavon", boss="Emalon el Vigia de la Tormenta (0.43%)" } }
ResolvedSources[42029] = { { instance="Guarida de Archavon", boss="Emalon el Vigia de la Tormenta (0.20%)" } }
ResolvedSources[42031] = { { instance="Guarida de Archavon", boss="Emalon el Vigia de la Tormenta (0.14%)" } }
ResolvedSources[42033] = { { instance="Guarida de Archavon", boss="Emalon el Vigia de la Tormenta (0.21%)" } }
ResolvedSources[42062] = { { instance="Guarida de Archavon", boss="Emalon el Vigia de la Tormenta (0.18%)" } }
ResolvedSources[42063] = { { instance="Guarida de Archavon", boss="Emalon el Vigia de la Tormenta (0.25%)" } }
ResolvedSources[42064] = { { instance="Guarida de Archavon", boss="Emalon el Vigia de la Tormenta (0.27%)" } }
ResolvedSources[42065] = { { instance="Guarida de Archavon", boss="Emalon el Vigia de la Tormenta (0.15%)" } }
ResolvedSources[42066] = { { instance="Guarida de Archavon", boss="Emalon el Vigia de la Tormenta (0.27%)" } }
ResolvedSources[42068] = { { instance="Guarida de Archavon", boss="Emalon el Vigia de la Tormenta (0.45%)" } }
ResolvedSources[42114] = { { instance="Guarida de Archavon", boss="Emalon el Vigia de la Tormenta (0.57%)" } }
ResolvedSources[42115] = { { instance="Guarida de Archavon", boss="Emalon el Vigia de la Tormenta (0.57%)" } }
ResolvedSources[43281] = { { instance="Ahn'kahet: El Antiguo Reino (Heroico)", boss="Jedoga Buscasombras (10.46%)" } }
ResolvedSources[43282] = { { instance="Ahn'kahet: El Antiguo Reino (Heroico)", boss="Jedoga Buscasombras (9.67%)" } }
ResolvedSources[43283] = { { instance="Ahn'kahet: El Antiguo Reino (Heroico)", boss="Jedoga Buscasombras (10.16%)" } }
ResolvedSources[43284] = { { instance="Ahn'kahet: El Antiguo Reino (Heroico)", boss="Amanitar (18.86%)" } }
ResolvedSources[43285] = { { instance="Ahn'kahet: El Antiguo Reino (Heroico)", boss="Amanitar (18.56%)" } }
ResolvedSources[43286] = { { instance="Ahn'kahet: El Antiguo Reino (Heroico)", boss="Amanitar (18.83%)" } }
ResolvedSources[43287] = { { instance="Ahn'kahet: El Antiguo Reino (Heroico)", boss="Amanitar (19.42%)" } }
ResolvedSources[43309] = { { instance="Gundrak", boss="Gal'darah (8.45%)" } }
ResolvedSources[43310] = { { instance="Gundrak", boss="Eck el Feroz (18.26%)" } }
ResolvedSources[43311] = { { instance="Gundrak", boss="Eck el Feroz (16.96%)" } }
ResolvedSources[43312] = { { instance="Gundrak", boss="Eck el Feroz (17.70%)" } }
ResolvedSources[43313] = { { instance="Gundrak", boss="Eck el Feroz (18.38%)" } }
ResolvedSources[43358] = { { instance="El Bastion Violeta (Normal)", boss="Zuramat el Obliterador (7.36%)" } }
ResolvedSources[43363] = { { instance="El Bastion Violeta (Normal)", boss="Erekem (6.82%)" } }
ResolvedSources[43375] = { { instance="El Bastion Violeta (Normal)", boss="Erekem (6.98%)" } }
ResolvedSources[43387] = { { instance="El Bastion Violeta (Normal)", boss="Moragg (6.17%)" } }
ResolvedSources[43401] = { { instance="El Bastion Violeta (Heroico)", boss="Icoron (20.26%)" } }
ResolvedSources[43402] = { { instance="El Bastion Violeta (Heroico)", boss="Zuramat el Obliterador (20.93%)" } }
ResolvedSources[43403] = { { instance="El Bastion Violeta (Heroico)", boss="Zuramat el Obliterador (22.18%)" } }
ResolvedSources[43405] = { { instance="El Bastion Violeta (Heroico)", boss="Erekem (21.95%)" } }
ResolvedSources[43406] = { { instance="El Bastion Violeta (Heroico)", boss="Erekem (20.29%)" } }
ResolvedSources[43407] = { { instance="El Bastion Violeta (Heroico)", boss="Erekem (21.04%)" } }
ResolvedSources[43408] = { { instance="El Bastion Violeta (Heroico)", boss="Moragg (22.41%)" } }
ResolvedSources[43409] = { { instance="El Bastion Violeta (Heroico)", boss="Moragg (21.42%)" } }
ResolvedSources[43410] = { { instance="El Bastion Violeta (Heroico)", boss="Moragg (23.50%)" } }
ResolvedSources[43500] = { { instance="El Bastion Violeta (Heroico)", boss="Cianigosa (15.55%)" } }
ResolvedSources[43573] = { { instance="Cumbres Tormentosas", boss="Val'kyr naciente (0.02%)" } }
ResolvedSources[44000] = { { instance="Sagrario Obsidiana", boss="Sartharion (15.09%)" } }
ResolvedSources[44002] = { { instance="Sagrario Obsidiana", boss="Sartharion (15.23%)" } }
ResolvedSources[44003] = { { instance="Sagrario Obsidiana", boss="Sartharion (15.33%)" } }
ResolvedSources[44004] = { { instance="Sagrario Obsidiana", boss="Sartharion (16.51%)" } }
ResolvedSources[44005] = { { instance="Sagrario Obsidiana", boss="Sartharion (10.85%)" } }
ResolvedSources[44006] = { { instance="Sagrario Obsidiana", boss="Sartharion (12.03%)" } }
ResolvedSources[44007] = { { instance="Sagrario Obsidiana", boss="Sartharion (12.20%)" } }
ResolvedSources[44008] = { { instance="Sagrario Obsidiana", boss="Sartharion (11.44%)" } }
ResolvedSources[44011] = { { instance="Sagrario Obsidiana", boss="Sartharion (11.36%)" } }
ResolvedSources[44657] = { { instance="El Nexo (Heroico)", boss="Keristrasza (7.45%)" } }
ResolvedSources[44659] = { { instance="Camaras de Piedra (Heroico)", boss="Sjonnir el Afilador (14.80%)" } }
ResolvedSources[44660] = { { instance="Gundrak", boss="Gal'darah (11.43%)" } }
ResolvedSources[45086] = { { instance="Ulduar", boss="Leviatan de llamas (7.32%)" } }
ResolvedSources[45106] = { { instance="Ulduar", boss="Leviatan de llamas (8.61%)" } }
ResolvedSources[45107] = { { instance="Ulduar", boss="Leviatan de llamas (8.01%)" } }
ResolvedSources[45108] = { { instance="Ulduar", boss="Leviatan de llamas (9.04%)" } }
ResolvedSources[45109] = { { instance="Ulduar", boss="Leviatan de llamas (9.30%)" } }
ResolvedSources[45110] = { { instance="Ulduar", boss="Leviatan de llamas (7.92%)" } }
ResolvedSources[45111] = { { instance="Ulduar", boss="Leviatan de llamas (9.39%)" } }
ResolvedSources[45112] = { { instance="Ulduar", boss="Leviatan de llamas (8.79%)" } }
ResolvedSources[45113] = { { instance="Ulduar", boss="Leviatan de llamas (7.15%)" } }
ResolvedSources[45114] = { { instance="Ulduar", boss="Leviatan de llamas (8.87%)" } }
ResolvedSources[45115] = { { instance="Ulduar", boss="Leviatan de llamas (8.35%)" } }
ResolvedSources[45116] = { { instance="Ulduar", boss="Leviatan de llamas (8.79%)" } }
ResolvedSources[45117] = { { instance="Ulduar", boss="Leviatan de llamas (8.35%)" } }
ResolvedSources[45118] = { { instance="Ulduar", boss="Leviatan de llamas (7.06%)" } }
ResolvedSources[45119] = { { instance="Ulduar", boss="Leviatan de llamas (10.16%)" } }
ResolvedSources[45132] = { { instance="Ulduar", boss="Leviatan de llamas (3.62%)" } }
ResolvedSources[45133] = { { instance="Ulduar", boss="Leviatan de llamas (3.70%)" } }
ResolvedSources[45134] = { { instance="Ulduar", boss="Leviatan de llamas (2.93%)" } }
ResolvedSources[45135] = { { instance="Ulduar", boss="Leviatan de llamas (2.15%)" } }
ResolvedSources[45136] = { { instance="Ulduar", boss="Leviatan de llamas (2.07%)" } }
ResolvedSources[45137] = { { instance="Ulduar", boss="Tajoescama (10.57%)" } }
ResolvedSources[45138] = { { instance="Ulduar", boss="Tajoescama (10.71%)" } }
ResolvedSources[45139] = { { instance="Ulduar", boss="Tajoescama (11.67%)" } }
ResolvedSources[45140] = { { instance="Ulduar", boss="Tajoescama (10.22%)" } }
ResolvedSources[45141] = { { instance="Ulduar", boss="Tajoescama (10.65%)" } }
ResolvedSources[45142] = { { instance="Ulduar", boss="Tajoescama (11.89%)" } }
ResolvedSources[45143] = { { instance="Ulduar", boss="Tajoescama (11.01%)" } }
ResolvedSources[45144] = { { instance="Ulduar", boss="Tajoescama (10.32%)" } }
ResolvedSources[45145] = { { instance="Ulduar", boss="General Vezax (11.55%)" } }
ResolvedSources[45146] = { { instance="Ulduar", boss="Tajoescama (10.36%)" } }
ResolvedSources[45147] = { { instance="Ulduar", boss="Tajoescama (11.27%)" } }
ResolvedSources[45148] = { { instance="Ulduar", boss="Tajoescama (10.51%)" } }
ResolvedSources[45149] = { { instance="Ulduar", boss="Tajoescama (11.25%)" } }
ResolvedSources[45150] = { { instance="Ulduar", boss="Tajoescama (11.14%)" } }
ResolvedSources[45151] = { { instance="Ulduar", boss="Tajoescama (10.39%)" } }
ResolvedSources[45157] = { { instance="Ulduar", boss="Ignis el Maestro de la Caldera (11.24%)" } }
ResolvedSources[45158] = { { instance="Ulduar", boss="Ignis el Maestro de la Caldera (10.83%)" } }
ResolvedSources[45161] = { { instance="Ulduar", boss="Ignis el Maestro de la Caldera (11.59%)" } }
ResolvedSources[45162] = { { instance="Ulduar", boss="Ignis el Maestro de la Caldera (10.93%)" } }
ResolvedSources[45164] = { { instance="Ulduar", boss="Ignis el Maestro de la Caldera (11.05%)" } }
ResolvedSources[45165] = { { instance="Ulduar", boss="Ignis el Maestro de la Caldera (11.24%)" } }
ResolvedSources[45166] = { { instance="Ulduar", boss="Ignis el Maestro de la Caldera (11.05%)" } }
ResolvedSources[45168] = { { instance="Ulduar", boss="Ignis el Maestro de la Caldera (10.37%)" } }
ResolvedSources[45169] = { { instance="Ulduar", boss="Ignis el Maestro de la Caldera (11.41%)" } }
ResolvedSources[45170] = { { instance="Ulduar", boss="Ignis el Maestro de la Caldera (10.62%)" } }
ResolvedSources[45171] = { { instance="Ulduar", boss="Ignis el Maestro de la Caldera (11.46%)" } }
ResolvedSources[45186] = { { instance="Ulduar", boss="Ignis el Maestro de la Caldera (11.16%)" } }
ResolvedSources[45187] = { { instance="Ulduar", boss="Ignis el Maestro de la Caldera (11.35%)" } }
ResolvedSources[45241] = { { instance="Ulduar", boss="Rompeacero (5.85%)" } }
ResolvedSources[45242] = { { instance="Ulduar", boss="Rompeacero (5.61%)" } }
ResolvedSources[45243] = { { instance="Ulduar", boss="Rompeacero (5.21%)" } }
ResolvedSources[45244] = { { instance="Ulduar", boss="Rompeacero (4.98%)" } }
ResolvedSources[45245] = { { instance="Ulduar", boss="Rompeacero (4.82%)" } }
ResolvedSources[45246] = { { instance="Ulduar", boss="[XT-002 Deconstructor] (10.00%)" } }
ResolvedSources[45247] = { { instance="Ulduar", boss="[XT-002 Deconstructor] (9.70%)" } }
ResolvedSources[45248] = { { instance="Ulduar", boss="[XT-002 Deconstructor] (10.29%)" } }
ResolvedSources[45249] = { { instance="Ulduar", boss="[XT-002 Deconstructor] (10.34%)" } }
ResolvedSources[45250] = { { instance="Ulduar", boss="[XT-002 Deconstructor] (10.12%)" } }
ResolvedSources[45251] = { { instance="Ulduar", boss="[XT-002 Deconstructor] (9.44%)" } }
ResolvedSources[45253] = { { instance="Ulduar", boss="[XT-002 Deconstructor] (9.78%)" } }
ResolvedSources[45254] = { { instance="Ulduar", boss="[XT-002 Deconstructor] (10.52%)" } }
ResolvedSources[45255] = { { instance="Ulduar", boss="[XT-002 Deconstructor] (9.97%)" } }
ResolvedSources[45256] = { { instance="Ulduar", boss="[XT-002 Deconstructor] (10.34%)" } }
ResolvedSources[45257] = { { instance="Ulduar", boss="[XT-002 Deconstructor] (10.77%)" } }
ResolvedSources[45258] = { { instance="Ulduar", boss="[XT-002 Deconstructor] (9.57%)" } }
ResolvedSources[45259] = { { instance="Ulduar", boss="[XT-002 Deconstructor] (10.12%)" } }
ResolvedSources[45293] = { { instance="Ulduar", boss="Leviatan de llamas (2.67%)" } }
ResolvedSources[45295] = { { instance="Ulduar", boss="Leviatan de llamas (1.81%)" } }
ResolvedSources[45296] = { { instance="Ulduar", boss="Leviatan de llamas (3.27%)" } }
ResolvedSources[45297] = { { instance="Ulduar", boss="Leviatan de llamas (2.33%)" } }
ResolvedSources[45300] = { { instance="Ulduar", boss="Leviatan de llamas (2.24%)" } }
ResolvedSources[45315] = { { instance="Ulduar", boss="Auriaya (10.82%)" } }
ResolvedSources[45319] = { { instance="Ulduar", boss="Auriaya (10.93%)" } }
ResolvedSources[45320] = { { instance="Ulduar", boss="Auriaya (11.28%)" } }
ResolvedSources[45325] = { { instance="Ulduar", boss="Auriaya (10.39%)" } }
ResolvedSources[45326] = { { instance="Ulduar", boss="Auriaya (10.73%)" } }
ResolvedSources[45327] = { { instance="Ulduar", boss="Auriaya (10.12%)" } }
ResolvedSources[45334] = { { instance="Ulduar", boss="Auriaya (10.72%)" } }
ResolvedSources[45337] = { { instance="Guarida de Archavon", boss="Emalon el Vigia de la Tormenta (0.87%)" } }
ResolvedSources[45338] = { { instance="Guarida de Archavon", boss="Emalon el Vigia de la Tormenta (0.80%)" } }
ResolvedSources[45341] = { { instance="Guarida de Archavon", boss="Emalon el Vigia de la Tormenta (0.94%)" } }
ResolvedSources[45343] = { { instance="Guarida de Archavon", boss="Emalon el Vigia de la Tormenta (0.69%)" } }
ResolvedSources[45351] = { { instance="Guarida de Archavon", boss="Emalon el Vigia de la Tormenta (0.66%)" } }
ResolvedSources[45353] = { { instance="Guarida de Archavon", boss="Emalon el Vigia de la Tormenta (0.50%)" } }
ResolvedSources[45355] = { { instance="Guarida de Archavon", boss="Emalon el Vigia de la Tormenta (0.71%)" } }
ResolvedSources[45357] = { { instance="Guarida de Archavon", boss="Emalon el Vigia de la Tormenta (0.63%)" } }
ResolvedSources[45360] = { { instance="Guarida de Archavon", boss="Emalon el Vigia de la Tormenta (1.94%)" } }
ResolvedSources[45367] = { { instance="Guarida de Archavon", boss="Emalon el Vigia de la Tormenta (1.65%)" } }
ResolvedSources[45370] = { { instance="Guarida de Archavon", boss="Emalon el Vigia de la Tormenta (0.73%)" } }
ResolvedSources[45371] = { { instance="Guarida de Archavon", boss="Emalon el Vigia de la Tormenta (0.43%)" } }
ResolvedSources[45376] = { { instance="Guarida de Archavon", boss="Emalon el Vigia de la Tormenta (0.50%)" } }
ResolvedSources[45379] = { { instance="Guarida de Archavon", boss="Emalon el Vigia de la Tormenta (0.60%)" } }
ResolvedSources[45383] = { { instance="Guarida de Archavon", boss="Emalon el Vigia de la Tormenta (0.57%)" } }
ResolvedSources[45384] = { { instance="Guarida de Archavon", boss="Emalon el Vigia de la Tormenta (0.66%)" } }
ResolvedSources[45387] = { { instance="Guarida de Archavon", boss="Emalon el Vigia de la Tormenta (0.95%)" } }
ResolvedSources[45388] = { { instance="Guarida de Archavon", boss="Emalon el Vigia de la Tormenta (0.66%)" } }
ResolvedSources[45392] = { { instance="Guarida de Archavon", boss="Emalon el Vigia de la Tormenta (0.97%)" } }
ResolvedSources[45394] = { { instance="Guarida de Archavon", boss="Emalon el Vigia de la Tormenta (0.92%)" } }
ResolvedSources[45397] = { { instance="Guarida de Archavon", boss="Emalon el Vigia de la Tormenta (1.83%)" } }
ResolvedSources[45399] = { { instance="Guarida de Archavon", boss="Emalon el Vigia de la Tormenta (2.01%)" } }
ResolvedSources[45401] = { { instance="Guarida de Archavon", boss="Emalon el Vigia de la Tormenta (0.48%)" } }
ResolvedSources[45403] = { { instance="Guarida de Archavon", boss="Emalon el Vigia de la Tormenta (0.76%)" } }
ResolvedSources[45406] = { { instance="Guarida de Archavon", boss="Emalon el Vigia de la Tormenta (0.59%)" } }
ResolvedSources[45409] = { { instance="Guarida de Archavon", boss="Emalon el Vigia de la Tormenta (0.57%)" } }
ResolvedSources[45414] = { { instance="Guarida de Archavon", boss="Emalon el Vigia de la Tormenta (0.57%)" } }
ResolvedSources[45416] = { { instance="Guarida de Archavon", boss="Emalon el Vigia de la Tormenta (0.71%)" } }
ResolvedSources[45419] = { { instance="Guarida de Archavon", boss="Emalon el Vigia de la Tormenta (2.13%)" } }
ResolvedSources[45420] = { { instance="Guarida de Archavon", boss="Emalon el Vigia de la Tormenta (1.85%)" } }
ResolvedSources[45426] = { { instance="Guarida de Archavon", boss="Emalon el Vigia de la Tormenta (1.17%)" } }
ResolvedSources[45427] = { { instance="Guarida de Archavon", boss="Emalon el Vigia de la Tormenta (0.92%)" } }
ResolvedSources[45430] = { { instance="Guarida de Archavon", boss="Emalon el Vigia de la Tormenta (0.76%)" } }
ResolvedSources[45432] = { { instance="Guarida de Archavon", boss="Emalon el Vigia de la Tormenta (0.76%)" } }
ResolvedSources[45436] = { { instance="Ulduar", boss="Auriaya (11.06%)" } }
ResolvedSources[45437] = { { instance="Ulduar", boss="Auriaya (11.54%)" } }
ResolvedSources[45439] = { { instance="Ulduar", boss="Auriaya (11.02%)" } }
ResolvedSources[45440] = { { instance="Ulduar", boss="Auriaya (10.64%)" } }
ResolvedSources[45441] = { { instance="Ulduar", boss="Auriaya (11.07%)" } }
ResolvedSources[45442] = { { instance="Ulduar", boss="[XT-002 Deconstructor] (3.11%)" } }
ResolvedSources[45443] = { { instance="Ulduar", boss="[XT-002 Deconstructor] (3.16%)" } }
ResolvedSources[45444] = { { instance="Ulduar", boss="[XT-002 Deconstructor] (3.66%)" } }
ResolvedSources[45445] = { { instance="Ulduar", boss="[XT-002 Deconstructor] (3.18%)" } }
ResolvedSources[45446] = { { instance="Ulduar", boss="[XT-002 Deconstructor] (3.08%)" } }
ResolvedSources[45447] = { { instance="Ulduar", boss="Rompeacero (11.23%)" } }
ResolvedSources[45448] = { { instance="Ulduar", boss="Rompeacero (12.73%)" } }
ResolvedSources[45449] = { { instance="Ulduar", boss="Rompeacero (12.38%)" } }
ResolvedSources[45455] = { { instance="Ulduar", boss="Rompeacero (10.88%)" } }
ResolvedSources[45456] = { { instance="Ulduar", boss="Rompeacero (12.87%)" } }
ResolvedSources[45458] = { { instance="Azjol-Nerub", boss="Hadronox (9.96%)" } }
ResolvedSources[45464] = { { instance="Azjol-Nerub", boss="Krik'thir el Vigia de las puertas (10.52%)" } }
ResolvedSources[45498] = { { instance="Ulduar", boss="General Vezax (11.64%)" } }
ResolvedSources[45501] = { { instance="Ulduar", boss="General Vezax (11.87%)" } }
ResolvedSources[45502] = { { instance="Ulduar", boss="General Vezax (11.10%)" } }
ResolvedSources[45503] = { { instance="Ulduar", boss="General Vezax (11.19%)" } }
ResolvedSources[45504] = { { instance="Ulduar", boss="General Vezax (11.31%)" } }
ResolvedSources[45505] = { { instance="Ulduar", boss="General Vezax (12.32%)" } }
ResolvedSources[45507] = { { instance="Ulduar", boss="General Vezax (11.47%)" } }
ResolvedSources[45508] = { { instance="Ulduar", boss="General Vezax (11.50%)" } }
ResolvedSources[45509] = { { instance="Ulduar", boss="General Vezax (11.34%)" } }
ResolvedSources[45510] = { { instance="Ulduar", boss="Tajoescama (10.92%)" } }
ResolvedSources[45511] = { { instance="Ulduar", boss="General Vezax (12.53%)" } }
ResolvedSources[45512] = { { instance="Ulduar", boss="General Vezax (11.56%)" } }
ResolvedSources[45513] = { { instance="Ulduar", boss="General Vezax (11.25%)" } }
ResolvedSources[45514] = { { instance="Ulduar", boss="General Vezax (11.26%)" } }
ResolvedSources[45515] = { { instance="Ulduar", boss="General Vezax (11.37%)" } }
ResolvedSources[45516] = { { instance="Ulduar", boss="General Vezax (5.53%)" } }
ResolvedSources[45517] = { { instance="Ulduar", boss="General Vezax (5.36%)" } }
ResolvedSources[45518] = { { instance="Ulduar", boss="General Vezax (5.37%)" } }
ResolvedSources[45519] = { { instance="Ulduar", boss="General Vezax (5.48%)" } }
ResolvedSources[45520] = { { instance="Ulduar", boss="General Vezax (5.57%)" } }
ResolvedSources[45521] = { { instance="Ulduar", boss="Yogg-Saron (8.46%)" } }
ResolvedSources[45522] = { { instance="Ulduar", boss="Yogg-Saron (10.00%)" } }
ResolvedSources[45523] = { { instance="Ulduar", boss="Yogg-Saron (11.54%)" } }
ResolvedSources[45524] = { { instance="Ulduar", boss="Yogg-Saron (9.23%)" } }
ResolvedSources[45525] = { { instance="Ulduar", boss="Yogg-Saron (14.62%)" } }
ResolvedSources[45527] = { { instance="Ulduar", boss="Yogg-Saron (13.08%)" } }
ResolvedSources[45529] = { { instance="Ulduar", boss="Yogg-Saron (6.92%)" } }
ResolvedSources[45531] = { { instance="Ulduar", boss="Yogg-Saron (10.00%)" } }
ResolvedSources[45532] = { { instance="Ulduar", boss="Yogg-Saron (14.62%)" } }
ResolvedSources[45533] = { { instance="Ulduar", boss="Yogg-Saron (3.85%)" } }
ResolvedSources[45534] = { { instance="Ulduar", boss="Yogg-Saron (6.15%)" } }
ResolvedSources[45535] = { { instance="Ulduar", boss="Yogg-Saron (11.54%)" } }
ResolvedSources[45536] = { { instance="Ulduar", boss="Yogg-Saron (4.62%)" } }
ResolvedSources[45537] = { { instance="Ulduar", boss="Yogg-Saron (4.62%)" } }
ResolvedSources[45607] = { { instance="Ulduar", boss="Rompeacero (4.93%)" } }
ResolvedSources[45696] = { { instance="Ahn'kahet: El Antiguo Reino (Heroico)", boss="Heraldo Volazj (5.31%)" } }
ResolvedSources[45697] = { { instance="Fortaleza de Drak'Tharon (Heroico)", boss="Cuernotrol (3.98%)" } }
ResolvedSources[45699] = { { instance="Ahn'kahet: El Antiguo Reino (Heroico)", boss="Heraldo Volazj (5.06%)" } }
ResolvedSources[45700] = { { instance="Fortaleza de Drak'Tharon (Heroico)", boss="Rey Dred (3.33%)" } }
ResolvedSources[45702] = { { instance="Ahn'kahet: El Antiguo Reino (Heroico)", boss="Jedoga Buscasombras (4.82%)" } }
ResolvedSources[45703] = { { instance="Fortaleza de Drak'Tharon (Heroico)", boss="Novos el Invocador (4.13%)" } }
ResolvedSources[45704] = { { instance="Ahn'kahet: El Antiguo Reino (Heroico)", boss="Heraldo Volazj (5.08%)" } }
ResolvedSources[45867] = { { instance="Ulduar", boss="[XT-002 Deconstructor] (4.37%)" } }
ResolvedSources[45868] = { { instance="Ulduar", boss="[XT-002 Deconstructor] (4.11%)" } }
ResolvedSources[45869] = { { instance="Ulduar", boss="[XT-002 Deconstructor] (4.19%)" } }
ResolvedSources[45870] = { { instance="Ulduar", boss="[XT-002 Deconstructor] (3.73%)" } }
ResolvedSources[45871] = { { instance="Ulduar", boss="[XT-002 Deconstructor] (4.11%)" } }
ResolvedSources[45874] = { { instance="Azjol-Nerub", boss="Krik'thir el Vigia de las puertas (10.78%)" } }
ResolvedSources[45892] = { { instance="Camaras de Piedra (Heroico)", boss="Krystallus (10.40%)" } }
ResolvedSources[45893] = { { instance="Gundrak", boss="Gal'darah (6.23%)" } }
ResolvedSources[45895] = { { instance="Camaras de Piedra (Heroico)", boss="Doncella del Dolor (9.69%)" } }
ResolvedSources[45927] = { { instance="Camaras de Piedra (Heroico)", boss="Krystallus (10.75%)" } }
ResolvedSources[45973] = { { instance="Gundrak", boss="Slad'ran (8.12%)" } }
ResolvedSources[45974] = { { instance="Fortaleza de Drak'Tharon (Heroico)", boss="El profeta Tharon'ja (4.62%)" } }
ResolvedSources[45976] = { { instance="Gundrak", boss="Slad'ran (9.61%)" } }
ResolvedSources[46012] = { { instance="Ulduar", boss="General Vezax (8.26%)" } }
ResolvedSources[46018] = { { instance="Ulduar", boss="Yogg-Saron (3.85%)" } }
ResolvedSources[46022] = { { instance="Ulduar", boss="Yogg-Saron (4.62%)" } }
ResolvedSources[46024] = { { instance="Ulduar", boss="Yogg-Saron (6.92%)" } }
ResolvedSources[46025] = { { instance="Ulduar", boss="Yogg-Saron (6.92%)" } }
ResolvedSources[46032] = { { instance="Ulduar", boss="General Vezax (5.34%)" } }
ResolvedSources[46033] = { { instance="Ulduar", boss="General Vezax (5.04%)" } }
ResolvedSources[46034] = { { instance="Ulduar", boss="General Vezax (4.63%)" } }
ResolvedSources[46035] = { { instance="Ulduar", boss="General Vezax (5.00%)" } }
ResolvedSources[46036] = { { instance="Ulduar", boss="General Vezax (4.82%)" } }
ResolvedSources[46067] = { { instance="Ulduar", boss="Yogg-Saron (2.31%)" } }
ResolvedSources[46068] = { { instance="Ulduar", boss="Yogg-Saron (6.15%)" } }
ResolvedSources[46095] = { { instance="Ulduar", boss="Yogg-Saron (5.38%)" } }
ResolvedSources[46096] = { { instance="Ulduar", boss="Yogg-Saron (3.85%)" } }
ResolvedSources[46097] = { { instance="Ulduar", boss="Yogg-Saron (2.31%)" } }
ResolvedSources[46113] = { { instance="Guarida de Archavon", boss="Emalon el Vigia de la Tormenta (2.87%)" } }
ResolvedSources[46116] = { { instance="Guarida de Archavon", boss="Emalon el Vigia de la Tormenta (2.70%)" } }
ResolvedSources[46119] = { { instance="Guarida de Archavon", boss="Emalon el Vigia de la Tormenta (3.38%)" } }
ResolvedSources[46121] = { { instance="Guarida de Archavon", boss="Emalon el Vigia de la Tormenta (2.71%)" } }
ResolvedSources[46124] = { { instance="Guarida de Archavon", boss="Emalon el Vigia de la Tormenta (6.10%)" } }
ResolvedSources[46126] = { { instance="Guarida de Archavon", boss="Emalon el Vigia de la Tormenta (5.50%)" } }
ResolvedSources[46131] = { { instance="Guarida de Archavon", boss="Emalon el Vigia de la Tormenta (1.75%)" } }
ResolvedSources[46132] = { { instance="Guarida de Archavon", boss="Emalon el Vigia de la Tormenta (5.34%)" } }
ResolvedSources[46133] = { { instance="Guarida de Archavon", boss="Emalon el Vigia de la Tormenta (5.75%)" } }
ResolvedSources[46135] = { { instance="Guarida de Archavon", boss="Emalon el Vigia de la Tormenta (5.36%)" } }
ResolvedSources[46139] = { { instance="Guarida de Archavon", boss="Emalon el Vigia de la Tormenta (5.03%)" } }
ResolvedSources[46142] = { { instance="Guarida de Archavon", boss="Emalon el Vigia de la Tormenta (5.90%)" } }
ResolvedSources[46144] = { { instance="Guarida de Archavon", boss="Emalon el Vigia de la Tormenta (5.26%)" } }
ResolvedSources[46148] = { { instance="Guarida de Archavon", boss="Emalon el Vigia de la Tormenta (2.73%)" } }
ResolvedSources[46150] = { { instance="Guarida de Archavon", boss="Emalon el Vigia de la Tormenta (2.95%)" } }
ResolvedSources[46153] = { { instance="Guarida de Archavon", boss="Emalon el Vigia de la Tormenta (2.14%)" } }
ResolvedSources[46155] = { { instance="Guarida de Archavon", boss="Emalon el Vigia de la Tormenta (1.83%)" } }
ResolvedSources[46158] = { { instance="Guarida de Archavon", boss="Emalon el Vigia de la Tormenta (1.93%)" } }
ResolvedSources[46160] = { { instance="Guarida de Archavon", boss="Emalon el Vigia de la Tormenta (2.00%)" } }
ResolvedSources[46163] = { { instance="Guarida de Archavon", boss="Emalon el Vigia de la Tormenta (2.66%)" } }
ResolvedSources[46164] = { { instance="Guarida de Archavon", boss="Emalon el Vigia de la Tormenta (3.08%)" } }
ResolvedSources[46169] = { { instance="Guarida de Archavon", boss="Emalon el Vigia de la Tormenta (2.60%)" } }
ResolvedSources[46170] = { { instance="Guarida de Archavon", boss="Emalon el Vigia de la Tormenta (2.69%)" } }
ResolvedSources[46174] = { { instance="Guarida de Archavon", boss="Emalon el Vigia de la Tormenta (1.96%)" } }
ResolvedSources[46176] = { { instance="Guarida de Archavon", boss="Emalon el Vigia de la Tormenta (1.96%)" } }
ResolvedSources[46179] = { { instance="Guarida de Archavon", boss="Emalon el Vigia de la Tormenta (1.78%)" } }
ResolvedSources[46181] = { { instance="Guarida de Archavon", boss="Emalon el Vigia de la Tormenta (2.24%)" } }
ResolvedSources[46183] = { { instance="Guarida de Archavon", boss="Emalon el Vigia de la Tormenta (2.00%)" } }
ResolvedSources[46185] = { { instance="Guarida de Archavon", boss="Emalon el Vigia de la Tormenta (1.85%)" } }
ResolvedSources[46188] = { { instance="Guarida de Archavon", boss="Emalon el Vigia de la Tormenta (2.74%)" } }
ResolvedSources[46189] = { { instance="Guarida de Archavon", boss="Emalon el Vigia de la Tormenta (1.96%)" } }
ResolvedSources[46192] = { { instance="Guarida de Archavon", boss="Emalon el Vigia de la Tormenta (2.06%)" } }
ResolvedSources[46195] = { { instance="Guarida de Archavon", boss="Emalon el Vigia de la Tormenta (2.85%)" } }
ResolvedSources[46199] = { { instance="Guarida de Archavon", boss="Emalon el Vigia de la Tormenta (1.89%)" } }
ResolvedSources[46200] = { { instance="Guarida de Archavon", boss="Emalon el Vigia de la Tormenta (2.04%)" } }
ResolvedSources[46202] = { { instance="Guarida de Archavon", boss="Emalon el Vigia de la Tormenta (1.94%)" } }
ResolvedSources[46207] = { { instance="Guarida de Archavon", boss="Emalon el Vigia de la Tormenta (1.96%)" } }
ResolvedSources[46208] = { { instance="Guarida de Archavon", boss="Emalon el Vigia de la Tormenta (1.94%)" } }
ResolvedSources[46210] = { { instance="Guarida de Archavon", boss="Emalon el Vigia de la Tormenta (2.17%)" } }
ResolvedSources[46312] = { { instance="Ulduar", boss="Yogg-Saron (1.54%)" } }
ResolvedSources[47750] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (0.90%)" } }
ResolvedSources[47752] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (0.58%)" } }
ResolvedSources[47753] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (2.63%)" } }
ResolvedSources[47755] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (2.80%)" } }
ResolvedSources[47770] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (2.47%)" } }
ResolvedSources[47772] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (3.29%)" } }
ResolvedSources[47773] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (0.66%)" } }
ResolvedSources[47775] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (0.66%)" } }
ResolvedSources[47780] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (2.55%)" } }
ResolvedSources[47782] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (2.47%)" } }
ResolvedSources[47783] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (1.32%)" } }
ResolvedSources[47785] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (1.15%)" } }
ResolvedSources[47800] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (0.82%)" } }
ResolvedSources[47802] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (0.25%)" } }
ResolvedSources[47803] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (2.71%)" } }
ResolvedSources[47805] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (3.70%)" } }
ResolvedSources[47980] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (0.33%)" } }
ResolvedSources[47982] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (0.49%)" } }
ResolvedSources[47983] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (1.97%)" } }
ResolvedSources[47985] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (1.23%)" } }
ResolvedSources[48064] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (1.56%)" } }
ResolvedSources[48066] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (1.56%)" } }
ResolvedSources[48067] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (0.25%)" } }
ResolvedSources[48069] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (0.25%)" } }
ResolvedSources[48072] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (0.58%)" } }
ResolvedSources[48077] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (1.32%)" } }
ResolvedSources[48079] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (1.15%)" } }
ResolvedSources[48094] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (1.81%)" } }
ResolvedSources[48096] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (1.48%)" } }
ResolvedSources[48097] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (0.74%)" } }
ResolvedSources[48099] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (0.41%)" } }
ResolvedSources[48130] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (0.58%)" } }
ResolvedSources[48132] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (0.25%)" } }
ResolvedSources[48133] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (0.49%)" } }
ResolvedSources[48135] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (1.23%)" } }
ResolvedSources[48150] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (0.74%)" } }
ResolvedSources[48152] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (1.07%)" } }
ResolvedSources[48153] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (0.49%)" } }
ResolvedSources[48155] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (0.49%)" } }
ResolvedSources[48160] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (0.16%)" } }
ResolvedSources[48162] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (0.25%)" } }
ResolvedSources[48163] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (1.07%)" } }
ResolvedSources[48165] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (1.23%)" } }
ResolvedSources[48180] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (1.56%)" } }
ResolvedSources[48182] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (1.07%)" } }
ResolvedSources[48183] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (0.33%)" } }
ResolvedSources[48185] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (0.41%)" } }
ResolvedSources[48190] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (0.16%)" } }
ResolvedSources[48192] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (0.25%)" } }
ResolvedSources[48193] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (1.07%)" } }
ResolvedSources[48195] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (1.56%)" } }
ResolvedSources[48210] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (1.23%)" } }
ResolvedSources[48212] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (0.82%)" } }
ResolvedSources[48215] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (0.16%)" } }
ResolvedSources[48220] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (0.82%)" } }
ResolvedSources[48222] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (0.58%)" } }
ResolvedSources[48224] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (2.38%)" } }
ResolvedSources[48226] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (2.63%)" } }
ResolvedSources[48239] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (3.21%)" } }
ResolvedSources[48241] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (2.80%)" } }
ResolvedSources[48244] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (0.82%)" } }
ResolvedSources[48246] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (0.49%)" } }
ResolvedSources[48252] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (0.90%)" } }
ResolvedSources[48254] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (0.66%)" } }
ResolvedSources[48256] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (2.80%)" } }
ResolvedSources[48258] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (2.63%)" } }
ResolvedSources[48271] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (3.87%)" } }
ResolvedSources[48273] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (3.04%)" } }
ResolvedSources[48276] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (1.40%)" } }
ResolvedSources[48278] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (0.74%)" } }
ResolvedSources[48282] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (0.33%)" } }
ResolvedSources[48284] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (0.16%)" } }
ResolvedSources[48286] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (0.99%)" } }
ResolvedSources[48288] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (0.74%)" } }
ResolvedSources[48296] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (0.33%)" } }
ResolvedSources[48298] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (0.66%)" } }
ResolvedSources[48301] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (1.07%)" } }
ResolvedSources[48303] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (0.74%)" } }
ResolvedSources[48312] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (0.41%)" } }
ResolvedSources[48314] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (0.49%)" } }
ResolvedSources[48317] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (0.66%)" } }
ResolvedSources[48319] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (0.49%)" } }
ResolvedSources[48332] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (0.58%)" } }
ResolvedSources[48334] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (0.82%)" } }
ResolvedSources[48337] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (0.16%)" } }
ResolvedSources[48339] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (0.33%)" } }
ResolvedSources[48342] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (0.16%)" } }
ResolvedSources[48347] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (0.99%)" } }
ResolvedSources[48349] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (0.66%)" } }
ResolvedSources[48362] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (0.99%)" } }
ResolvedSources[48364] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (0.99%)" } }
ResolvedSources[48367] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (0.25%)" } }
ResolvedSources[48369] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (0.58%)" } }
ResolvedSources[48373] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (0.16%)" } }
ResolvedSources[48375] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (0.33%)" } }
ResolvedSources[48377] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (1.07%)" } }
ResolvedSources[48379] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (1.64%)" } }
ResolvedSources[48387] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (0.90%)" } }
ResolvedSources[48389] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (0.49%)" } }
ResolvedSources[48392] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (1.15%)" } }
ResolvedSources[48394] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (2.06%)" } }
ResolvedSources[48445] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (0.41%)" } }
ResolvedSources[48446] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (1.97%)" } }
ResolvedSources[48449] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (0.41%)" } }
ResolvedSources[48452] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (1.23%)" } }
ResolvedSources[48457] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (0.58%)" } }
ResolvedSources[48459] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (0.33%)" } }
ResolvedSources[48462] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (1.48%)" } }
ResolvedSources[48464] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (1.73%)" } }
ResolvedSources[48476] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (0.49%)" } }
ResolvedSources[48480] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (0.33%)" } }
ResolvedSources[48482] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (1.73%)" } }
ResolvedSources[48484] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (1.64%)" } }
ResolvedSources[48497] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (1.23%)" } }
ResolvedSources[48499] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (0.99%)" } }
ResolvedSources[48502] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (0.66%)" } }
ResolvedSources[48504] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (0.49%)" } }
ResolvedSources[48533] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (0.25%)" } }
ResolvedSources[48537] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (0.58%)" } }
ResolvedSources[48539] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (1.07%)" } }
ResolvedSources[48541] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (0.49%)" } }
ResolvedSources[48554] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (1.64%)" } }
ResolvedSources[48556] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (1.15%)" } }
ResolvedSources[48561] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (0.25%)" } }
ResolvedSources[48568] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (0.16%)" } }
ResolvedSources[48574] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (0.25%)" } }
ResolvedSources[48576] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (0.58%)" } }
ResolvedSources[48578] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (0.66%)" } }
ResolvedSources[48591] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (1.73%)" } }
ResolvedSources[48593] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (0.82%)" } }
ResolvedSources[48598] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (0.58%)" } }
ResolvedSources[48603] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (0.16%)" } }
ResolvedSources[48605] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (0.41%)" } }
ResolvedSources[48608] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (1.23%)" } }
ResolvedSources[48610] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (1.07%)" } }
ResolvedSources[48623] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (1.32%)" } }
ResolvedSources[48625] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (0.74%)" } }
ResolvedSources[48628] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (0.25%)" } }
ResolvedSources[48633] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (0.16%)" } }
ResolvedSources[48635] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (0.49%)" } }
ResolvedSources[48638] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (0.99%)" } }
ResolvedSources[48640] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (0.90%)" } }
ResolvedSources[48655] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (0.25%)" } }
ResolvedSources[48658] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (1.07%)" } }
ResolvedSources[48660] = { { instance="Guarida de Archavon", boss="[Koralon the Flame Watcher] (0.99%)" } }
ResolvedSources[49076] = { { instance="Profundidades de Roca Negra", boss="Coren Cerveza Temible (1.10%)" } }
ResolvedSources[49078] = { { instance="Profundidades de Roca Negra", boss="Coren Cerveza Temible (1.06%)" } }
ResolvedSources[49118] = { { instance="Profundidades de Roca Negra", boss="Coren Cerveza Temible (0.98%)" } }
ResolvedSources[49123] = { { instance="Monasterio Escarlata", boss="El Jinete decapitado (1.29%)" } }
ResolvedSources[49126] = { { instance="Monasterio Escarlata", boss="El Jinete decapitado (0.11%)" } }
ResolvedSources[49227] = { { instance="Cumbres Tormentosas", boss="Skoll (73.91%)" } }
ResolvedSources[49981] = { { instance="Ciudadela de la Corona de Hielo", boss="El Rey Exanime (11.55%)" } }
ResolvedSources[49997] = { { instance="Ciudadela de la Corona de Hielo", boss="El Rey Exanime (7.83%)" } }
ResolvedSources[50012] = { { instance="Ciudadela de la Corona de Hielo", boss="El Rey Exanime (11.15%)" } }
ResolvedSources[50070] = { { instance="Ciudadela de la Corona de Hielo", boss="El Rey Exanime (14.87%)" } }
ResolvedSources[50079] = { { instance="Guarida de Archavon", boss="Toravon el Vigia de Hielo (1.16%)" } }
ResolvedSources[50081] = { { instance="Guarida de Archavon", boss="Toravon el Vigia de Hielo (1.11%)" } }
ResolvedSources[50088] = { { instance="Guarida de Archavon", boss="Toravon el Vigia de Hielo (2.54%)" } }
ResolvedSources[50090] = { { instance="Guarida de Archavon", boss="Toravon el Vigia de Hielo (2.41%)" } }
ResolvedSources[50097] = { { instance="Guarida de Archavon", boss="Toravon el Vigia de Hielo (1.25%)" } }
ResolvedSources[50109] = { { instance="Guarida de Archavon", boss="Toravon el Vigia de Hielo (0.80%)" } }
ResolvedSources[50240] = { { instance="Guarida de Archavon", boss="Toravon el Vigia de Hielo (1.87%)" } }
ResolvedSources[50242] = { { instance="Guarida de Archavon", boss="Toravon el Vigia de Hielo (2.36%)" } }
ResolvedSources[50275] = { { instance="Guarida de Archavon", boss="Toravon el Vigia de Hielo (1.74%)" } }
ResolvedSources[50325] = { { instance="Guarida de Archavon", boss="Toravon el Vigia de Hielo (0.76%)" } }
ResolvedSources[50327] = { { instance="Guarida de Archavon", boss="Toravon el Vigia de Hielo (0.58%)" } }
ResolvedSources[50343] = { { instance="Ciudadela de la Corona de Hielo", boss="Lady Susurramuerte (5.53%)" } }
ResolvedSources[50344] = { { instance="Ciudadela de la Corona de Hielo", boss="Profesor Putricidio (0.95%)" } }
ResolvedSources[50346] = { { instance="Ciudadela de la Corona de Hielo", boss="Lord Tuetano (3.77%)" } }
ResolvedSources[50348] = { { instance="Ciudadela de la Corona de Hielo", boss="Caraputrea (5.74%)" } }
ResolvedSources[50364] = { { instance="Ciudadela de la Corona de Hielo", boss="Sindragosa (2.87%)" } }
ResolvedSources[50365] = { { instance="Ciudadela de la Corona de Hielo", boss="Sindragosa (2.30%)" } }
ResolvedSources[50425] = { { instance="Ciudadela de la Corona de Hielo", boss="El Rey Exanime (13.31%)" } }
ResolvedSources[50426] = { { instance="Ciudadela de la Corona de Hielo", boss="El Rey Exanime (7.24%)" } }
ResolvedSources[50427] = { { instance="Ciudadela de la Corona de Hielo", boss="El Rey Exanime (7.83%)" } }
ResolvedSources[50428] = { { instance="Ciudadela de la Corona de Hielo", boss="El Rey Exanime (11.15%)" } }
ResolvedSources[50429] = { { instance="Ciudadela de la Corona de Hielo", boss="El Rey Exanime (14.29%)" } }
ResolvedSources[50603] = { { instance="Ciudadela de la Corona de Hielo", boss="Principe Valanar (2.47%)" } }
ResolvedSources[50604] = { { instance="Ciudadela de la Corona de Hielo", boss="Lord Tuetano (5.66%)" } }
ResolvedSources[50605] = { { instance="Ciudadela de la Corona de Hielo", boss="Lord Tuetano (5.47%)" } }
ResolvedSources[50606] = { { instance="Ciudadela de la Corona de Hielo", boss="Lord Tuetano (4.53%)" } }
ResolvedSources[50607] = { { instance="Ciudadela de la Corona de Hielo", boss="Lord Tuetano (4.25%)" } }
ResolvedSources[50608] = { { instance="Ciudadela de la Corona de Hielo", boss="Lord Tuetano (8.58%)" } }
ResolvedSources[50609] = { { instance="Ciudadela de la Corona de Hielo", boss="Lord Tuetano (5.94%)" } }
ResolvedSources[50610] = { { instance="Ciudadela de la Corona de Hielo", boss="Lord Tuetano (4.72%)" } }
ResolvedSources[50611] = { { instance="Ciudadela de la Corona de Hielo", boss="Lord Tuetano (4.43%)" } }
ResolvedSources[50612] = { { instance="Ciudadela de la Corona de Hielo", boss="Lord Tuetano (3.58%)" } }
ResolvedSources[50613] = { { instance="Ciudadela de la Corona de Hielo", boss="Lord Tuetano (6.42%)" } }
ResolvedSources[50614] = { { instance="Ciudadela de la Corona de Hielo", boss="Lord Tuetano (7.74%)" } }
ResolvedSources[50615] = { { instance="Ciudadela de la Corona de Hielo", boss="Lord Tuetano (3.68%)" } }
ResolvedSources[50616] = { { instance="Ciudadela de la Corona de Hielo", boss="Lord Tuetano (5.75%)" } }
ResolvedSources[50617] = { { instance="Ciudadela de la Corona de Hielo", boss="Lord Tuetano (3.40%)" } }
ResolvedSources[50633] = { { instance="Ciudadela de la Corona de Hielo", boss="Sindragosa (0.57%)" } }
ResolvedSources[50635] = { { instance="Ciudadela de la Corona de Hielo", boss="Sindragosa (1.15%)" } }
ResolvedSources[50636] = { { instance="Ciudadela de la Corona de Hielo", boss="Sindragosa (1.15%)" } }
ResolvedSources[50638] = { { instance="Ciudadela de la Corona de Hielo", boss="Lady Susurramuerte (3.06%)" } }
ResolvedSources[50639] = { { instance="Ciudadela de la Corona de Hielo", boss="Lady Susurramuerte (1.35%)" } }
ResolvedSources[50640] = { { instance="Ciudadela de la Corona de Hielo", boss="Lady Susurramuerte (1.20%)" } }
ResolvedSources[50641] = { { instance="Ciudadela de la Corona de Hielo", boss="Lady Susurramuerte (2.02%)" } }
ResolvedSources[50642] = { { instance="Ciudadela de la Corona de Hielo", boss="Lady Susurramuerte (0.67%)" } }
ResolvedSources[50643] = { { instance="Ciudadela de la Corona de Hielo", boss="Lady Susurramuerte (1.79%)" } }
ResolvedSources[50644] = { { instance="Ciudadela de la Corona de Hielo", boss="Lady Susurramuerte (1.94%)" } }
ResolvedSources[50645] = { { instance="Ciudadela de la Corona de Hielo", boss="Lady Susurramuerte (1.12%)" } }
ResolvedSources[50646] = { { instance="Ciudadela de la Corona de Hielo", boss="Lady Susurramuerte (1.49%)" } }
ResolvedSources[50647] = { { instance="Ciudadela de la Corona de Hielo", boss="Lady Susurramuerte (1.79%)" } }
ResolvedSources[50648] = { { instance="Ciudadela de la Corona de Hielo", boss="Lady Susurramuerte (1.87%)" } }
ResolvedSources[50649] = { { instance="Ciudadela de la Corona de Hielo", boss="Lady Susurramuerte (1.27%)" } }
ResolvedSources[50650] = { { instance="Ciudadela de la Corona de Hielo", boss="Lady Susurramuerte (1.20%)" } }
ResolvedSources[50651] = { { instance="Ciudadela de la Corona de Hielo", boss="Lady Susurramuerte (2.47%)" } }
ResolvedSources[50652] = { { instance="Ciudadela de la Corona de Hielo", boss="Lady Susurramuerte (1.35%)" } }
ResolvedSources[50673] = { { instance="Ciudadela de la Corona de Hielo", boss="Caraputrea (5.08%)" } }
ResolvedSources[50674] = { { instance="Ciudadela de la Corona de Hielo", boss="Caraputrea (5.52%)" } }
ResolvedSources[50675] = { { instance="Ciudadela de la Corona de Hielo", boss="Caraputrea (4.86%)" } }
ResolvedSources[50676] = { { instance="Ciudadela de la Corona de Hielo", boss="Caraputrea (5.67%)" } }
ResolvedSources[50677] = { { instance="Ciudadela de la Corona de Hielo", boss="Caraputrea (4.49%)" } }
ResolvedSources[50678] = { { instance="Ciudadela de la Corona de Hielo", boss="Caraputrea (8.54%)" } }
ResolvedSources[50679] = { { instance="Ciudadela de la Corona de Hielo", boss="Caraputrea (4.20%)" } }
ResolvedSources[50680] = { { instance="Ciudadela de la Corona de Hielo", boss="Caraputrea (2.95%)" } }
ResolvedSources[50681] = { { instance="Ciudadela de la Corona de Hielo", boss="Caraputrea (3.02%)" } }
ResolvedSources[50682] = { { instance="Ciudadela de la Corona de Hielo", boss="Caraputrea (6.55%)" } }
ResolvedSources[50684] = { { instance="Ciudadela de la Corona de Hielo", boss="Caraputrea (4.49%)" } }
ResolvedSources[50685] = { { instance="Ciudadela de la Corona de Hielo", boss="Caraputrea (8.17%)" } }
ResolvedSources[50686] = { { instance="Ciudadela de la Corona de Hielo", boss="Caraputrea (3.31%)" } }
ResolvedSources[50687] = { { instance="Ciudadela de la Corona de Hielo", boss="Caraputrea (3.53%)" } }
ResolvedSources[50688] = { { instance="Ciudadela de la Corona de Hielo", boss="Panzachancro (2.12%)" } }
ResolvedSources[50689] = { { instance="Ciudadela de la Corona de Hielo", boss="Panzachancro (3.49%)" } }
ResolvedSources[50690] = { { instance="Ciudadela de la Corona de Hielo", boss="Panzachancro (2.05%)" } }
ResolvedSources[50691] = { { instance="Ciudadela de la Corona de Hielo", boss="Panzachancro (1.37%)" } }
ResolvedSources[50692] = { { instance="Ciudadela de la Corona de Hielo", boss="Panzachancro (1.85%)" } }
ResolvedSources[50693] = { { instance="Ciudadela de la Corona de Hielo", boss="Panzachancro (2.26%)" } }
ResolvedSources[50694] = { { instance="Ciudadela de la Corona de Hielo", boss="Panzachancro (2.80%)" } }
ResolvedSources[50695] = { { instance="Ciudadela de la Corona de Hielo", boss="Panzachancro (4.72%)" } }
ResolvedSources[50696] = { { instance="Ciudadela de la Corona de Hielo", boss="Panzachancro (1.85%)" } }
ResolvedSources[50697] = { { instance="Ciudadela de la Corona de Hielo", boss="Panzachancro (2.12%)" } }
ResolvedSources[50698] = { { instance="Ciudadela de la Corona de Hielo", boss="Panzachancro (1.64%)" } }
ResolvedSources[50699] = { { instance="Ciudadela de la Corona de Hielo", boss="Panzachancro (4.58%)" } }
ResolvedSources[50700] = { { instance="Ciudadela de la Corona de Hielo", boss="Panzachancro (2.12%)" } }
ResolvedSources[50701] = { { instance="Ciudadela de la Corona de Hielo", boss="Panzachancro (2.26%)" } }
ResolvedSources[50702] = { { instance="Ciudadela de la Corona de Hielo", boss="Panzachancro (1.44%)" } }
ResolvedSources[50703] = { { instance="Ciudadela de la Corona de Hielo", boss="Panzachancro (3.01%)" } }
ResolvedSources[50704] = { { instance="Ciudadela de la Corona de Hielo", boss="Profesor Putricidio (1.02%)" } }
ResolvedSources[50705] = { { instance="Ciudadela de la Corona de Hielo", boss="Profesor Putricidio (0.32%)" } }
ResolvedSources[50706] = { { instance="Ciudadela de la Corona de Hielo", boss="Profesor Putricidio (0.95%)" } }
ResolvedSources[50707] = { { instance="Ciudadela de la Corona de Hielo", boss="Profesor Putricidio (0.95%)" } }
ResolvedSources[50708] = { { instance="Ciudadela de la Corona de Hielo", boss="Profesor Putricidio (0.47%)" } }
ResolvedSources[50709] = { { instance="Ciudadela de la Corona de Hielo", boss="Lord Tuetano (7.17%)" } }
ResolvedSources[50710] = { { instance="Ciudadela de la Corona de Hielo", boss="Principe Valanar (1.56%)" } }
ResolvedSources[50711] = { { instance="Ciudadela de la Corona de Hielo", boss="Principe Valanar (1.69%)" } }
ResolvedSources[50712] = { { instance="Ciudadela de la Corona de Hielo", boss="Principe Valanar (1.69%)" } }
ResolvedSources[50713] = { { instance="Ciudadela de la Corona de Hielo", boss="Principe Valanar (1.30%)" } }
ResolvedSources[50714] = { { instance="Ciudadela de la Corona de Hielo", boss="Principe Valanar (2.34%)" } }
ResolvedSources[50715] = { { instance="Ciudadela de la Corona de Hielo", boss="Principe Valanar (2.21%)" } }
ResolvedSources[50716] = { { instance="Ciudadela de la Corona de Hielo", boss="Principe Valanar (1.30%)" } }
ResolvedSources[50717] = { { instance="Ciudadela de la Corona de Hielo", boss="Principe Valanar (1.17%)" } }
ResolvedSources[50718] = { { instance="Ciudadela de la Corona de Hielo", boss="Principe Valanar (1.95%)" } }
ResolvedSources[50719] = { { instance="Ciudadela de la Corona de Hielo", boss="Principe Valanar (3.12%)" } }
ResolvedSources[50720] = { { instance="Ciudadela de la Corona de Hielo", boss="Principe Valanar (1.82%)" } }
ResolvedSources[50721] = { { instance="Ciudadela de la Corona de Hielo", boss="Principe Valanar (1.43%)" } }
ResolvedSources[50722] = { { instance="Ciudadela de la Corona de Hielo", boss="Principe Valanar (1.43%)" } }
ResolvedSources[50723] = { { instance="Ciudadela de la Corona de Hielo", boss="Principe Valanar (0.91%)" } }
ResolvedSources[50724] = { { instance="Ciudadela de la Corona de Hielo", boss="Reina de Sangre Lana'thel (2.67%)" } }
ResolvedSources[50725] = { { instance="Ciudadela de la Corona de Hielo", boss="Reina de Sangre Lana'thel (3.08%)" } }
ResolvedSources[50727] = { { instance="Ciudadela de la Corona de Hielo", boss="Reina de Sangre Lana'thel (3.29%)" } }
ResolvedSources[50728] = { { instance="Ciudadela de la Corona de Hielo", boss="Reina de Sangre Lana'thel (1.95%)" } }
ResolvedSources[50729] = { { instance="Ciudadela de la Corona de Hielo", boss="Reina de Sangre Lana'thel (1.34%)" } }
ResolvedSources[50730] = { { instance="Ciudadela de la Corona de Hielo", boss="El Rey Exanime (0.20%)" } }
ResolvedSources[50733] = { { instance="Ciudadela de la Corona de Hielo", boss="El Rey Exanime (0.20%)" } }
ResolvedSources[50734] = { { instance="Ciudadela de la Corona de Hielo", boss="El Rey Exanime (0.39%)" } }
ResolvedSources[50735] = { { instance="Ciudadela de la Corona de Hielo", boss="El Rey Exanime (0.59%)" } }
ResolvedSources[50737] = { { instance="Ciudadela de la Corona de Hielo", boss="El Rey Exanime (0.20%)" } }
ResolvedSources[50766] = { { instance="Guarida de Archavon", boss="Toravon el Vigia de Hielo (1.38%)" } }
ResolvedSources[50769] = { { instance="Guarida de Archavon", boss="Toravon el Vigia de Hielo (1.20%)" } }
ResolvedSources[50820] = { { instance="Guarida de Archavon", boss="Toravon el Vigia de Hielo (0.80%)" } }
ResolvedSources[50822] = { { instance="Guarida de Archavon", boss="Toravon el Vigia de Hielo (0.67%)" } }
ResolvedSources[50825] = { { instance="Guarida de Archavon", boss="Toravon el Vigia de Hielo (0.62%)" } }
ResolvedSources[50827] = { { instance="Guarida de Archavon", boss="Toravon el Vigia de Hielo (0.58%)" } }
ResolvedSources[50831] = { { instance="Guarida de Archavon", boss="Toravon el Vigia de Hielo (0.85%)" } }
ResolvedSources[50833] = { { instance="Guarida de Archavon", boss="Toravon el Vigia de Hielo (0.53%)" } }
ResolvedSources[50836] = { { instance="Guarida de Archavon", boss="Toravon el Vigia de Hielo (0.94%)" } }
ResolvedSources[50838] = { { instance="Guarida de Archavon", boss="Toravon el Vigia de Hielo (0.89%)" } }
ResolvedSources[50842] = { { instance="Guarida de Archavon", boss="Toravon el Vigia de Hielo (0.67%)" } }
ResolvedSources[50844] = { { instance="Guarida de Archavon", boss="Toravon el Vigia de Hielo (1.02%)" } }
ResolvedSources[50847] = { { instance="Guarida de Archavon", boss="Toravon el Vigia de Hielo (0.76%)" } }
ResolvedSources[50849] = { { instance="Guarida de Archavon", boss="Toravon el Vigia de Hielo (0.76%)" } }
ResolvedSources[50854] = { { instance="Guarida de Archavon", boss="Toravon el Vigia de Hielo (1.02%)" } }
ResolvedSources[50856] = { { instance="Guarida de Archavon", boss="Toravon el Vigia de Hielo (0.71%)" } }
ResolvedSources[51126] = { { instance="Guarida de Archavon", boss="Toravon el Vigia de Hielo (1.96%)" } }
ResolvedSources[51128] = { { instance="Guarida de Archavon", boss="Toravon el Vigia de Hielo (1.07%)" } }
ResolvedSources[51131] = { { instance="Guarida de Archavon", boss="Toravon el Vigia de Hielo (1.69%)" } }
ResolvedSources[51132] = { { instance="Guarida de Archavon", boss="Toravon el Vigia de Hielo (1.92%)" } }
ResolvedSources[51136] = { { instance="Guarida de Archavon", boss="Toravon el Vigia de Hielo (1.07%)" } }
ResolvedSources[51138] = { { instance="Guarida de Archavon", boss="Toravon el Vigia de Hielo (1.29%)" } }
ResolvedSources[51142] = { { instance="Guarida de Archavon", boss="Toravon el Vigia de Hielo (1.16%)" } }
ResolvedSources[51144] = { { instance="Guarida de Archavon", boss="Toravon el Vigia de Hielo (0.98%)" } }
ResolvedSources[51146] = { { instance="Guarida de Archavon", boss="Toravon el Vigia de Hielo (1.92%)" } }
ResolvedSources[51148] = { { instance="Guarida de Archavon", boss="Toravon el Vigia de Hielo (0.94%)" } }
ResolvedSources[51154] = { { instance="Guarida de Archavon", boss="Toravon el Vigia de Hielo (3.21%)" } }
ResolvedSources[51157] = { { instance="Guarida de Archavon", boss="Toravon el Vigia de Hielo (2.99%)" } }
ResolvedSources[51159] = { { instance="Guarida de Archavon", boss="Toravon el Vigia de Hielo (3.43%)" } }
ResolvedSources[51161] = { { instance="Guarida de Archavon", boss="Toravon el Vigia de Hielo (0.94%)" } }
ResolvedSources[51163] = { { instance="Guarida de Archavon", boss="Toravon el Vigia de Hielo (0.98%)" } }
ResolvedSources[51171] = { { instance="Guarida de Archavon", boss="Toravon el Vigia de Hielo (1.47%)" } }
ResolvedSources[51172] = { { instance="Guarida de Archavon", boss="Toravon el Vigia de Hielo (1.11%)" } }
ResolvedSources[51177] = { { instance="Guarida de Archavon", boss="Toravon el Vigia de Hielo (2.41%)" } }
ResolvedSources[51179] = { { instance="Guarida de Archavon", boss="Toravon el Vigia de Hielo (1.78%)" } }
ResolvedSources[51181] = { { instance="Guarida de Archavon", boss="Toravon el Vigia de Hielo (2.14%)" } }
ResolvedSources[51183] = { { instance="Guarida de Archavon", boss="Toravon el Vigia de Hielo (1.52%)" } }
ResolvedSources[51186] = { { instance="Guarida de Archavon", boss="Toravon el Vigia de Hielo (3.57%)" } }
ResolvedSources[51188] = { { instance="Guarida de Archavon", boss="Toravon el Vigia de Hielo (3.25%)" } }
ResolvedSources[51191] = { { instance="Guarida de Archavon", boss="Toravon el Vigia de Hielo (1.16%)" } }
ResolvedSources[51193] = { { instance="Guarida de Archavon", boss="Toravon el Vigia de Hielo (1.52%)" } }
ResolvedSources[51196] = { { instance="Guarida de Archavon", boss="Toravon el Vigia de Hielo (1.96%)" } }
ResolvedSources[51198] = { { instance="Guarida de Archavon", boss="Toravon el Vigia de Hielo (1.43%)" } }
ResolvedSources[51201] = { { instance="Guarida de Archavon", boss="Toravon el Vigia de Hielo (1.52%)" } }
ResolvedSources[51203] = { { instance="Guarida de Archavon", boss="Toravon el Vigia de Hielo (1.16%)" } }
ResolvedSources[51207] = { { instance="Guarida de Archavon", boss="Toravon el Vigia de Hielo (3.79%)" } }
ResolvedSources[51209] = { { instance="Guarida de Archavon", boss="Toravon el Vigia de Hielo (3.48%)" } }
ResolvedSources[51211] = { { instance="Guarida de Archavon", boss="Toravon el Vigia de Hielo (2.14%)" } }
ResolvedSources[51213] = { { instance="Guarida de Archavon", boss="Toravon el Vigia de Hielo (1.83%)" } }
ResolvedSources[51216] = { { instance="Guarida de Archavon", boss="Toravon el Vigia de Hielo (1.65%)" } }
ResolvedSources[51217] = { { instance="Guarida de Archavon", boss="Toravon el Vigia de Hielo (1.83%)" } }
ResolvedSources[51368] = { { instance="Guarida de Archavon", boss="Toravon el Vigia de Hielo (0.89%)" } }
ResolvedSources[51369] = { { instance="Guarida de Archavon", boss="Toravon el Vigia de Hielo (1.16%)" } }
ResolvedSources[51370] = { { instance="Guarida de Archavon", boss="Toravon el Vigia de Hielo (0.53%)" } }
ResolvedSources[51426] = { { instance="Guarida de Archavon", boss="Toravon el Vigia de Hielo (0.53%)" } }
ResolvedSources[51428] = { { instance="Guarida de Archavon", boss="Toravon el Vigia de Hielo (1.11%)" } }
ResolvedSources[51802] = { { instance="Ciudadela de la Corona de Hielo", boss="El Rey Exanime (7.24%)" } }
ResolvedSources[51811] = { { instance="Ciudadela de la Corona de Hielo", boss="Sindragosa (2.30%)" } }
ResolvedSources[51812] = { { instance="Ciudadela de la Corona de Hielo", boss="Sindragosa (1.72%)" } }
ResolvedSources[51813] = { { instance="Ciudadela de la Corona de Hielo", boss="Sindragosa (2.87%)" } }
ResolvedSources[51815] = { { instance="Ciudadela de la Corona de Hielo", boss="Sindragosa (1.15%)" } }
ResolvedSources[51816] = { { instance="Ciudadela de la Corona de Hielo", boss="Sindragosa (0.57%)" } }
ResolvedSources[51817] = { { instance="Ciudadela de la Corona de Hielo", boss="Sindragosa (1.15%)" } }
ResolvedSources[51820] = { { instance="Ciudadela de la Corona de Hielo", boss="Sindragosa (2.30%)" } }
ResolvedSources[51821] = { { instance="Ciudadela de la Corona de Hielo", boss="Sindragosa (1.15%)" } }
ResolvedSources[51822] = { { instance="Ciudadela de la Corona de Hielo", boss="Sindragosa (2.30%)" } }
ResolvedSources[51835] = { { instance="Ciudadela de la Corona de Hielo", boss="Reina de Sangre Lana'thel (3.39%)" } }
ResolvedSources[51837] = { { instance="Ciudadela de la Corona de Hielo", boss="Reina de Sangre Lana'thel (4.32%)" } }
ResolvedSources[51838] = { { instance="Ciudadela de la Corona de Hielo", boss="Reina de Sangre Lana'thel (5.34%)" } }
ResolvedSources[51839] = { { instance="Ciudadela de la Corona de Hielo", boss="Reina de Sangre Lana'thel (2.88%)" } }
ResolvedSources[51840] = { { instance="Ciudadela de la Corona de Hielo", boss="Reina de Sangre Lana'thel (2.47%)" } }
ResolvedSources[51841] = { { instance="Ciudadela de la Corona de Hielo", boss="Reina de Sangre Lana'thel (2.26%)" } }
ResolvedSources[51842] = { { instance="Ciudadela de la Corona de Hielo", boss="Reina de Sangre Lana'thel (2.77%)" } }
ResolvedSources[51843] = { { instance="Ciudadela de la Corona de Hielo", boss="Reina de Sangre Lana'thel (4.73%)" } }
ResolvedSources[51844] = { { instance="Ciudadela de la Corona de Hielo", boss="Reina de Sangre Lana'thel (3.80%)" } }
ResolvedSources[51845] = { { instance="Ciudadela de la Corona de Hielo", boss="Reina de Sangre Lana'thel (4.32%)" } }
ResolvedSources[51847] = { { instance="Ciudadela de la Corona de Hielo", boss="Principe Valanar (1.43%)" } }
ResolvedSources[51848] = { { instance="Ciudadela de la Corona de Hielo", boss="Principe Valanar (0.78%)" } }
ResolvedSources[51849] = { { instance="Ciudadela de la Corona de Hielo", boss="Principe Valanar (1.82%)" } }
ResolvedSources[51850] = { { instance="Ciudadela de la Corona de Hielo", boss="Principe Valanar (1.56%)" } }
ResolvedSources[51851] = { { instance="Ciudadela de la Corona de Hielo", boss="Principe Valanar (0.52%)" } }
ResolvedSources[51852] = { { instance="Ciudadela de la Corona de Hielo", boss="Principe Valanar (1.43%)" } }
ResolvedSources[51853] = { { instance="Ciudadela de la Corona de Hielo", boss="Principe Valanar (1.30%)" } }
ResolvedSources[51854] = { { instance="Ciudadela de la Corona de Hielo", boss="Principe Valanar (1.04%)" } }
ResolvedSources[51855] = { { instance="Ciudadela de la Corona de Hielo", boss="Principe Valanar (0.78%)" } }
ResolvedSources[51856] = { { instance="Ciudadela de la Corona de Hielo", boss="Principe Valanar (1.04%)" } }
ResolvedSources[51857] = { { instance="Ciudadela de la Corona de Hielo", boss="Principe Valanar (2.34%)" } }
ResolvedSources[51858] = { { instance="Ciudadela de la Corona de Hielo", boss="Principe Valanar (1.04%)" } }
ResolvedSources[51859] = { { instance="Ciudadela de la Corona de Hielo", boss="Profesor Putricidio (1.18%)" } }
ResolvedSources[51860] = { { instance="Ciudadela de la Corona de Hielo", boss="Profesor Putricidio (1.18%)" } }
ResolvedSources[51862] = { { instance="Ciudadela de la Corona de Hielo", boss="Profesor Putricidio (0.63%)" } }
ResolvedSources[51863] = { { instance="Ciudadela de la Corona de Hielo", boss="Profesor Putricidio (2.13%)" } }
ResolvedSources[51864] = { { instance="Ciudadela de la Corona de Hielo", boss="Profesor Putricidio (0.95%)" } }
ResolvedSources[51865] = { { instance="Ciudadela de la Corona de Hielo", boss="Profesor Putricidio (1.10%)" } }
ResolvedSources[51866] = { { instance="Ciudadela de la Corona de Hielo", boss="Profesor Putricidio (0.79%)" } }
ResolvedSources[51867] = { { instance="Ciudadela de la Corona de Hielo", boss="Profesor Putricidio (1.34%)" } }
ResolvedSources[51868] = { { instance="Ciudadela de la Corona de Hielo", boss="Profesor Putricidio (1.26%)" } }
ResolvedSources[51869] = { { instance="Ciudadela de la Corona de Hielo", boss="Profesor Putricidio (1.26%)" } }
ResolvedSources[51871] = { { instance="Ciudadela de la Corona de Hielo", boss="Caraputrea (3.39%)" } }
ResolvedSources[51872] = { { instance="Ciudadela de la Corona de Hielo", boss="Caraputrea (5.82%)" } }
ResolvedSources[51874] = { { instance="Ciudadela de la Corona de Hielo", boss="Caraputrea (4.05%)" } }
ResolvedSources[51875] = { { instance="Ciudadela de la Corona de Hielo", boss="Caraputrea (7.73%)" } }
ResolvedSources[51877] = { { instance="Ciudadela de la Corona de Hielo", boss="Caraputrea (3.46%)" } }
ResolvedSources[51878] = { { instance="Ciudadela de la Corona de Hielo", boss="Caraputrea (3.90%)" } }
ResolvedSources[51879] = { { instance="Ciudadela de la Corona de Hielo", boss="Caraputrea (3.83%)" } }
ResolvedSources[51880] = { { instance="Ciudadela de la Corona de Hielo", boss="Caraputrea (3.68%)" } }
ResolvedSources[51882] = { { instance="Ciudadela de la Corona de Hielo", boss="Panzachancro (3.42%)" } }
ResolvedSources[51883] = { { instance="Ciudadela de la Corona de Hielo", boss="Panzachancro (2.26%)" } }
ResolvedSources[51884] = { { instance="Ciudadela de la Corona de Hielo", boss="Panzachancro (3.01%)" } }
ResolvedSources[51887] = { { instance="Ciudadela de la Corona de Hielo", boss="Panzachancro (4.51%)" } }
ResolvedSources[51888] = { { instance="Ciudadela de la Corona de Hielo", boss="Panzachancro (1.50%)" } }
ResolvedSources[51889] = { { instance="Ciudadela de la Corona de Hielo", boss="Panzachancro (2.39%)" } }
ResolvedSources[51890] = { { instance="Ciudadela de la Corona de Hielo", boss="Panzachancro (2.80%)" } }
ResolvedSources[51891] = { { instance="Ciudadela de la Corona de Hielo", boss="Panzachancro (2.87%)" } }
ResolvedSources[51892] = { { instance="Ciudadela de la Corona de Hielo", boss="Panzachancro (3.83%)" } }
ResolvedSources[51893] = { { instance="Ciudadela de la Corona de Hielo", boss="Panzachancro (3.55%)" } }
ResolvedSources[51917] = { { instance="Ciudadela de la Corona de Hielo", boss="Lady Susurramuerte (3.21%)" } }
ResolvedSources[51918] = { { instance="Ciudadela de la Corona de Hielo", boss="Lady Susurramuerte (3.36%)" } }
ResolvedSources[51919] = { { instance="Ciudadela de la Corona de Hielo", boss="Lady Susurramuerte (3.59%)" } }
ResolvedSources[51920] = { { instance="Ciudadela de la Corona de Hielo", boss="Lady Susurramuerte (3.29%)" } }
ResolvedSources[51921] = { { instance="Ciudadela de la Corona de Hielo", boss="Lady Susurramuerte (4.48%)" } }
ResolvedSources[51922] = { { instance="Ciudadela de la Corona de Hielo", boss="Lady Susurramuerte (6.28%)" } }
ResolvedSources[51923] = { { instance="Ciudadela de la Corona de Hielo", boss="Lady Susurramuerte (4.11%)" } }
ResolvedSources[51924] = { { instance="Ciudadela de la Corona de Hielo", boss="Lady Susurramuerte (2.99%)" } }
ResolvedSources[51925] = { { instance="Ciudadela de la Corona de Hielo", boss="Lady Susurramuerte (3.51%)" } }
ResolvedSources[51926] = { { instance="Ciudadela de la Corona de Hielo", boss="Lady Susurramuerte (2.62%)" } }
ResolvedSources[51927] = { { instance="Ciudadela de la Corona de Hielo - BANDA", boss="Lady Susurramuerte (5.46%)" } }
ResolvedSources[51928] = { { instance="Ciudadela de la Corona de Hielo - BANDA", boss="Lord Tuetano (3.68%)" } }
ResolvedSources[51929] = { { instance="Ciudadela de la Corona de Hielo - BANDA", boss="Lord Tuetano (2.45%)" } }
ResolvedSources[51930] = { { instance="Ciudadela de la Corona de Hielo - BANDA", boss="Lord Tuetano (3.02%)" } }
ResolvedSources[51932] = { { instance="Ciudadela de la Corona de Hielo - BANDA", boss="Lord Tuetano (5.09%)" } }
ResolvedSources[51933] = { { instance="Ciudadela de la Corona de Hielo - BANDA", boss="Lord Tuetano (5.19%)" } }
ResolvedSources[51934] = { { instance="Ciudadela de la Corona de Hielo - BANDA", boss="Lord Tuetano (1.51%)" } }
ResolvedSources[51935] = { { instance="Ciudadela de la Corona de Hielo - BANDA", boss="Lord Tuetano (2.26%)" } }
ResolvedSources[51937] = { { instance="Ciudadela de la Corona de Hielo - BANDA", boss="Lord Tuetano (3.02%)" } }
ResolvedSources[51938] = { { instance="Ciudadela de la Corona de Hielo - BANDA", boss="Lord Tuetano (3.11%)" } }
ResolvedSources[51939] = { { instance="Ciudadela de la Corona de Hielo - BANDA", boss="El Rey Exanime (0.20%)" } }
ResolvedSources[51940] = { { instance="Ciudadela de la Corona de Hielo - BANDA", boss="El Rey Exanime (0.20%)" } }
ResolvedSources[51944] = { { instance="Ciudadela de la Corona de Hielo - BANDA", boss="El Rey Exanime (0.20%)" } }
ResolvedSources[51946] = { { instance="Ciudadela de la Corona de Hielo - BANDA", boss="El Rey Exanime (0.20%)" } }
ResolvedSources[37293] = { { instance="El Oculus (Heroico)", boss="Guardián-Ley Eregos" } }
ResolvedSources[39554] = { { instance="Vendedor", boss="Emblemas de Heroismo = Dalaran - Costo: Emblemas de Heroismo x80" } }
ResolvedSources[39557] = { { instance="Vendedor", boss="Emblemas de Heroismo = Dalaran - Costo: Emblemas de Heroismo x60" } }
ResolvedSources[37366] = { { instance="El Oculus (Heroico)", boss="Basura (varios enemigos)" } }
