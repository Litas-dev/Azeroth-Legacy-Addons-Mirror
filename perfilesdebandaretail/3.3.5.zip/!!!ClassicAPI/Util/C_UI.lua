local C_UI = C_UI or {}

C_UI.Reload = ReloadUI

-- Global
_G.C_UI = C_UI