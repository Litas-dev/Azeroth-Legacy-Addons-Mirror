local L = LibStub("AceLocale-3.0"):NewLocale("UnlimitedChatMessage", "deDE")
if not L then return end
