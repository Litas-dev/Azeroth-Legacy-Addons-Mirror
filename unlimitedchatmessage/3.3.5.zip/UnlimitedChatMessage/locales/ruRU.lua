local L = LibStub("AceLocale-3.0"):NewLocale("UnlimitedChatMessage", "ruRU")
if not L then return end
