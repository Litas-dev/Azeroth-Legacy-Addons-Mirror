local L = LibStub("AceLocale-3.0"):NewLocale("UnlimitedChatMessage", "frFR")
if not L then return end
L["Confirm Long Messages"] = "Confirme un Message long"
L["Core"] = "Noyau"
L["Enable"] = "Activer"
L["Enables / Disables the addon"] = "Active / désactive l'addon"
L["Multi-line support"] = "Support de Multi-ligne"
L["Show a confirm window when splitting message into %d+ lines."] = "Afficher une fenêtre de confirmation lorsque le message se divise en %d + lignes."
