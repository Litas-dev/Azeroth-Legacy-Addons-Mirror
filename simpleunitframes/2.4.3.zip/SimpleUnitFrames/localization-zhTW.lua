if not SimpleUnitFrames or GetLocale() ~= "zhTW" then return end

local loc = {}

loc.Basics = {
	["Player Frame"] = "玩家頭像",
	["Party Frame"] = "隊伍頭像",
	["ToT Frame"] = "目標的目標",
	["Target Frame"] = "目標頭像",
	["Pet Frame"] = "寵物頭像",
	["Party Pet Frame"] = "隊友寵物",
	["Middle Health Text"] = "生命條中間文字",
	["Right Health Text"] = "生命條右邊文字",
	["Middle Mana Text"] = "法力條中間文字",
	["Right Mana Text"] = "法力條右邊文字",
	["Health Text"] = "生命條文字",
	["Mana Text"] = "法力條文字",
	["Class Icon"] = "職業圖示",
	["Middle Health Text Description"] = "設定生命條中間文字格式",
	["Right Health Text Description"] = "設定法力條中間文字格式",
	["Middle Mana Text Description"] = "設定生命條右邊文字格式",
	["Right Mana Text Description"] = "設定法力條右邊文字格式",
	["Health Text Description"] = "設定生命條文字格式",
	["Mana Text Description"] = "設定法力條文字格式",
	["Class Icon Description"] = "職業圖示顯示",
}	
	
-- Localization for the return values of UnitCreatureType(), which is required by ClassIcon.
loc.UnitCreatureType = {
	["Beast"] = "野獸",
	["Critter"] = "小動物",
	["Demon"] = "惡魔",
	["Dragonkin"] = "龍類",
	["Elemental"] = "元素生物",
	["Giant"] = "巨人",
	["Humanoid"] = "人型生物",
	["Mechanical"] = "機械",
	["Undead"] = "不死族",
}
loc.PortraitDamage = {
	["Portrait Damage"] = "傷害描述",
	["Toggle the display of Portrait Damage on specific frame."] = "是否顯示傷害描述在特定框架",
	["target"] = "目標框架",
	["party"] = "小隊框架",
	["partypet"] = "隊友寵物框架",
	["focus"]  = "監控框架",
}
-- This enables partial localization: default english locale will be displayed if there is a missing locale for your language.
SimpleUnitFrames:UpdateLocales(loc)

-- nil out to save memory.
loc = nil 
