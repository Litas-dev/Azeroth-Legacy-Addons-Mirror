if not SimpleUnitFrames or GetLocale() ~= "koKR" then return end

local loc = {}

loc.Basics = {
	["Player Frame"] = "플레이어 프레임",
	["Party Frame"] = "파티 프레임",
	["ToT Frame"] = "대상의 대상 프레임",
	["Target Frame"] = "대상 프레임",
	["Pet Frame"] = "소환수 프레임",
	["Party Pet Frame"] = "파티 소환수 프레임",
	["Middle Health Text"] = "중간 생명력 글자",
	["Right Health Text"] = "오른쪽 생명력 글자",
	["Middle Mana Text"] = "중간 마나 글자",
	["Right Mana Text"] = "오른쪽 마나 글자",
	["Health Text"] = "생명력 글자",
	["Mana Text"] = "마나 글자",
	["Class Icon"] = "직업 아이콘",
	["Middle Health Text Description"] = "중간 생명력 글자 표시 방법 선택",
	["Right Health Text Description"] = "오른쪽 생명력 글자 표시 방법 선택",
	["Middle Mana Text Description"] = "중간 마나 글자 표시 방법 선택",
	["Right Mana Text Description"] = "오른쪽 마나 글자 표시 방법 선택",
	["Health Text Description"] = "생명력 글자 표시 방법 선택",
	["Mana Text Description"] = "마나 글자 표시 방법 선택",
	["Class Icon Description"] = "직업 아이콘 표시를 전환합니다.",
}

-- This enables partial localization: default english locale will be displayed if there is a missing locale for your language.
SimpleUnitFrames:UpdateLocales(loc)

-- nil out to save memory.
loc = nil 
