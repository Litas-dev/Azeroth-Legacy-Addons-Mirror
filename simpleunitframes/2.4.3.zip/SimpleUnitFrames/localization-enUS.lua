if not SimpleUnitFrames then return end

local loc = {}

loc.Basics = {
	["Player Frame"] = true,
	["Party Frame"] = true,
	["ToT Frame"] = true,
	["Target Frame"] = true,
	["Pet Frame"] = true,
	["Party Pet Frame"] = true,
	["Middle Health Text"] = true,
	["Right Health Text"] = true,
	["Middle Mana Text"] = true,
	["Right Mana Text"] = true,
	["Health Text"] = true,
	["Mana Text"] = true,
	["Class Icon"] = true,
	["Middle Health Text Description"] = "Set middle health text to one of the formats",
	["Right Health Text Description"] = "Set right health text to one of the formats",
	["Middle Mana Text Description"] = "Set middle mana text to one of the formats",
	["Right Mana Text Description"] = "Set right health text to one of the formats",
	["Health Text Description"] = "Set health text to one oxf the formats",
	["Mana Text Description"] = "Set mama text to one of the formats",
	["Class Icon Description"] = "Toggle display of class icon",
	
}

-- Localization for the return values of UnitCreatureType(), which is required by ClassIcon.
loc.UnitCreatureType = {
	["Beast"] = "Beast",
	["Critter"] = "Critter",
	["Demon"] = "Demon",
	["Dragonkin"] = "Dragonkin",
	["Elemental"] = "Elemental",
	["Giant"] = "Giant",
	["Humanoid"] = "Humanoid",
	["Mechanical"] = "Mechanical",
	["Undead"] = "Undead",
}

loc.PortraitDamage = {
	["Portrait Damage"] = true,
	["Toggle the display of Portrait Damage on specific frame."] = true,
	["target"] = "Target Frame",
	["party"] = "Party Frame",
	["partypet"] = "Party Pet Frame",
	["focus"]  = "Focus Frame",
}


-- This enables partial localization: default english locale will be displayed if there is a missing locale for your language.
SimpleUnitFrames:UpdateLocales(loc)

-- nil out to save memory.
loc = nil 
