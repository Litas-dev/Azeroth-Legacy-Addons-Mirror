﻿--[[ $Id: frFRlua 18597 2006-12-02 06:24:04Z fenlis $ ]]--

local L = LibStub("AceLocale-3.0"):NewLocale("ClosetGnome", "frFR")
if not L then return end
L["Keybindings"] = "Raccourcis clavier"
L["closetgnome_description"] = "La définition officielle du ClosetGnome se trouve dans l'O.E.D. (Orgrimmar English Dictionary). Elle est traduite dans le petit Gobelin illustré comme suit : 'nom (1) une créature ressemblant à un nabot supposée garder les habits de son possesseur, (2) un petit ornement ressemblant à un homme barbu et portant des habits sexy habituellement trouvé dans les placards.'\n\nPersonnellement, je dirai qu'il s'agit là de petites créatures amusantes. La plupart d'entre eux sont fiables et font bien leur boulot, non pas parce qu'ils vous sont fidèles, mais parce qu'ils sont fidèles aux habits qu'ils protègent.\n\nUn ClosetGnome peut être beaucoup plus efficace à sa tâche si vous l'habituez à utiliser les raccourcis clavier.\n\n"
L["keybinding_description"] = "L'association de raccourcis clavier pour vos ensembles ClosetGnome permet de changer d'équipement rapidement et facilement, sans passer par le menu.\n\n"

L["Show minimap icon"] = "Voir le bouton sur la mini-carte"
L["Toggle showing or hiding the minimap icon."] = "Afficher ou masquer le bouton de la mini-carte"
L["Quips"] = "Citations"
L["Toggle outputting random quips when equipping sets."] = "Affiche ou non des phrases rigolotes lorsque vous équipez un ensemble (en anglais)."
L["Keybinding"] = "Raccourci"
L["Assign a keybinding to %s."] = "Assigne un raccourci clavier à %s."
L["Registering keybinding %s to set %s."] = "Assignement du raccourci %s à l'ensemble %s."
L["%s is already registered to %s."] = "%s est déjà assigné à l'ensemble %s."
L["Removing keybinding %s from set %s."] = "Suppression du raccourci %s de l'ensemble %s."