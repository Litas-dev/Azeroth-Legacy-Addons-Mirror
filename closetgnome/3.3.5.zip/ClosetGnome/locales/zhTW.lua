-------------------------------------------------------------------------------
-- Localization                                                              --
-------------------------------------------------------------------------------
--[[ $Id: zhTW.lua 604 2009-05-20 00:59:18Z a9012456 $ ]]--

local L = LibStub("AceLocale-3.0"):NewLocale("ClosetGnome", "zhTW")
if not L then return end

L["Keybindings"] = "快捷鍵"

L["closetgnome_description"] = "ClosetGnomes are defined by the O.E.D. (Orgrimmar English Dictionary) as 'noun (1) a legendary dwarfish creature supposed to guard the owners outfits, (2) a small ornament in the form of a bearded man with a foxy outfit usually located inside closets.'\n\nPersonally, I would say they're funny little creatures, most of them are reliable and do a good job, not because they are loyal to you, but because they are loyal to the clothes they protect.\n\nA ClosetGnome can be made a whole lot more effective at his task if you train him using the keybindings.\n\n"
L["keybinding_description"] = "為你的ClosetGnome設定快捷鍵可以更快速且更簡單的交換在選單中的物品設定.\n\n"

L["|cffeda55fLeft-Click|r a slot to toggle it for this set. Green slots are |cff00ff00enabled|r, red are |cffff0000disabled|r, yellow are |cffffff00missing items|r.\n\nIf you want to assign an |cff0000fficon|r to this set, you can |cffeda55fCtrl-Click|r a slot to use that slots item as the icon.\n\nType the desired set name below and click Add when you are done."] = "在欄位上|cffeda55f左擊|r決定是否在此套裝使用這裝備，綠色表示|cff00ff00使用|r，紅色|cffff0000不使用|r，黃色|cffffff00找不到|r。\n\n若你想要指定裝備的|cff0000ff圖示|r，可以使用|cffeda55fCtrl-點擊|r。\n\n選好後在下面欄內輸入套裝名，並點擊「新增」。"
L["|cff00ff00Green slots|r are active, and any item currently in a green slot will be saved as part of the item set."] = "|cff00ff00綠色欄位|r表示使用，在此欄位的裝備會被儲存在套裝中。"
L["|cffff0000Red slots|r are disabled, and will be ignored by the item set."] = "|cffff0000紅色欄位|r表示不使用，在此欄位的裝備不會被儲存在套裝中。"
L["A |cffffff00yellow slot|r means the item is missing from your inventory, and when you update the set, the item stored in the set will be used, and not the currently equipped one."] = "|cffffff00黃色欄位|r表示該裝備並不在你的庫存中，當你更新設定時，設定中該欄位的裝備會被儲存，而不是你現在在該欄位穿著的裝備。"
L["A |cff0000ffblue slot|r tells your ClosetGnome to use the item in that slot as the set icon. If a slot is toggled to an icon slot, it is also activated immediately."] = "|cff0000ff藍色欄位|r使 ClosetGnome 使用該欄位的裝備圖示為設定圖示。假如該欄位被選擇為設定圖示，該欄位會被儲存在設定中。"

L["Show minimap icon"] = "顯示小地圖圖示"
L["Toggle showing or hiding the minimap icon."] = "顯示或隱藏小地圖圖示"
L["Add"] = "新增"
L["Creates a new set, or updates an existing one."] = "創建新設定，或更新一個現有的設定。"
L["Wear"] = "穿上"
L["Change equipment set."] = "改變裝備設定。"
L["Delete"] = "刪除"
L["Cancel"] = "取消"
L["Always equip weapons"] = "總是裝備武器"
L["Equip weapons in sets even if you are in combat."] = "裝備設定中的武器即使你在戰鬥中。"
L["Quips"] = "諷刺"
L["Toggle outputting random quips when equipping sets."] = "當你換裝時隨機諷刺。"
L["Are you sure you want to delete the set %s?"] = "你確定想刪除%s設定嗎?"
L["<set name>"] = "<設定名稱>"
L["Couldn't find %s in your inventory."] = "在你的物品中無法找到%s。"
L["Keybinding"] = "快捷鍵"
L["Assign a keybinding to %s."] = "指定一個快捷鍵給%s。"
L["Registering keybinding %s to set %s."] = "註冊快捷鍵 %s 到設定 %s。"
L["%s is already registered to %s."] = "%s已經註冊給%s。"
L["Removing keybinding %s from set %s."] = "從設定 %s 移除快捷鍵 %s。"

L["In combat: %s queued for swap."] = "戰鬥中: %s在佇列等候中。"
L["Added set: %s."] = "新增設定: %s。"
L["Deleted set: %s."] = "刪除設定: %s。"
L["Updating set: %s."] = "更新設定: %s。"
L["Please use a proper name for your set."] = "請為你的設定使用正確的名稱。"

-- This is what a normal bag is called, as returned from GetItemInfo's
-- subType
L["Bag"] = "背包"

-- Random quips when you equip a set.
L[1] = "Your ClosetGnome rapidly dresses you up in %s before he runs off with another sock."
L[2] = "Once in a blue moon your ClosetGnome will equip you with an Artifact item. Not today, however, you'll have to settle for %s."
L[3] = "ClosetGnomes are tidy creatures. Not yours, though, as he equips %s he just piles your old outfit in the corner."
L[4] = "It's almost as if he dances around you while he dresses you up in %s. Although it's a very ugly dance."
L[5] = "Since you forgot to feed your ClosetGnome today, he expresses his anger by equipping your %s backwards."
L[6] = "Never let your ClosetGnome tend to other needs than %s."
L[7] = "%s looks good on you today, at least compared to how it looked on your ClosetGnome when you caught him wearing it."
L[8] = "ClosetGnome equips %s."
L[9] = "Your ClosetGnome flinches in disgust as he equips %s. You're not sure why, but what's that smell ..."
L[10] = "Is that a whirlwind?! No, it's ClosetGnome dressing you in %s!"
L[11] = "Recently returned from the ClosetGnome convention, he's got a lot to talk about while dressing you in %s."
L[12] = "Noone knows if ClosetGnomes party, but you do. This is how it looked last time you dressed yourself in %s after a party."
L[13] = "'Getting Jiggy With It' was never your favorite, but you have to admit that it fits nicely with %s."
L[14] = "Even though your washer is clearly labeled 'Certified by ClosetGnomes, Inc.', it's clear that %s has not been cleaned in a while."
L[15] = "%s has the same color socks as your last set, and the one before that, and before that."
L[16] = "Instead of equipping %s, your ClosetGnome starts gnawing on your leg. You shake him off and do it yourself."
L[17] = "Noone has ever suspected you of having a ClosetGnome. Most of them are actually good at equipping things like %s."
L[18] = "What kind of person are you that dresses up in %s so often? Your ClosetGnome eyes you up and down. He looks .. hungry."
L[19] = "Your ClosetGnome is hungry and scavenges the pockets of %s for food, but finds nothing. Do you ever feed him?"
L[20] = "The first rule of the ClosetGnomes is that they do not talk about %s."
L[21] = "%s seems different somehow."
L[22] = "There is no %s."
L[23] = "You feel the need - the need for %s!"
L[24] = "Your ClosetGnome equips %s. Shaken, not stirred."
L[25] = "ClosetGnome puts %s in a corner. Then comes back and equips it."
L[26] = "Hasta la vista, %s."
L[27] = "Keep your %s close, but your ClosetGnome closer."
L[28] = "A boy's best friend is a ClosetGnome that comes with %s."
L[29] = "You love the smell of %s in the morning."
L[30] = "May your ClosetGnome be with you. And may he bring %s."
L[31] = "You make your ClosetGnome an offer he can't refuse, and so he equips %s."
L[32] = "You place a rainbow-coloured %s in front of your ClosetGnome, luring him to come out."
L[33] = "Your ClosetGnome equips %s and flaunts its massive size (or lack there of)."
L[34] = "Soothing his heart with 'Theme from Love Boat', your ClosetGnome dutifully equips %s."
L[35] = "Lately, your ClosetGnome has begun ranting about some device called SwapMagic. He says it would help him organize %s."