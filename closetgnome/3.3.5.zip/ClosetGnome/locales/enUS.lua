--[[ $Id: enUS.lua 18820 2006-12-04 03:43:09Z rabbit $ ]]--

local L = LibStub("AceLocale-3.0"):NewLocale("ClosetGnome", "enUS", true)

L["Keybindings"] = true
L["closetgnome_description"] = "ClosetGnomes are defined by the O.E.D. (Orgrimmar English Dictionary) as 'noun (1) a legendary dwarfish creature supposed to guard the owners outfits, (2) a small ornament in the form of a bearded man with a foxy outfit usually located inside closets.'\n\nPersonally, I would say they're funny little creatures, most of them are reliable and do a good job, not because they are loyal to you, but because they are loyal to the clothes they protect."
L["Keybinding"] = true
L["Click and press a key combination to bind it to this equipment set. Escape clears an existing binding."] = true
L["Show minimap icon"] = true
L["Quips"] = true
L.ldbTooltip = "|cffeda55fClick|r to access the menu, where you can equip sets or delete them by holding down Ctrl. |cffeda55fRight-Click|r to pop open the ClosetGnome interface options."

-- Random quips when you equip a set.
L[1] = "Your ClosetGnome rapidly dresses you up in %s before he runs off with another sock."
L[2] = "Once in a blue moon your ClosetGnome will equip you with an Artifact item. Not today, however, you'll have to settle for %s."
L[3] = "ClosetGnomes are tidy creatures. Not yours, though, as he equips %s he just piles your old outfit in the corner."
L[4] = "It's almost as if he dances around you while he dresses you up in %s. Although it's a very ugly dance."
L[5] = "Since you forgot to feed your ClosetGnome today, he expresses his anger by equipping your %s backwards."
L[6] = "Never let your ClosetGnome tend to other needs than %s."
L[7] = "%s looks good on you today, at least compared to how it looked on your ClosetGnome when you caught him wearing it."
L[8] = "ClosetGnome equips %s."
L[9] = "Your ClosetGnome flinches in disgust as he equips %s. You're not sure why, but what's that smell ..."
L[10] = "Is that a whirlwind?! No, it's ClosetGnome dressing you in %s!"
L[11] = "Recently returned from the ClosetGnome convention, he's got a lot to talk about while dressing you in %s."
L[12] = "Noone knows if ClosetGnomes party, but you do. This is how it looked last time you dressed yourself in %s after a party."
L[13] = "'Getting Jiggy With It' was never your favorite, but you have to admit that it fits nicely with %s."
L[14] = "Even though your washer is clearly labeled 'Certified by ClosetGnomes, Inc.', it's clear that %s has not been cleaned in a while."
L[15] = "%s has the same color socks as your last set, and the one before that, and before that."
L[16] = "Instead of equipping %s, your ClosetGnome starts gnawing on your leg. You shake him off and do it yourself."
L[17] = "Noone has ever suspected you of having a ClosetGnome. Most of them are actually good at equipping things like %s."
L[18] = "What kind of person are you that dresses up in %s so often? Your ClosetGnome eyes you up and down. He looks .. hungry."
L[19] = "Your ClosetGnome is hungry and scavenges the pockets of %s for food, but finds nothing. Do you ever feed him?"
L[20] = "The first rule of the ClosetGnomes is that they do not talk about %s."
L[21] = "%s seems different somehow."
L[22] = "There is no %s."
L[23] = "You feel the need - the need for %s!"
L[24] = "Your ClosetGnome equips %s. Shaken, not stirred."
L[25] = "ClosetGnome puts %s in a corner. Then comes back and equips it."
L[26] = "Hasta la vista, %s."
L[27] = "Keep your %s close, but your ClosetGnome closer."
L[28] = "A boy's best friend is a ClosetGnome that comes with %s."
L[29] = "You love the smell of %s in the morning."
L[30] = "May your ClosetGnome be with you. And may he bring %s."
L[31] = "You make your ClosetGnome an offer he can't refuse, and so he equips %s."
L[32] = "You place a rainbow-coloured %s in front of your ClosetGnome, luring him to come out."
L[33] = "Your ClosetGnome equips %s and flaunts its massive size (or lack there of)."
L[34] = "Soothing his heart with 'Theme from Love Boat', your ClosetGnome dutifully equips %s."
L[35] = "Lately, your ClosetGnome has begun ranting about some device called SwapMagic. He says it would help him organize %s."

-- Total number of quips
L["num_quips"] = 35

