-- This file is automagically generated.
-- Please visit http://www.wowace.com/projects/cooldown-to-go/localization/
-- if you wish to help with the translation.

local L = LibStub("AceLocale-3.0"):NewLocale("CooldownToGo_Options", "koKR")
if not L then return end

L["Color"] = "색상"
L["Font"] = "글꼴"
L["Font outline"] = "글꼴 윤각"
L["Font size"] = "글꼴 크기"
L["Frame strata"] = "창 우선순위"
L["High"] = "높음"
L["Locked"] = "잠금"
L["Lock/Unlock display frame"] = "표시 창을 고정시키거나 이동시킵니다."
L["Low"] = "낮음"
L["Medium"] = "중간"
L["None"] = "없음"
L["Normal"] = "보통"
L["Strata"] = "우선순위"
L["Thick"] = "굵게"

