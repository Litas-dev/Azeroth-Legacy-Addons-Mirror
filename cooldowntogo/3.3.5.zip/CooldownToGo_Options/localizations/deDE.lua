-- This file is automagically generated.
-- Please visit http://www.wowace.com/projects/cooldown-to-go/localization/
-- if you wish to help with the translation.

local L = LibStub("AceLocale-3.0"):NewLocale("CooldownToGo_Options", "deDE")
if not L then return end

L["Color"] = "Farbe"
L["Font"] = "Schriftart"
L["Font outline"] = "Schriftstil"
L["Font size"] = "Schriftgröße"
L["High"] = "Hoch"
L["Ignore list"] = "Ignorier-Liste"
L["Ignore next action"] = "Nächste Aktion ignorieren"
L["Items"] = "Gegenstände"
L["Locked"] = "Gesperrt"
L["Lock/Unlock display frame"] = "Anzeige sperren/entsperren"
L["Low"] = "Niedrig"
L["Medium"] = "Mittel"
L["None"] = "Keine"
L["Normal"] = "Normal"
L["Petbar"] = "Begleiterleiste"
L["Spells"] = "Zauber"
L["Thick"] = "Fett"
L["Warning Sound"] = "Warnungs Sound"
L["Warning Sound Name"] = "Name des Warnungs-Sound"

