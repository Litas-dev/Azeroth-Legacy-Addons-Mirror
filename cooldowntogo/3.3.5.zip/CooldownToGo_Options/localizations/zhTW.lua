-- This file is automagically generated.
-- Please visit http://www.wowace.com/projects/cooldown-to-go/localization/
-- if you wish to help with the translation.

local L = LibStub("AceLocale-3.0"):NewLocale("CooldownToGo_Options", "zhTW")
if not L then return end

L["Color"] = "顏色"
L["Font"] = "字體"
L["Font outline"] = "字體外框"
L["Font size"] = "字體大小"
L["Frame strata"] = "框架顯示層面"
L["High"] = "最高層"
L["Ignore list"] = "忽略名單"
L["Ignore next action"] = "忽略下個動作"
L["Items"] = "物品"
L["Locked"] = "鎖定"
L["Lock/Unlock display frame"] = "鎖定/解鎖框體"
L["Low"] = "最低層"
L["Medium"] = "中間層"
L["None"] = "無"
L["Normal"] = "正常"
L["Petbar"] = "寵物動作列"
L["Play a sound when the cooldown reaches Ready Time"] = "冷卻結束時發出音效"
L["Ready time"] = "冷卻結束"
L["Strata"] = "層面"
L["Thick"] = "加粗"
L["Time to hold the message in seconds"] = "文字停留時間"
L["Warning Sound"] = "警告音效"
L["Warning Sound Name"] = "警告音效名稱"

