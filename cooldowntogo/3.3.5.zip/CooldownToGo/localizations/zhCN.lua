-- This file is automagically generated.
-- Please visit http://www.wowace.com/projects/cooldown-to-go/localization/
-- if you wish to help with the translation.

local L = LibStub("AceLocale-3.0"):NewLocale("CooldownToGo", "zhCN")
if not L then return end

L["added %s to ignore list"] = "将 %s 加入忽略列表"
L["|cffeda55fControl + Left Click|r to lock frame"] = "|cffeda55fCTRL + 点击|r 锁定框体"
L["|cffeda55fDrag|r to move the frame"] = "|cffeda55f拖拽|r 移动框体"
L["|cffeda55fLeft Click|r to lock/unlock frame"] = "|cffeda55f点击|r 锁定或解锁框体"
L["|cffeda55fRight Click|r to open the configuration window"] = "|cffeda55f右击|r 打开配置窗口"
L["|cffeda55fShift + Left Click|r to ignore next action"] = "|cffeda55fShift + 点击|r 忽略下一个动作"
L["Next action will be added to ignore list"] = "下一个动作将被加入忽略列表"
L["Ready"] = "准备就绪"
L["removed %s from ignore list"] = "将 %s 从忽略列表中移除"

