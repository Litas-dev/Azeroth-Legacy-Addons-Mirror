-- This file is automagically generated.
-- Please visit http://www.wowace.com/projects/cooldown-to-go/localization/
-- if you wish to help with the translation.

local L = LibStub("AceLocale-3.0"):NewLocale("CooldownToGo", "ruRU")
if not L then return end

L["added %s to ignore list"] = "%s добавлен в Черный список"
L["|cffeda55fControl + Left Click|r to lock frame"] = "|cffeda55fКонтр + Л.клик|r закрепить окно"
L["|cffeda55fDrag|r to move the frame"] = "|cffeda55fУдерживать|r для перемещения"
L["|cffeda55fLeft Click|r to lock/unlock frame"] = "|cffeda55fЛ.клик|r закрепить окно"
L["|cffeda55fRight Click|r to open the configuration window"] = "|cffeda55fП.клик|r открыть окно настроек"
L["|cffeda55fShift + Left Click|r to ignore next action"] = "|cffeda55fШифт+Л.клик|r игнорировать следующее действие"
L["Next action will be added to ignore list"] = "Следующее действие будет добавлено в Черный список"
L["Ready"] = "Готов"
L["removed %s from ignore list"] = "%s удален из Черного списка"

