-- This file is automagically generated.
-- Please visit http://www.wowace.com/projects/cooldown-to-go/localization/
-- if you wish to help with the translation.

local L = LibStub("AceLocale-3.0"):NewLocale("CooldownToGo", "zhTW")
if not L then return end

L["added %s to ignore list"] = "已增加 % 到忽略名單中"
L["|cffeda55fControl + Left Click|r to lock frame"] = "|cffeda55fCtrl + 左鍵|r 鎖定框架"
L["|cffeda55fDrag|r to move the frame"] = "|cffeda55f拖放|r 移動框架"
L["|cffeda55fLeft Click|r to lock/unlock frame"] = "|cffeda55f左鍵|r to 鎖定/解鎖框架"
L["|cffeda55fRight Click|r to open the configuration window"] = "|cffeda55f右鍵|r 開啟設置視窗"
L["|cffeda55fShift + Left Click|r to ignore next action"] = "|cffeda55fShift + 左鍵|r 忽略下個動作"
L["Next action will be added to ignore list"] = "下個動作將被加入忽略名單"
L["Ready"] = "準備"
L["removed %s from ignore list"] = "%s 已從忽略名單中移除"

