-- This file is automagically generated.
-- Please visit http://www.wowace.com/projects/cooldown-to-go/localization/
-- if you wish to help with the translation.

local L = LibStub("AceLocale-3.0"):NewLocale("CooldownToGo", "deDE")
if not L then return end

L["added %s to ignore list"] = "%s der Ignorier-Liste hinzugefügt"
L["|cffeda55fControl + Left Click|r to lock frame"] = "|cffeda55fSTRG + Links-Klick,|r zum Sperren des Fensters"
L["|cffeda55fDrag|r to move the frame"] = "|cffeda55fZiehen,|r um das Fenster zu verschieben"
L["|cffeda55fLeft Click|r to lock/unlock frame"] = "|cffeda55fLlinks-Klick,|r zum Sperren/Entsperren des Fensters"
L["|cffeda55fRight Click|r to open the configuration window"] = "|cffeda55fRrechts-Klick,|r zum Öffnen des Konfigurationsfensters"
L["|cffeda55fShift + Left Click|r to ignore next action"] = "|cffeda55fUmschalt + Links-Klick,|r zum Ignorieren der nächsten Aktion"
L["Next action will be added to ignore list"] = "Nächste Aktion wird zur Ignorier-Liste hinzugefügt"
L["Ready"] = "Bereit"
L["removed %s from ignore list"] = "%s aus der Ignorier-Liste entfernt"

