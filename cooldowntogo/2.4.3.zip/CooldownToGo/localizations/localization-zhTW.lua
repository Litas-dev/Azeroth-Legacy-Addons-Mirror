local L = LibStub("AceLocale-3.0"):NewLocale("CooldownToGo", "zhTW", false)
if not L then return end
		
-- zhTW by lcncg

L["Locked"] = "鎖定"
L["Lock/Unlock display frame"] = "鎖定或解除鎖定顯示框"
-- L["Hold time"] = true
-- L["Time to hold the message in seconds"] = true
-- L["Fade time"] = true
-- L["Fade time of the message in seconds"] = true
-- L["Ready time"] = true
-- L["Show the cooldown again this many seconds before the cooldown expires"] = true
L["Font"] = "字體"
L["Default"] = "默認"
L["Font size"] = "字號"
L["Font outline"] = "字型"
L["None"] = "無"
L["Normal"] = "正常"
L["Thick"] = "加粗"
L["Color"] = "颜色"
L["%s loaded. Type /cdtg for help"] = "%s已加載。輸入 /cdtg 進行設置"
L["Strata"] = "層面"
L["Frame strata"] = "框架顯示層面"
L["High"] = "最高層"
L["Medium"] = "中間層"
L["Low"] = "最低層"
-- L["Configure"] = true
-- L["Bring up GUI configure dialog"] = true

