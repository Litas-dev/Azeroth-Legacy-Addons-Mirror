ZygorGuidesViewer.GuideMenuTier = 'CLA'
if ZGV:DoMutex('GoldFarmC') then
  return
end
