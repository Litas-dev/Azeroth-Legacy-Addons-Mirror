ZGV.Gold.guides_loaded = true
if ZGV:DoMutex('GoldGathC') then
  return
end
ZygorGuidesViewer.GuideMenuTier = 'CLA'
