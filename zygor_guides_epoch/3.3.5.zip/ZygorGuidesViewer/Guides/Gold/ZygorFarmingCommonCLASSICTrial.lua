ZygorGuidesViewer.GuideMenuTier = 'TRI'
if ZGV:DoMutex('GoldFarmC') then
  return
end
