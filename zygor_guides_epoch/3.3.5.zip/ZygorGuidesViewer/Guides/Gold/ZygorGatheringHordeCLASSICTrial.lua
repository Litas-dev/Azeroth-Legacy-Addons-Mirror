local ZygorGuidesViewer = ZygorGuidesViewer
if not ZygorGuidesViewer then
  return
end
if UnitFactionGroup('player') ~= 'Horde' then
  return
end
if ZGV:DoMutex('GoldGathH') then
  return
end
ZygorGuidesViewer.GuideMenuTier = 'TRI'
ZygorGuidesViewer:RegisterGuidePlaceholder('GOLD\\Gathering\\Silverleaf, Peacebloom')
ZygorGuidesViewer:RegisterGuidePlaceholder('GOLD\\Gathering\\Earthroot')
ZygorGuidesViewer:RegisterGuidePlaceholder('GOLD\\Gathering\\Mageroyal')
ZygorGuidesViewer:RegisterGuidePlaceholder('GOLD\\Gathering\\Stranglekelp')
ZygorGuidesViewer:RegisterGuidePlaceholder('GOLD\\Gathering\\Briarthorn, Swiftthistle')
ZygorGuidesViewer:RegisterGuidePlaceholder('GOLD\\Gathering\\Bruiseweed')
ZygorGuidesViewer:RegisterGuidePlaceholder('GOLD\\Gathering\\Wild Steelbloom')
ZygorGuidesViewer:RegisterGuidePlaceholder('GOLD\\Gathering\\Grave Moss')
ZygorGuidesViewer:RegisterGuidePlaceholder('GOLD\\Gathering\\Kingsblood')
ZygorGuidesViewer:RegisterGuidePlaceholder('GOLD\\Gathering\\Liferoot')
ZygorGuidesViewer:RegisterGuidePlaceholder('GOLD\\Gathering\\Fadeleaf')
ZygorGuidesViewer:RegisterGuidePlaceholder("GOLD\\Gathering\\Goldthorn, Khadgar's Whisker")
ZygorGuidesViewer:RegisterGuidePlaceholder('GOLD\\Gathering\\Wintersbite')
ZygorGuidesViewer:RegisterGuidePlaceholder('GOLD\\Gathering\\Wildvine')
ZygorGuidesViewer:RegisterGuidePlaceholder('GOLD\\Gathering\\Firebloom')
ZygorGuidesViewer:RegisterGuidePlaceholder('GOLD\\Gathering\\Purple Lotus')
ZygorGuidesViewer:RegisterGuidePlaceholder("GOLD\\Gathering\\Arthas' Tears")
ZygorGuidesViewer:RegisterGuidePlaceholder('GOLD\\Gathering\\Sungrass, Firebloom')
ZygorGuidesViewer:RegisterGuidePlaceholder('GOLD\\Gathering\\Blindweed, Fadeleaf')
ZygorGuidesViewer:RegisterGuidePlaceholder('GOLD\\Gathering\\Ghost Mushroom, Wildvine')
ZygorGuidesViewer:RegisterGuidePlaceholder('GOLD\\Gathering\\Gromsblood, Sungrass, Firebloom')
ZygorGuidesViewer:RegisterGuidePlaceholder('GOLD\\Gathering\\Golden Sansam, Dreamfoil')
ZygorGuidesViewer:RegisterGuidePlaceholder('GOLD\\Gathering\\Mountain Silversage')
ZygorGuidesViewer:RegisterGuidePlaceholder('GOLD\\Gathering\\Plaguebloom')
ZygorGuidesViewer:RegisterGuidePlaceholder('GOLD\\Gathering\\Icecap')
ZygorGuidesViewer:RegisterGuidePlaceholder('GOLD\\Gathering\\Black Lotus')
ZygorGuidesViewer:RegisterGuidePlaceholder('GOLD\\Gathering\\Copper Ore, Rough Stone')
ZygorGuidesViewer:RegisterGuidePlaceholder(
  'GOLD\\Gathering\\Silver Ore, Tin Ore, Coarse Stone, Moss Agate'
)
ZygorGuidesViewer:RegisterGuidePlaceholder('GOLD\\Gathering\\Iron Ore, Gold Ore, Heavy Stone')
ZygorGuidesViewer:RegisterGuidePlaceholder(
  'GOLD\\Gathering\\Mithril Ore, Truesilver Ore, Solid Stone'
)
ZygorGuidesViewer:RegisterGuidePlaceholder('GOLD\\Gathering\\Dark Iron Ore')
ZygorGuidesViewer:RegisterGuidePlaceholder('GOLD\\Gathering\\Thorium Ore, Dense Stone')
ZygorGuidesViewer:RegisterGuidePlaceholder('GOLD\\Gathering\\Guardian Stone')
ZygorGuidesViewer:RegisterGuidePlaceholder('GOLD\\Gathering\\Elementium Ore')
ZygorGuidesViewer:RegisterGuidePlaceholder('GOLD\\Gathering\\Strange Dust')
ZygorGuidesViewer:RegisterGuidePlaceholder('GOLD\\Gathering\\Lesser Magic Essence')
ZygorGuidesViewer:RegisterGuidePlaceholder('GOLD\\Gathering\\Greater Magic Essence')
ZygorGuidesViewer:RegisterGuidePlaceholder('GOLD\\Gathering\\Lesser Eternal Essence')
ZygorGuidesViewer:RegisterGuidePlaceholder('GOLD\\Gathering\\Greater Eternal Essence')
ZygorGuidesViewer:RegisterGuidePlaceholder('GOLD\\Gathering\\Small Brilliant Shard')
ZygorGuidesViewer:RegisterGuidePlaceholder('GOLD\\Gathering\\Large Brilliant Shard')
ZygorGuidesViewer:RegisterGuidePlaceholder('GOLD\\Gathering\\Illusion Dust')
ZygorGuidesViewer:RegisterGuidePlaceholder('GOLD\\Gathering\\Lesser Astral Essence')
ZygorGuidesViewer:RegisterGuidePlaceholder('GOLD\\Gathering\\Greater Astral Essence')
ZygorGuidesViewer:RegisterGuidePlaceholder('GOLD\\Gathering\\Soul Dust')
ZygorGuidesViewer:RegisterGuidePlaceholder('GOLD\\Gathering\\Lesser Mystic Essence')
ZygorGuidesViewer:RegisterGuidePlaceholder('GOLD\\Gathering\\Greater Mystic Essence')
ZygorGuidesViewer:RegisterGuidePlaceholder('GOLD\\Gathering\\Vision Dust')
ZygorGuidesViewer:RegisterGuidePlaceholder('GOLD\\Gathering\\Dream Dust')
ZygorGuidesViewer:RegisterGuidePlaceholder('GOLD\\Gathering\\Greater Nether Essence')
ZygorGuidesViewer:RegisterGuidePlaceholder('GOLD\\Gathering\\Lesser Nether Essence')
ZygorGuidesViewer:RegisterGuidePlaceholder(
  'GOLD\\Gathering\\Green Whelp Scale, Heavy Leather, Medium Leather'
)
ZygorGuidesViewer:RegisterGuidePlaceholder('GOLD\\Gathering\\Black Whelp Scale, Light Leather')
ZygorGuidesViewer:RegisterGuidePlaceholder('GOLD\\Gathering\\Light Leather, Ruined Leather Scraps')
ZygorGuidesViewer:RegisterGuidePlaceholder('GOLD\\Gathering\\Thin Kodo Leather')
ZygorGuidesViewer:RegisterGuidePlaceholder('GOLD\\Gathering\\Light Hide, Light Leather')
ZygorGuidesViewer:RegisterGuidePlaceholder('GOLD\\Gathering\\Slimy Murloc Scale')
ZygorGuidesViewer:RegisterGuidePlaceholder('GOLD\\Gathering\\Medium Leather, Heavy Leather')
ZygorGuidesViewer:RegisterGuidePlaceholder(
  'GOLD\\Gathering\\Medium Hide, Medium Leather, Light Leather'
)
ZygorGuidesViewer:RegisterGuidePlaceholder('GOLD\\Gathering\\Heavy Leather')
ZygorGuidesViewer:RegisterGuidePlaceholder('GOLD\\Gathering\\Raptor Hide')
ZygorGuidesViewer:RegisterGuidePlaceholder(
  'GOLD\\Gathering\\Heavy Hide, Heavy Leather, Thick Leather'
)
ZygorGuidesViewer:RegisterGuidePlaceholder(
  'GOLD\\Gathering\\Turtle Scale, Heavy Leather, Thick Leather'
)
ZygorGuidesViewer:RegisterGuidePlaceholder('GOLD\\Gathering\\Thick Murloc Scale')
ZygorGuidesViewer:RegisterGuidePlaceholder('GOLD\\Gathering\\Thick Hide, Thick Leather')
ZygorGuidesViewer:RegisterGuidePlaceholder(
  'GOLD\\Gathering\\Worn Dragonscale, Thick Leather, Heavy Leather'
)
ZygorGuidesViewer:RegisterGuidePlaceholder(
  'GOLD\\Gathering\\Scorpid Scale, Thick Leather, Heavy Leather'
)
ZygorGuidesViewer:RegisterGuidePlaceholder('GOLD\\Gathering\\Devilsaur Leather')
ZygorGuidesViewer:RegisterGuidePlaceholder('GOLD\\Gathering\\Rugged Leather')
ZygorGuidesViewer:RegisterGuidePlaceholder('GOLD\\Gathering\\Warbear Leather, Rugged Leather')
ZygorGuidesViewer:RegisterGuidePlaceholder(
  'GOLD\\Gathering\\Green Dragonscale, Thick Leather, Heavy Leather'
)
ZygorGuidesViewer:RegisterGuidePlaceholder(
  'GOLD\\Gathering\\Blue Dragonscale, Rugged Leather, Thick Leather'
)
ZygorGuidesViewer:RegisterGuidePlaceholder(
  'GOLD\\Gathering\\Rugged Hide, Rugged Leather, Thick Leather'
)
ZygorGuidesViewer:RegisterGuidePlaceholder('GOLD\\Gathering\\Black Dragonscale, Rugged Leather')
ZygorGuidesViewer:RegisterGuidePlaceholder('GOLD\\Gathering\\Heavy Scorpid Scale, Rugged Leather')
ZygorGuidesViewer:RegisterGuidePlaceholder('GOLD\\Gathering\\Core Leather')
ZygorGuidesViewer:RegisterGuidePlaceholder('GOLD\\Gathering\\Scale of Onyxia')
ZygorGuidesViewer:RegisterGuidePlaceholder('GOLD\\Gathering\\Red Dragonscale, Rugged Leather')
