assert(ZygorGuidesViewer, 'Zygor Guides Viewer failed to load.')
ZygorGuidesViewer.revision = tonumber(string.sub('$Revision: 1432 $', 12, -3))
ZygorGuidesViewer.version = '2.0.' .. ZygorGuidesViewer.revision
ZygorGuidesViewer.date = string.sub('$Date: 2010-10-21 08:39:31 -0500 (Thu, 21 Oct 2010) $', 8, 17)
--2010/10/15 18:11:46
