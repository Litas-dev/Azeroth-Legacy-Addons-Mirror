﻿--------------------------------------------------------------------------------------------------------
--                                             AceAddon init                                          --
--------------------------------------------------------------------------------------------------------
Broker_DurabilityInfo = LibStub("AceAddon-3.0"):NewAddon("Broker_DurabilityInfo", "AceConsole-3.0", "AceEvent-3.0")
local ldb = LibStub:GetLibrary("LibDataBroker-1.1")
local Crayon = LibStub:GetLibrary("LibCrayon-3.0")
local L = LibStub("AceLocale-3.0"):GetLocale("Broker_DurabilityInfo")
local AceConfig = LibStub("AceConfig-3.0")
local AceConfigDialog = LibStub("AceConfigDialog-3.0")
local AceDB = LibStub("AceDB-3.0")
local AceDBOptions = LibStub("AceDBOptions-3.0")

--------------------------------------------------------------------------------------------------------
--                          Broker_DurabilityInfo variables and defaults                              --
--------------------------------------------------------------------------------------------------------
local VALUE = 1
local MAX = 2
local COST = 3
local SLOT = 4
local NAME = 5
local ID = 6

local slotNames = {
	{ 0, 0, 0, "Head", L["Head"], 0 },
	{ 0, 0, 0, "Neck", L["Neck"], 0 },
	{ 0, 0, 0, "Shoulder", L["Shoulder"], 0 },
	{ 0, 0, 0, "Back", L["Back"], 0 },
	{ 0, 0, 0, "Chest", L["Chest"], 0 },
--	{ 0, 0, 0, "Shirt", L["Shirt"], 0 },
--	{ 0, 0, 0, "Tabard", L["Tabard"], 0 },
	{ 0, 0, 0, "Wrist", L["Wrist"], 0 },
	{ 0, 0, 0, "Hands", L["Hands"], 0 },
	{ 0, 0, 0, "Waist", L["Waist"], 0 },
	{ 0, 0, 0, "Legs", L["Legs"], 0 },
	{ 0, 0, 0, "Feet", L["Feet"], 0 },
--	{ 0, 0, 0, "Finger0", L["Finger0"], 0 },
--	{ 0, 0, 0, "Finger1", L["Finger1"], 0 },
--	{ 0, 0, 0, "Trinket0", L["Trinket0"], 0 },
--	{ 0, 0, 0, "Trinket1", L["Trinket1"], 0 },
	{ 0, 0, 0, "MainHand", L["MainHand"], 0 },
	{ 0, 0, 0, "SecondaryHand", L["SecondaryHand"], 0 },
	{ 0, 0, 0, "Ranged", L["Ranged"], 0 },
}
local bagCost = 0
local bagPercent = 0

local IN_COMBAT = 0
local OUT_OF_COMBAT = 1
local state = OUT_OF_COMBAT

local hiddenFrame = CreateFrame("GameTooltip")
hiddenFrame:SetOwner(WorldFrame, "ANCHOR_NONE")

local DATABASE_DEFAULTS = {
	profile = {
		showDetails = true,
		showBags = true,
		updateInCombat = true,
		autoRepair = false,
		repairFromGuild = false,
	},
}

--------------------------------------------------------------------------------------------------------
--                              Broker_DurabilityInfo options panel                                   --
--------------------------------------------------------------------------------------------------------
Broker_DurabilityInfo.options = {
	type = "group",
	name = "Broker DurabilityInfo",
	args = {
		general = {
			order = 1,
			type = "group",
			name = L["General Settings"],
			cmdInline = true,
			args = {
				details = {
					order = 1,
					type = "toggle",
					name = L["Show each item."],
					desc = L["Toggle to show detailed item durability."],
					get = function()
						return profileDB.showDetails
					end,
					set = function(key, value)
						profileDB.showDetails = value
					end,
				},
				bags = {
					order = 2,
					type = "toggle",
					name = L["Show bags."],
					desc = L["Toggle to show durability for items in bags."],
					get = function()
						return profileDB.showBags
					end,
					set = function(key, value)
						profileDB.showBags = value
					end,
				},
				combat = {
					order = 3,
					type = "toggle",
					name = L["Update in combat."],
					desc = L["Toggle to update while in combat. (could be CPU intensive)"],
					get = function()
						return profileDB.updateInCombat
					end,
					set = function(key, value)
						profileDB.updateInCombat = value
					end,
				},
				repair = {
					order = 4,
					type = "toggle",
					name = L["Auto repair."],
					desc = L["Toggle to repair when you visit a merchant."],
					get = function()
						return profileDB.autoRepair
					end,
					set = function(key, value)
						profileDB.autoRepair = value
					end,
				},
				repairGuild = {
					order = 5,
					type = "toggle",
					name = L["Use guild bank."],
					desc = L["Toggle to repair using guild bank."],
					get = function()
						return profileDB.repairFromGuild
					end,
					set = function(key, value)
						profileDB.repairFromGuild = value
					end,
				},
			},
		},
	},
}

function Broker_DurabilityInfo:SetupOptions()
	Broker_DurabilityInfo.options.args.profile = AceDBOptions:GetOptionsTable(self.db)
	Broker_DurabilityInfo.options.args.profile.order = -2

	AceConfig:RegisterOptionsTable("Broker_DurabilityInfo", Broker_DurabilityInfo.options, nil)
	
	self.optionsFrames = {}
	self.optionsFrames.general = AceConfigDialog:AddToBlizOptions("Broker_DurabilityInfo", nil, nil, "general")
	self.optionsFrames.profile = AceConfigDialog:AddToBlizOptions("Broker_DurabilityInfo", L["Profiles"], "Broker_DurabilityInfo", "profile")
end

--------------------------------------------------------------------------------------------------------
--                                    Broker_DurabilityInfo core                                      --
--------------------------------------------------------------------------------------------------------
function Broker_DurabilityInfo:OnInitialize()
	self.db = AceDB:New("Broker_DurabilityInfoDB", DATABASE_DEFAULTS, true)
	if not self.db then
		Print("Error: Database not loaded correctly.  Please exit out of WoW and delete Broker_DurabilityInfo.lua found in: \\World of Warcraft\\WTF\\Account\\<Account Name>>\\SavedVariables\\")
	end
	
	self.db.RegisterCallback(self, "OnProfileChanged", "OnProfileChanged")
	self.db.RegisterCallback(self, "OnProfileCopied", "OnProfileChanged")
	self.db.RegisterCallback(self, "OnProfileReset", "OnProfileChanged")
	
	profileDB = self.db.profile
	self:SetupOptions()
	
	local index,item
	for index,item in pairs(slotNames) do
		slotNames[index][ID] = GetInventorySlotInfo(item[SLOT].."Slot")
	end
	
	self:RegisterEvent("PLAYER_DEAD","MainUpdate")
	self:RegisterEvent("PLAYER_UNGHOST","MainUpdate")
	self:RegisterEvent("UPDATE_INVENTORY_DURABILITY","MainUpdate")
--	self:RegisterEvent("UPDATE_INVENTORY_ALERTS","MainUpdate")
--	self:RegisterEvent("UNIT_INVENTORY_CHANGED","MainUpdate")
--	self:RegisterEvent("EQUIPMENT_SWAP_FINISHED","MainUpdate")
	self:RegisterEvent("PLAYER_REGEN_ENABLED","OnRegenEnable")
	self:RegisterEvent("PLAYER_REGEN_DISABLED","OnRegenDisable")
	self:RegisterEvent("MERCHANT_SHOW","OnMerchantShow")
--	self:RegisterEvent("MERCHANT_CLOSED","MainUpdate")
	
	self:MainUpdate()
end

-- LDB object
Broker_DurabilityInfo.obj = ldb:NewDataObject("Broker_DurabilityInfo", {
	type = "data source",
	label = "Broker_DurabilityInfo",
	text = "",
	icon = "Interface\\Minimap\\Tracking\\Repair",
	OnClick = function(frame, msg)
		if msg == "RightButton" then
			Broker_DurabilityInfo:ShowConfig()
		end
		Broker_DurabilityInfo:MainUpdate()
	end,
	OnTooltipShow = function(tooltip)
		if not tooltip or not tooltip.AddLine then return end
		tooltip:AddLine("Broker_DurabilityInfo "..GetAddOnMetadata("Broker_DurabilityInfo", "Version"))

		local totalcost, percent, percentmin  = Broker_DurabilityInfo:GetRepairData()
		if totalcost <= 0 then
			tooltip:AddLine(" ")
			tooltip:AddLine(L["All items repaired!"],0,1,0)
		else
			if profileDB.showDetails then
				tooltip:AddLine(" ")
				for index,item in pairs(slotNames) do
					if item[MAX] > 0 and item[VALUE] < item[MAX] then
						local p = item[VALUE] / item[MAX]
						local r, g, b = Crayon:GetThresholdColor(p)
						tooltip:AddDoubleLine(string.format("%d%%  |cFFFFFF00%s|t", p * 100, item[NAME]), Broker_DurabilityInfo:CopperToString(math.floor(item[COST])), r, g, b, 1, 1, 1)
					end
				end
				if profileDB.showBags and (bagCost > 0) then
					local r, g, b = Crayon:GetThresholdColor(bagPercent)
					tooltip:AddDoubleLine(string.format("%d%%  |cFFFFFF00Bags|t", bagPercent * 100), Broker_DurabilityInfo:CopperToString(math.floor(bagCost)), r, g, b, 1, 1, 1)
				end
			end
			
			tooltip:AddLine(" ")
			local r, g, b = Crayon:GetThresholdColor(percent)
			tooltip:AddDoubleLine("|cFFFFFFFF"..L["Average"].." :", string.format("%d%%", percent * 100), 1, 1, 1, r, g, b)
			local r, g, b = Crayon:GetThresholdColor(percentmin)
			tooltip:AddDoubleLine("|cFFFFFFFF"..L["Lowest"].." :", string.format("%d%%", percentmin * 100), 1, 1, 1, r, g, b)

			tooltip:AddLine(" ")
			tooltip:AddLine("|cFFFFFFFF"..L["Cost for faction reputation:"])
			tooltip:AddDoubleLine("|cFFFFFF00".._G["FACTION_STANDING_LABEL4"], Broker_DurabilityInfo:CopperToString(math.floor(totalcost)))
			tooltip:AddDoubleLine("|cFFAAFF00".._G["FACTION_STANDING_LABEL5"], Broker_DurabilityInfo:CopperToString(math.floor(totalcost*0.95)))
			tooltip:AddDoubleLine("|cFF55FF00".._G["FACTION_STANDING_LABEL6"], Broker_DurabilityInfo:CopperToString(math.floor(totalcost*0.90)))
			tooltip:AddDoubleLine("|cFF00FF00".._G["FACTION_STANDING_LABEL7"], Broker_DurabilityInfo:CopperToString(math.floor(totalcost*0.85)))
			tooltip:AddDoubleLine("|cFF00FFAA".._G["FACTION_STANDING_LABEL8"], Broker_DurabilityInfo:CopperToString(math.floor(totalcost*0.80)))
		end

		tooltip:AddLine(" ")
		tooltip:AddLine(L["Right-hint"])
		end,
})

-- Main update function
function Broker_DurabilityInfo:MainUpdate()
	if (state == IN_COMBAT) and (not profileDB.updateInCombat) then
		return
	end
	
	local totalcost, percent, percentmin  = self:GetRepairData()
	
	if percentmin then
		self.obj.text = (string.format("|cff%s%d%%|r", Crayon:GetThresholdHexColor(percentmin), percentmin * 100))
	end
end

--------------------------------------------------------------------------------------------------------
--                               Broker_DurabilityInfo event handlers                                 --
--------------------------------------------------------------------------------------------------------
function Broker_DurabilityInfo:OnMerchantShow()
	if profileDB.autoRepair then
		if profileDB.repairFromGuild then
			self:AutoRepairFromBank()
		else
			self:AutoRepair()
		end
	end
	
	self:MainUpdate()
end

function Broker_DurabilityInfo:OnRegenEnable()
	state = OUT_OF_COMBAT
	self:MainUpdate()
end

function Broker_DurabilityInfo:OnRegenDisable()
	state = IN_COMBAT
end

--------------------------------------------------------------------------------------------------------
--                                   Broker_DurabilityInfo functions                                  --
--------------------------------------------------------------------------------------------------------

-- Called after profile changed
function Broker_DurabilityInfo:OnProfileChanged(event, database, newProfileKey)
	profileDB = database.profile
end

-- Open config window
function Broker_DurabilityInfo:ShowConfig()
	InterfaceOptionsFrame_OpenToCategory(self.optionsFrames.profile)
	InterfaceOptionsFrame_OpenToCategory(self.optionsFrames.general)
end

-- Show money with icons
function Broker_DurabilityInfo:CopperToString(c)
	local str = ""
	if not c or c < 0 then 
		return str 
	end
	
	if c >= 10000 then
		local g = math.floor(c/10000)
		c = c - g*10000
		str = str.."|cFFFFD800"..g.." |TInterface\\MoneyFrame\\UI-GoldIcon.blp:0:0:0:0|t"
	end
	if c >= 100 then
		local s = math.floor(c/100)
		c = c - s*100
		str = str.."|cFFC7C7C7"..s.." |TInterface\\MoneyFrame\\UI-SilverIcon.blp:0:0:0:0|t"
	end
	if c >= 0 then
		str = str.."|cFFEEA55F"..c.." |TInterface\\MoneyFrame\\UI-CopperIcon.blp:0:0:0:0|t"
	end
	
	return str
end

-- Update data structures
function Broker_DurabilityInfo:GetRepairData()
	local totalcost = 0
	local percent = 0
	local percentmin = 1
	
	local total = 0
	local current = 0
	local index,item
	
	for index,item in pairs(slotNames) do
		local val, max = GetInventoryItemDurability(slotNames[index][ID])
		local hasItem, hasCooldown, repairCost = hiddenFrame:SetInventoryItem("player", slotNames[index][ID])
		if max then
			total = total + max
			current = current + val
			totalcost = totalcost + repairCost
			slotNames[index][VALUE] = val
			slotNames[index][MAX] = max
			slotNames[index][COST] = repairCost
			percent = val/max
			if percent < percentmin then percentmin = percent end
		else
			slotNames [index][MAX] = 0
		end
	end
	
	local bagTotal, bagCurrent = 0, 0
	if profileDB.showBags then
		bagCost = 0;
		for bag = 0, 4 do
			local nrslots = GetContainerNumSlots(bag)
			for slot = 1, nrslots do
				local val, max = GetContainerItemDurability(bag, slot)
				local hasCooldown, repairCost = hiddenFrame:SetBagItem(bag, slot)
				if max then
					bagTotal = bagTotal + max
					bagCurrent = bagCurrent + val
					bagCost = bagCost + repairCost
					percent = val/max
					if percent < percentmin then percentmin = percent end
				end
			end
		end
		bagPercent = bagCurrent / bagTotal
		totalcost = totalcost + bagCost
	end
	
	current = current + bagCurrent
	total = total + bagTotal
	if total then
		percent = current/total
	end

	return totalcost, percent, percentmin
end

-- Auto repair using own money
function Broker_DurabilityInfo:AutoRepair()
	if CanMerchantRepair() == 1 then
		repairAllCost, canRepair = GetRepairAllCost()
		if repairAllCost > 0 then
			if canRepair == 1 then
				RepairAllItems()
				DEFAULT_CHAT_FRAME:AddMessage(L["Your items have been repaired for"].." "..Broker_DurabilityInfo:CopperToString(math.floor(repairAllCost)))
			else
				DEFAULT_CHAT_FRAME:AddMessage(L["You don't have enough money for repairs! You need"].." "..Broker_DurabilityInfo:CopperToString(math.floor(repairAllCost)))
			end
		end
	end
end

-- Auto repair using guild money
function Broker_DurabilityInfo:AutoRepairFromBank()
	if CanMerchantRepair() == 1 then
		repairAllCost, canRepair = GetRepairAllCost()
		if repairAllCost > 0 then
			if canRepair == 1 and CanGuildBankRepair() and GetGuildBankMoney() >= repairAllCost then
				RepairAllItems(1)
				DEFAULT_CHAT_FRAME:AddMessage(L["Your items have been repaired using guild bank for"].." "..Broker_DurabilityInfo:CopperToString(math.floor(repairAllCost)))
			else
				DEFAULT_CHAT_FRAME:AddMessage(L["Guild bank does not have enough money. Using yours."])
				Broker_DurabilityInfo.AutoRepair()
			end
		end
	end
end
