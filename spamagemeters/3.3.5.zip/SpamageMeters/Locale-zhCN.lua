local L = LibStub("AceLocale-3.0"):NewLocale("SpamageMeters", "zhCN")
if not L then return end

L["Capture Delay"] = [=[捕获延迟
设置选项]=]
L["Compress"] = "压缩"
L["Do Nothing"] = "挂起"
L["Enable Debug"] = "开启调试"
L["Enable the debug function"] = "开启调试功能"
L["Filter Custom Channels"] = "过滤自定义频道"
L["Filter Guild"] = "过滤公会频道"
L["Filter Officer"] = "过滤官员频道"
L["Filter Party"] = "过滤队伍频道"
L["Filter Raid"] = "过滤团队频道"
L["Filter Say"] = "过滤普通频道"
L["Filter Whisper"] = "过滤密语频道"
L["Filter Yell"] = "过滤叫喊频道"
L["How many seconds the addon waits after 'Recount - *' lines before it assumes spam burst is over. 1 seems to work in most cases"] = "多少秒后显示\"Recount- *\"的消息假定垃圾消息发送完毕。默认1秒"
L["Reported by %s"] = "报告 %s"
L["Selects the action to perform when encountering damage meter data in custom channels"] = "当自定义频道出现伤害输出报告选择执行动作"
L["Selects the action to perform when encountering damage meter data in guild chat"] = "当公会频道出现伤害输出报告选择执行动作"
L["Selects the action to perform when encountering damage meter data in officer chat"] = "当官员频道出现伤害输出报告选择执行动作"
L["Selects the action to perform when encountering damage meter data in party chat"] = "当队伍频道出现伤害输出报告选择执行动作"
L["Selects the action to perform when encountering damage meter data in raid chat"] = "当团队频道出现伤害输出报告选择执行动作"
L["Selects the action to perform when encountering damage meter data in say chat"] = "当普通频道出现伤害输出报告选择执行动作"
L["Selects the action to perform when encountering damage meter data in yell chat"] = "当叫喊频道出现伤害输出报告选择执行动作"
L["Selects the action to perform when encountering damage meter whisper"] = "当密语频道出现伤害输出报告选择执行动作"
L["Suppress"] = "阻止"
