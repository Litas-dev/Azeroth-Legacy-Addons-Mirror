﻿--[[---------------------------------------------------------------------------

Copyright (c) 2008 by K. Scott Piel 
All Rights Reserved

E-mail: < kscottpiel@gmail.com >
Web:    < http://www.scottpiel.com >

Translation (French) by...

Khisanth - (EU) Suramar
khisanth.wow@gmail.com

-and-

Copyright (c) 2008 by David ANGELELLI
All Rights Reserved
E-mail: < snesman@pc-dream.net >

Realm: 	Krasus (PvE) [French]
Name:	Tullia (Nightelf Rogue)

This file is part of nUI.

    nUI is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    nUI is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with nUI.  If not, see <http://www.gnu.org/licenses/>.
	
THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR 
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE 
USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

--]]---------------------------------------------------------------------------

if nUI_Locale == "frFR" then
		
	nUI_L["font1"] = "Fonts\\ARIALN.TTF";
	nUI_L["font2"] = "Fonts\\FRIZQT__.TTF";
	
	nUI_L["Welcome back to %s, %s..."] = "Bienvenue à %s, %s...";
	nUI_L["nUI version %s is loaded!"] = "nUI version %s est chargée!";
	nUI_L["Type '/nui' for a list of available nUI commands."] = "Taper '/nui' pour la liste des commandes disponibles.";
	
	-- clock strings
	
	nUI_L["am"] = "am";
	nUI_L["pm"] = "pm";
	nUI_L["(S) <hour>:<minute><suffix> - <hour>:<minute><suffix> (L)"] = "(S) %d:%02d%s - %d:%02d%s (L)";
	nUI_L["(S) <hour>:<minute> - <hour>:<minute> (L)"] = "(S) %02d:%02d - %02d:%02d (L)";
	
	-- state strings
	
	nUI_L["|cFF00FF00ENABLED|r"]  = "|cFF00FF00ACTIVE(E)|r";
	nUI_L["|cFFFF0000DISABLED|r"] = "|cFFFF0000DESACTIVE(E)|r";
	nUI_L["~INTERRUPTED~"]        = "~INTERROMPUE~";
	nUI_L["~FAILED~"]             = "~ECHOUE~";
	nUI_L["~MISSED~"]             = "~RATE~";
	nUI_L["OFFLINE"]              = "HORS LIGNE";
	nUI_L["DND"]                  = "NPD";
	nUI_L["AFK"]                  = "AFK";
	nUI_L["DEAD"]                 = "MORT";
	nUI_L["GHOST"]                = "FANTOME";
	nUI_L["FD"]                   = "FM";
	nUI_L["TAXI"]                 = "TAXI";
	
	-- time remaining (cooldowns, buffs, etc.)
	
	nUI_L["TimeLeftInHours"]   = "%0.0fh";
	nUI_L["TimeLeftInMinutes"] = "%0.0fm";
	nUI_L["TimeLeftInSeconds"] = "%0.0fs";
	nUI_L["TimeLeftInTenths"]  = "%0.1fs";
	
	-- raid and party role tooltip strings
	
	nUI_L["Party Role: |cFF00FFFF%s|r"] = "Fonction groupe: |cFF00FFFF%s|r";
	nUI_L["Raid Role: |cFF00FFFF%s|r"]  = "Fonction raid: |cFF00FFFF%s|r";
	nUI_L["Raid Leader"]                = "Chef de raid";
	nUI_L["Party Leader"]               = "Chef du groupe";
	nUI_L["Raid Assistant"]             = "Assistant Raid";
	nUI_L["Main Tank"]                  = "Tank principal";
	nUI_L["Off-Tank"]                   = "Tank secondaire";
	nUI_L["Master Looter"]              = "Chef du butin";
	
	-- hunter pet feeder strings
	
	nUI_L[nUI_FOOD_MEAT]	= "viande";
	nUI_L[nUI_FOOD_FISH]	= "poisson";
	nUI_L[nUI_FOOD_BREAD]	= "pain";
	nUI_L[nUI_FOOD_CHEESE]  = "fromage";
	nUI_L[nUI_FOOD_FRUIT]	= "fruit"; 
	nUI_L[nUI_FOOD_FUNGUS]  = "champignon";
	
	nUI_L["Click to feed %s"]           = "Cliquez pour nourrir %s"; 
	nUI_L["Click to cancel feeding"]    = "Cliquez pour annuler nourrir"; 
	nUI_L["nUI: %s can eat %s%s%s"]     = "nUI: %s peut manger %s%s%s";
	nUI_L[" or "]                       = " ou ";
	nUI_L["nUI: You don't have a pet!"] = "nUI: Vous n'avez pas de familier!";
	
	nUI_L["nUI: You can feed %s the following...\n"] = "nUI: Vous pouvez nourrir %s avec ce qui suit...\n";
	nUI_L["nUI: You have nothing you can feed %s in your current inventory"] = "nUI: Vous n'avez rien pour nourrir %s dans votre inventaire";
	nUI_L["    Click the pet happiness indictor to feed your pet now"] = "    Cliquez sur l'indicateur d'humeur de votre familier pour le nourrir maintenant";
		
	-- status bar strings
	
	nUI_L["nUI: Cannot change status bar config while in combat!"] = "nUI: Impossible de changer la configuration de la barre de status pendant le combat!";
	nUI_L["nUI: [%s] is not a valid option for orienting a status bar... use LEFT, RIGHT, TOP or BOTTOM"] = "nUI: [%s] n'est pas une option valide pour l'orientation d'une barre de status... utilisez LEFT, RIGHT, TOP or BOTTOM";
	nUI_L["nUI: Can not change status bar overlays while in combat!"] = "nUI: Impossible de changer le recouvrement de la barre de status durant un combat!";
	nUI_L["nUI: The maximum value (%d) of a status bar must be greater than the minimum value (%d)"] = "nUI: La valeur maximale (%d) d'une barre de status doit être plus grande que la valeur minimale (%d)";
	
	-- information panel strings
	
	nUI_L["Minimap"] = "Minicarte";
	
	nUI_L[nUI_INFOPANEL_MINIMAP]   		   		= "Panneau info: Affichage minicarte";
	nUI_L[nUI_INFOPANEL_MINIMAP.."Label"]		= "Minicarte";
	
	nUI_L[nUI_INFOPANEL_COMBATLOG]      		= "Panneau info: Affichage Journal de combat";
	nUI_L[nUI_INFOPANEL_COMBATLOG.."Label"]		= "Combat";
	
	nUI_L[nUI_INFOPANEL_BMM]		      		= "Panneau info: Affichage Minicarte du champs de bataille ";
	nUI_L[nUI_INFOPANEL_BMM.."Label"]			= "Carte";
	
	nUI_L[nUI_INFOPANEL_RECOUNT]		   		= "Panneau info: Affichage Recount";
	nUI_L[nUI_INFOPANEL_RECOUNT.."Label"]		= "Recount";
	
	nUI_L[nUI_INFOPANEL_OMEN2]		      		= "Panneau info: Affichage Omen2";
	nUI_L[nUI_INFOPANEL_OMEN2.."Label"]			= "Omen2";
	
	nUI_L[nUI_INFOPANEL_OMEN2KLH]	      		= "Panneau info: Affichage combiné Omen2 + KLH Threat Meter";
	nUI_L[nUI_INFOPANEL_OMEN2KLH.."Label"]		= "Menace";
	
	nUI_L[nUI_INFOPANEL_OMEN2RECOUNT]		   	= "Panneau info:  Affichage Omen2 + Recount";
	nUI_L[nUI_INFOPANEL_OMEN2RECOUNT.."Label"]	= "Omen2+";
	
	nUI_L[nUI_INFOPANEL_KLH]		      		= "Panneau info: KLH Threat Meter";
	nUI_L[nUI_INFOPANEL_KLH.."Label"]			= "KTM";
	
	nUI_L[nUI_INFOPANEL_KLHRECOUNT]	      		= "Panneau info: KLH Threat + Recount";
	nUI_L[nUI_INFOPANEL_KLHRECOUNT.."Label"]	= "KTM+";
	
	nUI_L["nUI: You need to go to the WoW Interface menu, select the 'Social' option and turn off the 'Simple Chat' menu option to enable integrated combat log support in nUI."] = "nUI: Vous devez utiliser le menu Interface de WoW, Choisir l'option 'Social' et désactiver l'option de menu 'Chat Simple' pour activer le support du journal de combat intégré à nUI.";
	nUI_L["The %s Info Panel plugin is a core plugin to nUI and cannot be disabled"] = "Le plugin du panneau d'info %s est un plugin noyau de nUI et ne peut pas être désactivé";
	nUI_L["Click to change information panels"] = "Cliquez pour change de panneau d'information";
	nUI_L["nUI: Cannot initialize the Info Panel plugin [ %s ] -- it does not have an initPanel() interface method"] = "nUI: Impossible d'initialiser  le plugin du Panneau d'information [ |cFF00FFFF%s|r ] -- il n'a pas de méthode d'interface initPanel()";
	nUI_L["nUI: Cannot initialize the Info Panel plugin [ %s ] -- No global object by that name exists"] = "nUI: Impossible d'initialiser  le plugin du Panneau d'information [ |cFF00FFFF%s|r ] -- Pas d'objet global de ce nom existant";	
	nUI_L["nUI: Cannot select the Info Panel plugin [ %s ] -- it does not have a setSelected() interface method"] = "nUI: Impossible de choisir le plugin du Panneau d'information [ |cFF00FFFF%s|r ] -- il n'a pas de méthode d'interface setSelected()";
	
	-- HUD layout strings (heads up display)
	
	nUI_L["Click to change HUD layouts"] = "Cliquez pour changer la disposition du HUD";
	
	nUI_L[nUI_HUDLAYOUT_PLAYERTARGET]	   		= "Disposition HUD: Joueur à gauche / Cible à droite";
	nUI_L[nUI_HUDLAYOUT_PLAYERTARGET.."Label"]	= "Joueur/Cible";
	
	nUI_L[nUI_HUDLAYOUT_HEALTHPOWER]	   		= "Disposition HUD: Vie à gauche / Capacité à droite";
	nUI_L[nUI_HUDLAYOUT_HEALTHPOWER.."Label"]	= "Vie/Capacité";
	
	nUI_L[nUI_HUDLAYOUT_SIDEBYSIDE]	   			= "Disposition HUD: Barres horizontales côtes à côtes";
	nUI_L[nUI_HUDLAYOUT_SIDEBYSIDE.."Label"]	= "Côte à côte";
	
	nUI_L[nUI_HUDLAYOUT_NOBARS]	   				= "Disposition HUD: HUD Simple (pas de barres)";
	nUI_L[nUI_HUDLAYOUT_NOBARS.."Label"]		= "HUD Simple";
	
	nUI_L[nUI_HUDLAYOUT_NOHUD]		   			= "Disposition HUD:: Désactivé (pas de HUD)";
	nUI_L[nUI_HUDLAYOUT_NOHUD.."Label"]			= "Pas de HUD";
	
	nUI_L[nUI_HUDMODE_PLAYERTARGET]        = "nUI Mode HUD Joueur/Cible";
	nUI_L[nUI_HUDSKIN_PLAYERTARGET_PET]    = nUI_L[nUI_HUDMODE_PLAYERTARGET]..": skin d'affichage des données du familier du joueur";
	nUI_L[nUI_HUDSKIN_PLAYERTARGET_PLAYER] = nUI_L[nUI_HUDMODE_PLAYERTARGET]..": skin d'affichage des données du joueur";
	nUI_L[nUI_HUDSKIN_PLAYERTARGET_TARGET] = nUI_L[nUI_HUDMODE_PLAYERTARGET]..": skin d'affichage des données de la cible";
	nUI_L[nUI_HUDSKIN_PLAYERTARGET_TOT]    = nUI_L[nUI_HUDMODE_PLAYERTARGET]..": skin d'affichage des données de la cible de la cible (CdC)";
	
	nUI_L[nUI_HUDMODE_HEALTHPOWER]         = "nUI Mode HUD Vie/Capacité";
	nUI_L[nUI_HUDSKIN_HEALTHPOWER_PET]     = nUI_L[nUI_HUDMODE_HEALTHPOWER]..": skin d'affichage des données du familier du joueur";
	nUI_L[nUI_HUDSKIN_HEALTHPOWER_PLAYER]  = nUI_L[nUI_HUDMODE_HEALTHPOWER]..": skin d'affichage des données du joueur";
	nUI_L[nUI_HUDSKIN_HEALTHPOWER_TARGET]  = nUI_L[nUI_HUDMODE_HEALTHPOWER]..": skin d'affichage des données de la cible";
	nUI_L[nUI_HUDSKIN_HEALTHPOWER_TOT]     = nUI_L[nUI_HUDMODE_HEALTHPOWER]..": skin d'affichage des données de la cible de la cible (CdC)";
	
	nUI_L[nUI_HUDMODE_SIDEBYSIDE]          = "nUI Mode HUD Côte à côte";
	nUI_L[nUI_HUDSKIN_SIDEBYSIDE_PET]      = nUI_L[nUI_HUDMODE_SIDEBYSIDE]..": skin d'affichage des données du familier du joueur";
	nUI_L[nUI_HUDSKIN_SIDEBYSIDE_PLAYER]   = nUI_L[nUI_HUDMODE_SIDEBYSIDE]..": skin d'affichage des données du joueur";
	nUI_L[nUI_HUDSKIN_SIDEBYSIDE_TARGET]   = nUI_L[nUI_HUDMODE_SIDEBYSIDE]..": skin d'affichage des données de la cible";
	nUI_L[nUI_HUDSKIN_SIDEBYSIDE_TOT]      = nUI_L[nUI_HUDMODE_SIDEBYSIDE]..": skin d'affichage des données de la cible de la cible (CdC)";
	
	-- nUI_Unit strings
	
	nUI_L["Pet"]    = "Fam.";
	nUI_L["Target"] = "Cible";
	
	nUI_L["Range: %d-%d"]             = "Portée: %d-%d";
	
	nUI_L["unit: player"]             = "Joueur";
	nUI_L["unit: pet"]		          = "Familier du joueur";
	nUI_L["unit: pettarget"]          = "Cible du familier du joueur";
	nUI_L["unit: focus"]              = "Focus du joueur";
	nUI_L["unit: focustarget"]        = "Cible du focus du joueur";
	nUI_L["unit: target"]             = "Cible du joueur";
	nUI_L["unit: %s-target"]          = "Cible de %s";
	nUI_L["unit: mouseover"]          = "Suvol souris de la Cible";
	nUI_L["unit: targettarget"]       = "Cible de la cible (CdC)";
	nUI_L["unit: targettargettarget"] = "Cible de CdC (CCdC)";
	nUI_L["unit: party%d"]            = "Membre du Groupe %d";
	nUI_L["unit: party%dpet"]         = "Familier du Membre du Groupe %d";
	nUI_L["unit: party%dtarget"]      = "Cible du Membre du Groupe %d";
	nUI_L["unit: party%dpettarget"]   = "Cible du Familier du Membre du Groupe %d";
	nUI_L["unit: raid%d"]             = "Membre du Raid %d";
	nUI_L["unit: raid%dpet"]          = "Familier du Membre du Raid %d";
	nUI_L["unit: raid%dtarget"]       = "Cible du Membre du Raid %d";
	nUI_L["unit: raid%dpettarget"]    = "Cible du Familier du Membre du Raid %d";

	nUI_L[nUI_UNITMODE_PLAYER]        = "nUI Mode joueur solo";
	nUI_L[nUI_UNITSKIN_PARTYFOCUS]    = nUI_L[nUI_UNITMODE_PLAYER]..": Skin de la fenêtre focus du joueur";
	nUI_L[nUI_UNITSKIN_PARTYMOUSE]    = nUI_L[nUI_UNITMODE_PLAYER]..": Skin de la fenêtre du survol souris sur cible";
	nUI_L[nUI_UNITSKIN_SOLOPET]       = nUI_L[nUI_UNITMODE_PLAYER]..": Skin de la fenêtre du familier du joueur";
	nUI_L[nUI_UNITSKIN_SOLOPETBUTTON] = nUI_L[nUI_UNITMODE_PLAYER]..": Skin du bouton de la cible du familier... i.e. Cible du familier, Focus du familier du joueur, etc";
	nUI_L[nUI_UNITSKIN_SOLOPLAYER]    = nUI_L[nUI_UNITMODE_PLAYER]..": Skin de la fenêtre du joueur";
	nUI_L[nUI_UNITSKIN_SOLOTARGET]    = nUI_L[nUI_UNITMODE_PLAYER]..": Skin de la fenêtre de la cible";
	nUI_L[nUI_UNITSKIN_SOLOTGTBUTTON] = nUI_L[nUI_UNITMODE_PLAYER]..": Skin du boutton cible de la fenêtre de la cible... i.e. Cible du focus du joueur, etc.";
	nUI_L[nUI_UNITSKIN_SOLOTOT]       = nUI_L[nUI_UNITMODE_PLAYER]..": Skin de la fenêtre de la Cible de la Cible (CdC)";

	nUI_L[nUI_UNITMODE_PARTY]          = "nUI Mode Groupe";
	nUI_L[nUI_UNITSKIN_PARTYFOCUS]     = nUI_L[nUI_UNITMODE_PARTY]..": Skin de la fenêtre du focus du joueur";
	nUI_L[nUI_UNITSKIN_PARTYMOUSE]     = nUI_L[nUI_UNITMODE_PARTY]..": Skin de la fenêtre du survol souris sur cible";
	nUI_L[nUI_UNITSKIN_PARTYPLAYER]    = nUI_L[nUI_UNITMODE_PARTY]..": Skin de la fenêtre du joueur";
	nUI_L[nUI_UNITSKIN_PARTYPET]       = nUI_L[nUI_UNITMODE_PARTY]..": Skin de la fenêtre du familier du joueu";
	nUI_L[nUI_UNITSKIN_PARTYTARGET]    = nUI_L[nUI_UNITMODE_PARTY]..": Skin de la fenêtre de la cible";
	nUI_L[nUI_UNITSKIN_PARTYTOT]       = nUI_L[nUI_UNITMODE_PARTY]..": Skin de la fenêtre de la Cible de la Cible (CdC)";
	nUI_L[nUI_UNITSKIN_PARTYFOCUS]     = nUI_L[nUI_UNITMODE_PARTY]..": Skin de la fenêtre du focus du joueur";
	nUI_L[nUI_UNITSKIN_PARTYLEFT]      = nUI_L[nUI_UNITMODE_PARTY]..": Skin de la partie gauche des membres du groupe";
	nUI_L[nUI_UNITSKIN_PARTYRIGHT]     = nUI_L[nUI_UNITMODE_PARTY]..": Skin de la partie droite des membres du groupe";
	nUI_L[nUI_UNITSKIN_PARTYPETBUTTON] = nUI_L[nUI_UNITMODE_PARTY]..": Skin des boutons cible des familiers du groupe";
	nUI_L[nUI_UNITSKIN_PARTYTGTBUTTON] = nUI_L[nUI_UNITMODE_PARTY]..": Skin du boutton cible des membres du groupe";
	nUI_L[nUI_UNITSKIN_PARTYMOUSE]     = nUI_L[nUI_UNITMODE_PARTY]..": Skin de la fenêtre survol souris";
	
	nUI_L[nUI_UNITMODE_RAID10]          ="nUI 10 Player Raid Mode";
	nUI_L[nUI_UNITSKIN_RAID10FOCUS]     = nUI_L[nUI_UNITMODE_RAID10]..": Skin de la fenêtre du focus du joueur";
	nUI_L[nUI_UNITSKIN_RAID10MOUSE]     = nUI_L[nUI_UNITMODE_RAID10]..": Skin de la fenêtre du survol souris sur cible";
	nUI_L[nUI_UNITSKIN_RAID10PLAYER]    = nUI_L[nUI_UNITMODE_RAID10]..": Skin de la fenêtre du joueur";
	nUI_L[nUI_UNITSKIN_RAID10PET]       = nUI_L[nUI_UNITMODE_RAID10]..": Skin de la fenêtre du familier du joueu";
	nUI_L[nUI_UNITSKIN_RAID10TARGET]    = nUI_L[nUI_UNITMODE_RAID10]..": Skin de la fenêtre de la cible";
	nUI_L[nUI_UNITSKIN_RAID10TOT]       = nUI_L[nUI_UNITMODE_RAID10]..": Skin de la fenêtre de la Cible de la Cible (CdC)";
	nUI_L[nUI_UNITSKIN_RAID10FOCUS]     = nUI_L[nUI_UNITMODE_RAID10]..": Skin de la fenêtre du focus du joueur";
	nUI_L[nUI_UNITSKIN_RAID10LEFT]      = nUI_L[nUI_UNITMODE_RAID10]..": Skin de la partie gauche des membres du raid";
	nUI_L[nUI_UNITSKIN_RAID10RIGHT]     = nUI_L[nUI_UNITMODE_RAID10]..": Skin de la partie droite des membres du groupe";
	nUI_L[nUI_UNITSKIN_RAID10PETBUTTON] = nUI_L[nUI_UNITMODE_RAID10]..": Skin des boutons cible des familiers du raid";
	nUI_L[nUI_UNITSKIN_RAID10TGTBUTTON] = nUI_L[nUI_UNITMODE_RAID10]..": Skin du boutton cible des membres du raid";
	nUI_L[nUI_UNITSKIN_RAID10MOUSE]     = nUI_L[nUI_UNITMODE_RAID10]..": Skin de la fenêtre survol souris";
	
	nUI_L[nUI_UNITPANEL_PLAYER]      		= "Panneau d'fenêtre : Mode Joueur Solo";
	nUI_L[nUI_UNITPANEL_PLAYER.."Label"]	= "Joueur";
	
	nUI_L[nUI_UNITPANEL_PARTY]       		= "Panneau d'fenêtre: Mode Groupe";
	nUI_L[nUI_UNITPANEL_PARTY.."Label"] 	= "Groupe";
	
	nUI_L[nUI_UNITPANEL_RAID10]      		= "Panneau d'fenêtre: Mode Raid 10 Joueurs";
	nUI_L[nUI_UNITPANEL_RAID10.."Label"]	= "Raid 10";
	
	nUI_L[nUI_UNITPANEL_RAID15]      		= "Panneau d'fenêtre: Mode Raid 15 Joueurs";
	nUI_L[nUI_UNITPANEL_RAID15.."Label"]	= "Raid 15";
	
	nUI_L[nUI_UNITPANEL_RAID20]      		= "Panneau d'fenêtre: Mode Raid 20 Joueurs";
	nUI_L[nUI_UNITPANEL_RAID20.."Label"]	= "Raid 20";
	
	nUI_L[nUI_UNITPANEL_RAID25]      		= "Panneau d'fenêtre: Mode Raid 25 Joueurs";
	nUI_L[nUI_UNITPANEL_RAID25.."Label"]	= "Raid 25";
	
	nUI_L[nUI_UNITPANEL_RAID40]      		= "Panneau d'fenêtre: Mode Raid 40 Joueurs";
	nUI_L[nUI_UNITPANEL_RAID40.."Label"]	= "Raid 40";
	
	nUI_L["Click to change unit frame panels"] = "Cliquez pour changer le panneau d'unité";
	
	nUI_L["<unnamed frame>"] = "<frame sans nom>";
	nUI_L["unit change"] = "changement d'unité";
	nUI_L["unit class"] = "classe de l'unité";
	nUI_L["pet happiness"] = "joie du familier";
	nUI_L["unit label"] = "label de l'unité";
	nUI_L["unit level"] = "niveau de l'untié";
	nUI_L["unit reaction"] = "reaction de l'unité";
	nUI_L["unit health"] = "vie de l'unité";
	nUI_L["unit power"] = "puissancede l'unité";
	nUI_L["unit portrait"] = "portrait de l'unité";
	nUI_L["raid group"] = "groupe de raid";
	nUI_L["unit PvP"] = "fenêtre PvP";
	nUI_L["raid target"] = "cible raid";
	nUI_L["casting bar"] = "barre de sort";
	nUI_L["ready check"] = "ready check";
	nUI_L["unit status"] = "status unité";
	nUI_L["unit aura"] = "aura de l'unité";
	nUI_L["unit combat"] = "combat de l'unité";
	nUI_L["unit resting"] = "repot de l'unité";
	nUI_L["unit role"] = "rôle de l'unité";
	nUI_L["unit feedback"] = "retour de l'unité";
	
	nUI_L["passed unit id is <nil> in callback table for %s"] = "L'unité adoptée est <nil> dans la table de callback pour %s"; 
	nUI_L["nUI: Warning.. anchoring %s to %s -- anchor point has a <nil> value."] = "nUI: Attention.. Ancrage de %s à %s -- le point d'ancrage a la valeur <nil>.";
	nUI_L["nUI: Cannot register %s for scaling... frame does not have an applyScale() method"] = "nUI: Impossible d'enregistrer %s for redimensionnement... la frame n'a pas de méthode applyScale().";
	nUI_L["nUI: Cannot register %s for scaling... frame does not have an applyAnchor() method"] = "nUI: Impossible d'enregistrer %s for redimensionnement... la frame n'a pas de métohde applyAnchor().";
	nUI_L["nUI: %s %s callback %s does not have a newUnitInfo() method."] = "nUI: %s %s callback %s n'a pas de méthode newUnitInfo().";
	nUI_L["nUI_UnitClass.lua: unhandled unit class [%s] for [%s]"] = "nUI_UnitClass.lua: fenêtre de classe [%s] non gérée pour [%s]";
	nUI_L["nUI: click-casting registration is %s"] = "nUI: l'enreigstrement du click-casting registration sur %s";
	nUI_L["nUI: must pass a valid parent frame to nUI_Unit:createFrame() for unit id [%s (%s)]"] = "nUI: Nom de fenêtre parent valide requis par nUI_Unit:createFrame() pour l'fenêtre ID [%s (%s)]";
	nUI_L["nUI says: Gratz for reaching level %d %s!"] = "nUI dit: Félicitation pour avoir atteint le niveau %d %s!";
	nUI_L["nUI_Unit: [%s] is not a valid unit frame element type!"] = "nUI_Unit: [%s] n'est pas une un type d'élément de fenêtre valide !";
	nUI_L["nUI_Unit: [%s] is not a known unit skin name!"] = "nUI_Unit: [%s] n'est pas un nom d'habillage connu!";
	
	-- nUI_Unit hunter pet strings
	
	nUI_L["Your pet"] = "Votre familier";
	nUI_L["quickly"] = "rapidement";
	nUI_L["slowly"] = "lentement";
	nUI_L["nUI: %s is happy."] = "nUI: %s est content.";
	nUI_L["nUI: %s is unhappy... time to feed!"] = "nUI: %s est mécontent... il est temps de le nourrir!";
	nUI_L["nUI: Warning! %s is |cFFFFFFFFNOT|r happy! Better feed soon."] = "nUI: Attntion! %s n'est |cFFFFFFFFPAS|r heureux! Vous devriez le nourrir rapidement.";
	nUI_L["nUI: Warning... %s is %s losing loyalty "] = "nUI: Attention... %s perd % en loyauté";
	nUI_L["nUI: %s is %s gaining loyalty"] = "nUI: %s gagne %s en loyauté";
	nUI_L["nUI: %s has stopped gaining loyalty"] = "nUI: %s a cessé de gagné en loyauté";
	nUI_L["nUI: %s has stopped losing loyalty"] = "nUI: %s a cessé de perdre en loyauté";
	nUI_L["nUI_UnitHappiness.lua: unhandled pet happiness value (%s)"] = "nUI_UnitHappiness.lua: Valeur de bonheur du familier non gérée (%s)";
	nUI_L["Your pet's current damage bonus is %d%%"] = "Le bonus aux dommages actuel de votre familier est de %+d%%"; 
	nUI_L["Your pet's current damage penalty is %d%%"] = "La pénalité aux dommages actuelle de votre familier est de %+d%%"; 
	nUI_L["nUI: It looks to me like you're a little busy... maybe you should try feeding %s AFTER you leave combat?"] = "nUI: Il me semble que vous êtes un peu occupé... vous devriez peut-être essayer de nourrir %s APRES avoir quitté le combat ?"; 
	nUI_L["nUI: I looked everywhere, but I couldn't find a pet to feed. Perhaps he's in your backpack?"] = "nUI: J'ai regardé par tout, mais je n'ai pu trouver de familier à nourrir. Peut-être est-il dans votre sac à dos?"; 
	nUI_L["nUI: You know, I could be wrong, but I don't think feeding %s is a very good idea... it doesn't look to me like what you have in your bags is what %s is thinking about eating."] = "nUI: Vous savez, je peux me tromper, mais je ne pense pas que nourrir %s soit une très bonne idée... il ne me semble pas que ce que vous avez dans votre sac soit ce dont %s est envie de manger."; 

	-- miscelaneous strings
	
	nUI_L["Version"]             = "nUI Version |cFF00FF00%s|r";
	nUI_L["Copyright"]           = "Copyright (C) 2008 by K. Scott Piel";
	nUI_L["Rights"]              = "Tous droits réservés";
	nUI_L["Off Hand Weapon:"]  = "Arme main secondaire:";
	nUI_L["Main Hand Weapon:"] = "Arme main principale:";
	nUI_L["Group %d"] = "Groupe %d";
	nUI_L["MS"]                  = "MS";
	nUI_L["FPS"]				 = "IPS";
	nUI_L["Minimap Button Bag"]  = "Sac des boutons de la Minicarte";
	
	-- health race bar tooltip strings
	
	nUI_L["nUI Health Race Stats..."] = "nUI Stats Course de Vie...";
	nUI_L["No current advantage to <player> or <target>"] = "Aucun avantage actuellement pour %s ou %s";
	nUI_L["<unit name>'s Health: <current>/<maximum> (<percent>)"] = "Vie de %s: |cFF00FF00%d/%d|r (|cFFFFFFFF%0.1f%%|r)";
	nUI_L["Advantage to <player>: <pct>"] = "Avantage à %s: (|cFF00FF00%+0.1f%%|r)";
	nUI_L["Advantage to <target>: <pct>"] = "Avantage à %s: (|cFFFFC0C0%0.1f%%|r)";
	
	-- skinning system messages
	
	nUI_L["nUI could not load the currently selected skin [ %s ]... perhaps you have it disabled? Switching to the default nUI skin."] = "nUI ne peut pas charger la skin couramment sélectionnée [ |cFFFFC0C0%s|r ]... peut-être l'avez-vous désactivée ? Remplacement par la skin par défaut."; 
	nUI_L["nUI: Cannot register %s for skinning... frame does not have an applySkin() method"] = "nUI: ne peut enregistrer |cFFFFC0C0%s|r pour habillage... la fenêtre n'a pas de méthode applySkin()"; 
	
	-- names of the various frames that nUI allows the user to move on the screen
	
	nUI_L["Micro-Menu"]                = "Micro-Menu";
	nUI_L["Capture Bar"]               = "Barre de Capture";
	nUI_L["Watched Quests"]            = "Quêtes suivies";
	nUI_L["Quest Timer"]               = "Timer de quête";
	nUI_L["Equipment Durability"]      = "Durabilité de l'équipement";
	nUI_L["PvP Objectives"]            = "Objectifs PVP";
	nUI_L["In-Game Tooltips"]          = "Bulles d'aide de jeu";
	nUI_L["Bag Bar"]                   = "Barre des sacs";
	nUI_L["pg1 / Action Bar]"]         = "pg1 / Barre d'action]";
	nUI_L["pg2 / nUI Bonus Bar 1"]     = "pg2 / Barre bonus nUI 1";
	nUI_L["pg3 / Right 2"]             = "pg3 / Droite 2";
	nUI_L["pg4 / Right"]               = "pg4 / Droite";
	nUI_L["pg5 / BottomRight"]         = "pg5 / Bas droite";
	nUI_L["pg6 / BottomLeft"]          = "pg6 / Bas gauche";
	nUI_L["nUI Bonus Bar 2"]           = "Barre bonus nUI 0";
	nUI_L["Pet/Stance/Shapeshift Bar"] = "Barre Familier/Position/Changement de forme";
	
	-- slash command processing	
	
	nUI_SlashCommands =
	{
		[nUI_SLASHCMD_HELP] =
		{
			command = "help",
			options = "{command}",
			desc    = "Affiche la liste de toutes les commandes disponibles si {command} n'est pas fournie, si {command} est fournie, affiche les informations sur la commande spécifiée",
			message = nil,
		},
		[nUI_SLASHCMD_RELOAD] =
		{
			command = "rl",
			options = nil,
			desc    = "Recharge l'interface utilisateur et les addons (identique à /console reloadui)",
			message = nil,
		},
		[nUI_SLASHCMD_BUTTONBAG] =
		{
			command = "bb",
			options = nil,
			desc    = "Cette commande alterne l'affichage du Sac de Boutons de la minicarte ON et OFF.",
			message = nil,
		},
		[nUI_SLASHCMD_MOVERS] =
		{
			command = "movers",
			options = nil,
			desc    = "Active et désactive le déplacement des fenêtres UI standards de Blizzard telles que bulles d'aide, durabilité, timer de quête, etc.",
			message = "nUI: Le déplacement des fenêtres Blizzard est %s", -- enabled or disabled
		},
		[nUI_SLASHCMD_CONSOLE] =
		{
			command = "console",
			options = "{on|off|mouseover}",
			desc    = "Règle l'option de  visibilité pour la console supérieure où 'on' affiche toujours la console, 'off' cache la console et 'mouseover' affiche la console quand la souris passe sur la console.",
			message = "nUI: La visibilité de la console supérieure est réglée sur %s", -- "on", "off" or "mouseover"
		},
		[nUI_SLASHCMD_TOOLTIPS] =
		{
			command = "tooltips",
			options = "{owner|mouse|fixed|default}",
			desc    = "Cette option définie la position des bulles d'aides d'information où 'owner' affiche les bulles d'aide à côté de la fenêtre d'origine, 'mouse' affiche la bulle d'aide à la position de la souris, 'fixed' affiche toutres les bulles d'aide à une position fixe ou 'default' pour aucune gestion particulière des bulles d'aide",
			message = "nUI: Mode d'affiche des bulles d'aide réglé sur |cFF00FFFF%s|r", -- the chosen tooltip mode
		},
		[nUI_SLASHCMD_BAGSCALE] =
		{
			command = "bagscale",
			options = "{n}",
			desc    = "Cette option augmente ou diminue la taille de vos sacs où {n} est un nombre compris entre 0.5 et 1.5 -- 1 par défaut",
			message = "nUI: L'echelle des sacs est modifiée en |cFF00FFFF%0.2f|r", -- the chosen scale
		},
		[nUI_SLASHCMD_BAGBAR] =
		{
			command = "bagbar",
			options = nil,
			desc    = "Cette option alterne l'affichage de la barre des sacs ON et OFF",
			message = "nUI: L'affichage de la barre des sacs a été %s", -- enabled or disabled
		},
		[nUI_SLASHCMD_FRAMERATE] =
		{
			command = "framerate",
			options = "{n}",
			desc    = "Cette option change (ou active) le taux de rafraichissement maximum des animations de barres et fenêtres d'fenêtre. Augmentez {n} pour plus de fluidité, diminuez {n} pour la performance. Valeur par défaut "..nUI_DEFAULT_FRAME_RATE.." images par seconde.",
			message = "nUI: Votre taux de rafraichissement à été changé par |cFF00FFFF%0.0fFPS|r", -- the chosen rate in frames per second... change FPS if you need a different abreviation!
		},
		[nUI_SLASHCMD_SHOWANIM] =
		{
			command = "anim",
			options = nil,
			desc    = "Cette commande alterne l'affichage des portraits et barres d'fenêtres animés ON et OFF",
			message = "nUI: Affichage de portraits animés %s", -- enabled or disabled
		},
		[nUI_SLASHCMD_HUD] =
		{
			command  = "hud",
			options  = nil,
			desc     = "Cette commande permet l'accès à une série de commandes utilisées pour le comportement du HUD de nUI. Utilisez la commande '/nui hud' seule pour avoir la liste des sosus-commandes disponibles.",
			message  = nil,
			sub_menu =
			{
				[nUI_SLASHCMD_HUD_SCALE] =
				{
					command = "scale",
					options = "{n}",
					desc    = "Cette option règle l'échelle du HUD où 0.25 <= {n} <= 1.75. de petites valeurs de {n} diminuent la taille du HUD et de grandes valeurs augmententsa taille. Par défaut {n} = 1",
					message = "nUI: L'échelle du HUD a été réglée sur |cFF00FFFF%0.2f|r", -- a number
				},
				[nUI_SLASHCMD_HUD_SHOWNPC] =
				{
					command = "shownpc",
					options = nil,
					desc    = "Cette option alterne l'affichage des barres du HUD pour le ciblage de PNJs non-attaquables ON et OFF quand hors combat",
					message = "nUI: Barres HUD sur ciblage de PNJs non-attaquables a été %s", -- enabled or disabled
				},
				[nUI_SLASHCMD_HUD_HEALTHRACE] =
				{
					command = "healthrace",
					options = nil,
					desc    = "Cette option alterne l'affichage de la barre Course de Vie du HUD ON et OFF",
					message = "nUI: L'affichage de la barre HUD Course de Vie a été %s", -- enabled or disabled
				},
				[nUI_SLASHCMD_HUD_HGAP] =
				{
					command = "hgap",
					options = "{n}",
					desc    = "Cette option règle l'écart entre les côtés gauches et droits du HUD où {n} est un nombre plus grand que 0. Augmentez {n} pour augmenter l'écart entrela gauche et la droite du HUD. La valeur par défaut de {n} est 400",
					message = "nUI: L'écart horizontal du HUD est de |cFF00FFFF%0.0f|r", -- a number greater than zero
				},
				[nUI_SLASHCMD_HUD_IDLEALPHA] =
				{
					command = "idlealpha",
					options = "{n}",
					desc    = "Cette option règle la transparence du HUD quand vous êtes inactif avec {n} = 0 pour un HUD invisible et {n} = 1 pour un HUD totalement opaque. Par défaut {n} = 0",
					message = "nUI: L'alpha du HUDquand inactif a été réglée sur |cFF00FFFF%0.2f|r", -- a number between 0 and 1
				},
				[nUI_SLASHCMD_HUD_REGENALPHA] =
				{
					command = "regenalpha",
					options = "{n}",
					desc    = "Cette option règle la transparence du HUD quand vous (ou votre familier) régénérez votre vie, votre puissance ou subissez un effet négatif où {n} = 0 pour un HUD invisible et {n} = 1 pour un HUD totalement opaque . The default is {n} = 0.35",
					message = "nUI: L'alpha du HUD durant régénération a été réglé sur |cFF00FFFF%0.2f|r", -- a number between 0 and 1
				},
				[nUI_SLASHCMD_HUD_TARGETALPHA] =
				{
					command = "targetalpha",
					options = "{n}",
					desc    = "Cette option règle la transparence du HUD quand vous avez ciblé une cible valide où {n} = 0 pour un invisible HUD et {n} = 1 pour HUD totalement opaque. La valeur par défaut est {n} = 0.75",
					message = "nUI: l'apha du HUD de ciblage a éé réglé sur |cFF00FFFF%0.2f|r", -- a number between 0 and 1
				},
				[nUI_SLASHCMD_HUD_COMBATALPHA] =
				{
					command = "combatalpha",
					options = "{n}",
					desc    = "Cette option règle la transparence du HUD quand vous ou votre familier êtes en combat où {n} = 0 pour un HUD invisible et {n} = 1 pour un HUD totalement opaque. La valeur par défaut est {n} = 1",
					message = "nUI: L'apha du HUD en combat a été réglé sur |cFF00FFFF%0.2f|r", -- a number between 0 and 1
				},
			},
		},
		[nUI_SLASHCMD_CLOCK] =
		{
			command = "clock",
			options = "{12|24}",
			desc    = "Cette option règle l'affichage du tableau d'horloge sur un décompte de 12 heures ou 24 heures. 12 par défaut",
			message = "nUI: Le tableau d'horloge est réglé sur le format |cFF00FFFF%d|r heures", -- 12 or 24 hour format
		},
		[nUI_SLASHCMD_LASTITEM+1] =
		{
			command = "debug",
			options = "{n}",
			desc    = "Cette option règle le niveua de message du débuggueur de nUI. En principe vous ne devriez change le niveau de débug uniquement à la demande de l'uatuer du mod. Utilisez {n} = 0 pour désactiver le débuggage complètement (par défaut).",
			message = "nUI: Votre niveau de débuggarge est de |cFF00FFFF%d|r", -- an integer value
		},
	};
	
	nUI_L[nUI_SLASHCMD_OPTIONS( nUI_SLASHCMD_CONSOLE, "on" )]        = "on";
	nUI_L[nUI_SLASHCMD_OPTIONS( nUI_SLASHCMD_CONSOLE, "off" )]       = "off";
	nUI_L[nUI_SLASHCMD_OPTIONS( nUI_SLASHCMD_CONSOLE, "mouseover" )] = "mouseover";
	
	nUI_L[nUI_SLASHCMD_OPTIONS( nUI_SLASHCMD_TOOLTIPS, "owner" )]   = "ouwner";
	nUI_L[nUI_SLASHCMD_OPTIONS( nUI_SLASHCMD_TOOLTIPS, "mouse" )]   = "mouse";
	nUI_L[nUI_SLASHCMD_OPTIONS( nUI_SLASHCMD_TOOLTIPS, "fixed" )]   = "fixed";
	nUI_L[nUI_SLASHCMD_OPTIONS( nUI_SLASHCMD_TOOLTIPS, "default" )] = "default";
	
	-- miscellaneous slash command messages printed to the player
	
	nUI_L["The value [ %s ] is not a valid nUI slash command. Try [ /nui help ] for a list of commands"] = "L'entrée [ |cFFFFC000%s|r ] n'est pas une commande nUI valide. Essayez [ |cFF00FFFF/nui help|r ] pour la liste des commandes";
	nUI_L["nUI currently supports the following list of slash commands..."]	= "nUI supporte actuellement la liste de commnades suivantes..."; 
	nUI_L["The '/nui %s' slash command currently supports the following list of sub-commands..."] = "La commande '|cFF00FFFF/nui %s|r' supporte actuellement la liste de sous-commandes suivante...";
	nUI_L["nUI: [ %s ] is not a valid tooltip settings option... please choose from %s, %s, %s or %s"] = "nUI: [ |cFFFFC0C0%s|r ] n'est pas une option de bulle d'aide valide... merci de choisir entre |cFF00FFFF%s|r, |cFF00FFFF%s|r, |cFF00FFFF%s|r et |cFF00FFFF%s|r";
	nUI_L["nUI: [ %s ] is not a valid console visibility option... please choose from %s, %s or %s"] = "nUI: [ |cFFFFC0C0%s|r ] n'est pas une option de visibilité de la console valide... merci de choisir entre |cFF00FFFF%s|r, |cFF00FFFF%s|r et |cFF00FFFF%s|r";
	nUI_L["nUI: [ %s ] is not a valid alpha value... please choose a number between 0 and 1 where 0 is fully transparent and 1 is fully opaque."] = "nUI: [ |cFFFFC0C0%s|r ] n'est pas une valeur alpha valide... merci de choisir un nombre entre 0 et 1 où 0 est transparence totale et 1 est opacité totale.";
	nUI_L["nUI: [ %s ] is not a valid horizontal gap value... please choose a number between 1 and 1200 where 1 is very narrow and 1200 is very wide."] = "nUI: [ |cFFFFC0C0%s|r ] n'est pas une valeur d'écartement horizontal valide... merci de choisir un nombre entre 1 et 1200 où 1 est très rapproché et 1200 est très éloigné.";
	nUI_L["nUI: [ %s ] is not a valid clock option... please choose either '12' for a 12 hour clock or '24' for a 24 hour clock."] = "nUI: [ |cFFFFC0C0%s|r ] n'est pas une option d'horloge valide... merci de choisir soit '12' pour un affichage sur 12 heures ou '24' pour un affichage sur 24 heures.";	
		
	
end
