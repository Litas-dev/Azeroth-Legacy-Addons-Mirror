﻿--[[---------------------------------------------------------------------------

Copyright (c) 2008 by K. Scott Piel 
All Rights Reserved

E-mail: < kscottpiel@gmail.com >
Web:    < http://www.scottpiel.com >

This file is part of nUI.

    nUI is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    nUI is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with nUI.  If not, see <http://www.gnu.org/licenses/>.
	
THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR 
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE 
USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

-------------------------------------------------------------------------------

Translation (German)

Copyright (c) 2008 by Andre Patock
All Rights Reserved
E-mail: < andre.patock@gmx.net >


Realm: 	Alleria (PvE) [German]
Name:	Aldea (Nightelf Druid - heal)

and

Copyright (c) 2008 by Marcel Waizenhöfer
All Rights Reserved
E-mail: < ogogo@gmx.de >


Realm		Ysera (PvE) [German]
Name: Ameba (Undead Rogue-Shadowstep)


Wenn die Übersetzung teilweise nicht so gut ist, sendet mir einfach per E-mail 
eine bessere Version zu.

Diese Datei ist ein Teil von nUI.
	
	Bei nUI handelt es sich um eine freu verfügbare Software.
	Du kannst sie weitergeben und/oder sie unter Bedingungen der GNU General 
	Public License License as published by the Free Software Foundation modifizieren.

	nUI wird verteilt in der Hoffnung, dass es von Nutzen sein wird, aber OHNE JEDE GARANTIE; 
	sogar ohne die implizite Gewährleistung der Marktfähigkeit oder Eignung für einen bestimmten 
	Zweck. Lese die GNU General Public License f�r ausf�hrlichere Informationen.

	Du solltest eine Kopie der GNU General Public License zusammen mit nUI haben. 
	Ist dies nicht der Fall, siehe <http://www.gnu.org/licenses/>.

Diese Software wird von dem Inhaber von Urheberrechten und Beitragszahler
"As is" und jegliche ausdrückliche oder stillschweigend, zur Gewährleistung, einschließlich, aber nicht
Beschränkt auf die gesetzlichen Gew�hrleistungen der Marktg�ngigkeit und die Eignung für
einen besonderen Zweck abgelehnt. In keinem Fall kann laut des Urheberrecht der
Eigent�mers oder der Beitragszahler haftbar gemacht werden für etwaige direkte, indirekte, zufällige,
SPEZIELLE, EXEMPLARISCHE ODER FOLGESCHÄDEN (EINSCHLIESSLICH,
Beschränkt sich auf die Beschaffung von Ersatz Waren oder Dienstleistungen; VERLUST VON NUTZUNG,
Daten oder Gewinne; oder geschäftlicher Unterbrechung) führte, jedoch zu und über etwaige
Theorie der Haftung, ob im Vertrag, verschuldensunabhängige Haftung oder unerlaubter Handlung
(Einschließlich Fahrlässigkeit oder anderweitig). 
Die Nutzung dieser Software besteht auf eigene Gefahr, auch wenn die Möglichkeit eines Schadens oder 
der Verlust von daten besteht.

--]]---------------------------------------------------------------------------

if nUI_Locale == "deDE" then
	
	nUI_L["font1"] = "Fonts\\ARIALN.TTF";
	nUI_L["font2"] = "Fonts\\FRIZQT__.TTF";
	
	nUI_L["Welcome back to %s, %s..."] = "Willkommen auf dem Realm %s,  %s..."; -- new.. the first %s is the player name, the second is their realm name
	nUI_L["nUI version %s is loaded!"] = "nUI Version %s wurde geladen!"; -- new
	nUI_L["Type '/nui' for a list of available nUI commands."] = "Schreibe '/nui' um eine Liste der möglichen Befehle für nUI zu erhalten."; -- new
	
	-- clock strings
	
	nUI_L["am"] = "am";		-- new -- 12:01 in the morning until noon suffix
	nUI_L["pm"] = "pm";		-- new -- 12:00 noon to midnight suffix
	nUI_L["(S) <hour>:<minute><suffix> - <hour>:<minute><suffix> (L)"] = "(S) %d:%02d%s - %d:%02d%s (L)"; -- new -- 12 hour clock format where (S) is short for "Server time" and "L" is short for "Local time"
	nUI_L["(S) <hour>:<minute> - <hour>:<minute> (L)"] = "(S) %02d:%02d - %02d:%02d (L)"; -- new -- 24 hour clock format where (S) is short for "Server time" and (L) is short for "Local time"
	
	-- state strings
	
	nUI_L["|cFF00FF00ENABLED|r"]  = "|cFF00FF00EINGESCHALTET|r";
	nUI_L["|cFFFF0000DISABLED|r"] = "|cFFFF0000AUSGESCHALTET|r";
	nUI_L["~INTERRUPTED~"]        = "~UNTERBROCHEN~";
	nUI_L["~FAILED~"]             = "~FEHLGESCHLAGEN~";
	nUI_L["~MISSED~"]             = "~DANEBEN~";
	nUI_L["OFFLINE"]              = "OFFLINE";
	nUI_L["DND"]                  = "DND"; -- new -- Do Not Disturb abbreviation
	nUI_L["AFK"]                  = "AFK";
	nUI_L["DEAD"]                 = "TOD";
	nUI_L["GHOST"]                = "GEIST";
	nUI_L["FD"]                   = "FD";
	nUI_L["TAXI"]                 = "TAXI";
	
	-- time remaining (cooldowns, buffs, etc.)
	
	nUI_L["TimeLeftInHours"]   = "%0.0fh";
	nUI_L["TimeLeftInMinutes"] = "%0.0fm";
	nUI_L["TimeLeftInSeconds"] = "%0.0fs";
	nUI_L["TimeLeftInTenths"]  = "%0.1fs";
	
	-- raid and party role tooltip strings
	
	nUI_L["Party Role: |cFF00FFFF%s|r"] = "Gruppen Rolle: |cFF00FFFF%s|r";
	nUI_L["Raid Role: |cFF00FFFF%s|r"]  = "Raid Rolle: |cFF00FFFF%s|r";
	nUI_L["Raid Leader"]                = "Raid Leader";
	nUI_L["Party Leader"]               = "Gruppen Leader";
	nUI_L["Raid Assistant"]             = "Raid Assistant";
	nUI_L["Main Tank"]                  = "Main Tank";
	nUI_L["Off-Tank"]                   = "Off-Tank";
	nUI_L["Master Looter"]              = "Master Looter";
	
	-- hunter pet feeder strings
	
	nUI_L[nUI_FOOD_MEAT]	= "Fleisch";
	nUI_L[nUI_FOOD_FISH]	= "Fisch";
	nUI_L[nUI_FOOD_BREAD]	= "Brot";
	nUI_L[nUI_FOOD_CHEESE]  = "Käse";
	nUI_L[nUI_FOOD_FRUIT]	= "Obst";
	nUI_L[nUI_FOOD_FUNGUS]  = "Fungus";
	
	nUI_L["Click to feed %s"]           = "Zum essen klicken %s";
	nUI_L["Click to cancel feeding"]    = "Um das essen abzubrechen, klicken";
	nUI_L["nUI: %s can eat %s%s%s"]     = "nUI: %s kann essen %s %s %s";	
	nUI_L[" or "]                       = " oder ";
	nUI_L["nUI: You don't have a pet!"] = "nUI: Du hast keinen Begleiter!";
	
	nUI_L["nUI: You can feed %s the following...\n"] = "nUI: Du kannst %s dies essen...\n";
	nUI_L["nUI: You have nothing you can feed %s in your current inventory"] = "nUI: Du hast nichts zu essen %s in deinem Inventar";
	nUI_L["    Click the pet happiness indictor to feed your pet now"] = "Klick auf den Indikator um deinen Begleiter jetzt zu füttern";
	
	-- status bar strings
	
	nUI_L["nUI: Cannot change status bar config while in combat!"] = "nUI: Du kannst die Statusleiste Konfiguration während des Kampfes nicht verändern!";
	nUI_L["nUI: [%s] is not a valid option for orienting a status bar... use LEFT, RIGHT, TOP or BOTTOM"] = "nUI: [%s] ist keine gültige Option für die Ausrichtung der Statusleiste... verwende LEFT, RIGHT, TOP oder BOTTOM";
	nUI_L["nUI: Can not change status bar overlays while in combat!"] = "nUI: Du kannst die Statusleiste Oberfläche während des Kampfes nicht verändern!";
	nUI_L["nUI: The maximum value (%d) of a status bar must be greater than the minimum value (%d)"] = "nUI: Der maximale Wert (%d) der Statusleiste muss größer sein als der Mindestwert (%d)";
	
	-- information panel strings
	
	-- new -- this entire section is new...
	
	nUI_L["Minimap"] = "Minimap";
	
	nUI_L[nUI_INFOPANEL_MINIMAP]   		   		= "Info Panel: Minimap anzeige Modus"; -- this is the phrase shown in the mouseover tooltip
	nUI_L[nUI_INFOPANEL_MINIMAP.."Label"]		= "Minimap"; -- small word or abbreviation to show on the panel selector button
	
	nUI_L[nUI_INFOPANEL_COMBATLOG]      		= "Info Panel: Kampflog Anzeige Modus";
	nUI_L[nUI_INFOPANEL_COMBATLOG.."Label"]		= "Combat"; -- small word or abbreviation to show on the panel selector button
	
	nUI_L[nUI_INFOPANEL_BMM]		      		= "Info Panel: Schlachtfeld Minimap";
	nUI_L[nUI_INFOPANEL_BMM.."Label"]			= "Map"; -- small word or abbreviation to show on the panel selector button
	
	nUI_L[nUI_INFOPANEL_RECOUNT]		   		= "Info Panel: Recount Damage Meter Modus";
	nUI_L[nUI_INFOPANEL_RECOUNT.."Label"]		= "Recount"; -- small word or abbreviation to show on the panel selector button
	
	nUI_L[nUI_INFOPANEL_OMEN2]		      		= "Info Panel: Omen2 Aggro Modus";
	nUI_L[nUI_INFOPANEL_OMEN2.."Label"]			= "Omen2"; -- small word or abbreviation to show on the panel selector button
	
	nUI_L[nUI_INFOPANEL_OMEN2KLH]	      		= "Info Panel: Omen2 + KLH Aggro Modus";
	nUI_L[nUI_INFOPANEL_OMEN2KLH.."Label"]		= "Threat"; -- small word or abbreviation to show on the panel selector button
	
	nUI_L[nUI_INFOPANEL_OMEN2RECOUNT]		   	= "Info Panel: Omen2 + Recount Damage Meter Modus";
	nUI_L[nUI_INFOPANEL_OMEN2RECOUNT.."Label"]	= "Omen2+"; -- small word or abbreviation to show on the panel selector button
	
	nUI_L[nUI_INFOPANEL_KLH]		      		= "Info Panel: KLH Aggro Modus";
	nUI_L[nUI_INFOPANEL_KLH.."Label"]			= "KTM"; -- small word or abbreviation to show on the panel selector button
	
	nUI_L[nUI_INFOPANEL_KLHRECOUNT]	      		= "Info Panel: KLH Aggro + Recount Damage Meter Modus";
	nUI_L[nUI_INFOPANEL_KLHRECOUNT.."Label"]	= "KTM+"; -- small word or abbreviation to show on the panel selector button
	
	nUI_L["nUI: You need to go to the WoW Interface menu, select the 'Social' option and turn off the 'Simple Chat' menu option to enable integrated combat log support in nUI."] = "nUI: Es muss im WoW Interface Menü, der Einfache Chat Deaktiviert werden um den Integrierten Kampflog von nUI Anzeigen zu können.";
	nUI_L["The %s Info Panel plugin is a core plugin to nUI and cannot be disabled"] = "Das %s Info Panel plugin ist ein Wichtiges Plugin von nUI und kann nicht deaktiviert werden";
	nUI_L["Click to change information panels"] = "Drücken um die Menüs Omen/Recount etc. zu ändern";
	nUI_L["nUI: Cannot initialize the Info Panel plugin [ %s ] -- it does not have an initPanel() interface method"] = "nUI: kann nicht das Info Panel plugin laden [ |cFF00FFFF%s|r ] -- es hat nicht die initPanel() interface methode";
	nUI_L["nUI: Cannot initialize the Info Panel plugin [ %s ] -- No global object by that name exists"] = "nUI: Cannot kann nicht das Info Panel plugin laden [ |cFF00FFFF%s|r ] -- No global object by that name exists";	
	nUI_L["nUI: Cannot select the Info Panel plugin [ %s ] -- it does not have a setSelected() interface method"] = "nUI: cannot select the Info Panel plugin [ |cFF00FFFF%s|r ] -- es hat nicht die setSelected() interface methode";
	
	-- HUD layout strings (heads up display)
	
	-- new -- this entire section is new
	
	nUI_L["Click to change HUD layouts"] = "Klicken um die Darstellung des HUD's zu ändern";
	
	nUI_L[nUI_HUDLAYOUT_PLAYERTARGET]	   		= "HUD Layout: Spieler Links / Ziel Rechts"; -- mouseover tooltip phrase
	nUI_L[nUI_HUDLAYOUT_PLAYERTARGET.."Label"]	= "Spieler/Ziel"; -- small phrase or abbreviation to show on the HUD selector button
	
	nUI_L[nUI_HUDLAYOUT_HEALTHPOWER]	   		= "HUD Layout: Leben Links / Mana etc. Rechts";
	nUI_L[nUI_HUDLAYOUT_HEALTHPOWER.."Label"]	= "Leben/Kraft,Wut etc."; -- small phrase or abbreviation to show on the HUD selector button
	
	nUI_L[nUI_HUDLAYOUT_SIDEBYSIDE]	   			= "HUD Layout: Seite-bei-Seite Horizontale Leisten";
	nUI_L[nUI_HUDLAYOUT_SIDEBYSIDE.."Label"]	= "Seite-bei-Seite"; -- small phrase or abbreviation to show on the HUD selector button
	
	nUI_L[nUI_HUDLAYOUT_NOBARS]	   				= "HUD Layout: Einfaches HUD (keine Leisten)";
	nUI_L[nUI_HUDLAYOUT_NOBARS.."Label"]		= "Einfaches HUD"; -- small phrase or abbreviation to show on the HUD selector button
	
	nUI_L[nUI_HUDLAYOUT_NOHUD]		   			= "HUD Layout: Deaktiviert (kein HUD)";
	nUI_L[nUI_HUDLAYOUT_NOHUD.."Label"]			= "Kein HUD"; -- small phrase or abbreviation to show on the panel selector button
	
	nUI_L[nUI_HUDMODE_PLAYERTARGET]        = "nUI Player/Target HUD Mode";
	nUI_L[nUI_HUDSKIN_PLAYERTARGET_PET]    = nUI_L[nUI_HUDMODE_PLAYERTARGET]..": Skin zur Darstellung des Begleiters";
	nUI_L[nUI_HUDSKIN_PLAYERTARGET_PLAYER] = nUI_L[nUI_HUDMODE_PLAYERTARGET]..": Skin zur Darstellung des Spieler's";
	nUI_L[nUI_HUDSKIN_PLAYERTARGET_TARGET] = nUI_L[nUI_HUDMODE_PLAYERTARGET]..": Skin zur Darstellung des Ziels";
	nUI_L[nUI_HUDSKIN_PLAYERTARGET_TOT]    = nUI_L[nUI_HUDMODE_PLAYERTARGET]..": Skin zur Darstellung des Ziel des Ziel's (ToT)";
	
	nUI_L[nUI_HUDMODE_HEALTHPOWER]         = "nUI Health/Power HUD Mode";
	nUI_L[nUI_HUDSKIN_HEALTHPOWER_PET]     = nUI_L[nUI_HUDMODE_HEALTHPOWER]..": Skin zur Darstellung des Begleiters";
	nUI_L[nUI_HUDSKIN_HEALTHPOWER_PLAYER]  = nUI_L[nUI_HUDMODE_HEALTHPOWER]..": Skin zur Darstellung des Spielers";
	nUI_L[nUI_HUDSKIN_HEALTHPOWER_TARGET]  = nUI_L[nUI_HUDMODE_HEALTHPOWER]..": Skin zur Darstellung des Ziels";
	nUI_L[nUI_HUDSKIN_HEALTHPOWER_TOT]     = nUI_L[nUI_HUDMODE_HEALTHPOWER]..": Skin zur Darstellung des Ziel des Ziel's (ToT)";
	
	nUI_L[nUI_HUDMODE_SIDEBYSIDE]          = "nUI Side by Side HUD Mode";
	nUI_L[nUI_HUDSKIN_SIDEBYSIDE_PET]      = nUI_L[nUI_HUDMODE_SIDEBYSIDE]..": Skin zur Darstellung des Begleiters";
	nUI_L[nUI_HUDSKIN_SIDEBYSIDE_PLAYER]   = nUI_L[nUI_HUDMODE_SIDEBYSIDE]..": Skin zur Darstellung des Spieler's";
	nUI_L[nUI_HUDSKIN_SIDEBYSIDE_TARGET]   = nUI_L[nUI_HUDMODE_SIDEBYSIDE]..": Skin zur Darstellung des Ziel's";
	nUI_L[nUI_HUDSKIN_SIDEBYSIDE_TOT]      = nUI_L[nUI_HUDMODE_SIDEBYSIDE]..": Skin zur Darstellung des Ziel des Ziel's (ToT)";
	
	-- nUI_Unit strings
	
	nUI_L["Pet"]    = "Begleiter";    -- new -- this should be a small single word or abbreviation to use as a label on a small targeting button
	nUI_L["Target"] = "Ziel"; -- new -- this hsould be a small single word or abbreviation to use as a label on a small targeting button	
	nUI_L["Range"]  = "Reichweite";
	
	nUI_L["unit: player"]             = "Spieler";
	nUI_L["unit: pet"]		          = "Begleiter";
	nUI_L["unit: pettarget"]          = "Ziel des Begleiters";
	nUI_L["unit: focus"]              = "Spieler Focus";
	nUI_L["unit: focustarget"]        = "Ziel des Spieler Focus";
	nUI_L["unit: target"]             = "Spieler Ziel";
	nUI_L["unit: %s-target"]          = "%s's Ziel";
	nUI_L["unit: mouseover"]          = "Mouseover Ziel";
	nUI_L["unit: targettarget"]       = "Ziel des Ziels (ToT)";
	nUI_L["unit: targettargettarget"] = "Ziel des ToT (ToTT)";
	nUI_L["unit: party%d"]            = "Gruppen Mitglied %d";
	nUI_L["unit: party%dpet"]         = "Gruppen Mitglied %d's Begleiter";
	nUI_L["unit: party%dtarget"]      = "Gruppen Mitglied %d's Ziel";
	nUI_L["unit: party%dpettarget"]   = "Gruppen Mitglied %d Pet Ziel";
	nUI_L["unit: raid%d"]             = "Raid Mitglied %d";
	nUI_L["unit: raid%dpet"]          = "Raid Mitglied %d's Begleiter";
	nUI_L["unit: raid%dtarget"]       = "Raid Mitglied %d's Ziel";
	nUI_L["unit: raid%dpettarget"]    = "Raid Mitglied %d Pet Ziel";

	nUI_L[nUI_UNITMODE_PLAYER]        = "nUI Einzel Spieler Modus"; -- new
	nUI_L[nUI_UNITSKIN_PARTYFOCUS]    = nUI_L[nUI_UNITMODE_PLAYER]..": Spieler Focus's Skin"; -- new
	nUI_L[nUI_UNITSKIN_PARTYMOUSE]    = nUI_L[nUI_UNITMODE_PLAYER]..": Mouseover Ziel Skin"; -- new
	nUI_L[nUI_UNITSKIN_SOLOPET]       = nUI_L[nUI_UNITMODE_PLAYER]..": Begleiter Skin"; -- new
	nUI_L[nUI_UNITSKIN_SOLOPETBUTTON] = nUI_L[nUI_UNITMODE_PLAYER]..": Begleiter Ziel Knopf/Schaltflächen Skins ... z.B. Ziel's Begleiter, Spieler Focus, etc"; -- new
	nUI_L[nUI_UNITSKIN_SOLOPLAYER]    = nUI_L[nUI_UNITMODE_PLAYER]..": Spieler Skin"; -- new
	nUI_L[nUI_UNITSKIN_SOLOTARGET]    = nUI_L[nUI_UNITMODE_PLAYER]..": Ziel Skin"; -- new
	nUI_L[nUI_UNITSKIN_SOLOTGTBUTTON] = nUI_L[nUI_UNITMODE_PLAYER]..": Ziel Knopf/Schaltflächen Skins ... z.B. Spieler Focus, etc."; -- new
	nUI_L[nUI_UNITSKIN_SOLOTOT]       = nUI_L[nUI_UNITMODE_PLAYER]..": Ziel des Ziels (ToT) Skin"; -- new

	nUI_L[nUI_UNITMODE_PARTY]          = "nUI Party/Group Mode"; -- new
	nUI_L[nUI_UNITSKIN_PARTYFOCUS]     = nUI_L[nUI_UNITMODE_PARTY]..": Spieler Focus' Darstellung"; -- new
	nUI_L[nUI_UNITSKIN_PARTYMOUSE]     = nUI_L[nUI_UNITMODE_PARTY]..": Mouseover Ziel Darstellung"; -- new
	nUI_L[nUI_UNITSKIN_PARTYPLAYER]    = nUI_L[nUI_UNITMODE_PARTY]..": Spieler Darstellung"; -- new
	nUI_L[nUI_UNITSKIN_PARTYPET]       = nUI_L[nUI_UNITMODE_PARTY]..": Begleiter Darstellung"; -- new
	nUI_L[nUI_UNITSKIN_PARTYTARGET]    = nUI_L[nUI_UNITMODE_PARTY]..": Ziel Darstellung"; -- new
	nUI_L[nUI_UNITSKIN_PARTYTOT]       = nUI_L[nUI_UNITMODE_PARTY]..": Ziel des Ziel's (ToT) Darstellung"; -- new
	nUI_L[nUI_UNITSKIN_PARTYFOCUS]     = nUI_L[nUI_UNITMODE_PARTY]..": Spieler Focus Darstellung"; -- new
	nUI_L[nUI_UNITSKIN_PARTYLEFT]      = nUI_L[nUI_UNITMODE_PARTY]..": Linke Seite Party Mitglieder Darstellung"; -- new
	nUI_L[nUI_UNITSKIN_PARTYRIGHT]     = nUI_L[nUI_UNITMODE_PARTY]..": Rechte Seite Party Mitglieder Darstellung"; -- new
	nUI_L[nUI_UNITSKIN_PARTYPETBUTTON] = nUI_L[nUI_UNITMODE_PARTY]..": Party Mitglieder und Begleiter Knopf/Schaltfläche Darstellung"; -- new
	nUI_L[nUI_UNITSKIN_PARTYTGTBUTTON] = nUI_L[nUI_UNITMODE_PARTY]..": Party Mitglieder and Focus Knopf/Schaltfläche Darstellung"; -- new
	nUI_L[nUI_UNITSKIN_PARTYMOUSE]     = nUI_L[nUI_UNITMODE_PARTY]..": Mouseover Darstellung"; -- new
	
	nUI_L[nUI_UNITMODE_RAID10]          ="nUI 10 Spieler Raid Mode"; -- new
	nUI_L[nUI_UNITSKIN_RAID10FOCUS]     = nUI_L[nUI_UNITMODE_RAID10]..": Spieler Focus Darstellung"; -- new
	nUI_L[nUI_UNITSKIN_RAID10MOUSE]     = nUI_L[nUI_UNITMODE_RAID10]..": Mouseover Ziel Darstellung"; -- new
	nUI_L[nUI_UNITSKIN_RAID10PLAYER]    = nUI_L[nUI_UNITMODE_RAID10]..": Spieler Darstellung"; -- new
	nUI_L[nUI_UNITSKIN_RAID10PET]       = nUI_L[nUI_UNITMODE_RAID10]..": Begleiter Darstellung"; -- new
	nUI_L[nUI_UNITSKIN_RAID10TARGET]    = nUI_L[nUI_UNITMODE_RAID10]..": Ziel Darstellung"; -- new
	nUI_L[nUI_UNITSKIN_RAID10TOT]       = nUI_L[nUI_UNITMODE_RAID10]..": Ziel des Ziel's (ToT) Darstellung"; -- new
	nUI_L[nUI_UNITSKIN_RAID10FOCUS]     = nUI_L[nUI_UNITMODE_RAID10]..": Focus Darstellung"; -- new
	nUI_L[nUI_UNITSKIN_RAID10LEFT]      = nUI_L[nUI_UNITMODE_RAID10]..": Linke Seite Raid Mitglieder Darstellung"; -- new
	nUI_L[nUI_UNITSKIN_RAID10RIGHT]     = nUI_L[nUI_UNITMODE_RAID10]..": Rechte Seite Raid Mitglieder Darstellung"; -- new
	nUI_L[nUI_UNITSKIN_RAID10PETBUTTON] = nUI_L[nUI_UNITMODE_RAID10]..": Raid Member und Focus Darstellung"; -- new
	nUI_L[nUI_UNITSKIN_RAID10TGTBUTTON] = nUI_L[nUI_UNITMODE_RAID10]..": Raid Member und Ziel Darstellung"; -- new
	nUI_L[nUI_UNITSKIN_RAID10MOUSE]     = nUI_L[nUI_UNITMODE_RAID10]..": Mouseover Darstellung"; -- new
	
	nUI_L[nUI_UNITPANEL_PLAYER]      		= "Aufgaben Panel: Solo Spieler Modus";
	nUI_L[nUI_UNITPANEL_PLAYER.."Label"]	= "Spieler";
	
	nUI_L[nUI_UNITPANEL_PARTY]       		= "Aufgaben Panel: Gruppen Modus";
	nUI_L[nUI_UNITPANEL_PARTY.."Label"] 	= "Gruppe";
	
	nUI_L[nUI_UNITPANEL_RAID10]      		= "Aufgaben Panel: 10 Spieler Raid Modus";
	nUI_L[nUI_UNITPANEL_RAID10.."Label"]	= "Raid 10";
	
	nUI_L[nUI_UNITPANEL_RAID15]      		= "Aufgaben: 15 Spieler Raid Modus";
	nUI_L[nUI_UNITPANEL_RAID15.."Label"]	= "Raid 15";
	
	nUI_L[nUI_UNITPANEL_RAID20]      		= "Unit Panel: 20 Spieler Raid Modus"; -- new
	nUI_L[nUI_UNITPANEL_RAID20.."Label"]	= "Raid 20"; -- new
	
	nUI_L[nUI_UNITPANEL_RAID25]      		= "Aufgaben: 25 Spieler Raid Modus";
	nUI_L[nUI_UNITPANEL_RAID25.."Label"]	= "Raid 25";
        
	nUI_L[nUI_UNITPANEL_RAID40]      		= "Aufgaben: 40 Spieler Raid Modus";
	nUI_L[nUI_UNITPANEL_RAID40.."Label"]	= "Raid 40";
	
	nUI_L["Click to change unit frame panels"] = "Click to change unit frame panels"; -- new
	
	nUI_L["<unnamed frame>"] = "<unbekannter frame>";
	nUI_L["unit change"] = "Aufgaben ändern";
	nUI_L["unit class"] = "Klasse";
	nUI_L["pet happiness"] = "Begleiter Glücklichkeitsstatus";
	nUI_L["unit label"] = "label";
	nUI_L["unit level"] = "Level";
	nUI_L["unit reaction"] = "Reaktion";
	nUI_L["unit health"] = "Gesundheit";
	nUI_L["unit power"] = "Kraft";
	nUI_L["unit portrait"] = "Portrait";
	nUI_L["raid group"] = "Raid Gruppe";
	nUI_L["unit PvP"] = "PvP";
	nUI_L["raid target"] = "Raid Ziel";
	nUI_L["casting bar"] = "Casting Leiste";
	nUI_L["ready check"] = "prüfen";
	nUI_L["unit status"] = "Status";
	nUI_L["unit aura"] = "Aura";
	nUI_L["unit combat"] = "bekämpfen";
	nUI_L["unit resting"] = "ruhen";
	nUI_L["unit role"] = "Würfeln";
	nUI_L["unit feedback"] = "Rückmeldung";
	
	nUI_L["passed unit id is <nil> in callback table for %s"] = "passed unit id is <nil> in callback table for %s"; -- new
	nUI_L["nUI: Warning.. anchoring %s to %s -- anchor point has a <nil> value."] = "nUI: Warnung .. Verankerung %s zu %s -- hat den <nil> Wert.";
	nUI_L["nUI: Cannot register %s for scaling... frame does not have a applyScale() method"] = "nUI: Kann für die Skallierung %s nicht registrieren... frame hat keinen applyScale()";
	nUI_L["nUI: Cannot register %s for scaling... frame does not have a applyAnchor() method"] = "nUI: Kann für die Skallierung %s nicht registrieren... frame hat keinen applyAnchor()";
	nUI_L["nUI: %s %s callback %s does not have a newUnitInfo() method."] = "%s %s zurück rufen %s hat keine newUnitInfo() Wirkung.";
	nUI_L["nUI_UnitClass.lua: unhandled unit class [%s] for [%s]"] = "nUI_UnitClass.lua: unbehandelte klassen Einheit [%s] für [%s]";
	nUI_L["nUI: click-casting registration is %s"] = "nUI: Die Klick-casting registrierung ist %s";
	nUI_L["nUI: must pass a valid parent frame to nUI_Unit:createFrame() for unit id [%s (%s)]"] = "nUI: muss einen gültigen frame zu nUI_Unit:createFrame() haben, für unit id [%s (%s)]";
	nUI_L["nUI says: Gratz for reaching level %d %s!"] = "nUI sagt: Herzlichen Glückwunsch zum erreichen von level %d %s!";
	nUI_L["nUI_Unit: [%s] is not a valid unit frame element type!"] = "nUI_Unit: [%s] Typ ist keine gültige Einheit!";
	nUI_L["nUI_Unit: [%s] is not a known unit skin name!"] = "nUI_Unit: [%s] Ist kein gültiger Skin Name!";
	
	-- nUI_Unit hunter pet strings
	
	nUI_L["Your pet"] = "Dein Begleiter";
	nUI_L["quickly"] = "schnell";
	nUI_L["slowly"] = "langsam";
	nUI_L["nUI: %s is happy."] = "nUI: %s ist glücklich.";
	nUI_L["nUI: %s is unhappy... time to feed!"] = "nUI: %s ist unglücklich ... Zeit zum füttern";
	nUI_L["nUI: Warning! %s is |cFFFFFFFFNOT|r happy! Better feed soon."] = "nUI: Warnung! %s ist |cFFFFFFFFNICHT|r glücklich! Benötige besseres Futter.";
	nUI_L["nUI: Warning... %s is %s losing loyalty "] = "nUI: Warnung... %s ist dabei %s die Loyalität zu verlieren ";
	nUI_L["nUI: %s is %s gaining loyalty"] = "nUI: %s ist dabei %s die Loyalität wieder zu gewinnen";
	nUI_L["nUI: %s has stopped gaining loyalty"] = "nUI: %s hat aufgehört Loyalität zu gewinnen";
	nUI_L["nUI: %s has stopped losing loyalty"] = "nUI: %s hat aufgehört Loyalität zu verlieren";
	nUI_L["nUI_UnitHappiness.lua: unhandled pet happiness value (%s)"] = "nUI_UnitHappiness.lua: unbehandelte Pet Werte (%s)";
	nUI_L["Your pet's current damage bonus is %d%%"] = "Der Bonus Schaden deines Begleiters ist %+d%%"; -- new
	nUI_L["Your pet's current damage penalty is %d%%"] = "Der Schadensverlust deines Begleiters ist %+d%%"; -- new
	nUI_L["nUI: It looks to me like you're a little busy... maybe you should try feeding %s AFTER you leave combat?"] = "nUI: It looks to me like you're a little busy... maybe you should try feeding %s AFTER you leave combat?"; -- new
	nUI_L["nUI: I looked everywhere, but I couldn't find a pet to feed. Perhaps he's in your backpack?"] = "nUI: I looked everywhere, but I couldn't find a pet to feed. Perhaps he's in your backpack?"; -- new
	nUI_L["nUI: You know, I could be wrong, but I don't think feeding %s is a very good idea... it doesn't look to me like what you have in your bags is what %s is thinking about eating."] = "nUI: Weist du, ich könnte falsch legen, aber ich denke nicht %s zu verfüttern ist eine gute Idee... es sieht nicht aus als hättest du etwas im Inventar wo man verfüttern könnte."; -- new

	-- miscelaneous strings
	
	nUI_L["Version"]             = "nUI Version |cFF00FF00%s|r"; -- new -- prints the current version number
	nUI_L["Copyright"]           = "Copyright (C) 2008 by K. Scott Piel"; -- new
	nUI_L["Rights"]              = "Alle Rechte vorbehalten"; -- new
	nUI_L["Off Hand Weapon:"]    = "Nebenhand Waffe:";
	nUI_L["Main Hand Weapon:"]   = "Haupthand Waffe:";
	nUI_L["Group %d"]            = "Gruppe %d";
	nUI_L["MS"]                  = "MS"; -- new -- abbreviation label for latency in milliseconds
	nUI_L["FPS"]				 = "FPS"; -- new -- abbreviation label for frame rate in "Frames Per Second"
	nUI_L["Minimap Button Bag"]  = "Minimap Button Bag"; -- new -- label for the bag bar "button bag" used to hold the collection of buttons that are normally around the minimap
	
	nUI_L[FACTION_UPDATE_START_STRING]    = "EUER RUF bei der Fraktion ";
	nUI_L[FACTION_UPDATE_END_STRING]      = " hat sich um";
	nUI_L[FACTION_UPDATE_INCREASE_STRING] = "verbessert";
	
	-- health race bar tooltip strings
	
	nUI_L["nUI Health Race Stats..."] = "nUI Health Race Stats..."; -- new
	nUI_L["No current advantage to <player> or <target>"] = "Kein Vorteil zu %s oder %s"; -- new
	nUI_L["<unit name>'s Health: <current>/<maximum> (<percent>)"] = "%s's Gesundheit: |cFF00FF00%d/%d|r (|cFFFFFFFF%0.1f%%|r)"; -- new
	nUI_L["Advantage to <player>: <pct>"] = "Vorteil zu %s: (|cFF00FF00%+0.1f%%|r)"; -- new 
	nUI_L["Advantage to <target>: <pct>"] = "Vorteil zu %s: (|cFFFFC0C0%0.1f%%|r)"; -- new
	
	-- skinning system messages
	
	nUI_L["nUI could not load the currently selected skin [ %s ]... perhaps you have it disabled? Switching to the default nUI skin."] = "nUI konnte den gewählten Skin nicht laden [ |cFFFFC0C0%s|r ]... möglicherweiße ist er Deaktiviert ? Wechsle zu dem Standart Skin."; -- new
	nUI_L["nUI: Cannot register %s for skinning... frame does not have a applySkin() method"] = "nUI: Kann gespeichert werden |cFFFFC0C0%s|r als skin... Fenster hat keine applySkin() method???"; -- new
	
	-- names of the various frames that nUI allows the user to move on the screen
	
	-- new / this entire section is new...
	-- these are labels for all of the movable frames in UI (the frames the user can drag around after using '/nui movers'
	
	nUI_L["Micro-Menu"]                = "Mini-Menü";
	nUI_L["Capture Bar"]               = "Capture Bar";
	nUI_L["Watched Quests"]            = "Quests überwachen";
	nUI_L["Quest Timer"]               = "Quest Timer";
	nUI_L["Equipment Durability"]      = "Ausrüstung Haltbarkeit";
	nUI_L["PvP Objectives"]            = "PvP Ziele";
	nUI_L["In-Game Tooltips"]          = "In-Game Tooltips";
	nUI_L["Bag Bar"]                   = "Taschen Leiste";
	nUI_L["pg1 / Action Bar]"]         = "pg1 / Actions Leiste]";
	nUI_L["pg2 / nUI Bonus Bar 1"]     = "pg2 / nUI Bonus Leiste 1";
	nUI_L["pg3 / Right 2"]             = "pg3 / Rechts 2";
	nUI_L["pg4 / Right"]               = "pg4 / Rechts";
	nUI_L["pg5 / BottomRight"]         = "pg5 / Unten Rechts";
	nUI_L["pg6 / BottomLeft"]          = "pg6 / Unten Links";
	nUI_L["nUI Bonus Bar 2"]           = "nUI Bonus Leiste 2";
	nUI_L["Pet/Stance/Shapeshift Bar"] = "Begleiter/Haltung/Verstohlenheits Leiste";
	
	-- slash command processing	
	
	-- new / this entire section is new...
	-- there are four components to each slash command entry... the command word the user types after the "/nui", a list of options
	-- (or arguments if you prefer) the user can provide to the command, a description of the command itself and a message that
	-- is printed after the command is executed. Any or all of these elements can be translated to make sense in the local language
	-- The only thing that cannot be translated, of course, is the "/nui" prefix itself. If any element is "nil" then it just does 
	-- not apply to that command and can be ignored.
	
	nUI_SlashCommands =
	{
		[nUI_SLASHCMD_HELP] =
		{
			command = "help",
			options = "{command}",
			desc    = "Zeigt eine Liste mit allen verfügbaren Befehlen an wenn {command} nicht gegeben ist oder, wenn {command} gegebeben ist. Zeigt alle verfügbaren befehle an.",
			message = nil,
		},
		[nUI_SLASHCMD_RELOAD] =
		{
			command = "rl",
			options = nil,
			desc    = "Startet das Interface neu und Aktiviert alle neu Aktivierten Addons (das gleiche wie /console reloadui)",
			message = nil,
		},
		[nUI_SLASHCMD_BUTTONBAG] =
		{
			command = "bb",
			options = nil,
			desc    = "Dieser Befehl blendet den Minimap ButtonBag (Wichtige Knöpfe für Addons etc) ein und aus.",
			message = nil,
		},
		[nUI_SLASHCMD_MOVERS] =
		{
			command = "movers",
			options = nil,
			desc    = "Ermöglicht es alle Blizzard Fenster wie Handeln,Talentbäume,Questmenü etc. zu verschieben.",
			message = "nUI: Blizzard Fenster verschieben wurde auf %s gesetzt", -- enabled or disabled
		},
		[nUI_SLASHCMD_CONSOLE] =
		{
			command = "console",
			options = "{on|off|mouseover}",
			desc    = "Stellt die Sichtbarkeit der Console oben Mitte ein 'on' zeigt die Console immer, 'off' versteckt die Console und 'mouseover' zeigt die Console nur wenn man mit der Maus darüber fährt.",
			message = "nUI: Die Sichtbarkeit der Console wurde auf %s gestellt", -- "on", "off" or "mouseover"
		},
		[nUI_SLASHCMD_TOOLTIPS] =
		{
			command = "tooltips",
			options = "{owner|mouse|fixed|default}",
			desc    = "This option sets the location of the mouseover tooltips where 'owner' displays the tooltip next to the frame that owns it, 'mouse' displays the tooltip at the current mouse location, 'fixed' displays all tooltips at a fixed location on screen or 'default' does not manage tooltips at all",
			message = "nUI: Tooltip display mode changed to |cFF00FFFF%s|r", -- the chosen tooltip mode
		},
		[nUI_SLASHCMD_BAGSCALE] =
		{
			command = "bagscale",
			options = "{n}",
			desc    = "Diese Option vergrößert oder verkleinert die Größe der Taschen wobei die Zahl {n} zwischen 0.5 und 1.5 liegen muss -- 1 ist Standart",
			message = "nUI: Die Taschen größe wurde auf |cFF00FFFF%0.2f|r gesetzt", -- the chosen scale
		},
		[nUI_SLASHCMD_BAGBAR] =
		{
			command = "bagbar",
			options = nil,
			desc    = "Diese Option schaltet die Taschenleiste ein und aus",
			message = "nUI: Die Taschenleiste wurde %s geschaltet", -- enabled or disabled
		},
		[nUI_SLASHCMD_FRAMERATE] =
		{
			command = "framerate",
			options = "{n}",
			desc    = "Diese Option erhöht (oder veringert) die maximale abfrage rate der Animationen und der Leisten. Erhöhe {n} um ein Schnelleres Interface zu haben (Verringerte Performance (FPS)), verringere {n} für Geschwindigkeit (Verbesserte Performance (FPS)). Der standart ist "..nUI_DEFAULT_FRAME_RATE.." Bilder pro Sekunde (FPS).",
			message = "nUI: Deine Bild wiederhohl Rate wurde auf |cFF00FFFF%0.0fFPS|r gesetzt", -- the chosen rate in frames per second... change FPS if you need a different abreviation!
		},
		[nUI_SLASHCMD_SHOWANIM] =
		{
			command = "anim",
			options = nil,
			desc    = "Diese Option Schaltet die Animation der Portraits(Bilder) und der Leisten ein und aus",
			message = "nUI: Die Animationen wurden %s geschallten<y", -- enabled or disabled
		},
		[nUI_SLASHCMD_HUD] =
		{
			command  = "hud",
			options  = nil,
			desc     = "Dieser Befehl giebt Zugriff auf die Befehle um das HUD von nUI einzustellen. Nutze den Befehl '/nui hud' um eine Liste der Unter-Befehle anzeigen zu lassen.",
			message  = nil,
			sub_menu =
			{
				[nUI_SLASHCMD_HUD_SCALE] =
				{
					command = "scale",
					options = "{n}",
					desc    = "Diese Option legt die Größe des HUD fest wobei 0.25 <= {n} <= 1.75. Ein kleinerer Wert von {n} verkleinert das HUD und ein größerer Wert vergrößert das HUD. Der Standart Wert von {n} = 1",
					message = "nUI: Die Größe des HUD wurde auf |cFF00FFFF%0.2f|r gesetzt", -- a number
				},
				[nUI_SLASHCMD_HUD_SHOWNPC] =
				{
					command = "shownpc",
					options = nil,
					desc    = "Diese Option schaltet das HUD bei befreundeten NPC's sofern man sich nicht im Kampf befindet aus.",
					message = "nUI: HUD bei Befreundeten NPC's anzeigen ( sofern nicht im Kampf ) %s", -- enabled or disabled
				},
				[nUI_SLASHCMD_HUD_HEALTHRACE] =
				{
					command = "healthrace",
					options = nil,
					desc    = "Diese Option schaltet die integrierte Lebenleiste im HUD an und aus.",
					message = "nUI: Die Lebensanzeige vom HUD wurde %s", -- enabled or disabled
				},
				[nUI_SLASHCMD_HUD_HGAP] =
				{
					command = "hgap",
					options = "{n}",
					desc    = "Diese Option stellt den Horizontalen Abstand zwischen der Linken und der Rechten seite des HUD's ein wobei {n} größer seien MUSS als 0. Erhöhe {n} um den Abstand zu vergrößern. Der Standart Wert von {n} ist 400",
					message = "nUI: Der Horizontale Abstand wurde auf |cFF00FFFF%0.0f|r gesetzt", -- a number greater than zero
				},
				[nUI_SLASHCMD_HUD_IDLEALPHA] =
				{
					command = "idlealpha",
					options = "{n}",
					desc    = "Diese Option stellt die Transparenz des HUD's wärend man sich nicht im Kampf befindet ein. Woebei {n} = 0 für komplett unsichtbar und {n} = 1 für Komplett sichtbares HUD ist. Der Standart Wert von {n} = 0",
					message = "nUI: Die Sichtbarkeit des HUD's wurde auf |cFF00FFFF%0.2f|r gesetzt", -- a number between 0 and 1
				},
				[nUI_SLASHCMD_HUD_REGENALPHA] =
				{
					command = "regenalpha",
					options = "{n}",
					desc    = "Diese Option stellt die Transparenz des HUD's wärend man selbst (oder der Begleiter) Leben/Energie/Mana Regeneriert oder einen Debuffed hat wobei {n} = 0 für komplett unsichtbar ist und {n} = 1 für Komplett sichtbares HUD ist. Der Standart Wert von {n} = 0.35",
					message = "nUI: Die Transparenz des HUD's wärend man Reggt oder Debuffed ist wurde auf |cFF00FFFF%0.2f|r gesetzt", -- a number between 0 and 1
				},
				[nUI_SLASHCMD_HUD_TARGETALPHA] =
				{
					command = "targetalpha",
					options = "{n}",
					desc    = "Diese Option legt die Transpraenz des HUD's wärend man ein richtiges Ziel hat (z.b. Angreifbar) fest, wobei {n} = 0 für komplett unsichtbar und {n} = 1 für ein komplett sichtbares HUD ist. Der Standart Wert von {n} = 0.75",
					message = "nUI: Die Transparenz des HUD's wärend man ein richtiges ziel gewählt hat wurde auf |cFF00FFFF%0.2f|r gesetzt", -- a number between 0 and 1
				},
				[nUI_SLASHCMD_HUD_COMBATALPHA] =
				{
					command = "combatalpha",
					options = "{n}",
					desc    = "Diese Option legt die Transparenz wärend man sich selbst oder der Begleiter im Kampf befindet fest, wobei {n} = 0 für komplett unsichtbar und {n} = 1 für ein komplett sichtbares HUD ist. Der Standart Wert von {n} = 1",
					message = "nUI: Die Transparenz des HUD's wärend des Kampfes wurde auf |cFF00FFFF%0.2f|r gesetzt", -- a number between 0 and 1
				},
			},
		},
		[nUI_SLASHCMD_CLOCK] =
		{
			command = "clock",
			options = "{12|24}",
			desc    = "Diese Option stell die Uhr des Interfaces ( unten Mitte ) auf eine (12 Stunden AM/PM) bzw 24 Stunden Zeit ein. Der Standart Wert ist 12",
			message = "nUI: Die Uhr des Interfaces wurde auf das |cFF00FFFF%d|r Stundenformat geändert", -- 12 or 24 hour format
		},
		[nUI_SLASHCMD_LASTITEM+1] =
		{
			command = "debug",
			options = "{n}",
			desc    = "Diese Option stellt den Debugger von nUI auf das gewünschte Nachrichtenlevel ein. Man sollte diesen Wert nur ändern wenn man von einem Moderator zwecks Hilfe anfrage gebeten wurde. Nutze {n} = 0 um den Debugger zu Deaktivieren (Standart).",
			message = "nUI: Der DebuggLevel wurde auf |cFF00FFFF%d|r gesetzt", -- an integer value
		},
	};
	
	-- new -- these strings are the optional arguments to their respective commands and can be 
	--        translated to make sense in the local language
	
	nUI_L[nUI_SLASHCMD_OPTIONS( nUI_SLASHCMD_CONSOLE, "on" )]        = "AN";
	nUI_L[nUI_SLASHCMD_OPTIONS( nUI_SLASHCMD_CONSOLE, "off" )]       = "AUS";
	nUI_L[nUI_SLASHCMD_OPTIONS( nUI_SLASHCMD_CONSOLE, "mouseover" )] = "mouseover";
	
	nUI_L[nUI_SLASHCMD_OPTIONS( nUI_SLASHCMD_TOOLTIPS, "owner" )]   = "owner";
	nUI_L[nUI_SLASHCMD_OPTIONS( nUI_SLASHCMD_TOOLTIPS, "mouse" )]   = "mause";
	nUI_L[nUI_SLASHCMD_OPTIONS( nUI_SLASHCMD_TOOLTIPS, "fixed" )]   = "gefixed";
	nUI_L[nUI_SLASHCMD_OPTIONS( nUI_SLASHCMD_TOOLTIPS, "default" )] = "Standart";
	
	-- new -- miscellaneous slash command messages printed to the player
	
	nUI_L["The value [ %s ] is not a valid nUI slash command. Try [ /nui help ] for a list of commands"] = "Der Wert [ |cFFFFC000%s|r ] ist kein Gültiger /nUI Befehl. Nutze [ |cFF00FFFF/nui help|r ] für eine Liste der möglichen Befehle";
	nUI_L["nUI currently supports the following list of slash commands..."]	= "nUI unterstüzt momentan folgende Befehle..."; 
	nUI_L["The '/nui %s' slash command currently supports the following list of sub-commands..."] = "Der '|cFF00FFFF/nui %s|r' unterstützt folgende Unter-Befehle...";
	nUI_L["nUI: [ %s ] is not a valid tooltip settings option... please choose from %s, %s, %s or %s"] = "nUI: [ |cFFFFC0C0%s|r ] is not a valid tooltip settings option... please choose from |cFF00FFFF%s|r, |cFF00FFFF%s|r, |cFF00FFFF%s|r or |cFF00FFFF%s|r";
	nUI_L["nUI: [ %s ] is not a valid console visibility option... please choose from %s, %s or %s"] = "nUI: [ |cFFFFC0C0%s|r ] ist kein richtiger Wert für die Consolen Sichtbarkeit... bitte wähle zwischen |cFF00FFFF%s|r, |cFF00FFFF%s|r or |cFF00FFFF%s|r";
	nUI_L["nUI: [ %s ] is not a valid alpha value... please choose choose a number between 0 and 1 where 0 is fully transparent and 1 is fully opaque."] = "nUI: [ |cFFFFC0C0%s|r ] ist kein gültiger Wert ... bitte wähle zwischen 0 und 1 wobei 0 komplett Transparent und 1 vollkommen sichtbar ist.";
	nUI_L["nUI: [ %s ] is not a valid horizontal gap value... please choose choose a number between 1 and 1200 where 1 is very narrow and 1200 is very wide."] = "nUI: [ |cFFFFC0C0%s|r ] ist kein gültiger horizontal Wert ... bitte wähle zwischen 1 und 1200 wobei 1 sehr klein/dünn und 1200 Weit ist.";
	nUI_L["nUI: [ %s ] is not a valid clock option... please choose choose either '12' for a 12 hour clock or '24' for a 24 hour clock."] = "nUI: [ |cFFFFC0C0%s|r ] ist kein gültiger Wert ... bitte wähle zwischen '12' für 12 Stunden Uhrzeit und der '24' Stunden Uhrzeit.";	
		
			
end
