local L = LibStub("AceLocale-3.0"):NewLocale("JHide", "enUS", true)

-- Chat commands
L["JHide"] = true
L["jhide"] = true

--Option Tabs Names
L["General Options"] = true
L["Sidebar Options"] = true
L["Colour Options"] = true

--Colour Tab Options
L["JHide Color"] = true 		--FillColour Tag
L["Sets the color for JHide"] = true	--FillColour Mouseover



















L["Message"] = true
L["Message Description"] = true
L["<Message>"] = true
